--TEST--
Inspect a minimal valid SEC v1 container without trusting metadata
--SKIPIF--
<?php if (!extension_loaded('concheron_sec')) die('skip concheron_sec not loaded'); ?>
--FILE--
<?php
$p = sys_get_temp_dir() . '/consec-test-' . getmypid() . '.sec';
$m = '{"format":"CONCHERON-SEC","format_version":1}';
$header = 'CONSEC01' . pack('n', 1) . pack('n', 0) . pack('N', 0) .
          pack('N', strlen($m)) . pack('N', 0) . pack('N2', 0, 0) .
          pack('N', 0) . pack('N', 0);
file_put_contents($p, $header . $m);
$r = concheron_sec_inspect_package($p);
unlink($p);
echo $r['success'] ? 'success' : 'fail', "\n";
echo $r['verified'] ? 'verified' : 'unverified', "\n";
echo $r['format_version'], "\n";
echo $r['manifest_raw'], "\n";
?>
--EXPECT--
success
unverified
1
{"format":"CONCHERON-SEC","format_version":1}
