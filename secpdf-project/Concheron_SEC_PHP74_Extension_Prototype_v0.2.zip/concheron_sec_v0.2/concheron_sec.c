#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "php.h"
#include "ext/standard/info.h"
#include "php_concheron_sec.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define SEC_MAGIC "CONSEC01"
#define SEC_MAGIC_LEN 8
#define SEC_HEADER_SIZE 40
#define SEC_MAX_MANIFEST (1024U * 1024U)
#define SEC_MAX_RECIPIENT (1024U * 1024U)
#define SEC_MAX_SIGNATURE (1024U * 1024U)
#define SEC_MAX_PACKAGE ((uint64_t) 1024U * 1024U * 1024U * 4U)

static uint16_t sec_be16(const unsigned char *p) {
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}
static uint32_t sec_be32(const unsigned char *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t sec_be64(const unsigned char *p) {
    return ((uint64_t)sec_be32(p) << 32) | sec_be32(p + 4);
}
static void sec_error(zval *rv, const char *code, const char *message) {
    array_init(rv);
    add_assoc_bool(rv, "success", 0);
    add_assoc_string(rv, "error_code", (char *)code);
    add_assoc_string(rv, "message", (char *)message);
}

PHP_FUNCTION(concheron_sec_version) {
    array_init(return_value);
    add_assoc_string(return_value, "extension_version", PHP_CONCHERON_SEC_VERSION);
    add_assoc_long(return_value, "api_version", PHP_CONCHERON_SEC_API_VERSION);
    zval pv, cs;
    array_init(&pv); add_next_index_long(&pv, 1); add_assoc_zval(return_value, "package_versions", &pv);
    array_init(&cs); add_next_index_string(&cs, "SEC-SUITE-1"); add_assoc_zval(return_value, "crypto_suites", &cs);
}

PHP_FUNCTION(concheron_sec_capabilities) {
    array_init(return_value);
    add_assoc_bool(return_value, "package_inspect", 1);
    add_assoc_bool(return_value, "usb_provider", 0);
    add_assoc_bool(return_value, "server_key_provider", 0);
    add_assoc_bool(return_value, "package_verify", 0);
    add_assoc_bool(return_value, "package_import", 0);
    add_assoc_bool(return_value, "staff_certificate_verify", 0);
    zval pv; array_init(&pv); add_next_index_long(&pv, 1);
    add_assoc_zval(return_value, "supported_package_versions", &pv);
}

PHP_FUNCTION(concheron_sec_inspect_package) {
    char *path = NULL; size_t path_len = 0;
    FILE *fp = NULL;
    unsigned char h[SEC_HEADER_SIZE];
    uint16_t version;
    uint32_t flags, manifest_len, recipient_len, signature_len;
    uint64_t payload_len, expected_size, actual_size;
    zend_string *manifest = NULL;

    if (zend_parse_parameters(ZEND_NUM_ARGS(), "p", &path, &path_len) == FAILURE) return;
    fp = VCWD_FOPEN(path, "rb");
    if (!fp) { sec_error(return_value, "SEC_E_PACKAGE_OPEN", "Package could not be opened."); return; }

    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_IO", "Package size could not be read."); return; }
    long sz = ftell(fp);
    if (sz < 0) { fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_IO", "Package size could not be read."); return; }
    actual_size = (uint64_t)sz;
    rewind(fp);

    if (actual_size < SEC_HEADER_SIZE || actual_size > SEC_MAX_PACKAGE) {
        fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_SIZE", "Package size is outside the allowed range."); return;
    }
    if (fread(h, 1, SEC_HEADER_SIZE, fp) != SEC_HEADER_SIZE) {
        fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_TRUNCATED", "Package header is truncated."); return;
    }
    if (memcmp(h, SEC_MAGIC, SEC_MAGIC_LEN) != 0) {
        fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_MAGIC", "Package magic is invalid."); return;
    }

    version = sec_be16(h + 8);
    flags = sec_be32(h + 12);
    manifest_len = sec_be32(h + 16);
    recipient_len = sec_be32(h + 20);
    payload_len = sec_be64(h + 24);
    signature_len = sec_be32(h + 32);

    if (version != 1) { fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_VERSION", "Package version is not supported."); return; }
    if (manifest_len == 0 || manifest_len > SEC_MAX_MANIFEST || recipient_len > SEC_MAX_RECIPIENT || signature_len > SEC_MAX_SIGNATURE) {
        fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_LENGTH", "A package section length is invalid."); return;
    }
    if (payload_len > SEC_MAX_PACKAGE) { fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_LENGTH", "Payload length is invalid."); return; }

    expected_size = SEC_HEADER_SIZE;
    if (UINT64_MAX - expected_size < manifest_len) goto overflow;
    expected_size += manifest_len;
    if (UINT64_MAX - expected_size < recipient_len) goto overflow;
    expected_size += recipient_len;
    if (UINT64_MAX - expected_size < payload_len) goto overflow;
    expected_size += payload_len;
    if (UINT64_MAX - expected_size < signature_len) goto overflow;
    expected_size += signature_len;
    if (expected_size != actual_size) { fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_LENGTH", "Declared package lengths do not match file size."); return; }

    manifest = zend_string_alloc(manifest_len, 0);
    if (fread(ZSTR_VAL(manifest), 1, manifest_len, fp) != manifest_len) {
        zend_string_release(manifest); fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_TRUNCATED", "Manifest is truncated."); return;
    }
    ZSTR_VAL(manifest)[manifest_len] = '\0';
    fclose(fp);

    array_init(return_value);
    add_assoc_bool(return_value, "success", 1);
    add_assoc_bool(return_value, "verified", 0);
    add_assoc_string(return_value, "trust", "UNVERIFIED");
    add_assoc_long(return_value, "format_version", version);
    add_assoc_long(return_value, "flags", flags);
    add_assoc_long(return_value, "manifest_length", manifest_len);
    add_assoc_long(return_value, "recipient_length", recipient_len);
    add_assoc_long(return_value, "payload_length", (zend_long)payload_len);
    add_assoc_long(return_value, "signature_length", signature_len);
    add_assoc_str(return_value, "manifest_raw", manifest);
    return;

overflow:
    fclose(fp); sec_error(return_value, "SEC_E_PACKAGE_LENGTH", "Package length arithmetic overflowed.");
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_none, 0, 0, 0)
ZEND_END_ARG_INFO()
ZEND_BEGIN_ARG_INFO_EX(arginfo_inspect, 0, 0, 1)
    ZEND_ARG_INFO(0, packagePath)
ZEND_END_ARG_INFO()

static const zend_function_entry concheron_sec_functions[] = {
    PHP_FE(concheron_sec_version, arginfo_none)
    PHP_FE(concheron_sec_capabilities, arginfo_none)
    PHP_FE(concheron_sec_inspect_package, arginfo_inspect)
    PHP_FE_END
};

PHP_MINFO_FUNCTION(concheron_sec) {
    php_info_print_table_start();
    php_info_print_table_header(2, "Concheron SEC support", "enabled");
    php_info_print_table_row(2, "Extension version", PHP_CONCHERON_SEC_VERSION);
    php_info_print_table_row(2, "API version", "1");
    php_info_print_table_row(2, "Package inspection", "enabled (unverified metadata only)");
    php_info_print_table_end();
}

zend_module_entry concheron_sec_module_entry = {
    STANDARD_MODULE_HEADER, "concheron_sec", concheron_sec_functions,
    NULL, NULL, NULL, NULL, PHP_MINFO(concheron_sec),
    PHP_CONCHERON_SEC_VERSION, STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_CONCHERON_SEC
# ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
# endif
ZEND_GET_MODULE(concheron_sec)
#endif
