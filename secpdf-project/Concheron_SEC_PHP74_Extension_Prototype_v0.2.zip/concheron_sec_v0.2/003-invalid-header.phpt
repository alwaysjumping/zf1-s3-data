--TEST--
Reject invalid SEC package magic
--SKIPIF--
<?php if (!extension_loaded('concheron_sec')) die('skip concheron_sec not loaded'); ?>
--FILE--
<?php
$p = sys_get_temp_dir() . '/consec-bad-' . getmypid() . '.sec';
file_put_contents($p, str_repeat('X', 40));
$r = concheron_sec_inspect_package($p);
unlink($p);
echo $r['success'] ? 'success' : 'fail', "\n";
echo $r['error_code'], "\n";
?>
--EXPECT--
fail
SEC_E_PACKAGE_MAGIC
