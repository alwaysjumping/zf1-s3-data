# Concheron SEC PHP Extension Prototype v0.2

Target: **PHP 7.4**

Version 0.2 adds a bounded, fixed-header `.sec` container inspector. It intentionally performs **no cryptographic verification and no decryption**. Manifest bytes returned by `concheron_sec_inspect_package()` are explicitly marked `UNVERIFIED` and must never be used for authorization before signature verification is implemented.

## Implemented API

```php
concheron_sec_version(): array
concheron_sec_capabilities(): array
concheron_sec_inspect_package(string $packagePath): array
```

## v1 prototype header

All integers are unsigned big-endian/network byte order.

| Offset | Size | Field |
|---:|---:|---|
| 0 | 8 | Magic: `CONSEC01` |
| 8 | 2 | Container version (`1`) |
| 10 | 2 | Reserved |
| 12 | 4 | Flags |
| 16 | 4 | Manifest length |
| 20 | 4 | Recipient-block length |
| 24 | 8 | Payload length |
| 32 | 4 | Signature-block length |
| 36 | 4 | Reserved |

Header size: **40 bytes**.

Sections immediately follow the header in this order:

```text
manifest || recipient block || encrypted payload || signature block
```

This is a prototype container layout and should not be declared production-final until signature/canonicalization and test vectors are frozen.

## Parser protections

The v0.2 inspector checks:

- exact `CONSEC01` magic
- supported container version
- minimum/maximum package size
- bounded manifest/recipient/signature lengths
- payload/package limits
- integer-overflow-safe total-length calculation
- exact declared-size vs actual-file-size match
- truncated header/manifest errors

The inspector does not scan for embedded filenames and does not execute package content.

## Build on Linux with PHP 7.4 development tools

```bash
cd concheron_sec_v0.2
phpize
./configure --enable-concheron_sec
make
make test
```

Then install `modules/concheron_sec.so` into the PHP 7.4 extension directory and configure:

```ini
extension=concheron_sec.so
```

## Important security boundary

This is safe inspection, **not verification**:

```php
$r = concheron_sec_inspect_package('/path/file.sec');
```

Even when `$r['success'] === true`, the result contains:

```text
verified = false
trust = UNVERIFIED
```

Do not use `manifest_raw`, company ID, recipient ID, document ID, title, classification, or other future manifest fields for authorization until `concheron_sec_verify_package()` validates the Concheron signature.

## Next milestone: v0.3

Add:

1. strict canonical manifest parser
2. package signature block definition
3. configured Concheron trust anchor/signing certificate
4. OpenSSL signature verification
5. `concheron_sec_verify_package()`
6. malformed/signature-negative test vectors

AES-GCM decryption and USB private-key integration should follow only after signature verification is stable.
