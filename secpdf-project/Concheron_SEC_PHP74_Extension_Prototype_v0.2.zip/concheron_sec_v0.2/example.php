<?php
var_dump(concheron_sec_version());
var_dump(concheron_sec_capabilities());

if ($argc > 1) {
    $info = concheron_sec_inspect_package($argv[1]);
    var_dump($info);
    echo "WARNING: inspect_package() returns UNVERIFIED metadata only.\n";
}
