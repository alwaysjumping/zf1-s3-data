--TEST--
Concheron SEC v0.2 version and capabilities
--SKIPIF--
<?php if (!extension_loaded('concheron_sec')) die('skip concheron_sec not loaded'); ?>
--FILE--
<?php
$v = concheron_sec_version();
$c = concheron_sec_capabilities();
echo $v['extension_version'], "\n";
echo $c['package_inspect'] ? 'yes' : 'no', "\n";
echo $c['package_verify'] ? 'yes' : 'no', "\n";
?>
--EXPECT--
0.2.0
yes
no
