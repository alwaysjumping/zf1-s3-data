#ifndef PHP_CONCHERON_SEC_H
#define PHP_CONCHERON_SEC_H

extern zend_module_entry concheron_sec_module_entry;
#define phpext_concheron_sec_ptr &concheron_sec_module_entry

#define PHP_CONCHERON_SEC_VERSION "0.1.0"
#define PHP_CONCHERON_SEC_API_VERSION 1

#endif /* PHP_CONCHERON_SEC_H */
