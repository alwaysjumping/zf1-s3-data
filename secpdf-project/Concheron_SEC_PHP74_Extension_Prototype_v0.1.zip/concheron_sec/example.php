<?php
if (!extension_loaded('concheron_sec')) {
    fwrite(STDERR, "concheron_sec extension is not loaded.\n");
    exit(1);
}

print_r(concheron_sec_version());
print_r(concheron_sec_capabilities());
