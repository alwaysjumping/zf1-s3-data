#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "php.h"
#include "php_concheron_sec.h"

PHP_FUNCTION(concheron_sec_version)
{
    array_init(return_value);
    add_assoc_string(return_value, "extension_version", PHP_CONCHERON_SEC_VERSION);
    add_assoc_long(return_value, "api_version", PHP_CONCHERON_SEC_API_VERSION);

    zval package_versions;
    array_init(&package_versions);
    add_next_index_long(&package_versions, 1);
    add_assoc_zval(return_value, "package_versions", &package_versions);

    zval crypto_suites;
    array_init(&crypto_suites);
    add_next_index_string(&crypto_suites, "SEC-SUITE-1");
    add_assoc_zval(return_value, "crypto_suites", &crypto_suites);
}

PHP_FUNCTION(concheron_sec_capabilities)
{
    array_init(return_value);

    /* Prototype: crypto/USB/server-key providers are not implemented yet. */
    add_assoc_bool(return_value, "usb_provider", 0);
    add_assoc_bool(return_value, "server_key_provider", 0);
    add_assoc_bool(return_value, "package_verify", 0);
    add_assoc_bool(return_value, "package_import", 0);
    add_assoc_bool(return_value, "staff_certificate_verify", 0);

    zval package_versions;
    array_init(&package_versions);
    add_next_index_long(&package_versions, 1);
    add_assoc_zval(return_value, "supported_package_versions", &package_versions);
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_concheron_sec_none, 0, 0, 0)
ZEND_END_ARG_INFO()

static const zend_function_entry concheron_sec_functions[] = {
    PHP_FE(concheron_sec_version, arginfo_concheron_sec_none)
    PHP_FE(concheron_sec_capabilities, arginfo_concheron_sec_none)
    PHP_FE_END
};

PHP_MINFO_FUNCTION(concheron_sec)
{
    php_info_print_table_start();
    php_info_print_table_header(2, "Concheron SEC support", "enabled");
    php_info_print_table_row(2, "Extension version", PHP_CONCHERON_SEC_VERSION);
    php_info_print_table_row(2, "API version", "1");
    php_info_print_table_end();
}

zend_module_entry concheron_sec_module_entry = {
    STANDARD_MODULE_HEADER,
    "concheron_sec",
    concheron_sec_functions,
    NULL,
    NULL,
    NULL,
    NULL,
    PHP_MINFO(concheron_sec),
    PHP_CONCHERON_SEC_VERSION,
    STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_CONCHERON_SEC
# ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
# endif
ZEND_GET_MODULE(concheron_sec)
#endif
