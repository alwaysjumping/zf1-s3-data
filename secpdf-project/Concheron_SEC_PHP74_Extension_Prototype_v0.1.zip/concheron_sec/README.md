# Concheron SEC PHP Extension Prototype

Prototype version: **0.1.0**  
Target: **PHP 7.4**

This first milestone intentionally contains no real document cryptography and no USB private-key integration. It establishes the native PHP extension boundary that later SEC functions will use.

## Implemented functions

```php
concheron_sec_version(): array
concheron_sec_capabilities(): array
```

## Linux build (PHP 7.4 development environment)

```bash
cd concheron_sec
phpize
./configure --enable-concheron_sec
make
make test
```

The built module will normally be:

```text
modules/concheron_sec.so
```

For a test installation, copy/install the module into the PHP 7.4 extension directory and add:

```ini
extension=concheron_sec.so
```

Then verify:

```bash
php -m | grep concheron_sec
php --ri concheron_sec
```

Test from PHP:

```php
<?php
var_dump(concheron_sec_version());
var_dump(concheron_sec_capabilities());
```

## Windows

A Windows PHP 7.4 build must match the exact PHP architecture and build characteristics, including x86/x64, TS/NTS, and compatible compiler/runtime. The resulting module should be named `php_concheron_sec.dll`.

Do not use a DLL built for a different PHP ABI.

## Current security boundary

The prototype does **not** implement:

- `.sec` package parsing
- package signature verification
- AES-256-GCM
- USB/token middleware
- server-key provider
- staff certificate verification
- document import/decryption

The capability function intentionally reports these features as disabled.

## Next milestone

Version 0.2 should add a safe fixed-header `.sec` parser and `concheron_sec_inspect_package()` without decryption. The parser should validate magic/version/lengths and return only non-secret metadata. Cryptographic verification should be added only after the parser is covered by malformed-input tests.
