PHP_ARG_ENABLE([concheron_sec],
  [whether to enable Concheron SEC support],
  [AS_HELP_STRING([--enable-concheron_sec], [Enable Concheron SEC extension])],
  [no])

if test "$PHP_CONCHERON_SEC" != "no"; then
  PHP_NEW_EXTENSION([concheron_sec], [concheron_sec.c], [$ext_shared])
fi
