--TEST--
Concheron SEC version and capabilities
--SKIPIF--
<?php if (!extension_loaded('concheron_sec')) die('skip concheron_sec not loaded'); ?>
--FILE--
<?php
$v = concheron_sec_version();
$c = concheron_sec_capabilities();

echo $v['extension_version'], "\n";
echo $v['api_version'], "\n";
echo $v['package_versions'][0], "\n";
echo $v['crypto_suites'][0], "\n";
echo $c['package_verify'] ? 'yes' : 'no', "\n";
?>
--EXPECT--
0.1.0
1
1
SEC-SUITE-1
no
