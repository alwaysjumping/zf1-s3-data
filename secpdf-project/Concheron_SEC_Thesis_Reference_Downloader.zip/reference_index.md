# Concheron SEC Thesis — Reference Download Index

This package maps the principal thesis references to authoritative sources and provides `download_references.ps1` for downloading the freely available documents.

## Important update

The thesis originally cites **NIST SP 800-63B (2017/2020 update)**. NIST withdrew that edition on **August 1, 2025** and superseded it with **NIST SP 800-63B-4 (July 2025)**. The downloader retrieves **both** editions: the old edition for thesis traceability and the current edition for updating the final thesis.

## Freely downloadable standards and guidance

| Ref. | Document | Local filename after script |
|---|---|---|
| [1] | NIST SP 800-38D — GCM and GMAC | `NIST/NIST_SP_800-38D_GCM_GMAC.pdf` |
| [2] | RFC 5116 — Authenticated Encryption | `RFC/RFC_5116_AEAD.txt` |
| [3] | RFC 8017 — PKCS #1 / RSA | `RFC/RFC_8017_PKCS1_RSA.txt` |
| [4] | NIST SP 800-57 Part 1 Rev. 5 — Key Management | `NIST/NIST_SP_800-57_Part1_Rev5_Key_Management.pdf` |
| [5] | RFC 5280 — X.509 / CRL Profile | `RFC/RFC_5280_X509_CRL.txt` |
| [6] | NIST SP 800-63B — historical cited edition | `NIST/NIST_SP_800-63B_2020_SUPERSEDED.pdf` |
| Update | NIST SP 800-63B-4 — current replacement | `NIST/NIST_SP_800-63B-4_2025_CURRENT.pdf` |
| [7] | OWASP Authorization Cheat Sheet | `OWASP/OWASP_Authorization_Cheat_Sheet.md` |
| [8] | NIST SP 800-207 — Zero Trust Architecture | `NIST/NIST_SP_800-207_Zero_Trust.pdf` |
| [10] | OWASP File Upload Cheat Sheet | `OWASP/OWASP_File_Upload_Cheat_Sheet.md` |
| Additional | RFC 8785 — JSON Canonicalization Scheme | `RFC/RFC_8785_JSON_Canonicalization.txt` |
| Additional | NIST SP 800-90A Rev. 1 — DRBG | `NIST/NIST_SP_800-90A_Rev1_DRBG.pdf` |

## Academic references

### [9] Su, Hartung & Girod (1998)

**Digital watermarking of text, image, and video documents**  
*Computers & Graphics*, 22(6), 687–695.  
DOI: `10.1016/S0097-8493(98)00089-2`

Official publisher page:

`https://www.sciencedirect.com/science/article/pii/S0097849398000892`

This article is publisher-controlled and may require institutional/subscription access, so the downloader does not copy it automatically.

### [11] Ben Jabra & Ben Farah (2024)

**Deep Learning-Based Watermarking Techniques Challenges: A Review of Current and Future Trends**  
*Circuits, Systems, and Signal Processing*, 43, 4339–4368.  
DOI: `10.1007/s00034-024-02651-z`

Official Springer page:

`https://link.springer.com/article/10.1007/s00034-024-02651-z`

The publisher identifies this article as open access. Use the **Download PDF** control on the official article page if direct automated download is blocked.

## Official web sources

- NIST SP 800-38D: `https://csrc.nist.gov/pubs/sp/800/38/d/final`
- NIST SP 800-57 Part 1 Rev. 5: `https://csrc.nist.gov/pubs/sp/800/57/pt1/r5/final`
- NIST SP 800-63B-4: `https://csrc.nist.gov/pubs/sp/800/63/B/4/final`
- NIST SP 800-207: `https://csrc.nist.gov/pubs/sp/800/207/final`
- NIST SP 800-90A Rev. 1: `https://csrc.nist.gov/pubs/sp/800/90/a/r1/final`
- RFC Editor: `https://www.rfc-editor.org/`
- OWASP Authorization Cheat Sheet: `https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html`
- OWASP File Upload Cheat Sheet: `https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html`

## How to use on Windows

1. Extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\download_references.ps1
```

4. The downloaded files will be created under the `references` folder.

The script is intentionally simple and compatible with Windows PowerShell 5.x.
