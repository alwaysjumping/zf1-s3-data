﻿$ErrorActionPreference = "Stop"

$Root = Join-Path $PSScriptRoot "references"
$folders = @("NIST","RFC","OWASP","Academic")
foreach ($f in $folders) {
    $p = Join-Path $Root $f
    if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null }
}

# TLS 1.2 is needed on some older PowerShell/.NET installations.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$downloads = @(
    @{ Url="https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38d.pdf"; Out="NIST\NIST_SP_800-38D_GCM_GMAC.pdf" },
    @{ Url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-57pt1r5.pdf"; Out="NIST\NIST_SP_800-57_Part1_Rev5_Key_Management.pdf" },
    @{ Url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-63b.pdf"; Out="NIST\NIST_SP_800-63B_2020_SUPERSEDED.pdf" },
    @{ Url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-63b-4.pdf"; Out="NIST\NIST_SP_800-63B-4_2025_CURRENT.pdf" },
    @{ Url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-207.pdf"; Out="NIST\NIST_SP_800-207_Zero_Trust.pdf" },
    @{ Url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-90Ar1.pdf"; Out="NIST\NIST_SP_800-90A_Rev1_DRBG.pdf" },

    @{ Url="https://www.rfc-editor.org/rfc/rfc5116.txt"; Out="RFC\RFC_5116_AEAD.txt" },
    @{ Url="https://www.rfc-editor.org/rfc/rfc8017.txt"; Out="RFC\RFC_8017_PKCS1_RSA.txt" },
    @{ Url="https://www.rfc-editor.org/rfc/rfc5280.txt"; Out="RFC\RFC_5280_X509_CRL.txt" },
    @{ Url="https://www.rfc-editor.org/rfc/rfc8785.txt"; Out="RFC\RFC_8785_JSON_Canonicalization.txt" },

    @{ Url="https://raw.githubusercontent.com/OWASP/CheatSheetSeries/master/cheatsheets/Authorization_Cheat_Sheet.md"; Out="OWASP\OWASP_Authorization_Cheat_Sheet.md" },
    @{ Url="https://raw.githubusercontent.com/OWASP/CheatSheetSeries/master/cheatsheets/File_Upload_Cheat_Sheet.md"; Out="OWASP\OWASP_File_Upload_Cheat_Sheet.md" }
)

foreach ($d in $downloads) {
    $target = Join-Path $Root $d.Out
    Write-Host "Downloading $($d.Url)"
    try {
        Invoke-WebRequest -Uri $d.Url -OutFile $target -UseBasicParsing
        Write-Host "  OK -> $target" -ForegroundColor Green
    }
    catch {
        Write-Warning "FAILED: $($d.Url)"
        Write-Warning $_.Exception.Message
    }
}

Write-Host ""
Write-Host "Finished. Files are under:" -ForegroundColor Cyan
Write-Host $Root
Write-Host ""
Write-Host "Note: The 1998 Elsevier watermarking article is not automatically downloaded because publisher access may require a subscription."
Write-Host "The 2024 Springer article is open access; use the official article page listed in reference_index.md if automatic publisher download is unavailable."
