#!/usr/bin/env bash
set -Eeuo pipefail
# Offline-only ImageMagick + PHP Imagick installer for CentOS/RHEL-compatible systems.
# Requires preverified RPMs (and repodata) matching the target OS and PHP ABI.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$ROOT/repo"
DRY_RUN=0
for arg in "$@"; do case "$arg" in --dry-run) DRY_RUN=1;; *) echo "Unknown option: $arg" >&2; exit 2;; esac; done
log(){ printf '[offline-imagick] %s\n' "$*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || fail 'Run as root (sudo).'
[[ -d "$REPO/repodata" ]] || fail "Missing $REPO/repodata. Build the repository on a matching online machine."
command -v rpm >/dev/null || fail 'rpm is required.'
if command -v dnf >/dev/null; then PM=dnf; elif command -v yum >/dev/null; then PM=yum; else fail 'Neither dnf nor yum found.'; fi
log "OS: $(. /etc/os-release; echo "$PRETTY_NAME")"
log "Architecture: $(uname -m)"
command -v php >/dev/null || fail 'PHP CLI not found.'
PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
PHP_API=$(php -i | sed -n 's/^PHP API => //p' | head -n1)
log "PHP: $PHP_VER; PHP API: ${PHP_API:-unknown}"
[[ "$PHP_VER" == '7.4' ]] || fail 'This bundle targets PHP 7.4. Refusing to change a different PHP runtime.'
# All RPMs must be authenticated independently; the supplied public key must be vetted out of band.
KEY="$ROOT/trusted-rpm-key.asc"
[[ -s "$KEY" ]] || fail 'Missing trusted-rpm-key.asc. Import a VERIFIED vendor signing key; do not turn off GPG checks.'
log 'Importing preverified RPM signing key'
if (( ! DRY_RUN )); then rpm --import "$KEY"; fi
# Ensure every RPM has a valid signature against imported trusted keys.
shopt -s nullglob
rpms=("$REPO"/*.rpm)
((${#rpms[@]})) || fail 'No RPM packages in repo/'
if (( ! DRY_RUN )); then
  for rpm_file in "${rpms[@]}"; do
    result=$(rpm -Kv "$rpm_file" 2>&1) || fail "RPM verification failed: $rpm_file: $result"
    if grep -Eiq 'NOT OK|NOKEY|NOT SIGNED|BAD|MISSING' <<<"$result"; then fail "Untrusted RPM: $rpm_file: $result"; fi
  done
fi
REPO_ID=concheron-imagick-offline
REPO_FILE="/etc/yum.repos.d/${REPO_ID}.repo"
[[ -d /etc/yum.repos.d ]] || fail 'Missing /etc/yum.repos.d'
# Use a temporary repo file, remove on exit. file:// is strictly local.
cleanup(){ rm -f "$REPO_FILE"; }
trap cleanup EXIT
cat > "$REPO_FILE" <<REPOCFG
[$REPO_ID]
name=Concheron Offline Imagick
baseurl=file://$REPO
enabled=0
gpgcheck=1
repo_gpgcheck=0
metadata_expire=-1
REPOCFG
# Note: repo_gpgcheck=0 only disables metadata signing; RPM signatures remain mandatory.
ARGS=(--disablerepo='*' --enablerepo="$REPO_ID" --setopt=install_weak_deps=False)
if [[ "$PM" == yum ]]; then ARGS=(--disablerepo='*' --enablerepo="$REPO_ID"); fi
if (( DRY_RUN )); then
  log "DRY RUN: would install ImageMagick and php-pecl-imagick using $PM from $REPO only."
  log 'No package installation performed.'
  exit 0
fi
log 'Installing from local repository only (network repositories disabled).'
"$PM" "${ARGS[@]}" -y install ImageMagick php-pecl-imagick
log 'Verifying PHP CLI extension'
php -r 'if (!extension_loaded("imagick")) {fwrite(STDERR,"imagick not loaded\n");exit(1);} $v=Imagick::getVersion(); echo $v["versionString"],"\n";'
log 'Installed package versions:'
rpm -q ImageMagick php-pecl-imagick || true
log 'Check the PHP web SAPI separately; restart httpd/php-fpm in an approved maintenance window.'
