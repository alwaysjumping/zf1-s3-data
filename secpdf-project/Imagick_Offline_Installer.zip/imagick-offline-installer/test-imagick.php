<?php
// PHP 7.4 smoke test. Run: php test-imagick.php
if (!extension_loaded('imagick')) {
    fwrite(STDERR, "Imagick is not loaded.\n");
    exit(1);
}
$image = new Imagick();
try {
    $image->newImage(640, 320, new ImagickPixel('white'), 'png');
    $draw = new ImagickDraw();
    $draw->setFillColor(new ImagickPixel('#555555'));
    $draw->setFontSize(28);
    $draw->annotation(50, 160, 'Concheron Imagick Test');
    $image->drawImage($draw);
    $target = __DIR__ . '/imagick-test.png';
    if (!$image->writeImage($target)) {
        throw new RuntimeException('Image write failed');
    }
    echo "Created: {$target}\n";
} finally {
    $image->clear();
}
