# Concheron Imagick Offline Installer (PHP 7.4)

## Scope
This reusable bundle installs **ImageMagick** and a repository-provided **php-pecl-imagick** RPM entirely from a local `file://` repository. It does **not** download anything on the offline server and does **not** build Imagick from source. Use it only where compatible RPMs exist for the target's CentOS/RHEL release, architecture, PHP 7.4 build, and ImageMagick ABI.

**Important:** CentOS 7 and CentOS Linux 8 are end-of-life. Do not use unmaintained libraries on a confidential document server. The scripts have not been executed against your particular CentOS server.

## 1. Determine target configuration

```bash
cat /etc/os-release
uname -m
php -v
php --ini
php -i | grep -E '^(PHP API|Thread Safety|extension_dir)'
rpm -qa | grep -Ei '^(php|ImageMagick|imagick)'
```

Record the package source/repository of the installed PHP 7.4 runtime. A generic `php-pecl-imagick` package may target another PHP ABI. Confirm that the package requires the correct PHP API (PHP 7.4 usually `20190902`) and ImageMagick libraries. Use a matching, clean build/download VM.

## 2. Prepare online (matching Linux machine)

Install `dnf-plugins-core` and `createrepo_c` (or `yum-utils` and `createrepo` for older systems). Enable only compatible repositories, including the repository providing the target PHP 7.4 packages. Run:

```bash
bash prepare-online.sh
```

This produces `repo/*.rpm`, `repo/repodata/`, and `SHA256SUMS`. If the target needs packages that the downloader considers already installed, the DNF `--alldeps` flag helps include them; verify the result on a clean matching VM. If the requested RPM isn't available, **stop** and use a source-build/package workflow rather than mixing incompatible repositories.

### Verify trust before transfer

Obtain the official RPM signing key from the actual package vendor via an authenticated channel; verify its fingerprint against a trusted source. Place it as `trusted-rpm-key.asc` in the bundle root. The installer imports that key and verifies RPM signatures. A SHA-256 manifest detects transfer corruption but does not establish provenance by itself. This sample does not verify signed repository metadata; secure and audit the bundle distribution process.

## 3. Transfer and install offline

Transfer the entire directory using an approved medium. Verify the `SHA256SUMS` file against a separately authenticated expected hash, then:

```bash
cd imagick-offline-installer
sudo bash install.sh --dry-run
sudo bash install.sh
php --ri imagick
php test-imagick.php
```

The script disables all configured online repositories for installation and creates a temporary local repo definition. It does not restart production services. Plan a maintenance window to restart the actual PHP handler (`httpd`, `php-fpm`, or a version-specific service) and test the web SAPI separately.

## 4. Troubleshooting

- **Package not found:** The compatible PHP 7.4 repository may not provide `php-pecl-imagick`; source-build the extension on a matching VM and package it as a signed RPM.
- **Missing dependency:** Add matching RPMs to `repo/`, regenerate `repodata`, then transfer the complete bundle again. Do not use `rpm --nodeps`.
- **Wrong PHP ABI:** Inspect `rpm -qp --requires repo/php-pecl-imagick*.rpm` and compare with `php -i` and the installed PHP packages.
- **`imagick.so` cannot load:** Inspect `php --ri imagick`, `php --ini`, and `ldd /path/to/imagick.so`. Do not mix ImageMagick 6 and 7 shared libraries.
- **CLI works, Apache doesn't:** The web server may use a different PHP binary or configuration.
- **PDF decoding denied:** Expected in a hardened ImageMagick configuration. Use Poppler to render PDF pages and Imagick only for PNG overlays; don't weaken `policy.xml` globally.

## 5. Production caveats

This is an **RPM installation workflow**, not a hermetic software appliance. Local package manager operations can run RPM scriptlets; use only verified, trusted RPMs. For high-assurance air-gapped environments, inspect scriptlets (`rpm -qp --scripts`), test the entire bundle in a disposable matching VM, and monitor for unexpected network access. Configure ImageMagick `policy.xml` resource limits and restrict coders/delegates for the SEC use case.
