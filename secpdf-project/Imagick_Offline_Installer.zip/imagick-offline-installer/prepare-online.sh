#!/usr/bin/env bash
set -Eeuo pipefail
# Run on an internet-connected system matching the offline target's OS, architecture,
# repositories and PHP 7.4 packaging. Does not export/import trusted keys.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$ROOT/repo"
if command -v dnf >/dev/null; then
  command -v createrepo_c >/dev/null || { echo 'Install createrepo_c first' >&2; exit 1; }
  dnf download --resolve --alldeps --destdir="$ROOT/repo" ImageMagick php-pecl-imagick
  createrepo_c "$ROOT/repo"
elif command -v repotrack >/dev/null && command -v createrepo >/dev/null; then
  repotrack -p "$ROOT/repo" ImageMagick php-pecl-imagick
  createrepo "$ROOT/repo"
else
  echo 'Requires dnf download + createrepo_c, or repotrack + createrepo' >&2
  exit 1
fi
(cd "$ROOT" && find repo -type f -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS)
echo 'Package download complete. Verify PHP ABI and package signatures; supply trusted-rpm-key.asc out of band.'
