#ifndef PHP_CONCHERON_SEC_H
#define PHP_CONCHERON_SEC_H

extern zend_module_entry concheron_sec_module_entry;
#define phpext_concheron_sec_ptr &concheron_sec_module_entry

#define PHP_CONCHERON_SEC_VERSION "0.3.0"
#define CONCHERON_SEC_API_VERSION 1

PHP_FUNCTION(concheron_sec_version);
PHP_FUNCTION(concheron_sec_capabilities);
PHP_FUNCTION(concheron_sec_inspect_package);
PHP_FUNCTION(concheron_sec_verify_package);

#endif
