#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "ext/standard/info.h"
#include "php_concheron_sec.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>

#define SEC_MAGIC "CONSEC01"
#define SEC_MAGIC_LEN 8
#define SEC_HEADER_SIZE 40
#define SEC_CONTAINER_VERSION 1

#define SEC_MAX_MANIFEST (1024U * 1024U)
#define SEC_MAX_RECIPIENT (1024U * 1024U)
#define SEC_MAX_SIGNATURE (1024U * 1024U)
#define SEC_MAX_PACKAGE ((uint64_t)1024U * 1024U * 1024U * 4U)

#define SEC_SIG_MAGIC "CSIG"
#define SEC_SIG_MAGIC_LEN 4
#define SEC_SIG_VERSION 1
#define SEC_SIG_ALG_RSA_PSS_SHA256 1
#define SEC_SIG_HEADER_SIZE 16

static uint16_t sec_read_u16_be(const unsigned char *p)
{
    return (uint16_t)(((uint16_t)p[0] << 8) | (uint16_t)p[1]);
}

static uint32_t sec_read_u32_be(const unsigned char *p)
{
    return ((uint32_t)p[0] << 24) |
           ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) |
           (uint32_t)p[3];
}

static uint64_t sec_read_u64_be(const unsigned char *p)
{
    uint64_t v = 0;
    int i;
    for (i = 0; i < 8; i++) {
        v = (v << 8) | p[i];
    }
    return v;
}

typedef struct _sec_header {
    uint16_t version;
    uint32_t flags;
    uint32_t manifest_length;
    uint32_t recipient_length;
    uint64_t payload_length;
    uint32_t signature_length;
} sec_header;

static int sec_parse_header(const unsigned char *buf, size_t len, sec_header *h)
{
    uint64_t expected;

    if (len < SEC_HEADER_SIZE) return 0;
    if (memcmp(buf, SEC_MAGIC, SEC_MAGIC_LEN) != 0) return 0;

    h->version = sec_read_u16_be(buf + 8);
    h->flags = sec_read_u32_be(buf + 12);
    h->manifest_length = sec_read_u32_be(buf + 16);
    h->recipient_length = sec_read_u32_be(buf + 20);
    h->payload_length = sec_read_u64_be(buf + 24);
    h->signature_length = sec_read_u32_be(buf + 32);

    if (h->version != SEC_CONTAINER_VERSION) return 0;
    if (h->manifest_length == 0 || h->manifest_length > SEC_MAX_MANIFEST) return 0;
    if (h->recipient_length > SEC_MAX_RECIPIENT) return 0;
    if (h->signature_length == 0 || h->signature_length > SEC_MAX_SIGNATURE) return 0;
    if (h->payload_length > SEC_MAX_PACKAGE) return 0;

    expected = SEC_HEADER_SIZE;
    if (UINT64_MAX - expected < h->manifest_length) return 0;
    expected += h->manifest_length;
    if (UINT64_MAX - expected < h->recipient_length) return 0;
    expected += h->recipient_length;
    if (UINT64_MAX - expected < h->payload_length) return 0;
    expected += h->payload_length;
    if (UINT64_MAX - expected < h->signature_length) return 0;
    expected += h->signature_length;

    if (expected != (uint64_t)len) return 0;
    return 1;
}

static int sec_load_file(const char *path, unsigned char **out, size_t *out_len)
{
    FILE *fp;
    long fsize;
    unsigned char *buf;

    fp = fopen(path, "rb");
    if (!fp) return 0;

    if (fseek(fp, 0, SEEK_END) != 0) { fclose(fp); return 0; }
    fsize = ftell(fp);
    if (fsize < 0 || (uint64_t)fsize > SEC_MAX_PACKAGE) {
        fclose(fp);
        return 0;
    }
    rewind(fp);

    buf = emalloc((size_t)fsize);
    if (!buf) { fclose(fp); return 0; }

    if ((size_t)fsize != fread(buf, 1, (size_t)fsize, fp)) {
        efree(buf);
        fclose(fp);
        return 0;
    }

    fclose(fp);
    *out = buf;
    *out_len = (size_t)fsize;
    return 1;
}

static int sec_verify_rsa_pss_sha256(
    const unsigned char *data, size_t data_len,
    const unsigned char *sig, size_t sig_len,
    const char *public_key_path)
{
    FILE *fp = NULL;
    EVP_PKEY *pkey = NULL;
    EVP_MD_CTX *ctx = NULL;
    EVP_PKEY_CTX *pctx = NULL;
    int ok = 0;

    fp = fopen(public_key_path, "rb");
    if (!fp) goto done;

    pkey = PEM_read_PUBKEY(fp, NULL, NULL, NULL);
    fclose(fp);
    fp = NULL;
    if (!pkey) goto done;

    ctx = EVP_MD_CTX_new();
    if (!ctx) goto done;

    if (EVP_DigestVerifyInit(ctx, &pctx, EVP_sha256(), NULL, pkey) <= 0) goto done;
    if (EVP_PKEY_base_id(pkey) != EVP_PKEY_RSA) goto done;

    if (EVP_PKEY_CTX_set_rsa_padding(pctx, RSA_PKCS1_PSS_PADDING) <= 0) goto done;
    if (EVP_PKEY_CTX_set_rsa_pss_saltlen(pctx, -1) <= 0) goto done;

    if (EVP_DigestVerifyUpdate(ctx, data, data_len) <= 0) goto done;
    if (EVP_DigestVerifyFinal(ctx, sig, sig_len) == 1) ok = 1;

done:
    if (fp) fclose(fp);
    if (ctx) EVP_MD_CTX_free(ctx);
    if (pkey) EVP_PKEY_free(pkey);
    ERR_clear_error();
    return ok;
}

PHP_FUNCTION(concheron_sec_version)
{
    array_init(return_value);
    add_assoc_string(return_value, "extension_version", PHP_CONCHERON_SEC_VERSION);
    add_assoc_long(return_value, "api_version", CONCHERON_SEC_API_VERSION);

    zval versions;
    array_init(&versions);
    add_next_index_long(&versions, SEC_CONTAINER_VERSION);
    add_assoc_zval(return_value, "package_versions", &versions);

    zval suites;
    array_init(&suites);
    add_next_index_string(&suites, "SEC-SUITE-1");
    add_assoc_zval(return_value, "crypto_suites", &suites);
}

PHP_FUNCTION(concheron_sec_capabilities)
{
    array_init(return_value);
    add_assoc_bool(return_value, "package_inspect", 1);
    add_assoc_bool(return_value, "package_signature_verify", 1);
    add_assoc_bool(return_value, "package_import", 0);
    add_assoc_bool(return_value, "usb_provider", 0);
    add_assoc_bool(return_value, "server_key_provider", 0);
    add_assoc_bool(return_value, "staff_certificate_verify", 0);
}

PHP_FUNCTION(concheron_sec_inspect_package)
{
    char *path;
    size_t path_len;
    unsigned char *buf = NULL;
    size_t len = 0;
    sec_header h;

    if (zend_parse_parameters(ZEND_NUM_ARGS(), "p", &path, &path_len) == FAILURE) {
        RETURN_FALSE;
    }

    if (!sec_load_file(path, &buf, &len)) {
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_READ");
        return;
    }

    if (!sec_parse_header(buf, len, &h)) {
        efree(buf);
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_FORMAT");
        return;
    }

    array_init(return_value);
    add_assoc_bool(return_value, "success", 1);
    add_assoc_bool(return_value, "verified", 0);
    add_assoc_string(return_value, "trust", "UNVERIFIED");
    add_assoc_long(return_value, "format_version", h.version);
    add_assoc_long(return_value, "flags", h.flags);
    add_assoc_long(return_value, "manifest_length", h.manifest_length);
    add_assoc_long(return_value, "recipient_length", h.recipient_length);
    add_assoc_long(return_value, "payload_length", (zend_long)h.payload_length);
    add_assoc_long(return_value, "signature_length", h.signature_length);
    add_assoc_stringl(return_value, "manifest",
        (char *)(buf + SEC_HEADER_SIZE), h.manifest_length);

    efree(buf);
}

PHP_FUNCTION(concheron_sec_verify_package)
{
    char *path, *pubkey_path;
    size_t path_len, pubkey_len;
    unsigned char *buf = NULL;
    size_t len = 0;
    sec_header h;
    uint64_t signed_len64;
    size_t signed_len, sig_offset;
    const unsigned char *sig_block, *sig;
    uint16_t sig_version, sig_alg;
    uint32_t sig_len;

    if (zend_parse_parameters(
            ZEND_NUM_ARGS(), "pp",
            &path, &path_len,
            &pubkey_path, &pubkey_len) == FAILURE) {
        RETURN_FALSE;
    }

    if (!sec_load_file(path, &buf, &len)) {
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_READ");
        return;
    }

    if (!sec_parse_header(buf, len, &h)) {
        efree(buf);
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_FORMAT");
        return;
    }

    signed_len64 = (uint64_t)SEC_HEADER_SIZE +
        h.manifest_length + h.recipient_length + h.payload_length;

    if (signed_len64 > SIZE_MAX) {
        efree(buf);
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_FORMAT");
        return;
    }

    signed_len = (size_t)signed_len64;
    sig_offset = signed_len;
    sig_block = buf + sig_offset;

    if (h.signature_length < SEC_SIG_HEADER_SIZE ||
        memcmp(sig_block, SEC_SIG_MAGIC, SEC_SIG_MAGIC_LEN) != 0) {
        efree(buf);
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_SIGNATURE_FORMAT");
        return;
    }

    sig_version = sec_read_u16_be(sig_block + 4);
    sig_alg = sec_read_u16_be(sig_block + 6);
    sig_len = sec_read_u32_be(sig_block + 8);

    if (sig_version != SEC_SIG_VERSION ||
        sig_alg != SEC_SIG_ALG_RSA_PSS_SHA256 ||
        (uint64_t)SEC_SIG_HEADER_SIZE + sig_len != h.signature_length) {
        efree(buf);
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_SIGNATURE_FORMAT");
        return;
    }

    sig = sig_block + SEC_SIG_HEADER_SIZE;

    if (!sec_verify_rsa_pss_sha256(
            buf, signed_len, sig, sig_len, pubkey_path)) {
        efree(buf);
        array_init(return_value);
        add_assoc_bool(return_value, "success", 0);
        add_assoc_bool(return_value, "verified", 0);
        add_assoc_string(return_value, "error_code", "SEC_E_PACKAGE_SIGNATURE");
        return;
    }

    array_init(return_value);
    add_assoc_bool(return_value, "success", 1);
    add_assoc_bool(return_value, "verified", 1);
    add_assoc_string(return_value, "trust", "SIGNATURE_VERIFIED");
    add_assoc_long(return_value, "format_version", h.version);
    add_assoc_stringl(return_value, "manifest",
        (char *)(buf + SEC_HEADER_SIZE), h.manifest_length);

    efree(buf);
}

ZEND_BEGIN_ARG_INFO_EX(arginfo_none, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_path, 0, 0, 1)
    ZEND_ARG_INFO(0, packagePath)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_verify, 0, 0, 2)
    ZEND_ARG_INFO(0, packagePath)
    ZEND_ARG_INFO(0, trustedPublicKeyPath)
ZEND_END_ARG_INFO()

static const zend_function_entry concheron_sec_functions[] = {
    PHP_FE(concheron_sec_version, arginfo_none)
    PHP_FE(concheron_sec_capabilities, arginfo_none)
    PHP_FE(concheron_sec_inspect_package, arginfo_path)
    PHP_FE(concheron_sec_verify_package, arginfo_verify)
    PHP_FE_END
};

PHP_MINFO_FUNCTION(concheron_sec)
{
    php_info_print_table_start();
    php_info_print_table_header(2, "Concheron SEC support", "enabled");
    php_info_print_table_row(2, "Version", PHP_CONCHERON_SEC_VERSION);
    php_info_print_table_row(2, "Package signature verification", "RSA-PSS/SHA-256");
    php_info_print_table_end();
}

zend_module_entry concheron_sec_module_entry = {
    STANDARD_MODULE_HEADER,
    "concheron_sec",
    concheron_sec_functions,
    NULL, NULL, NULL, NULL,
    PHP_MINFO(concheron_sec),
    PHP_CONCHERON_SEC_VERSION,
    STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_CONCHERON_SEC
# ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
# endif
ZEND_GET_MODULE(concheron_sec)
#endif
