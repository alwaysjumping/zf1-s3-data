# Concheron SEC PHP 7.4 Extension Prototype v0.3

This prototype adds the first cryptographic trust boundary to the previous safe package parser.

## Implemented

- `concheron_sec_version()`
- `concheron_sec_capabilities()`
- `concheron_sec_inspect_package()`
- `concheron_sec_verify_package()`
- `CONSEC01` fixed-header validation
- Strict package length limits
- Signature-block parsing
- OpenSSL EVP signature verification
- RSA-PSS with SHA-256 for the prototype package-signing profile
- Explicit `UNVERIFIED` inspection state
- Explicit `SIGNATURE_VERIFIED` state after verification

## Deliberately not implemented yet

- USB private-key access
- CEK unwrap
- AES-256-GCM PDF decryption
- Server-key re-encryption
- Staff certificate authentication
- Rendering

## Important trust rule

`concheron_sec_inspect_package()` only parses structural metadata. Its manifest output is **untrusted**.

Only after `concheron_sec_verify_package()` returns:

```php
[
    'success' => true,
    'verified' => true,
    'trust' => 'SIGNATURE_VERIFIED'
]
```

may the application treat the signed package bytes as authentic.

Application authorization is still separate.

## Prototype signature block

The package's `signature_length` section uses:

```text
Offset  Size  Field
0       4     "CSIG"
4       2     signature block version = 1
6       2     algorithm = 1 (RSA-PSS/SHA-256)
8       4     signature byte length
12      4     reserved
16      N     signature bytes
```

The signature covers all package bytes before the signature block:

```text
fixed header || manifest || recipient block || encrypted payload
```

This makes modifications to those bytes invalidate the signature.

## Build on Linux

Install the PHP 7.4 development headers and OpenSSL development package for your distribution, then:

```bash
phpize
./configure --enable-concheron-sec
make
make test
sudo make install
```

Enable:

```ini
extension=concheron_sec.so
```

Check:

```bash
php -m | grep concheron
php --ri concheron_sec
```

## PHP example

```php
$inspection = concheron_sec_inspect_package('/secure/incoming/document.sec');

if (!$inspection['success']) {
    throw new RuntimeException('Invalid SEC package.');
}

/* Never authorize from $inspection['manifest']. */

$verified = concheron_sec_verify_package(
    '/secure/incoming/document.sec',
    '/etc/concheron/trust/sec-package-signing-public.pem'
);

if (!$verified['success'] || !$verified['verified']) {
    throw new RuntimeException('SEC package signature verification failed.');
}

/* Now parse the verified canonical manifest and apply company/recipient policy. */
```

## Production hardening still required

This is a prototype, not a finished production security component.

Before production:

- Replace caller-selected public-key paths with a configured Concheron trust store/key ID.
- Parse a canonical manifest representation rather than returning raw manifest text.
- Validate signing certificate chain, policy, validity, and revocation as required.
- Add operation/correlation IDs.
- Add structured internal diagnostics without leaking OpenSSL details.
- Stream large payload verification rather than loading multi-GB packages fully into memory.
- Add fuzzing and malformed-package regression corpus.
- Review all native code for memory-safety and integer-boundary issues.
- Define the final signing algorithm/profile through Concheron PKI policy.

## Next milestone: v0.4

v0.4 should add:

1. Strict canonical manifest parser.
2. Required-field validation.
3. `target_company_id` validation.
4. `recipient_usb_certificate_id` validation.
5. Package expiry/minimum-extension checks.
6. Trusted signing-key configuration instead of an arbitrary PHP path.
7. Test package generator for interoperability tests.

After those checks are stable, the next cryptographic milestone is USB recipient-key integration and AES-256-GCM payload authentication/decryption.
