--TEST--
Concheron SEC v0.3 capabilities
--SKIPIF--
<?php if (!extension_loaded("concheron_sec")) die("skip"); ?>
--FILE--
<?php
$c = concheron_sec_capabilities();
var_dump($c["package_inspect"]);
var_dump($c["package_signature_verify"]);
var_dump($c["package_import"]);
?>
--EXPECT--
bool(true)
bool(true)
bool(false)
