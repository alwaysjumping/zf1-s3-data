--TEST--
Concheron SEC version
--SKIPIF--
<?php if (!extension_loaded("concheron_sec")) die("skip"); ?>
--FILE--
<?php
$v = concheron_sec_version();
echo $v["extension_version"], "\n";
echo $v["api_version"], "\n";
?>
--EXPECT--
0.3.0
1
