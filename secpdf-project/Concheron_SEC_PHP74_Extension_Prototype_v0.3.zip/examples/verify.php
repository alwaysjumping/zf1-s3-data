<?php

$package = $argv[1] ?? null;
$publicKey = $argv[2] ?? null;

if (!$package || !$publicKey) {
    fwrite(STDERR, "Usage: php verify.php package.sec trusted-public-key.pem\n");
    exit(1);
}

print_r(concheron_sec_inspect_package($package));
print_r(concheron_sec_verify_package($package, $publicKey));
