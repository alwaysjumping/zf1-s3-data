#ifndef PHP_CONCHERON_SEC_H
#define PHP_CONCHERON_SEC_H

extern zend_module_entry concheron_sec_module_entry;
#define phpext_concheron_sec_ptr &concheron_sec_module_entry

#define PHP_CONCHERON_SEC_VERSION "0.4.0"
#define CONCHERON_SEC_API_VERSION 1

ZEND_BEGIN_MODULE_GLOBALS(concheron_sec)
    char *company_id;
    char *trusted_signing_key;
    zend_long max_package_size;
ZEND_END_MODULE_GLOBALS(concheron_sec)

ZEND_EXTERN_MODULE_GLOBALS(concheron_sec)
#define SEC_G(v) ZEND_MODULE_GLOBALS_ACCESSOR(concheron_sec, v)

PHP_FUNCTION(concheron_sec_version);
PHP_FUNCTION(concheron_sec_capabilities);
PHP_FUNCTION(concheron_sec_inspect_package);
PHP_FUNCTION(concheron_sec_verify_package);

#endif
