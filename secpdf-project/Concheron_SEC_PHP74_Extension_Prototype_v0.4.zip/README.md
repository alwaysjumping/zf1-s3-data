# Concheron SEC PHP 7.4 Extension Prototype v0.4

v0.4 moves package policy decisions behind the signature-verification boundary.

## New in v0.4

- `concheron_sec_verify_package()` no longer accepts a public-key path from PHP.
- Trusted package-signing public key is configured with `PHP_INI_SYSTEM`.
- Local subsidiary/company ID is configured with `PHP_INI_SYSTEM`.
- Signed manifest JSON is parsed only after package signature verification.
- Required manifest fields are validated.
- `target_company_id` must equal the configured subsidiary.
- `crypto_suite` must be supported.
- Payload type must be `application/pdf`.
- Optional package expiration is checked.
- Optional `minimum_extension_version` is checked.
- Successful state is `SIGNATURE_AND_POLICY_VERIFIED`.

## Configuration

Example `php.ini`:

```ini
extension=concheron_sec.so

concheron_sec.company_id=COMPANY-A
concheron_sec.trusted_signing_key=/etc/concheron/trust/sec-package-signing-public.pem
concheron_sec.max_package_size=1073741824
```

Because these settings are `PHP_INI_SYSTEM`, normal application code should not be able to replace the trusted signing key using `ini_set()`.

The signing-key file itself must have restrictive OS permissions.

## API

```php
concheron_sec_version();
concheron_sec_capabilities();
concheron_sec_inspect_package($packagePath);
concheron_sec_verify_package($packagePath);
```

Example:

```php
$result = concheron_sec_verify_package('/secure/incoming/example.sec');

if (!$result['success']) {
    throw new RuntimeException($result['error_code']);
}

if ($result['trust'] !== 'SIGNATURE_AND_POLICY_VERIFIED') {
    throw new RuntimeException('SEC package is not trusted.');
}

echo $result['document_id'];
echo $result['recipient_usb_certificate_id'];
```

## Trust sequence

```text
Read package
   |
Validate binary structure
   |
Verify Concheron signature using configured trusted key
   |
Parse signed manifest
   |
Validate required fields
   |
Validate configured target company
   |
Validate crypto suite / PDF payload
   |
Check expiry / minimum extension version
   |
SIGNATURE_AND_POLICY_VERIFIED
```

## Important limitation

This is still a prototype. In particular:

- The manifest uses JSON but does not yet implement a full formal canonical-JSON specification.
- Package signature trust uses a configured public key rather than a full X.509 chain/revocation policy.
- `recipient_usb_certificate_id` is structurally required but is not yet matched to a physically present USB token.
- Payload encryption/decryption is not implemented.
- The prototype currently reads the package into memory; production code should stream large payloads.
- Date parsing should receive a stricter production implementation with complete calendar validation.
- A production implementation needs fuzzing and independent native-code/security review.

## Build

Linux example:

```bash
phpize
./configure --enable-concheron-sec
make
make test
sudo make install
```

Enable/configure in `php.ini`, then:

```bash
php --ri concheron_sec
```

## v0.5 recommendation

The next version should add a test package generator and recipient block specification, then implement:

1. Physical SEC USB/token discovery.
2. Match signed `recipient_usb_certificate_id` to the present token.
3. Private-key proof/operation through token middleware.
4. CEK unwrap.
5. AES-256-GCM authentication/decryption.
6. Controlled plaintext handling.

Do not implement direct private-key export to PHP.
