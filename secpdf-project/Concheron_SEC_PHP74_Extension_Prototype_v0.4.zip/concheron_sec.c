#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "ext/standard/info.h"
#include "ext/json/php_json.h"
#include "php_concheron_sec.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/err.h>

#define SEC_MAGIC "CONSEC01"
#define SEC_MAGIC_LEN 8
#define SEC_HEADER_SIZE 40
#define SEC_CONTAINER_VERSION 1

#define SEC_DEFAULT_MAX_PACKAGE ((zend_long)1073741824)
#define SEC_MAX_MANIFEST (1024U * 1024U)
#define SEC_MAX_RECIPIENT (1024U * 1024U)
#define SEC_MAX_SIGNATURE (1024U * 1024U)

#define SEC_SIG_MAGIC "CSIG"
#define SEC_SIG_MAGIC_LEN 4
#define SEC_SIG_VERSION 1
#define SEC_SIG_ALG_RSA_PSS_SHA256 1
#define SEC_SIG_HEADER_SIZE 16

ZEND_DECLARE_MODULE_GLOBALS(concheron_sec)

static PHP_INI_MH(OnUpdateMaxPackage)
{
    zend_long v = zend_atol(new_value->val, new_value->len);
    if (v <= 0) return FAILURE;
    SEC_G(max_package_size) = v;
    return SUCCESS;
}

PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("concheron_sec.company_id", "", PHP_INI_SYSTEM,
        OnUpdateString, company_id, zend_concheron_sec_globals, concheron_sec_globals)
    STD_PHP_INI_ENTRY("concheron_sec.trusted_signing_key", "", PHP_INI_SYSTEM,
        OnUpdateString, trusted_signing_key, zend_concheron_sec_globals, concheron_sec_globals)
    PHP_INI_ENTRY("concheron_sec.max_package_size", "1073741824",
        PHP_INI_SYSTEM, OnUpdateMaxPackage)
PHP_INI_END()

static void php_concheron_sec_init_globals(zend_concheron_sec_globals *g)
{
    g->company_id = NULL;
    g->trusted_signing_key = NULL;
    g->max_package_size = SEC_DEFAULT_MAX_PACKAGE;
}

static uint16_t sec_u16(const unsigned char *p) {
    return (uint16_t)(((uint16_t)p[0] << 8) | p[1]);
}
static uint32_t sec_u32(const unsigned char *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | p[3];
}
static uint64_t sec_u64(const unsigned char *p) {
    uint64_t v=0; int i; for(i=0;i<8;i++) v=(v<<8)|p[i]; return v;
}

typedef struct {
    uint16_t version;
    uint32_t flags, manifest_length, recipient_length, signature_length;
    uint64_t payload_length;
} sec_header;

static int sec_parse_header(const unsigned char *b,size_t n,sec_header *h)
{
    uint64_t expected;
    if(n<SEC_HEADER_SIZE || memcmp(b,SEC_MAGIC,8)!=0) return 0;
    h->version=sec_u16(b+8);
    h->flags=sec_u32(b+12);
    h->manifest_length=sec_u32(b+16);
    h->recipient_length=sec_u32(b+20);
    h->payload_length=sec_u64(b+24);
    h->signature_length=sec_u32(b+32);
    if(h->version!=1 || !h->manifest_length || h->manifest_length>SEC_MAX_MANIFEST ||
       h->recipient_length>SEC_MAX_RECIPIENT ||
       !h->signature_length || h->signature_length>SEC_MAX_SIGNATURE) return 0;
    expected=SEC_HEADER_SIZE;
#define ADDLEN(x) do { if(UINT64_MAX-expected<(x)) return 0; expected+=(x); } while(0)
    ADDLEN(h->manifest_length); ADDLEN(h->recipient_length);
    ADDLEN(h->payload_length); ADDLEN(h->signature_length);
#undef ADDLEN
    return expected==(uint64_t)n;
}

static int sec_load(const char *path,unsigned char **out,size_t *n)
{
    FILE *f; long s; unsigned char *b;
    f=fopen(path,"rb"); if(!f) return 0;
    if(fseek(f,0,SEEK_END)!=0){fclose(f);return 0;}
    s=ftell(f);
    if(s<0 || (uint64_t)s>(uint64_t)SEC_G(max_package_size)){fclose(f);return 0;}
    rewind(f);
    b=emalloc((size_t)s);
    if(!b){fclose(f);return 0;}
    if(fread(b,1,(size_t)s,f)!=(size_t)s){efree(b);fclose(f);return 0;}
    fclose(f); *out=b; *n=(size_t)s; return 1;
}

static int sec_verify_sig(const unsigned char *data,size_t data_n,
    const unsigned char *sig,size_t sig_n,const char *keypath)
{
    FILE *f=NULL; EVP_PKEY *k=NULL; EVP_MD_CTX *m=NULL; EVP_PKEY_CTX *pc=NULL; int ok=0;
    f=fopen(keypath,"rb"); if(!f) goto done;
    k=PEM_read_PUBKEY(f,NULL,NULL,NULL); fclose(f); f=NULL;
    if(!k || EVP_PKEY_base_id(k)!=EVP_PKEY_RSA) goto done;
    m=EVP_MD_CTX_new(); if(!m) goto done;
    if(EVP_DigestVerifyInit(m,&pc,EVP_sha256(),NULL,k)<=0) goto done;
    if(EVP_PKEY_CTX_set_rsa_padding(pc,RSA_PKCS1_PSS_PADDING)<=0) goto done;
    if(EVP_PKEY_CTX_set_rsa_pss_saltlen(pc,-1)<=0) goto done;
    if(EVP_DigestVerifyUpdate(m,data,data_n)<=0) goto done;
    ok=(EVP_DigestVerifyFinal(m,sig,sig_n)==1);
done:
    if(f) fclose(f); if(m) EVP_MD_CTX_free(m); if(k) EVP_PKEY_free(k);
    ERR_clear_error(); return ok;
}

static zval *sec_req(zval *a,const char *key,int type)
{
    zval *v=zend_hash_str_find(Z_ARRVAL_P(a),key,strlen(key));
    if(!v || Z_TYPE_P(v)!=type) return NULL;
    return v;
}

static int sec_parse_iso8601_utc(const char *s, time_t *out)
{
    int Y,M,D,h,m,sec; char z;
    struct tm tmv;
    if(sscanf(s,"%4d-%2d-%2dT%2d:%2d:%2d%c",&Y,&M,&D,&h,&m,&sec,&z)!=7 || z!='Z')
        return 0;
    memset(&tmv,0,sizeof(tmv));
    tmv.tm_year=Y-1900; tmv.tm_mon=M-1; tmv.tm_mday=D;
    tmv.tm_hour=h; tmv.tm_min=m; tmv.tm_sec=sec;
#ifdef PHP_WIN32
    *out=_mkgmtime(&tmv);
#else
    *out=timegm(&tmv);
#endif
    return *out!=(time_t)-1;
}

static int sec_manifest_validate(zval *manifest, zval *ret)
{
    zval *format,*fv,*pid,*did,*dv,*cls,*pub,*company,*recipient,*created,*suite,*ptype,*minext,*expires;
    if(Z_TYPE_P(manifest)!=IS_ARRAY) goto bad;
#define RSTR(k,var) do{ var=sec_req(manifest,k,IS_STRING); if(!var) goto bad; }while(0)
    RSTR("format",format); RSTR("package_id",pid); RSTR("document_id",did);
    RSTR("document_version",dv); RSTR("classification",cls); RSTR("publisher",pub);
    RSTR("target_company_id",company); RSTR("recipient_usb_certificate_id",recipient);
    RSTR("created_at",created); RSTR("crypto_suite",suite); RSTR("payload_type",ptype);
#undef RSTR
    fv=sec_req(manifest,"format_version",IS_LONG); if(!fv) goto bad;

    if(strcmp(Z_STRVAL_P(format),"CONCHERON-SEC")!=0 || Z_LVAL_P(fv)!=1) goto bad;
    if(strcmp(Z_STRVAL_P(suite),"SEC-SUITE-1")!=0) {
        add_assoc_string(ret,"error_code","SEC_E_UNSUPPORTED_SUITE"); return 0;
    }
    if(strcmp(Z_STRVAL_P(ptype),"application/pdf")!=0) {
        add_assoc_string(ret,"error_code","SEC_E_PACKAGE_PAYLOAD_TYPE"); return 0;
    }
    if(!SEC_G(company_id) || !*SEC_G(company_id) ||
       strcmp(Z_STRVAL_P(company),SEC_G(company_id))!=0) {
        add_assoc_string(ret,"error_code","SEC_E_WRONG_COMPANY"); return 0;
    }

    minext=zend_hash_str_find(Z_ARRVAL_P(manifest),"minimum_extension_version",25);
    if(minext && Z_TYPE_P(minext)==IS_STRING &&
       version_compare(Z_STRVAL_P(minext),PHP_CONCHERON_SEC_VERSION)>0) {
        add_assoc_string(ret,"error_code","SEC_E_EXTENSION_TOO_OLD"); return 0;
    }

    expires=zend_hash_str_find(Z_ARRVAL_P(manifest),"expires_at",10);
    if(expires && Z_TYPE_P(expires)==IS_STRING) {
        time_t exp;
        if(!sec_parse_iso8601_utc(Z_STRVAL_P(expires),&exp)) goto bad;
        if(time(NULL)>exp) {
            add_assoc_string(ret,"error_code","SEC_E_PACKAGE_EXPIRED"); return 0;
        }
    }

    add_assoc_string(ret,"package_id",Z_STRVAL_P(pid));
    add_assoc_string(ret,"document_id",Z_STRVAL_P(did));
    add_assoc_string(ret,"document_version",Z_STRVAL_P(dv));
    add_assoc_string(ret,"classification",Z_STRVAL_P(cls));
    add_assoc_string(ret,"target_company_id",Z_STRVAL_P(company));
    add_assoc_string(ret,"recipient_usb_certificate_id",Z_STRVAL_P(recipient));
    add_assoc_string(ret,"crypto_suite",Z_STRVAL_P(suite));
    return 1;
bad:
    add_assoc_string(ret,"error_code","SEC_E_MANIFEST_INVALID"); return 0;
}

PHP_FUNCTION(concheron_sec_version)
{
    array_init(return_value);
    add_assoc_string(return_value,"extension_version",PHP_CONCHERON_SEC_VERSION);
    add_assoc_long(return_value,"api_version",1);
}

PHP_FUNCTION(concheron_sec_capabilities)
{
    array_init(return_value);
    add_assoc_bool(return_value,"package_inspect",1);
    add_assoc_bool(return_value,"canonical_manifest_json",1);
    add_assoc_bool(return_value,"package_signature_verify",1);
    add_assoc_bool(return_value,"package_policy_validate",1);
    add_assoc_bool(return_value,"package_import",0);
    add_assoc_bool(return_value,"usb_provider",0);
}

PHP_FUNCTION(concheron_sec_inspect_package)
{
    char *path; size_t pl; unsigned char *b=NULL; size_t n=0; sec_header h;
    if(zend_parse_parameters(ZEND_NUM_ARGS(),"p",&path,&pl)==FAILURE) RETURN_FALSE;
    array_init(return_value);
    if(!sec_load(path,&b,&n)){add_assoc_bool(return_value,"success",0);add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_READ");return;}
    if(!sec_parse_header(b,n,&h)){efree(b);add_assoc_bool(return_value,"success",0);add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_FORMAT");return;}
    add_assoc_bool(return_value,"success",1); add_assoc_bool(return_value,"verified",0);
    add_assoc_string(return_value,"trust","UNVERIFIED");
    add_assoc_long(return_value,"format_version",h.version);
    add_assoc_stringl(return_value,"manifest_raw",(char*)(b+SEC_HEADER_SIZE),h.manifest_length);
    efree(b);
}

PHP_FUNCTION(concheron_sec_verify_package)
{
    char *path; size_t pl; unsigned char *b=NULL; size_t n=0; sec_header h;
    uint64_t signed64; size_t signed_n; const unsigned char *sb,*sig;
    uint16_t sv,sa; uint32_t sl; zval manifest;

    if(zend_parse_parameters(ZEND_NUM_ARGS(),"p",&path,&pl)==FAILURE) RETURN_FALSE;
    array_init(return_value);

    if(!SEC_G(trusted_signing_key) || !*SEC_G(trusted_signing_key)) {
        add_assoc_bool(return_value,"success",0);
        add_assoc_string(return_value,"error_code","SEC_E_TRUST_NOT_CONFIGURED"); return;
    }
    if(!SEC_G(company_id) || !*SEC_G(company_id)) {
        add_assoc_bool(return_value,"success",0);
        add_assoc_string(return_value,"error_code","SEC_E_COMPANY_NOT_CONFIGURED"); return;
    }
    if(!sec_load(path,&b,&n)){add_assoc_bool(return_value,"success",0);add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_READ");return;}
    if(!sec_parse_header(b,n,&h)){efree(b);add_assoc_bool(return_value,"success",0);add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_FORMAT");return;}

    signed64=(uint64_t)SEC_HEADER_SIZE+h.manifest_length+h.recipient_length+h.payload_length;
    if(signed64>SIZE_MAX){efree(b);add_assoc_bool(return_value,"success",0);add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_FORMAT");return;}
    signed_n=(size_t)signed64; sb=b+signed_n;
    if(h.signature_length<SEC_SIG_HEADER_SIZE || memcmp(sb,SEC_SIG_MAGIC,4)!=0) goto sigfmt;
    sv=sec_u16(sb+4); sa=sec_u16(sb+6); sl=sec_u32(sb+8);
    if(sv!=1 || sa!=1 || (uint64_t)SEC_SIG_HEADER_SIZE+sl!=h.signature_length) goto sigfmt;
    sig=sb+SEC_SIG_HEADER_SIZE;
    if(!sec_verify_sig(b,signed_n,sig,sl,SEC_G(trusted_signing_key))) {
        efree(b); add_assoc_bool(return_value,"success",0); add_assoc_bool(return_value,"verified",0);
        add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_SIGNATURE"); return;
    }

    ZVAL_UNDEF(&manifest);
    php_json_decode_ex(&manifest,(char*)(b+SEC_HEADER_SIZE),h.manifest_length,
        PHP_JSON_OBJECT_AS_ARRAY,512);
    if(Z_TYPE(manifest)!=IS_ARRAY) {
        zval_ptr_dtor(&manifest); efree(b); add_assoc_bool(return_value,"success",0);
        add_assoc_bool(return_value,"verified",1); add_assoc_string(return_value,"error_code","SEC_E_MANIFEST_INVALID"); return;
    }

    add_assoc_bool(return_value,"verified",1);
    if(!sec_manifest_validate(&manifest,return_value)) {
        add_assoc_bool(return_value,"success",0);
        zval_ptr_dtor(&manifest); efree(b); return;
    }
    add_assoc_bool(return_value,"success",1);
    add_assoc_string(return_value,"trust","SIGNATURE_AND_POLICY_VERIFIED");
    zval_ptr_dtor(&manifest); efree(b); return;

sigfmt:
    efree(b); add_assoc_bool(return_value,"success",0);
    add_assoc_string(return_value,"error_code","SEC_E_PACKAGE_SIGNATURE_FORMAT");
}

ZEND_BEGIN_ARG_INFO_EX(ai_none,0,0,0)
ZEND_END_ARG_INFO()
ZEND_BEGIN_ARG_INFO_EX(ai_path,0,0,1)
    ZEND_ARG_INFO(0,packagePath)
ZEND_END_ARG_INFO()

static const zend_function_entry funcs[]={
    PHP_FE(concheron_sec_version,ai_none)
    PHP_FE(concheron_sec_capabilities,ai_none)
    PHP_FE(concheron_sec_inspect_package,ai_path)
    PHP_FE(concheron_sec_verify_package,ai_path)
    PHP_FE_END
};

PHP_MINIT_FUNCTION(concheron_sec){REGISTER_INI_ENTRIES();return SUCCESS;}
PHP_MSHUTDOWN_FUNCTION(concheron_sec){UNREGISTER_INI_ENTRIES();return SUCCESS;}
PHP_MINFO_FUNCTION(concheron_sec)
{
    php_info_print_table_start();
    php_info_print_table_header(2,"Concheron SEC support","enabled");
    php_info_print_table_row(2,"Version",PHP_CONCHERON_SEC_VERSION);
    php_info_print_table_row(2,"Policy validation","enabled");
    php_info_print_table_end();
    DISPLAY_INI_ENTRIES();
}

zend_module_entry concheron_sec_module_entry={
    STANDARD_MODULE_HEADER,"concheron_sec",funcs,
    PHP_MINIT(concheron_sec),PHP_MSHUTDOWN(concheron_sec),NULL,NULL,
    PHP_MINFO(concheron_sec),PHP_CONCHERON_SEC_VERSION,STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_CONCHERON_SEC
# ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
# endif
ZEND_GET_MODULE(concheron_sec)
#endif
