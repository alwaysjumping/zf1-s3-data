<?php
$path = $argv[1] ?? null;
if (!$path) {
    fwrite(STDERR, "Usage: php verify.php package.sec\n");
    exit(1);
}

$inspect = concheron_sec_inspect_package($path);
print_r($inspect);

$verified = concheron_sec_verify_package($path);
print_r($verified);
