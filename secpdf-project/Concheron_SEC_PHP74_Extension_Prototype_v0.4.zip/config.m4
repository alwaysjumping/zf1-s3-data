PHP_ARG_ENABLE(concheron_sec, whether to enable Concheron SEC support,
[  --enable-concheron-sec     Enable Concheron SEC support])

if test "$PHP_CONCHERON_SEC" != "no"; then
  PHP_SETUP_OPENSSL(CONCHERON_SEC_SHARED_LIBADD, [
    AC_MSG_ERROR([OpenSSL development files are required])
  ])
  PHP_SUBST(CONCHERON_SEC_SHARED_LIBADD)
  PHP_NEW_EXTENSION(concheron_sec, concheron_sec.c, $ext_shared)
fi
