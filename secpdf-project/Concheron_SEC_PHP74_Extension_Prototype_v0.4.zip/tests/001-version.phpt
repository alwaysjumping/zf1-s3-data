--TEST--
Concheron SEC v0.4 version
--SKIPIF--
<?php if (!extension_loaded("concheron_sec")) die("skip"); ?>
--FILE--
<?php
$v=concheron_sec_version();
echo $v["extension_version"], "\n";
?>
--EXPECT--
0.4.0
