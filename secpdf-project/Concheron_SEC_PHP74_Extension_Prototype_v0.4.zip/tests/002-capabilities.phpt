--TEST--
Concheron SEC v0.4 capabilities
--SKIPIF--
<?php if (!extension_loaded("concheron_sec")) die("skip"); ?>
--FILE--
<?php
$c=concheron_sec_capabilities();
var_dump($c["canonical_manifest_json"]);
var_dump($c["package_policy_validate"]);
var_dump($c["package_import"]);
?>
--EXPECT--
bool(true)
bool(true)
bool(false)
