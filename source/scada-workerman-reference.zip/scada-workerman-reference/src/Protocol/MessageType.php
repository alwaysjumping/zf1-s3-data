<?php
namespace Scada\Protocol;
final class MessageType {
 const HELLO='hello', HELLO_ACK='hello_ack', HEARTBEAT='heartbeat', HEARTBEAT_ACK='heartbeat_ack';
 const TAG_BATCH='tag_batch', COMMAND='command', COMMAND_ACK='command_ack', COMMAND_RESULT='command_result';
 const SNAPSHOT_REQUEST='snapshot_request', SNAPSHOT='snapshot', ERROR='error';
 public static function isValid(string $v): bool { return in_array($v,[self::HELLO,self::HELLO_ACK,self::HEARTBEAT,self::HEARTBEAT_ACK,self::TAG_BATCH,self::COMMAND,self::COMMAND_ACK,self::COMMAND_RESULT,self::SNAPSHOT_REQUEST,self::SNAPSHOT,self::ERROR],true); }
}
