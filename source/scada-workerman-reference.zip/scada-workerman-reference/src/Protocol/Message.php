<?php
namespace Scada\Protocol;
class Message {
 private $version,$type,$messageId,$sequence,$sourceId,$timestamp,$data;
 public function __construct(int $version,string $type,string $messageId,int $sequence,string $sourceId,int $timestamp,array $data=[]){$this->version=$version;$this->type=$type;$this->messageId=$messageId;$this->sequence=$sequence;$this->sourceId=$sourceId;$this->timestamp=$timestamp;$this->data=$data;}
 public static function fromArray(array $a): self { return new self((int)$a['version'],(string)$a['type'],(string)$a['message_id'],(int)$a['sequence'],(string)$a['source_id'],(int)$a['timestamp'],(array)($a['data']??[])); }
 public static function create(string $type,string $sourceId,int $sequence,array $data=[]): self { $ms=(int)floor(microtime(true)*1000); return new self(1,$type,$ms.'-'.bin2hex(random_bytes(6)),$sequence,$sourceId,$ms,$data); }
 public function toArray(): array { return ['version'=>$this->version,'type'=>$this->type,'message_id'=>$this->messageId,'sequence'=>$this->sequence,'source_id'=>$this->sourceId,'timestamp'=>$this->timestamp,'data'=>$this->data]; }
 public function getType():string{return $this->type;} public function getSourceId():string{return $this->sourceId;} public function getSequence():int{return $this->sequence;} public function getData():array{return $this->data;} public function getMessageId():string{return $this->messageId;}
}
