<?php
namespace Scada\Protocol;
class MessageValidator { public function validate(array $a): void { foreach(['version','type','message_id','sequence','source_id','timestamp','data'] as $k) if(!array_key_exists($k,$a)) throw new \RuntimeException('Missing field: '.$k); if((int)$a['version']!==1) throw new \RuntimeException('Unsupported protocol version'); if(!MessageType::isValid((string)$a['type'])) throw new \RuntimeException('Unknown message type'); if(!is_array($a['data'])) throw new \RuntimeException('data must be object/array'); } }
