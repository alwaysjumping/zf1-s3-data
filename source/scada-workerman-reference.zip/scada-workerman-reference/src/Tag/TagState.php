<?php
namespace Scada\Tag;
class TagState { public $name,$value,$quality,$sourceTimestamp,$serverTimestamp,$sourceId; public function __construct(string $name,$value,string $quality,int $sourceTimestamp,string $sourceId){$this->name=$name;$this->value=$value;$this->quality=$quality;$this->sourceTimestamp=$sourceTimestamp;$this->serverTimestamp=(int)floor(microtime(true)*1000);$this->sourceId=$sourceId;} public function toArray():array{return get_object_vars($this);} }
