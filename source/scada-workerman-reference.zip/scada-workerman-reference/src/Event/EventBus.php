<?php
namespace Scada\Event;
class EventBus { private $listeners=[]; public function subscribe(string $name,callable $fn):void{$this->listeners[$name][]=$fn;} public function dispatch(string $name,$event):void{foreach($this->listeners[$name]??[] as $fn){try{$fn($event);}catch(\Throwable $e){error_log('Event listener '.$name.': '.$e->getMessage());}}} }
