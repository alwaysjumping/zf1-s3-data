<?php
namespace Scada\Network;
use Workerman\Connection\ConnectionInterface;
use Scada\Protocol\Message;
class ScadaProtocol {
 const HEADER_SIZE=4, MAX_PACKAGE_SIZE=1048576;
 public static function input(string $buffer,ConnectionInterface $connection): int { if(strlen($buffer)<4)return 0; $h=unpack('Nlength',substr($buffer,0,4)); $n=(int)$h['length']; if($n<=0||$n>self::MAX_PACKAGE_SIZE){$connection->close();return 0;} return 4+$n; }
 public static function decode(string $buffer,ConnectionInterface $connection): array { $a=json_decode(substr($buffer,4),true); if(!is_array($a))throw new \RuntimeException('Invalid JSON'); return $a; }
 public static function encode($data,ConnectionInterface $connection): string { if($data instanceof Message)$data=$data->toArray(); $json=is_string($data)?$data:json_encode($data,JSON_UNESCAPED_SLASHES); if($json===false)throw new \RuntimeException('JSON encode failed'); return pack('N',strlen($json)).$json; }
}
