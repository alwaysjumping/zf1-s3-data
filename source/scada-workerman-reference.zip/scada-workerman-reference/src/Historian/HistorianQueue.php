<?php
namespace Scada\Historian;
class HistorianQueue { private $items=[],$max; public function __construct(int $max=10000){$this->max=$max;} public function push(array $x):bool{if(count($this->items)>=$this->max)return false;$this->items[]=$x;return true;} public function drain(int $n=500):array{return array_splice($this->items,0,$n);} public function count():int{return count($this->items);} }
