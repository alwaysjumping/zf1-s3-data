# SCADA Core with Workerman Raw TCP — PHP 7.4 Reference Guide

## 1. Purpose
This project is a reference implementation for the architecture developed in our SCADA design discussion. It uses **PHP 7.4**, **Workerman raw TCP**, and **MariaDB**. Internal SCADA/gateway communication is raw TCP, not WebSocket.

> This is an engineering reference/simulator, not a certified safety system. PLC/SIS logic must retain safety interlocks and emergency-stop responsibilities.

## 2. Architecture

```text
PLC / RTU
   |
Modbus TCP / OPC UA
   |
PLC Gateway
   |  normalized length-prefixed JSON over raw TCP
   v
SCADA Core (one logical realtime state owner)
   |-- Source/Session Manager
   |-- Tag Engine / current state
   |-- Internal Event Bus
   |-- Alarm Engine
   |-- Command Engine
   |-- Realtime publisher boundary
   `-- Historian handoff
            |
       separate historian process in production
            |
         MariaDB / disk spool
```

The included simulator replaces the real Modbus/OPC-UA acquisition driver so the protocol and SCADA Core can be exercised without PLC hardware.

## 3. Why Workerman raw TCP
Workerman provides the event loop, connection lifecycle, non-blocking managed socket I/O, receive/send buffering, timers, process lifecycle, and callbacks. TCP itself is a byte stream, so this project adds a protocol frame:

```text
+----------------+-------------------------+
| uint32 length  | JSON payload            |
+----------------+-------------------------+
```

The four-byte length is network byte order (`pack('N', $length)`). `ScadaProtocol::input()` tells Workerman the complete frame length; `decode()` converts the JSON payload to an array.

## 4. Message envelope

```json
{
  "version": 1,
  "type": "tag_batch",
  "message_id": "unique-message-id",
  "sequence": 1001,
  "source_id": "PLC-GATEWAY-01",
  "timestamp": 1791080000000,
  "data": {}
}
```

- `message_id`: protocol-message identity/deduplication/tracing.
- `sequence`: ordering and gap detection.
- `source_id`: authenticated logical sender.
- `timestamp`: sender timestamp in milliseconds.
- `data`: message-specific payload.
- Production recovery should also retain a gateway `boot_id` so a sequence reset after gateway restart is distinguishable from sequence regression.

## 5. Session lifecycle

```text
DISCONNECTED
  -> CONNECTED
  -> AUTHENTICATED (HELLO)
  -> SYNCHRONIZING (snapshot)
  -> HEALTHY
  -> DEGRADED / DISCONNECTED
```

A TCP connection is not a SCADA session. The gateway must first send `HELLO`. The Core replies with `HELLO_ACK` and requests a snapshot.

## 6. Tag Engine
The Tag Engine owns normalized current state in memory. A tag state includes value, quality, source timestamp, server timestamp and source identity. The simulator uses `GOOD`; production should support `GOOD`, `UNCERTAIN`, `BAD`, `COMM_LOST`, `STALE`, `NOT_CONNECTED`, and configuration errors.

On gateway disconnect, the last value is retained but quality becomes `COMM_LOST`; the value must not be replaced with zero.

```text
72.5 GOOD
   -> communication failure
72.5 COMM_LOST
```

MariaDB is not queried synchronously for every tag update.

## 7. Internal Event Bus
`EventBus` decouples the Tag Engine from consumers. A tag update can feed Alarm Engine, Command Engine, historian selection and realtime publication. In-process listeners must be fast and non-blocking. Blocking PDO/device-library work belongs in another process.

State and events are different:

- **STATE** (current tag values) can sometimes be coalesced for a slow HMI because a snapshot can reconstruct current truth.
- **EVENTS** (alarm activation/ACK/return and commands) must preserve occurrence/order and must not be silently coalesced.

## 8. Alarm Engine
The included alarm implementation demonstrates HIGH/LOW evaluation and hysteresis. The production design adds HIGH_HIGH/LOW_LOW, activation delay, `ACTIVE_UNACK`, `ACTIVE_ACK`, `RETURNED_UNACK`, acknowledgement, shelving, suppression, disablement and an append-oriented durable alarm journal.

ACK means the operator acknowledged the alarm; it does not mean the process condition is fixed.

## 9. Command Engine
A control command is not successful just because TCP accepted bytes.

```text
REQUESTED
 -> VALIDATED
 -> SENT
 -> gateway COMMAND_ACK
 -> EXECUTING
 -> physical feedback observed
 -> CONFIRMED
```

Possible terminal states include `REJECTED`, `FAILED`, `TIMEOUT`, and `INDETERMINATE` after ambiguous failure/recovery.

Example:

```text
PUMP01.START
  -> gateway writes PUMP01.START_CMD = 1
  -> PLC applies its own interlocks
  -> equipment changes
  -> PUMP01.RUNNING = 1
  -> Command Engine CONFIRMED
```

Never blindly retry an ambiguous non-idempotent control command after a disconnect. Use command IDs, request/idempotency IDs, feedback and reconciliation.

## 10. Safety boundary
SCADA validation is defense-in-depth and operator assistance. It does **not** replace PLC/SIS interlocks. Emergency stop must not depend on Browser -> CodeIgniter -> SCADA Core -> gateway -> PLC software communication.

## 11. Historian
Realtime processing should not execute one synchronous SQL insert per tag update. The included `HistorianQueue` demonstrates the handoff concept. Production architecture should run historian persistence in a separate process with IPC, batch writes and a bounded disk spool.

Recommended modes:

- `CHANGE`: record meaningful value/quality changes.
- `CYCLIC`: sample current TagStateStore at a configured interval.
- `EVENT`: durable occurrence-oriented history.

A MariaDB outage must not freeze acquisition, alarms or commands.

## 12. Acquisition / PLC gateway
Protocol-specific code belongs at the gateway:

```text
ModbusTcpDriver --\
                  -> Acquisition Manager -> normalized tags -> SCADA Core
OpcUaDriver -----/
```

Modbus polling should combine contiguous registers into read blocks. Store unambiguous register type + zero-based protocol offset rather than relying only on human `40001` notation. Scaling belongs in the acquisition layer.

OPC UA drivers can use subscriptions and native quality/timestamps while still producing the same normalized SCADA tag model.

## 13. Recovery
After SCADA restart, do not load the last historian value and mark it `GOOD`. Initialize runtime state as unknown/`NOT_CONNECTED`, reconnect sources, obtain fresh snapshots, then mark data good after fresh valid acquisition.

Snapshots recover **state**. They cannot reconstruct events that occurred and cleared while central SCADA was offline. If those events must survive central downtime, the gateway/PLC side needs durable event capture/replay.

Alarm recovery combines durable alarm lifecycle state with fresh process conditions. Command recovery combines durable command records with live PLC feedback and must support an `INDETERMINATE` outcome when historical execution cannot be proven.

## 14. MariaDB
`sql/schema.sql` provides a compact starter schema. The full production schema should additionally include scan groups, Modbus/OPC-UA mapping tables, alarm definitions/current state, command definitions/events, configuration versions, and audit events as designed in the architecture discussion.

Important historian index:

```sql
KEY idx_tag_source_ts (tag_id, source_ts)
```

Do not create one history table per tag.

## 15. Browser / CodeIgniter boundary
The browser cannot directly use arbitrary raw TCP. Keep internal gateway communication raw TCP; use HTTPS plus WebSocket or SSE at the browser boundary.

CodeIgniter handles authentication, authorization, configuration, reports, history queries, alarm actions and command requests. It should not directly perform Modbus writes. All operator control follows the Command Engine path.

## 16. Installation
On the CentOS/Linux runtime with PHP 7.4 and Composer available:

```bash
cd scada-workerman-reference
composer install
```

For an offline deployment, prepare the Composer dependencies on an internet-connected staging machine compatible with PHP 7.4, then transfer the project/vendor tree according to your controlled software-deployment procedure.

## 17. Run the demonstration
Terminal 1:

```bash
php start.php start
```

Terminal 2:

```bash
php gateway/simulator.php
```

The gateway performs `HELLO`; the Core requests a snapshot; the simulator sends current `TANK01.LEVEL` and `PUMP01.RUNNING` states and then periodic tag batches and heartbeats. As the simulated tank level crosses the configured high threshold, the demo Alarm Engine prints activation/return messages.

Stop the gateway to observe source disconnect handling and `COMM_LOST` propagation.

## 18. Source tree

```text
scada-workerman-reference/
|-- composer.json
|-- start.php
|-- SCADA_WORKERMAN_GUIDE.md
|-- gateway/
|   `-- simulator.php
|-- sql/
|   `-- schema.sql
`-- src/
    |-- Alarm/AlarmEngine.php
    |-- Command/CommandEngine.php
    |-- Event/EventBus.php
    |-- Historian/HistorianQueue.php
    |-- Network/ScadaProtocol.php
    |-- Protocol/Message.php
    |-- Protocol/MessageType.php
    |-- Protocol/MessageValidator.php
    |-- Source/SourceManager.php
    `-- Tag/
        |-- TagEngine.php
        `-- TagState.php
```

## 19. What the sample intentionally does not pretend to implement
The reference does not claim production completeness for: TLS/mTLS certificate provisioning, real Modbus/OPC-UA libraries, certified safety behavior, complete RBAC, durable alarm/command repositories, disk spool integrity, high-availability/redundancy, browser realtime transport, configuration deployment, or complete sequence-gap replay. Those are explicit extension points rather than fake implementations.

## 20. Recommended implementation sequence
1. Run Core + simulator.
2. Add PHPUnit tests for framing, Tag Engine, alarms and commands.
3. Add durable alarm/command repositories.
4. Split historian into its own Workerman/process service and IPC protocol.
5. Implement snapshot chunks/base sequence and gap detection.
6. Add gateway authentication/encryption.
7. Add a real Modbus driver behind the gateway interface.
8. Add OPC UA behind the same normalized interface.
9. Integrate CodeIgniter current-state/alarm/command/history APIs.
10. Perform failure injection and load tests before production deployment.

## 21. Key rules to preserve
- Workerman raw TCP is the SCADA/gateway transport.
- One logical realtime process owns authoritative in-memory state in version 1.
- Workerman processes do not automatically share PHP memory.
- Never block the realtime event loop with slow PDO or blocking industrial-protocol calls.
- Current state, process history and critical events have different durability semantics.
- `COMMAND_ACK` is not physical confirmation.
- State may sometimes coalesce; critical events may not.
- A snapshot repairs current state, not missing historical events.
- Never mark stale restored values `GOOD` after restart.
- Do not blindly retry ambiguous commands.
- PLC/SIS owns safety and deterministic interlocks.
