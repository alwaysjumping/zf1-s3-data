<?php
use Workerman\Worker; use Workerman\Timer;
use Scada\Network\ScadaProtocol; use Scada\Protocol\{Message,MessageType,MessageValidator}; use Scada\Event\EventBus; use Scada\Tag\TagEngine; use Scada\Alarm\AlarmEngine; use Scada\Command\CommandEngine; use Scada\Source\SourceManager; use Scada\Historian\HistorianQueue;
require __DIR__.'/vendor/autoload.php';
$bus=new EventBus(); $sources=new SourceManager(); $validator=new MessageValidator(); $seq=0;
$owners=['TANK01.LEVEL'=>'PLC-GATEWAY-01','PUMP01.RUNNING'=>'PLC-GATEWAY-01'];
$tags=new TagEngine($bus,$owners);
$alarms=new AlarmEngine([['code'=>'TANK01.LEVEL_HIGH','tag'=>'TANK01.LEVEL','type'=>'HIGH','limit'=>90,'hysteresis'=>2]]);
$commands=new CommandEngine(['PUMP01.START'=>['source'=>'PLC-GATEWAY-01','write_tag'=>'PUMP01.START_CMD','write_value'=>1,'feedback_tag'=>'PUMP01.RUNNING','expected_feedback'=>1,'timeout_ms'=>5000]],$tags);
$history=new HistorianQueue();
$bus->subscribe('tag.updated',[$alarms,'onTagUpdated']); $bus->subscribe('tag.updated',[$commands,'onTagUpdated']); $bus->subscribe('tag.updated',function($e)use($history){$history->push($e['new']->toArray());});
$worker=new Worker('tcp://0.0.0.0:9000'); $worker->name='SCADA-Core'; $worker->count=1; $worker->protocol=ScadaProtocol::class;
$sendTo=function(string $source,Message $m)use($sources){$c=$sources->connection($source);if(!$c)throw new RuntimeException('Source offline: '.$source);$c->send($m);};
$worker->onConnect=function($c)use($sources){$sources->add($c);echo "CONNECT {$c->id}\n";};
$worker->onMessage=function($c,$raw)use($sources,$validator,$tags,&$seq){try{$validator->validate($raw);$m=Message::fromArray($raw); if(!$sources->isAuthenticated($c)&&$m->getType()!==MessageType::HELLO)throw new RuntimeException('HELLO required'); if($m->getType()===MessageType::HELLO){$d=$m->getData();$sources->hello($c,$m->getSourceId(),(string)($d['boot_id']??'unknown'));$c->send(Message::create(MessageType::HELLO_ACK,'SCADA-CORE-01',++$seq,['heartbeat_interval'=>10,'snapshot_required'=>true]));$c->send(Message::create(MessageType::SNAPSHOT_REQUEST,'SCADA-CORE-01',++$seq,['reason'=>'connect']));return;} if($m->getSourceId()!==$sources->getSource($c))throw new RuntimeException('Source mismatch');$sources->touch($c,$m->getSequence()); if($m->getType()===MessageType::HEARTBEAT){$c->send(Message::create(MessageType::HEARTBEAT_ACK,'SCADA-CORE-01',++$seq,[]));return;} if(in_array($m->getType(),[MessageType::TAG_BATCH,MessageType::SNAPSHOT],true)){foreach(($m->getData()['tags']??[]) as $t)$tags->update($m->getSourceId(),$t['tag'],$t['value'],$t['quality']??'GOOD',(int)($t['source_timestamp']??floor(microtime(true)*1000)));return;} }catch(Throwable $e){echo 'ERROR '.$e->getMessage()."\n";$c->send(Message::create(MessageType::ERROR,'SCADA-CORE-01',++$seq,['message'=>$e->getMessage()]));}};
$worker->onClose=function($c)use($sources,$tags){$s=$sources->remove($c);if($s){$tags->markSourceOffline($s);echo "SOURCE OFFLINE $s\n";}};
$worker->onWorkerStart=function()use($commands,$history){Timer::add(0.1,function()use($commands){$commands->tick();});Timer::add(1.0,function()use($history){if($history->count()){echo 'Historian demo drain: '.count($history->drain(500))." samples\n";}});};
Worker::runAll();
