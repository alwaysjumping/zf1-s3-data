<?php
/** ZF1 class, underscore autoload convention. Use in both web and CLI bootstraps. */
require_once dirname(__DIR__,4).'/src/LicenseRuntime.php';
class S3_License_Manager {
 private $runtime;
 public function __construct(S3_License_Runtime $runtime) {$this->runtime=$runtime;}
 public static function fromConfig(array $config): self {return new self(S3_License_Runtime::fromConfig($config));}
 public function canActivate(string $moduleId,string $installedVersion): bool {return $this->runtime->canActivate($moduleId,$installedVersion);}
 public function canExecute(string $moduleId,string $installedVersion): bool {return $this->runtime->canExecute($moduleId,$installedVersion);}
 public function canUseFeature(string $moduleId,string $installedVersion,string $feature): bool {return $this->runtime->canUseFeature($moduleId,$installedVersion,$feature);}
 public function getStatus(string $moduleId,string $installedVersion): array {return $this->runtime->getStatus($moduleId,$installedVersion);}
}
