<?php
/** PHP 7.4 runtime gate for trusted server-side callers. Never accept company/installation from HTTP. */
require_once __DIR__.'/Core.php';
final class S3_License_Runtime {
 private $db; private $identity; private $public; private $kid;
 public function __construct(PDO $db, array $identity, string $authorityPublicKey, string $keyId) {
  foreach(['company_id','installation_id','public_key'] as $k) if(!is_string($identity[$k]??null)||$identity[$k]==='') throw new RuntimeException('Invalid local identity');
  if(strlen(Core::unb64($identity['public_key']))!==32||strlen($authorityPublicKey)!==32) throw new RuntimeException('Invalid public key');
  $this->db=$db; $this->identity=$identity; $this->public=$authorityPublicKey; $this->kid=$keyId;
 }
 public static function fromConfig(array $config): self {
  if(!is_string($config['identity_file']??null)||!is_file($config['identity_file'])) throw new RuntimeException('Trusted identity file missing');
  $identity=Core::parse(file_get_contents($config['identity_file']));
  if(!is_string($config['authority_public_key_file']??null)||!is_file($config['authority_public_key_file'])) throw new RuntimeException('Authority key missing');
  $public=Core::unb64(trim(file_get_contents($config['authority_public_key_file'])));
  return new self(Core::db($config),$identity,$public,$config['key_id']);
 }
 public function canExecute(string $moduleId,string $installedVersion): bool {return $this->decision($moduleId,$installedVersion,null);}
 public function canActivate(string $moduleId,string $installedVersion): bool {return $this->decision($moduleId,$installedVersion,null);}
 public function canUseFeature(string $moduleId,string $installedVersion,string $feature): bool {return $this->decision($moduleId,$installedVersion,$feature);}
 public function getStatus(string $moduleId,string $installedVersion): array {
  try {return ['allowed'=>$this->decisionChecked($moduleId,$installedVersion,null),'reason'=>'Policy evaluated'];}
  catch(Throwable $e) {return ['allowed'=>false,'reason'=>'License unavailable or invalid'];}
 }
 private function decision(string $module,string $version,?string $feature): bool {
  try{return $this->decisionChecked($module,$version,$feature);}catch(Throwable $e){return false;}
 }
 private function decisionChecked(string $module,string $version,?string $feature): bool {
  if(!preg_match('/^[a-zA-Z0-9._-]{1,150}$/D',$module)||!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$/D',$version)) return false;
  $s=Core::row($this->db,'SELECT sequence_no,status_json FROM local_status_state WHERE id=1');
  if(!$s) return false;
  $status=Core::verifyStatus($s['status_json'],$this->public,$this->kid);
  if((int)$s['sequence_no']!==$status['sequence']) return false;
  $q=$this->db->prepare("SELECT certificate_json FROM local_license_certificates WHERE module_code=? AND status='ACTIVE' ORDER BY revision_no DESC,id DESC");
  $q->execute([$module]);
  while(($cert=$q->fetchColumn())!==false){
   try {
    $p=Core::verifyLicense($cert,$this->public,$this->kid);
    foreach(['license_id','company_id','installation_id','installation_key_sha256','module_id','version_min','version_max_exclusive','not_before'] as $key)
     if(!is_string($p[$key]??null)||$p[$key]==='')continue 2;
    if(!hash_equals($this->identity['company_id'],$p['company_id'])||!hash_equals($this->identity['installation_id'],$p['installation_id']))continue;
    if(!hash_equals(hash('sha256',Core::unb64($this->identity['public_key'])),$p['installation_key_sha256']))continue;
    if($p['module_id']!==$module||version_compare($version,$p['version_min'],'<')||version_compare($version,$p['version_max_exclusive'],'>='))continue;
    if(time()<Core::utcTimestamp($p['not_before']))continue;
    if(($p['usage_expires_at']??null)!==null && (!is_string($p['usage_expires_at'])||time()>=Core::utcTimestamp($p['usage_expires_at'])))continue;
    if(in_array($p['license_id'],$status['revoked_license_ids'],true))continue;
    $revoked=Core::row($this->db,'SELECT license_code FROM local_revoked_licenses WHERE license_code=?',[$p['license_id']]);
    if($revoked)continue;
    if($feature!==null && (!is_array($p['features']??null)||!in_array($feature,$p['features'],true)))continue;
    return true;
   }catch(Throwable $ignored) {continue;}
  }
  return false;
 }
}
