# Module Licensing Foundation — PHP 7.4 demo

**Scope:** Runnable command-line proof of concept for offline activation with MariaDB, Ed25519 installation proof, single-use challenges, transactional activation limits, idempotent issuance, and signed offline license verification. **Not production-ready**: no authenticated operator interface, full schema validation, revocation, secure hardware binding, audit logs, renewal, or release trust verification. The `verify` command checks the license signature and basic claims; it does not verify possession of the installation private key or revocation state. It must not be used as a production authorization gate.

## Requirements

PHP 7.4 with `sodium`, `pdo_mysql`; MariaDB 10.11. Run CLI tools only on trusted hosts. Use separate authority and subsidiary environments in production; this demo combines commands for convenience.

## Setup

1. Create database `module_licensing`, and a restricted DB account with access to it. Import `sql/schema.sql`.
2. Copy `config/config.example.php` to `config/config.php` and set DB credentials.
3. Generate signing keys: `php bin/app.php keys > keys.json`. Copy the `secret` value to `secrets/authority.secret`, and `public` to `secrets/authority.public` (each file contains only the base64url value). Restrict secret file permissions and never serve the secrets directory over HTTP. For production, do not generate or export keys in a combined JSON file.
4. `php bin/app.php company COMPANY_B 'Company B'`
5. `php bin/app.php identity COMPANY_B > company-b-identity.json` — **contains private key; keep secret**.
6. `php bin/app.php register company-b-identity.json` — demo operator approval; production registration requires independent company authorization.
7. `php bin/app.php entitlement COMPANY_B company_a.crm_advanced 1 2.0.0 3.0.0` — record printed entitlement ID.
8. `php bin/app.php challenge ENT-... INST-... > challenge.json` — use the IDs from the previous outputs.
9. `php bin/app.php respond challenge.json company-b-identity.json > response.json`
10. `php bin/app.php activate response.json > license.json`
11. `php bin/app.php verify license.json secrets/authority.public COMPANY_B INST-... company_a.crm_advanced 2.1.0`
12. Repeat step 10: the exact request returns the same certificate. Create a second identity and challenge for the same entitlement to test the one-installation limit.

`config/config.php`, `secrets/`, identity files, and response/license artifacts should be protected and excluded from source control. The `bin/app.php` file is CLI-only and must not be exposed via a web server.

## Security limitations

- The demo uses the application server's wall clock, which is not tamper-resistant.
- Offline revocation and security-status freshness are not implemented.
- Software-based private keys can be copied by a privileged user.
- JSON duplicate-key rejection, strict payload schemas, and full protocol parsing are not implemented.
- Operator actions have no authentication or audit trail in this prototype.
- Challenge expiration uses the application clock for comparison; configure application and database servers to UTC and synchronize clocks.
- The demo supports one issuer key ID (`demo-2026-01`) and no key rotation.
- No PHPUnit suite is included yet. Test in an isolated development environment only.

## Part 16 extension — subsidiary-side import and offline checks

The `bin/client.php` tool adds a local MariaDB certificate store. It is **development-only** and intentionally does not enforce revocation or trustworthy local time. The local identity file contains an exportable private key; do not expose it through HTTP.

1. Create a separate `module_licensing_client` MariaDB database and import `sql/client-schema.sql` there.
2. Copy `config/client.example.php` to `config/client.php`; configure a restricted local database account.
3. Keep the authority public key in `secrets/authority.public` (the client must **not** receive `authority.secret`).
4. After following the authority workflow above and generating `license.json`, run:

```sh
php bin/client.php import license.json company-b-identity.json company_a.crm_advanced 2.1.0
php bin/client.php check company-b-identity.json company_a.crm_advanced 2.1.0
php bin/client.php list
```

Re-importing an identical certificate is idempotent. Importing a different certificate with the same logical license and revision is rejected. A newer signed revision supersedes the old revision.

**Important:** The CLI uses a caller-supplied identity file and has no administrative authentication, hardened private-key storage, signed revocation-status synchronization, anti-rollback storage, release trust verification, or integration tests. The `check` command is **not** an authorization API for production ZF1 modules. In particular, do not enable paid modules based solely on its result. The certificate importer currently requires the requested module version to be permitted at import time; a future installer should allow import before installing a module. Existing Part 15 scripts are unchanged.


## v0.3: Signed offline revocation status (development prototype)

Apply `sql/client-status-v03.sql` to the **client** database after the v0.2 schema.

Authority: prepare `revoked.json` as a JSON array of revoked license IDs, e.g. `["LIC-EXAMPLE"]`. This file must be an administrator-approved **cumulative** list, not merely new revocations.

```sh
php bin/issue-status.php 1 2026-10-25T00:00:00Z revoked.json status.json
```

The sequence is allocated by the operator in this prototype. In production, the authority must allocate it atomically from a durable registry; do not reuse sequence numbers. Use a future expiry suitable for your policy. Transfer `status.json` through the authorized offline channel.

On subsidiary:

```sh
php bin/client.php import-status status.json
php bin/client.php check identity.json company_a.crm_advanced 2.1.0
```

The check **fails closed** if no status package has been imported or the signed status package is expired. Status signature verification is separate from license signature verification, using domain-separated signing messages. Imported sequence numbers must increase; identical package reimports are idempotent. Revoked IDs remain denied in the local database, and the current signed snapshot is also checked.

**Limitations:** No live MariaDB integration test has been performed. Revocation status cannot update until transferred; a database rollback, compromised administrator, clock manipulation, or copied private key can undermine offline guarantees. For production, use protected monotonic state, a durable authority-side status sequence, authenticated operators, stronger time assumptions, and a full audit trail. A previously revoked ID is never unrevoked by this prototype. Also note that `check` validates the identity JSON supplied on the CLI, not a hardware-backed identity.

## v0.4 — ZF1 runtime license gate (prototype)

New `src/LicenseRuntime.php` provides `canActivate($moduleId,$installedVersion)`, `canExecute($moduleId,$installedVersion)`, `canUseFeature($moduleId,$installedVersion,$feature)` and `getStatus(...)`. It checks signed license certificates and signed status snapshots, and fails closed on missing/stale status. A simple ZF1 underscore-named adapter is in `zf1/library/S3/License/Manager.php`.

**Installation:** copy `src/Core.php`, `src/LicenseRuntime.php` and `zf1/library/S3/License/Manager.php` into equivalent paths in your ZF1 deployment (preserve the relative layout or adjust the require path). Use a **trusted server-side** config, never request parameters, to supply `identity_file`, `authority_public_key_file`, `key_id`, `dsn`, `user`, and `password`. The `identity_file` should point to the installation identity JSON generated during setup, located outside the document root. This runtime only uses its public fields; protect its private key separately. The MariaDB client tables from v0.2 and status tables from v0.3 are required.

```php
$config = require '/secure/config/client.php';
$licenses = S3_License_Manager::fromConfig($config);
$moduleId = 'company_a.crm_advanced';
$installedVersion = '2.1.0'; // obtain from trusted installed-module registry
if (!$licenses->canExecute($moduleId, $installedVersion)) {
    throw new RuntimeException('Module not licensed');
}
```

Do not use an HTTP-supplied version string or company/installation ID as a trusted input. Apply checks in APIs, cron, CLI, hooks and module activation, not just menus. The adapter does not automatically intercept ZF1 execution: the host application must enforce the check at its trusted dispatch/execution boundaries.

**Feature checks:** `canUseFeature('company_a.crm_advanced','2.1.0','advanced_reporting')` denies by default when the signed payload lacks a `features` array. Existing v0.1–v0.3 issued certificates may not carry features and therefore cannot authorize specific features. Version 0.4 does not add new issuance parameters.

**Smoke test:** `php tests/smoke.php`. It tests signing and tampering without a database. Integration tests with MariaDB, concurrency, certificate rollback, clock tampering, trusted release verification, and a full ZF1 installation are not yet implemented. This is **not production authorization software**. PHP 7.4 is end-of-life; plan a supported PHP upgrade.
