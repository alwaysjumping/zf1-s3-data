<?php
require __DIR__.'/../src/LicenseRuntime.php';
function expect(bool $ok,string $name): void {if(!$ok)throw new RuntimeException('FAIL '.$name);echo 'PASS '.$name."\n";}
$pair=sodium_crypto_sign_keypair();$secret=sodium_crypto_sign_secretkey($pair);$public=sodium_crypto_sign_publickey($pair);
$payload=['license_id'=>'LIC-X','company_id'=>'B','installation_id'=>'I','installation_key_sha256'=>str_repeat('0',64),'module_id'=>'company_a.crm_advanced','version_min'=>'2.0.0','version_max_exclusive'=>'3.0.0','not_before'=>'2026-01-01T00:00:00Z'];
$cert=Core::signLicense($payload,$secret,'test');expect(Core::verifyLicense($cert,$public,'test')===$payload,'signature roundtrip');
$c=json_decode($cert,true);$c['payload']=Core::b64('{"tampered":true}');
try{Core::verifyLicense(Core::json($c),$public,'test');throw new RuntimeException('Tamper accepted');}catch(RuntimeException $e){if($e->getMessage()==='Tamper accepted')throw $e;echo "PASS tamper rejected\n";}
$status=Core::signStatus(['sequence'=>1,'issued_at'=>'2026-10-01T00:00:00Z','valid_until'=>'2099-01-01T00:00:00Z','revoked_license_ids'=>['LIC-X']],$secret,'test');
expect(Core::verifyStatus($status,$public,'test')['revoked_license_ids']===['LIC-X'],'signed status');
expect(class_exists('S3_License_Runtime'),'runtime class loads');
