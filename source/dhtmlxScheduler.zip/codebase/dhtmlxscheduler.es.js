/** @license

dhtmlxScheduler v.7.2.15 Standard

To use dhtmlxScheduler in non-GPL projects (and get Pro version of the product), please obtain Commercial/Enterprise or Ultimate license on our site https://dhtmlx.com/docs/products/dhtmlxScheduler/#licensing or contact us at sales@dhtmlx.com

(c) XB Software Ltd.

*/
const le = typeof window < "u" ? window : global;
function Tt(e) {
  let i = [], t = !1, n = null, s = null;
  function a() {
    return e.config.drag_highlight && e.markTimespan;
  }
  function o(l) {
    const _ = e.getView(l);
    return _ ? _.layout : l;
  }
  function d(l) {
    const { event: _, layout: h, viewName: p, sectionId: v, eventNode: g } = l;
    (function(u, y) {
      switch (y) {
        case "month":
          u.style.top = "", u.style.left = "";
          break;
        case "timeline":
          u.style.left = "", u.style.marginLeft = "1px";
          break;
        default:
          u.style.top = "";
      }
    })(g, h);
    const c = {};
    let f = { start_date: _.start_date, end_date: _.end_date, css: "dhx_scheduler_dnd_marker", html: g };
    if (h == "timeline") {
      const u = e.getView(p);
      if (u.round_position) {
        const y = e._get_date_index(u, _.start_date), w = u._trace_x[y];
        f.start_date = w;
      }
    }
    return h != "timeline" && h != "month" || (f = { ...f, end_date: e.date.add(_.start_date, 1, "minute") }), v && (c[p] = v, f.sections = c), f;
  }
  function r(l) {
    const { layout: _ } = l;
    let h;
    switch (_) {
      case "month":
        h = function(p) {
          let v = [];
          const { event: g, layout: c, viewName: f, sectionId: u } = p, y = [];
          let w = new Date(g.start_date);
          for (; w.valueOf() < g.end_date.valueOf(); ) {
            let M = { start_date: w };
            y.push(M), w = e.date.week_start(e.date.add(w, 1, "week"));
          }
          let D = e.$container.querySelectorAll(`[${e.config.event_attribute}='${g.id}']`);
          for (let M = 0; M < D.length; M++) {
            const k = { event: y[M], layout: c, viewName: f, sectionId: u, eventNode: D[M].cloneNode(!0) };
            v.push(d(k));
          }
          return v;
        }(l);
        break;
      case "timeline":
      case "units":
        h = function(p) {
          let v = [];
          const { event: g, layout: c, viewName: f, eventNode: u } = p;
          let y = function(w) {
            const D = e.getView(w);
            return D.y_property ? D.y_property : D.map_to ? D.map_to : void 0;
          }(f);
          if (y) {
            const w = String(g[y]).split(e.config.section_delimiter).map((M) => String(M)), D = [];
            for (let M = 0; M < w.length; M++) {
              D[M] = u.cloneNode(!0);
              const k = { event: g, layout: c, viewName: f, sectionId: w[M], eventNode: D[M] };
              v.push(d(k));
            }
          }
          return v;
        }(l);
        break;
      default:
        h = function(p) {
          const { event: v, layout: g, viewName: c, sectionId: f } = p;
          let u = [], y = e.$container.querySelectorAll(`[${e.config.event_attribute}='${v.id}']:not(.dhx_cal_select_menu):not(.dhx_drag_marker)`);
          if (y)
            for (let w = 0; w < y.length; w++) {
              let D = y[w].cloneNode(!0);
              const M = { event: { start_date: /* @__PURE__ */ new Date(+D.getAttribute("data-bar-start")), end_date: /* @__PURE__ */ new Date(+D.getAttribute("data-bar-end")) }, layout: g, viewName: c, sectionId: f, eventNode: D };
              u.push(d(M));
            }
          return u;
        }(l);
    }
    h.forEach((p) => {
      i.push(e.markTimespan(p));
    });
  }
  e.attachEvent("onBeforeDrag", function(l, _, h) {
    return a() && (t = !0, s = e.getEvent(l), n = h.target.closest(`[${e.config.event_attribute}]`), o(e.getState().mode) == "units" && e.config.cascade_event_display && (e.unselect(l), n = h.target.closest(`[${e.config.event_attribute}]`))), !0;
  }), e.attachEvent("onEventDrag", function(l, _, h) {
    if (t && a()) {
      t = !1;
      const p = e.getState().mode, v = o(p), g = e.getActionData(h).section;
      s && r({ event: s, layout: v, viewName: p, sectionId: g, eventNode: n });
    }
  }), e.attachEvent("onDragEnd", function(l, _, h) {
    for (let p = 0; p < i.length; p++)
      e.unmarkTimespan(i[p]);
    i = [], n = null, s = null;
  });
}
function At(e) {
  e.config.mark_now = !0, e.config.display_marked_timespans = !0, e.config.overwrite_marked_timespans = !0;
  var i = "dhx_time_block", t = "default", n = function(a, o, d) {
    var r = typeof a == "object" ? a : { days: a };
    return r.type = i, r.css = "", o && (d && (r.sections = d), r = function(l, _, h) {
      return _ instanceof Date && h instanceof Date ? (l.start_date = _, l.end_date = h) : (l.days = _, l.zones = h), l;
    }(r, a, o)), r;
  };
  function s(a, o, d, r, l) {
    var _ = e, h = [], p = { _props: "map_to", matrix: "y_property" };
    for (var v in p) {
      var g = p[v];
      if (_[v])
        for (var c in _[v]) {
          var f = _[v][c][g];
          a[f] && (h = _._add_timespan_zones(h, e._get_blocked_zones(o[c], a[f], d, r, l)));
        }
    }
    return h = _._add_timespan_zones(h, e._get_blocked_zones(o, "global", d, r, l));
  }
  e.blockTime = function(a, o, d) {
    var r = n(a, o, d);
    return e.addMarkedTimespan(r);
  }, e.unblockTime = function(a, o, d) {
    var r = n(a, o = o || "fullday", d);
    return e.deleteMarkedTimespan(r);
  }, e.checkInMarkedTimespan = function(a, o, d) {
    o = o || t;
    for (var r = !0, l = new Date(a.start_date.valueOf()), _ = e.date.add(l, 1, "day"), h = e._marked_timespans; l < a.end_date; l = e.date.date_part(_), _ = e.date.add(l, 1, "day")) {
      var p = +e.date.date_part(new Date(l)), v = s(a, h, l.getDay(), p, o);
      if (v)
        for (var g = 0; g < v.length; g += 2) {
          var c = e._get_zone_minutes(l), f = a.end_date > _ || a.end_date.getDate() != l.getDate() ? 1440 : e._get_zone_minutes(a.end_date), u = v[g], y = v[g + 1];
          if (u < f && y > c && !(r = typeof d == "function" && d(a, c, f, u, y)))
            break;
        }
    }
    return !r;
  }, e.checkLimitViolation = function(a) {
    if (!a || !e.config.check_limits)
      return !0;
    var o = e, d = o.config, r = [];
    if (a.rec_type && a._end_date || a.rrule) {
      const v = a._end_date || a.end_date;
      return !d.limit_start || !d.limit_end || v.valueOf() >= d.limit_start.valueOf() && a.start_date.valueOf() <= d.limit_end.valueOf();
    }
    r = [a];
    for (var l = !0, _ = 0; _ < r.length; _++) {
      var h = !0, p = r[_];
      p._timed = e.isOneDayEvent(p), (h = !d.limit_start || !d.limit_end || p.start_date.valueOf() >= d.limit_start.valueOf() && p.end_date.valueOf() <= d.limit_end.valueOf()) && (h = !e.checkInMarkedTimespan(p, i, function(v, g, c, f, u) {
        var y = !0;
        return g <= u && g >= f && ((u == 1440 || c <= u) && (y = !1), v._timed && o._drag_id && o._drag_mode == "new-size" ? (v.start_date.setHours(0), v.start_date.setMinutes(u)) : y = !1), (c >= f && c <= u || g < f && c > u) && (v._timed && o._drag_id && o._drag_mode == "new-size" ? (v.end_date.setHours(0), v.end_date.setMinutes(f)) : y = !1), y;
      })), h || (h = o.checkEvent("onLimitViolation") ? o.callEvent("onLimitViolation", [p.id, p]) : h), l = l && h;
    }
    return l || (o._drag_id = null, o._drag_mode = null), l;
  }, e._get_blocked_zones = function(a, o, d, r, l) {
    var _ = [];
    if (a && a[o])
      for (var h = a[o], p = this._get_relevant_blocked_zones(d, r, h, l), v = 0; v < p.length; v++)
        _ = this._add_timespan_zones(_, p[v].zones);
    return _;
  }, e._get_relevant_blocked_zones = function(a, o, d, r) {
    var l;
    return e.config.overwrite_marked_timespans ? l = d[o] && d[o][r] ? d[o][r] : d[a] && d[a][r] ? d[a][r] : [] : (l = [], d[o] && d[o][r] && (l = l.concat(d[o][r])), d[a] && d[a][r] && (l = l.concat(d[a][r]))), l;
  }, e._mark_now = function(a) {
    var o = "dhx_now_time";
    this._els[o] || (this._els[o] = []);
    var d = e._currentDate(), r = this.config;
    if (e._remove_mark_now(), !a && r.mark_now && d < this._max_date && d > this._min_date && d.getHours() >= r.first_hour && d.getHours() < r.last_hour) {
      var l = this.locate_holder_day(d);
      this._els[o] = e._append_mark_now(l, d);
    }
  }, e._append_mark_now = function(a, o) {
    var d = "dhx_now_time", r = e._get_zone_minutes(o), l = { zones: [r, r + 1], css: d, type: d };
    if (!this._table_view) {
      if (this._props && this._props[this._mode]) {
        var _, h, p = this._props[this._mode], v = p.size || p.options.length;
        p.days > 1 ? (p.size && p.options.length && (a = (p.position + a) / p.options.length * p.size), _ = a, h = a + v) : h = (_ = 0) + v;
        for (var g = [], c = _; c < h; c++) {
          var f = c;
          l.days = f;
          var u = e._render_marked_timespan(l, null, f)[0];
          g.push(u);
        }
        return g;
      }
      return l.days = a, e._render_marked_timespan(l, null, a);
    }
    if (this._mode == "month")
      return l.days = +e.date.date_part(o), e._render_marked_timespan(l, null, null);
  }, e._remove_mark_now = function() {
    for (var a = "dhx_now_time", o = this._els[a], d = 0; d < o.length; d++) {
      var r = o[d], l = r.parentNode;
      l && l.removeChild(r);
    }
    this._els[a] = [];
  }, e._marked_timespans = { global: {} }, e._get_zone_minutes = function(a) {
    return 60 * a.getHours() + a.getMinutes();
  }, e._prepare_timespan_options = function(a) {
    var o = [], d = [];
    if (a.days == "fullweek" && (a.days = [0, 1, 2, 3, 4, 5, 6]), a.days instanceof Array) {
      for (var r = a.days.slice(), l = 0; l < r.length; l++) {
        var _ = e._lame_clone(a);
        _.days = r[l], o.push.apply(o, e._prepare_timespan_options(_));
      }
      return o;
    }
    if (!a || !(a.start_date && a.end_date && a.end_date > a.start_date || a.days !== void 0 && a.zones) && !a.type)
      return o;
    a.zones == "fullday" && (a.zones = [0, 1440]), a.zones && a.invert_zones && (a.zones = e.invertZones(a.zones)), a.id = e.uid(), a.css = a.css || "", a.type = a.type || t;
    var h = a.sections;
    if (h) {
      for (var p in h)
        if (h.hasOwnProperty(p)) {
          var v = h[p];
          for (v instanceof Array || (v = [v]), l = 0; l < v.length; l++)
            (D = e._lame_copy({}, a)).sections = {}, D.sections[p] = v[l], d.push(D);
        }
    } else
      d.push(a);
    for (var g = 0; g < d.length; g++) {
      var c = d[g], f = c.start_date, u = c.end_date;
      if (f && u)
        for (var y = e.date.date_part(new Date(f)), w = e.date.add(y, 1, "day"); y < u; ) {
          var D;
          delete (D = e._lame_copy({}, c)).start_date, delete D.end_date, D.days = y.valueOf();
          var M = f > y ? e._get_zone_minutes(f) : 0, k = u > w || u.getDate() != y.getDate() ? 1440 : e._get_zone_minutes(u);
          D.zones = [M, k], o.push(D), y = w, w = e.date.add(w, 1, "day");
        }
      else
        c.days instanceof Date && (c.days = e.date.date_part(c.days).valueOf()), c.zones = a.zones.slice(), o.push(c);
    }
    return o;
  }, e._get_dates_by_index = function(a, o, d) {
    var r = [];
    o = e.date.date_part(new Date(o || e._min_date)), d = new Date(d || e._max_date);
    for (var l = o.getDay(), _ = a - l >= 0 ? a - l : 7 - o.getDay() + a, h = e.date.add(o, _, "day"); h < d; h = e.date.add(h, 1, "week"))
      r.push(h);
    return r;
  }, e._get_css_classes_by_config = function(a) {
    var o = [];
    return a.type == i && (o.push(i), a.css && o.push(i + "_reset")), o.push("dhx_marked_timespan", a.css), o.join(" ");
  }, e._get_block_by_config = function(a) {
    var o = document.createElement("div");
    if (a.html) {
      let d = a.html;
      typeof d == "function" && (d = d(a)), typeof d == "string" ? o.innerHTML = a.html : e.config.external_render && e.config.external_render.isElement(d) ? e.config.external_render.renderElement(d, o) : o.appendChild(d);
    }
    return o;
  }, e._render_marked_timespan = function(a, o, d) {
    var r = [], l = e.config, _ = this._min_date, h = this._max_date, p = !1;
    if (!l.display_marked_timespans)
      return r;
    if (!d && d !== 0) {
      if (a.days < 7)
        d = a.days;
      else {
        var v = new Date(a.days);
        if (p = +v, !(+h > +v && +_ <= +v))
          return r;
        d = v.getDay();
      }
      var g = _.getDay();
      g > d ? d = 7 - (g - d) : d -= g;
    }
    var c = a.zones, f = e._get_css_classes_by_config(a);
    if (e._table_view && e._mode == "month") {
      var u = [], y = [];
      if (o)
        u.push(o), y.push(d);
      else {
        y = p ? [p] : e._get_dates_by_index(d);
        for (var w = 0; w < y.length; w++)
          u.push(this._scales[y[w]]);
      }
      for (w = 0; w < u.length; w++) {
        o = u[w], d = y[w];
        var D = this.locate_holder_day(d, !1) % this._cols.length;
        if (!this._ignores[D]) {
          var M = e._get_block_by_config(a);
          M.className = f, M.style.top = "0px", M.style.height = "100%";
          for (var k = 0; k < c.length; k += 2) {
            var N = c[w];
            if ((E = c[w + 1]) <= N)
              return [];
            (S = M.cloneNode(!0)).style.left = "0px", S.style.width = "100%", o.appendChild(S), r.push(S);
          }
        }
      }
    } else {
      var m = d;
      if (this._ignores[this.locate_holder_day(d, !1)])
        return r;
      if (this._props && this._props[this._mode] && a.sections && a.sections[this._mode]) {
        var x = this._props[this._mode];
        m = x.order[a.sections[this._mode]];
        var b = x.order[a.sections[this._mode]];
        x.days > 1 ? m = m * (x.size || x.options.length) + b : (m = b, x.size && m > x.position + x.size && (m = 0));
      }
      for (o = o || e.locate_holder(m), w = 0; w < c.length; w += 2) {
        var E, S;
        if (N = Math.max(c[w], 60 * l.first_hour), (E = Math.min(c[w + 1], 60 * l.last_hour)) <= N) {
          if (w + 2 < c.length)
            continue;
          return [];
        }
        (S = e._get_block_by_config(a)).className = f;
        var T = 24 * this.config.hour_size_px + 1, C = 36e5;
        S.style.top = Math.round((60 * N * 1e3 - this.config.first_hour * C) * this.config.hour_size_px / C) % T + "px", S.style.height = Math.max(Math.round(60 * (E - N) * 1e3 * this.config.hour_size_px / C) % T, 1) + "px", o.appendChild(S), r.push(S);
      }
    }
    return r;
  }, e._mark_timespans = function() {
    var a = this._els.dhx_cal_data[0], o = [];
    if (e._table_view && e._mode == "month")
      for (var d in this._scales) {
        var r = /* @__PURE__ */ new Date(+d);
        o.push.apply(o, e._on_scale_add_marker(this._scales[d], r));
      }
    else {
      r = new Date(e._min_date);
      for (var l = 0, _ = a.childNodes.length; l < _; l++) {
        var h = a.childNodes[l];
        h.firstChild && e._getClassName(h.firstChild).indexOf("dhx_scale_hour") > -1 || (o.push.apply(o, e._on_scale_add_marker(h, r)), r = e.date.add(r, 1, "day"));
      }
    }
    return o;
  }, e.markTimespan = function(a) {
    if (!this._els)
      throw new Error("`scheduler.markTimespan` can't be used before scheduler initialization. Place `scheduler.markTimespan` call after `scheduler.init`.");
    var o = !1;
    this._els.dhx_cal_data || (e.get_elements(), o = !0);
    var d = e._marked_timespans_ids, r = e._marked_timespans_types, l = e._marked_timespans;
    e.deleteMarkedTimespan(), e.addMarkedTimespan(a);
    var _ = e._mark_timespans();
    return o && (e._els = []), e._marked_timespans_ids = d, e._marked_timespans_types = r, e._marked_timespans = l, _;
  }, e.unmarkTimespan = function(a) {
    if (a)
      for (var o = 0; o < a.length; o++) {
        var d = a[o];
        d.parentNode && d.parentNode.removeChild(d);
      }
  }, e._addMarkerTimespanConfig = function(a) {
    var o = "global", d = e._marked_timespans, r = a.id, l = e._marked_timespans_ids;
    l[r] || (l[r] = []);
    var _ = a.days, h = a.sections, p = a.type;
    if (a.id = r, h) {
      for (var v in h)
        if (h.hasOwnProperty(v)) {
          d[v] || (d[v] = {});
          var g = h[v], c = d[v];
          c[g] || (c[g] = {}), c[g][_] || (c[g][_] = {}), c[g][_][p] || (c[g][_][p] = [], e._marked_timespans_types || (e._marked_timespans_types = {}), e._marked_timespans_types[p] || (e._marked_timespans_types[p] = !0));
          var f = c[g][_][p];
          a._array = f, f.push(a), l[r].push(a);
        }
    } else
      d[o][_] || (d[o][_] = {}), d[o][_][p] || (d[o][_][p] = []), e._marked_timespans_types || (e._marked_timespans_types = {}), e._marked_timespans_types[p] || (e._marked_timespans_types[p] = !0), f = d[o][_][p], a._array = f, f.push(a), l[r].push(a);
  }, e._marked_timespans_ids = {}, e.addMarkedTimespan = function(a) {
    var o = e._prepare_timespan_options(a);
    if (o.length) {
      for (var d = o[0].id, r = 0; r < o.length; r++)
        e._addMarkerTimespanConfig(o[r]);
      return d;
    }
  }, e._add_timespan_zones = function(a, o) {
    var d = a.slice();
    if (o = o.slice(), !d.length)
      return o;
    for (var r = 0; r < d.length; r += 2)
      for (var l = d[r], _ = d[r + 1], h = r + 2 == d.length, p = 0; p < o.length; p += 2) {
        var v = o[p], g = o[p + 1];
        if (g > _ && v <= _ || v < l && g >= l)
          d[r] = Math.min(l, v), d[r + 1] = Math.max(_, g), r -= 2;
        else {
          if (!h)
            continue;
          var c = l > v ? 0 : 2;
          d.splice(r + c, 0, v, g);
        }
        o.splice(p--, 2);
        break;
      }
    return d;
  }, e._subtract_timespan_zones = function(a, o) {
    for (var d = a.slice(), r = 0; r < d.length; r += 2)
      for (var l = d[r], _ = d[r + 1], h = 0; h < o.length; h += 2) {
        var p = o[h], v = o[h + 1];
        if (v > l && p < _) {
          var g = !1;
          l >= p && _ <= v && d.splice(r, 2), l < p && (d.splice(r, 2, l, p), g = !0), _ > v && d.splice(g ? r + 2 : r, g ? 0 : 2, v, _), r -= 2;
          break;
        }
      }
    return d;
  }, e.invertZones = function(a) {
    return e._subtract_timespan_zones([0, 1440], a.slice());
  }, e._delete_marked_timespan_by_id = function(a) {
    var o = e._marked_timespans_ids[a];
    if (o) {
      for (var d = 0; d < o.length; d++)
        for (var r = o[d], l = r._array, _ = 0; _ < l.length; _++)
          if (l[_] == r) {
            l.splice(_, 1);
            break;
          }
    }
  }, e._delete_marked_timespan_by_config = function(a) {
    var o, d = e._marked_timespans, r = a.sections, l = a.days, _ = a.type || t;
    if (r) {
      for (var h in r)
        if (r.hasOwnProperty(h) && d[h]) {
          var p = r[h];
          d[h][p] && (o = d[h][p]);
        }
    } else
      o = d.global;
    if (o) {
      if (l !== void 0)
        o[l] && o[l][_] && (e._addMarkerTimespanConfig(a), e._delete_marked_timespans_list(o[l][_], a));
      else
        for (var v in o)
          if (o[v][_]) {
            var g = e._lame_clone(a);
            a.days = v, e._addMarkerTimespanConfig(g), e._delete_marked_timespans_list(o[v][_], a);
          }
    }
  }, e._delete_marked_timespans_list = function(a, o) {
    for (var d = 0; d < a.length; d++) {
      var r = a[d], l = e._subtract_timespan_zones(r.zones, o.zones);
      if (l.length)
        r.zones = l;
      else {
        a.splice(d, 1), d--;
        for (var _ = e._marked_timespans_ids[r.id], h = 0; h < _.length; h++)
          if (_[h] == r) {
            _.splice(h, 1);
            break;
          }
      }
    }
  }, e.deleteMarkedTimespan = function(a) {
    if (arguments.length || (e._marked_timespans = { global: {} }, e._marked_timespans_ids = {}, e._marked_timespans_types = {}), typeof a != "object")
      e._delete_marked_timespan_by_id(a);
    else {
      a.start_date && a.end_date || (a.days !== void 0 || a.type || (a.days = "fullweek"), a.zones || (a.zones = "fullday"));
      var o = [];
      if (a.type)
        o.push(a.type);
      else
        for (var d in e._marked_timespans_types)
          o.push(d);
      for (var r = e._prepare_timespan_options(a), l = 0; l < r.length; l++)
        for (var _ = r[l], h = 0; h < o.length; h++) {
          var p = e._lame_clone(_);
          p.type = o[h], e._delete_marked_timespan_by_config(p);
        }
    }
  }, e._get_types_to_render = function(a, o) {
    var d = a ? e._lame_copy({}, a) : {};
    for (var r in o || {})
      o.hasOwnProperty(r) && (d[r] = o[r]);
    return d;
  }, e._get_configs_to_render = function(a) {
    var o = [];
    for (var d in a)
      a.hasOwnProperty(d) && o.push.apply(o, a[d]);
    return o;
  }, e._on_scale_add_marker = function(a, o) {
    if (!e._table_view || e._mode == "month") {
      var d = o.getDay(), r = o.valueOf(), l = this._mode, _ = e._marked_timespans, h = [], p = [];
      if (this._props && this._props[l]) {
        var v = this._props[l], g = v.options, c = g[e._get_unit_index(v, o)];
        if (v.days > 1) {
          var f = Math.round((o - e._min_date) / 864e5), u = v.size || g.length;
          o = e.date.add(e._min_date, Math.floor(f / u), "day"), o = e.date.date_part(o);
        } else
          o = e.date.date_part(new Date(this._date));
        if (d = o.getDay(), r = o.valueOf(), _[l] && _[l][c.key]) {
          var y = _[l][c.key], w = e._get_types_to_render(y[d], y[r]);
          h.push.apply(h, e._get_configs_to_render(w));
        }
      }
      var D = _.global;
      if (e.config.overwrite_marked_timespans) {
        var M = D[r] || D[d];
        h.push.apply(h, e._get_configs_to_render(M));
      } else
        D[r] && h.push.apply(h, e._get_configs_to_render(D[r])), D[d] && h.push.apply(h, e._get_configs_to_render(D[d]));
      for (var k = 0; k < h.length; k++)
        p.push.apply(p, e._render_marked_timespan(h[k], a, o));
      return p;
    }
  }, e.attachEvent("onScaleAdd", function() {
    e._on_scale_add_marker.apply(e, arguments);
  }), e.dblclick_dhx_marked_timespan = function(a, o) {
    e.callEvent("onScaleDblClick", [e.getActionData(a).date, o, a]), e.config.dblclick_create && e.addEventNow(e.getActionData(a).date, null, a);
  };
}
function Ct(e) {
  var i = {}, t = !1;
  function n(r, l) {
    l = typeof l == "function" ? l : function() {
    }, i[r] || (i[r] = this[r], this[r] = l);
  }
  function s(r) {
    i[r] && (this[r] = i[r], i[r] = null);
  }
  function a(r) {
    for (var l in r)
      n.call(this, l, r[l]);
  }
  function o() {
    for (var r in i)
      s.call(this, r);
  }
  function d(r) {
    try {
      r();
    } catch (l) {
      window.console.error(l);
    }
  }
  return e.$stateProvider.registerProvider("batchUpdate", function() {
    return { batch_update: t };
  }, !1), function(r, l) {
    if (t)
      return void d(r);
    var _, h = this._dp && this._dp.updateMode != "off";
    h && (_ = this._dp.updateMode, this._dp.setUpdateMode("off"));
    const p = { setModeDate: { date: null, mode: null }, needRender: !1, needUpdateView: !1, repaintEvents: {} }, v = (c, f) => {
      c && (p.setModeDate.date = c), f && (p.setModeDate.mode = f);
    };
    var g = { render: (c, f) => {
      p.needRender = !0, v(c, f);
    }, setCurrentView: (c, f) => {
      p.needRender = !0, v(c, f);
    }, updateView: (c, f) => {
      p.needUpdateView = !0, v(c, f);
    }, render_data: () => p.needRender = !0, render_view_data: (c) => {
      c && c.length ? c.forEach((f) => p.repaintEvents[f.id] = !0) : p.needRender = !0;
    } };
    if (a.call(this, g), t = !0, this.callEvent("onBeforeBatchUpdate", []), d(r), this.callEvent("onAfterBatchUpdate", []), o.call(this), t = !1, !l)
      if (p.needRender)
        e.render(p.setModeDate.date, p.setModeDate.mode);
      else if (p.needUpdateView)
        e.updateView(p.setModeDate.date, p.setModeDate.mode);
      else
        for (const c in p.repaintEvents)
          e.updateEvent(c);
    h && (this._dp.setUpdateMode(_), this._dp.sendData());
  };
}
class Ot {
  constructor(i) {
    const { url: t, token: n } = i;
    this._url = t, this._token = n, this._mode = 1, this._seed = 1, this._queue = [], this.data = {}, this.api = {}, this._events = {};
  }
  headers() {
    return { Accept: "application/json", "Content-Type": "application/json", "Remote-Token": this._token };
  }
  fetch(i, t) {
    const n = { credentials: "include", headers: this.headers() };
    return t && (n.method = "POST", n.body = t), fetch(i, n).then((s) => s.json());
  }
  load(i) {
    return i && (this._url = i), this.fetch(this._url).then((t) => this.parse(t));
  }
  parse(i) {
    const { key: t, websocket: n } = i;
    t !== void 0 && (this._token = t);
    for (const s in i.data)
      this.data[s] = i.data[s];
    for (const s in i.api) {
      const a = this.api[s] = {}, o = i.api[s];
      for (const d in o)
        a[d] = this._wrapper(s + "." + d);
    }
    return n && this.connect(), this;
  }
  connect() {
    const i = this._socket;
    i && (this._socket = null, i.onclose = function() {
    }, i.close()), this._mode = 2, this._socket = function(t, n, s, a) {
      let o = n;
      o[0] === "/" && (o = document.location.protocol + "//" + document.location.host + n), o = o.replace(/^http(s|):/, "ws$1:");
      const d = o.indexOf("?") != -1 ? "&" : "?";
      o = `${o}${d}token=${s}&ws=1`;
      const r = new WebSocket(o);
      return r.onclose = () => setTimeout(() => t.connect(), 2e3), r.onmessage = (l) => {
        const _ = JSON.parse(l.data);
        switch (_.action) {
          case "result":
            t.result(_.body, []);
            break;
          case "event":
            t.fire(_.body.name, _.body.value);
            break;
          case "start":
            a();
            break;
          default:
            t.onError(_.data);
        }
      }, r;
    }(this, this._url, this._token, () => {
      this._mode = 3, this._send(), this._resubscribe();
    });
  }
  _wrapper(i) {
    return (function() {
      const t = [].slice.call(arguments);
      let n = null;
      const s = new Promise((a, o) => {
        n = { data: { id: this._uid(), name: i, args: t }, status: 1, resolve: a, reject: o }, this._queue.push(n);
      });
      return n && this.onCall(n, s), n && this._mode === 3 ? this._send(n) : setTimeout(() => this._send(), 1), s;
    }).bind(this);
  }
  _uid() {
    return (this._seed++).toString();
  }
  _send(i) {
    if (this._mode == 2)
      return void setTimeout(() => this._send(), 100);
    const t = i ? [i] : this._queue.filter((s) => s.status === 1);
    if (!t.length)
      return;
    const n = t.map((s) => (s.status = 2, s.data));
    this._mode !== 3 ? this.fetch(this._url, JSON.stringify(n)).catch((s) => this.onError(s)).then((s) => this.result(s, n)) : this._socket.send(JSON.stringify({ action: "call", body: n }));
  }
  result(i, t) {
    const n = {};
    if (i)
      for (let s = 0; s < i.length; s++)
        n[i[s].id] = i[s];
    else
      for (let s = 0; s < t.length; s++)
        n[t[s].id] = { id: t[s].id, error: "Network Error", data: null };
    for (let s = this._queue.length - 1; s >= 0; s--) {
      const a = this._queue[s], o = n[a.data.id];
      o && (this.onResponse(a, o), o.error ? a.reject(o.error) : a.resolve(o.data), this._queue.splice(s, 1));
    }
  }
  on(i, t) {
    const n = this._uid();
    let s = this._events[i];
    const a = !!s;
    return a || (s = this._events[i] = []), s.push({ id: n, handler: t }), a || this._mode != 3 || this._socket.send(JSON.stringify({ action: "subscribe", name: i })), { name: i, id: n };
  }
  _resubscribe() {
    if (this._mode == 3)
      for (const i in this._events)
        this._socket.send(JSON.stringify({ action: "subscribe", name: i }));
  }
  detach(i) {
    if (!i) {
      if (this._mode == 3)
        for (const a in this._events)
          this._socket.send(JSON.stringify({ action: "unsubscribe", key: a }));
      return void (this._events = {});
    }
    const { id: t, name: n } = i, s = this._events[n];
    if (s) {
      const a = s.filter((o) => o.id != t);
      a.length ? this._events[n] = a : (delete this._events[n], this._mode == 3 && this._socket.send(JSON.stringify({ action: "unsubscribe", name: n })));
    }
  }
  fire(i, t) {
    const n = this._events[i];
    if (n)
      for (let s = 0; s < n.length; s++)
        n[s].handler(t);
  }
  onError(i) {
    return null;
  }
  onCall(i, t) {
  }
  onResponse(i, t) {
  }
}
class Lt {
  constructor(i, t) {
    const n = new Ot({ url: i, token: t });
    n.fetch = function(s, a) {
      const o = { headers: this.headers() };
      return a && (o.method = "POST", o.body = a), fetch(s, o).then((d) => d.json());
    }, this._ready = n.load().then((s) => this._remote = s);
  }
  ready() {
    return this._ready;
  }
  on(i, t) {
    this.ready().then((n) => {
      if (typeof i == "string")
        n.on(i, t);
      else
        for (const s in i)
          n.on(s, i[s]);
    });
  }
}
function $t(e) {
  function i(n, s) {
    switch (n) {
      case "add-event":
        (function(a) {
          if (e.getEvent(a.id))
            return void console.warn(`Event with ID ${a.id} already exists. Skipping add.`);
          typeof a.start_date == "string" && (a.start_date = e.templates.parse_date(a.start_date)), typeof a.end_date == "string" && (a.end_date = e.templates.parse_date(a.end_date)), a.original_start && typeof a.original_start == "string" && (a.original_start = e.templates.parse_date(a.original_start)), t(() => {
            e.addEvent(a);
          });
        })(s);
        break;
      case "update-event":
        (function(a) {
          const o = a.id;
          if (!e.getEvent(o))
            return void console.warn(`Event with ID ${o} does not exist. Skipping update.`);
          const d = e.getEvent(o);
          t(() => {
            for (let r in a)
              r !== "start_date" && r !== "end_date" && (d[r] = a[r]);
            typeof a.start_date == "string" && (d.start_date = e.templates.parse_date(a.start_date)), typeof a.end_date == "string" && (d.end_date = e.templates.parse_date(a.end_date)), a.original_start && typeof a.original_start == "string" && (d.original_start = e.templates.parse_date(a.original_start)), e.callEvent("onEventChanged", [o, d]), e.updateEvent(o), o !== a.id && e.changeEventId(o, a.id);
          });
        })(s);
        break;
      case "delete-event":
        (function(a) {
          const o = a.id;
          if (!e.getEvent(o))
            return void ((a.event_pid || a.recurring_event_id) && t(() => {
              e.addEvent(a);
            }));
          t(() => {
            const d = e.getEvent(o);
            if (d) {
              if (d.rec_type || d.rrule) {
                e._roll_back_dates(d);
                const r = e._get_rec_markers(o);
                for (const l in r)
                  e.getEvent(l) && e.deleteEvent(l, !0);
              }
              if (e.getState().lightbox_id == o && (this._new_event = this._lightbox_id, a.id = this._lightbox_id, this._events[this._lightbox_id] = a, e.callEvent("onLiveUpdateCollision", [o, null, "delete", a]) === !1))
                return void e.endLightbox(!1, e._lightbox);
              e.deleteEvent(o, !0);
            }
          });
        })(s);
    }
  }
  function t(n) {
    e._dp ? e._dp.ignore(n) : n();
  }
  return { events: function(n) {
    if (!n || !n.event || !n.event.id)
      return void console.error("Invalid message format:", n);
    const { type: s, event: a } = n;
    if (!e._dp || !e._dp._in_progress[a.id]) {
      if (s === "add-event" && e._dp) {
        for (const o in e._dp._in_progress)
          if (e._dp.getState(o) === "inserted")
            return void e._dp.attachEvent("onFullSync", function() {
              e.getEvent(a.id) || i(s, a);
            }, { once: !0 });
      }
      i(s, a);
    }
  } };
}
function Ht(e) {
  (function(i) {
    const t = {};
    i.attachEvent("onConfirmedBeforeEventDelete", function(n) {
      return t[n] = !0, !0;
    }), i.attachEvent("onEventDeleted", function(n, s) {
      if (!t[n])
        return;
      delete t[n];
      let a = i.copy(s);
      i.config.undo_deleted && !i.getState().new_event && i.message({ text: `<div class="dhx_info_message">
                            <span class="undo_popup_text">Event deleted</span>
                            <button class="undo_button" data-deleted-event-id="${s.id}">Undo</button>
                        </div>`, expire: 1e4, type: "popup_after_delete", callback: function(o) {
        o.target.closest(`[data-deleted-event-id="${s.id}"]`) && (a.rrule && a.duration && (a.end_date = new Date(a.start_date.valueOf() + 1e3 * a.duration), i.addEvent(a)), i.addEvent(a), i.render());
      } });
    });
  })(e), Tt(e), At(e), function(i) {
    i.batchUpdate = Ct(i);
  }(e), function(i) {
    i.ext || (i.ext = {}), i.ext.liveUpdates = { RemoteEvents: Lt, remoteUpdates: $t(i) };
  }(e);
}
let zt = Date.now();
function Ae(e) {
  return !!(e && typeof e == "object" && e.getFullYear && e.getMonth && e.getDate);
}
const ne = { uid: function() {
  return zt++;
}, mixin: function(e, i, t) {
  const n = e, s = i;
  for (const a in s)
    (n[a] === void 0 || t) && (n[a] = s[a]);
  return e;
}, copy: function e(i) {
  let t;
  if (i && typeof i == "object")
    switch (!0) {
      case Ae(i):
        t = new Date(i);
        break;
      case (n = i, Array.isArray ? Array.isArray(n) : !!(n && typeof n == "object" && "length" in n && n.pop && n.push)):
        t = new Array(i.length);
        for (let s = 0; s < i.length; s++)
          t[s] = e(i[s]);
        break;
      case function(s) {
        return !(!s || typeof s != "object" || Function.prototype.toString.call(s.constructor) !== "function String() { [native code] }");
      }(i):
        t = new String(i);
        break;
      case function(s) {
        return !(!s || typeof s != "object" || Function.prototype.toString.call(s.constructor) !== "function Number() { [native code] }");
      }(i):
        t = new Number(i);
        break;
      case function(s) {
        return !(!s || typeof s != "object" || Function.prototype.toString.call(s.constructor) !== "function Boolean() { [native code] }");
      }(i):
        t = new Boolean(i);
        break;
      default:
        t = {};
        for (const s in i)
          if (Object.prototype.hasOwnProperty.call(i, s)) {
            const a = i[s], o = typeof a;
            o === "string" || o === "number" || o === "boolean" ? t[s] = a : Ae(a) ? t[s] = new Date(a) : t[s] = e(a);
          }
    }
  var n;
  return t || i;
}, defined: function(e) {
  return e !== void 0;
}, isDate: Ae, delay: function(e, i) {
  let t;
  const n = function(...s) {
    n.$cancelTimeout(), n.$pending = !0, t = setTimeout(function() {
      e.apply(this, s), n.$pending = !1;
    }, i);
  };
  return n.$pending = !1, n.$cancelTimeout = function() {
    clearTimeout(t), n.$pending = !1;
  }, n.$execute = function(...s) {
    e.apply(this, s), n.$cancelTimeout();
  }, n;
} };
function qt(e) {
  function i(g) {
    var c = document.createElement("div");
    return (g || "").split(" ").forEach(function(f) {
      c.classList.add(f);
    }), c;
  }
  var t = function() {
    return i("dhx_cal_navbar_rows_container");
  }, n = function() {
    return i("dhx_cal_navbar_row");
  }, s = function(g) {
    var c = i("dhx_cal_tab");
    return c.setAttribute("name", g.view + "_tab"), c.setAttribute("data-tab", g.view), e.config.fix_tab_position && (g.$firstTab ? c.classList.add("dhx_cal_tab_first") : g.$lastTab ? c.classList.add("dhx_cal_tab_last") : g.view !== "week" && c.classList.add("dhx_cal_tab_standalone"), g.$segmentedTab && c.classList.add("dhx_cal_tab_segmented")), c;
  }, a = function() {
    return i("dhx_cal_date");
  }, o = function(g) {
    return i("dhx_cal_nav_button dhx_cal_nav_button_custom dhx_cal_tab");
  }, d = function(g) {
    return i("dhx_cal_" + g.view + "_button dhx_cal_nav_button");
  }, r = function() {
    return i("dhx_cal_line_spacer");
  }, l = function(g) {
    var c = i("dhx_minical_icon");
    return g.click || c.$_eventAttached || e.event(c, "click", function() {
      e.isCalendarVisible() ? e.destroyCalendar() : e.renderCalendar({ position: this, date: e.getState().date, navigation: !0, handler: function(f, u) {
        e.setCurrentView(f), e.destroyCalendar();
      } });
    }), c;
  };
  function _(g) {
    var c = function(y) {
      var w;
      if (y.view)
        switch (y.view) {
          case "today":
          case "next":
          case "prev":
            w = d;
            break;
          case "date":
            w = a;
            break;
          case "spacer":
            w = r;
            break;
          case "button":
            w = o;
            break;
          case "minicalendar":
            w = l;
            break;
          default:
            w = s;
        }
      else
        y.rows ? w = t : y.cols && (w = n);
      return w;
    }(g);
    if (c) {
      var f = c(g);
      if (g.css && f.classList.add(g.css), g.width && ((u = g.width) === 1 * u && (u += "px"), f.style.width = u), g.height && ((u = g.height) === 1 * u && (u += "px"), f.style.height = u), g.click && e.event(f, "click", g.click), g.html && (f.innerHTML = g.html), g.align) {
        var u = "";
        g.align == "right" ? u = "flex-end" : g.align == "left" && (u = "flex-start"), f.style.justifyContent = u;
      }
      return f;
    }
  }
  function h(g) {
    return typeof g == "string" && (g = { view: g }), g.view || g.rows || g.cols || (g.view = "button"), g;
  }
  function p(g) {
    var c, f = document.createDocumentFragment();
    c = Array.isArray(g) ? g : [g];
    for (var u = 0; u < c.length; u++) {
      var y, w = h(c[u]);
      w.view === "day" && c[u + 1] && ((y = h(c[u + 1])).view !== "week" && y.view !== "month" || (w.$firstTab = !0, w.$segmentedTab = !0)), w.view === "week" && c[u - 1] && ((y = h(c[u + 1])).view !== "week" && y.view !== "month" || (w.$segmentedTab = !0)), w.view === "month" && c[u - 1] && ((y = h(c[u - 1])).view !== "week" && y.view !== "day" || (w.$lastTab = !0, w.$segmentedTab = !0));
      var D = _(w);
      f.appendChild(D), (w.cols || w.rows) && D.appendChild(p(w.cols || w.rows));
    }
    return f;
  }
  e._init_nav_bar = function(g) {
    var c = this.$container.querySelector(".dhx_cal_navline");
    return c || ((c = document.createElement("div")).className = "dhx_cal_navline dhx_cal_navline_flex", e._update_nav_bar(g, c), c);
  };
  var v = null;
  e._update_nav_bar = function(g, c) {
    if (g) {
      var f = !1, u = g.height || e.xy.nav_height;
      v !== null && v === u || (f = !0), f && (e.xy.nav_height = u), c.innerHTML = "", c.appendChild(p(g)), e.unset_actions(), e._els = [], e.get_elements(), e.set_actions(), c.style.display = u === 0 ? "none" : "", v = u;
    }
  };
}
function jt(e) {
  function i(a) {
    return a.isConnected !== void 0 ? a.isConnected : document.body.contains(a);
  }
  function t(a) {
    return { w: a.innerWidth || document.documentElement.clientWidth, h: a.innerHeight || document.documentElement.clientHeight };
  }
  function n(a, o) {
    var d, r = t(o);
    a.event(o, "resize", function() {
      clearTimeout(d), d = setTimeout(function() {
        if (i(a.$container) && !a.$destroyed) {
          var l, _, h = t(o);
          _ = h, ((l = r).w != _.w || l.h != _.h) && (r = h, s(a));
        }
      }, 150);
    });
  }
  function s(a) {
    a.$initialized && !a.$destroyed && a.$root && i(a.$root) && a.callEvent("onSchedulerResize", []) && (a.updateView(), a.callEvent("onAfterSchedulerResize", []));
  }
  (function(a) {
    var o = a.$container;
    if (window.getComputedStyle(o).getPropertyValue("position") == "static" && (o.style.position = "relative"), window.ResizeObserver) {
      let r = !0;
      const l = new ResizeObserver(function(_) {
        r ? r = !1 : s(a);
      });
      l.observe(o), a.attachEvent("onDestroy", function() {
        l.unobserve(o);
      });
    } else {
      var d = document.createElement("iframe");
      d.className = "scheduler_container_resize_watcher", d.tabIndex = -1, a.config.wai_aria_attributes && (d.setAttribute("role", "none"), d.setAttribute("aria-hidden", !0)), window.Sfdc || window.$A || window.Aura ? function(r) {
        var l = r.$root.offsetHeight, _ = r.$root.offsetWidth;
        (function h() {
          r.$destroyed || (r.$root && (r.$root.offsetHeight == l && r.$root.offsetWidth == _ || s(r), l = r.$root.offsetHeight, _ = r.$root.offsetWidth), setTimeout(h, 200));
        })();
      }(a) : (o.appendChild(d), d.contentWindow ? n(a, d.contentWindow) : (o.removeChild(d), n(a, window)));
    }
  })(e);
}
class It {
  constructor() {
    this._silent_mode = !1, this.listeners = {};
  }
  _silentStart() {
    this._silent_mode = !0;
  }
  _silentEnd() {
    this._silent_mode = !1;
  }
}
function Ye(e) {
  const i = new It();
  e.attachEvent = function(t, n, s) {
    t = "ev_" + t.toLowerCase(), i.listeners[t] || (i.listeners[t] = function(o) {
      let d = {}, r = 0;
      const l = function(..._) {
        let h = !0;
        for (const p in d) {
          const v = d[p].apply(o, _);
          h = h && v;
        }
        return h;
      };
      return l.addEvent = function(_, h) {
        if (typeof _ == "function") {
          let p;
          if (h && h.id ? p = h.id : (p = r, r++), h && h.once) {
            const v = _;
            _ = function() {
              v(), l.removeEvent(p);
            };
          }
          return d[p] = _, p;
        }
        return !1;
      }, l.removeEvent = function(_) {
        delete d[_];
      }, l.clear = function() {
        d = {};
      }, l;
    }(this)), s && s.thisObject && (n = n.bind(s.thisObject));
    let a = t + ":" + i.listeners[t].addEvent(n, s);
    return s && s.id && (a = s.id), a;
  }, e.attachAll = function(t) {
    this.attachEvent("listen_all", t);
  }, e.callEvent = function(t, n) {
    if (i._silent_mode)
      return !0;
    const s = "ev_" + t.toLowerCase(), a = i.listeners;
    return a.ev_listen_all && a.ev_listen_all.apply(this, [t].concat(n)), !a[s] || a[s].apply(this, n);
  }, e.checkEvent = function(t) {
    return !!i.listeners["ev_" + t.toLowerCase()];
  }, e.detachEvent = function(t) {
    if (t) {
      let n = i.listeners;
      for (const a in n)
        n[a].removeEvent(t);
      const s = String(t).split(":");
      if (n = i.listeners, s.length === 2) {
        const a = s[0], o = s[1];
        n[a] && n[a].removeEvent(o);
      }
    }
  }, e.detachAllEvents = function() {
    for (const t in i.listeners)
      i.listeners[t].clear();
  };
}
const Pt = function(e, i, t) {
  e.addEventListener ? e.addEventListener(i, t, !1) : e.attachEvent && e.attachEvent("on" + i, t);
}, Rt = function(e, i, t) {
  e.removeEventListener ? e.removeEventListener(i, t, !1) : e.detachEvent && e.detachEvent("on" + i, t);
};
function Ut(e) {
  var i = function() {
    const t = (n = Pt, s = Rt) => {
      const a = [], o = { attach(d, r, l, _) {
        a.push({ element: d, event: r, callback: l, capture: _ }), n(d, r, l, _);
      }, detach(d, r, l, _) {
        s(d, r, l, _);
        for (let h = 0; h < a.length; h++) {
          const p = a[h];
          p.element === d && p.event === r && p.callback === l && p.capture === _ && (a.splice(h, 1), h--);
        }
      }, detachAll() {
        const d = a.slice();
        for (let r = 0; r < d.length; r++) {
          const l = d[r];
          o.detach(l.element, l.event, l.callback, l.capture), o.detach(l.element, l.event, l.callback, void 0), o.detach(l.element, l.event, l.callback, !1), o.detach(l.element, l.event, l.callback, !0);
        }
        a.splice(0, a.length);
      }, extend() {
        return t(this.event, this.eventRemove);
      } };
      return o;
    };
    return t();
  }();
  e.event = i.attach, e.eventRemove = i.detach, e._eventRemoveAll = i.detachAll, e._createDomEventScope = i.extend, e._trim = function(t) {
    return (String.prototype.trim || function() {
      return this.replace(/^\s+|\s+$/g, "");
    }).apply(t);
  }, e._isDate = function(t) {
    return !(!t || typeof t != "object") && !!(t.getFullYear && t.getMonth && t.getDate);
  }, e._isObject = function(t) {
    return t && typeof t == "object";
  };
}
function We(e) {
  let i = 0, t = 0, n = 0, s = 0;
  const a = e;
  if (e.getBoundingClientRect) {
    const o = e.getBoundingClientRect(), d = document.body, r = document.documentElement || document.body.parentNode || document.body, l = window.pageYOffset || r.scrollTop || d.scrollTop, _ = window.pageXOffset || r.scrollLeft || d.scrollLeft, h = r.clientTop || d.clientTop || 0, p = r.clientLeft || d.clientLeft || 0;
    i = o.top + l - h, t = o.left + _ - p, n = document.body.offsetWidth - o.right, s = document.body.offsetHeight - o.bottom;
  } else {
    let o = e;
    for (; o; )
      i += parseInt(String(o.offsetTop), 10), t += parseInt(String(o.offsetLeft), 10), o = o.offsetParent;
    n = document.body.offsetWidth - a.offsetWidth - t, s = document.body.offsetHeight - a.offsetHeight - i;
  }
  return { y: Math.round(i), x: Math.round(t), width: a.offsetWidth, height: a.offsetHeight, right: Math.round(n), bottom: Math.round(s) };
}
function ft(e) {
  if (!e)
    return "";
  let i = e.className || "";
  return typeof i != "string" && e.className.baseVal && (i = e.className.baseVal), typeof i == "string" && i.indexOf || (i = ""), i || "";
}
function pt(e, i, t = !0) {
  let n = e.target || ("srcElement" in e ? e.srcElement : null);
  for (; n; ) {
    const s = ft(n);
    if (s) {
      const a = s.indexOf(i);
      if (a >= 0) {
        if (!t)
          return n;
        const o = a === 0 || !(s.charAt(a - 1) || "").trim(), d = a + i.length >= s.length || !s.charAt(a + i.length).trim();
        if (o && d)
          return n;
      }
    }
    n = n.parentNode;
  }
  return null;
}
function Yt(e) {
  let i = !1, t = !1;
  if (window.getComputedStyle) {
    const a = window.getComputedStyle(e, null);
    i = a.display, t = a.visibility;
  } else
    e.currentStyle && (i = e.currentStyle.display, t = e.currentStyle.visibility);
  let n = !1;
  const s = pt({ target: e }, "dhx_form_repeat", !1);
  return s && (n = s.style.height === "0px"), n = n || !e.offsetHeight, i !== "none" && t !== "hidden" && !n;
}
function Vt(e) {
  const i = e.getAttribute("tabindex");
  return i !== null && !Number.isNaN(Number(i)) && Number(i) >= 0;
}
function Ft(e) {
  return !{ a: !0, area: !0 }[e.nodeName.toLowerCase()] || !!e.getAttribute("href");
}
function Bt(e) {
  return !{ input: !0, select: !0, textarea: !0, button: !0, object: !0 }[e.nodeName.toLowerCase()] || !e.hasAttribute("disabled");
}
function gt() {
  const e = document.head;
  return !(!e.createShadowRoot && !e.attachShadow);
}
function Ke(e) {
  if (!e || !gt())
    return document.body;
  let i = e;
  for (; i.parentNode; )
    if (i = i.parentNode, i instanceof ShadowRoot)
      return i.host;
  return document.body;
}
const he = { getAbsoluteLeft(e) {
  return this.getOffset(e).left + (parseInt(window.getComputedStyle(e).paddingLeft, 10) || 0);
}, getAbsoluteTop(e) {
  return this.getOffset(e).top + (parseInt(window.getComputedStyle(e).paddingTop, 10) || 0);
}, getOffsetSum(e) {
  let i = 0, t = 0, n = e;
  for (; n; )
    i += parseInt(String(n.offsetTop), 10), t += parseInt(String(n.offsetLeft), 10), n = n.offsetParent;
  return { top: i, left: t };
}, getOffsetRect(e) {
  var s;
  const i = e.getBoundingClientRect();
  let t = 0, n = 0;
  if (/Mobi/.test(navigator.userAgent)) {
    const a = document.createElement("div");
    a.style.position = "absolute", a.style.left = "0px", a.style.top = "0px", a.style.width = "1px", a.style.height = "1px", document.body.appendChild(a);
    const o = a.getBoundingClientRect();
    t = i.top - o.top, n = i.left - o.left, (s = a.parentNode) == null || s.removeChild(a);
  } else {
    const a = document.body, o = document.documentElement, d = window.pageYOffset || o.scrollTop || a.scrollTop, r = window.pageXOffset || o.scrollLeft || a.scrollLeft, l = o.clientTop || a.clientTop || 0, _ = o.clientLeft || a.clientLeft || 0;
    t = i.top + d - l, n = i.left + r - _;
  }
  return { top: Math.round(t), left: Math.round(n) };
}, getOffset(e) {
  return this.getOffsetSum(e);
}, closest: (e, i) => e && i ? function(t, n) {
  if (typeof t.closest == "function")
    return t.closest(n);
  let s = t;
  if (!document.documentElement.contains(s))
    return null;
  do {
    const a = s, o = a.matches || a.msMatchesSelector || a.webkitMatchesSelector;
    if (o != null && o.call(s, n))
      return s;
    s = s.parentElement || s.parentNode;
  } while (s !== null && s.nodeType === 1);
  return console.error("Your browser is not supported"), null;
}(e, i) : null, insertAfter(e, i) {
  i.parentNode && (i.nextSibling ? i.parentNode.insertBefore(e, i.nextSibling) : i.parentNode.appendChild(e));
}, remove(e) {
  e != null && e.parentNode && e.parentNode.removeChild(e);
}, isChildOf: (e, i) => i.contains(e), getFocusableNodes: function(e) {
  const i = e.querySelectorAll(["a[href]", "area[href]", "input", "select", "textarea", "button", "iframe", "object", "embed", "[tabindex]", "[contenteditable]"].join(", ")), t = Array.from(i);
  for (let n = 0; n < t.length; n++)
    t[n].$position = n;
  t.sort((n, s) => n.tabIndex === 0 && s.tabIndex !== 0 ? 1 : n.tabIndex !== 0 && s.tabIndex === 0 ? -1 : n.tabIndex === s.tabIndex ? (n.$position || 0) - (s.$position || 0) : n.tabIndex < s.tabIndex ? -1 : 1);
  for (let n = 0; n < t.length; n++) {
    const s = t[n];
    (Vt(s) || Bt(s) || Ft(s)) && Yt(s) || (t.splice(n, 1), n--);
  }
  return t;
}, getClassName: ft, locateCss: pt, getRootNode: Ke, hasShadowParent: function(e) {
  return !!Ke(e);
}, isShadowDomSupported: gt, getActiveElement: function() {
  var i, t;
  let e = document.activeElement;
  return e != null && e.shadowRoot && (e = ((i = e.shadowRoot) == null ? void 0 : i.activeElement) || e), e === document.body && document.getSelection && (e = ((t = document.getSelection()) == null ? void 0 : t.focusNode) || document.body), e;
}, getRelativeEventPosition: function(e, i) {
  const t = document.documentElement, n = We(i);
  return { x: e.clientX - t.clientLeft - n.x + i.scrollLeft, y: e.clientY - t.clientTop - n.y + i.scrollTop };
}, getTargetNode: function(e) {
  let i;
  if ("tagName" in e)
    i = e;
  else {
    const t = e || window.event;
    i = t.target || t.srcElement, i != null && i.shadowRoot && t.composedPath && (i = t.composedPath()[0]);
  }
  return i;
}, getNodePosition: function(e) {
  return We(e);
} }, mt = typeof window < "u", se = mt && typeof navigator < "u" ? navigator.userAgent : "", Jt = { isIE: se.includes("MSIE") || se.includes("Trident"), isOpera: se.includes("Opera"), isChrome: se.includes("Chrome"), isKHTML: se.includes("Safari") || se.includes("Konqueror"), isFF: se.includes("Firefox"), isIPad: /iPad/i.test(se), isEdge: se.includes("Edge"), isNode: !mt || typeof navigator > "u" };
function vt(e) {
  if (typeof e == "string")
    return e;
  if (typeof e == "number")
    return String(e);
  var i = "";
  for (var t in e) {
    var n = "";
    e.hasOwnProperty(t) && (n = t + "=" + (n = typeof e[t] == "string" ? encodeURIComponent(e[t]) : typeof e[t] == "number" ? e[t] : encodeURIComponent(JSON.stringify(e[t]))), i.length && (n = "&" + n), i += n);
  }
  return i;
}
function Ge(e) {
  return e ? typeof e == "string" ? e : vt(e) : "";
}
function ve(e, i) {
  const t = Array.from(i);
  if (t.length === 0)
    throw new Error("Arguments list of query is wrong.");
  const n = { method: e, url: "" };
  if (t.length === 1) {
    const s = t[0];
    return typeof s == "string" ? (n.url = s, n.async = !0) : (n.url = s.url, n.async = s.async ?? !0, n.callback = s.callback, n.headers = s.headers), e !== "POST" && e !== "PUT" || (n.data = Ge(s.data)), n;
  }
  switch (n.url = t[0], e) {
    case "GET":
    case "DELETE":
      n.callback = t[1], n.headers = t[2];
      break;
    case "POST":
    case "PUT":
      n.data = Ge(t[1]), n.callback = t[2], n.headers = t[3];
  }
  return n;
}
function Wt(e) {
  var i = function(a, o) {
    for (var d = "var temp=date.match(/[a-zA-Z]+|[0-9]+/g);", r = a.match(/%[a-zA-Z]/g), l = 0; l < r.length; l++)
      switch (r[l]) {
        case "%j":
        case "%d":
          d += "set[2]=temp[" + l + "]||1;";
          break;
        case "%n":
        case "%m":
          d += "set[1]=(temp[" + l + "]||1)-1;";
          break;
        case "%y":
          d += "set[0]=temp[" + l + "]*1+(temp[" + l + "]>50?1900:2000);";
          break;
        case "%g":
        case "%G":
        case "%h":
        case "%H":
          d += "set[3]=temp[" + l + "]||0;";
          break;
        case "%i":
          d += "set[4]=temp[" + l + "]||0;";
          break;
        case "%Y":
          d += "set[0]=temp[" + l + "]||0;";
          break;
        case "%a":
        case "%A":
          d += "set[3]=set[3]%12+((temp[" + l + "]||'').toLowerCase()=='am'?0:12);";
          break;
        case "%s":
          d += "set[5]=temp[" + l + "]||0;";
          break;
        case "%M":
          d += "set[1]=this.locale.date.month_short_hash[temp[" + l + "]]||0;";
          break;
        case "%F":
          d += "set[1]=this.locale.date.month_full_hash[temp[" + l + "]]||0;";
      }
    var _ = "set[0],set[1],set[2],set[3],set[4],set[5]";
    return o && (_ = " Date.UTC(" + _ + ")"), new Function("date", "var set=[0,0,1,0,0,0]; " + d + " return new Date(" + _ + ");");
  }, t = function(a, o) {
    const d = a.match(/%[a-zA-Z]/g);
    return function(r) {
      for (var l = [0, 0, 1, 0, 0, 0], _ = r.match(/[a-zA-Z]+|[0-9]+/g), h = 0; h < d.length; h++)
        switch (d[h]) {
          case "%j":
          case "%d":
            l[2] = _[h] || 1;
            break;
          case "%n":
          case "%m":
            l[1] = (_[h] || 1) - 1;
            break;
          case "%y":
            l[0] = 1 * _[h] + (_[h] > 50 ? 1900 : 2e3);
            break;
          case "%g":
          case "%G":
          case "%h":
          case "%H":
            l[3] = _[h] || 0;
            break;
          case "%i":
            l[4] = _[h] || 0;
            break;
          case "%Y":
            l[0] = _[h] || 0;
            break;
          case "%a":
          case "%A":
            l[3] = l[3] % 12 + ((_[h] || "").toLowerCase() == "am" ? 0 : 12);
            break;
          case "%s":
            l[5] = _[h] || 0;
            break;
          case "%M":
            l[1] = e.locale.date.month_short_hash[_[h]] || 0;
            break;
          case "%F":
            l[1] = e.locale.date.month_full_hash[_[h]] || 0;
        }
      return o ? new Date(Date.UTC(l[0], l[1], l[2], l[3], l[4], l[5])) : new Date(l[0], l[1], l[2], l[3], l[4], l[5]);
    };
  };
  let n;
  function s() {
    var a = !1;
    return e.config.csp === "auto" ? (n === void 0 && (n = function() {
      try {
        new Function("cspEnabled = false;"), n = !1;
      } catch {
        n = !0;
      }
      return n;
    }()), a = n) : a = e.config.csp, a;
  }
  e.date = { init: function() {
    for (var a = e.locale.date.month_short, o = e.locale.date.month_short_hash = {}, d = 0; d < a.length; d++)
      o[a[d]] = d;
    for (a = e.locale.date.month_full, o = e.locale.date.month_full_hash = {}, d = 0; d < a.length; d++)
      o[a[d]] = d;
  }, date_part: function(a) {
    const o = new Date(a);
    var d = new Date(o);
    return o.setHours(0), o.setMinutes(0), o.setSeconds(0), o.setMilliseconds(0), o.getHours() && (o.getDate() < d.getDate() || o.getMonth() < d.getMonth() || o.getFullYear() < d.getFullYear()) && o.setTime(o.getTime() + 36e5 * (24 - o.getHours())), o;
  }, time_part: function(a) {
    return (a.valueOf() / 1e3 - 60 * a.getTimezoneOffset()) % 86400;
  }, week_start: function(a) {
    var o = a.getDay();
    return e.config.start_on_monday && (o === 0 ? o = 6 : o--), this.date_part(this.add(a, -1 * o, "day"));
  }, month_start: function(a) {
    const o = new Date(a);
    return o.setDate(1), this.date_part(o);
  }, year_start: function(a) {
    const o = new Date(a);
    return o.setMonth(0), this.month_start(o);
  }, day_start: function(a) {
    const o = new Date(a);
    return this.date_part(o);
  }, _add_days: function(a, o) {
    var d = new Date(a.valueOf());
    if (d.setDate(d.getDate() + o), o == Math.round(o) && o > 0) {
      var r = (+d - +a) % 864e5;
      if (r && a.getTimezoneOffset() == d.getTimezoneOffset()) {
        var l = r / 36e5;
        d.setTime(d.getTime() + 60 * (24 - l) * 60 * 1e3);
      }
    }
    return o >= 0 && !a.getHours() && d.getHours() && (d.getDate() < a.getDate() || d.getMonth() < a.getMonth() || d.getFullYear() < a.getFullYear()) && d.setTime(d.getTime() + 36e5 * (24 - d.getHours())), d;
  }, add: function(a, o, d) {
    var r = new Date(a.valueOf());
    switch (d) {
      case "day":
        r = e.date._add_days(r, o);
        break;
      case "week":
        r = e.date._add_days(r, 7 * o);
        break;
      case "month":
        r.setMonth(r.getMonth() + o);
        break;
      case "year":
        r.setYear(r.getFullYear() + o);
        break;
      case "hour":
        r.setTime(r.getTime() + 60 * o * 60 * 1e3);
        break;
      case "minute":
        r.setTime(r.getTime() + 60 * o * 1e3);
        break;
      default:
        return e.date["add_" + d](a, o, d);
    }
    return r;
  }, to_fixed: function(a) {
    return a < 10 ? "0" + a : a;
  }, copy: function(a) {
    return new Date(a.valueOf());
  }, date_to_str: function(a, o) {
    return s() ? function(d, r) {
      return function(l) {
        return d.replace(/%[a-zA-Z]/g, function(_) {
          switch (_) {
            case "%d":
              return r ? e.date.to_fixed(l.getUTCDate()) : e.date.to_fixed(l.getDate());
            case "%m":
              return r ? e.date.to_fixed(l.getUTCMonth() + 1) : e.date.to_fixed(l.getMonth() + 1);
            case "%j":
              return r ? l.getUTCDate() : l.getDate();
            case "%n":
              return r ? l.getUTCMonth() + 1 : l.getMonth() + 1;
            case "%y":
              return r ? e.date.to_fixed(l.getUTCFullYear() % 100) : e.date.to_fixed(l.getFullYear() % 100);
            case "%Y":
              return r ? l.getUTCFullYear() : l.getFullYear();
            case "%D":
              return r ? e.locale.date.day_short[l.getUTCDay()] : e.locale.date.day_short[l.getDay()];
            case "%l":
              return r ? e.locale.date.day_full[l.getUTCDay()] : e.locale.date.day_full[l.getDay()];
            case "%M":
              return r ? e.locale.date.month_short[l.getUTCMonth()] : e.locale.date.month_short[l.getMonth()];
            case "%F":
              return r ? e.locale.date.month_full[l.getUTCMonth()] : e.locale.date.month_full[l.getMonth()];
            case "%h":
              return r ? e.date.to_fixed((l.getUTCHours() + 11) % 12 + 1) : e.date.to_fixed((l.getHours() + 11) % 12 + 1);
            case "%g":
              return r ? (l.getUTCHours() + 11) % 12 + 1 : (l.getHours() + 11) % 12 + 1;
            case "%G":
              return r ? l.getUTCHours() : l.getHours();
            case "%H":
              return r ? e.date.to_fixed(l.getUTCHours()) : e.date.to_fixed(l.getHours());
            case "%i":
              return r ? e.date.to_fixed(l.getUTCMinutes()) : e.date.to_fixed(l.getMinutes());
            case "%a":
              return r ? l.getUTCHours() > 11 ? "pm" : "am" : l.getHours() > 11 ? "pm" : "am";
            case "%A":
              return r ? l.getUTCHours() > 11 ? "PM" : "AM" : l.getHours() > 11 ? "PM" : "AM";
            case "%s":
              return r ? e.date.to_fixed(l.getUTCSeconds()) : e.date.to_fixed(l.getSeconds());
            case "%W":
              return r ? e.date.to_fixed(e.date.getUTCISOWeek(l)) : e.date.to_fixed(e.date.getISOWeek(l));
            default:
              return _;
          }
        });
      };
    }(a, o) : (a = a.replace(/%[a-zA-Z]/g, function(d) {
      switch (d) {
        case "%d":
          return '"+this.date.to_fixed(date.getDate())+"';
        case "%m":
          return '"+this.date.to_fixed((date.getMonth()+1))+"';
        case "%j":
          return '"+date.getDate()+"';
        case "%n":
          return '"+(date.getMonth()+1)+"';
        case "%y":
          return '"+this.date.to_fixed(date.getFullYear()%100)+"';
        case "%Y":
          return '"+date.getFullYear()+"';
        case "%D":
          return '"+this.locale.date.day_short[date.getDay()]+"';
        case "%l":
          return '"+this.locale.date.day_full[date.getDay()]+"';
        case "%M":
          return '"+this.locale.date.month_short[date.getMonth()]+"';
        case "%F":
          return '"+this.locale.date.month_full[date.getMonth()]+"';
        case "%h":
          return '"+this.date.to_fixed((date.getHours()+11)%12+1)+"';
        case "%g":
          return '"+((date.getHours()+11)%12+1)+"';
        case "%G":
          return '"+date.getHours()+"';
        case "%H":
          return '"+this.date.to_fixed(date.getHours())+"';
        case "%i":
          return '"+this.date.to_fixed(date.getMinutes())+"';
        case "%a":
          return '"+(date.getHours()>11?"pm":"am")+"';
        case "%A":
          return '"+(date.getHours()>11?"PM":"AM")+"';
        case "%s":
          return '"+this.date.to_fixed(date.getSeconds())+"';
        case "%W":
          return '"+this.date.to_fixed(this.date.getISOWeek(date))+"';
        default:
          return d;
      }
    }), o && (a = a.replace(/date\.get/g, "date.getUTC")), new Function("date", 'return "' + a + '";').bind(e));
  }, str_to_date: function(a, o, d) {
    var r = s() ? t : i, l = r(a, o), _ = /^[0-9]{4}(\-|\/)[0-9]{2}(\-|\/)[0-9]{2} ?(([0-9]{1,2}:[0-9]{1,2})(:[0-9]{1,2})?)?$/, h = /^[0-9]{2}\/[0-9]{2}\/[0-9]{4} ?(([0-9]{1,2}:[0-9]{2})(:[0-9]{1,2})?)?$/, p = /^[0-9]{2}\-[0-9]{2}\-[0-9]{4} ?(([0-9]{1,2}:[0-9]{1,2})(:[0-9]{1,2})?)?$/, v = /^([\+-]?\d{4}(?!\d{2}\b))((-?)((0[1-9]|1[0-2])(\3([12]\d|0[1-9]|3[01]))?|W([0-4]\d|5[0-2])(-?[1-7])?|(00[1-9]|0[1-9]\d|[12]\d{2}|3([0-5]\d|6[1-6])))([T\s]((([01]\d|2[0-3])((:?)[0-5]\d)?|24\:?00)([\.,]\d+(?!:))?)?(\17[0-5]\d([\.,]\d+)?)?([zZ]|([\+-])([01]\d|2[0-3]):?([0-5]\d)?)?)?)?$/, g = r("%Y-%m-%d %H:%i:%s", o), c = r("%m/%d/%Y %H:%i:%s", o), f = r("%d-%m-%Y %H:%i:%s", o);
    return function(u) {
      if (!d && !e.config.parse_exact_format) {
        if (u && u.getISOWeek)
          return new Date(u);
        if (typeof u == "number")
          return new Date(u);
        if (y = u, _.test(String(y)))
          return g(u);
        if (function(w) {
          return h.test(String(w));
        }(u))
          return c(u);
        if (function(w) {
          return p.test(String(w));
        }(u))
          return f(u);
        if (function(w) {
          return v.test(w);
        }(u))
          return new Date(u);
      }
      var y;
      return l.call(e, u);
    };
  }, getISOWeek: function(a) {
    if (!a)
      return !1;
    var o = (a = this.date_part(new Date(a))).getDay();
    o === 0 && (o = 7);
    var d = new Date(a.valueOf());
    d.setDate(a.getDate() + (4 - o));
    var r = d.getFullYear(), l = Math.round((d.getTime() - new Date(r, 0, 1).getTime()) / 864e5);
    return 1 + Math.floor(l / 7);
  }, getUTCISOWeek: function(a) {
    return this.getISOWeek(this.convert_to_utc(a));
  }, convert_to_utc: function(a) {
    return new Date(a.getUTCFullYear(), a.getUTCMonth(), a.getUTCDate(), a.getUTCHours(), a.getUTCMinutes(), a.getUTCSeconds());
  } };
}
const Kt = [];
function Gt(e) {
  let i = null, t = null, n = 0, s = null;
  function a(r) {
    return r.getAttribute(e.config.event_attribute);
  }
  function o(r) {
    const l = a(r);
    if (l === null)
      return;
    const _ = i.get(l);
    _ ? _.push(r) : i.set(l, [r]);
  }
  function d() {
    s = n > 0 ? t[n - 1] : null;
  }
  return { sync() {
    const r = e._rendered;
    if (i === null || t !== r || r.length < n || n > 0 && r[n - 1] !== s)
      (function(l) {
        i = /* @__PURE__ */ new Map(), t = l, n = l.length;
        for (let _ = 0; _ < l.length; _++)
          o(l[_]);
        d();
      })(r);
    else if (n !== r.length) {
      for (; n < r.length; n++)
        o(r[n]);
      d();
    }
  }, lookup(r) {
    return this.sync(), i.get(String(r)) || Kt;
  }, forget(r) {
    if (i === null)
      return;
    const l = a(r), _ = l === null ? null : i.get(l);
    if (_) {
      const h = _.indexOf(r);
      h > -1 && _.splice(h, 1), _.length || i.delete(l);
    }
    n > 0 && n--, d();
  }, invalidate() {
    i = null, t = null, n = 0, s = null;
  } };
}
function yt(e) {
  return (function() {
    var i = {};
    for (var t in this._events) {
      var n = this._events[t];
      n.id.toString().indexOf("#") == -1 && (i[n.id] = n);
    }
    return i;
  }).bind(e);
}
function Xt(e) {
  e._loaded = {}, e._load = function(t, n) {
    if (t = t || this._load_url) {
      var s;
      if (t += (t.indexOf("?") == -1 ? "?" : "&") + "timeshift=" + (/* @__PURE__ */ new Date()).getTimezoneOffset(), this.config.prevent_cache && (t += "&uid=" + this.uid()), n = n || this._date, this._load_mode) {
        var a = this.templates.load_format;
        for (n = this.date[this._load_mode + "_start"](new Date(n.valueOf())); n > this._min_date; )
          n = this.date.add(n, -1, this._load_mode);
        s = n;
        for (var o = !0; s < this._max_date; )
          s = this.date.add(s, 1, this._load_mode), this._loaded[a(n)] && o ? n = this.date.add(n, 1, this._load_mode) : o = !1;
        var d = s;
        do
          s = d, d = this.date.add(s, -1, this._load_mode);
        while (d > n && this._loaded[a(d)]);
        if (s <= n)
          return !1;
        for (e.ajax.get(t + "&from=" + a(n) + "&to=" + a(s), r); n < s; )
          this._loaded[a(n)] = !0, n = this.date.add(n, 1, this._load_mode);
      } else
        e.ajax.get(t, r);
      return this.callEvent("onXLS", []), this.callEvent("onLoadStart", []), !0;
    }
    function r(l) {
      e.on_load(l), e.callEvent("onLoadEnd", []);
    }
  }, e._parsers = {}, function(t) {
    t._parsers.xml = { canParse: function(n, s) {
      if (s.responseXML && s.responseXML.firstChild)
        return !0;
      try {
        var a = t.ajax.parse(s.responseText), o = t.ajax.xmltop("data", a);
        if (o && o.tagName === "data")
          return !0;
      } catch {
      }
      return !1;
    }, parse: function(n) {
      var s;
      if (n.xmlDoc.responseXML || (n.xmlDoc.responseXML = t.ajax.parse(n.xmlDoc.responseText)), (s = t.ajax.xmltop("data", n.xmlDoc)).tagName != "data")
        return null;
      var a = s.getAttribute("dhx_security");
      a && (window.dhtmlx && (window.dhtmlx.security_key = a), t.security_key = a);
      for (var o = t.ajax.xpath("//coll_options", n.xmlDoc), d = 0; d < o.length; d++) {
        var r = o[d].getAttribute("for"), l = t.serverList[r];
        l || (t.serverList[r] = l = []), l.splice(0, l.length);
        for (var _ = t.ajax.xpath(".//item", o[d]), h = 0; h < _.length; h++) {
          for (var p = _[h].attributes, v = { key: _[h].getAttribute("value"), label: _[h].getAttribute("label") }, g = 0; g < p.length; g++) {
            var c = p[g];
            c.nodeName != "value" && c.nodeName != "label" && (v[c.nodeName] = c.nodeValue);
          }
          l.push(v);
        }
      }
      o.length && t.callEvent("onOptionsLoad", []);
      var f = t.ajax.xpath("//userdata", n.xmlDoc);
      for (d = 0; d < f.length; d++) {
        var u = t._xmlNodeToJSON(f[d]);
        t._userdata[u.name] = u.text;
      }
      var y = [];
      for (s = t.ajax.xpath("//event", n.xmlDoc), d = 0; d < s.length; d++) {
        var w = y[d] = t._xmlNodeToJSON(s[d]);
        t._init_event(w);
      }
      return y;
    } };
  }(e), function(t) {
    t.json = t._parsers.json = { canParse: function(n) {
      if (n && typeof n == "object")
        return !0;
      if (typeof n == "string")
        try {
          var s = JSON.parse(n);
          return Object.prototype.toString.call(s) === "[object Object]" || Object.prototype.toString.call(s) === "[object Array]";
        } catch {
          return !1;
        }
      return !1;
    }, parse: function(n) {
      var s = [];
      typeof n == "string" && (n = JSON.parse(n)), Object.prototype.toString.call(n) === "[object Array]" ? s = n : n && (n.events ? s = n.events : n.data && (s = n.data)), s = s || [], n.dhx_security && (window.dhtmlx && (window.dhtmlx.security_key = n.dhx_security), t.security_key = n.dhx_security);
      var a = n && n.collections ? n.collections : {}, o = !1;
      for (var d in a)
        if (a.hasOwnProperty(d)) {
          o = !0;
          var r = a[d], l = t.serverList[d];
          l || (t.serverList[d] = l = []), l.splice(0, l.length);
          for (var _ = 0; _ < r.length; _++) {
            var h = r[_], p = { key: h.value, label: h.label };
            for (var v in h)
              if (h.hasOwnProperty(v)) {
                if (v == "value" || v == "label")
                  continue;
                p[v] = h[v];
              }
            l.push(p);
          }
        }
      o && t.callEvent("onOptionsLoad", []);
      for (var g = [], c = 0; c < s.length; c++) {
        var f = s[c];
        t._init_event(f), g.push(f);
      }
      return g;
    } };
  }(e), function(t) {
    t.ical = t._parsers.ical = { canParse: function(n) {
      return typeof n == "string" && new RegExp("^BEGIN:VCALENDAR").test(n);
    }, parse: function(n) {
      var s = n.match(RegExp(this.c_start + "[^\f]*" + this.c_end, ""));
      if (s.length) {
        s[0] = s[0].replace(/[\r\n]+ /g, ""), s[0] = s[0].replace(/[\r\n]+(?=[a-z \t])/g, " "), s[0] = s[0].replace(/;[^:\r\n]*:/g, ":");
        for (var a, o = [], d = RegExp("(?:" + this.e_start + ")([^\f]*?)(?:" + this.e_end + ")", "g"); (a = d.exec(s)) !== null; ) {
          for (var r, l = {}, _ = /[^\r\n]+[\r\n]+/g; (r = _.exec(a[1])) !== null; )
            this.parse_param(r.toString(), l);
          l.uid && !l.id && (l.id = l.uid), o.push(l);
        }
        return o;
      }
    }, parse_param: function(n, s) {
      var a = n.indexOf(":");
      if (a != -1) {
        var o = n.substr(0, a).toLowerCase(), d = n.substr(a + 1).replace(/\\,/g, ",").replace(/[\r\n]+$/, "");
        o == "summary" ? o = "text" : o == "dtstart" ? (o = "start_date", d = this.parse_date(d, 0, 0)) : o == "dtend" && (o = "end_date", d = this.parse_date(d, 0, 0)), s[o] = d;
      }
    }, parse_date: function(n, s, a) {
      var o = n.split("T"), d = !1;
      o[1] && (s = o[1].substr(0, 2), a = o[1].substr(2, 2), d = o[1][6] == "Z");
      var r = o[0].substr(0, 4), l = parseInt(o[0].substr(4, 2), 10) - 1, _ = o[0].substr(6, 2);
      return t.config.server_utc || d ? new Date(Date.UTC(r, l, _, s, a)) : new Date(r, l, _, s, a);
    }, c_start: "BEGIN:VCALENDAR", e_start: "BEGIN:VEVENT", e_end: "END:VEVENT", c_end: "END:VCALENDAR" };
  }(e), e.on_load = function(t) {
    var n;
    this.callEvent("onBeforeParse", []);
    var s = !1, a = !1;
    for (var o in this._parsers) {
      var d = this._parsers[o];
      if (d.canParse(t.xmlDoc.responseText, t.xmlDoc)) {
        try {
          var r = t.xmlDoc.responseText;
          o === "xml" && (r = t), (n = d.parse(r)) || (s = !0);
        } catch {
          s = !0;
        }
        a = !0;
        break;
      }
    }
    if (!a)
      if (this._process && this[this._process])
        try {
          n = this[this._process].parse(t.xmlDoc.responseText);
        } catch {
          s = !0;
        }
      else
        s = !0;
    (s || t.xmlDoc.status && t.xmlDoc.status >= 400) && (this.callEvent("onLoadError", [t.xmlDoc]), n = []), this._process_loading(n), this.callEvent("onXLE", []), this.callEvent("onParse", []);
  }, e._process_loading = function(t) {
    this._loading = !0, this._not_render = !0;
    for (var n = 0; n < t.length; n++)
      this.callEvent("onEventLoading", [t[n]]) && this.addEvent(t[n]);
    this._not_render = !1, this._render_wait && this.render_view_data(), this._loading = !1, this._after_call && this._after_call(), this._after_call = null;
  }, e._init_event = function(t) {
    t.text = t.text || t._tagvalue || "", t.start_date = e._init_date(t.start_date), t.end_date = e._init_date(t.end_date);
  }, e._init_date = function(t) {
    return t ? typeof t == "string" ? e._helpers.parseDate(t) : new Date(t) : null;
  };
  const i = yt(e);
  e.serialize = function() {
    const t = [], n = i();
    for (var s in n) {
      const d = {};
      var a = n[s];
      for (var o in a) {
        if (o.charAt(0) == "$" || o.charAt(0) == "_")
          continue;
        let r;
        const l = a[o];
        r = e.utils.isDate(l) ? e.defined(e.templates.xml_format) ? e.templates.xml_format(l) : e.templates.format_date(l) : l, d[o] = r;
      }
      t.push(d);
    }
    return t;
  }, e.parse = function(t, n) {
    this._process = n, this.on_load({ xmlDoc: { responseText: t } });
  }, e.load = function(t, n) {
    typeof n == "string" && (this._process = n, n = arguments[2]), this._load_url = t, this._after_call = n, this._load(t, this._date);
  }, e.setLoadMode = function(t) {
    t == "all" && (t = ""), this._load_mode = t;
  }, e.serverList = function(t, n) {
    return n ? (this.serverList[t] = n.slice(0), this.serverList[t]) : (this.serverList[t] = this.serverList[t] || [], this.serverList[t]);
  }, e._userdata = {}, e._xmlNodeToJSON = function(t) {
    for (var n = {}, s = 0; s < t.attributes.length; s++)
      n[t.attributes[s].name] = t.attributes[s].value;
    for (s = 0; s < t.childNodes.length; s++) {
      var a = t.childNodes[s];
      a.nodeType == 1 && (n[a.tagName] = a.firstChild ? a.firstChild.nodeValue : "");
    }
    return n.text || (n.text = t.firstChild ? t.firstChild.nodeValue : ""), n;
  }, e.attachEvent("onXLS", function() {
    var t;
    this.config.show_loading === !0 && ((t = this.config.show_loading = document.createElement("div")).className = "dhx_loading", t.style.left = Math.round((this._x - 128) / 2) + "px", t.style.top = Math.round((this._y - 15) / 2) + "px", this._obj.appendChild(t));
  }), e.attachEvent("onXLE", function() {
    var t = this.config.show_loading;
    t && typeof t == "object" && (t.parentNode && t.parentNode.removeChild(t), this.config.show_loading = !0);
  });
}
function Zt(e) {
  function i() {
    const t = e.config.csp === !0, n = !!window.Sfdc || !!window.$A || window.Aura || "$shadowResolver$" in document.body;
    return t || n ? e.$root : document.body;
  }
  e._lightbox_controls = {}, e.formSection = function(t) {
    for (var n = this.config.lightbox.sections, s = 0; s < n.length && n[s].name != t; s++)
      ;
    if (s === n.length)
      return null;
    var a = n[s];
    e._lightbox || e.getLightbox();
    var o = e._lightbox.querySelector(`#${a.id}`), d = o.nextSibling, r = { section: a, header: o, node: d, getValue: function(_) {
      return e.form_blocks[a.type].get_value(d, _ || {}, a);
    }, setValue: function(_, h) {
      return e.form_blocks[a.type].set_value(d, _, h || {}, a);
    } }, l = e._lightbox_controls["get_" + a.type + "_control"];
    return l ? l(r) : r;
  }, e._lightbox_controls.get_template_control = function(t) {
    return t.control = t.node, t;
  }, e._lightbox_controls.get_select_control = function(t) {
    return t.control = t.node.getElementsByTagName("select")[0], t;
  }, e._lightbox_controls.get_textarea_control = function(t) {
    return t.control = t.node.getElementsByTagName("textarea")[0], t;
  }, e._lightbox_controls.get_time_control = function(t) {
    return t.control = t.node.getElementsByTagName("select"), t;
  }, e._lightbox_controls.defaults = { template: { height: 30 }, textarea: { height: 200 }, select: { height: 23 }, time: { height: 20 } }, e.form_blocks = { template: { render: function(t) {
    return `<div class='dhx_cal_ltext dhx_cal_template' ${t.height ? `style='height:${t.height}px;'` : ""}></div>`;
  }, set_value: function(t, n, s, a) {
    t.innerHTML = n || "";
  }, get_value: function(t, n, s) {
    return t.innerHTML || "";
  }, focus: function(t) {
  } }, textarea: { render: function(t) {
    return `<div class='dhx_cal_ltext' ${t.height ? `style='height:${t.height}px;'` : ""}><textarea ${t.placeholder ? `placeholder='${t.placeholder}'` : ""}></textarea></div>`;
  }, set_value: function(t, n, s) {
    e.form_blocks.textarea._get_input(t).value = n || "";
  }, get_value: function(t, n) {
    return e.form_blocks.textarea._get_input(t).value;
  }, focus: function(t) {
    var n = e.form_blocks.textarea._get_input(t);
    e._focus(n, !0);
  }, _get_input: function(t) {
    return t.getElementsByTagName("textarea")[0];
  } }, select: { render: function(t) {
    for (var n = `<div class='dhx_cal_ltext dhx_cal_select' ${t.height ? `style='height:${t.height}px;'` : ""}><select style='width:100%;'>`, s = 0; s < t.options.length; s++)
      n += "<option value='" + t.options[s].key + "'>" + t.options[s].label + "</option>";
    return n += "</select></div>";
  }, set_value: function(t, n, s, a) {
    var o = t.firstChild;
    !o._dhx_onchange && a.onchange && (e.event(o, "change", a.onchange), o._dhx_onchange = !0), n === void 0 && (n = (o.options[0] || {}).value), o.value = n || "";
  }, get_value: function(t, n) {
    return t.firstChild.value;
  }, focus: function(t) {
    var n = t.firstChild;
    e._focus(n, !0);
  } }, time: { render: function(t) {
    t.time_format || (t.time_format = ["%H:%i", "%d", "%m", "%Y"]), t._time_format_order = {};
    var n = t.time_format, s = e.config, a = e.date.date_part(e._currentDate()), o = 1440, d = 0;
    e.config.limit_time_select && (o = 60 * s.last_hour + 1, d = 60 * s.first_hour, a.setHours(s.first_hour));
    for (var r = "", l = 0; l < n.length; l++) {
      var _ = n[l];
      l > 0 && (r += " ");
      var h = "", p = "";
      switch (_) {
        case "%Y":
          var v, g, c;
          h = "dhx_lightbox_year_select", t._time_format_order[3] = l, t.year_range && (isNaN(t.year_range) ? t.year_range.push && (g = t.year_range[0], c = t.year_range[1]) : v = t.year_range), v = v || 10;
          var f = f || Math.floor(v / 2);
          g = g || a.getFullYear() - f, c = c || g + v;
          for (var u = g; u < c; u++)
            p += "<option value='" + u + "'>" + u + "</option>";
          break;
        case "%m":
          for (h = "dhx_lightbox_month_select", t._time_format_order[2] = l, u = 0; u < 12; u++)
            p += "<option value='" + u + "'>" + this.locale.date.month_full[u] + "</option>";
          break;
        case "%d":
          for (h = "dhx_lightbox_day_select", t._time_format_order[1] = l, u = 1; u < 32; u++)
            p += "<option value='" + u + "'>" + u + "</option>";
          break;
        case "%H:%i":
          h = "dhx_lightbox_time_select", t._time_format_order[0] = l, u = d;
          var y = a.getDate();
          for (t._time_values = []; u < o; )
            p += "<option value='" + u + "'>" + this.templates.time_picker(a) + "</option>", t._time_values.push(u), a.setTime(a.valueOf() + 60 * this.config.time_step * 1e3), u = 24 * (a.getDate() != y ? 1 : 0) * 60 + 60 * a.getHours() + a.getMinutes();
      }
      if (p) {
        var w = e._waiAria.lightboxSelectAttrString(_);
        r += "<select class='" + h + "' " + (t.readonly ? "disabled='disabled'" : "") + w + ">" + p + "</select> ";
      }
    }
    return `<div class='dhx_section_time' ${t.height ? `style='height:${t.height}px;'` : ""}>${r}<span style='font-weight:normal; font-size:10pt;' class='dhx_section_time_spacer'> &nbsp;&ndash;&nbsp; </span>${r}</div>`;
  }, set_value: function(t, n, s, a) {
    var o, d, r = e.config, l = t.getElementsByTagName("select"), _ = a._time_format_order;
    if (r.full_day) {
      if (!t._full_day) {
        var h = "<label class='dhx_fullday'><input type='checkbox' name='full_day' value='true'> " + e.locale.labels.full_day + "&nbsp;</label></input>";
        e.config.wide_form || (h = t.previousSibling.innerHTML + h), t.previousSibling.innerHTML = h, t._full_day = !0;
      }
      var p = t.previousSibling.getElementsByTagName("input")[0];
      p.checked = e.date.time_part(s.start_date) === 0 && e.date.time_part(s.end_date) === 0, l[_[0]].disabled = p.checked, l[_[0] + l.length / 2].disabled = p.checked, p.$_eventAttached || (p.$_eventAttached = !0, e.event(p, "click", function() {
        if (p.checked) {
          var f = {};
          e.form_blocks.time.get_value(t, f, a), o = e.date.date_part(f.start_date), (+(d = e.date.date_part(f.end_date)) == +o || +d >= +o && (s.end_date.getHours() !== 0 || s.end_date.getMinutes() !== 0)) && (d = e.date.add(d, 1, "day"));
        } else
          o = null, d = null;
        l[_[0]].disabled = p.checked, l[_[0] + l.length / 2].disabled = p.checked, c(l, 0, o || s.start_date), c(l, 4, d || s.end_date);
      }));
    }
    if (r.auto_end_date && r.event_duration)
      for (var v = function() {
        r.auto_end_date && r.event_duration && (o = new Date(l[_[3]].value, l[_[2]].value, l[_[1]].value, 0, l[_[0]].value), d = new Date(o.getTime() + 60 * e.config.event_duration * 1e3), c(l, 4, d));
      }, g = 0; g < 4; g++)
        l[g].$_eventAttached || (l[g].$_eventAttached = !0, e.event(l[g], "change", v));
    function c(f, u, y) {
      for (var w = a._time_values, D = 60 * y.getHours() + y.getMinutes(), M = D, k = !1, N = 0; N < w.length; N++) {
        var m = w[N];
        if (m === D) {
          k = !0;
          break;
        }
        m < D && (M = m);
      }
      f[u + _[0]].value = k ? D : M, k || M || (f[u + _[0]].selectedIndex = -1), f[u + _[1]].value = y.getDate(), f[u + _[2]].value = y.getMonth(), f[u + _[3]].value = y.getFullYear();
    }
    c(l, 0, s.start_date), c(l, 4, s.end_date);
  }, get_value: function(t, n, s) {
    var a = t.getElementsByTagName("select"), o = s._time_format_order;
    if (n.start_date = new Date(a[o[3]].value, a[o[2]].value, a[o[1]].value, 0, a[o[0]].value), n.end_date = new Date(a[o[3] + 4].value, a[o[2] + 4].value, a[o[1] + 4].value, 0, a[o[0] + 4].value), !a[o[3]].value || !a[o[3] + 4].value) {
      var d = e.getEvent(e._lightbox_id);
      d && (n.start_date = d.start_date, n.end_date = d.end_date);
    }
    return n.end_date <= n.start_date && (n.end_date = e.date.add(n.start_date, e.config.time_step, "minute")), { start_date: new Date(n.start_date), end_date: new Date(n.end_date) };
  }, focus: function(t) {
    e._focus(t.getElementsByTagName("select")[0]);
  } } }, e._setLbPosition = function(t) {
    t && (t.style.top = Math.max(i().offsetHeight / 2 - t.offsetHeight / 2, 0) + "px", t.style.left = Math.max(i().offsetWidth / 2 - t.offsetWidth / 2, 0) + "px");
  }, e.showCover = function(t) {
    t && (t.style.display = "block", this._setLbPosition(t)), e.config.responsive_lightbox && (document.documentElement.classList.add("dhx_cal_overflow_container"), i().classList.add("dhx_cal_overflow_container")), this.show_cover(), this._cover.style.display = "";
  }, e.showLightbox = function(t) {
    if (t)
      if (this.callEvent("onBeforeLightbox", [t])) {
        this.showCover(n);
        var n = this.getLightbox();
        this._setLbPosition(n), this._fill_lightbox(t, n), this._waiAria.lightboxVisibleAttr(n), this.callEvent("onLightbox", [t]);
      } else
        this._new_event && (this._new_event = null, e.getEvent(t) && delete e.getEvent(t).$new);
  }, e._fill_lightbox = function(t, n) {
    var s = this.getEvent(t), a = n.getElementsByTagName("span"), o = [];
    if (e.templates.lightbox_header) {
      o.push("");
      var d = e.templates.lightbox_header(s.start_date, s.end_date, s);
      o.push(d), a[1].innerHTML = "", a[2].innerHTML = d;
    } else {
      var r = this.templates.event_header(s.start_date, s.end_date, s), l = (this.templates.event_bar_text(s.start_date, s.end_date, s) || "").substr(0, 70);
      o.push(r), o.push(l), a[1].innerHTML = r, a[2].innerHTML = l;
    }
    this._waiAria.lightboxHeader(n, o.join(" "));
    for (var _ = this.config.lightbox.sections, h = 0; h < _.length; h++) {
      var p = _[h], v = e._get_lightbox_section_node(p), g = this.form_blocks[p.type], c = s[p.map_to] !== void 0 ? s[p.map_to] : p.default_value;
      g.set_value.call(this, v, c, s, p), _[h].focus && g.focus.call(this, v);
    }
    e._lightbox_id = t;
  }, e._get_lightbox_section_node = function(t) {
    return e._lightbox.querySelector(`#${t.id}`).nextSibling;
  }, e._lightbox_out = function(t) {
    for (var n = this.config.lightbox.sections, s = 0; s < n.length; s++) {
      var a = e._lightbox.querySelector(`#${n[s].id}`);
      a = a && a.nextSibling;
      var o = this.form_blocks[n[s].type].get_value.call(this, a, t, n[s]);
      n[s].map_to != "auto" && (t[n[s].map_to] = o);
    }
    return t;
  }, e._empty_lightbox = function(t) {
    var n = e._lightbox_id, s = this.getEvent(n);
    s && (this._lame_copy(s, t), this.setEvent(s.id, s), this._edit_stop_event(s, !0)), this.render_view_data();
  }, e.hide_lightbox = function(t) {
    e.endLightbox(!1, this.getLightbox());
  }, e.hideCover = function(t) {
    t && (t.style.display = "none"), this.hide_cover(), e.config.responsive_lightbox && (document.documentElement.classList.remove("dhx_cal_overflow_container"), i().classList.remove("dhx_cal_overflow_container"));
  }, e.hide_cover = function() {
    this._cover && this._cover.parentNode.removeChild(this._cover), this._cover = null;
  }, e.show_cover = function() {
    this._cover || (this._cover = document.createElement("div"), this._cover.className = "dhx_cal_cover", this._cover.style.display = "none", e.event(this._cover, "mousemove", e._move_while_dnd), e.event(this._cover, "mouseup", e._finish_dnd), i().appendChild(this._cover));
  }, e.save_lightbox = function() {
    var t = this._lightbox_out({}, this._lame_copy(this.getEvent(this._lightbox_id)));
    this.checkEvent("onEventSave") && !this.callEvent("onEventSave", [this._lightbox_id, t, this._new_event]) || (this.checkEvent("onRecurringEventSave") && e.callEvent("onRecurringEventSave", [this._lightbox_id, t, this._new_event]), this._empty_lightbox(t), this.hide_lightbox());
  }, e.startLightbox = function(t, n) {
    this._lightbox_id = t, this._custom_lightbox = !0, this._temp_lightbox = this._lightbox, this._lightbox = n, this.showCover(n);
  }, e.endLightbox = function(t, n) {
    n = n || e.getLightbox();
    var s = e.getEvent(this._lightbox_id);
    s && this._edit_stop_event(s, t), t && e.render_view_data(), this.hideCover(n), this._custom_lightbox && (this._lightbox = this._temp_lightbox, this._custom_lightbox = !1), this._temp_lightbox = this._lightbox_id = null, this._waiAria.lightboxHiddenAttr(n), this.resetLightbox(), this.callEvent("onAfterLightbox", []);
  }, e.resetLightbox = function() {
    e._lightbox && !e._custom_lightbox && e._lightbox.parentNode.removeChild(e._lightbox), e._lightbox = null;
  }, e.cancel_lightbox = function() {
    this._lightbox_id && this.callEvent("onEventCancel", [this._lightbox_id, !!this._new_event]), this.hide_lightbox();
  }, e.hideLightbox = e.cancel_lightbox, e._delete_event_confirm = function({ event: t, message: n, title: s, callback: a, ok: o }) {
    e._dhtmlx_confirm({ message: n, title: s, callback: a, ok: o });
  }, e._init_lightbox_events = function() {
    if (this.getLightbox().$_eventAttached)
      return;
    const t = this.getLightbox();
    t.$_eventAttached = !0, e.event(t, "click", function(n) {
      n.target.closest(".dhx_cal_ltitle_close_btn") && e.cancel_lightbox();
      const s = e.$domHelpers.closest(n.target, ".dhx_btn_set");
      if (!s) {
        const d = e.$domHelpers.closest(n.target, ".dhx_custom_button[data-section-index]");
        if (d) {
          const r = Number(d.getAttribute("data-section-index"));
          e.form_blocks[e.config.lightbox.sections[r].type].button_click(e.$domHelpers.closest(d, ".dhx_cal_lsection"), d, n);
        }
        return;
      }
      const a = s ? s.getAttribute("data-action") : null;
      switch (a) {
        case "dhx_save_btn":
        case "save":
          if (e.config.readonly_active)
            return;
          e.save_lightbox();
          break;
        case "dhx_delete_btn":
        case "delete":
          if (e.config.readonly_active)
            return;
          var o = e.locale.labels.confirm_deleting;
          e._delete_event_confirm({ event: e.getEvent(e._lightbox_id), message: o, title: e.locale.labels.title_confirm_deleting, callback: function() {
            let d = e.getEvent(e._lightbox_id);
            d._thisAndFollowing ? (d._removeFollowing = !0, e.callEvent("onRecurringEventSave", [d.id, d, e._new_event])) : e.deleteEvent(e._lightbox_id), e._new_event = null, delete d.$new, e.hide_lightbox();
          }, config: { ok: e.locale.labels.icon_delete } });
          break;
        case "dhx_cancel_btn":
        case "cancel":
          e.cancel_lightbox();
          break;
        default:
          e.callEvent("onLightboxButton", [a, s, n]);
      }
    }), e.event(t, "keydown", function(n) {
      var s = n || window.event, a = n.target || n.srcElement, o = a.querySelector("[dhx_button]");
      switch (o || (o = a.parentNode.querySelector(".dhx_custom_button, .dhx_readonly")), (n || s).keyCode) {
        case 32:
          if ((n || s).shiftKey)
            return;
          o && o.click && o.click();
          break;
        case e.keys.edit_save:
          if ((n || s).shiftKey)
            return;
          if (o && o.click)
            o.click();
          else {
            if (e.config.readonly_active)
              return;
            e.save_lightbox();
          }
          break;
        case e.keys.edit_cancel:
          e.cancel_lightbox();
      }
    }), e.event(t, "click", function(n) {
      if (n.target.closest(".dhx_lightbox_day_select") || n.target.closest(".dhx_lightbox_month_select")) {
        const s = t.querySelectorAll(".dhx_lightbox_month_select"), a = t.querySelectorAll(".dhx_lightbox_day_select"), o = t.querySelectorAll(".dhx_lightbox_year_select");
        s.length && a.length && o && s.forEach((d, r) => {
          const l = a[r], _ = parseInt(d.value, 10);
          let h = parseInt(o[r].value, 10);
          h || (h = new Date(e.getState().date).getFullYear());
          const p = function(c, f) {
            return new Date(c, f + 1, 0).getDate();
          }(h, _), v = p || 31;
          let g = l.value;
          l.innerHTML = "";
          for (let c = 1; c <= v; c++) {
            const f = document.createElement("option");
            f.value = c, f.textContent = c, l.appendChild(f);
          }
          l.value = Math.min(g, v);
        });
      }
    });
  }, e.setLightboxSize = function() {
  }, e._init_dnd_events = function() {
    e.event(i(), "mousemove", e._move_while_dnd), e.event(i(), "mouseup", e._finish_dnd), e._init_dnd_events = function() {
    };
  }, e._move_while_dnd = function(t) {
    if (e._dnd_start_lb) {
      document.dhx_unselectable || (i().classList.add("dhx_unselectable"), document.dhx_unselectable = !0);
      var n = e.getLightbox(), s = [t.pageX, t.pageY];
      n.style.top = e._lb_start[1] + s[1] - e._dnd_start_lb[1] + "px", n.style.left = e._lb_start[0] + s[0] - e._dnd_start_lb[0] + "px";
    }
  }, e._ready_to_dnd = function(t) {
    var n = e.getLightbox();
    e._lb_start = [n.offsetLeft, n.offsetTop], e._dnd_start_lb = [t.pageX, t.pageY];
  }, e._finish_dnd = function() {
    e._lb_start && (e._lb_start = e._dnd_start_lb = !1, i().classList.remove("dhx_unselectable"), document.dhx_unselectable = !1);
  }, e.getLightbox = function() {
    if (!this._lightbox) {
      var t = document.createElement("div");
      t.className = "dhx_cal_light", e.config.wide_form && (t.className += " dhx_cal_light_wide"), e.form_blocks.recurring && (t.className += " dhx_cal_light_rec"), e.config.rtl && (t.className += " dhx_cal_light_rtl"), e.config.responsive_lightbox && (t.className += " dhx_cal_light_responsive"), t.style.visibility = "hidden";
      var n = this._lightbox_template, s = this.config.buttons_right;
      n += "<div class='dhx_cal_lcontrols'>";
      for (var a = 0; a < s.length; a++)
        n += "<div " + this._waiAria.lightboxButtonAttrString(s[a]) + " data-action='" + s[a] + "' class='dhx_btn_set dhx_" + (e.config.rtl ? "right" : "left") + "_btn_set " + s[a] + "_set'><div class='dhx_btn_inner " + s[a] + "'></div><div>" + e.locale.labels[s[a]] + "</div></div>";
      s = this.config.buttons_left;
      var o = e.config.rtl;
      for (a = 0; a < s.length; a++)
        n += "<div class='dhx_cal_lcontrols_push_right'></div>", n += "<div " + this._waiAria.lightboxButtonAttrString(s[a]) + " data-action='" + s[a] + "' class='dhx_btn_set dhx_" + (o ? "left" : "right") + "_btn_set " + s[a] + "_set'><div class='dhx_btn_inner " + s[a] + "'></div><div>" + e.locale.labels[s[a]] + "</div></div>";
      n += "</div>", n += "</div>", t.innerHTML = n, e.config.drag_lightbox && (e.event(t.firstChild, "mousedown", e._ready_to_dnd), e.event(t.firstChild, "selectstart", function(v) {
        return v.preventDefault(), !1;
      }), t.firstChild.style.cursor = "move", e._init_dnd_events()), this._waiAria.lightboxAttr(t), this.show_cover(), this._cover.insertBefore(t, this._cover.firstChild), this._lightbox = t;
      var d = this.config.lightbox.sections;
      for (n = "", a = 0; a < d.length; a++) {
        var r = this.form_blocks[d[a].type];
        if (r) {
          d[a].id = "area_" + this.uid();
          var l = "";
          d[a].button && (l = "<div " + e._waiAria.lightboxSectionButtonAttrString(this.locale.labels["button_" + d[a].button]) + " class='dhx_custom_button' data-section-index='" + a + "' index='" + a + "'><div class='dhx_custom_button_" + d[a].button + "'></div><div>" + this.locale.labels["button_" + d[a].button] + "</div></div>"), this.config.wide_form && (n += "<div class='dhx_wrap_section'>");
          var _ = this.locale.labels["section_" + d[a].name];
          typeof _ != "string" && (_ = d[a].name), n += "<div id='" + d[a].id + "' class='dhx_cal_lsection dhx_cal_lsection_" + d[a].name + "'>" + l + "<label>" + _ + "</label></div>" + r.render.call(this, d[a]), n += "</div>";
        }
      }
      var h = t.getElementsByTagName("div");
      for (a = 0; a < h.length; a++) {
        var p = h[a];
        if (e._getClassName(p) == "dhx_cal_larea") {
          p.innerHTML = n;
          break;
        }
      }
      e._bindLightboxLabels(d), this.setLightboxSize(), this._init_lightbox_events(this), t.style.visibility = "visible";
    }
    return this._lightbox;
  }, e._bindLightboxLabels = function(t) {
    for (var n = 0; n < t.length; n++) {
      var s = t[n];
      if (s.id && e._lightbox.querySelector(`#${s.id}`)) {
        for (var a = e._lightbox.querySelector(`#${s.id}`).querySelector("label"), o = e._get_lightbox_section_node(s); o && !o.querySelector; )
          o = o.nextSibling;
        var d = !0;
        if (o) {
          var r = o.querySelector("input, select, textarea");
          r && (s.inputId = r.id || "input_" + e.uid(), r.id || (r.id = s.inputId), a.setAttribute("for", s.inputId), d = !1);
        }
        d && e.form_blocks[s.type].focus && e.event(a, "click", function(l) {
          return function() {
            var _ = e.form_blocks[l.type], h = e._get_lightbox_section_node(l);
            _ && _.focus && _.focus.call(e, h);
          };
        }(s));
      }
    }
  }, e.attachEvent("onEventIdChange", function(t, n) {
    this._lightbox_id == t && (this._lightbox_id = n);
  }), e._lightbox_template = `<div class='dhx_cal_ltitle'><div class="dhx_cal_ltitle_descr"><span class='dhx_mark'>&nbsp;</span><span class='dhx_time'></span><span class='dhx_title'></span>
</div>
<div class="dhx_cal_ltitle_controls">
<a class="dhx_cal_ltitle_close_btn scheduler_icon close"></a>
</div></div><div class='dhx_cal_larea'></div>`;
}
function Qt(e) {
  e._init_touch_events = function() {
    if ((this.config.touch && (navigator.userAgent.indexOf("Mobile") != -1 || navigator.userAgent.indexOf("iPad") != -1 || navigator.userAgent.indexOf("Android") != -1 || navigator.userAgent.indexOf("Touch") != -1) && !window.MSStream || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) && (this.xy.scroll_width = 0, this._mobile = !0), this.config.touch) {
      var i = !0;
      try {
        document.createEvent("TouchEvent");
      } catch {
        i = !1;
      }
      i ? this._touch_events(["touchmove", "touchstart", "touchend"], function(t) {
        return t.touches && t.touches.length > 1 ? null : t.touches[0] ? { target: t.target, pageX: t.touches[0].pageX, pageY: t.touches[0].pageY, clientX: t.touches[0].clientX, clientY: t.touches[0].clientY } : t;
      }, function() {
        return !1;
      }) : window.PointerEvent || window.navigator.pointerEnabled ? this._touch_events(["pointermove", "pointerdown", "pointerup"], function(t) {
        return t.pointerType == "mouse" ? null : t;
      }, function(t) {
        return !t || t.pointerType == "mouse";
      }) : window.navigator.msPointerEnabled && this._touch_events(["MSPointerMove", "MSPointerDown", "MSPointerUp"], function(t) {
        return t.pointerType == t.MSPOINTER_TYPE_MOUSE ? null : t;
      }, function(t) {
        return !t || t.pointerType == t.MSPOINTER_TYPE_MOUSE;
      });
    }
  }, e._touch_events = function(i, t, n) {
    var s, a, o, d, r, l, _ = 0;
    function h(v, g, c) {
      e.event(v, g, function(f) {
        return !!e._is_lightbox_open() || (n(f) ? void 0 : c(f));
      }, { passive: !1 });
    }
    function p(v) {
      n(v) || (e._hide_global_tip(), d && (e._on_mouse_up(t(v)), e._temp_touch_block = !1), e._drag_id = null, e._drag_mode = null, e._drag_pos = null, e._pointerDragId = null, clearTimeout(o), d = l = !1, r = !0);
    }
    h(document.body, i[0], function(v) {
      if (!n(v)) {
        var g = t(v);
        if (g) {
          if (d)
            return function(c) {
              if (!n(c)) {
                var f = e.getState().drag_mode, u = !!e.matrix && e.matrix[e._mode], y = e.render_view_data;
                f == "create" && u && (e.render_view_data = function() {
                  for (var w = e.getState().drag_id, D = e.getEvent(w), M = u.y_property, k = e.getEvents(D.start_date, D.end_date), N = 0; N < k.length; N++)
                    k[N][M] != D[M] && (k.splice(N, 1), N--);
                  D._sorder = k.length - 1, D._count = k.length, this.render_data([D], e.getState().mode);
                }), e._on_mouse_move(c), f == "create" && u && (e.render_view_data = y), c.preventDefault && c.preventDefault(), c.cancelBubble = !0;
              }
            }(g), v.preventDefault && v.preventDefault(), v.cancelBubble = !0, e._update_global_tip(), !1;
          a = t(v), l && (a ? (s.target != a.target || Math.abs(s.pageX - a.pageX) > 5 || Math.abs(s.pageY - a.pageY) > 5) && (r = !0, clearTimeout(o)) : r = !0);
        }
      }
    }), h(this._els.dhx_cal_data[0], "touchcancel", p), h(this._els.dhx_cal_data[0], "contextmenu", function(v) {
      if (!n(v))
        return l ? (v && v.preventDefault && v.preventDefault(), v.cancelBubble = !0, !1) : void 0;
    }), h(this._obj, i[1], function(v) {
      var g;
      if (document && document.body && document.body.classList.add("dhx_cal_touch_active"), !n(v))
        if (e._pointerDragId = v.pointerId, d = r = !1, l = !0, g = a = t(v)) {
          var c = /* @__PURE__ */ new Date();
          if (!r && !d && c - _ < 250)
            return e._click.dhx_cal_data(g), window.setTimeout(function() {
              e.$destroyed || e._on_dbl_click(g);
            }, 50), v.preventDefault && v.preventDefault(), v.cancelBubble = !0, e._block_next_stop = !0, !1;
          if (_ = c, !r && !d && e.config.touch_drag) {
            var f = e._locate_event(document.activeElement), u = e._locate_event(g.target), y = s ? e._locate_event(s.target) : null;
            if (f && u && f == u && f != y)
              return v.preventDefault && v.preventDefault(), v.cancelBubble = !0, e._ignore_next_click = !1, e._click.dhx_cal_data(g), s = g, !1;
            o = setTimeout(function() {
              if (!e.$destroyed) {
                d = !0;
                var w = s.target, D = e._getClassName(w);
                w && D.indexOf("dhx_body") != -1 && (w = w.previousSibling), e._on_mouse_down(s, w), e._drag_mode && e._drag_mode != "create" && e.for_rendered(e._drag_id, function(M, k) {
                  M.style.display = "none", e._forget_rendered_event(M, k);
                }), e.config.touch_tip && e._show_global_tip(), e.updateEvent(e._drag_id);
              }
            }, e.config.touch_drag), s = g;
          }
        } else
          r = !0;
    }), h(this._els.dhx_cal_data[0], i[2], function(v) {
      if (document && document.body && document.body.classList.remove("dhx_cal_touch_active"), !n(v))
        return e.config.touch_swipe_dates && !d && function(g, c, f, u) {
          if (!g || !c)
            return !1;
          for (var y = g.target; y && y != e._obj; )
            y = y.parentNode;
          if (y != e._obj || e.matrix && e.matrix[e.getState().mode] && e.matrix[e.getState().mode].scrollable)
            return !1;
          var w = Math.abs(g.pageY - c.pageY), D = Math.abs(g.pageX - c.pageX);
          return w < u && D > f && (!w || D / w > 3) && (g.pageX > c.pageX ? e._click.dhx_cal_next_button() : e._click.dhx_cal_prev_button(), !0);
        }(s, a, 200, 100) && (e._block_next_stop = !0), d && (e._ignore_next_click = !0, setTimeout(function() {
          e._ignore_next_click = !1;
        }, 100)), p(v), e._block_next_stop ? (e._block_next_stop = !1, v.preventDefault && v.preventDefault(), v.cancelBubble = !0, !1) : void 0;
    }), e.event(document.body, i[2], p);
  }, e._show_global_tip = function() {
    e._hide_global_tip();
    var i = e._global_tip = document.createElement("div");
    i.className = "dhx_global_tip", e._update_global_tip(1), document.body.appendChild(i);
  }, e._update_global_tip = function(i) {
    var t = e._global_tip;
    if (t) {
      var n = "";
      if (e._drag_id && !i) {
        var s = e.getEvent(e._drag_id);
        s && (n = "<div>" + (s._timed ? e.templates.event_header(s.start_date, s.end_date, s) : e.templates.day_date(s.start_date, s.end_date, s)) + "</div>");
      }
      e._drag_mode == "create" || e._drag_mode == "new-size" ? t.innerHTML = (e.locale.labels.drag_to_create || "Drag to create") + n : t.innerHTML = (e.locale.labels.drag_to_move || "Drag to move") + n;
    }
  }, e._hide_global_tip = function() {
    var i = e._global_tip;
    i && i.parentNode && (i.parentNode.removeChild(i), e._global_tip = 0);
  };
}
function ea(e) {
  var i, t;
  function n() {
    if (e._is_material_skin())
      return !0;
    if (t !== void 0)
      return t;
    var d = document.createElement("div");
    d.style.position = "absolute", d.style.left = "-9999px", d.style.top = "-9999px", d.innerHTML = "<div class='dhx_cal_container'><div class='dhx_cal_data'><div class='dhx_cal_event'><div class='dhx_body'></div></div><div>", document.body.appendChild(d);
    var r = window.getComputedStyle(d.querySelector(".dhx_body")).getPropertyValue("box-sizing");
    document.body.removeChild(d), (t = r === "border-box") || setTimeout(function() {
      t = void 0;
    }, 1e3);
  }
  function s() {
    if (!e._is_material_skin() && !e._border_box_events()) {
      var d = t;
      t = void 0, i = void 0, d !== n() && e.$container && e.getState().mode && e.setCurrentView();
    }
  }
  function a(d) {
    var r = d.getMinutes();
    return r = r < 10 ? "0" + r : r, "<span class='dhx_scale_h'>" + d.getHours() + "</span><span class='dhx_scale_m'>&nbsp;" + r + "</span>";
  }
  e._addThemeClass = function() {
    document.documentElement.setAttribute("data-scheduler-theme", e.skin);
  }, e._skin_settings = { fix_tab_position: [1, 0], use_select_menu_space: [1, 0], wide_form: [1, 0], hour_size_px: [44, 42], displayed_event_color: ["#ff4a4a", "ffc5ab"], displayed_event_text_color: ["#ffef80", "7e2727"] }, e._skin_xy = { lightbox_additional_height: [90, 50], nav_height: [59, 22], bar_height: [24, 20] }, e._is_material_skin = function() {
    return e.skin ? (e.skin + "").indexOf("material") > -1 : function() {
      if (i === void 0) {
        var d = document.createElement("div");
        d.style.position = "absolute", d.style.left = "-9999px", d.style.top = "-9999px", d.innerHTML = "<div class='dhx_cal_container'><div class='dhx_cal_scale_placeholder'></div><div>", document.body.appendChild(d);
        var r = window.getComputedStyle(d.querySelector(".dhx_cal_scale_placeholder")).getPropertyValue("position");
        i = r === "absolute", setTimeout(function() {
          i = null, d && d.parentNode && d.parentNode.removeChild(d);
        }, 500);
      }
      return i;
    }();
  }, e._build_skin_info = function() {
    (function() {
      const v = e.$container;
      clearInterval(o), v && (o = setInterval(() => {
        const g = getComputedStyle(v).getPropertyValue("--dhx-scheduler-theme");
        g && g !== e.skin && e.setSkin(g);
      }, 100));
    })();
    const d = getComputedStyle(this.$container), r = d.getPropertyValue("--dhx-scheduler-theme");
    let l, _ = !!r, h = {}, p = !1;
    if (_) {
      l = r;
      for (let v in e.xy)
        h[v] = d.getPropertyValue(`--dhx-scheduler-xy-${v}`);
      h.hour_size_px = d.getPropertyValue("--dhx-scheduler-config-hour_size_px"), h.wide_form = d.getPropertyValue("--dhx-scheduler-config-form_wide");
    } else
      l = function() {
        for (var v = document.getElementsByTagName("link"), g = 0; g < v.length; g++) {
          var c = v[g].href.match("dhtmlxscheduler_([a-z]+).css");
          if (c)
            return c[1];
        }
      }(), p = e._is_material_skin();
    if (e._theme_info = { theme: l, cssVarTheme: _, oldMaterialTheme: p, values: h }, e._theme_info.cssVarTheme) {
      const v = this._theme_info.values;
      for (let g in e.xy)
        isNaN(parseInt(v[g])) || (e.xy[g] = parseInt(v[g]));
    }
  }, typeof window < "u" && (e.event(window, "DOMContentLoaded", s), e.event(window, "load", s)), e._border_box_events = function() {
    return n();
  }, e._configure = function(d, r, l) {
    for (var _ in r)
      d[_] === void 0 && (d[_] = r[_][l]);
  }, e.setSkin = function(d) {
    this.skin = d, e._addThemeClass(), e.$container && (this._skin_init(), this.render());
  };
  let o = null;
  e.attachEvent("onDestroy", function() {
    clearInterval(o);
  }), e._skin_init = function() {
    this._build_skin_info(), this.skin || (this.skin = this._theme_info.theme), e._addThemeClass(), e.skin === "flat" ? e.templates.hour_scale = a : e.templates.hour_scale === a && (e.templates.hour_scale = e.date.date_to_str(e.config.hour_date)), e.attachEvent("onTemplatesReady", function() {
      var d = e.date.date_to_str("%d");
      e.templates._old_month_day || (e.templates._old_month_day = e.templates.month_day);
      var r = e.templates._old_month_day;
      e.templates.month_day = function(l) {
        if (this._mode == "month") {
          var _ = d(l);
          return l.getDate() == 1 && (_ = e.locale.date.month_full[l.getMonth()] + " " + _), +l == +e.date.date_part(this._currentDate()) && (_ = e.locale.labels.dhx_cal_today_button + " " + _), _;
        }
        return r.call(this, l);
      }, e.config.fix_tab_position && (e._els.dhx_cal_navline[0].querySelectorAll("[data-tab]").forEach((l) => {
        switch (l.getAttribute("data-tab") || l.getAttribute("name")) {
          case "day":
          case "day_tab":
            l.classList.add("dhx_cal_tab_first"), l.classList.add("dhx_cal_tab_segmented");
            break;
          case "week":
          case "week_tab":
            l.classList.add("dhx_cal_tab_segmented");
            break;
          case "month":
          case "month_tab":
            l.classList.add("dhx_cal_tab_last"), l.classList.add("dhx_cal_tab_segmented");
            break;
          default:
            l.classList.add("dhx_cal_tab_standalone");
        }
      }), function(l) {
        if (e.config.header)
          return;
        const _ = Array.from(l.querySelectorAll(".dhx_cal_tab")), h = ["day", "week", "month"].map((v) => _.find((g) => g.getAttribute("data-tab") === v)).filter((v) => v !== void 0);
        let p = _.length > 0 ? _[0] : null;
        h.reverse().forEach((v) => {
          l.insertBefore(v, p), p = v;
        });
      }(e._els.dhx_cal_navline[0]));
    }, { once: !0 });
  };
}
function ta(e, i) {
  this.$scheduler = e, this.$dp = i, this._dataProcessorHandlers = [], this.attach = function() {
    var t = this.$dp, n = this.$scheduler;
    this._dataProcessorHandlers.push(n.attachEvent("onEventAdded", function(s) {
      !this._loading && this._validId(s) && t.setUpdated(s, !0, "inserted");
    })), this._dataProcessorHandlers.push(n.attachEvent("onConfirmedBeforeEventDelete", function(s) {
      if (this._validId(s)) {
        var a = t.getState(s);
        return a == "inserted" || this._new_event ? (t.setUpdated(s, !1), !0) : a != "deleted" && (a == "true_deleted" || (t.setUpdated(s, !0, "deleted"), !1));
      }
    })), this._dataProcessorHandlers.push(n.attachEvent("onEventChanged", function(s) {
      !this._loading && this._validId(s) && t.setUpdated(s, !0, "updated");
    })), this._dataProcessorHandlers.push(n.attachEvent("onClearAll", function() {
      t._in_progress = {}, t._invalid = {}, t.updatedRows = [], t._waitMode = 0;
    })), t.attachEvent("insertCallback", n._update_callback), t.attachEvent("updateCallback", n._update_callback), t.attachEvent("deleteCallback", function(s, a) {
      n.getEvent(a) ? (n.setUserData(a, this.action_param, "true_deleted"), n.deleteEvent(a)) : n._add_rec_marker && n._update_callback(s, a);
    });
  }, this.detach = function() {
    for (var t in this._dataProcessorHandlers) {
      var n = this._dataProcessorHandlers[t];
      this.$scheduler.detachEvent(n);
    }
    this._dataProcessorHandlers = [];
  };
}
function $e(e) {
  return this.serverProcessor = e, this.action_param = "!nativeeditor_status", this.object = null, this.updatedRows = [], this.autoUpdate = !0, this.updateMode = "cell", this._tMode = "GET", this._headers = null, this._payload = null, this.post_delim = "_", this._waitMode = 0, this._in_progress = {}, this._invalid = {}, this.messages = [], this.styles = { updated: "font-weight:bold;", inserted: "font-weight:bold;", deleted: "text-decoration : line-through;", invalid: "background-color:FFE0E0;", invalid_cell: "border-bottom:2px solid red;", error: "color:red;", clear: "font-weight:normal;text-decoration:none;" }, this.enableUTFencoding(!0), Ye(this), this;
}
function aa(e) {
  var i = "data-dhxbox", t = null;
  function n(u, y, w) {
    var D = u.callback;
    D && D(y, w), g.hide(u.box), t = u.box = null;
  }
  function s(u) {
    if (t) {
      var y = u.which || u.keyCode, w = !1;
      if (c.keyboard) {
        if (y == 13 || y == 32) {
          var D = u.target || u.srcElement;
          he.getClassName(D).indexOf("scheduler_popup_button") > -1 && D.click ? D.click() : (n(t, !0), w = !0);
        }
        y == 27 && (n(t, !1), w = !0);
      }
      return w ? (u.preventDefault && u.preventDefault(), !(u.cancelBubble = !0)) : void 0;
    }
  }
  function a(u) {
    a.cover || (a.cover = document.createElement("div"), e.event(a.cover, "keydown", s), a.cover.className = "dhx_modal_cover", document.body.appendChild(a.cover)), a.cover.style.display = u ? "inline-block" : "none";
  }
  function o(u, y, w) {
    var D = e._waiAria.messageButtonAttrString(u), M = (y || "").toLowerCase().replace(/ /g, "_");
    return `<div ${D} class='scheduler_popup_button dhtmlx_popup_button ${`scheduler_${M}_button dhtmlx_${M}_button`}' data-result='${w}' result='${w}' ><div>${u}</div></div>`;
  }
  function d() {
    for (var u = [].slice.apply(arguments, [0]), y = 0; y < u.length; y++)
      if (u[y])
        return u[y];
  }
  function r(u, y, w) {
    var D = u.tagName ? u : function(N, m, x) {
      var b = document.createElement("div"), E = ne.uid();
      e._waiAria.messageModalAttr(b, E), b.className = " scheduler_modal_box dhtmlx_modal_box scheduler-" + N.type + " dhtmlx-" + N.type, b.setAttribute(i, 1);
      var S = "";
      if (N.width && (b.style.width = N.width), N.height && (b.style.height = N.height), N.title && (S += '<div class="scheduler_popup_title dhtmlx_popup_title">' + N.title + "</div>"), S += '<div class="scheduler_popup_text dhtmlx_popup_text" id="' + E + '"><span>' + (N.content ? "" : N.text) + '</span></div><div  class="scheduler_popup_controls dhtmlx_popup_controls">', m && (S += o(d(N.ok, e.locale.labels.message_ok, "OK"), "ok", !0)), x && (S += o(d(N.cancel, e.locale.labels.message_cancel, "Cancel"), "cancel", !1)), N.buttons)
        for (var T = 0; T < N.buttons.length; T++) {
          var C = N.buttons[T];
          S += typeof C == "object" ? o(C.label, C.css || "scheduler_" + C.label.toLowerCase() + "_button dhtmlx_" + C.label.toLowerCase() + "_button", C.value || T) : o(C, C, T);
        }
      if (S += "</div>", b.innerHTML = S, N.content) {
        var A = N.content;
        typeof A == "string" && (A = document.getElementById(A)), A.style.display == "none" && (A.style.display = ""), b.childNodes[N.title ? 1 : 0].appendChild(A);
      }
      return e.event(b, "click", function($) {
        var H = $.target || $.srcElement;
        if (H.className || (H = H.parentNode), he.closest(H, ".scheduler_popup_button")) {
          var O = H.getAttribute("data-result");
          n(N, O = O == "true" || O != "false" && O, $);
        }
      }), N.box = b, (m || x) && (t = N), b;
    }(u, y, w);
    u.hidden || a(!0), document.body.appendChild(D);
    var M = Math.abs(Math.floor(((window.innerWidth || document.documentElement.offsetWidth) - D.offsetWidth) / 2)), k = Math.abs(Math.floor(((window.innerHeight || document.documentElement.offsetHeight) - D.offsetHeight) / 2));
    return u.position == "top" ? D.style.top = "-3px" : D.style.top = k + "px", D.style.left = M + "px", e.event(D, "keydown", s), g.focus(D), u.hidden && g.hide(D), e.callEvent("onMessagePopup", [D]), D;
  }
  function l(u) {
    return r(u, !0, !1);
  }
  function _(u) {
    return r(u, !0, !0);
  }
  function h(u) {
    return r(u);
  }
  function p(u, y, w) {
    return typeof u != "object" && (typeof y == "function" && (w = y, y = ""), u = { text: u, type: y, callback: w }), u;
  }
  function v(u, y, w, D, M) {
    return typeof u != "object" && (u = { text: u, type: y, expire: w, id: D, callback: M }), u.id = u.id || ne.uid(), u.expire = u.expire || c.expire, u;
  }
  typeof window < "u" && e.event(document, "keydown", s, !0);
  var g = function() {
    var u = p.apply(this, arguments);
    return u.type = u.type || "alert", h(u);
  };
  g.hide = function(u) {
    for (; u && u.getAttribute && !u.getAttribute(i); )
      u = u.parentNode;
    u && (u.parentNode.removeChild(u), a(!1), e.callEvent("onAfterMessagePopup", [u]));
  }, g.focus = function(u) {
    setTimeout(function() {
      var y = he.getFocusableNodes(u);
      y.length && y[0].focus && y[0].focus();
    }, 1);
  };
  var c = function(u, y, w, D) {
    switch ((u = v.apply(this, arguments)).type = u.type || "info", u.type.split("-")[0]) {
      case "alert":
        return l(u);
      case "confirm":
        return _(u);
      case "modalbox":
        return h(u);
      default:
        return function(M) {
          c.area || (c.area = document.createElement("div"), c.area.className = "scheduler_message_area dhtmlx_message_area", c.area.style[c.position] = "5px", document.body.appendChild(c.area)), c.hide(M.id);
          var k = document.createElement("div");
          return k.innerHTML = "<div>" + M.text + "</div>", k.className = "scheduler-info dhtmlx-info scheduler-" + M.type + " dhtmlx-" + M.type, e.event(k, "click", function(N) {
            M.callback && M.callback.call(this, N), c.hide(M.id), M = null;
          }), e._waiAria.messageInfoAttr(k), c.position == "bottom" && c.area.firstChild ? c.area.insertBefore(k, c.area.firstChild) : c.area.appendChild(k), M.expire > 0 && (c.timers[M.id] = window.setTimeout(function() {
            c && c.hide(M.id);
          }, M.expire)), c.pull[M.id] = k, k = null, M.id;
        }(u);
    }
  };
  c.seed = (/* @__PURE__ */ new Date()).valueOf(), c.uid = ne.uid, c.expire = 4e3, c.keyboard = !0, c.position = "top", c.pull = {}, c.timers = {}, c.hideAll = function() {
    for (var u in c.pull)
      c.hide(u);
  }, c.hide = function(u) {
    var y = c.pull[u];
    y && y.parentNode && (window.setTimeout(function() {
      y.parentNode.removeChild(y), y = null;
    }, 2e3), y.className += " hidden", c.timers[u] && window.clearTimeout(c.timers[u]), delete c.pull[u]);
  };
  var f = [];
  return e.attachEvent("onMessagePopup", function(u) {
    f.push(u);
  }), e.attachEvent("onAfterMessagePopup", function(u) {
    for (var y = 0; y < f.length; y++)
      f[y] === u && (f.splice(y, 1), y--);
  }), e.attachEvent("onDestroy", function() {
    a.cover && a.cover.parentNode && a.cover.parentNode.removeChild(a.cover);
    for (var u = 0; u < f.length; u++)
      f[u].parentNode && f[u].parentNode.removeChild(f[u]);
    f = null, c.area && c.area.parentNode && c.area.parentNode.removeChild(c.area), c = null;
  }), { alert: function() {
    var u = p.apply(this, arguments);
    return u.type = u.type || "confirm", l(u);
  }, confirm: function() {
    var u = p.apply(this, arguments);
    return u.type = u.type || "alert", _(u);
  }, message: c, modalbox: g };
}
$e.prototype = { setTransactionMode: function(e, i) {
  typeof e == "object" ? (this._tMode = e.mode || this._tMode, e.headers !== void 0 && (this._headers = e.headers), e.payload !== void 0 && (this._payload = e.payload), this._tSend = !!i) : (this._tMode = e, this._tSend = i), this._tMode == "REST" && (this._tSend = !1, this._endnm = !0), this._tMode === "JSON" || this._tMode === "REST-JSON" ? (this._tSend = !1, this._endnm = !0, this._serializeAsJson = !0, this._headers = this._headers || {}, this._headers["Content-Type"] = "application/json") : this._headers && !this._headers["Content-Type"] && (this._headers["Content-Type"] = "application/x-www-form-urlencoded"), this._tMode === "CUSTOM" && (this._tSend = !1, this._endnm = !0, this._router = e.router);
}, escape: function(e) {
  return this._utf ? encodeURIComponent(e) : escape(e);
}, enableUTFencoding: function(e) {
  this._utf = !!e;
}, setDataColumns: function(e) {
  this._columns = typeof e == "string" ? e.split(",") : e;
}, getSyncState: function() {
  return !this.updatedRows.length;
}, enableDataNames: function(e) {
  this._endnm = !!e;
}, enablePartialDataSend: function(e) {
  this._changed = !!e;
}, setUpdateMode: function(e, i) {
  this.autoUpdate = e == "cell", this.updateMode = e, this.dnd = i;
}, ignore: function(e, i) {
  this._silent_mode = !0, e.call(i || window), this._silent_mode = !1;
}, setUpdated: function(e, i, t) {
  if (!this._silent_mode) {
    var n = this.findRow(e);
    t = t || "updated";
    var s = this.$scheduler.getUserData(e, this.action_param);
    s && t == "updated" && (t = s), i ? (this.set_invalid(e, !1), this.updatedRows[n] = e, this.$scheduler.setUserData(e, this.action_param, t), this._in_progress[e] && (this._in_progress[e] = "wait")) : this.is_invalid(e) || (this.updatedRows.splice(n, 1), this.$scheduler.setUserData(e, this.action_param, "")), this.markRow(e, i, t), i && this.autoUpdate && this.sendData(e);
  }
}, markRow: function(e, i, t) {
  var n = "", s = this.is_invalid(e);
  if (s && (n = this.styles[s], i = !0), this.callEvent("onRowMark", [e, i, t, s]) && (n = this.styles[i ? t : "clear"] + n, this.$scheduler[this._methods[0]](e, n), s && s.details)) {
    n += this.styles[s + "_cell"];
    for (var a = 0; a < s.details.length; a++)
      s.details[a] && this.$scheduler[this._methods[1]](e, a, n);
  }
}, getActionByState: function(e) {
  return e === "inserted" ? "create" : e === "updated" ? "update" : e === "deleted" ? "delete" : "update";
}, getState: function(e) {
  return this.$scheduler.getUserData(e, this.action_param);
}, is_invalid: function(e) {
  return this._invalid[e];
}, set_invalid: function(e, i, t) {
  t && (i = { value: i, details: t, toString: function() {
    return this.value.toString();
  } }), this._invalid[e] = i;
}, checkBeforeUpdate: function(e) {
  return !0;
}, sendData: function(e) {
  return this.$scheduler.editStop && this.$scheduler.editStop(), e === void 0 || this._tSend ? this.sendAllData() : !this._in_progress[e] && (this.messages = [], !(!this.checkBeforeUpdate(e) && this.callEvent("onValidationError", [e, this.messages])) && void this._beforeSendData(this._getRowData(e), e));
}, _beforeSendData: function(e, i) {
  if (!this.callEvent("onBeforeUpdate", [i, this.getState(i), e]))
    return !1;
  this._sendData(e, i);
}, serialize: function(e, i) {
  if (this._serializeAsJson)
    return this._serializeAsJSON(e);
  if (typeof e == "string")
    return e;
  if (i !== void 0)
    return this.serialize_one(e, "");
  var t = [], n = [];
  for (var s in e)
    e.hasOwnProperty(s) && (t.push(this.serialize_one(e[s], s + this.post_delim)), n.push(s));
  return t.push("ids=" + this.escape(n.join(","))), this.$scheduler.security_key && t.push("dhx_security=" + this.$scheduler.security_key), t.join("&");
}, serialize_one: function(e, i) {
  if (typeof e == "string")
    return e;
  var t = [], n = "";
  for (var s in e)
    if (e.hasOwnProperty(s)) {
      if ((s == "id" || s == this.action_param) && this._tMode == "REST")
        continue;
      n = typeof e[s] == "string" || typeof e[s] == "number" ? e[s] : JSON.stringify(e[s]), t.push(this.escape((i || "") + s) + "=" + this.escape(n));
    }
  return t.join("&");
}, _applyPayload: function(e) {
  var i = this.$scheduler.ajax;
  if (this._payload)
    for (var t in this._payload)
      e = e + i.urlSeparator(e) + this.escape(t) + "=" + this.escape(this._payload[t]);
  return e;
}, _sendData: function(e, i) {
  if (e) {
    if (!this.callEvent("onBeforeDataSending", i ? [i, this.getState(i), e] : [null, null, e]))
      return !1;
    i && (this._in_progress[i] = (/* @__PURE__ */ new Date()).valueOf());
    var t = this, n = this.$scheduler.ajax;
    if (this._tMode === "CUSTOM") {
      var s = this.getState(i), a = this.getActionByState(s);
      delete e[this.action_param];
      var o = function(c) {
        var f = s;
        if (c && c.responseText && c.setRequestHeader) {
          c.status !== 200 && (f = "error");
          try {
            c = JSON.parse(c.responseText);
          } catch {
          }
        }
        f = f || "updated";
        var u = i, y = i;
        c && (f = c.action || f, u = c.sid || u, y = c.id || c.tid || y), t.afterUpdateCallback(u, y, f, c);
      };
      const g = "event";
      var d;
      if (this._router instanceof Function)
        d = this._router(g, a, e, i);
      else
        switch (s) {
          case "inserted":
            d = this._router[g].create(e);
            break;
          case "deleted":
            d = this._router[g].delete(i);
            break;
          default:
            d = this._router[g].update(e, i);
        }
      if (d) {
        if (!d.then && d.id === void 0 && d.tid === void 0 && d.action === void 0)
          throw new Error("Incorrect router return value. A Promise or a response object is expected");
        d.then ? d.then(o).catch(function(c) {
          c && c.action ? o(c) : o({ action: "error", value: c });
        }) : o(d);
      } else
        o(null);
      return;
    }
    var r, l = { callback: function(g) {
      var c = [];
      if (i)
        c.push(i);
      else if (e)
        for (var f in e)
          c.push(f);
      return t.afterUpdate(t, g, c);
    }, headers: t._headers }, _ = this.serverProcessor + (this._user ? n.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + this.$scheduler.getUserData(0, "version")].join("&") : ""), h = this._applyPayload(_);
    switch (this._tMode) {
      case "GET":
        r = this._cleanupArgumentsBeforeSend(e), l.url = h + n.urlSeparator(h) + this.serialize(r, i), l.method = "GET";
        break;
      case "POST":
        r = this._cleanupArgumentsBeforeSend(e), l.url = h, l.method = "POST", l.data = this.serialize(r, i);
        break;
      case "JSON":
        r = {};
        var p = this._cleanupItemBeforeSend(e);
        for (var v in p)
          v !== this.action_param && v !== "id" && v !== "gr_id" && (r[v] = p[v]);
        l.url = h, l.method = "POST", l.data = JSON.stringify({ id: i, action: e[this.action_param], data: r });
        break;
      case "REST":
      case "REST-JSON":
        switch (h = _.replace(/(&|\?)editing=true/, ""), r = "", this.getState(i)) {
          case "inserted":
            l.method = "POST", l.data = this.serialize(e, i);
            break;
          case "deleted":
            l.method = "DELETE", h = h + (h.slice(-1) === "/" ? "" : "/") + i;
            break;
          default:
            l.method = "PUT", l.data = this.serialize(e, i), h = h + (h.slice(-1) === "/" ? "" : "/") + i;
        }
        l.url = this._applyPayload(h);
    }
    return this._waitMode++, n.query(l);
  }
}, sendAllData: function() {
  if (this.updatedRows.length && this.updateMode !== "off") {
    this.messages = [];
    var e = !0;
    if (this._forEachUpdatedRow(function(i) {
      e = e && this.checkBeforeUpdate(i);
    }), !e && !this.callEvent("onValidationError", ["", this.messages]))
      return !1;
    this._tSend ? this._sendData(this._getAllData()) : this._forEachUpdatedRow(function(i) {
      if (!this._in_progress[i]) {
        if (this.is_invalid(i))
          return;
        this._beforeSendData(this._getRowData(i), i);
      }
    });
  }
}, _getAllData: function(e) {
  var i = {}, t = !1;
  return this._forEachUpdatedRow(function(n) {
    if (!this._in_progress[n] && !this.is_invalid(n)) {
      var s = this._getRowData(n);
      this.callEvent("onBeforeUpdate", [n, this.getState(n), s]) && (i[n] = s, t = !0, this._in_progress[n] = (/* @__PURE__ */ new Date()).valueOf());
    }
  }), t ? i : null;
}, findRow: function(e) {
  var i = 0;
  for (i = 0; i < this.updatedRows.length && e != this.updatedRows[i]; i++)
    ;
  return i;
}, defineAction: function(e, i) {
  this._uActions || (this._uActions = {}), this._uActions[e] = i;
}, afterUpdateCallback: function(e, i, t, n) {
  if (this.$scheduler) {
    var s = e, a = t !== "error" && t !== "invalid";
    if (a || this.set_invalid(e, t), this._uActions && this._uActions[t] && !this._uActions[t](n))
      return delete this._in_progress[s];
    this._in_progress[s] !== "wait" && this.setUpdated(e, !1);
    var o = e;
    switch (t) {
      case "inserted":
      case "insert":
        i != e && (this.setUpdated(e, !1), this.$scheduler[this._methods[2]](e, i), e = i);
        break;
      case "delete":
      case "deleted":
        return this.$scheduler.setUserData(e, this.action_param, "true_deleted"), this.$scheduler[this._methods[3]](e, i), delete this._in_progress[s], this.callEvent("onAfterUpdate", [e, t, i, n]);
    }
    this._in_progress[s] !== "wait" ? (a && this.$scheduler.setUserData(e, this.action_param, ""), delete this._in_progress[s]) : (delete this._in_progress[s], this.setUpdated(i, !0, this.$scheduler.getUserData(e, this.action_param))), this.callEvent("onAfterUpdate", [o, t, i, n]);
  }
}, _errorResponse: function(e, i) {
  return this.$scheduler && this.$scheduler.callEvent && this.$scheduler.callEvent("onSaveError", [i, e.xmlDoc]), this.cleanUpdate(i);
}, _setDefaultTransactionMode: function() {
  this.serverProcessor && (this.setTransactionMode("POST", !0), this.serverProcessor += (this.serverProcessor.indexOf("?") !== -1 ? "&" : "?") + "editing=true", this._serverProcessor = this.serverProcessor);
}, afterUpdate: function(e, i, t) {
  var n = this.$scheduler.ajax;
  if (i.xmlDoc.status === 200) {
    var s;
    try {
      s = JSON.parse(i.xmlDoc.responseText);
    } catch {
      i.xmlDoc.responseText.length || (s = {});
    }
    if (s) {
      var a = s.action || this.getState(t) || "updated", o = s.sid || t[0], d = s.tid || t[0];
      return e.afterUpdateCallback(o, d, a, s), void e.finalizeUpdate();
    }
    var r = n.xmltop("data", i.xmlDoc);
    if (!r)
      return this._errorResponse(i, t);
    var l = n.xpath("//data/action", r);
    if (!l.length)
      return this._errorResponse(i, t);
    for (var _ = 0; _ < l.length; _++) {
      var h = l[_];
      a = h.getAttribute("type"), o = h.getAttribute("sid"), d = h.getAttribute("tid"), e.afterUpdateCallback(o, d, a, h);
    }
    e.finalizeUpdate();
  } else
    this._errorResponse(i, t);
}, cleanUpdate: function(e) {
  if (e)
    for (var i = 0; i < e.length; i++)
      delete this._in_progress[e[i]];
}, finalizeUpdate: function() {
  this._waitMode && this._waitMode--, this.callEvent("onAfterUpdateFinish", []), this.updatedRows.length || this.callEvent("onFullSync", []);
}, init: function(e) {
  if (!this._initialized) {
    this.$scheduler = e, this.$scheduler._dp_init && this.$scheduler._dp_init(this), this._setDefaultTransactionMode(), this._methods = this._methods || ["_set_event_text_style", "", "_dp_change_event_id", "_dp_hook_delete"], function(t, n) {
      t._validId = function(s) {
        return !this._is_virtual_event || !this._is_virtual_event(s);
      }, t.setUserData = function(s, a, o) {
        if (s) {
          var d = this.getEvent(s);
          d && (d[a] = o);
        } else
          this._userdata[a] = o;
      }, t.getUserData = function(s, a) {
        if (s) {
          var o = this.getEvent(s);
          return o ? o[a] : null;
        }
        return this._userdata[a];
      }, t._set_event_text_style = function(s, a) {
        if (t.getEvent(s)) {
          this.for_rendered(s, function(d) {
            d.style.cssText += ";" + a;
          });
          var o = this.getEvent(s);
          o._text_style = a, this.event_updated(o);
        }
      }, t._update_callback = function(s, a) {
        var o = t._xmlNodeToJSON(s.firstChild);
        o.rec_type == "none" && (o.rec_pattern = "none"), o.text = o.text || o._tagvalue, o.start_date = t._helpers.parseDate(o.start_date), o.end_date = t._helpers.parseDate(o.end_date), t.addEvent(o), t._add_rec_marker && t.setCurrentView();
      }, t._dp_change_event_id = function(s, a) {
        t.getEvent(s) && t.changeEventId(s, a);
      }, t._dp_hook_delete = function(s, a) {
        if (t.getEvent(s))
          return a && s != a && (this.getUserData(s, n.action_param) == "true_deleted" && this.setUserData(s, n.action_param, "updated"), this.changeEventId(s, a)), this.deleteEvent(a, !0);
      }, t.setDp = function() {
        this._dp = n;
      }, t.setDp();
    }(this.$scheduler, this);
    var i = new ta(this.$scheduler, this);
    i.attach(), this.attachEvent("onDestroy", function() {
      delete this._getRowData, delete this.$scheduler._dp, delete this.$scheduler._dataprocessor, delete this.$scheduler._set_event_text_style, delete this.$scheduler._dp_change_event_id, delete this.$scheduler._dp_hook_delete, delete this.$scheduler, i.detach();
    }), this.$scheduler.callEvent("onDataProcessorReady", [this]), this._initialized = !0, e._dataprocessor = this;
  }
}, setOnAfterUpdate: function(e) {
  this.attachEvent("onAfterUpdate", e);
}, setOnBeforeUpdateHandler: function(e) {
  this.attachEvent("onBeforeDataSending", e);
}, setAutoUpdate: function(e, i) {
  e = e || 2e3, this._user = i || (/* @__PURE__ */ new Date()).valueOf(), this._need_update = !1, this._update_busy = !1, this.attachEvent("onAfterUpdate", function(s, a, o, d) {
    this.afterAutoUpdate(s, a, o, d);
  }), this.attachEvent("onFullSync", function() {
    this.fullSync();
  });
  var t = this;
  let n = le.setInterval(function() {
    t.loadUpdate();
  }, e);
  this.attachEvent("onDestroy", function() {
    clearInterval(n);
  });
}, afterAutoUpdate: function(e, i, t, n) {
  return i != "collision" || (this._need_update = !0, !1);
}, fullSync: function() {
  return this._need_update && (this._need_update = !1, this.loadUpdate()), !0;
}, getUpdates: function(e, i) {
  var t = this.$scheduler.ajax;
  if (this._update_busy)
    return !1;
  this._update_busy = !0, t.get(e, i);
}, _getXmlNodeValue: function(e) {
  return e.firstChild ? e.firstChild.nodeValue : "";
}, loadUpdate: function() {
  var e = this, i = this.$scheduler.ajax, t = this.$scheduler.getUserData(0, "version"), n = this.serverProcessor + i.urlSeparator(this.serverProcessor) + ["dhx_user=" + this._user, "dhx_version=" + t].join("&");
  n = n.replace("editing=true&", ""), this.getUpdates(n, function(s) {
    var a = i.xpath("//userdata", s);
    e.$scheduler.setUserData(0, "version", e._getXmlNodeValue(a[0]));
    var o = i.xpath("//update", s);
    if (o.length) {
      e._silent_mode = !0;
      for (var d = 0; d < o.length; d++) {
        var r = o[d].getAttribute("status"), l = o[d].getAttribute("id"), _ = o[d].getAttribute("parent");
        switch (r) {
          case "inserted":
            this.callEvent("insertCallback", [o[d], l, _]);
            break;
          case "updated":
            this.callEvent("updateCallback", [o[d], l, _]);
            break;
          case "deleted":
            this.callEvent("deleteCallback", [o[d], l, _]);
        }
      }
      e._silent_mode = !1;
    }
    e._update_busy = !1, e = null;
  });
}, destructor: function() {
  this.callEvent("onDestroy", []), this.detachAllEvents(), this.updatedRows = [], this._in_progress = {}, this._invalid = {}, this._headers = null, this._payload = null, delete this._initialized;
}, url: function(e) {
  this.serverProcessor = this._serverProcessor = e;
}, _serializeAsJSON: function(e) {
  if (typeof e == "string")
    return e;
  var i = this.$scheduler.utils.copy(e);
  return this._tMode === "REST-JSON" && (delete i.id, delete i[this.action_param]), JSON.stringify(i);
}, _cleanupArgumentsBeforeSend: function(e) {
  var i;
  if (e[this.action_param] === void 0)
    for (var t in i = {}, e)
      i[t] = this._cleanupArgumentsBeforeSend(e[t]);
  else
    i = this._cleanupItemBeforeSend(e);
  return i;
}, _cleanupItemBeforeSend: function(e) {
  var i = null;
  return e && (e[this.action_param] === "deleted" ? ((i = {}).id = e.id, i[this.action_param] = e[this.action_param]) : i = e), i;
}, _forEachUpdatedRow: function(e) {
  for (var i = this.updatedRows.slice(), t = 0; t < i.length; t++) {
    var n = i[t];
    this.$scheduler.getUserData(n, this.action_param) && e.call(this, n);
  }
}, _prepareItemForJson(e) {
  const i = {}, t = this.$scheduler, n = t.utils.copy(e);
  for (let s in n) {
    let a = n[s];
    s.indexOf("_") !== 0 && (a ? a.getUTCFullYear ? i[s] = t._helpers.formatDate(a) : i[s] = typeof a == "object" ? this._prepareItemForJson(a) : a : a !== void 0 && (i[s] = a));
  }
  return i[this.action_param] = t.getUserData(e.id, this.action_param), i;
}, _prepareItemForForm(e) {
  const i = {}, t = this.$scheduler, n = t.utils.copy(e);
  for (var s in n) {
    let a = n[s];
    s.indexOf("_") !== 0 && (a ? a.getUTCFullYear ? i[s] = t._helpers.formatDate(a) : i[s] = typeof a == "object" ? this._prepareItemForForm(a) : a : i[s] = "");
  }
  return i[this.action_param] = t.getUserData(e.id, this.action_param), i;
}, _prepareDataItem: function(e) {
  return this._serializeAsJson ? this._prepareItemForJson(e) : this._prepareItemForForm(e);
}, _getRowData: function(e) {
  var i = this.$scheduler.getEvent(e);
  return i || (i = { id: e }), this._prepareDataItem(i);
} };
class na {
  constructor(i) {
    this._locales = {};
    for (const t in i)
      this._locales[t] = i[t];
  }
  addLocale(i, t) {
    this._locales[i] = t;
  }
  getLocale(i) {
    return this._locales[i];
  }
}
const ra = Object.freeze(Object.defineProperty({ __proto__: null, ar: { date: { month_full: ["كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"], month_short: ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"], day_full: ["الأحد", "الأثنين", "ألثلاثاء", "الأربعاء", "ألحميس", "ألجمعة", "السبت"], day_short: ["احد", "اثنين", "ثلاثاء", "اربعاء", "خميس", "جمعة", "سبت"] }, labels: { dhx_cal_today_button: "اليوم", day_tab: "يوم", week_tab: "أسبوع", month_tab: "شهر", new_event: "حدث جديد", icon_save: "اخزن", icon_cancel: "الغاء", icon_details: "تفاصيل", icon_edit: "تحرير", icon_delete: "حذف", confirm_closing: "التغييرات سوف تضيع, هل انت متأكد؟", confirm_deleting: "الحدث سيتم حذفها نهائيا ، هل أنت متأكد؟", section_description: "الوصف", section_time: "الفترة الزمنية", full_day: "طوال اليوم", confirm_recurring: "هل تريد تحرير مجموعة كاملة من الأحداث المتكررة؟", section_recurring: "تكرار الحدث", button_recurring: "تعطيل", button_recurring_open: "تمكين", button_edit_series: "تحرير سلسلة", button_edit_occurrence: "تعديل نسخة", button_edit_occurrence_and_following: "This and following events", grid_tab: "جدول", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "يومي", repeat_radio_week: "أسبوعي", repeat_radio_month: "شهري", repeat_radio_year: "سنوي", repeat_radio_day_type: "كل", repeat_text_day_count: "يوم", repeat_radio_day_type2: "كل يوم عمل", repeat_week: " تكرار كل", repeat_text_week_count: "أسبوع في الأيام التالية:", repeat_radio_month_type: "تكرار", repeat_radio_month_start: "في", repeat_text_month_day: "يوم كل", repeat_text_month_count: "شهر", repeat_text_month_count2_before: "كل", repeat_text_month_count2_after: "شهر", repeat_year_label: "في", select_year_day2: "من", repeat_text_year_day: "يوم", select_year_month: "شهر", repeat_radio_end: "بدون تاريخ انتهاء", repeat_text_occurrences_count: "تكرارات", repeat_radio_end2: "بعد", repeat_radio_end3: "ينتهي في", repeat_never: "أبداً", repeat_daily: "كل يوم", repeat_workdays: "كل يوم عمل", repeat_weekly: "كل أسبوع", repeat_monthly: "كل شهر", repeat_yearly: "كل سنة", repeat_custom: "تخصيص", repeat_freq_day: "يوم", repeat_freq_week: "أسبوع", repeat_freq_month: "شهر", repeat_freq_year: "سنة", repeat_on_date: "في التاريخ", repeat_ends: "ينتهي", month_for_recurring: ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"], day_for_recurring: ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"] } }, be: { date: { month_full: ["Студзень", "Люты", "Сакавік", "Красавік", "Maй", "Чэрвень", "Ліпень", "Жнівень", "Верасень", "Кастрычнік", "Лістапад", "Снежань"], month_short: ["Студз", "Лют", "Сак", "Крас", "Maй", "Чэр", "Ліп", "Жнів", "Вер", "Каст", "Ліст", "Снеж"], day_full: ["Нядзеля", "Панядзелак", "Аўторак", "Серада", "Чацвер", "Пятніца", "Субота"], day_short: ["Нд", "Пн", "Аўт", "Ср", "Чцв", "Пт", "Сб"] }, labels: { dhx_cal_today_button: "Сёння", day_tab: "Дзень", week_tab: "Тыдзень", month_tab: "Месяц", new_event: "Новая падзея", icon_save: "Захаваць", icon_cancel: "Адмяніць", icon_details: "Дэталі", icon_edit: "Змяніць", icon_delete: "Выдаліць", confirm_closing: "", confirm_deleting: "Падзея будзе выдалена незваротна, працягнуць?", section_description: "Апісанне", section_time: "Перыяд часу", full_day: "Увесь дзень", confirm_recurring: "Вы хочаце змяніць усю серыю паўтаральных падзей?", section_recurring: "Паўтарэнне", button_recurring: "Адключана", button_recurring_open: "Уключана", button_edit_series: "Рэдагаваць серыю", button_edit_occurrence: "Рэдагаваць асобнік", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Спіс", date: "Дата", description: "Апісанне", year_tab: "Год", week_agenda_tab: "Спіс", grid_tab: "Спic", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Дзень", repeat_radio_week: "Тыдзень", repeat_radio_month: "Месяц", repeat_radio_year: "Год", repeat_radio_day_type: "Кожны", repeat_text_day_count: "дзень", repeat_radio_day_type2: "Кожны працоўны дзень", repeat_week: " Паўтараць кожны", repeat_text_week_count: "тыдзень", repeat_radio_month_type: "Паўтараць", repeat_radio_month_start: "", repeat_text_month_day: " чысла кожнага", repeat_text_month_count: "месяцу", repeat_text_month_count2_before: "кожны ", repeat_text_month_count2_after: "месяц", repeat_year_label: "", select_year_day2: "", repeat_text_year_day: "дзень", select_year_month: "", repeat_radio_end: "Без даты заканчэння", repeat_text_occurrences_count: "паўтораў", repeat_radio_end2: "", repeat_radio_end3: "Да ", repeat_never: "Ніколі", repeat_daily: "Кожны дзень", repeat_workdays: "Кожны працоўны дзень", repeat_weekly: "Кожны тыдзень", repeat_monthly: "Кожны месяц", repeat_yearly: "Кожны год", repeat_custom: "Наладжвальны", repeat_freq_day: "Дзень", repeat_freq_week: "Тыдзень", repeat_freq_month: "Месяц", repeat_freq_year: "Год", repeat_on_date: "На дату", repeat_ends: "Заканчваецца", month_for_recurring: ["Студзеня", "Лютага", "Сакавіка", "Красавіка", "Мая", "Чэрвеня", "Ліпeня", "Жніўня", "Верасня", "Кастрычніка", "Лістапада", "Снежня"], day_for_recurring: ["Нядзелю", "Панядзелак", "Аўторак", "Сераду", "Чацвер", "Пятніцу", "Суботу"] } }, ca: { date: { month_full: ["Gener", "Febrer", "Març", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"], month_short: ["Gen", "Feb", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Oct", "Nov", "Des"], day_full: ["Diumenge", "Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres", "Dissabte"], day_short: ["Dg", "Dl", "Dm", "Dc", "Dj", "Dv", "Ds"] }, labels: { dhx_cal_today_button: "Hui", day_tab: "Dia", week_tab: "Setmana", month_tab: "Mes", new_event: "Nou esdeveniment", icon_save: "Guardar", icon_cancel: "Cancel·lar", icon_details: "Detalls", icon_edit: "Editar", icon_delete: "Esborrar", confirm_closing: "", confirm_deleting: "L'esdeveniment s'esborrarà definitivament, continuar ?", section_description: "Descripció", section_time: "Periode de temps", full_day: "Tot el dia", confirm_recurring: "¿Desitja modificar el conjunt d'esdeveniments repetits?", section_recurring: "Repeteixca l'esdeveniment", button_recurring: "Impedit", button_recurring_open: "Permés", button_edit_series: "Edit sèrie", button_edit_occurrence: "Edita Instància", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Data", description: "Descripció", year_tab: "Any", week_agenda_tab: "Agenda", grid_tab: "Taula", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Diari", repeat_radio_week: "Setmanal", repeat_radio_month: "Mensual", repeat_radio_year: "Anual", repeat_radio_day_type: "Cada", repeat_text_day_count: "dia", repeat_radio_day_type2: "Cada dia laborable", repeat_week: " Repetir cada", repeat_text_week_count: "setmana els dies següents:", repeat_radio_month_type: "Repetir", repeat_radio_month_start: "El", repeat_text_month_day: "dia cada", repeat_text_month_count: "mes", repeat_text_month_count2_before: "cada", repeat_text_month_count2_after: "mes", repeat_year_label: "El", select_year_day2: "de", repeat_text_year_day: "dia", select_year_month: "mes", repeat_radio_end: "Sense data de finalització", repeat_text_occurrences_count: "ocurrències", repeat_radio_end2: "Després", repeat_radio_end3: "Finalitzar el", repeat_never: "Mai", repeat_daily: "Cada dia", repeat_workdays: "Cada dia laborable", repeat_weekly: "Cada setmana", repeat_monthly: "Cada mes", repeat_yearly: "Cada any", repeat_custom: "Personalitzat", repeat_freq_day: "Dia", repeat_freq_week: "Setmana", repeat_freq_month: "Mes", repeat_freq_year: "Any", repeat_on_date: "En la data", repeat_ends: "Finalitza", month_for_recurring: ["Gener", "Febrer", "Març", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"], day_for_recurring: ["Diumenge", "Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres", "Dissabte"] } }, cn: { date: { month_full: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"], month_short: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], day_full: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"], day_short: ["日", "一", "二", "三", "四", "五", "六"] }, labels: { dhx_cal_today_button: "今天", day_tab: "日", week_tab: "周", month_tab: "月", new_event: "新建日程", icon_save: "保存", icon_cancel: "关闭", icon_details: "详细", icon_edit: "编辑", icon_delete: "删除", confirm_closing: "请确认是否撤销修改!", confirm_deleting: "是否删除日程?", section_description: "描述", section_time: "时间范围", full_day: "整天", confirm_recurring: "请确认是否将日程设为重复模式?", section_recurring: "重复周期", button_recurring: "禁用", button_recurring_open: "启用", button_edit_series: "编辑系列", button_edit_occurrence: "编辑实例", button_edit_occurrence_and_following: "This and following events", agenda_tab: "议程", date: "日期", description: "说明", year_tab: "今年", week_agenda_tab: "议程", grid_tab: "电网", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "按天", repeat_radio_week: "按周", repeat_radio_month: "按月", repeat_radio_year: "按年", repeat_radio_day_type: "每", repeat_text_day_count: "天", repeat_radio_day_type2: "每个工作日", repeat_week: " 重复 每", repeat_text_week_count: "星期的:", repeat_radio_month_type: "重复", repeat_radio_month_start: "在", repeat_text_month_day: "日 每", repeat_text_month_count: "月", repeat_text_month_count2_before: "每", repeat_text_month_count2_after: "月", repeat_year_label: "在", select_year_day2: "的", repeat_text_year_day: "日", select_year_month: "月", repeat_radio_end: "无结束日期", repeat_text_occurrences_count: "次结束", repeat_radio_end2: "重复", repeat_radio_end3: "结束于", repeat_never: "从不", repeat_daily: "每天", repeat_workdays: "每个工作日", repeat_weekly: "每周", repeat_monthly: "每月", repeat_yearly: "每年", repeat_custom: "自定义", repeat_freq_day: "天", repeat_freq_week: "周", repeat_freq_month: "月", repeat_freq_year: "年", repeat_on_date: "在日期", repeat_ends: "结束", month_for_recurring: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"], day_for_recurring: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"] } }, cs: { date: { month_full: ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"], month_short: ["Led", "Ún", "Bře", "Dub", "Kvě", "Čer", "Čec", "Srp", "Září", "Říj", "List", "Pro"], day_full: ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"], day_short: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"] }, labels: { dhx_cal_today_button: "Dnes", day_tab: "Den", week_tab: "Týden", month_tab: "Měsíc", new_event: "Nová událost", icon_save: "Uložit", icon_cancel: "Zpět", icon_details: "Detail", icon_edit: "Edituj", icon_delete: "Smazat", confirm_closing: "", confirm_deleting: "Událost bude trvale smazána, opravdu?", section_description: "Poznámky", section_time: "Doba platnosti", confirm_recurring: "Přejete si upravit celou řadu opakovaných událostí?", section_recurring: "Opakování události", button_recurring: "Vypnuto", button_recurring_open: "Zapnuto", button_edit_series: "Edit series", button_edit_occurrence: "Upravit instance", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Program", date: "Datum", description: "Poznámka", year_tab: "Rok", full_day: "Full day", week_agenda_tab: "Program", grid_tab: "Mřížka", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Denně", repeat_radio_week: "Týdně", repeat_radio_month: "Měsíčně", repeat_radio_year: "Ročně", repeat_radio_day_type: "každý", repeat_text_day_count: "Den", repeat_radio_day_type2: "pracovní dny", repeat_week: "Opakuje každých", repeat_text_week_count: "Týdnů na:", repeat_radio_month_type: "u každého", repeat_radio_month_start: "na", repeat_text_month_day: "Den každého", repeat_text_month_count: "Měsíc", repeat_text_month_count2_before: "každý", repeat_text_month_count2_after: "Měsíc", repeat_year_label: "na", select_year_day2: "v", repeat_text_year_day: "Den v", select_year_month: "", repeat_radio_end: "bez data ukončení", repeat_text_occurrences_count: "Události", repeat_radio_end2: "po", repeat_radio_end3: "Konec", repeat_never: "Nikdy", repeat_daily: "Každý den", repeat_workdays: "Každý pracovní den", repeat_weekly: "Každý týden", repeat_monthly: "Každý měsíc", repeat_yearly: "Každý rok", repeat_custom: "Vlastní", repeat_freq_day: "Den", repeat_freq_week: "Týden", repeat_freq_month: "Měsíc", repeat_freq_year: "Rok", repeat_on_date: "Na datum", repeat_ends: "Končí", month_for_recurring: ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"], day_for_recurring: ["Neděle ", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"] } }, da: { date: { month_full: ["Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"], day_short: ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"] }, labels: { dhx_cal_today_button: "Idag", day_tab: "Dag", week_tab: "Uge", month_tab: "Måned", new_event: "Ny begivenhed", icon_save: "Gem", icon_cancel: "Fortryd", icon_details: "Detaljer", icon_edit: "Tilret", icon_delete: "Slet", confirm_closing: "Dine rettelser vil gå tabt.. Er dy sikker?", confirm_deleting: "Bigivenheden vil blive slettet permanent. Er du sikker?", section_description: "Beskrivelse", section_time: "Tidsperiode", confirm_recurring: "Vil du tilrette hele serien af gentagne begivenheder?", section_recurring: "Gentag begivenhed", button_recurring: "Frakoblet", button_recurring_open: "Tilkoblet", button_edit_series: "Rediger serien", button_edit_occurrence: "Rediger en kopi", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Dagsorden", date: "Dato", description: "Beskrivelse", year_tab: "År", week_agenda_tab: "Dagsorden", grid_tab: "Grid", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Daglig", repeat_radio_week: "Ugenlig", repeat_radio_month: "Månedlig", repeat_radio_year: "Årlig", repeat_radio_day_type: "Hver", repeat_text_day_count: "dag", repeat_radio_day_type2: "På hver arbejdsdag", repeat_week: " Gentager sig hver", repeat_text_week_count: "uge på følgende dage:", repeat_radio_month_type: "Hver den", repeat_radio_month_start: "Den", repeat_text_month_day: " i hver", repeat_text_month_count: "måned", repeat_text_month_count2_before: "hver", repeat_text_month_count2_after: "måned", repeat_year_label: "Den", select_year_day2: "i", repeat_text_year_day: "dag i", select_year_month: "", repeat_radio_end: "Ingen slutdato", repeat_text_occurrences_count: "gentagelse", repeat_radio_end2: "Efter", repeat_radio_end3: "Slut", repeat_never: "Aldrig", repeat_daily: "Hver dag", repeat_workdays: "Hver hverdag", repeat_weekly: "Hver uge", repeat_monthly: "Hver måned", repeat_yearly: "Hvert år", repeat_custom: "Brugerdefineret", repeat_freq_day: "Dag", repeat_freq_week: "Uge", repeat_freq_month: "Måned", repeat_freq_year: "År", repeat_on_date: "På dato", repeat_ends: "Slutter", month_for_recurring: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"], day_for_recurring: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"] } }, de: { date: { month_full: [" Januar", " Februar", " März ", " April", " Mai", " Juni", " Juli", " August", " September ", " Oktober", " November ", " Dezember"], month_short: ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"], day_full: ["Sonntag", "Montag", "Dienstag", " Mittwoch", " Donnerstag", "Freitag", "Samstag"], day_short: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"] }, labels: { dhx_cal_today_button: "Heute", day_tab: "Tag", week_tab: "Woche", month_tab: "Monat", new_event: "neuer Eintrag", icon_save: "Speichern", icon_cancel: "Abbrechen", icon_details: "Details", icon_edit: "Ändern", icon_delete: "Löschen", confirm_closing: "", confirm_deleting: "Der Eintrag wird gelöscht", section_description: "Beschreibung", section_time: "Zeitspanne", full_day: "Ganzer Tag", confirm_recurring: "Wollen Sie alle Einträge bearbeiten oder nur diesen einzelnen Eintrag?", section_recurring: "Wiederholung", button_recurring: "Aus", button_recurring_open: "An", button_edit_series: "Bearbeiten Sie die Serie", button_edit_occurrence: "Bearbeiten Sie eine Kopie", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Datum", description: "Beschreibung", year_tab: "Jahre", week_agenda_tab: "Agenda", grid_tab: "Grid", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Täglich", repeat_radio_week: "Wöchentlich", repeat_radio_month: "Monatlich", repeat_radio_year: "Jährlich", repeat_radio_day_type: "jeden", repeat_text_day_count: "Tag", repeat_radio_day_type2: "an jedem Arbeitstag", repeat_week: " Wiederholt sich jede", repeat_text_week_count: "Woche am:", repeat_radio_month_type: "an jedem", repeat_radio_month_start: "am", repeat_text_month_day: "Tag eines jeden", repeat_text_month_count: "Monats", repeat_text_month_count2_before: "jeden", repeat_text_month_count2_after: "Monats", repeat_year_label: "am", select_year_day2: "im", repeat_text_year_day: "Tag im", select_year_month: "", repeat_radio_end: "kein Enddatum", repeat_text_occurrences_count: "Ereignissen", repeat_radio_end3: "Schluß", repeat_radio_end2: "nach", repeat_never: "Nie", repeat_daily: "Jeden Tag", repeat_workdays: "Jeden Werktag", repeat_weekly: "Jede Woche", repeat_monthly: "Jeden Monat", repeat_yearly: "Jedes Jahr", repeat_custom: "Benutzerdefiniert", repeat_freq_day: "Tag", repeat_freq_week: "Woche", repeat_freq_month: "Monat", repeat_freq_year: "Jahr", repeat_on_date: "Am Datum", repeat_ends: "Endet", month_for_recurring: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"], day_for_recurring: ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"] } }, el: { date: { month_full: ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάϊος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"], month_short: ["ΙΑΝ", "ΦΕΒ", "ΜΑΡ", "ΑΠΡ", "ΜΑΙ", "ΙΟΥΝ", "ΙΟΥΛ", "ΑΥΓ", "ΣΕΠ", "ΟΚΤ", "ΝΟΕ", "ΔΕΚ"], day_full: ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο"], day_short: ["ΚΥ", "ΔΕ", "ΤΡ", "ΤΕ", "ΠΕ", "ΠΑ", "ΣΑ"] }, labels: { dhx_cal_today_button: "Σήμερα", day_tab: "Ημέρα", week_tab: "Εβδομάδα", month_tab: "Μήνας", new_event: "Νέο έργο", icon_save: "Αποθήκευση", icon_cancel: "Άκυρο", icon_details: "Λεπτομέρειες", icon_edit: "Επεξεργασία", icon_delete: "Διαγραφή", confirm_closing: "", confirm_deleting: "Το έργο θα διαγραφεί οριστικά. Θέλετε να συνεχίσετε;", section_description: "Περιγραφή", section_time: "Χρονική περίοδος", full_day: "Πλήρης Ημέρα", confirm_recurring: "Θέλετε να επεξεργασθείτε ολόκληρη την ομάδα των επαναλαμβανόμενων έργων;", section_recurring: "Επαναλαμβανόμενο έργο", button_recurring: "Ανενεργό", button_recurring_open: "Ενεργό", button_edit_series: "Επεξεργαστείτε τη σειρά", button_edit_occurrence: "Επεξεργασία ένα αντίγραφο", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Ημερήσια Διάταξη", date: "Ημερομηνία", description: "Περιγραφή", year_tab: "Έτος", week_agenda_tab: "Ημερήσια Διάταξη", grid_tab: "Πλέγμα", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Ημερησίως", repeat_radio_week: "Εβδομαδιαίως", repeat_radio_month: "Μηνιαίως", repeat_radio_year: "Ετησίως", repeat_radio_day_type: "Κάθε", repeat_text_day_count: "ημέρα", repeat_radio_day_type2: "Κάθε εργάσιμη", repeat_week: " Επανάληψη κάθε", repeat_text_week_count: "εβδομάδα τις επόμενες ημέρες:", repeat_radio_month_type: "Επανάληψη", repeat_radio_month_start: "Την", repeat_text_month_day: "ημέρα κάθε", repeat_text_month_count: "μήνα", repeat_text_month_count2_before: "κάθε", repeat_text_month_count2_after: "μήνα", repeat_year_label: "Την", select_year_day2: "του", repeat_text_year_day: "ημέρα", select_year_month: "μήνα", repeat_radio_end: "Χωρίς ημερομηνία λήξεως", repeat_text_occurrences_count: "επαναλήψεις", repeat_radio_end3: "Λήγει την", repeat_radio_end2: "Μετά από", repeat_never: "Ποτέ", repeat_daily: "Κάθε μέρα", repeat_workdays: "Κάθε εργάσιμη μέρα", repeat_weekly: "Κάθε εβδομάδα", repeat_monthly: "Κάθε μήνα", repeat_yearly: "Κάθε χρόνο", repeat_custom: "Προσαρμοσμένο", repeat_freq_day: "Ημέρα", repeat_freq_week: "Εβδομάδα", repeat_freq_month: "Μήνας", repeat_freq_year: "Χρόνος", repeat_on_date: "Σε ημερομηνία", repeat_ends: "Λήγει", month_for_recurring: ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάϊος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"], day_for_recurring: ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο"] } }, en: { date: { month_full: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], day_full: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], day_short: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"] }, labels: { dhx_cal_today_button: "Today", day_tab: "Day", week_tab: "Week", month_tab: "Month", new_event: "New event", icon_save: "Save", icon_cancel: "Cancel", icon_details: "Details", icon_edit: "Edit", icon_delete: "Delete", confirm_closing: "", confirm_deleting: "Event will be deleted permanently, are you sure?", section_description: "Description", section_time: "Time period", full_day: "Full day", confirm_recurring: "Edit recurring event", section_recurring: "Repeat event", button_recurring: "Disabled", button_recurring_open: "Enabled", button_edit_series: "All events", button_edit_occurrence: "This event", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Date", description: "Description", year_tab: "Year", week_agenda_tab: "Agenda", grid_tab: "Grid", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Daily", repeat_radio_week: "Weekly", repeat_radio_month: "Monthly", repeat_radio_year: "Yearly", repeat_radio_day_type: "Every", repeat_text_day_count: "day", repeat_radio_day_type2: "Every workday", repeat_week: " Repeat every", repeat_text_week_count: "week next days:", repeat_radio_month_type: "Repeat", repeat_radio_month_start: "On", repeat_text_month_day: "day every", repeat_text_month_count: "month", repeat_text_month_count2_before: "every", repeat_text_month_count2_after: "month", repeat_year_label: "On", select_year_day2: "of", repeat_text_year_day: "day", select_year_month: "month", repeat_radio_end: "No end date", repeat_text_occurrences_count: "occurrences", repeat_radio_end2: "After", repeat_radio_end3: "End by", repeat_never: "Never", repeat_daily: "Every day", repeat_workdays: "Every weekday", repeat_weekly: "Every week", repeat_monthly: "Every month", repeat_yearly: "Every year", repeat_custom: "Custom", repeat_freq_day: "Day", repeat_freq_week: "Week", repeat_freq_month: "Month", repeat_freq_year: "Year", repeat_on_date: "On date", repeat_ends: "Ends", month_for_recurring: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], day_for_recurring: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] } }, es: { date: { month_full: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], month_short: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"], day_full: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"], day_short: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"] }, labels: { dhx_cal_today_button: "Hoy", day_tab: "Día", week_tab: "Semana", month_tab: "Mes", new_event: "Nuevo evento", icon_save: "Guardar", icon_cancel: "Cancelar", icon_details: "Detalles", icon_edit: "Editar", icon_delete: "Eliminar", confirm_closing: "", confirm_deleting: "El evento se borrará definitivamente, ¿continuar?", section_description: "Descripción", section_time: "Período", full_day: "Todo el día", confirm_recurring: "¿Desea modificar el conjunto de eventos repetidos?", section_recurring: "Repita el evento", button_recurring: "Impedido", button_recurring_open: "Permitido", button_edit_series: "Editar la serie", button_edit_occurrence: "Editar este evento", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Día", date: "Fecha", description: "Descripción", year_tab: "Año", week_agenda_tab: "Día", grid_tab: "Reja", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Diariamente", repeat_radio_week: "Semanalmente", repeat_radio_month: "Mensualmente", repeat_radio_year: "Anualmente", repeat_radio_day_type: "Cada", repeat_text_day_count: "dia", repeat_radio_day_type2: "Cada jornada de trabajo", repeat_week: " Repetir cada", repeat_text_week_count: "semana:", repeat_radio_month_type: "Repita", repeat_radio_month_start: "El", repeat_text_month_day: "dia cada ", repeat_text_month_count: "mes", repeat_text_month_count2_before: "cada", repeat_text_month_count2_after: "mes", repeat_year_label: "El", select_year_day2: "del", repeat_text_year_day: "dia", select_year_month: "mes", repeat_radio_end: "Sin fecha de finalización", repeat_text_occurrences_count: "ocurrencias", repeat_radio_end3: "Fin", repeat_radio_end2: "Después de", repeat_never: "Nunca", repeat_daily: "Cada día", repeat_workdays: "Cada día laborable", repeat_weekly: "Cada semana", repeat_monthly: "Cada mes", repeat_yearly: "Cada año", repeat_custom: "Personalizado", repeat_freq_day: "Día", repeat_freq_week: "Semana", repeat_freq_month: "Mes", repeat_freq_year: "Año", repeat_on_date: "En la fecha", repeat_ends: "Termina", month_for_recurring: ["Enero", "Febrero", "Маrzo", "Аbril", "Mayo", "Junio", "Julio", "Аgosto", "Setiembre", "Octubre", "Noviembre", "Diciembre"], day_for_recurring: ["Domingo", "Lunes", "Martes", "Miércoles", "Jeuves", "Viernes", "Sabado"] } }, fi: { date: { month_full: ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kes&auml;kuu", "Hein&auml;kuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"], month_short: ["Tam", "Hel", "Maa", "Huh", "Tou", "Kes", "Hei", "Elo", "Syy", "Lok", "Mar", "Jou"], day_full: ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"], day_short: ["Su", "Ma", "Ti", "Ke", "To", "Pe", "La"] }, labels: { dhx_cal_today_button: "Tänään", day_tab: "Päivä", week_tab: "Viikko", month_tab: "Kuukausi", new_event: "Uusi tapahtuma", icon_save: "Tallenna", icon_cancel: "Peru", icon_details: "Tiedot", icon_edit: "Muokkaa", icon_delete: "Poista", confirm_closing: "", confirm_deleting: "Haluatko varmasti poistaa tapahtuman?", section_description: "Kuvaus", section_time: "Aikajakso", full_day: "Koko päivä", confirm_recurring: "Haluatko varmasti muokata toistuvan tapahtuman kaikkia jaksoja?", section_recurring: "Toista tapahtuma", button_recurring: "Ei k&auml;yt&ouml;ss&auml;", button_recurring_open: "K&auml;yt&ouml;ss&auml;", button_edit_series: "Muokkaa sarja", button_edit_occurrence: "Muokkaa kopio", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Esityslista", date: "Päivämäärä", description: "Kuvaus", year_tab: "Vuoden", week_agenda_tab: "Esityslista", grid_tab: "Ritilä", drag_to_create: "Luo uusi vetämällä", drag_to_move: "Siirrä vetämällä", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "P&auml;ivitt&auml;in", repeat_radio_week: "Viikoittain", repeat_radio_month: "Kuukausittain", repeat_radio_year: "Vuosittain", repeat_radio_day_type: "Joka", repeat_text_day_count: "p&auml;iv&auml;", repeat_radio_day_type2: "Joka arkip&auml;iv&auml;", repeat_week: "Toista joka", repeat_text_week_count: "viikko n&auml;in&auml; p&auml;ivin&auml;:", repeat_radio_month_type: "Toista", repeat_radio_month_start: "", repeat_text_month_day: "p&auml;iv&auml;n&auml; joka", repeat_text_month_count: "kuukausi", repeat_text_month_count2_before: "joka", repeat_text_month_count2_after: "kuukausi", repeat_year_label: "", select_year_day2: "", repeat_text_year_day: "p&auml;iv&auml;", select_year_month: "kuukausi", repeat_radio_end: "Ei loppumisaikaa", repeat_text_occurrences_count: "Toiston j&auml;lkeen", repeat_radio_end3: "Loppuu", repeat_radio_end2: "", repeat_never: "Ei koskaan", repeat_daily: "Joka päivä", repeat_workdays: "Joka arkipäivä", repeat_weekly: "Joka viikko", repeat_monthly: "Joka kuukausi", repeat_yearly: "Joka vuosi", repeat_custom: "Mukautettu", repeat_freq_day: "Päivä", repeat_freq_week: "Viikko", repeat_freq_month: "Kuukausi", repeat_freq_year: "Vuosi", repeat_on_date: "Tiettynä päivänä", repeat_ends: "Päättyy", month_for_recurring: ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kes&auml;kuu", "Hein&auml;kuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"], day_for_recurring: ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"] } }, fr: { date: { month_full: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"], month_short: ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Aoû", "Sep", "Oct", "Nov", "Déc"], day_full: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"], day_short: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"] }, labels: { dhx_cal_today_button: "Aujourd'hui", day_tab: "Jour", week_tab: "Semaine", month_tab: "Mois", new_event: "Nouvel événement", icon_save: "Enregistrer", icon_cancel: "Annuler", icon_details: "Détails", icon_edit: "Modifier", icon_delete: "Effacer", confirm_closing: "", confirm_deleting: "L'événement sera effacé sans appel, êtes-vous sûr ?", section_description: "Description", section_time: "Période", full_day: "Journée complète", confirm_recurring: "Voulez-vous éditer toute une série d'évènements répétés?", section_recurring: "Périodicité", button_recurring: "Désactivé", button_recurring_open: "Activé", button_edit_series: "Modifier la série", button_edit_occurrence: "Modifier une copie", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Jour", date: "Date", description: "Description", year_tab: "Année", week_agenda_tab: "Jour", grid_tab: "Grille", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Quotidienne", repeat_radio_week: "Hebdomadaire", repeat_radio_month: "Mensuelle", repeat_radio_year: "Annuelle", repeat_radio_day_type: "Chaque", repeat_text_day_count: "jour", repeat_radio_day_type2: "Chaque journée de travail", repeat_week: " Répéter toutes les", repeat_text_week_count: "semaine:", repeat_radio_month_type: "Répéter", repeat_radio_month_start: "Le", repeat_text_month_day: "jour chaque", repeat_text_month_count: "mois", repeat_text_month_count2_before: "chaque", repeat_text_month_count2_after: "mois", repeat_year_label: "Le", select_year_day2: "du", repeat_text_year_day: "jour", select_year_month: "mois", repeat_radio_end: "Pas de date d&quot;achèvement", repeat_text_occurrences_count: "occurrences", repeat_radio_end3: "Fin", repeat_radio_end2: "Après", repeat_never: "Jamais", repeat_daily: "Chaque jour", repeat_workdays: "Chaque jour ouvrable", repeat_weekly: "Chaque semaine", repeat_monthly: "Chaque mois", repeat_yearly: "Chaque année", repeat_custom: "Personnalisé", repeat_freq_day: "Jour", repeat_freq_week: "Semaine", repeat_freq_month: "Mois", repeat_freq_year: "Année", repeat_on_date: "À la date", repeat_ends: "Se termine", month_for_recurring: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"], day_for_recurring: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"] } }, he: { date: { month_full: ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"], month_short: ["ינו", "פבר", "מרץ", "אפר", "מאי", "יונ", "יול", "אוג", "ספט", "אוק", "נוב", "דצמ"], day_full: ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"], day_short: ["א", "ב", "ג", "ד", "ה", "ו", "ש"] }, labels: { dhx_cal_today_button: "היום", day_tab: "יום", week_tab: "שבוע", month_tab: "חודש", new_event: "ארוע חדש", icon_save: "שמור", icon_cancel: "בטל", icon_details: "פרטים", icon_edit: "ערוך", icon_delete: "מחק", confirm_closing: "", confirm_deleting: "ארוע ימחק סופית.להמשיך?", section_description: "תיאור", section_time: "תקופה", confirm_recurring: "האם ברצונך לשנות כל סדרת ארועים מתמשכים?", section_recurring: "להעתיק ארוע", button_recurring: "לא פעיל", button_recurring_open: "פעיל", full_day: "יום שלם", button_edit_series: "ערוך את הסדרה", button_edit_occurrence: "עריכת עותק", button_edit_occurrence_and_following: "This and following events", agenda_tab: "סדר יום", date: "תאריך", description: "תיאור", year_tab: "לשנה", week_agenda_tab: "סדר יום", grid_tab: "סורג", drag_to_create: "Drag to create", drag_to_move: "גרור כדי להזיז", message_ok: "OK", message_cancel: "בטל", next: "הבא", prev: "הקודם", year: "שנה", month: "חודש", day: "יום", hour: "שעה", minute: "דקה", repeat_radio_day: "יומי", repeat_radio_week: "שבועי", repeat_radio_month: "חודשי", repeat_radio_year: "שנתי", repeat_radio_day_type: "חזור כל", repeat_text_day_count: "ימים", repeat_radio_day_type2: "חזור כל יום עבודה", repeat_week: " חזור כל", repeat_text_week_count: "שבוע לפי ימים:", repeat_radio_month_type: "חזור כל", repeat_radio_month_start: "כל", repeat_text_month_day: "ימים כל", repeat_text_month_count: "חודשים", repeat_text_month_count2_before: "חזור כל", repeat_text_month_count2_after: "חודש", repeat_year_label: "כל", select_year_day2: "בחודש", repeat_text_year_day: "ימים", select_year_month: "חודש", repeat_radio_end: "לעולם לא מסתיים", repeat_text_occurrences_count: "אירועים", repeat_radio_end3: "מסתיים ב", repeat_radio_end2: "אחרי", repeat_never: "אף פעם", repeat_daily: "כל יום", repeat_workdays: "כל יום עבודה", repeat_weekly: "כל שבוע", repeat_monthly: "כל חודש", repeat_yearly: "כל שנה", repeat_custom: "מותאם אישית", repeat_freq_day: "יום", repeat_freq_week: "שבוע", repeat_freq_month: "חודש", repeat_freq_year: "שנה", repeat_on_date: "בתאריך", repeat_ends: "מסתיים", month_for_recurring: ["ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני", "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר"], day_for_recurring: ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"] } }, hu: { date: { month_full: ["Január", "Február", "Március", "Április", "Május", "Június", "Július", "Augusztus", "Szeptember", "Október", "November", "December"], month_short: ["Jan", "Feb", "Már", "Ápr", "Máj", "Jún", "Júl", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Vasárnap", "Hétfõ", "Kedd", "Szerda", "Csütörtök", "Péntek", "szombat"], day_short: ["Va", "Hé", "Ke", "Sze", "Csü", "Pé", "Szo"] }, labels: { dhx_cal_today_button: "Ma", day_tab: "Nap", week_tab: "Hét", month_tab: "Hónap", new_event: "Új esemény", icon_save: "Mentés", icon_cancel: "Mégse", icon_details: "Részletek", icon_edit: "Szerkesztés", icon_delete: "Törlés", confirm_closing: "", confirm_deleting: "Az esemény törölve lesz, biztosan folytatja?", section_description: "Leírás", section_time: "Idõszak", full_day: "Egesz napos", confirm_recurring: "Biztosan szerkeszteni akarod az összes ismétlõdõ esemény beállítását?", section_recurring: "Esemény ismétlése", button_recurring: "Tiltás", button_recurring_open: "Engedélyezés", button_edit_series: "Edit series", button_edit_occurrence: "Szerkesztés bíróság", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Napirend", date: "Dátum", description: "Leírás", year_tab: "Év", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Napi", repeat_radio_week: "Heti", repeat_radio_month: "Havi", repeat_radio_year: "Éves", repeat_radio_day_type: "Minden", repeat_text_day_count: "nap", repeat_radio_day_type2: "Minden munkanap", repeat_week: " Ismételje meg minden", repeat_text_week_count: "héten a következő napokon:", repeat_radio_month_type: "Ismétlés", repeat_radio_month_start: "Ekkor", repeat_text_month_day: "nap minden", repeat_text_month_count: "hónapban", repeat_text_month_count2_before: "minden", repeat_text_month_count2_after: "hónapban", repeat_year_label: "Ekkor", select_year_day2: "-án/-én", repeat_text_year_day: "nap", select_year_month: "hónap", repeat_radio_end: "Nincs befejezési dátum", repeat_text_occurrences_count: "esemény", repeat_radio_end2: "Után", repeat_radio_end3: "Befejező dátum", repeat_never: "Soha", repeat_daily: "Minden nap", repeat_workdays: "Minden munkanap", repeat_weekly: "Minden héten", repeat_monthly: "Minden hónapban", repeat_yearly: "Minden évben", repeat_custom: "Egyedi", repeat_freq_day: "Nap", repeat_freq_week: "Hét", repeat_freq_month: "Hónap", repeat_freq_year: "Év", repeat_on_date: "Dátum szerint", repeat_ends: "Befejeződik", month_for_recurring: ["Január", "Február", "Március", "Április", "Május", "Június", "Július", "Augusztus", "Szeptember", "Október", "November", "December"], day_for_recurring: ["Vasárnap", "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat"] } }, id: { date: { month_full: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"], month_short: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des"], day_full: ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"], day_short: ["Ming", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"] }, labels: { dhx_cal_today_button: "Hari Ini", day_tab: "Hari", week_tab: "Minggu", month_tab: "Bulan", new_event: "Acara Baru", icon_save: "Simpan", icon_cancel: "Batal", icon_details: "Detail", icon_edit: "Edit", icon_delete: "Hapus", confirm_closing: "", confirm_deleting: "Acara akan dihapus", section_description: "Keterangan", section_time: "Periode", full_day: "Hari penuh", confirm_recurring: "Apakah acara ini akan berulang?", section_recurring: "Acara Rutin", button_recurring: "Tidak Difungsikan", button_recurring_open: "Difungsikan", button_edit_series: "Mengedit seri", button_edit_occurrence: "Mengedit salinan", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Tanggal", description: "Keterangan", year_tab: "Tahun", week_agenda_tab: "Agenda", grid_tab: "Tabel", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Harian", repeat_radio_week: "Mingguan", repeat_radio_month: "Bulanan", repeat_radio_year: "Tahunan", repeat_radio_day_type: "Setiap", repeat_text_day_count: "hari", repeat_radio_day_type2: "Setiap hari kerja", repeat_week: " Ulangi setiap", repeat_text_week_count: "minggu pada hari berikut:", repeat_radio_month_type: "Ulangi", repeat_radio_month_start: "Pada", repeat_text_month_day: "hari setiap", repeat_text_month_count: "bulan", repeat_text_month_count2_before: "setiap", repeat_text_month_count2_after: "bulan", repeat_year_label: "Pada", select_year_day2: "dari", repeat_text_year_day: "hari", select_year_month: "bulan", repeat_radio_end: "Tanpa tanggal akhir", repeat_text_occurrences_count: "kejadian", repeat_radio_end2: "Setelah", repeat_radio_end3: "Berakhir pada", repeat_never: "Tidak pernah", repeat_daily: "Setiap hari", repeat_workdays: "Setiap hari kerja", repeat_weekly: "Setiap minggu", repeat_monthly: "Setiap bulan", repeat_yearly: "Setiap tahun", repeat_custom: "Kustom", repeat_freq_day: "Hari", repeat_freq_week: "Minggu", repeat_freq_month: "Bulan", repeat_freq_year: "Tahun", repeat_on_date: "Pada tanggal", repeat_ends: "Berakhir", month_for_recurring: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"], day_for_recurring: ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"] } }, it: { date: { month_full: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"], month_short: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"], day_full: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"], day_short: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"] }, labels: { dhx_cal_today_button: "Oggi", day_tab: "Giorno", week_tab: "Settimana", month_tab: "Mese", new_event: "Nuovo evento", icon_save: "Salva", icon_cancel: "Chiudi", icon_details: "Dettagli", icon_edit: "Modifica", icon_delete: "Elimina", confirm_closing: "", confirm_deleting: "L'evento sarà eliminato, siete sicuri?", section_description: "Descrizione", section_time: "Periodo di tempo", full_day: "Intera giornata", confirm_recurring: "Vuoi modificare l'intera serie di eventi?", section_recurring: "Ripetere l'evento", button_recurring: "Disattivato", button_recurring_open: "Attivato", button_edit_series: "Modificare la serie", button_edit_occurrence: "Modificare una copia", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Data", description: "Descrizione", year_tab: "Anno", week_agenda_tab: "Agenda", grid_tab: "Griglia", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Quotidiano", repeat_radio_week: "Settimanale", repeat_radio_month: "Mensile", repeat_radio_year: "Annuale", repeat_radio_day_type: "Ogni", repeat_text_day_count: "giorno", repeat_radio_day_type2: "Ogni giornata lavorativa", repeat_week: " Ripetere ogni", repeat_text_week_count: "settimana:", repeat_radio_month_type: "Ripetere", repeat_radio_month_start: "Il", repeat_text_month_day: "giorno ogni", repeat_text_month_count: "mese", repeat_text_month_count2_before: "ogni", repeat_text_month_count2_after: "mese", repeat_year_label: "Il", select_year_day2: "del", repeat_text_year_day: "giorno", select_year_month: "mese", repeat_radio_end: "Senza data finale", repeat_text_occurrences_count: "occorenze", repeat_radio_end3: "Fine", repeat_radio_end2: "Dopo", repeat_never: "Mai", repeat_daily: "Ogni giorno", repeat_workdays: "Ogni giorno feriale", repeat_weekly: "Ogni settimana", repeat_monthly: "Ogni mese", repeat_yearly: "Ogni anno", repeat_custom: "Personalizzato", repeat_freq_day: "Giorno", repeat_freq_week: "Settimana", repeat_freq_month: "Mese", repeat_freq_year: "Anno", repeat_on_date: "Alla data", repeat_ends: "Finisce", month_for_recurring: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Jiugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"], day_for_recurring: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Jovedì", "Venerdì", "Sabato"] } }, jp: { date: { month_full: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], month_short: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], day_full: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"], day_short: ["日", "月", "火", "水", "木", "金", "土"] }, labels: { dhx_cal_today_button: "今日", day_tab: "日", week_tab: "週", month_tab: "月", new_event: "新イベント", icon_save: "保存", icon_cancel: "キャンセル", icon_details: "詳細", icon_edit: "編集", icon_delete: "削除", confirm_closing: "", confirm_deleting: "イベント完全に削除されます、宜しいですか？", section_description: "デスクリプション", section_time: "期間", confirm_recurring: "繰り返されているイベントを全て編集しますか？", section_recurring: "イベントを繰り返す", button_recurring: "無効", button_recurring_open: "有効", full_day: "終日", button_edit_series: "シリーズを編集します", button_edit_occurrence: "コピーを編集", button_edit_occurrence_and_following: "This and following events", agenda_tab: "議題は", date: "日付", description: "説明", year_tab: "今年", week_agenda_tab: "議題は", grid_tab: "グリッド", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "毎日", repeat_radio_week: "毎週", repeat_radio_month: "毎月", repeat_radio_year: "毎年", repeat_radio_day_type: "毎", repeat_text_day_count: "日", repeat_radio_day_type2: "毎営業日", repeat_week: " 繰り返し毎", repeat_text_week_count: "週 次の日:", repeat_radio_month_type: "繰り返し", repeat_radio_month_start: "オン", repeat_text_month_day: "日毎", repeat_text_month_count: "月", repeat_text_month_count2_before: "毎", repeat_text_month_count2_after: "月", repeat_year_label: "オン", select_year_day2: "の", repeat_text_year_day: "日", select_year_month: "月", repeat_radio_end: "終了日なし", repeat_text_occurrences_count: "回数", repeat_radio_end2: "後", repeat_radio_end3: "終了日まで", repeat_never: "決して", repeat_daily: "毎日", repeat_workdays: "毎営業日", repeat_weekly: "毎週", repeat_monthly: "毎月", repeat_yearly: "毎年", repeat_custom: "カスタム", repeat_freq_day: "日", repeat_freq_week: "週", repeat_freq_month: "月", repeat_freq_year: "年", repeat_on_date: "日にち", repeat_ends: "終了", month_for_recurring: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"], day_for_recurring: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"] } }, nb: { date: { month_full: ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"], month_short: ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"], day_full: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"], day_short: ["Søn", "Mon", "Tir", "Ons", "Tor", "Fre", "Lør"] }, labels: { dhx_cal_today_button: "I dag", day_tab: "Dag", week_tab: "Uke", month_tab: "Måned", new_event: "Ny hendelse", icon_save: "Lagre", icon_cancel: "Avbryt", icon_details: "Detaljer", icon_edit: "Rediger", icon_delete: "Slett", confirm_closing: "", confirm_deleting: "Hendelsen vil bli slettet permanent. Er du sikker?", section_description: "Beskrivelse", section_time: "Tidsperiode", confirm_recurring: "Vil du forandre hele dette settet av repeterende hendelser?", section_recurring: "Repeter hendelsen", button_recurring: "Av", button_recurring_open: "På", button_edit_series: "Rediger serien", button_edit_occurrence: "Redigere en kopi", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Dato", description: "Beskrivelse", year_tab: "År", week_agenda_tab: "Agenda", grid_tab: "Grid", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Daglig", repeat_radio_week: "Ukentlig", repeat_radio_month: "Månedlig", repeat_radio_year: "Årlig", repeat_radio_day_type: "Hver", repeat_text_day_count: "dag", repeat_radio_day_type2: "Alle hverdager", repeat_week: " Gjentas hver", repeat_text_week_count: "uke på:", repeat_radio_month_type: "På hver", repeat_radio_month_start: "På", repeat_text_month_day: "dag hver", repeat_text_month_count: "måned", repeat_text_month_count2_before: "hver", repeat_text_month_count2_after: "måned", repeat_year_label: "på", select_year_day2: "i", repeat_text_year_day: "dag i", select_year_month: "", repeat_radio_end: "Ingen sluttdato", repeat_text_occurrences_count: "forekomst", repeat_radio_end3: "Stop den", repeat_radio_end2: "Etter", repeat_never: "Aldri", repeat_daily: "Hver dag", repeat_workdays: "Hver ukedag", repeat_weekly: "Hver uke", repeat_monthly: "Hver måned", repeat_yearly: "Hvert år", repeat_custom: "Tilpasset", repeat_freq_day: "Dag", repeat_freq_week: "Uke", repeat_freq_month: "Måned", repeat_freq_year: "År", repeat_on_date: "På dato", repeat_ends: "Slutter", month_for_recurring: ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"], day_for_recurring: ["Sondag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"] } }, nl: { date: { month_full: ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "mrt", "Apr", "Mei", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"], day_short: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"] }, labels: { dhx_cal_today_button: "Vandaag", day_tab: "Dag", week_tab: "Week", month_tab: "Maand", new_event: "Nieuw item", icon_save: "Opslaan", icon_cancel: "Annuleren", icon_details: "Details", icon_edit: "Bewerken", icon_delete: "Verwijderen", confirm_closing: "", confirm_deleting: "Item zal permanent worden verwijderd, doorgaan?", section_description: "Beschrijving", section_time: "Tijd periode", full_day: "Hele dag", confirm_recurring: "Wilt u alle terugkerende items bijwerken?", section_recurring: "Item herhalen", button_recurring: "Uit", button_recurring_open: "Aan", button_edit_series: "Bewerk de serie", button_edit_occurrence: "Bewerk een kopie", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Datum", description: "Omschrijving", year_tab: "Jaar", week_agenda_tab: "Agenda", grid_tab: "Tabel", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Dagelijks", repeat_radio_week: "Wekelijks", repeat_radio_month: "Maandelijks", repeat_radio_year: "Jaarlijks", repeat_radio_day_type: "Elke", repeat_text_day_count: "dag(en)", repeat_radio_day_type2: "Elke werkdag", repeat_week: " Herhaal elke", repeat_text_week_count: "week op de volgende dagen:", repeat_radio_month_type: "Herhaal", repeat_radio_month_start: "Op", repeat_text_month_day: "dag iedere", repeat_text_month_count: "maanden", repeat_text_month_count2_before: "iedere", repeat_text_month_count2_after: "maanden", repeat_year_label: "Op", select_year_day2: "van", repeat_text_year_day: "dag", select_year_month: "maand", repeat_radio_end: "Geen eind datum", repeat_text_occurrences_count: "keren", repeat_radio_end3: "Eindigd per", repeat_radio_end2: "Na", repeat_never: "Nooit", repeat_daily: "Elke dag", repeat_workdays: "Elke werkdag", repeat_weekly: "Elke week", repeat_monthly: "Elke maand", repeat_yearly: "Elk jaar", repeat_custom: "Aangepast", repeat_freq_day: "Dag", repeat_freq_week: "Week", repeat_freq_month: "Maand", repeat_freq_year: "Jaar", repeat_on_date: "Op datum", repeat_ends: "Eindigt", month_for_recurring: ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"], day_for_recurring: ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"] } }, no: { date: { month_full: ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"], month_short: ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"], day_full: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"], day_short: ["Søn", "Man", "Tir", "Ons", "Tor", "Fre", "Lør"] }, labels: { dhx_cal_today_button: "Idag", day_tab: "Dag", week_tab: "Uke", month_tab: "Måned", new_event: "Ny", icon_save: "Lagre", icon_cancel: "Avbryt", icon_details: "Detaljer", icon_edit: "Endre", icon_delete: "Slett", confirm_closing: "Endringer blir ikke lagret, er du sikker?", confirm_deleting: "Oppføringen vil bli slettet, er du sikker?", section_description: "Beskrivelse", section_time: "Tidsperiode", full_day: "Full dag", confirm_recurring: "Vil du endre hele settet med repeterende oppføringer?", section_recurring: "Repeterende oppføring", button_recurring: "Ikke aktiv", button_recurring_open: "Aktiv", button_edit_series: "Rediger serien", button_edit_occurrence: "Redigere en kopi", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Dato", description: "Beskrivelse", year_tab: "År", week_agenda_tab: "Agenda", grid_tab: "Grid", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Daglig", repeat_radio_week: "Ukentlig", repeat_radio_month: "Månedlig", repeat_radio_year: "Årlig", repeat_radio_day_type: "Hver", repeat_text_day_count: "dag", repeat_radio_day_type2: "Hver arbeidsdag", repeat_week: " Gjenta hver", repeat_text_week_count: "uke neste dager:", repeat_radio_month_type: "Gjenta", repeat_radio_month_start: "På", repeat_text_month_day: "dag hver", repeat_text_month_count: "måned", repeat_text_month_count2_before: "hver", repeat_text_month_count2_after: "måned", repeat_year_label: "På", select_year_day2: "av", repeat_text_year_day: "dag", select_year_month: "måned", repeat_radio_end: "Ingen sluttdato", repeat_text_occurrences_count: "forekomster", repeat_radio_end2: "Etter", repeat_radio_end3: "Slutt innen", repeat_never: "Aldri", repeat_daily: "Hver dag", repeat_workdays: "Hver ukedag", repeat_weekly: "Hver uke", repeat_monthly: "Hver måned", repeat_yearly: "Hvert år", repeat_custom: "Tilpasset", repeat_freq_day: "Dag", repeat_freq_week: "Uke", repeat_freq_month: "Måned", repeat_freq_year: "År", repeat_on_date: "På dato", repeat_ends: "Slutter", month_for_recurring: ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"], day_for_recurring: ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"] } }, pl: { date: { month_full: ["Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad", "Grudzień"], month_short: ["Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Paź", "Lis", "Gru"], day_full: ["Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota"], day_short: ["Nie", "Pon", "Wto", "Śro", "Czw", "Pią", "Sob"] }, labels: { dhx_cal_today_button: "Dziś", day_tab: "Dzień", week_tab: "Tydzień", month_tab: "Miesiąc", new_event: "Nowe zdarzenie", icon_save: "Zapisz", icon_cancel: "Anuluj", icon_details: "Szczegóły", icon_edit: "Edytuj", icon_delete: "Usuń", confirm_closing: "", confirm_deleting: "Zdarzenie zostanie usunięte na zawsze, kontynuować?", section_description: "Opis", section_time: "Okres czasu", full_day: "Cały dzień", confirm_recurring: "Czy chcesz edytować cały zbiór powtarzających się zdarzeń?", section_recurring: "Powtórz zdarzenie", button_recurring: "Nieaktywne", button_recurring_open: "Aktywne", button_edit_series: "Edytuj serię", button_edit_occurrence: "Edytuj kopię", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Data", description: "Opis", year_tab: "Rok", week_agenda_tab: "Agenda", grid_tab: "Tabela", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Codziennie", repeat_radio_week: "Co tydzie", repeat_radio_month: "Co miesic", repeat_radio_year: "Co rok", repeat_radio_day_type: "Kadego", repeat_text_day_count: "dnia", repeat_radio_day_type2: "Kadego dnia roboczego", repeat_week: " Powtarzaj kadego", repeat_text_week_count: "tygodnia w dni:", repeat_radio_month_type: "Powtrz", repeat_radio_month_start: "W", repeat_text_month_day: "dnia kadego", repeat_text_month_count: "miesica", repeat_text_month_count2_before: "kadego", repeat_text_month_count2_after: "miesica", repeat_year_label: "W", select_year_day2: "miesica", repeat_text_year_day: "dnia miesica", select_year_month: "", repeat_radio_end: "Bez daty kocowej", repeat_text_occurrences_count: "wystpieniu/ach", repeat_radio_end3: "Zakocz w", repeat_radio_end2: "Po", repeat_never: "Nigdy", repeat_daily: "Codziennie", repeat_workdays: "Każdy dzień roboczy", repeat_weekly: "Co tydzień", repeat_monthly: "Co miesiąc", repeat_yearly: "Co rok", repeat_custom: "Niestandardowy", repeat_freq_day: "Dzień", repeat_freq_week: "Tydzień", repeat_freq_month: "Miesiąc", repeat_freq_year: "Rok", repeat_on_date: "W dniu", repeat_ends: "Kończy się", month_for_recurring: ["Stycznia", "Lutego", "Marca", "Kwietnia", "Maja", "Czerwca", "Lipca", "Sierpnia", "Wrzenia", "Padziernka", "Listopada", "Grudnia"], day_for_recurring: ["Niedziela", "Poniedziaek", "Wtorek", "roda", "Czwartek", "Pitek", "Sobota"] } }, pt: { date: { month_full: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"], month_short: ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"], day_full: ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"], day_short: ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"] }, labels: { dhx_cal_today_button: "Hoje", day_tab: "Dia", week_tab: "Semana", month_tab: "Mês", new_event: "Novo evento", icon_save: "Salvar", icon_cancel: "Cancelar", icon_details: "Detalhes", icon_edit: "Editar", icon_delete: "Deletar", confirm_closing: "", confirm_deleting: "Tem certeza que deseja excluir?", section_description: "Descrição", section_time: "Período de tempo", full_day: "Dia inteiro", confirm_recurring: "Deseja editar todos esses eventos repetidos?", section_recurring: "Repetir evento", button_recurring: "Desabilitar", button_recurring_open: "Habilitar", button_edit_series: "Editar a série", button_edit_occurrence: "Editar uma cópia", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Dia", date: "Data", description: "Descrição", year_tab: "Ano", week_agenda_tab: "Dia", grid_tab: "Grade", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Diário", repeat_radio_week: "Semanal", repeat_radio_month: "Mensal", repeat_radio_year: "Anual", repeat_radio_day_type: "Cada", repeat_text_day_count: "dia(s)", repeat_radio_day_type2: "Cada trabalho diário", repeat_week: " Repita cada", repeat_text_week_count: "semana:", repeat_radio_month_type: "Repetir", repeat_radio_month_start: "Em", repeat_text_month_day: "todo dia", repeat_text_month_count: "mês", repeat_text_month_count2_before: "todo", repeat_text_month_count2_after: "mês", repeat_year_label: "Em", select_year_day2: "of", repeat_text_year_day: "dia", select_year_month: "mês", repeat_radio_end: "Sem data final", repeat_text_occurrences_count: "ocorrências", repeat_radio_end3: "Fim", repeat_radio_end2: "Depois", repeat_never: "Nunca", repeat_daily: "Todos os dias", repeat_workdays: "Todos os dias úteis", repeat_weekly: "Toda semana", repeat_monthly: "Todo mês", repeat_yearly: "Todo ano", repeat_custom: "Personalizado", repeat_freq_day: "Dia", repeat_freq_week: "Semana", repeat_freq_month: "Mês", repeat_freq_year: "Ano", repeat_on_date: "Na data", repeat_ends: "Termina", month_for_recurring: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"], day_for_recurring: ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"] } }, ro: { date: { month_full: ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "November", "December"], month_short: ["Ian", "Feb", "Mar", "Apr", "Mai", "Iun", "Iul", "Aug", "Sep", "Oct", "Nov", "Dec"], day_full: ["Duminica", "Luni", "Marti", "Miercuri", "Joi", "Vineri", "Sambata"], day_short: ["Du", "Lu", "Ma", "Mi", "Jo", "Vi", "Sa"] }, labels: { dhx_cal_today_button: "Astazi", day_tab: "Zi", week_tab: "Saptamana", month_tab: "Luna", new_event: "Eveniment nou", icon_save: "Salveaza", icon_cancel: "Anuleaza", icon_details: "Detalii", icon_edit: "Editeaza", icon_delete: "Sterge", confirm_closing: "Schimbarile nu vor fi salvate, esti sigur?", confirm_deleting: "Evenimentul va fi sters permanent, esti sigur?", section_description: "Descriere", section_time: "Interval", full_day: "Toata ziua", confirm_recurring: "Vrei sa editezi toata seria de evenimente repetate?", section_recurring: "Repetare", button_recurring: "Dezactivata", button_recurring_open: "Activata", button_edit_series: "Editeaza serie", button_edit_occurrence: "Editeaza doar intrare", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Agenda", date: "Data", description: "Descriere", year_tab: "An", week_agenda_tab: "Agenda", grid_tab: "Lista", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Zilnic", repeat_radio_week: "Saptamanal", repeat_radio_month: "Lunar", repeat_radio_year: "Anual", repeat_radio_day_type: "La fiecare", repeat_text_day_count: "zi(le)", repeat_radio_day_type2: "Fiecare zi lucratoare", repeat_week: " Repeta la fiecare", repeat_text_week_count: "saptamana in urmatoarele zile:", repeat_radio_month_type: "Repeta in", repeat_radio_month_start: "In a", repeat_text_month_day: "zi la fiecare", repeat_text_month_count: "luni", repeat_text_month_count2_before: "la fiecare", repeat_text_month_count2_after: "luni", repeat_year_label: "In", select_year_day2: "a lunii", repeat_text_year_day: "zi a lunii", select_year_month: "", repeat_radio_end: "Fara data de sfarsit", repeat_text_occurrences_count: "evenimente", repeat_radio_end3: "La data", repeat_radio_end2: "Dupa", repeat_never: "Niciodată", repeat_daily: "În fiecare zi", repeat_workdays: "În fiecare zi lucrătoare", repeat_weekly: "În fiecare săptămână", repeat_monthly: "În fiecare lună", repeat_yearly: "În fiecare an", repeat_custom: "Personalizat", repeat_freq_day: "Zi", repeat_freq_week: "Săptămână", repeat_freq_month: "Lună", repeat_freq_year: "An", repeat_on_date: "La data", repeat_ends: "Se termină", month_for_recurring: ["Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"], day_for_recurring: ["Duminica", "Luni", "Marti", "Miercuri", "Joi", "Vineri", "Sambata"] } }, ru: { date: { month_full: ["Январь", "Февраль", "Март", "Апрель", "Maй", "Июнь", "Июль", "Август", "Сентябрь", "Oктябрь", "Ноябрь", "Декабрь"], month_short: ["Янв", "Фев", "Maр", "Aпр", "Maй", "Июн", "Июл", "Aвг", "Сен", "Окт", "Ноя", "Дек"], day_full: ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"], day_short: ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"] }, labels: { dhx_cal_today_button: "Сегодня", day_tab: "День", week_tab: "Неделя", month_tab: "Месяц", new_event: "Новое событие", icon_save: "Сохранить", icon_cancel: "Отменить", icon_details: "Детали", icon_edit: "Изменить", icon_delete: "Удалить", confirm_closing: "", confirm_deleting: "Событие будет удалено безвозвратно, продолжить?", section_description: "Описание", section_time: "Период времени", full_day: "Весь день", confirm_recurring: "Вы хотите изменить всю серию повторяющихся событий?", section_recurring: "Повторение", button_recurring: "Отключено", button_recurring_open: "Включено", button_edit_series: "Редактировать серию", button_edit_occurrence: "Редактировать экземпляр", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Список", date: "Дата", description: "Описание", year_tab: "Год", week_agenda_tab: "Список", grid_tab: "Таблица", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "День", repeat_radio_week: "Неделя", repeat_radio_month: "Месяц", repeat_radio_year: "Год", repeat_radio_day_type: "Каждый", repeat_text_day_count: "день", repeat_radio_day_type2: "Каждый рабочий день", repeat_week: " Повторять каждую", repeat_text_week_count: "неделю , в:", repeat_radio_month_type: "Повторять", repeat_radio_month_start: "", repeat_text_month_day: " числа каждый ", repeat_text_month_count: "месяц", repeat_text_month_count2_before: "каждый ", repeat_text_month_count2_after: "месяц", repeat_year_label: "", select_year_day2: "", repeat_text_year_day: "день", select_year_month: "", repeat_radio_end: "Без даты окончания", repeat_text_occurrences_count: "повторений", repeat_radio_end3: "До ", repeat_radio_end2: "", repeat_never: "Никогда", repeat_daily: "Каждый день", repeat_workdays: "Каждый будний день", repeat_weekly: "Каждую неделю", repeat_monthly: "Каждый месяц", repeat_yearly: "Каждый год", repeat_custom: "Настроить", repeat_freq_day: "День", repeat_freq_week: "Неделя", repeat_freq_month: "Месяц", repeat_freq_year: "Год", repeat_on_date: "В дату", repeat_ends: "Заканчивается", month_for_recurring: ["Января", "Февраля", "Марта", "Апреля", "Мая", "Июня", "Июля", "Августа", "Сентября", "Октября", "Ноября", "Декабря"], day_for_recurring: ["Воскресенье", "Понедельник", "Вторник", "Среду", "Четверг", "Пятницу", "Субботу"] } }, si: { date: { month_full: ["Januar", "Februar", "Marec", "April", "Maj", "Junij", "Julij", "Avgust", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Nedelja", "Ponedeljek", "Torek", "Sreda", "Četrtek", "Petek", "Sobota"], day_short: ["Ned", "Pon", "Tor", "Sre", "Čet", "Pet", "Sob"] }, labels: { dhx_cal_today_button: "Danes", day_tab: "Dan", week_tab: "Teden", month_tab: "Mesec", new_event: "Nov dogodek", icon_save: "Shrani", icon_cancel: "Prekliči", icon_details: "Podrobnosti", icon_edit: "Uredi", icon_delete: "Izbriši", confirm_closing: "", confirm_deleting: "Dogodek bo izbrisan. Želite nadaljevati?", section_description: "Opis", section_time: "Časovni okvir", full_day: "Ves dan", confirm_recurring: "Želite urediti celoten set ponavljajočih dogodkov?", section_recurring: "Ponovi dogodek", button_recurring: "Onemogočeno", button_recurring_open: "Omogočeno", button_edit_series: "Edit series", button_edit_occurrence: "Edit occurrence", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Zadeva", date: "Datum", description: "Opis", year_tab: "Leto", week_agenda_tab: "Zadeva", grid_tab: "Miza", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Dnevno", repeat_radio_week: "Tedensko", repeat_radio_month: "Mesečno", repeat_radio_year: "Letno", repeat_radio_day_type: "Vsak", repeat_text_day_count: "dan", repeat_radio_day_type2: "Vsak delovni dan", repeat_week: " Ponavljaj vsak", repeat_text_week_count: "teden na naslednje dni:", repeat_radio_month_type: "Ponavljaj", repeat_radio_month_start: "Na", repeat_text_month_day: "dan vsak", repeat_text_month_count: "mesec", repeat_text_month_count2_before: "vsak", repeat_text_month_count2_after: "mesec", repeat_year_label: "Na", select_year_day2: "od", repeat_text_year_day: "dan", select_year_month: "mesec", repeat_radio_end: "Brez končnega datuma", repeat_text_occurrences_count: "pojavitve", repeat_radio_end2: "Po", repeat_radio_end3: "Končaj do", repeat_never: "Nikoli", repeat_daily: "Vsak dan", repeat_workdays: "Vsak delovni dan", repeat_weekly: "Vsak teden", repeat_monthly: "Vsak mesec", repeat_yearly: "Vsako leto", repeat_custom: "Po meri", repeat_freq_day: "Dan", repeat_freq_week: "Teden", repeat_freq_month: "Mesec", repeat_freq_year: "Leto", repeat_on_date: "Na datum", repeat_ends: "Konča se", month_for_recurring: ["Januar", "Februar", "Marec", "April", "Maj", "Junij", "Julij", "Avgust", "September", "Oktober", "November", "December"], day_for_recurring: ["Nedelja", "Ponedeljek", "Torek", "Sreda", "Četrtek", "Petek", "Sobota"] } }, sk: { date: { month_full: ["Január", "Február", "Marec", "Apríl", "Máj", "Jún", "Júl", "August", "September", "Október", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Máj", "Jún", "Júl", "Aug", "Sept", "Okt", "Nov", "Dec"], day_full: ["Nedeľa", "Pondelok", "Utorok", "Streda", "Štvrtok", "Piatok", "Sobota"], day_short: ["Ne", "Po", "Ut", "St", "Št", "Pi", "So"] }, labels: { dhx_cal_today_button: "Dnes", day_tab: "Deň", week_tab: "Týždeň", month_tab: "Mesiac", new_event: "Nová udalosť", icon_save: "Uložiť", icon_cancel: "Späť", icon_details: "Detail", icon_edit: "Edituj", icon_delete: "Zmazať", confirm_closing: "Vaše zmeny nebudú uložené. Skutočne?", confirm_deleting: "Udalosť bude natrvalo vymazaná. Skutočne?", section_description: "Poznámky", section_time: "Doba platnosti", confirm_recurring: "Prajete si upraviť celú radu opakovaných udalostí?", section_recurring: "Opakovanie udalosti", button_recurring: "Vypnuté", button_recurring_open: "Zapnuté", button_edit_series: "Upraviť opakovania", button_edit_occurrence: "Upraviť inštancie", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Program", date: "Dátum", description: "Poznámka", year_tab: "Rok", full_day: "Celý deň", week_agenda_tab: "Program", grid_tab: "Mriežka", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Denne", repeat_radio_week: "Týždenne", repeat_radio_month: "Mesaène", repeat_radio_year: "Roène", repeat_radio_day_type: "Každý", repeat_text_day_count: "deò", repeat_radio_day_type2: "Každý prac. deò", repeat_week: "Opakova každý", repeat_text_week_count: "týždeò v dòoch:", repeat_radio_month_type: "Opakova", repeat_radio_month_start: "On", repeat_text_month_day: "deò každý", repeat_text_month_count: "mesiac", repeat_text_month_count2_before: "každý", repeat_text_month_count2_after: "mesiac", repeat_year_label: "On", select_year_day2: "poèas", repeat_text_year_day: "deò", select_year_month: "mesiac", repeat_radio_end: "Bez dátumu ukonèenia", repeat_text_occurrences_count: "udalostiach", repeat_radio_end3: "Ukonèi", repeat_radio_end2: "Po", repeat_never: "Nikdy", repeat_daily: "Každý deň", repeat_workdays: "Každý pracovný deň", repeat_weekly: "Každý týždeň", repeat_monthly: "Každý mesiac", repeat_yearly: "Každý rok", repeat_custom: "Vlastné", repeat_freq_day: "Deň", repeat_freq_week: "Týždeň", repeat_freq_month: "Mesiac", repeat_freq_year: "Rok", repeat_on_date: "Na dátum", repeat_ends: "Koniec", month_for_recurring: ["Január", "Február", "Marec", "Apríl", "Máj", "Jún", "Júl", "August", "September", "Október", "November", "December"], day_for_recurring: ["Nede¾a", "Pondelok", "Utorok", "Streda", "Štvrtok", "Piatok", "Sobota"] } }, sv: { date: { month_full: ["Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December"], month_short: ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"], day_full: ["Söndag", "Måndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "Lördag"], day_short: ["Sön", "Mån", "Tis", "Ons", "Tor", "Fre", "Lör"] }, labels: { dhx_cal_today_button: "Idag", day_tab: "Dag", week_tab: "Vecka", month_tab: "Månad", new_event: "Ny händelse", icon_save: "Spara", icon_cancel: "Ångra", icon_details: "Detaljer", icon_edit: "Ändra", icon_delete: "Ta bort", confirm_closing: "", confirm_deleting: "Är du säker på att du vill ta bort händelsen permanent?", section_description: "Beskrivning", section_time: "Tid", full_day: "Hela dagen", confirm_recurring: "Vill du redigera hela serien med repeterande händelser?", section_recurring: "Upprepa händelse", button_recurring: "Inaktiverat", button_recurring_open: "Aktiverat", button_edit_series: "Redigera serien", button_edit_occurrence: "Redigera en kopia", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Dagordning", date: "Datum", description: "Beskrivning", year_tab: "År", week_agenda_tab: "Dagordning", grid_tab: "Galler", drag_to_create: "Dra för att skapa ny", drag_to_move: "Dra för att flytta", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Dagligen", repeat_radio_week: "Veckovis", repeat_radio_month: "Månadsvis", repeat_radio_year: "Årligen", repeat_radio_day_type: "Var", repeat_text_day_count: "dag", repeat_radio_day_type2: "Varje arbetsdag", repeat_week: " Upprepa var", repeat_text_week_count: "vecka dessa dagar:", repeat_radio_month_type: "Upprepa", repeat_radio_month_start: "Den", repeat_text_month_day: "dagen var", repeat_text_month_count: "månad", repeat_text_month_count2_before: "var", repeat_text_month_count2_after: "månad", repeat_year_label: "Den", select_year_day2: "i", repeat_text_year_day: "dag i", select_year_month: "månad", repeat_radio_end: "Inget slutdatum", repeat_text_occurrences_count: "upprepningar", repeat_radio_end3: "Sluta efter", repeat_radio_end2: "Efter", repeat_never: "Aldrig", repeat_daily: "Varje dag", repeat_workdays: "Varje vardag", repeat_weekly: "Varje vecka", repeat_monthly: "Varje månad", repeat_yearly: "Varje år", repeat_custom: "Anpassad", repeat_freq_day: "Dag", repeat_freq_week: "Vecka", repeat_freq_month: "Månad", repeat_freq_year: "År", repeat_on_date: "På datum", repeat_ends: "Slutar", month_for_recurring: ["Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December"], day_for_recurring: ["Söndag", "Måndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "Lördag"] } }, tr: { date: { month_full: ["Ocak", "Þubat", "Mart", "Nisan", "Mayýs", "Haziran", "Temmuz", "Aðustos", "Eylül", "Ekim", "Kasým", "Aralýk"], month_short: ["Oca", "Þub", "Mar", "Nis", "May", "Haz", "Tem", "Aðu", "Eyl", "Eki", "Kas", "Ara"], day_full: ["Pazar", "Pazartes,", "Salý", "Çarþamba", "Perþembe", "Cuma", "Cumartesi"], day_short: ["Paz", "Pts", "Sal", "Çar", "Per", "Cum", "Cts"] }, labels: { dhx_cal_today_button: "Bugün", day_tab: "Gün", week_tab: "Hafta", month_tab: "Ay", new_event: "Uygun", icon_save: "Kaydet", icon_cancel: "Ýptal", icon_details: "Detaylar", icon_edit: "Düzenle", icon_delete: "Sil", confirm_closing: "", confirm_deleting: "Etkinlik silinecek, devam?", section_description: "Açýklama", section_time: "Zaman aralýðý", full_day: "Tam gün", confirm_recurring: "Tüm tekrar eden etkinlikler silinecek, devam?", section_recurring: "Etkinliði tekrarla", button_recurring: "Pasif", button_recurring_open: "Aktif", button_edit_series: "Dizi düzenleme", button_edit_occurrence: "Bir kopyasını düzenleyin", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Ajanda", date: "Tarih", description: "Açýklama", year_tab: "Yýl", week_agenda_tab: "Ajanda", grid_tab: "Izgara", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "Günlük", repeat_radio_week: "Haftalık", repeat_radio_month: "Aylık", repeat_radio_year: "Yıllık", repeat_radio_day_type: "Her", repeat_text_day_count: "gün", repeat_radio_day_type2: "Her iş günü", repeat_week: " Tekrar her", repeat_text_week_count: "hafta şu günlerde:", repeat_radio_month_type: "Tekrar et", repeat_radio_month_start: "Tarihinde", repeat_text_month_day: "gün her", repeat_text_month_count: "ay", repeat_text_month_count2_before: "her", repeat_text_month_count2_after: "ay", repeat_year_label: "Tarihinde", select_year_day2: "ayın", repeat_text_year_day: "günü", select_year_month: "ay", repeat_radio_end: "Bitiş tarihi yok", repeat_text_occurrences_count: "olay", repeat_radio_end2: "Sonra", repeat_radio_end3: "Tarihinde bitir", repeat_never: "Asla", repeat_daily: "Her gün", repeat_workdays: "Her iş günü", repeat_weekly: "Her hafta", repeat_monthly: "Her ay", repeat_yearly: "Her yıl", repeat_custom: "Özel", repeat_freq_day: "Gün", repeat_freq_week: "Hafta", repeat_freq_month: "Ay", repeat_freq_year: "Yıl", repeat_on_date: "Tarihinde", repeat_ends: "Biter", month_for_recurring: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"], day_for_recurring: ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"] } }, ua: { date: { month_full: ["Січень", "Лютий", "Березень", "Квітень", "Травень", "Червень", "Липень", "Серпень", "Вересень", "Жовтень", "Листопад", "Грудень"], month_short: ["Січ", "Лют", "Бер", "Кві", "Тра", "Чер", "Лип", "Сер", "Вер", "Жов", "Лис", "Гру"], day_full: ["Неділя", "Понеділок", "Вівторок", "Середа", "Четвер", "П'ятниця", "Субота"], day_short: ["Нед", "Пон", "Вів", "Сер", "Чет", "Птн", "Суб"] }, labels: { dhx_cal_today_button: "Сьогодні", day_tab: "День", week_tab: "Тиждень", month_tab: "Місяць", new_event: "Нова подія", icon_save: "Зберегти", icon_cancel: "Відміна", icon_details: "Деталі", icon_edit: "Редагувати", icon_delete: "Вилучити", confirm_closing: "", confirm_deleting: "Подія вилучиться назавжди. Ви впевнені?", section_description: "Опис", section_time: "Часовий проміжок", full_day: "Весь день", confirm_recurring: "Хочете редагувати весь перелік повторюваних подій?", section_recurring: "Повторювана подія", button_recurring: "Відключено", button_recurring_open: "Включено", button_edit_series: "Редагувати серію", button_edit_occurrence: "Редагувати примірник", button_edit_occurrence_and_following: "This and following events", agenda_tab: "Перелік", date: "Дата", description: "Опис", year_tab: "Рік", week_agenda_tab: "Перелік", grid_tab: "Таблиця", drag_to_create: "Drag to create", drag_to_move: "Drag to move", message_ok: "OK", message_cancel: "Cancel", next: "Next", prev: "Previous", year: "Year", month: "Month", day: "Day", hour: "Hour", minute: "Minute", repeat_radio_day: "День", repeat_radio_week: "Тиждень", repeat_radio_month: "Місяць", repeat_radio_year: "Рік", repeat_radio_day_type: "Кожний", repeat_text_day_count: "день", repeat_radio_day_type2: "Кожний робочий день", repeat_week: " Повторювати кожен", repeat_text_week_count: "тиждень , по:", repeat_radio_month_type: "Повторювати", repeat_radio_month_start: "", repeat_text_month_day: " числа кожний ", repeat_text_month_count: "місяць", repeat_text_month_count2_before: "кожен ", repeat_text_month_count2_after: "місяць", repeat_year_label: "", select_year_day2: "", repeat_text_year_day: "день", select_year_month: "", repeat_radio_end: "Без дати закінчення", repeat_text_occurrences_count: "повторень", repeat_radio_end3: "До ", repeat_radio_end2: "", repeat_never: "Ніколи", repeat_daily: "Щодня", repeat_workdays: "Щодня в робочі дні", repeat_weekly: "Щотижня", repeat_monthly: "Щомісяця", repeat_yearly: "Щороку", repeat_custom: "Налаштоване", repeat_freq_day: "День", repeat_freq_week: "Тиждень", repeat_freq_month: "Місяць", repeat_freq_year: "Рік", repeat_on_date: "На дату", repeat_ends: "Закінчується", month_for_recurring: ["січня", "лютого", "березня", "квітня", "травня", "червня", "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"], day_for_recurring: ["Неділям", "Понеділкам", "Вівторкам", "Середам", "Четвергам", "П'ятницям", "Суботам"] } } }, Symbol.toStringTag, { value: "Module" }));
class ia {
  constructor(i, t, n = {}) {
    this.state = { date: /* @__PURE__ */ new Date(), modes: ["days", "months", "years"], currentRange: [], eventDates: [], filterDays: null, currentModeIndex: 0, ...n }, this.container = null, this.element = null, this.onStateChangeHandlers = [], this.scheduler = i, this._domEvents = i._createDomEventScope(), this.state = this.getState(), Ye(this), t && (this.container = t, this.render(this.container)), this.onStateChange((s, a) => {
      this.callEvent("onStateChange", [a, s]);
    });
  }
  getState() {
    return { ...this.state, mode: this.state.modes[this.state.currentModeIndex] };
  }
  setState(i) {
    const t = { ...this.state };
    i.mode && (i.currentModeIndex = this.state.modes.indexOf(i.mode)), this.state = { ...this.state, ...i }, this._notifyStateChange(t, this.state), this.container && this.render(this.container);
  }
  onStateChange(i) {
    return this.onStateChangeHandlers.push(i), () => {
      const t = this.onStateChangeHandlers.indexOf(i);
      t !== -1 && this.onStateChangeHandlers.splice(t, 1);
    };
  }
  _notifyStateChange(i, t) {
    this.onStateChangeHandlers.forEach((n) => n(i, t));
  }
  _adjustDate(i) {
    const { mode: t, date: n } = this.getState(), s = new Date(n);
    t === "days" ? s.setMonth(n.getMonth() + i) : t === "months" ? s.setFullYear(n.getFullYear() + i) : s.setFullYear(n.getFullYear() + 10 * i), this.setState({ date: s });
  }
  _toggleMode() {
    const i = (this.state.currentModeIndex + 1) % this.state.modes.length;
    this.setState({ currentModeIndex: i });
  }
  _renderCalendarHeader(i) {
    const { mode: t, date: n } = this.getState(), s = document.createElement("div");
    s.classList.add("dhx_cal_datepicker_header");
    const a = document.createElement("button");
    a.classList.add("dhx_cal_datepicker_arrow", "scheduler_icon", "arrow_left"), s.appendChild(a);
    const o = document.createElement("div");
    if (o.classList.add("dhx_cal_datepicker_title"), t === "days")
      o.innerText = n.toLocaleString("default", { month: "long" }) + " " + n.getFullYear();
    else if (t === "months")
      o.innerText = n.getFullYear();
    else {
      const r = 10 * Math.floor(n.getFullYear() / 10);
      o.innerText = `${r} - ${r + 9}`;
    }
    this._domEvents.attach(o, "click", this._toggleMode.bind(this)), s.appendChild(o);
    const d = document.createElement("button");
    d.classList.add("dhx_cal_datepicker_arrow", "scheduler_icon", "arrow_right"), s.appendChild(d), i.appendChild(s), this._domEvents.attach(a, "click", this._adjustDate.bind(this, -1)), this._domEvents.attach(d, "click", this._adjustDate.bind(this, 1));
  }
  render(i) {
    this._domEvents.detachAll(), this.container = i || this.container, this.container.innerHTML = "", this.element || (this.element = document.createElement("div"), this.element.classList.add("dhx_cal_datepicker")), this.element.innerHTML = "", this.container.appendChild(this.element), this._renderCalendarHeader(this.element);
    const t = document.createElement("div");
    t.classList.add("dhx_cal_datepicker_data"), this.element.appendChild(t);
    const { mode: n } = this.getState();
    n === "days" ? this._renderDayGrid(t) : n === "months" ? this._renderMonthGrid(t) : this._renderYearGrid(t);
  }
  _renderDayGridHeader(i) {
    const { date: t, filterDays: n } = this.getState(), s = this.scheduler;
    let a = s.date.week_start(new Date(t));
    const o = s.date.add(s.date.week_start(new Date(t)), 1, "week");
    i.classList.add("dhx_cal_datepicker_days");
    const d = s.date.date_to_str("%D");
    for (; a.valueOf() < o.valueOf(); ) {
      if (!n || !n(a)) {
        const r = d(a), l = document.createElement("div");
        l.setAttribute("data-day", a.getDay()), l.classList.add("dhx_cal_datepicker_dayname"), l.innerText = r, i.appendChild(l);
      }
      a = s.date.add(a, 1, "day");
    }
  }
  _weeksBetween(i, t) {
    const n = this.scheduler;
    let s = 0, a = new Date(i);
    for (; a.valueOf() < t.valueOf(); )
      s += 1, a = n.date.week_start(n.date.add(a, 1, "week"));
    return s;
  }
  _renderDayGrid(i) {
    const { date: t, currentRange: n, eventDates: s, minWeeks: a, filterDays: o } = this.getState();
    let d = n[0], r = n[1];
    const l = s.reduce((M, k) => (M[this.scheduler.date.day_start(new Date(k)).valueOf()] = !0, M), {}), _ = document.createElement("div");
    this._renderDayGridHeader(_);
    const h = _.children.length;
    i.appendChild(_), h !== 7 && i.style.setProperty("--dhx-scheduler-week-length", h);
    const p = this.scheduler, v = p.date.week_start(p.date.month_start(new Date(t))), g = p.date.month_start(new Date(t)), c = p.date.add(p.date.month_start(new Date(t)), 1, "month");
    let f = p.date.add(p.date.month_start(new Date(t)), 1, "month");
    const u = p.date.date_part(p._currentDate());
    if (f.getDay() !== 0 && p.config.start_on_monday) {
      const M = (7 - f.getDay()) % 7;
      f = p.date.add(f, M + 1, "day");
    } else
      f = p.date.add(p.date.week_start(f), 1, "week");
    let y = this._weeksBetween(v, f);
    a && y < a && (f = p.date.add(f, a - y, "week"));
    let w = v;
    const D = document.createElement("div");
    for (D.classList.add("dhx_cal_datepicker_days"), this._domEvents.attach(D, "click", (M) => {
      const k = M.target.closest("[data-cell-date]"), N = new Date(k.getAttribute("data-cell-date"));
      this.callEvent("onDateClick", [N, M]);
    }); w.valueOf() < f.valueOf(); ) {
      if (!o || !o(w)) {
        const M = document.createElement("div");
        M.setAttribute("data-cell-date", p.templates.format_date(w)), M.setAttribute("data-day", w.getDay()), M.innerHTML = p.templates.month_day(w), w.valueOf() < g.valueOf() ? M.classList.add("dhx_before") : w.valueOf() >= c.valueOf() && M.classList.add("dhx_after"), w.getDay() !== 0 && w.getDay() !== 6 || M.classList.add("dhx_cal_datepicker_weekend"), w.valueOf() == u.valueOf() && M.classList.add("dhx_now"), d && r && w.valueOf() >= d.valueOf() && w.valueOf() < r.valueOf() && M.classList.add("dhx_cal_datepicker_current"), l[w.valueOf()] && M.classList.add("dhx_cal_datepicker_event"), M.classList.add("dhx_cal_datepicker_date"), D.appendChild(M);
      }
      w = p.date.add(w, 1, "day");
    }
    i.appendChild(D);
  }
  _renderMonthGrid(i) {
    const { date: t } = this.getState(), n = document.createElement("div");
    n.classList.add("dhx_cal_datepicker_months");
    const s = [];
    for (let r = 0; r < 12; r++)
      s.push(new Date(t.getFullYear(), r, 1));
    const a = this.scheduler.date.date_to_str("%M");
    s.forEach((r) => {
      const l = document.createElement("div");
      l.classList.add("dhx_cal_datepicker_month"), t.getMonth() === r.getMonth() && l.classList.add("dhx_cal_datepicker_current"), l.setAttribute("data-month", r.getMonth()), l.innerHTML = a(r), this._domEvents.attach(l, "click", () => {
        const _ = new Date(r);
        this.setState({ date: _, mode: "days" });
      }), n.appendChild(l);
    }), i.appendChild(n);
    const o = document.createElement("div");
    o.classList.add("dhx_cal_datepicker_done");
    const d = document.createElement("button");
    d.innerText = "Done", d.classList.add("dhx_cal_datepicker_done_btn"), this._domEvents.attach(d, "click", () => {
      this.setState({ mode: "days" });
    }), o.appendChild(d), i.appendChild(o);
  }
  _renderYearGrid(i) {
    const { date: t } = this.getState(), n = 10 * Math.floor(t.getFullYear() / 10), s = document.createElement("div");
    s.classList.add("dhx_cal_datepicker_years");
    for (let d = n - 1; d <= n + 10; d++) {
      const r = document.createElement("div");
      r.innerText = d, r.classList.add("dhx_cal_datepicker_year"), r.setAttribute("data-year", d), t.getFullYear() === d && r.classList.add("dhx_cal_datepicker_current"), this._domEvents.attach(r, "click", () => {
        this.setState({ date: new Date(d, t.getMonth(), 1), mode: "months" });
      }), s.appendChild(r);
    }
    i.appendChild(s);
    const a = document.createElement("div");
    a.classList.add("dhx_cal_datepicker_done");
    const o = document.createElement("button");
    o.innerText = "Done", o.classList.add("dhx_cal_datepicker_done_btn"), this._domEvents.attach(o, "click", () => {
      this.setState({ mode: "months" });
    }), a.appendChild(o), i.appendChild(a);
  }
  destructor() {
    this.onStateChangeHandlers = [], this.element && (this.element.innerHTML = "", this.element.remove()), this._domEvents.detachAll(), this.callEvent("onDestroy", []), this.detachAllEvents(), this.scheduler = null;
  }
}
function oa(e) {
  const i = { version: "7.2.15" };
  i.$stateProvider = function() {
    const r = {};
    return { getState: function(l) {
      if (r[l])
        return r[l].method();
      {
        const _ = {};
        for (const h in r)
          r[h].internal || ne.mixin(_, r[h].method(), !0);
        return _;
      }
    }, registerProvider: function(l, _, h) {
      r[l] = { method: _, internal: h };
    }, unregisterProvider: function(l) {
      delete r[l];
    } };
  }(), i.getState = i.$stateProvider.getState, function(r) {
    var l = { agenda: "https://docs.dhtmlx.com/scheduler/agenda_view.html", grid: "https://docs.dhtmlx.com/scheduler/grid_view.html", map: "https://docs.dhtmlx.com/scheduler/map_view.html", unit: "https://docs.dhtmlx.com/scheduler/units_view.html", timeline: "https://docs.dhtmlx.com/scheduler/timeline_view.html", week_agenda: "https://docs.dhtmlx.com/scheduler/weekagenda_view.html", year: "https://docs.dhtmlx.com/scheduler/year_view.html", anythingElse: "https://docs.dhtmlx.com/scheduler/views.html" }, _ = { agenda: "scheduler.plugins({ agenda_view: true })", grid: "scheduler.plugins({ grid_view: true })", map: "scheduler.plugins({ map_view: true })", unit: "scheduler.plugins({ units: true })", timeline: "scheduler.plugins({ timeline: true, treetimeline: true, daytimeline: true})", week_agenda: "scheduler.plugins({ week_agenda: true })", year: "scheduler.plugins({ year_view: true })", limit: "scheduler.plugins({ limit: true })" };
    r._commonErrorMessages = { unknownView: function(h) {
      var p = _[h] ? "You're probably missing " + _[h] + "." : "";
      return "`" + h + "` view is not defined. \nPlease check parameters you pass to `scheduler.init` or `scheduler.setCurrentView` in your code and ensure you've imported appropriate extensions. \nRelated docs: " + (l[h] || l.anythingElse) + `
` + (p ? p + `
` : "");
    }, collapsedContainer: function(h) {
      return `Scheduler container height is set to *100%* but the rendered height is zero and the scheduler is not visible. 
Make sure that the container has some initial height or use different units. For example:
<div id='scheduler_here' class='dhx_cal_container' style='width:100%; height:600px;'> 
`;
    } }, r.createTimelineView = function() {
      throw new Error("scheduler.createTimelineView is not implemented. Be sure to add the required extension: " + _.timeline + `
Related docs: ` + l.timeline);
    }, r.createUnitsView = function() {
      throw new Error("scheduler.createUnitsView is not implemented. Be sure to add the required extension: " + _.unit + `
Related docs: ` + l.unit);
    }, r.createGridView = function() {
      throw new Error("scheduler.createGridView is not implemented. Be sure to add the required extension: " + _.grid + `
Related docs: ` + l.grid);
    }, r.addMarkedTimespan = function() {
      throw new Error(`scheduler.addMarkedTimespan is not implemented. Be sure to add the required extension: scheduler.plugins({ limit: true })
Related docs: https://docs.dhtmlx.com/scheduler/limits.html`);
    }, r.renderCalendar = function() {
      throw new Error(`scheduler.renderCalendar is not implemented. Be sure to add the required extension: scheduler.plugins({ minical: true })
https://docs.dhtmlx.com/scheduler/minicalendar.html`);
    }, r.exportToPNG = function() {
      throw new Error(["scheduler.exportToPNG is not implemented.", "This feature requires an additional module, be sure to check the related doc here https://docs.dhtmlx.com/scheduler/png.html", "Licensing info: https://dhtmlx.com/docs/products/dhtmlxScheduler/export.shtml"].join(`
`));
    }, r.exportToPDF = function() {
      throw new Error(["scheduler.exportToPDF is not implemented.", "This feature requires an additional module, be sure to check the related doc here https://docs.dhtmlx.com/scheduler/pdf.html", "Licensing info: https://dhtmlx.com/docs/products/dhtmlxScheduler/export.shtml"].join(`
`));
    };
  }(i), Ut(i), function(r) {
    Ye(r), qt(r), r._detachDomEvent = function(c, f, u) {
      c.removeEventListener ? c.removeEventListener(f, u, !1) : c.detachEvent && c.detachEvent("on" + f, u);
    }, r._init_once = function() {
      jt(r), r._init_once = function() {
      };
    };
    const l = { render: function(c) {
      return r._init_nav_bar(c);
    } }, _ = { render: function(c) {
      const f = document.createElement("div");
      return f.className = "dhx_cal_header", f;
    } }, h = { render: function(c) {
      const f = document.createElement("div");
      return f.className = "dhx_cal_data", f;
    } };
    function p(c) {
      return !!(c.querySelector(".dhx_cal_header") && c.querySelector(".dhx_cal_data") && c.querySelector(".dhx_cal_navline"));
    }
    r._getInitialState = function(c) {
      return { date: c.date || this._currentDate(), mode: c.mode || "week" };
    }, r.init = function(c, f, u) {
      if (this.$destroyed)
        return;
      if (this._obj = typeof c == "string" ? document.getElementById(c) : c, this.$container = this._obj, this.$root = this._obj, this._obj && this.unset_actions(), !this.$container.offsetHeight && this.$container.offsetWidth && this.$container.style.height === "100%" && window.console.error(r._commonErrorMessages.collapsedContainer(), this.$container), this.config.wai_aria_attributes && this.config.wai_aria_application_role && this.$container.setAttribute("role", "application"), this.config.header || p(this.$container) || (this.config.header = function(M) {
        const k = ["day", "week", "month"];
        if (M.matrix)
          for (const N in M.matrix)
            k.push(N);
        if (M._props)
          for (const N in M._props)
            k.push(N);
        if (M._grid && M._grid.names)
          for (const N in M._grid.names)
            k.push(N);
        return ["map", "agenda", "week_agenda", "year"].forEach(function(N) {
          M[N + "_view"] && k.push(N);
        }), k.concat(["date"]).concat(["prev", "today", "next"]);
      }(this), window.console.log(["Required DOM elements are missing from the scheduler container and **scheduler.config.header** is not specified.", "Using a default header configuration: ", "scheduler.config.header = " + JSON.stringify(this.config.header, null, 2), "Check this article for the details: https://docs.dhtmlx.com/scheduler/initialization.html"].join(`
`))), this.config.header)
        this.$container.innerHTML = "", this.$container.classList.add("dhx_cal_container"), this.config.header.height && (this.xy.nav_height = this.config.header.height), this.$container.appendChild(l.render(this.config.header)), this.$container.appendChild(_.render()), this.$container.appendChild(h.render());
      else if (!p(this.$container))
        throw new Error(["Required DOM elements are missing from the scheduler container.", "Be sure to either specify them manually in the markup: https://docs.dhtmlx.com/scheduler/initialization.html#initializingschedulerviamarkup", "Or to use **scheduler.config.header** setting so they could be created automatically: https://docs.dhtmlx.com/scheduler/initialization.html#initializingschedulerviaheaderconfig"].join(`
`));
      this.config.rtl && (this.$container.className += " dhx_cal_container_rtl"), this._skin_init && r._skin_init(), r.date.init(), this._scroll = !0, this._els = [], this.get_elements(), this.init_templates(), this.set_actions(), this._init_once(), this._init_touch_events(), this.set_sizes();
      const y = r._getInitialState({ date: f, mode: u }), w = y.date, D = y.mode;
      r.callEvent("onSchedulerReady", []), r.$initialized = !0, this.setCurrentView(w, D);
    }, r.xy = { min_event_height: 20, bar_height: 24, scale_width: 50, scroll_width: 18, scale_height: 20, month_scale_height: 20, menu_width: 25, margin_top: 0, margin_left: 0, editor_width: 140, month_head_height: 22, event_header_height: 14 }, r.keys = { edit_save: 13, edit_cancel: 27 }, r.bind = function(c, f) {
      return c.bind ? c.bind(f) : function() {
        return c.apply(f, arguments);
      };
    }, r.set_sizes = function() {
      var c = this._x = this._obj.clientWidth - this.xy.margin_left, f = this._table_view ? 0 : this.xy.scale_width + this.xy.scroll_width, u = this.$container.querySelector(".dhx_cal_scale_placeholder");
      if (r._is_material_skin()) {
        u || ((u = document.createElement("div")).className = "dhx_cal_scale_placeholder", this.$container.insertBefore(u, this._els.dhx_cal_header[0])), u.style.display = "block";
        const w = r.$root.querySelector(".dhx_cal_navline");
        let D = 0;
        w && (D += w.offsetHeight);
        const M = r.$root.querySelector(".dhx_cal_header");
        let k, N, m = 0;
        M && (m += M.offsetHeight), m ? (k = D + 1, N = m) : (k = D - 4, N = 5), this.set_xy(u, c, N, 0, k);
      } else
        u && u.parentNode.removeChild(u);
      this._lightbox && (r.$container.offsetWidth < 1200 || this._setLbPosition(document.querySelector(".dhx_cal_light"))), this._data_width = c - f, this._els.dhx_cal_navline[0].style.width = c + "px";
      const y = this._els.dhx_cal_header[0];
      this.set_xy(y, this._data_width, this.xy.scale_height), y.style.left = "", y.style.right = "", this._table_view ? this.config.rtl ? y.style.right = "-1px" : y.style.left = "-1px" : this.config.rtl ? y.style.right = `${this.xy.scale_width}px` : y.style.left = `${this.xy.scale_width}px`;
    }, r.set_xy = function(c, f, u, y, w) {
      function D(k) {
        let N = k;
        return isNaN(Number(N)) || (N = Math.max(0, N) + "px"), N;
      }
      var M = "left";
      f !== void 0 && (c.style.width = D(f)), u !== void 0 && (c.style.height = D(u)), arguments.length > 3 && (y !== void 0 && (this.config.rtl && (M = "right"), c.style[M] = y + "px"), w !== void 0 && (c.style.top = w + "px"));
    }, r.get_elements = function() {
      const c = this._obj.getElementsByTagName("DIV");
      for (let f = 0; f < c.length; f++) {
        let u = r._getClassName(c[f]);
        const y = c[f].getAttribute("data-tab") || c[f].getAttribute("name") || "";
        u && (u = u.split(" ")[0]), this._els[u] || (this._els[u] = []), this._els[u].push(c[f]);
        let w = r.locale.labels[y + "_tab"] || r.locale.labels[y || u];
        typeof w != "string" && y && !c[f].innerHTML && (w = y.split("_")[0]), w && (this._waiAria.labelAttr(c[f], w), c[f].innerHTML = w);
      }
    };
    const v = r._createDomEventScope();
    function g(c, f) {
      const u = new Date(c), y = (new Date(f).getTime() - u.getTime()) / 864e5;
      return Math.abs(y);
    }
    r.unset_actions = function() {
      v.detachAll();
    }, r.set_actions = function() {
      for (const c in this._els)
        if (this._click[c])
          for (let f = 0; f < this._els[c].length; f++) {
            const u = this._els[c][f], y = this._click[c].bind(u);
            v.attach(u, "click", y);
          }
      v.attach(this._obj, "selectstart", function(c) {
        return c.preventDefault(), !1;
      }), v.attach(this._obj, "mousemove", function(c) {
        r._temp_touch_block || r._on_mouse_move(c);
      }), v.attach(this._obj, "mousedown", function(c) {
        r._ignore_next_click || r._on_mouse_down(c);
      }), v.attach(this._obj, "mouseup", function(c) {
        r._ignore_next_click || r._on_mouse_up(c);
      }), v.attach(this._obj, "dblclick", function(c) {
        r._on_dbl_click(c);
      }), v.attach(this._obj, "contextmenu", function(c) {
        return r.checkEvent("onContextMenu") && c.preventDefault(), r.callEvent("onContextMenu", [r._locate_event(c.target), c]);
      });
    }, r.select = function(c) {
      this._select_id != c && (r._close_not_saved(), this.editStop(!1), this._select_id && this.unselect(), this._select_id = c, this.updateEvent(c), this.callEvent("onEventSelected", [c]));
    }, r.unselect = function(c) {
      if (c && c != this._select_id)
        return;
      const f = this._select_id;
      this._select_id = null, f && this.getEvent(f) && this.updateEvent(f), this.callEvent("onEventUnselected", [f]);
    }, r.$stateProvider.registerProvider("global", (function() {
      return { mode: this._mode, date: new Date(this._date), min_date: new Date(this._min_date), max_date: new Date(this._max_date), editor_id: this._edit_id, lightbox_id: this._lightbox_id, new_event: this._new_event, select_id: this._select_id, expanded: this.expanded, drag_id: this._drag_id, drag_mode: this._drag_mode };
    }).bind(r)), r._click = { dhx_cal_data: function(c) {
      if (r._ignore_next_click)
        return c.preventDefault && c.preventDefault(), c.cancelBubble = !0, r._ignore_next_click = !1, !1;
      const f = r._locate_event(c.target);
      if (f) {
        if (!r.callEvent("onClick", [f, c]) || r.config.readonly)
          return;
      } else
        r.callEvent("onEmptyClick", [r.getActionData(c).date, c]);
      if (f && r.config.select) {
        r.select(f);
        const u = c.target.closest(".dhx_menu_icon"), y = r._getClassName(u);
        y.indexOf("_icon") != -1 && r._click.buttons[y.split(" ")[1].replace("icon_", "")](f);
      } else
        r._close_not_saved(), r.getState().select_id && (/* @__PURE__ */ new Date()).valueOf() - (r._new_event || 0) > 500 && r.unselect();
    }, dhx_cal_prev_button: function() {
      r._click.dhx_cal_next_button(0, -1);
    }, dhx_cal_next_button: function(c, f) {
      let u = 1;
      r.config.rtl && (f = -f, u = -u), r.setCurrentView(r.date.add(r.date[r._mode + "_start"](new Date(r._date)), f || u, r._mode));
    }, dhx_cal_today_button: function() {
      r.callEvent("onBeforeTodayDisplayed", []) && r.setCurrentView(r._currentDate());
    }, dhx_cal_tab: function() {
      const c = this.getAttribute("data-tab"), f = this.getAttribute("name"), u = c || f.substring(0, f.search("_tab"));
      r.setCurrentView(r._date, u);
    }, buttons: { delete: function(c) {
      const f = r.locale.labels.confirm_deleting;
      r._delete_event_confirm({ event: r.getEvent(c), message: f, title: r.locale.labels.title_confirm_deleting, callback: function() {
        r.deleteEvent(c);
      }, config: { ok: r.locale.labels.icon_delete } });
    }, edit: function(c) {
      r.edit(c);
    }, save: function(c) {
      r.editStop(!0);
    }, details: function(c) {
      r.showLightbox(c);
    }, form: function(c) {
      r.showLightbox(c);
    }, cancel: function(c) {
      r.editStop(!1);
    } } }, r._dhtmlx_confirm = function({ message: c, title: f, callback: u, config: y }) {
      if (!c)
        return u();
      y = y || {};
      const w = { ...y, text: c };
      f && (w.title = f), u && (w.callback = function(D) {
        D && u();
      }), r.confirm(w);
    }, r.addEventNow = function(c, f, u) {
      let y = {};
      r._isObject(c) && !r._isDate(c) && (y = c, c = null);
      const w = 6e4 * (this.config.event_duration || this.config.time_step);
      c || (c = y.start_date || Math.round(r._currentDate().valueOf() / w) * w);
      let D = new Date(c);
      if (!f) {
        let N = this.config.first_hour;
        N > D.getHours() && (D.setHours(N), c = D.valueOf()), f = c.valueOf() + w;
      }
      let M = new Date(f);
      D.valueOf() == M.valueOf() && M.setTime(M.valueOf() + w), y.start_date = y.start_date || D, y.end_date = y.end_date || M, y.text = y.text || this.locale.labels.new_event, y.id = this._drag_id = y.id || this.uid(), this._drag_mode = "new-size", this._loading = !0;
      const k = this.addEvent(y);
      return this.callEvent("onEventCreated", [this._drag_id, u]), this._loading = !1, this._drag_event = {}, this._on_mouse_up(u), k;
    }, r._on_dbl_click = function(c, f) {
      if (f = f || c.target, this.config.readonly)
        return;
      const u = r._getClassName(f).split(" ")[0];
      switch (u) {
        case "dhx_scale_bar":
          this.callEvent("onScaleDblClick");
          break;
        case "dhx_scale_holder":
        case "dhx_scale_holder_now":
        case "dhx_month_body":
        case "dhx_wa_day_data":
          if (!r.config.dblclick_create)
            break;
          this.addEventNow(this.getActionData(c).date, null, c);
          break;
        case "dhx_cal_event":
        case "dhx_wa_ev_body":
        case "dhx_agenda_line":
        case "dhx_cal_agenda_event_line":
        case "dhx_grid_event":
        case "dhx_cal_event_line":
        case "dhx_cal_event_clear": {
          const y = this._locate_event(f);
          if (!this.callEvent("onDblClick", [y, c]))
            return;
          this.config.details_on_dblclick || this._table_view || !this.getEvent(y)._timed || !this.config.select ? this.showLightbox(y) : this.edit(y);
          break;
        }
        case "dhx_time_block":
        case "dhx_cal_container":
          return;
        default: {
          const y = this["dblclick_" + u];
          if (y)
            y.call(this, c);
          else if (f.parentNode && f != this)
            return r._on_dbl_click(c, f.parentNode);
          break;
        }
      }
    }, r._get_column_index = function(c) {
      let f = 0;
      if (this._cols) {
        let u = 0, y = 0;
        for (; u + this._cols[y] < c && y < this._cols.length; )
          u += this._cols[y], y++;
        if (f = y + (this._cols[y] ? (c - u) / this._cols[y] : 0), this._ignores && f >= this._cols.length)
          for (; f >= 1 && this._ignores[Math.floor(f)]; )
            f--;
      }
      return f;
    }, r._week_indexes_from_pos = function(c) {
      if (this._cols) {
        const f = this._get_column_index(c.x);
        return c.x = Math.min(this._cols.length - 1, Math.max(0, Math.ceil(f) - 1)), c.y = Math.max(0, Math.ceil(60 * c.y / (this.config.time_step * this.config.hour_size_px)) - 1) + this.config.first_hour * (60 / this.config.time_step), c;
      }
      return c;
    }, r._mouse_coords = function(c) {
      let f;
      const u = document.body, y = document.documentElement;
      f = this.$env.isIE || !c.pageX && !c.pageY ? { x: c.clientX + (u.scrollLeft || y.scrollLeft || 0) - u.clientLeft, y: c.clientY + (u.scrollTop || y.scrollTop || 0) - u.clientTop } : { x: c.pageX, y: c.pageY }, this.config.rtl && this._colsS ? (f.x = this.$container.querySelector(".dhx_cal_data").offsetWidth - f.x, f.x += this.$domHelpers.getAbsoluteLeft(this._obj), this._mode !== "month" && (f.x -= this.xy.scale_width)) : f.x -= this.$domHelpers.getAbsoluteLeft(this._obj) + (this._table_view ? 0 : this.xy.scale_width);
      const w = this.$container.querySelector(".dhx_cal_data");
      f.y -= this.$domHelpers.getAbsoluteTop(w) - this._els.dhx_cal_data[0].scrollTop, f.ev = c;
      const D = this["mouse_" + this._mode];
      if (D)
        f = D.call(this, f);
      else if (this._table_view) {
        const M = this._get_column_index(f.x);
        if (!this._cols || !this._colsS)
          return f;
        let k = 0;
        for (k = 1; k < this._colsS.heights.length && !(this._colsS.heights[k] > f.y); k++)
          ;
        f.y = Math.ceil(24 * (Math.max(0, M) + 7 * Math.max(0, k - 1)) * 60 / this.config.time_step), (r._drag_mode || this._mode == "month") && (f.y = 24 * (Math.max(0, Math.ceil(M) - 1) + 7 * Math.max(0, k - 1)) * 60 / this.config.time_step), this._drag_mode == "move" && r._ignores_detected && r.config.preserve_length && (f._ignores = !0, this._drag_event._event_length || (this._drag_event._event_length = this._get_real_event_length(this._drag_event.start_date, this._drag_event.end_date, { x_step: 1, x_unit: "day" }))), f.x = 0;
      } else
        f = this._week_indexes_from_pos(f);
      return f.timestamp = +/* @__PURE__ */ new Date(), f;
    }, r._close_not_saved = function() {
      if ((/* @__PURE__ */ new Date()).valueOf() - (r._new_event || 0) > 500 && r._edit_id) {
        const c = r.locale.labels.confirm_closing;
        r._dhtmlx_confirm({ message: c, title: r.locale.labels.title_confirm_closing, callback: function() {
          r.editStop(r.config.positive_closing);
        } }), c && (this._drag_id = this._drag_pos = this._drag_mode = null);
      }
    }, r._correct_shift = function(c, f) {
      return c - 6e4 * (new Date(r._min_date).getTimezoneOffset() - new Date(c).getTimezoneOffset()) * (f ? -1 : 1);
    }, r._is_pos_changed = function(c, f) {
      function u(y, w, D) {
        return Math.abs(y - w) > D;
      }
      return !c || !this._drag_pos || !!(this._drag_pos.has_moved || !this._drag_pos.timestamp || f.timestamp - this._drag_pos.timestamp > 100 || u(c.ev.clientX, f.ev.clientX, 5) || u(c.ev.clientY, f.ev.clientY, 5));
    }, r._correct_drag_start_date = function(c) {
      let f;
      r.matrix && (f = r.matrix[r._mode]), f = f || { x_step: 1, x_unit: "day" }, c = new Date(c);
      let u = 1;
      return (f._start_correction || f._end_correction) && (u = 60 * (f.last_hour || 0) - (60 * c.getHours() + c.getMinutes()) || 1), 1 * c + (r._get_fictional_event_length(c, u, f) - u);
    }, r._correct_drag_end_date = function(c, f) {
      let u;
      r.matrix && (u = r.matrix[r._mode]), u = u || { x_step: 1, x_unit: "day" };
      const y = 1 * c + r._get_fictional_event_length(c, f, u);
      return new Date(1 * y - (r._get_fictional_event_length(y, -1, u, -1) + 1));
    }, r._on_mouse_move = function(c) {
      if (this._drag_mode) {
        var f = this._mouse_coords(c);
        if (this._is_pos_changed(this._drag_pos, f)) {
          var u, y;
          if (this._edit_id != this._drag_id && this._close_not_saved(), !this._drag_mode)
            return;
          var w = null;
          if (this._drag_pos && !this._drag_pos.has_moved && ((w = this._drag_pos).has_moved = !0), this._drag_pos = f, this._drag_pos.has_moved = !0, this._drag_mode == "create") {
            if (w && (f = w), this._close_not_saved(), this.unselect(this._select_id), this._loading = !0, u = this._get_date_from_pos(f).valueOf(), !this._drag_start)
              return this.callEvent("onBeforeEventCreated", [c, this._drag_id]) ? (this._loading = !1, void (this._drag_start = u)) : void (this._loading = !1);
            y = u, this._drag_start;
            var D = new Date(this._drag_start), M = new Date(y);
            this._mode != "day" && this._mode != "week" || D.getHours() != M.getHours() || D.getMinutes() != M.getMinutes() || (M = new Date(this._drag_start + 1e3)), this._drag_id = this.uid(), this.addEvent(D, M, this.locale.labels.new_event, this._drag_id, f.fields), this.callEvent("onEventCreated", [this._drag_id, c]), this._loading = !1, this._drag_mode = "new-size";
          }
          var k, N = this.config.time_step, m = this.getEvent(this._drag_id);
          if (r.matrix && (k = r.matrix[r._mode]), k = k || { x_step: 1, x_unit: "day" }, this._drag_mode == "move")
            u = this._min_date.valueOf() + 6e4 * (f.y * this.config.time_step + 24 * f.x * 60), !f.custom && this._table_view && (u += 1e3 * this.date.time_part(m.start_date)), !this._table_view && this._dragEventBody && this._drag_event._move_event_shift === void 0 && (this._drag_event._move_event_shift = u - m.start_date), this._drag_event._move_event_shift && (u -= this._drag_event._move_event_shift), u = this._correct_shift(u), f._ignores && this.config.preserve_length && this._table_view && k ? (u = r._correct_drag_start_date(u), y = r._correct_drag_end_date(u, this._drag_event._event_length)) : y = m.end_date.valueOf() - (m.start_date.valueOf() - u);
          else {
            if (u = m.start_date.valueOf(), y = m.end_date.valueOf(), this._table_view) {
              var x = this._min_date.valueOf() + f.y * this.config.time_step * 6e4 + (f.custom ? 0 : 864e5);
              if (this._mode == "month")
                if (x = this._correct_shift(x, !1), this._drag_from_start) {
                  var b = 864e5;
                  x <= r.date.date_part(new Date(y + b - 1)).valueOf() && (u = x - b);
                } else
                  y = x;
              else if (this.config.preserve_length) {
                if (f.resize_from_start)
                  u = r._correct_drag_start_date(x), k.round_position && k.first_hour && k.last_hour && k.x_unit == "day" && (u = new Date(1 * u + k._start_correction));
                else if (y = r._correct_drag_end_date(x, 0), k.round_position && k.first_hour && k.last_hour && k.x_unit == "day" && (y = r.date.date_part(new Date(y)), y = new Date(1 * y - k._end_correction)), k.round_position && r["ignore_" + r._mode] && k.x_unit == "day") {
                  const W = this["ignore_" + this._mode];
                  let pe = r.date.add(new Date(y), -k.x_step, k.x_unit);
                  W(pe) && (y = pe);
                }
              } else
                f.resize_from_start ? u = x : y = x;
            } else {
              var E = this.date.date_part(new Date(m.end_date.valueOf() - 1)).valueOf(), S = new Date(E), T = this.config.first_hour, C = 60 / N * (this.config.last_hour - T);
              this.config.time_step = 1;
              var A = this._mouse_coords(c);
              this.config.time_step = N;
              var $ = f.y * N * 6e4, H = Math.min(f.y + 1, C) * N * 6e4, O = 6e4 * A.y;
              y = Math.abs($ - O) > Math.abs(H - O) ? E + H : E + $, y += 6e4 * (new Date(y).getTimezoneOffset() - S.getTimezoneOffset()), this._els.dhx_cal_data[0].style.cursor = "s-resize", this._mode != "week" && this._mode != "day" || (y = this._correct_shift(y));
            }
            if (this._drag_mode == "new-size")
              if (y <= this._drag_start) {
                var P = f.shift || (this._table_view && !f.custom ? 864e5 : 0);
                u = y - (f.shift ? 0 : P), y = this._drag_start + (P || 6e4 * N);
              } else
                u = this._drag_start;
            else
              y <= u && (y = k && k.round_position ? k.x_unit == "hour" || k.x_unit == "minute" ? r.date.add(u, k.x_step, k.x_unit) : r.date.add(r.date.date_part(new Date(u)), 1, k.x_unit) : u + 6e4 * N);
          }
          var R = new Date(y - 1), j = new Date(u);
          if (this._drag_mode == "move" && r.config.limit_drag_out && (+j < +r._min_date || +y > +r._max_date)) {
            if (+m.start_date < +r._min_date || +m.end_date > +r._max_date)
              j = new Date(m.start_date), y = new Date(m.end_date);
            else {
              var I = y - j;
              +j < +r._min_date ? (j = new Date(r._min_date), f._ignores && this.config.preserve_length && this._table_view ? (j = new Date(r._correct_drag_start_date(j)), k._start_correction && (j = new Date(j.valueOf() + k._start_correction)), y = new Date(1 * j + this._get_fictional_event_length(j, this._drag_event._event_length, k))) : y = new Date(+j + I)) : (y = new Date(r._max_date), f._ignores && this.config.preserve_length && this._table_view ? (k._end_correction && (y = new Date(y.valueOf() - k._end_correction)), y = new Date(1 * y - this._get_fictional_event_length(y, 0, k, !0)), j = new Date(1 * y - this._get_fictional_event_length(y, this._drag_event._event_length, k, !0)), this._ignores_detected && (j = r.date.add(j, k.x_step, k.x_unit), y = new Date(1 * y - this._get_fictional_event_length(y, 0, k, !0)), y = r.date.add(y, k.x_step, k.x_unit))) : j = new Date(+y - I));
            }
            R = new Date(y - 1);
          }
          if (!this._table_view && this._dragEventBody && !r.config.all_timed && (!r._get_section_view() && f.x != this._get_event_sday({ start_date: new Date(u), end_date: new Date(u) }) || new Date(u).getHours() < this.config.first_hour) && (I = y - j, this._drag_mode == "move" && (b = this._min_date.valueOf() + 24 * f.x * 60 * 6e4, (j = new Date(b)).setHours(this.config.first_hour), +j <= +m.start_date ? y = new Date(+j + I) : j = new Date(+y - I))), this._table_view || r.config.all_timed || !(!r.getView() && f.x != this._get_event_sday({ start_date: new Date(y), end_date: new Date(y) }) || new Date(y).getHours() >= this.config.last_hour) || (I = y - j, b = this._min_date.valueOf() + 24 * f.x * 60 * 6e4, (y = r.date.date_part(new Date(b))).setHours(this.config.last_hour), R = new Date(y - 1), this._drag_mode == "move" && (+j <= +m.start_date ? y = new Date(+j + I) : j = new Date(+y - I))), !this._table_view && r.config.all_timed) {
            let W = this._min_date.valueOf() + 24 * f.x * 60 * 6e4;
            new Date(r._drag_start).getDay() != new Date(W) && (W = new Date(r._drag_start));
            let pe = new Date(W).setHours(this.config.last_hour);
            r._drag_start && this._drag_mode == "new-size" && pe < new Date(y) && ((y = r.date.date_part(new Date(W))).setHours(this.config.last_hour), R = new Date(y - 1));
          }
          if (this._table_view && r["ignore_" + this._mode] && (this._drag_mode == "resize" || this._drag_mode == "new-size") && +y > +r._max_date) {
            y = new Date(r._max_date);
            const W = this["ignore_" + this._mode];
            for (; W(y); )
              y = r.date.add(y, -k.x_step, k.x_unit);
            y = r.date.add(y, k.x_step, k.x_unit);
          }
          if (this._table_view || R.getDate() == j.getDate() && R.getHours() < this.config.last_hour || r._allow_dnd)
            if (m.start_date = j, m.end_date = new Date(y), this.config.update_render) {
              var U = r._els.dhx_cal_data[0].scrollTop;
              this.update_view(), r._els.dhx_cal_data[0].scrollTop = U;
            } else
              this.updateEvent(this._drag_id);
          this._table_view && this.for_rendered(this._drag_id, function(W) {
            W.className += " dhx_in_move dhx_cal_event_drag";
          }), this.callEvent("onEventDrag", [this._drag_id, this._drag_mode, c]);
        }
      } else if (r.checkEvent("onMouseMove")) {
        var B = this._locate_event(c.target || c.srcElement);
        this.callEvent("onMouseMove", [B, c]);
      }
    }, r._on_mouse_down = function(c, f) {
      if (c.button != 2 && !this.config.readonly && !this._drag_mode) {
        f = f || c.target || c.srcElement;
        var u = r._getClassName(f).split(" ")[0];
        switch (this.config.drag_event_body && u == "dhx_body" && f.parentNode && f.parentNode.className.indexOf("dhx_cal_select_menu") === -1 && (u = "dhx_event_move", this._dragEventBody = !0), u) {
          case "dhx_cal_event_line":
          case "dhx_cal_event_clear":
            this._table_view && (this._drag_mode = "move");
            break;
          case "dhx_event_move":
          case "dhx_wa_ev_body":
            this._drag_mode = "move";
            break;
          case "dhx_event_resize":
            this._drag_mode = "resize", r._getClassName(f).indexOf("dhx_event_resize_end") < 0 ? r._drag_from_start = !0 : r._drag_from_start = !1;
            break;
          case "dhx_scale_holder":
          case "dhx_scale_holder_now":
          case "dhx_month_body":
          case "dhx_matrix_cell":
          case "dhx_marked_timespan":
            this._drag_mode = "create";
            break;
          case "":
            if (f.parentNode)
              return r._on_mouse_down(c, f.parentNode);
            break;
          default:
            if ((!r.checkEvent("onMouseDown") || r.callEvent("onMouseDown", [u, c])) && f.parentNode && f != this && u != "dhx_body")
              return r._on_mouse_down(c, f.parentNode);
            this._drag_mode = null, this._drag_id = null;
        }
        if (this._drag_mode) {
          var y = this._locate_event(f);
          if (this.config["drag_" + this._drag_mode] && this.callEvent("onBeforeDrag", [y, this._drag_mode, c])) {
            if (this._drag_id = y, (this._edit_id != this._drag_id || this._edit_id && this._drag_mode == "create") && this._close_not_saved(), !this._drag_mode)
              return;
            this._drag_event = r._lame_clone(this.getEvent(this._drag_id) || {}), this._drag_pos = this._mouse_coords(c);
          } else
            this._drag_mode = this._drag_id = 0;
        }
        this._drag_start = null;
      }
    }, r._get_private_properties = function(c) {
      var f = {};
      for (var u in c)
        u.indexOf("_") === 0 && (f[u] = !0);
      return f;
    }, r._clear_temporary_properties = function(c, f) {
      var u = this._get_private_properties(c), y = this._get_private_properties(f);
      for (var w in y)
        u[w] || delete f[w];
    }, r._on_mouse_up = function(c) {
      if (!c || c.button != 2 || !this._mobile) {
        if (this._drag_mode && this._drag_id) {
          this._els.dhx_cal_data[0].style.cursor = "default";
          var f = this._drag_id, u = this._drag_mode, y = !this._drag_pos || this._drag_pos.has_moved;
          delete this._drag_event._move_event_shift;
          var w = this.getEvent(this._drag_id);
          if (y && (this._drag_event._dhx_changed || !this._drag_event.start_date || w.start_date.valueOf() != this._drag_event.start_date.valueOf() || w.end_date.valueOf() != this._drag_event.end_date.valueOf())) {
            var D = this._drag_mode == "new-size";
            if (this.callEvent("onBeforeEventChanged", [w, c, D, this._drag_event]))
              if (this._drag_id = this._drag_mode = null, D && this.config.edit_on_create) {
                if (this.unselect(), this._new_event = /* @__PURE__ */ new Date(), w.$new = !0, this._table_view || this.config.details_on_create || !this.config.select || !this.isOneDayEvent(this.getEvent(f)))
                  return r.callEvent("onDragEnd", [f, u, c]), this.showLightbox(f);
                this._drag_pos = !0, this._select_id = this._edit_id = f;
              } else
                this._new_event || this.callEvent(D ? "onEventAdded" : "onEventChanged", [f, this.getEvent(f)]);
            else
              D ? this.deleteEvent(w.id, !0) : (this._drag_event._dhx_changed = !1, this._clear_temporary_properties(w, this._drag_event), r._lame_copy(w, this._drag_event), this.updateEvent(w.id));
          }
          this._drag_pos && (this._drag_pos.has_moved || this._drag_pos === !0) && (this._drag_id = this._drag_mode = null, this.render_view_data()), r.callEvent("onDragEnd", [f, u, c]);
        }
        this._drag_id = null, this._drag_mode = null, this._drag_pos = null, this._drag_event = null, this._drag_from_start = null;
      }
    }, r._trigger_dyn_loading = function() {
      return !(!this._load_mode || !this._load() || (this._render_wait = !0, 0));
    }, r.update_view = function() {
      this._reset_ignores(), this._update_nav_bar(this.config.header, this.$container.querySelector(".dhx_cal_navline"));
      var c = this[this._mode + "_view"];
      if (c ? c.call(this, !0) : this._reset_scale(), this._trigger_dyn_loading())
        return !0;
      this.render_view_data();
    }, r.isViewExists = function(c) {
      return !!(r[c + "_view"] || r.date[c + "_start"] && r.templates[c + "_date"] && r.templates[c + "_scale_date"]);
    }, r._set_aria_buttons_attrs = function() {
      for (var c = ["dhx_cal_next_button", "dhx_cal_prev_button", "dhx_cal_tab", "dhx_cal_today_button"], f = 0; f < c.length; f++)
        for (var u = this._els[c[f]], y = 0; u && y < u.length; y++) {
          var w = u[y].getAttribute("data-tab") || u[y].getAttribute("name"), D = this.locale.labels[c[f]];
          w && (D = this.locale.labels[w + "_tab"] || this.locale.labels[w] || D), c[f] == "dhx_cal_next_button" ? D = this.locale.labels.next : c[f] == "dhx_cal_prev_button" && (D = this.locale.labels.prev), this._waiAria.headerButtonsAttributes(u[y], D || "");
        }
    }, r.updateView = function(c, f) {
      if (!this.$container)
        throw new Error(`The scheduler is not initialized. 
 **scheduler.updateView** or **scheduler.setCurrentView** can be called only after **scheduler.init**`);
      c = c || this._date, f = f || this._mode;
      var u = "dhx_cal_data";
      this.locale.labels.icon_form || (this.locale.labels.icon_form = this.locale.labels.icon_edit);
      var y = this._obj, w = "dhx_scheduler_" + this._mode, D = "dhx_scheduler_" + f;
      y.classList.remove(w), y.classList.add(D);
      var M, k = "dhx_multi_day", N = !(this._mode != f || !this.config.preserve_scroll) && this._els[u][0].scrollTop;
      this._els[k] && this._els[k][0] && (M = this._els[k][0].scrollTop), this[this._mode + "_view"] && f && this._mode != f && this[this._mode + "_view"](!1), this._close_not_saved(), this._els[k] && (this._els[k][0].parentNode.removeChild(this._els[k][0]), this._els[k] = null), this._mode = f, this._date = c, this._table_view = this._mode == "month", this._dy_shift = 0, this.update_view(), this._set_aria_buttons_attrs();
      var m = this._els.dhx_cal_tab;
      if (m)
        for (var x = 0; x < m.length; x++) {
          var b = m[x];
          b.getAttribute("data-tab") == this._mode || b.getAttribute("name") == this._mode + "_tab" ? (b.classList.add("active"), this._waiAria.headerToggleState(b, !0)) : (b.classList.remove("active"), this._waiAria.headerToggleState(b, !1));
        }
      typeof N == "number" && (this._els[u][0].scrollTop = N), typeof M == "number" && this._els[k] && this._els[k][0] && (this._els[k][0].scrollTop = M);
    }, r.setCurrentView = function(c, f) {
      this.callEvent("onBeforeViewChange", [this._mode, this._date, f || this._mode, c || this._date]) && (this.updateView(c, f), this.callEvent("onViewChange", [this._mode, this._date]));
    }, r.render = function(c, f) {
      r.setCurrentView(c, f);
    }, r._render_x_header = function(c, f, u, y, w) {
      w = w || 0;
      var D = document.createElement("div");
      D.className = "dhx_scale_bar", this.templates[this._mode + "_scalex_class"] && (D.className += " " + this.templates[this._mode + "_scalex_class"](u));
      var M = this._cols[c];
      this._mode == "month" && c === 0 && this.config.left_border && (D.className += " dhx_scale_bar_border", f += 1), this.set_xy(D, M, this.xy.scale_height - 1, f, w);
      var k = this.templates[this._mode + "_scale_date"](u, this._mode);
      D.innerHTML = k, this._waiAria.dayHeaderAttr(D, k), y.appendChild(D);
    }, r._get_columns_num = function(c, f) {
      var u = 7;
      if (!r._table_view) {
        var y = r.date["get_" + r._mode + "_end"];
        y && (f = y(c)), u = Math.round((f.valueOf() - c.valueOf()) / 864e5);
      }
      return u;
    }, r._get_timeunit_start = function() {
      return this.date[this._mode + "_start"](new Date(this._date.valueOf()));
    }, r._get_view_end = function() {
      var c = this._get_timeunit_start(), f = r.date.add(c, 1, this._mode);
      if (!r._table_view) {
        var u = r.date["get_" + r._mode + "_end"];
        u && (f = u(c));
      }
      return f;
    }, r._calc_scale_sizes = function(c, f, u) {
      var y = this.config.rtl, w = c, D = this._get_columns_num(f, u);
      this._process_ignores(f, D, "day", 1);
      for (var M = D - this._ignores_detected, k = 0; k < D; k++)
        this._ignores[k] ? (this._cols[k] = 0, M++) : this._cols[k] = Math.floor(w / (M - k)), w -= this._cols[k], this._colsS[k] = (this._cols[k - 1] || 0) + (this._colsS[k - 1] || (this._table_view ? 0 : y ? this.xy.scroll_width : this.xy.scale_width));
      this._colsS.col_length = D, this._colsS[D] = this._cols[D - 1] + this._colsS[D - 1] || 0;
    }, r._set_scale_col_size = function(c, f, u) {
      var y = this.config;
      this.set_xy(c, f, y.hour_size_px * (y.last_hour - y.first_hour), u + this.xy.scale_width + 1, 0);
    }, r._render_scales = function(c, f) {
      var u = new Date(r._min_date), y = new Date(r._max_date), w = this.date.date_part(r._currentDate()), D = parseInt(c.style.width, 10) - 1, M = new Date(this._min_date), k = this._get_columns_num(u, y);
      this._calc_scale_sizes(D, u, y);
      var N = 0;
      c.innerHTML = "";
      for (var m = 0; m < k; m++) {
        if (this._ignores[m] || this._render_x_header(m, N, M, c), !this._table_view) {
          var x = document.createElement("div"), b = "dhx_scale_holder";
          M.valueOf() == w.valueOf() && (b += " dhx_scale_holder_now"), x.setAttribute("data-column-index", m), this._ignores_detected && this._ignores[m] && (b += " dhx_scale_ignore");
          for (let E = 1 * this.config.first_hour; E < this.config.last_hour; E++) {
            const S = document.createElement("div");
            S.className = "dhx_scale_time_slot dhx_scale_time_slot_hour_start", S.style.height = this.config.hour_size_px / 2 + "px";
            let T = new Date(M.getFullYear(), M.getMonth(), M.getDate(), E, 0);
            S.setAttribute("data-slot-date", this.templates.format_date(T));
            let C = this.templates.time_slot_text(T);
            C && (S.innerHTML = C);
            let A = this.templates.time_slot_class(T);
            A && S.classList.add(A), x.appendChild(S);
            const $ = document.createElement("div");
            $.className = "dhx_scale_time_slot", T = new Date(M.getFullYear(), M.getMonth(), M.getDate(), E, 30), $.setAttribute("data-slot-date", this.templates.format_date(T)), $.style.height = this.config.hour_size_px / 2 + "px", C = this.templates.time_slot_text(T), C && ($.innerHTML = C), A = this.templates.time_slot_class(T), A && $.classList.add(A), x.appendChild($);
          }
          x.className = b + " " + this.templates.week_date_class(M, w), this._waiAria.dayColumnAttr(x, M), this._set_scale_col_size(x, this._cols[m], N), f.appendChild(x), this.callEvent("onScaleAdd", [x, M]);
        }
        N += this._cols[m], M = this.date.add(M, 1, "day"), M = this.date.day_start(M);
      }
    }, r._getNavDateElement = function() {
      return this.$container.querySelector(".dhx_cal_date");
    }, r._reset_scale = function() {
      if (this.templates[this._mode + "_date"]) {
        var c = this._els.dhx_cal_header[0], f = this._els.dhx_cal_data[0], u = this.config;
        c.innerHTML = "", f.innerHTML = "";
        var y, w, D = (u.readonly || !u.drag_resize ? " dhx_resize_denied" : "") + (u.readonly || !u.drag_move ? " dhx_move_denied" : "");
        f.className = "dhx_cal_data" + D, this._scales = {}, this._cols = [], this._colsS = { height: 0 }, this._dy_shift = 0, this.set_sizes();
        var M = this._get_timeunit_start(), k = r._get_view_end();
        y = w = this._table_view ? r.date.week_start(M) : M, this._min_date = y;
        var N = this.templates[this._mode + "_date"](M, k, this._mode), m = this._getNavDateElement();
        if (m && (m.innerHTML = N, this._waiAria.navBarDateAttr(m, N)), this._max_date = k, r._render_scales(c, f), this._table_view)
          this._reset_month_scale(f, M, w);
        else if (this._reset_hours_scale(f, M, w), u.multi_day) {
          var x = "dhx_multi_day";
          this._els[x] && (this._els[x][0].parentNode.removeChild(this._els[x][0]), this._els[x] = null);
          var b = document.createElement("div");
          b.className = x, b.style.visibility = "hidden", b.style.display = "none";
          var E = this._colsS[this._colsS.col_length], S = u.rtl ? this.xy.scale_width : this.xy.scroll_width, T = Math.max(E + S, 0);
          this.set_xy(b, T, 0, 0), f.parentNode.insertBefore(b, f);
          var C = b.cloneNode(!0);
          C.className = x + "_icon", C.style.visibility = "hidden", C.style.display = "none", this.set_xy(C, this.xy.scale_width + 1, 0, 0), b.appendChild(C), this._els[x] = [b, C], r.event(this._els[x][0], "click", this._click.dhx_cal_data);
        }
      }
    }, r._reset_hours_scale = function(c, f, u) {
      var y = document.createElement("div");
      y.className = "dhx_scale_holder";
      for (var w = new Date(1980, 1, 1, this.config.first_hour, 0, 0), D = 1 * this.config.first_hour; D < this.config.last_hour; D++) {
        var M = document.createElement("div");
        M.className = "dhx_scale_hour", M.style.height = this.config.hour_size_px + "px";
        var k = this.xy.scale_width;
        this.config.left_border && (M.className += " dhx_scale_hour_border"), M.style.width = k + "px";
        var N = r.templates.hour_scale(w);
        M.innerHTML = N, this._waiAria.hourScaleAttr(M, N), y.appendChild(M), w = this.date.add(w, 1, "hour");
      }
      c.appendChild(y), this.config.scroll_hour && (c.scrollTop = this.config.hour_size_px * (this.config.scroll_hour - this.config.first_hour));
    }, r._currentDate = function() {
      return r.config.now_date ? new Date(r.config.now_date) : /* @__PURE__ */ new Date();
    }, r._reset_ignores = function() {
      this._ignores = {}, this._ignores_detected = 0;
    }, r._process_ignores = function(c, f, u, y, w) {
      this._reset_ignores();
      var D = r["ignore_" + this._mode];
      if (D)
        for (var M = new Date(c), k = 0; k < f; k++)
          D(M) && (this._ignores_detected += 1, this._ignores[k] = !0, w && f++), M = r.date.add(M, y, u), r.date[u + "_start"] && (M = r.date[u + "_start"](M));
    }, r._render_month_scale = function(c, f, u, y) {
      var w = r.date.add(f, 1, "month"), D = new Date(u), M = r._currentDate();
      M = this.date.date_part(M), u = this.date.date_part(u), y = y || Math.ceil(Math.round((w.valueOf() - u.valueOf()) / 864e5) / 7);
      for (var k = [], N = 0; N <= 7; N++) {
        var m = this._cols[N] || 0;
        isNaN(Number(m)) || (m += "px"), k[N] = m;
      }
      function x(j) {
        var I = r._colsS.height;
        return r._colsS.heights[j + 1] !== void 0 && (I = r._colsS.heights[j + 1] - (r._colsS.heights[j] || 0)), I;
      }
      var b = 0;
      const E = document.createElement("div");
      for (E.classList.add("dhx_cal_month_table"), N = 0; N < y; N++) {
        var S = document.createElement("div");
        S.classList.add("dhx_cal_month_row"), S.style.height = x(N) + "px", E.appendChild(S);
        for (var T = 0; T < 7; T++) {
          var C = document.createElement("div");
          S.appendChild(C);
          var A = "dhx_cal_month_cell";
          u < f ? A += " dhx_before" : u >= w ? A += " dhx_after" : u.valueOf() == M.valueOf() && (A += " dhx_now"), this._ignores_detected && this._ignores[T] && (A += " dhx_scale_ignore"), C.className = A + " " + this.templates.month_date_class(u, M), C.setAttribute("data-cell-date", r.templates.format_date(u));
          var $ = "dhx_month_body", H = "dhx_month_head";
          if (T === 0 && this.config.left_border && ($ += " dhx_month_body_border", H += " dhx_month_head_border"), this._ignores_detected && this._ignores[T])
            C.appendChild(document.createElement("div")), C.appendChild(document.createElement("div"));
          else {
            C.style.width = k[T], this._waiAria.monthCellAttr(C, u);
            var O = document.createElement("div");
            O.style.height = r.xy.month_head_height + "px", O.className = H, O.innerHTML = this.templates.month_day(u), C.appendChild(O);
            var P = document.createElement("div");
            P.className = $, C.appendChild(P);
          }
          var R = u.getDate();
          (u = this.date.add(u, 1, "day")).getDate() - R > 1 && (u = new Date(u.getFullYear(), u.getMonth(), R + 1, 12, 0));
        }
        r._colsS.heights[N] = b, b += x(N);
      }
      return this._min_date = D, this._max_date = u, c.innerHTML = "", c.appendChild(E), this._scales = {}, c.querySelectorAll("[data-cell-date]").forEach((j) => {
        const I = r.templates.parse_date(j.getAttribute("data-cell-date")), U = j.querySelector(".dhx_month_body");
        this._scales[+I] = U, this.callEvent("onScaleAdd", [this._scales[+I], I]);
      }), this._max_date;
    }, r._reset_month_scale = function(c, f, u, y) {
      var w = r.date.add(f, 1, "month");
      u = this.date.date_part(u), y = y || Math.ceil(Math.round((w.valueOf() - u.valueOf()) / 864e5) / 7);
      var D = Math.floor(c.clientHeight / y) - this.xy.month_head_height;
      return this._colsS.height = D + this.xy.month_head_height, this._colsS.heights = [], r._render_month_scale(c, f, u, y);
    }, r.getView = function(c) {
      return c || (c = r.getState().mode), r.matrix && r.matrix[c] ? r.matrix[c] : r._props && r._props[c] ? r._props[c] : null;
    }, r.getLabel = function(c, f) {
      for (var u = this.config.lightbox.sections, y = 0; y < u.length; y++)
        if (u[y].map_to == c) {
          for (var w = u[y].options, D = 0; D < w.length; D++)
            if (w[D].key == f)
              return w[D].label;
        }
      return "";
    }, r.updateCollection = function(c, f) {
      var u = r.serverList(c);
      return !!u && (u.splice(0, u.length), u.push.apply(u, f || []), r.callEvent("onOptionsLoad", []), r.resetLightbox(), r.hideCover(), !0);
    }, r._lame_clone = function(c, f) {
      var u, y, w;
      for (f = f || [], u = 0; u < f.length; u += 2)
        if (c === f[u])
          return f[u + 1];
      if (c && typeof c == "object") {
        for (w = Object.create(c), y = [Array, Date, Number, String, Boolean], u = 0; u < y.length; u++)
          c instanceof y[u] && (w = u ? new y[u](c) : new y[u]());
        for (u in f.push(c, w), c)
          Object.prototype.hasOwnProperty.apply(c, [u]) && (w[u] = r._lame_clone(c[u], f));
      }
      return w || c;
    }, r._lame_copy = function(c, f) {
      for (var u in f)
        f.hasOwnProperty(u) && (c[u] = f[u]);
      return c;
    }, r._get_date_from_pos = function(c) {
      var f = this._min_date.valueOf() + 6e4 * (c.y * this.config.time_step + 24 * (this._table_view ? 0 : c.x) * 60);
      return new Date(this._correct_shift(f));
    }, r.getActionData = function(c) {
      var f = this._mouse_coords(c);
      return { date: this._get_date_from_pos(f), section: f.section };
    }, r._focus = function(c, f) {
      if (c && c.focus)
        if (this._mobile)
          window.setTimeout(function() {
            c.focus();
          }, 10);
        else
          try {
            f && c.select && c.offsetWidth && c.select(), c.focus();
          } catch {
          }
    }, r._get_real_event_length = function(c, f, u) {
      var y, w = f - c, D = this["ignore_" + this._mode], M = 0;
      u.render ? (M = this._get_date_index(u, c), y = this._get_date_index(u, f), c.valueOf() < r.getState().min_date.valueOf() && (M = -g(c, r.getState().min_date)), f.valueOf() > r.getState().max_date.valueOf() && (y += g(f, r.getState().max_date))) : y = Math.round(w / 60 / 60 / 1e3 / 24);
      for (var k = !0; M < y; ) {
        var N = r.date.add(f, -u.x_step, u.x_unit);
        if (D && D(f) && (!k || k && D(N)))
          w -= f - N;
        else {
          let m = 0;
          const x = new Date(Math.max(N.valueOf(), c.valueOf())), b = f, E = new Date(x.getFullYear(), x.getMonth(), x.getDate(), u.first_hour || 0), S = new Date(x.getFullYear(), x.getMonth(), x.getDate(), u.last_hour || 24), T = new Date(f.getFullYear(), f.getMonth(), f.getDate(), u.first_hour || 0), C = new Date(f.getFullYear(), f.getMonth(), f.getDate(), u.last_hour || 24);
          b.valueOf() > C.valueOf() && (m += b - C), b.valueOf() > T.valueOf() ? m += u._start_correction : m += 60 * b.getHours() * 60 * 1e3 + 60 * b.getMinutes() * 1e3, x.valueOf() <= S.valueOf() && (m += u._end_correction), x.valueOf() < E.valueOf() && (m += E.valueOf() - x.valueOf()), w -= m, k = !1;
        }
        f = N, y--;
      }
      return w;
    }, r._get_fictional_event_length = function(c, f, u, y) {
      var w = new Date(c), D = y ? -1 : 1;
      if (u._start_correction || u._end_correction) {
        var M;
        M = y ? 60 * w.getHours() + w.getMinutes() - 60 * (u.first_hour || 0) : 60 * (u.last_hour || 0) - (60 * w.getHours() + w.getMinutes());
        var k = 60 * (u.last_hour - u.first_hour), N = Math.ceil((f / 6e4 - M) / k);
        N < 0 && (N = 0), f += N * (1440 - k) * 60 * 1e3;
      }
      var m, x = new Date(1 * c + f * D), b = this["ignore_" + this._mode], E = 0;
      function S() {
        return u.x_unit === "day" ? E * D < m * D : E * D <= m * D;
      }
      for (u.render ? (E = this._get_date_index(u, w), m = this._get_date_index(u, x)) : m = Math.round(f / 60 / 60 / 1e3 / 24); S(); ) {
        var T = r.date.add(w, u.x_step * D, u.x_unit);
        b && b(w) && (f += (T - w) * D, m += D), w = T, E += D;
      }
      return f;
    }, r._get_section_view = function() {
      return this.getView();
    }, r._get_section_property = function() {
      return this.matrix && this.matrix[this._mode] ? this.matrix[this._mode].y_property : this._props && this._props[this._mode] ? this._props[this._mode].map_to : null;
    }, r._is_initialized = function() {
      var c = this.getState();
      return this._obj && c.date && c.mode;
    }, r._is_lightbox_open = function() {
      var c = this.getState();
      return c.lightbox_id !== null && c.lightbox_id !== void 0;
    };
  }(i), function(r) {
    (function() {
      var l = new RegExp(`<(?:.|
)*?>`, "gm"), _ = new RegExp(" +", "gm");
      function h(c) {
        return (c + "").replace(l, " ").replace(_, " ");
      }
      var p = new RegExp("'", "gm");
      function v(c) {
        return (c + "").replace(p, "&#39;");
      }
      for (var g in r._waiAria = { getAttributeString: function(c) {
        var f = [" "];
        for (var u in c)
          if (typeof c[u] != "function" && typeof c[u] != "object") {
            var y = v(h(c[u]));
            f.push(u + "='" + y + "'");
          }
        return f.push(" "), f.join(" ");
      }, setAttributes: function(c, f) {
        for (var u in f)
          c.setAttribute(u, h(f[u]));
        return c;
      }, labelAttr: function(c, f) {
        return this.setAttributes(c, { "aria-label": f });
      }, label: function(c) {
        return r._waiAria.getAttributeString({ "aria-label": c });
      }, hourScaleAttr: function(c, f) {
        this.labelAttr(c, f);
      }, monthCellAttr: function(c, f) {
        this.labelAttr(c, r.templates.day_date(f));
      }, navBarDateAttr: function(c, f) {
        this.labelAttr(c, f);
      }, dayHeaderAttr: function(c, f) {
        this.labelAttr(c, f);
      }, dayColumnAttr: function(c, f) {
        this.dayHeaderAttr(c, r.templates.day_date(f));
      }, headerButtonsAttributes: function(c, f) {
        return this.setAttributes(c, { role: "button", "aria-label": f });
      }, headerToggleState: function(c, f) {
        return this.setAttributes(c, { "aria-pressed": f ? "true" : "false" });
      }, getHeaderCellAttr: function(c) {
        return r._waiAria.getAttributeString({ "aria-label": c });
      }, eventAttr: function(c, f) {
        this._eventCommonAttr(c, f);
      }, _eventCommonAttr: function(c, f) {
        f.setAttribute("aria-label", h(r.templates.event_text(c.start_date, c.end_date, c))), r.config.readonly && f.setAttribute("aria-readonly", !0), c.$dataprocessor_class && f.setAttribute("aria-busy", !0), f.setAttribute("aria-selected", r.getState().select_id == c.id ? "true" : "false");
      }, setEventBarAttr: function(c, f) {
        this._eventCommonAttr(c, f);
      }, _getAttributes: function(c, f) {
        var u = { setAttribute: function(y, w) {
          this[y] = w;
        } };
        return c.apply(this, [f, u]), u;
      }, eventBarAttrString: function(c) {
        return this.getAttributeString(this._getAttributes(this.setEventBarAttr, c));
      }, agendaHeadAttrString: function() {
        return this.getAttributeString({ role: "row" });
      }, agendaHeadDateString: function(c) {
        return this.getAttributeString({ role: "columnheader", "aria-label": c });
      }, agendaHeadDescriptionString: function(c) {
        return this.agendaHeadDateString(c);
      }, agendaDataAttrString: function() {
        return this.getAttributeString({ role: "grid" });
      }, agendaEventAttrString: function(c) {
        var f = this._getAttributes(this._eventCommonAttr, c);
        return f.role = "row", this.getAttributeString(f);
      }, agendaDetailsBtnString: function() {
        return this.getAttributeString({ role: "button", "aria-label": r.locale.labels.icon_details });
      }, gridAttrString: function() {
        return this.getAttributeString({ role: "grid" });
      }, gridRowAttrString: function(c) {
        return this.agendaEventAttrString(c);
      }, gridCellAttrString: function(c, f, u) {
        return this.getAttributeString({ role: "gridcell", "aria-label": [f.label === void 0 ? f.id : f.label, ": ", u] });
      }, mapAttrString: function() {
        return this.gridAttrString();
      }, mapRowAttrString: function(c) {
        return this.gridRowAttrString(c);
      }, mapDetailsBtnString: function() {
        return this.agendaDetailsBtnString();
      }, minicalHeader: function(c, f) {
        this.setAttributes(c, { id: f + "", "aria-live": "assertice", "aria-atomic": "true" });
      }, minicalGrid: function(c, f) {
        this.setAttributes(c, { "aria-labelledby": f + "", role: "grid" });
      }, minicalRow: function(c) {
        this.setAttributes(c, { role: "row" });
      }, minicalDayCell: function(c, f) {
        var u = f.valueOf() < r._max_date.valueOf() && f.valueOf() >= r._min_date.valueOf();
        this.setAttributes(c, { role: "gridcell", "aria-label": r.templates.day_date(f), "aria-selected": u ? "true" : "false" });
      }, minicalHeadCell: function(c) {
        this.setAttributes(c, { role: "columnheader" });
      }, weekAgendaDayCell: function(c, f) {
        var u = c.querySelector(".dhx_wa_scale_bar"), y = c.querySelector(".dhx_wa_day_data"), w = r.uid() + "";
        this.setAttributes(u, { id: w }), this.setAttributes(y, { "aria-labelledby": w });
      }, weekAgendaEvent: function(c, f) {
        this.eventAttr(f, c);
      }, lightboxHiddenAttr: function(c) {
        c.setAttribute("aria-hidden", "true");
      }, lightboxVisibleAttr: function(c) {
        c.setAttribute("aria-hidden", "false");
      }, lightboxSectionButtonAttrString: function(c) {
        return this.getAttributeString({ role: "button", "aria-label": c, tabindex: "0" });
      }, yearHeader: function(c, f) {
        this.setAttributes(c, { id: f + "" });
      }, yearGrid: function(c, f) {
        this.minicalGrid(c, f);
      }, yearHeadCell: function(c) {
        return this.minicalHeadCell(c);
      }, yearRow: function(c) {
        return this.minicalRow(c);
      }, yearDayCell: function(c) {
        this.setAttributes(c, { role: "gridcell" });
      }, lightboxAttr: function(c) {
        c.setAttribute("role", "dialog"), c.setAttribute("aria-hidden", "true"), c.firstChild.setAttribute("role", "heading");
      }, lightboxButtonAttrString: function(c) {
        return this.getAttributeString({ role: "button", "aria-label": r.locale.labels[c], tabindex: "0" });
      }, eventMenuAttrString: function(c) {
        return this.getAttributeString({ role: "button", "aria-label": r.locale.labels[c] });
      }, lightboxHeader: function(c, f) {
        c.setAttribute("aria-label", f);
      }, lightboxSelectAttrString: function(c) {
        var f = "";
        switch (c) {
          case "%Y":
            f = r.locale.labels.year;
            break;
          case "%m":
            f = r.locale.labels.month;
            break;
          case "%d":
            f = r.locale.labels.day;
            break;
          case "%H:%i":
            f = r.locale.labels.hour + " " + r.locale.labels.minute;
        }
        return r._waiAria.getAttributeString({ "aria-label": f });
      }, messageButtonAttrString: function(c) {
        return "tabindex='0' role='button' aria-label='" + c + "'";
      }, messageInfoAttr: function(c) {
        c.setAttribute("role", "alert");
      }, messageModalAttr: function(c, f) {
        c.setAttribute("role", "dialog"), f && c.setAttribute("aria-labelledby", f);
      }, quickInfoAttr: function(c) {
        c.setAttribute("role", "dialog");
      }, quickInfoHeaderAttrString: function() {
        return " role='heading' ";
      }, quickInfoHeader: function(c, f) {
        c.setAttribute("aria-label", f);
      }, quickInfoButtonAttrString: function(c) {
        return r._waiAria.getAttributeString({ role: "button", "aria-label": c, tabindex: "0" });
      }, tooltipAttr: function(c) {
        c.setAttribute("role", "tooltip");
      }, tooltipVisibleAttr: function(c) {
        c.setAttribute("aria-hidden", "false");
      }, tooltipHiddenAttr: function(c) {
        c.setAttribute("aria-hidden", "true");
      } }, r._waiAria)
        r._waiAria[g] = function(c) {
          return function() {
            return r.config.wai_aria_attributes ? c.apply(this, arguments) : " ";
          };
        }(r._waiAria[g]);
    })();
  }(i), i.utils = ne, i.$domHelpers = he, i.utils.dom = he, i.uid = ne.uid, i.mixin = ne.mixin, i.defined = ne.defined, i.assert = function(r) {
    return function(l, _) {
      l || r.config.show_errors && r.callEvent("onError", [_]) !== !1 && (r.message ? r.message({ type: "error", text: _, expire: -1 }) : console.log(_));
    };
  }(i), i.copy = ne.copy, i._createDatePicker = function(r, l) {
    return new ia(i, r, l);
  }, i._getFocusableNodes = he.getFocusableNodes, i._getClassName = he.getClassName, i._locate_css = he.locateCss;
  const t = aa(i);
  var n, s, a;
  i.utils.mixin(i, t), i.env = i.$env = Jt, i.Promise = Promise, function(r) {
    r.destructor = function() {
      for (var l in r.callEvent("onDestroy", []), this.clearAll(), this.$container && (this.$container.innerHTML = "", this.$container.classList.remove(`dhx_scheduler_${this._mode}`)), this._eventRemoveAll && this._eventRemoveAll(), this.resetLightbox && this.resetLightbox(), this._dp && this._dp.destructor && this._dp.destructor(), this.detachAllEvents(), this)
        l.indexOf("$") === 0 && delete this[l];
      r.$destroyed = !0;
    };
  }(i), function(r) {
    r.Promise = typeof window < "u" ? window.Promise : Promise;
    const l = { cache: !0, method: "get", serializeRequestParams: vt, parse(_) {
      if (typeof _ != "string")
        return _;
      let h;
      const p = _.replace(/^[\s]+/, "");
      return typeof DOMParser > "u" || r.$env.isIE ? typeof window < "u" && window.ActiveXObject !== void 0 && (h = new window.ActiveXObject("Microsoft.XMLDOM"), h.async = "false", h.loadXML(p)) : h = new DOMParser().parseFromString(p, "text/xml"), h || p;
    }, xmltop(_, h, p) {
      if (h.status === void 0 || h.status < 400) {
        const v = h.responseXML ? h.responseXML : this.parse(h.responseText || h);
        if (typeof v != "string" && v.documentElement !== null && !v.getElementsByTagName("parsererror").length)
          return v.getElementsByTagName(_)[0];
      }
      return p !== -1 && r.callEvent("onLoadXMLError", ["Incorrect XML", h, p]), document.createElement("DIV");
    }, xpath(_, h) {
      var c;
      const p = "nodeName" in h ? h : h.responseXML || h;
      if (r.$env.isIE)
        return ((c = p.selectNodes) == null ? void 0 : c.call(p, _)) || [];
      const v = [], g = (p.ownerDocument || p).evaluate(_, p, null, XPathResult.ANY_TYPE, null);
      for (; ; ) {
        const f = g.iterateNext();
        if (!f)
          break;
        v.push(f);
      }
      return v;
    }, query(_) {
      return this._call(_.method || "GET", _.url, String(_.data || ""), _.async ?? !0, _.callback, _.headers);
    }, get(_, h, p) {
      const v = ve("GET", arguments);
      return this.query(v);
    }, getSync(_, h) {
      const p = ve("GET", arguments);
      return p.async = !1, this.query(p);
    }, put(_, h, p, v) {
      const g = ve("PUT", arguments);
      return this.query(g);
    }, del(_, h, p) {
      const v = ve("DELETE", arguments);
      return this.query(v);
    }, post(_, h, p, v) {
      let g = h, c = p;
      arguments.length === 1 ? g = "" : arguments.length === 2 && typeof g == "function" && (c = g, g = "");
      const f = ve("POST", [_, g, c, v]);
      return this.query(f);
    }, postSync(_, h, p) {
      const v = ve("POST", [_, h === null ? "" : String(h), p]);
      return v.async = !1, this.query(v);
    }, _call(_, h, p, v, g, c) {
      return new r.Promise((f) => {
        let u = typeof XMLHttpRequest > "u" || r.$env.isIE ? new window.ActiveXObject("Microsoft.XMLHTTP") : new XMLHttpRequest();
        const y = typeof navigator < "u" ? navigator.userAgent : "", w = y.match(/AppleWebKit/) !== null && y.match(/Qt/) !== null && y.match(/Safari/) !== null;
        v && u.addEventListener("readystatechange", () => {
          if (u.readyState === 4 || w && u.readyState === 3) {
            if ((u.status !== 200 || u.responseText === "") && !r.callEvent("onAjaxError", [u]))
              return;
            setTimeout(() => {
              typeof g == "function" && g.apply(window, [{ xmlDoc: u, filePath: h }]), f(u);
            }, 0);
          }
        });
        let D = h;
        if (_ !== "GET" || this.cache || (D += `${D.indexOf("?") >= 0 ? "&" : "?"}dhxr${Date.now()}=1`), u.open(_, D, v), c)
          for (const M in c)
            u.setRequestHeader(M, c[M]);
        else
          _ === "POST" || _ === "PUT" || _ === "DELETE" ? u.setRequestHeader("Content-Type", "application/x-www-form-urlencoded") : _ === "GET" && (p = null);
        u.setRequestHeader("X-Requested-With", "XMLHttpRequest"), u.send(p), v || f(u);
      });
    }, urlSeparator: (_) => _.indexOf("?") !== -1 ? "&" : "?" };
    r.ajax = l, r.$ajax = r.ajax;
  }(i), Wt(i), function(r) {
    r.config = { default_date: "%j %M %Y", month_date: "%F %Y", load_date: "%Y-%m-%d", week_date: "%l", day_date: "%D %j", hour_date: "%H:%i", month_day: "%d", date_format: "%Y-%m-%d %H:%i", api_date: "%d-%m-%Y %H:%i", parse_exact_format: !1, preserve_length: !0, time_step: 5, displayed_event_color: "#ff4a4a", displayed_event_text_color: "#ffef80", wide_form: 0, day_column_padding: 8, use_select_menu_space: !0, fix_tab_position: !0, start_on_monday: !0, first_hour: 0, last_hour: 24, readonly: !1, drag_resize: !0, drag_move: !0, drag_create: !0, drag_event_body: !0, dblclick_create: !0, details_on_dblclick: !0, edit_on_create: !0, details_on_create: !0, header: null, hour_size_px: 44, resize_month_events: !1, resize_month_timed: !1, responsive_lightbox: !1, separate_short_events: !0, rtl: !1, cascade_event_display: !1, cascade_event_count: 4, cascade_event_margin: 30, multi_day: !0, multi_day_height_limit: 200, drag_lightbox: !0, preserve_scroll: !0, select: !0, undo_deleted: !0, server_utc: !1, touch: !0, touch_tip: !0, touch_drag: 500, touch_swipe_dates: !1, quick_info_detached: !0, positive_closing: !1, drag_highlight: !0, limit_drag_out: !1, icons_edit: ["icon_save", "icon_cancel"], icons_select: ["icon_details", "icon_edit", "icon_delete"], buttons_right: ["dhx_save_btn", "dhx_cancel_btn"], buttons_left: ["dhx_delete_btn"], lightbox: { sections: [{ name: "description", map_to: "text", type: "textarea", focus: !0 }, { name: "time", height: 72, type: "time", map_to: "auto" }] }, highlight_displayed_event: !0, left_border: !1, ajax_error: "alert", delay_render: 0, timeline_swap_resize: !0, wai_aria_attributes: !0, wai_aria_application_role: !0, csp: "auto", event_attribute: "data-event-id", show_errors: !0 }, r.config.buttons_left.$initial = r.config.buttons_left.join(), r.config.buttons_right.$initial = r.config.buttons_right.join(), r._helpers = { parseDate: function(l) {
      return (r.templates.xml_date || r.templates.parse_date)(l);
    }, formatDate: function(l) {
      return (r.templates.xml_format || r.templates.format_date)(l);
    } }, r.templates = {}, r.init_templates = function() {
      var l = r.date.date_to_str, _ = r.config;
      (function(h, p) {
        for (var v in p)
          h[v] || (h[v] = p[v]);
      })(r.templates, { day_date: l(_.default_date), month_date: l(_.month_date), week_date: function(h, p) {
        return _.rtl ? r.templates.day_date(r.date.add(p, -1, "day")) + " &ndash; " + r.templates.day_date(h) : r.templates.day_date(h) + " &ndash; " + r.templates.day_date(r.date.add(p, -1, "day"));
      }, day_scale_date: l(_.default_date), time_slot_text: function(h) {
        return "";
      }, time_slot_class: function(h) {
        return "";
      }, month_scale_date: l(_.week_date), week_scale_date: l(_.day_date), hour_scale: l(_.hour_date), time_picker: l(_.hour_date), event_date: l(_.hour_date), month_day: l(_.month_day), load_format: l(_.load_date), format_date: l(_.date_format, _.server_utc), parse_date: r.date.str_to_date(_.date_format, _.server_utc), api_date: r.date.str_to_date(_.api_date, !1, !1), event_header: function(h, p, v) {
        return v._mode === "small" || v._mode === "smallest" ? r.templates.event_date(h) : r.templates.event_date(h) + " - " + r.templates.event_date(p);
      }, event_text: function(h, p, v) {
        return v.text;
      }, event_class: function(h, p, v) {
        return "";
      }, month_date_class: function(h) {
        return "";
      }, week_date_class: function(h) {
        return "";
      }, event_bar_date: function(h, p, v) {
        return r.templates.event_date(h);
      }, event_bar_text: function(h, p, v) {
        return v.text;
      }, month_events_link: function(h, p) {
        return "<a>View more(" + p + " events)</a>";
      }, drag_marker_class: function(h, p, v) {
        return "";
      }, drag_marker_content: function(h, p, v) {
        return "";
      }, tooltip_date_format: r.date.date_to_str("%Y-%m-%d %H:%i"), tooltip_text: function(h, p, v) {
        return "<b>Event:</b> " + v.text + "<br/><b>Start date:</b> " + r.templates.tooltip_date_format(h) + "<br/><b>End date:</b> " + r.templates.tooltip_date_format(p);
      }, calendar_month: l("%F %Y"), calendar_scale_date: l("%D"), calendar_date: l("%d"), calendar_time: l("%d-%m-%Y") }), this.callEvent("onTemplatesReady", []);
    };
  }(i), function(r) {
    const l = Gt(r);
    r._events = {}, r.clearAll = function() {
      this._events = {}, this._loaded = {}, this._edit_id = null, this._select_id = null, this._drag_id = null, this._drag_mode = null, this._drag_pos = null, this._new_event = null, this.clear_view(), this.callEvent("onClearAll", []);
    }, r.addEvent = function(_, h, p, v, g) {
      if (!arguments.length)
        return this.addEventNow();
      var c = _;
      arguments.length != 1 && ((c = g || {}).start_date = _, c.end_date = h, c.text = p, c.id = v), c.id = c.id || r.uid(), c.text = c.text || "", typeof c.start_date == "string" && (c.start_date = this.templates.api_date(c.start_date)), typeof c.end_date == "string" && (c.end_date = this.templates.api_date(c.end_date));
      var f = 6e4 * (this.config.event_duration || this.config.time_step);
      new Date(c.end_date).valueOf() - new Date(c.start_date).valueOf() <= f && c.end_date.setTime(c.start_date.valueOf() + f), c.start_date.setMilliseconds(0), c.end_date.setMilliseconds(0), c._timed = this.isOneDayEvent(c);
      var u = !this._events[c.id];
      return this._events[c.id] = c, this.event_updated(c), this._loading || this.callEvent(u ? "onEventAdded" : "onEventChanged", [c.id, c]), c.id;
    }, r.deleteEvent = function(_, h) {
      var p = this._events[_];
      (h || this.callEvent("onBeforeEventDelete", [_, p]) && this.callEvent("onConfirmedBeforeEventDelete", [_, p])) && (p && (r.getState().select_id == _ && r.unselect(), delete this._events[_], this.event_updated(p), this._drag_id == p.id && (this._drag_id = null, this._drag_mode = null, this._drag_pos = null)), this.callEvent("onEventDeleted", [_, p]));
    }, r.getEvent = function(_) {
      return this._events[_];
    }, r.setEvent = function(_, h) {
      h.id || (h.id = _), this._events[_] = h;
    }, r.for_rendered = function(_, h) {
      for (var p = l.lookup(_), v = p.length - 1; v >= 0; v--) {
        var g = this._rendered.indexOf(p[v]);
        g < 0 || h(p[v], g);
      }
    }, r._forget_rendered_event = function(_, h) {
      l.sync();
      var p = h === void 0 || this._rendered[h] !== _ ? this._rendered.indexOf(_) : h;
      return !(p < 0 || (this._rendered.splice(p, 1), l.forget(_), 0));
    }, r.changeEventId = function(_, h) {
      if (_ != h) {
        var p = this._events[_];
        p && (p.id = h, this._events[h] = p, delete this._events[_]), this.for_rendered(_, function(v) {
          v.setAttribute("event_id", h), v.setAttribute(r.config.event_attribute, h);
        }), l.invalidate(), this._select_id == _ && (this._select_id = h), this._edit_id == _ && (this._edit_id = h), this.callEvent("onEventIdChange", [_, h]);
      }
    }, function() {
      for (var _ = ["text", "Text", "start_date", "StartDate", "end_date", "EndDate"], h = function(g) {
        return function(c) {
          return r.getEvent(c)[g];
        };
      }, p = function(g) {
        return function(c, f) {
          var u = r.getEvent(c);
          u[g] = f, u._changed = !0, u._timed = this.isOneDayEvent(u), r.event_updated(u, !0);
        };
      }, v = 0; v < _.length; v += 2)
        r["getEvent" + _[v + 1]] = h(_[v]), r["setEvent" + _[v + 1]] = p(_[v]);
    }(), r.event_updated = function(_, h) {
      this.is_visible_events(_) ? this.render_view_data() : this.clear_event(_.id);
    }, r.is_visible_events = function(_) {
      if (!this._min_date || !this._max_date)
        return !1;
      if (_.start_date.valueOf() < this._max_date.valueOf() && this._min_date.valueOf() < _.end_date.valueOf()) {
        var h = _.start_date.getHours(), p = _.end_date.getHours() + _.end_date.getMinutes() / 60, v = this.config.last_hour, g = this.config.first_hour;
        return !(!this._table_view && (p > v || p <= g) && (h >= v || h < g) && !((_.end_date.valueOf() - _.start_date.valueOf()) / 36e5 > 24 - (this.config.last_hour - this.config.first_hour) || h < v && p > g));
      }
      return !1;
    }, r.isOneDayEvent = function(_) {
      var h = new Date(_.end_date.valueOf() - 1);
      return _.start_date.getFullYear() === h.getFullYear() && _.start_date.getMonth() === h.getMonth() && _.start_date.getDate() === h.getDate() && _.end_date.valueOf() - _.start_date.valueOf() < 864e5;
    }, r.get_visible_events = function(_) {
      var h = [];
      for (var p in this._events)
        this.is_visible_events(this._events[p]) && (_ && !this._events[p]._timed || this.filter_event(p, this._events[p]) && h.push(this._events[p]));
      return h;
    }, r.filter_event = function(_, h) {
      var p = this["filter_" + this._mode];
      return !p || p(_, h);
    }, r._is_main_area_event = function(_) {
      return !!_._timed;
    }, r.render_view_data = function(_, h) {
      var p = !1;
      if (!_) {
        if (p = !0, this._not_render)
          return void (this._render_wait = !0);
        this._render_wait = !1, this.clear_view(), _ = this.get_visible_events(!(this._table_view || this.config.multi_day));
      }
      for (var v = 0, g = _.length; v < g; v++)
        this._recalculate_timed(_[v]);
      if (this.config.multi_day && !this._table_view) {
        var c = [], f = [];
        for (v = 0; v < _.length; v++)
          this._is_main_area_event(_[v]) ? c.push(_[v]) : f.push(_[v]);
        if (!this._els.dhx_multi_day) {
          var u = r._commonErrorMessages.unknownView(this._mode);
          throw new Error(u);
        }
        this._rendered_location = this._els.dhx_multi_day[0], this._table_view = !0, this.render_data(f, h), this._table_view = !1, this._rendered_location = this._els.dhx_cal_data[0], this._table_view = !1, this.render_data(c, h);
      } else {
        var y = document.createDocumentFragment(), w = this._els.dhx_cal_data[0];
        this._rendered_location = y, this.render_data(_, h), w.appendChild(y), this._rendered_location = w;
      }
      p && this.callEvent("onDataRender", []);
    }, r._view_month_day = function(_) {
      var h = r.getActionData(_).date;
      r.callEvent("onViewMoreClick", [h]) && r.setCurrentView(h, "day");
    }, r._render_month_link = function(_) {
      for (var h = this._rendered_location, p = this._lame_clone(_), v = _._sday; v < _._eday; v++) {
        p._sday = v, p._eday = v + 1;
        var g = r.date, c = r._min_date;
        c = g.add(c, p._sweek, "week"), c = g.add(c, p._sday, "day");
        var f = r.getEvents(c, g.add(c, 1, "day")).length, u = this._get_event_bar_pos(p), y = u.x2 - u.x, w = document.createElement("div");
        r.event(w, "click", function(D) {
          r._view_month_day(D);
        }), w.className = "dhx_month_link", w.style.top = u.y + "px", w.style.left = u.x + "px", w.style.width = y + "px", w.innerHTML = r.templates.month_events_link(c, f), this._rendered.push(w), h.appendChild(w);
      }
    }, r._recalculate_timed = function(_) {
      var h;
      _ && (h = typeof _ != "object" ? this._events[_] : _) && (h._timed = r.isOneDayEvent(h));
    }, r.attachEvent("onEventChanged", r._recalculate_timed), r.attachEvent("onEventAdded", r._recalculate_timed), r.render_data = function(_, h) {
      _ = this._pre_render_events(_, h);
      for (var p = {}, v = 0; v < _.length; v++)
        if (this._table_view)
          if (r._mode != "month")
            this.render_event_bar(_[v]);
          else {
            var g = r.config.max_month_events;
            g !== 1 * g || _[v]._sorder < g ? this.render_event_bar(_[v]) : g !== void 0 && _[v]._sorder == g && r._render_month_link(_[v]);
          }
        else {
          var c = _[v], f = r.locate_holder(c._sday);
          if (!f)
            continue;
          p[c._sday] || (p[c._sday] = { real: f, buffer: document.createDocumentFragment(), width: f.clientWidth });
          var u = p[c._sday];
          this.render_event(c, u.buffer, u.width);
        }
      for (var v in p)
        (u = p[v]).real && u.buffer && u.real.appendChild(u.buffer);
    }, r._get_first_visible_cell = function(_) {
      for (var h = 0; h < _.length; h++)
        if ((_[h].className || "").indexOf("dhx_scale_ignore") == -1)
          return _[h];
      return _[0];
    }, r._pre_render_events = function(_, h) {
      var p = this.xy.bar_height, v = this._colsS.heights, g = this._colsS.heights = [0, 0, 0, 0, 0, 0, 0], c = this._els.dhx_cal_data[0];
      if (_ = this._table_view ? this._pre_render_events_table(_, h) : this._pre_render_events_line(_, h), this._table_view)
        if (h)
          this._colsS.heights = v;
        else {
          var f = c.querySelectorAll(".dhx_cal_month_row");
          if (f.length) {
            for (var u = 0; u < f.length; u++) {
              g[u]++;
              var y = f[u].querySelectorAll(".dhx_cal_month_cell"), w = this._colsS.height - this.xy.month_head_height;
              if (g[u] * p > w) {
                var D = w;
                1 * this.config.max_month_events !== this.config.max_month_events || g[u] <= this.config.max_month_events ? D = g[u] * p : (this.config.max_month_events + 1) * p > w && (D = (this.config.max_month_events + 1) * p), f[u].style.height = D + this.xy.month_head_height + "px";
              }
              g[u] = (g[u - 1] || 0) + r._get_first_visible_cell(y).offsetHeight;
            }
            g.unshift(0);
            const T = this.$container.querySelector(".dhx_cal_data");
            if (T.offsetHeight < T.scrollHeight && !r._colsS.scroll_fix && r.xy.scroll_width) {
              var M = r._colsS, k = M[M.col_length], N = M.heights.slice();
              k -= r.xy.scroll_width || 0, this._calc_scale_sizes(k, this._min_date, this._max_date), r._colsS.heights = N, this.set_xy(this._els.dhx_cal_header[0], k), r._render_scales(this._els.dhx_cal_header[0]), r._render_month_scale(this._els.dhx_cal_data[0], this._get_timeunit_start(), this._min_date), M.scroll_fix = !0;
            }
          } else if (_.length || this._els.dhx_multi_day[0].style.visibility != "visible" || (g[0] = -1), _.length || g[0] == -1) {
            var m = (g[0] + 1) * p + 4, x = m, b = m + "px";
            this.config.multi_day_height_limit && (b = (x = Math.min(m, this.config.multi_day_height_limit)) + "px");
            var E = this._els.dhx_multi_day[0];
            E.style.height = b, E.style.visibility = g[0] == -1 ? "hidden" : "visible", E.style.display = g[0] == -1 ? "none" : "";
            var S = this._els.dhx_multi_day[1];
            S.style.height = b, S.style.visibility = g[0] == -1 ? "hidden" : "visible", S.style.display = g[0] == -1 ? "none" : "", S.className = g[0] ? "dhx_multi_day_icon" : "dhx_multi_day_icon_small", this._dy_shift = (g[0] + 1) * p, this.config.multi_day_height_limit && (this._dy_shift = Math.min(this.config.multi_day_height_limit, this._dy_shift)), g[0] = 0, x != m && (E.style.overflowY = "auto", S.style.position = "fixed", S.style.top = "", S.style.left = "");
          }
        }
      return _;
    }, r._get_event_sday = function(_) {
      var h = this.date.day_start(new Date(_.start_date));
      return Math.round((h.valueOf() - this._min_date.valueOf()) / 864e5);
    }, r._get_event_mapped_end_date = function(_) {
      var h = _.end_date;
      if (this.config.separate_short_events) {
        var p = (_.end_date - _.start_date) / 6e4;
        p < this._min_mapped_duration && (h = this.date.add(h, this._min_mapped_duration - p, "minute"));
      }
      return h;
    }, r._pre_render_events_line = function(_, h) {
      _.sort(function(S, T) {
        return S.start_date.valueOf() == T.start_date.valueOf() ? S.id > T.id ? 1 : -1 : S.start_date > T.start_date ? 1 : -1;
      });
      var p = [], v = [];
      this._min_mapped_duration = Math.floor(60 * this.xy.min_event_height / this.config.hour_size_px);
      for (var g = 0; g < _.length; g++) {
        var c = _[g], f = c.start_date, u = c.end_date, y = f.getHours(), w = u.getHours();
        if (c._sday = this._get_event_sday(c), this._ignores[c._sday])
          _.splice(g, 1), g--;
        else {
          if (p[c._sday] || (p[c._sday] = []), !h) {
            c._inner = !1;
            for (var D = p[c._sday]; D.length; ) {
              var M = D[D.length - 1];
              if (!(this._get_event_mapped_end_date(M).valueOf() <= c.start_date.valueOf()))
                break;
              D.splice(D.length - 1, 1);
            }
            for (var k = D.length, N = !1, m = 0; m < D.length; m++)
              if (M = D[m], this._get_event_mapped_end_date(M).valueOf() <= c.start_date.valueOf()) {
                N = !0, c._sorder = M._sorder, k = m, c._inner = !0;
                break;
              }
            if (D.length && (D[D.length - 1]._inner = !0), !N)
              if (D.length)
                if (D.length <= D[D.length - 1]._sorder) {
                  if (D[D.length - 1]._sorder)
                    for (m = 0; m < D.length; m++) {
                      for (var x = !1, b = 0; b < D.length; b++)
                        if (D[b]._sorder == m) {
                          x = !0;
                          break;
                        }
                      if (!x) {
                        c._sorder = m;
                        break;
                      }
                    }
                  else
                    c._sorder = 0;
                  c._inner = !0;
                } else {
                  var E = D[0]._sorder;
                  for (m = 1; m < D.length; m++)
                    D[m]._sorder > E && (E = D[m]._sorder);
                  c._sorder = E + 1, c._inner = !1;
                }
              else
                c._sorder = 0;
            D.splice(k, k == D.length ? 0 : 1, c), D.length > (D.max_count || 0) ? (D.max_count = D.length, c._count = D.length) : c._count = c._count ? c._count : 1;
          }
          (y < this.config.first_hour || w >= this.config.last_hour) && (v.push(c), _[g] = c = this._copy_event(c), y < this.config.first_hour && (c.start_date.setHours(this.config.first_hour), c.start_date.setMinutes(0)), w >= this.config.last_hour && (c.end_date.setMinutes(0), c.end_date.setHours(this.config.last_hour)), c.start_date > c.end_date || y == this.config.last_hour) && (_.splice(g, 1), g--);
        }
      }
      if (!h) {
        for (g = 0; g < _.length; g++)
          _[g]._count = p[_[g]._sday].max_count;
        for (g = 0; g < v.length; g++)
          v[g]._count = p[v[g]._sday].max_count;
      }
      return _;
    }, r._time_order = function(_) {
      _.sort(function(h, p) {
        return h.start_date.valueOf() == p.start_date.valueOf() ? h._timed && !p._timed ? 1 : !h._timed && p._timed ? -1 : h.id > p.id ? 1 : -1 : h.start_date > p.start_date ? 1 : -1;
      });
    }, r._is_any_multiday_cell_visible = function(_, h, p) {
      var v = this._cols.length, g = !1, c = _, f = !0, u = new Date(h);
      for (r.date.day_start(new Date(h)).valueOf() != h.valueOf() && (u = r.date.day_start(u), u = r.date.add(u, 1, "day")); c < u; ) {
        f = !1;
        var y = this.locate_holder_day(c, !1, p) % v;
        if (!this._ignores[y]) {
          g = !0;
          break;
        }
        c = r.date.add(c, 1, "day");
      }
      return f || g;
    }, r._pre_render_events_table = function(_, h) {
      this._time_order(_);
      for (var p, v = [], g = [[], [], [], [], [], [], []], c = this._colsS.heights, f = this._cols.length, u = {}, y = 0; y < _.length; y++) {
        var w = _[y], D = w.id;
        u[D] || (u[D] = { first_chunk: !0, last_chunk: !0 });
        var M = u[D], k = p || w.start_date, N = w.end_date;
        k < this._min_date && (M.first_chunk = !1, k = this._min_date), N > this._max_date && (M.last_chunk = !1, N = this._max_date);
        var m = this.locate_holder_day(k, !1, w);
        if (w._sday = m % f, !this._ignores[w._sday] || !w._timed) {
          var x = this.locate_holder_day(N, !0, w) || f;
          if (w._eday = x % f || f, w._length = x - m, w._sweek = Math.floor((this._correct_shift(k.valueOf(), 1) - this._min_date.valueOf()) / (864e5 * f)), r._is_any_multiday_cell_visible(k, N, w)) {
            var b, E = g[w._sweek];
            for (b = 0; b < E.length && !(E[b]._eday <= w._sday); b++)
              ;
            if (w._sorder && h || (w._sorder = b), w._sday + w._length <= f)
              p = null, v.push(w), E[b] = w, c[w._sweek] = E.length - 1, w._first_chunk = M.first_chunk, w._last_chunk = M.last_chunk;
            else {
              var S = this._copy_event(w);
              S.id = w.id, S._length = f - w._sday, S._eday = f, S._sday = w._sday, S._sweek = w._sweek, S._sorder = w._sorder, S.end_date = this.date.add(k, S._length, "day"), S._first_chunk = M.first_chunk, M.first_chunk && (M.first_chunk = !1), v.push(S), E[b] = S, p = S.end_date, c[w._sweek] = E.length - 1, y--;
            }
          } else
            p = null;
        }
      }
      return v;
    }, r._copy_dummy = function() {
      var _ = new Date(this.start_date), h = new Date(this.end_date);
      this.start_date = _, this.end_date = h;
    }, r._copy_event = function(_) {
      return this._copy_dummy.prototype = _, new this._copy_dummy();
    }, r._rendered = [], r._reset_rendered_events = function() {
      this._rendered = [], l.invalidate();
    }, r.clear_view = function() {
      for (var _ = 0; _ < this._rendered.length; _++) {
        var h = this._rendered[_];
        h.parentNode && h.parentNode.removeChild(h);
      }
      this._reset_rendered_events();
    }, r.updateEvent = function(_) {
      var h = this.getEvent(_);
      this.clear_event(_), h && this.is_visible_events(h) && this.filter_event(_, h) && (this._table_view || this.config.multi_day || h._timed) && (this.config.update_render ? this.render_view_data() : this.getState().mode != "month" || this.getState().drag_id || this.isOneDayEvent(h) ? this.render_view_data([h], !0) : this.render_view_data());
    }, r.clear_event = function(_) {
      this.for_rendered(_, function(h, p) {
        h.parentNode && h.parentNode.removeChild(h), r._forget_rendered_event(h, p);
      });
    }, r._y_from_date = function(_) {
      var h = 60 * _.getHours() + _.getMinutes();
      return Math.round((60 * h * 1e3 - 60 * this.config.first_hour * 60 * 1e3) * this.config.hour_size_px / 36e5) % (24 * this.config.hour_size_px);
    }, r._calc_event_y = function(_, h) {
      h = h || 0;
      var p = 60 * _.start_date.getHours() + _.start_date.getMinutes(), v = 60 * _.end_date.getHours() + _.end_date.getMinutes() || 60 * r.config.last_hour;
      return { top: this._y_from_date(_.start_date), height: Math.max(h, (v - p) * this.config.hour_size_px / 60) };
    }, r.render_event = function(_, h, p) {
      var v = r.xy.menu_width, g = this.config.use_select_menu_space ? 0 : v;
      if (!(_._sday < 0)) {
        var c = r.locate_holder(_._sday);
        if (c) {
          h = h || c;
          var f = this._calc_event_y(_, r.xy.min_event_height), u = f.top, y = f.height, w = _._count || 1, D = _._sorder || 0;
          p = p || c.clientWidth, this.config.day_column_padding && (p -= this.config.day_column_padding);
          var M = Math.floor((p - g) / w), k = D * M + 1;
          if (_._inner || (M *= w - D), this.config.cascade_event_display) {
            const A = this.config.cascade_event_count, $ = this.config.cascade_event_margin;
            let H, O = (w - D - 1) % A * $, P = D % A * $;
            w * $ < p - this.config.day_column_padding ? H = _._inner ? O / 2 : 0 : (H = _._inner ? O / 3 : 0, k = P / 3, w * $ / 2 > p - this.config.day_column_padding && (H = _._inner ? O / A : 0, k = P / A)), M = Math.floor(p - g - k - H);
          }
          _._mode = y < 30 ? "smallest" : y < 42 ? "small" : null;
          var N = this._render_v_bar(_, g + k, u, M, y, _._text_style, r.templates.event_header(_.start_date, _.end_date, _), r.templates.event_text(_.start_date, _.end_date, _));
          if (_._mode === "smallest" ? N.classList.add("dhx_cal_event--xsmall") : _._mode === "small" && N.classList.add("dhx_cal_event--small"), this._waiAria.eventAttr(_, N), this._rendered.push(N), h.appendChild(N), k = k + parseInt(this.config.rtl ? c.style.right : c.style.left, 10) + g, this._edit_id == _.id) {
            N.style.zIndex = 1, M = Math.max(M, r.xy.editor_width), (N = document.createElement("div")).setAttribute("event_id", _.id), N.setAttribute(this.config.event_attribute, _.id), this._waiAria.eventAttr(_, N), N.className = "dhx_cal_event dhx_cal_editor", this.config.rtl && k++, this.set_xy(N, M, y, k, u), _.color && N.style.setProperty("--dhx-scheduler-event-background", _.color);
            var m = r.templates.event_class(_.start_date, _.end_date, _);
            m && (N.className += " " + m);
            var x = document.createElement("div");
            x.style.cssText += "overflow:hidden;height:100%", N.appendChild(x), this._els.dhx_cal_data[0].appendChild(N), this._rendered.push(N), x.innerHTML = "<textarea class='dhx_cal_editor'>" + _.text + "</textarea>", this._editor = x.querySelector("textarea"), r.event(this._editor, "keydown", function(A) {
              if (A.shiftKey)
                return !0;
              var $ = A.keyCode;
              $ == r.keys.edit_save && r.editStop(!0), $ == r.keys.edit_cancel && r.editStop(!1), $ != r.keys.edit_save && $ != r.keys.edit_cancel || A.preventDefault && A.preventDefault();
            }), r.event(this._editor, "selectstart", function(A) {
              return A.cancelBubble = !0, !0;
            }), r._focus(this._editor, !0), this._els.dhx_cal_data[0].scrollLeft = 0;
          }
          if (this.xy.menu_width !== 0 && this._select_id == _.id) {
            this.config.cascade_event_display && this._drag_mode && (N.style.zIndex = 1);
            for (var b, E = this.config["icons_" + (this._edit_id == _.id ? "edit" : "select")], S = "", T = 0; T < E.length; T++) {
              const A = E[T];
              b = this._waiAria.eventMenuAttrString(A), S += `<div class='dhx_menu_icon ${A}' title='${this.locale.labels[A]}' ${b}></div>`;
            }
            var C = this._render_v_bar(_, k - v - 1, u, v, null, "", "<div class='dhx_menu_head'></div>", S, !0);
            _.color && C.style.setProperty("--dhx-scheduler-event-background", _.color), _.textColor && C.style.setProperty("--dhx-scheduler-event-color", _.textColor), this._els.dhx_cal_data[0].appendChild(C), this._rendered.push(C);
          }
          this.config.drag_highlight && this._drag_id == _.id && this.highlightEventPosition(_);
        }
      }
    }, r._render_v_bar = function(_, h, p, v, g, c, f, u, y) {
      var w = document.createElement("div"), D = _.id, M = y ? "dhx_cal_event dhx_cal_select_menu" : "dhx_cal_event", k = r.getState();
      k.drag_id == _.id && (M += " dhx_cal_event_drag"), k.select_id == _.id && (M += " dhx_cal_event_selected");
      var N = r.templates.event_class(_.start_date, _.end_date, _);
      N && (M = M + " " + N), this.config.cascade_event_display && (M += " dhx_cal_event_cascade");
      var m = v - 1, x = `<div event_id="${D}" ${this.config.event_attribute}="${D}" class="${M}"
				style="position:absolute; top:${p}px; ${this.config.rtl ? "right:" : "left:"}${h}px; width:${m}px; height:${g}px; ${c || ""}" 
				data-bar-start="${_.start_date.valueOf()}" data-bar-end="${_.end_date.valueOf()}">
				</div>`;
      w.innerHTML = x;
      var b = w.cloneNode(!0).firstChild;
      if (!y && r.renderEvent(b, _, v, g, f, u))
        return _.color && b.style.setProperty("--dhx-scheduler-event-background", _.color), _.textColor && b.style.setProperty("--dhx-scheduler-event-color", _.textColor), b;
      b = w.firstChild, _.color && b.style.setProperty("--dhx-scheduler-event-background", _.color), _.textColor && b.style.setProperty("--dhx-scheduler-event-color", _.textColor);
      var E = '<div class="dhx_event_move dhx_header" >&nbsp;</div>';
      E += '<div class="dhx_event_move dhx_title">' + f + "</div>", E += '<div class="dhx_body">' + u + "</div>";
      var S = "dhx_event_resize dhx_footer";
      return (y || _._drag_resize === !1) && (S = "dhx_resize_denied " + S), E += '<div class="' + S + '" style=" width:' + (y ? " margin-top:-1px;" : "") + '" ></div>', b.innerHTML = E, b;
    }, r.renderEvent = function() {
      return !1;
    }, r.locate_holder = function(_) {
      return this._mode == "day" ? this._els.dhx_cal_data[0].firstChild : this._els.dhx_cal_data[0].childNodes[_];
    }, r.locate_holder_day = function(_, h) {
      var p = Math.floor((this._correct_shift(_, 1) - this._min_date) / 864e5);
      return h && this.date.time_part(_) && p++, p;
    }, r._get_dnd_order = function(_, h, p) {
      if (!this._drag_event)
        return _;
      this._drag_event._orig_sorder ? _ = this._drag_event._orig_sorder : this._drag_event._orig_sorder = _;
      for (var v = h * _; v + h > p; )
        _--, v -= h;
      return Math.max(_, 0);
    }, r._get_event_bar_pos = function(_) {
      var h = this.config.rtl, p = this._colsS, v = p[_._sday], g = p[_._eday];
      h && (v = p[p.col_length] - p[_._eday] + p[0], g = p[p.col_length] - p[_._sday] + p[0]), g == v && (g = p[_._eday + 1]);
      var c = this.xy.bar_height, f = _._sorder;
      if (_.id == this._drag_id) {
        var u = p.heights[_._sweek + 1] - p.heights[_._sweek] - this.xy.month_head_height;
        f = r._get_dnd_order(f, c, u);
      }
      var y = f * c;
      return { x: v, x2: g, y: p.heights[_._sweek] + (p.height ? this.xy.month_scale_height + 2 : 2) + y };
    }, r.render_event_bar = function(_) {
      var h = this._rendered_location, p = this._get_event_bar_pos(_), v = p.y, g = p.x, c = p.x2, f = "";
      if (c) {
        var u = r.config.resize_month_events && this._mode == "month" && (!_._timed || r.config.resize_month_timed), y = document.createElement("div"), w = _.hasOwnProperty("_first_chunk") && _._first_chunk, D = _.hasOwnProperty("_last_chunk") && _._last_chunk, M = u && (_._timed || w), k = u && (_._timed || D), N = !0, m = "dhx_cal_event_clear";
        _._timed && !u || (N = !1, m = "dhx_cal_event_line"), w && (m += " dhx_cal_event_line_start"), D && (m += " dhx_cal_event_line_end"), M && (f += "<div class='dhx_event_resize dhx_event_resize_start'></div>"), k && (f += "<div class='dhx_event_resize dhx_event_resize_end'></div>");
        var x = r.templates.event_class(_.start_date, _.end_date, _);
        x && (m += " " + x);
        var b = _.color ? "--dhx-scheduler-event-background:" + _.color + ";" : "", E = _.textColor ? "--dhx-scheduler-event-color:" + _.textColor + ";" : "", S = ["position:absolute", "top:" + v + "px", "left:" + g + "px", "width:" + (c - g - (N ? 1 : 0)) + "px", "height:" + (this.xy.bar_height - 2) + "px", E, b, _._text_style || ""].join(";"), T = "<div event_id='" + _.id + "' " + this.config.event_attribute + "='" + _.id + "' class='" + m + "' style='" + S + "'" + this._waiAria.eventBarAttrString(_) + ">";
        u && (T += f), r.getState().mode != "month" || _._beforeEventChangedFlag || (_ = r.getEvent(_.id)), _._timed && (T += `<span class='dhx_cal_event_clear_date'>${r.templates.event_bar_date(_.start_date, _.end_date, _)}</span>`), T += "<div class='dhx_cal_event_line_content'>", T += r.templates.event_bar_text(_.start_date, _.end_date, _) + "</div>", T += "</div>", T += "</div>", y.innerHTML = T, this._rendered.push(y.firstChild), h.appendChild(y.firstChild);
      }
    }, r._locate_event = function(_) {
      for (var h = null; _ && !h && _.getAttribute; )
        h = _.getAttribute(this.config.event_attribute), _ = _.parentNode;
      return h;
    }, r.edit = function(_) {
      this._edit_id != _ && (this.editStop(!1, _), this._edit_id = _, this.updateEvent(_));
    }, r.editStop = function(_, h) {
      if (!h || this._edit_id != h) {
        var p = this.getEvent(this._edit_id);
        p && (_ && (p.text = this._editor.value), this._edit_id = null, this._editor = null, this.updateEvent(p.id), this._edit_stop_event(p, _));
      }
    }, r._edit_stop_event = function(_, h) {
      this._new_event ? (h ? this.callEvent("onEventAdded", [_.id, _]) : _ && this.deleteEvent(_.id, !0), delete _.$new, this._new_event = null) : h && this.callEvent("onEventChanged", [_.id, _]);
    }, r.getEvents = function(_, h) {
      var p = [];
      for (var v in this._events) {
        var g = this._events[v];
        g && (!_ && !h || g.start_date < h && g.end_date > _) && p.push(g);
      }
      return p;
    }, r.getRenderedEvent = function(_) {
      if (_) {
        for (var h = r._rendered, p = 0; p < h.length; p++) {
          var v = h[p];
          if (v.getAttribute(r.config.event_attribute) == _)
            return v;
        }
        return null;
      }
    }, r.showEvent = function(_, h) {
      _ && typeof _ == "object" && (h = _.mode, D = _.section, _ = _.section);
      var p = typeof _ == "number" || typeof _ == "string" ? r.getEvent(_) : _;
      if (h = h || r._mode, p && (!this.checkEvent("onBeforeEventDisplay") || this.callEvent("onBeforeEventDisplay", [p, h]))) {
        var v = r.config.scroll_hour;
        r.config.scroll_hour = p.start_date.getHours();
        var g = r.config.preserve_scroll;
        r.config.preserve_scroll = !1;
        var c = p.color, f = p.textColor;
        if (r.config.highlight_displayed_event && (p.color = r.config.displayed_event_color, p.textColor = r.config.displayed_event_text_color), r.setCurrentView(new Date(p.start_date), h), r.config.scroll_hour = v, r.config.preserve_scroll = g, r.matrix && r.matrix[h]) {
          var u = r.getView(), y = u.y_property, w = r.getEvent(p.id);
          if (w) {
            if (!D) {
              var D = w[y];
              Array.isArray(D) ? D = D[0] : typeof D == "string" && r.config.section_delimiter && D.indexOf(r.config.section_delimiter) > -1 && (D = D.split(r.config.section_delimiter)[0]);
            }
            var M = u.getSectionTop(D), k = u.posFromDate(w.start_date), N = r.$container.querySelector(".dhx_timeline_data_wrapper");
            if (k -= (N.offsetWidth - u.dx) / 2, M = M - N.offsetHeight / 2 + u.dy / 2, u._smartRenderingEnabled())
              var m = u.attachEvent("onScroll", function() {
                x(), u.detachEvent(m);
              });
            u.scrollTo({ left: k, top: M }), u._smartRenderingEnabled() || x();
          }
        } else
          x();
        r.callEvent("onAfterEventDisplay", [p, h]);
      }
      function x() {
        p.color = c, p.textColor = f;
      }
    };
  }(i), function(r) {
    r._append_drag_marker = function(l) {
      if (!l.parentNode) {
        var _ = r._els.dhx_cal_data[0].lastChild, h = r._getClassName(_);
        h.indexOf("dhx_scale_holder") < 0 && _.previousSibling && (_ = _.previousSibling), h = r._getClassName(_), _ && h.indexOf("dhx_scale_holder") === 0 && _.appendChild(l);
      }
    }, r._update_marker_position = function(l, _) {
      var h = r._calc_event_y(_, 0);
      l.style.top = h.top + "px", l.style.height = h.height + "px";
    }, r.highlightEventPosition = function(l) {
      var _ = document.createElement("div");
      _.setAttribute("event_id", l.id), _.setAttribute(this.config.event_attribute, l.id), this._rendered.push(_), this._update_marker_position(_, l);
      var h = this.templates.drag_marker_class(l.start_date, l.end_date, l), p = this.templates.drag_marker_content(l.start_date, l.end_date, l);
      _.className = "dhx_drag_marker", h && (_.className += " " + h), p && (_.innerHTML = p), this._append_drag_marker(_);
    };
  }(i), Xt(i), Zt(i), Qt(i), function(r) {
    r.getRootView = function() {
      return { view: { render: function() {
        return { tag: "div", type: 1, attrs: { style: "width:100%;height:100%;" }, hooks: { didInsert: function() {
          r.setCurrentView();
        } }, body: [{ el: this.el, type: 1 }] };
      }, init: function() {
        var l = document.createElement("DIV");
        l.id = "scheduler_" + r.uid(), l.style.width = "100%", l.style.height = "100%", l.classList.add("dhx_cal_container"), l.cmp = "grid", l.innerHTML = '<div class="dhx_cal_navline"><div class="dhx_cal_prev_button"></div><div class="dhx_cal_next_button"></div><div class="dhx_cal_today_button"></div><div class="dhx_cal_date"></div><div class="dhx_cal_tab" data-tab="day"></div><div class="dhx_cal_tab" data-tab="week"></div><div class="dhx_cal_tab" data-tab="month"></div></div><div class="dhx_cal_header"></div><div class="dhx_cal_data"></div>', r.init(l), this.el = l;
      } }, type: 4 };
    };
  }(i), ea(i), typeof window < "u" && window.jQuery && (n = window.jQuery, s = 0, a = [], n.fn.dhx_scheduler = function(r) {
    if (typeof r != "string") {
      var l = [];
      return this.each(function() {
        if (this && this.getAttribute)
          if (this.getAttribute("dhxscheduler"))
            l.push(window[this.getAttribute("dhxscheduler")]);
          else {
            var _ = "scheduler";
            s && (_ = "scheduler" + (s + 1), window[_] = Scheduler.getSchedulerInstance());
            var h = window[_];
            for (var p in this.setAttribute("dhxscheduler", _), r)
              p != "data" && (h.config[p] = r[p]);
            this.getElementsByTagName("div").length || (this.innerHTML = '<div class="dhx_cal_navline"><div class="dhx_cal_prev_button"></div><div class="dhx_cal_next_button"></div><div class="dhx_cal_today_button"></div><div class="dhx_cal_date"></div><div class="dhx_cal_tab" name="day_tab" data-tab="day" style="right:204px;"></div><div class="dhx_cal_tab" name="week_tab" data-tab="week" style="right:140px;"></div><div class="dhx_cal_tab" name="month_tab" data-tab="month" style="right:76px;"></div></div><div class="dhx_cal_header"></div><div class="dhx_cal_data"></div>', this.className += " dhx_cal_container"), h.init(this, h.config.date, h.config.mode), r.data && h.parse(r.data), l.push(h), s++;
          }
      }), l.length === 1 ? l[0] : l;
    }
    if (a[r])
      return a[r].apply(this, []);
    n.error("Method " + r + " does not exist on jQuery.dhx_scheduler");
  }), function(r) {
    (function() {
      var l = r.setCurrentView, _ = r.updateView, h = null, p = null, v = function(f, u) {
        var y = this;
        le.clearTimeout(p), le.clearTimeout(h);
        var w = y._date, D = y._mode;
        c(this, f, u), p = setTimeout(function() {
          r.$destroyed || (y.callEvent("onBeforeViewChange", [D, w, u || y._mode, f || y._date]) ? (_.call(y, f, u), y.callEvent("onViewChange", [y._mode, y._date]), le.clearTimeout(h), p = 0) : c(y, w, D));
        }, r.config.delay_render);
      }, g = function(f, u) {
        var y = this, w = arguments;
        c(this, f, u), le.clearTimeout(h), h = setTimeout(function() {
          r.$destroyed || p || _.apply(y, w);
        }, r.config.delay_render);
      };
      function c(f, u, y) {
        u && (f._date = u), y && (f._mode = y);
      }
      r.attachEvent("onSchedulerReady", function() {
        r.config.delay_render ? (r.setCurrentView = v, r.updateView = g) : (r.setCurrentView = l, r.updateView = _);
      });
    })();
  }(i), function(r) {
    r.createDataProcessor = function(l) {
      var _, h;
      l instanceof Function ? _ = l : l.hasOwnProperty("router") ? _ = l.router : l.hasOwnProperty("event") && (_ = l), h = _ ? "CUSTOM" : l.mode || "REST-JSON";
      var p = new $e(l.url);
      return p.init(r), p.setTransactionMode({ mode: h, router: _ }, l.batchUpdate), p;
    }, r.DataProcessor = $e;
  }(i), function(r) {
    r.attachEvent("onSchedulerReady", function() {
      typeof dhtmlxError < "u" && window.dhtmlxError.catchError("LoadXML", function(l, _, h) {
        var p = h[0].responseText;
        switch (r.config.ajax_error) {
          case "alert":
            le.alert(p);
            break;
          case "console":
            le.console.log(p);
        }
      });
    });
  }(i);
  const o = new na(ra);
  i.i18n = { addLocale: o.addLocale, setLocale: function(r) {
    if (typeof r == "string") {
      var l = o.getLocale(r);
      l || (l = o.getLocale("en")), i.locale = l;
    } else if (r)
      if (i.locale)
        for (var _ in r)
          r[_] && typeof r[_] == "object" ? (i.locale[_] || (i.locale[_] = {}), i.mixin(i.locale[_], r[_], !0)) : i.locale[_] = r[_];
      else
        i.locale = r;
    var h = i.locale.labels;
    h.dhx_save_btn = h.icon_save, h.dhx_cancel_btn = h.icon_cancel, h.dhx_delete_btn = h.icon_delete, i.$container && i.get_elements();
  }, getLocale: o.getLocale }, i.i18n.setLocale("en"), i.ext = {}, Ht(i);
  const d = {};
  return i.plugins = function(r) {
    return function(_, h, p) {
      const v = [];
      for (const g in _)
        if (_[g]) {
          const c = g.toLowerCase();
          h[c] && h[c].forEach(function(f) {
            const u = f.toLowerCase();
            _[u] || v.push(u);
          }), v.push(c);
        }
      return v.sort(function(g, c) {
        const f = p[g] || 0, u = p[c] || 0;
        return f > u ? 1 : f < u ? -1 : 0;
      }), v;
    }(r, { treetimeline: ["timeline"], daytimeline: ["timeline"], outerdrag: ["legacy"] }, { legacy: 1, limit: 1, timeline: 2, daytimeline: 3, treetimeline: 3, outerdrag: 6 }).forEach(function(_) {
      if (!d[_]) {
        const h = e.getExtension(_);
        if (!h)
          throw new Error("unknown plugin " + _);
        h(i), d[_] = !0;
      }
    }), d;
  }, i.plugins({ all_timed: "short" }), i;
}
class sa {
  constructor(i) {
    this._extensions = {};
    for (const t in i)
      this._extensions[t] = i[t];
  }
  addExtension(i, t) {
    this._extensions[i] = t;
  }
  getExtension(i) {
    return this._extensions[i];
  }
}
typeof dhtmlx < "u" && dhtmlx.attaches && (dhtmlx.attaches.attachScheduler = function(e, i, t, n) {
  t = t || '<div class="dhx_cal_tab" name="day_tab" data-tab="day" style="right:204px;"></div><div class="dhx_cal_tab" name="week_tab" data-tab="week" style="right:140px;"></div><div class="dhx_cal_tab" name="month_tab" data-tab="month" style="right:76px;"></div>';
  var s = document.createElement("DIV");
  return s.id = "dhxSchedObj_" + this._genStr(12), s.innerHTML = '<div id="' + s.id + '" class="dhx_cal_container" style="width:100%; height:100%;"><div class="dhx_cal_navline"><div class="dhx_cal_prev_button"></div><div class="dhx_cal_next_button"></div><div class="dhx_cal_today_button"></div><div class="dhx_cal_date"></div>' + t + '</div><div class="dhx_cal_header"></div><div class="dhx_cal_data"></div></div>', document.body.appendChild(s.firstChild), this.attachObject(s.id, !1, !0), this.vs[this.av].sched = n, this.vs[this.av].schedId = s.id, n.setSizes = n.updateView, n.destructor = function() {
  }, n.init(s.id, e, i), this.vs[this._viewRestore()].sched;
});
const ce = (e, i) => {
  i(!1, `The ${e} extension is not included in this version of dhtmlxScheduler.<br>
		You may need a <a href="https://docs.dhtmlx.com/scheduler/editions_comparison.html" target="_blank">Professional version of the component</a>.<br>
		Contact us at <a href="https://dhtmlx.com/docs/contact.shtml" target="_blank">https://dhtmlx.com/docs/contact.shtml</a> if you have any questions.`);
};
function da(e) {
  (function() {
    var i = [];
    function t() {
      return !!i.length;
    }
    function n(d) {
      setTimeout(function() {
        if (e.$destroyed)
          return !0;
        t() || function(r, l) {
          for (; r && r != l; )
            r = r.parentNode;
          return r == l;
        }(document.activeElement, e.$container) || e.focus();
      }, 1);
    }
    function s(d) {
      var r = (d = d || window.event).currentTarget;
      r == i[i.length - 1] && e.$keyboardNavigation.trapFocus(r, d);
    }
    if (e.attachEvent("onLightbox", function() {
      var d;
      d = e.getLightbox(), e.eventRemove(d, "keydown", s), e.event(d, "keydown", s), i.push(d);
    }), e.attachEvent("onAfterLightbox", function() {
      var d = i.pop();
      d && e.eventRemove(d, "keydown", s), n();
    }), e.attachEvent("onAfterQuickInfo", function() {
      n();
    }), !e._keyNavMessagePopup) {
      e._keyNavMessagePopup = !0;
      var a = null, o = null;
      const d = [];
      e.attachEvent("onMessagePopup", function(r) {
        for (a = document.activeElement, o = a; o && e._getClassName(o).indexOf("dhx_cal_data") < 0; )
          o = o.parentNode;
        o && (o = o.parentNode), e.eventRemove(r, "keydown", s), e.event(r, "keydown", s), d.push(r);
      }), e.attachEvent("onAfterMessagePopup", function() {
        var r = d.pop();
        r && e.eventRemove(r, "keydown", s), setTimeout(function() {
          if (e.$destroyed)
            return !0;
          for (var l = document.activeElement; l && e._getClassName(l).indexOf("dhx_cal_light") < 0; )
            l = l.parentNode;
          l || (a && a.parentNode ? a.focus() : o && o.parentNode && o.focus(), a = null, o = null);
        }, 1);
      });
    }
    e.$keyboardNavigation.isModal = t;
  })();
}
function _a(e) {
  e._temp_key_scope = function() {
    e.config.key_nav = !0, e.$keyboardNavigation._pasteDate = null, e.$keyboardNavigation._pasteSection = null;
    var i = null, t = {};
    function n(o) {
      o = o || window.event, t.x = o.clientX, t.y = o.clientY;
    }
    function s() {
      for (var o, d, r = document.elementFromPoint(t.x, t.y); r && r != e._obj; )
        r = r.parentNode;
      return o = r == e._obj, d = e.$keyboardNavigation.dispatcher.isEnabled(), o || d;
    }
    function a(o) {
      return e._lame_copy({}, o);
    }
    document.body ? e.event(document.body, "mousemove", n) : e.event(window, "load", function() {
      e.event(document.body, "mousemove", n);
    }), e.attachEvent("onMouseMove", function(o, d) {
      var r = e.getState();
      if (r.mode && r.min_date) {
        var l = e.getActionData(d);
        e.$keyboardNavigation._pasteDate = l.date, e.$keyboardNavigation._pasteSection = l.section;
      }
    }), e._make_pasted_event = function(o) {
      var d = e.$keyboardNavigation._pasteDate, r = e.$keyboardNavigation._pasteSection, l = o.end_date - o.start_date, _ = a(o);
      if (function(p) {
        delete p.rec_type, delete p.rec_pattern, delete p.event_pid, delete p.event_length;
      }(_), _.start_date = new Date(d), _.end_date = new Date(_.start_date.valueOf() + l), r) {
        var h = e._get_section_property();
        e.config.multisection && o[h] && e.isMultisectionEvent && e.isMultisectionEvent(o) ? _[h] = o[h] : _[h] = r;
      }
      return _;
    }, e._do_paste = function(o, d, r) {
      e.callEvent("onBeforeEventPasted", [o, d, r]) !== !1 && (e.addEvent(d), e.callEvent("onEventPasted", [o, d, r]));
    }, e._is_key_nav_active = function() {
      return !(!this._is_initialized() || this._is_lightbox_open() || !this.config.key_nav);
    }, e.event(document, "keydown", function(o) {
      (o.ctrlKey || o.metaKey) && o.keyCode == 86 && e._buffer_event && !e.$keyboardNavigation.dispatcher.isEnabled() && (e.$keyboardNavigation.dispatcher.isActive = s());
    }), e._key_nav_copy_paste = function(o) {
      if (!e._is_key_nav_active())
        return !0;
      if (o.keyCode == 37 || o.keyCode == 39) {
        o.cancelBubble = !0;
        var d = e.date.add(e._date, o.keyCode == 37 ? -1 : 1, e._mode);
        return e.setCurrentView(d), !0;
      }
      var r, l = (r = e.$keyboardNavigation.dispatcher.getActiveNode()) && r.eventId ? r.eventId : e._select_id;
      if ((o.ctrlKey || o.metaKey) && o.keyCode == 67)
        return l && (e._buffer_event = a(e.getEvent(l)), i = !0, e.callEvent("onEventCopied", [e.getEvent(l)])), !0;
      if ((o.ctrlKey || o.metaKey) && o.keyCode == 88 && l) {
        i = !1;
        var _ = e._buffer_event = a(e.getEvent(l));
        e.updateEvent(_.id), e.callEvent("onEventCut", [_]);
      }
      if ((o.ctrlKey || o.metaKey) && o.keyCode == 86 && s()) {
        if (_ = (_ = e._buffer_event ? e.getEvent(e._buffer_event.id) : e._buffer_event) || e._buffer_event) {
          var h = e._make_pasted_event(_);
          i ? (h.id = e.uid(), e._do_paste(i, h, _)) : e.callEvent("onBeforeEventChanged", [h, o, !1, _]) && (e._do_paste(i, h, _), i = !0);
        }
        return !0;
      }
    };
  }, e._temp_key_scope();
}
function la(e) {
  e.$keyboardNavigation.attachSchedulerHandlers = function() {
    var i, t = e.$keyboardNavigation.dispatcher, n = function(r) {
      if (e.config.key_nav)
        return t.keyDownHandler(r);
    }, s = function() {
      t.keepScrollPosition(function() {
        t.focusGlobalNode();
      });
    };
    e.attachEvent("onDataRender", function() {
      e.config.key_nav && t.isEnabled() && !e.getState().editor_id && (clearTimeout(i), i = setTimeout(function() {
        if (e.$destroyed)
          return !0;
        t.isEnabled() || t.enable(), a();
      }));
    });
    var a = function() {
      if (t.isEnabled()) {
        var r = t.getActiveNode();
        r && (r.isValid() || (r = r.fallback()), !r || r instanceof e.$keyboardNavigation.MinicalButton || r instanceof e.$keyboardNavigation.MinicalCell || t.keepScrollPosition(function() {
          r.focus(!0);
        }));
      }
    };
    function o(r) {
      if (!e.config.key_nav)
        return !0;
      const l = e.getView();
      let _ = !1;
      if (e.getState().mode === "month")
        _ = e.$keyboardNavigation.isChildOf(r.target || r.srcElement, e.$container.querySelector(".dhx_cal_month_table"));
      else if (l && l.layout === "timeline")
        _ = e.$keyboardNavigation.isChildOf(r.target || r.srcElement, e.$container.querySelector(".dhx_timeline_data_col"));
      else {
        const v = e.$container.querySelectorAll(".dhx_scale_holder");
        _ = Array.from(v).some((g) => g === r.target.parentNode);
      }
      var h, p = e.getActionData(r);
      e._locate_event(r.target || r.srcElement) ? h = new e.$keyboardNavigation.Event(e._locate_event(r.target || r.srcElement)) : _ && (h = new e.$keyboardNavigation.TimeSlot(), p.date && _ && (h = h.nextSlot(new e.$keyboardNavigation.TimeSlot(p.date, null, p.section)))), h && (t.isEnabled() ? p.date && _ && t.delay(function() {
        t.setActiveNode(h);
      }) : t.activeNode = h);
    }
    e.attachEvent("onSchedulerReady", function() {
      var r = e.$container;
      e.eventRemove(document, "keydown", n), e.eventRemove(r, "mousedown", o), e.eventRemove(r, "focus", s), e.config.key_nav ? (e.event(document, "keydown", n), e.event(r, "mousedown", o), e.event(r, "focus", s), r.setAttribute("tabindex", "0")) : r.removeAttribute("tabindex");
    });
    var d = e.updateEvent;
    e.updateEvent = function(r) {
      var l = d.apply(this, arguments);
      if (e.config.key_nav && t.isEnabled() && e.getState().select_id == r) {
        var _ = new e.$keyboardNavigation.Event(r);
        e.getState().lightbox_id || function(h) {
          if (e.config.key_nav && t.isEnabled()) {
            var p = h, v = new e.$keyboardNavigation.Event(p.eventId);
            if (!v.isValid()) {
              var g = v.start || p.start, c = v.end || p.end, f = v.section || p.section;
              (v = new e.$keyboardNavigation.TimeSlot(g, c, f)).isValid() || (v = new e.$keyboardNavigation.TimeSlot());
            }
            t.setActiveNode(v);
            var u = t.getActiveNode();
            u && u.getNode && document.activeElement != u.getNode() && t.focusNode(t.getActiveNode());
          }
        }(_);
      }
      return l;
    }, e.attachEvent("onEventDeleted", function(r) {
      return e.config.key_nav && t.isEnabled() && t.getActiveNode().eventId == r && t.setActiveNode(new e.$keyboardNavigation.TimeSlot()), !0;
    }), e.attachEvent("onClearAll", function() {
      if (!e.config.key_nav)
        return !0;
      t.isEnabled() && t.getActiveNode() instanceof e.$keyboardNavigation.Event && t.setActiveNode(new e.$keyboardNavigation.TimeSlot());
    });
  };
}
class ca {
  constructor(i) {
    this.map = null, this._markers = [], this.scheduler = i;
  }
  onEventClick(i) {
    if (this._markers && this._markers.length > 0) {
      for (let t = 0; t < this._markers.length; t++)
        if (i.id == this._markers[t].event.id) {
          let n = this.settings.zoom_after_resolve || this.settings.initial_zoom;
          i.lat && i.lng ? (this.map.setCenter({ lat: i.lat, lng: i.lng }), this.map.setZoom(n)) : (this.map.setCenter({ lat: this.settings.error_position.lat, lng: this.settings.error_position.lng }), this.map.setZoom(n)), google.maps.event.trigger(this._markers[t].marker, "click");
        }
    }
  }
  initialize(i, t) {
    this.settings = t;
    let n = this.scheduler, s = { center: { lat: t.initial_position.lat, lng: t.initial_position.lng }, zoom: t.initial_zoom, mapId: i.id, scrollwheel: !0, mapTypeId: t.type };
    if (this.map === null)
      this.map = new google.maps.Map(i, s);
    else {
      let a = this.map;
      i.appendChild(this.map.__gm.messageOverlay), i.appendChild(this.map.__gm.outerContainer), setTimeout(function() {
        a.setOptions({ container: i.id });
      }, 500);
    }
    google.maps.event.addListener(this.map, "dblclick", function(a) {
      const o = new google.maps.Geocoder();
      if (!n.config.readonly && n.config.dblclick_create) {
        let d = a.latLng;
        o.geocode({ latLng: d }, function(r, l) {
          l == google.maps.GeocoderStatus.OK ? (d = r[0].geometry.location, n.addEventNow({ lat: d.lat(), lng: d.lng(), event_location: r[0].formatted_address, start_date: n.getState().date, end_date: n.date.add(n.getState().date, n.config.time_step, "minute") })) : console.error("Geocode was not successful for the following reason: " + l);
        });
      }
    });
  }
  destroy(i) {
    for (google.maps.event.clearInstanceListeners(window), google.maps.event.clearInstanceListeners(document), google.maps.event.clearInstanceListeners(i); i.firstChild; )
      i.firstChild.remove();
    i.innerHTML = "";
  }
  async addEventMarker(i) {
    let t = { title: i.text, position: {}, map: {} };
    i.lat && i.lng ? t.position = { lat: i.lat, lng: i.lng } : t.position = { lat: this.settings.error_position.lat, lng: this.settings.error_position.lng };
    const { AdvancedMarkerElement: n } = await google.maps.importLibrary("marker");
    let s;
    this.scheduler.ext.mapView.createMarker ? (t.map = this.map, s = this.scheduler.ext.mapView.createMarker(t)) : (s = new n(t), s.map = this.map), s.setMap(this.map), i["!nativeeditor_status"] == "true_deleted" && s.setMap(null), google.maps.event.addListener(s, "click", () => {
      this.infoWindow && this.infoWindow.close(), this.infoWindow = new google.maps.InfoWindow({ maxWidth: this.settings.info_window_max_width }), this.infoWindow.setContent(this.scheduler.templates.map_info_content(i)), this.infoWindow.open({ anchor: s, map: this.map });
    });
    let a = { event: i, ...t, marker: s };
    this._markers.push(a);
  }
  removeEventMarker(i) {
    for (let t = 0; t < this._markers.length; t++)
      i == this._markers[t].event.id && (this._markers[t].marker.setVisible(!1), this._markers[t].marker.setMap(null), this._markers[t].marker.setPosition(null), this._markers[t].marker = null, this._markers.splice(t, 1), t--);
  }
  updateEventMarker(i) {
    for (let t = 0; t < this._markers.length; t++)
      if (this._markers[t].event.id == i.id) {
        this._markers[t].event = i, this._markers[t].position.lat = i.lat, this._markers[t].position.lng = i.lng, this._markers[t].text = i.text;
        let n = new google.maps.LatLng(i.lat, i.lng);
        this._markers[t].marker.setPosition(n);
      }
  }
  clearEventMarkers() {
    if (this._markers.length > 0) {
      for (let i = 0; i < this._markers.length; i++)
        this._markers[i].marker.setMap(null);
      this._markers = [];
    }
  }
  setView(i, t, n) {
    this.map.setCenter({ lat: i, lng: t }), this.map.setZoom(n);
  }
  async resolveAddress(i) {
    const t = new google.maps.Geocoder();
    return await new Promise((n) => {
      t.geocode({ address: i }, function(s, a) {
        a == google.maps.GeocoderStatus.OK ? n({ lat: s[0].geometry.location.lat(), lng: s[0].geometry.location.lng() }) : (console.error("Geocode was not successful for the following reason: " + a), n({}));
      });
    });
  }
}
class ha {
  constructor(i) {
    this.map = null, this._markers = [], this.scheduler = i;
  }
  onEventClick(i) {
    if (this._markers && this._markers.length > 0)
      for (let t = 0; t < this._markers.length; t++)
        i.id == this._markers[t].event.id && (this._markers[t].marker.openPopup(), this._markers[t].marker.closeTooltip(), i.lat && i.lng ? this.setView(i.lat, i.lng, this.settings.zoom_after_resolve || this.settings.initial_zoom) : this.setView(this.settings.error_position.lat, this.settings.error_position.lng, this.settings.zoom_after_resolve || this.settings.initial_zoom));
  }
  initialize(i, t) {
    let n = this.scheduler, s = document.createElement("div");
    s.className = "mapWrapper", s.id = "mapWrapper", s.style.width = i.style.width, s.style.height = i.style.height, i.appendChild(s);
    let a = L.map(s, { center: L.latLng(t.initial_position.lat, t.initial_position.lng), zoom: t.initial_zoom, keyboard: !1 });
    L.tileLayer("http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(a), a.on("dblclick", async function(o) {
      let d = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${o.latlng.lat}&lon=${o.latlng.lng}&format=json`, { method: "GET", headers: { "Accept-Language": "en" } }).then((r) => r.json());
      if (d.address) {
        let r = d.address.country;
        n.addEventNow({ lat: o.latlng.lat, lng: o.latlng.lng, event_location: r, start_date: n.getState().date, end_date: n.date.add(n.getState().date, n.config.time_step, "minute") });
      } else
        console.error("unable recieve a position of the event", d.error);
    }), this.map = a, this.settings = t;
  }
  destroy(i) {
    for (this.map.remove(); i.firstChild; )
      i.firstChild.remove();
    i.innerHTML = "";
  }
  addEventMarker(i) {
    const t = L.icon({ iconUrl: "https://unpkg.com/leaflet@1.0.3/dist/images/marker-icon.png", iconSize: [25, 41], shadowSize: [30, 65], iconAnchor: [12, 41], shadowAnchor: [7, 65] });
    let n = { minWidth: 180, maxWidth: this.settings.info_window_max_width };
    const s = L.popup(n).setContent(this.scheduler.templates.map_info_content(i)), a = L.tooltip().setContent(i.text);
    let o = [i.lat, i.lng];
    i.lat && i.lng || (o = [this.settings.error_position.lat, this.settings.error_position.lng]);
    const d = { event: i, marker: L.marker(o, { icon: t }).bindPopup(s).bindTooltip(a).addTo(this.map) };
    this._markers.push(d);
  }
  removeEventMarker(i) {
    for (let t = 0; t < this._markers.length; t++)
      i == this._markers[t].event.id && (this.map.removeLayer(this._markers[t].marker), this._markers.splice(t, 1), t--);
  }
  updateEventMarker(i) {
    for (let t = 0; t < this._markers.length; t++)
      this._markers[t].event.id == i.id && (this._markers[t].event = i, i.lat && i.lng ? this._markers[t].marker.setLatLng([i.lat, i.lng]) : this._markers[t].marker.setLatLng([this.settings.error_position.lat, this.settings.error_position.lng]));
  }
  clearEventMarkers() {
    if (this._markers) {
      for (let i = 0; i < this._markers.length; i++)
        this.map.removeLayer(this._markers[i].marker);
      this._markers = [];
    }
  }
  setView(i, t, n) {
    this.map.setView([i, t], n);
  }
  async resolveAddress(i) {
    let t = {}, n = await fetch(`https://nominatim.openstreetmap.org/search?q=${i}&format=json`, { method: "GET", headers: { "Accept-Language": "en" } }).then((s) => s.json());
    return n && n.length ? (t.lat = +n[0].lat, t.lng = +n[0].lon) : console.error(`Unable recieve a position of the event's location: ${i}`), t;
  }
}
class ua {
  constructor(i) {
    this.map = null, this._markers = [], this.scheduler = i;
  }
  onEventClick(i) {
    if (this._markers && this._markers.length > 0)
      for (let t = 0; t < this._markers.length; t++) {
        const n = this._markers[t].marker.getPopup();
        n.isOpen() && n.remove(), i.id == this._markers[t].event.id && (this._markers[t].marker.togglePopup(), i.lat && i.lng ? this.setView(i.lat, i.lng, this.settings.zoom_after_resolve || this.settings.initial_zoom) : this.setView(this.settings.error_position.lat, this.settings.error_position.lng, this.settings.zoom_after_resolve || this.settings.initial_zoom));
      }
  }
  initialize(i, t) {
    let n = this.scheduler;
    mapboxgl.accessToken = t.accessToken;
    const s = new mapboxgl.Map({ container: i, center: [t.initial_position.lng, t.initial_position.lat], zoom: t.initial_zoom + 1 });
    s.on("dblclick", async function(a) {
      let o = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${a.lngLat.lng},${a.lngLat.lat}.json?access_token=${t.accessToken}`).then((d) => d.json());
      if (o.features) {
        let d = o.features[0].place_name;
        n.addEventNow({ lat: a.lngLat.lat, lng: a.lngLat.lng, event_location: d, start_date: n.getState().date, end_date: n.date.add(n.getState().date, n.config.time_step, "minute") });
      } else
        console.error("unable recieve a position of the event");
    }), this.map = s, this.settings = t;
  }
  destroy(i) {
    for (this.map.remove(); i.firstChild; )
      i.firstChild.remove();
    i.innerHTML = "";
  }
  addEventMarker(i) {
    let t = [i.lng, i.lat];
    i.lat && i.lng || (t = [this.settings.error_position.lng, this.settings.error_position.lat]);
    const n = new mapboxgl.Popup({ offset: 25, focusAfterOpen: !1 }).setMaxWidth(`${this.settings.info_window_max_width}px`).setHTML(this.scheduler.templates.map_info_content(i)), s = { event: i, marker: new mapboxgl.Marker().setLngLat(t).setPopup(n).addTo(this.map) };
    this._markers.push(s);
  }
  removeEventMarker(i) {
    for (let t = 0; t < this._markers.length; t++)
      i == this._markers[t].event.id && (this._markers[t].marker.remove(), this._markers.splice(t, 1), t--);
  }
  updateEventMarker(i) {
    for (let t = 0; t < this._markers.length; t++)
      this._markers[t].event.id == i.id && (this._markers[t].event = i, i.lat && i.lng ? this._markers[t].marker.setLngLat([i.lng, i.lat]) : this._markers[t].marker.setLngLat([this.settings.error_position.lng, this.settings.error_position.lat]));
  }
  clearEventMarkers() {
    for (let i = 0; i < this._markers.length; i++)
      this._markers[i].marker.remove();
    this._markers = [];
  }
  setView(i, t, n) {
    this.map.setCenter([t, i]), this.map.setZoom(n);
  }
  async resolveAddress(i) {
    let t = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${i}.json?access_token=${this.settings.accessToken}`).then((s) => s.json()), n = {};
    return t && t.features.length ? (n.lng = t.features[0].center[0], n.lat = t.features[0].center[1]) : console.error(`Unable recieve a position of the event's location: ${i}`), n;
  }
}
var He = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"], Z = function() {
  function e(i, t) {
    if (t === 0)
      throw new Error("Can't create weekday with n == 0");
    this.weekday = i, this.n = t;
  }
  return e.fromStr = function(i) {
    return new e(He.indexOf(i));
  }, e.prototype.nth = function(i) {
    return this.n === i ? this : new e(this.weekday, i);
  }, e.prototype.equals = function(i) {
    return this.weekday === i.weekday && this.n === i.n;
  }, e.prototype.toString = function() {
    var i = He[this.weekday];
    return this.n && (i = (this.n > 0 ? "+" : "") + String(this.n) + i), i;
  }, e.prototype.getJsWeekday = function() {
    return this.weekday === 6 ? 0 : this.weekday + 1;
  }, e;
}(), J = function(e) {
  return e != null;
}, re = function(e) {
  return typeof e == "number";
}, Xe = function(e) {
  return typeof e == "string" && He.includes(e);
}, Q = Array.isArray, oe = function(e, i) {
  i === void 0 && (i = e), arguments.length === 1 && (i = e, e = 0);
  for (var t = [], n = e; n < i; n++)
    t.push(n);
  return t;
}, Y = function(e, i) {
  var t = 0, n = [];
  if (Q(e))
    for (; t < i; t++)
      n[t] = [].concat(e);
  else
    for (; t < i; t++)
      n[t] = e;
  return n;
}, fa = function(e) {
  return Q(e) ? e : [e];
};
function ye(e, i, t) {
  t === void 0 && (t = " ");
  var n = String(e);
  return i |= 0, n.length > i ? String(n) : ((i -= n.length) > t.length && (t += Y(t, i / t.length)), t.slice(0, i) + String(n));
}
var te = function(e, i) {
  var t = e % i;
  return t * i < 0 ? t + i : t;
}, Ce = function(e, i) {
  return { div: Math.floor(e / i), mod: te(e, i) };
}, ie = function(e) {
  return !J(e) || e.length === 0;
}, K = function(e) {
  return !ie(e);
}, F = function(e, i) {
  return K(e) && e.indexOf(i) !== -1;
}, me = function(e, i, t, n, s, a) {
  return n === void 0 && (n = 0), s === void 0 && (s = 0), a === void 0 && (a = 0), new Date(Date.UTC(e, i - 1, t, n, s, a));
}, pa = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], bt = 864e5, xt = me(1970, 1, 1), ga = [6, 0, 1, 2, 3, 4, 5], ke = function(e) {
  return e % 4 == 0 && e % 100 != 0 || e % 400 == 0;
}, wt = function(e) {
  return e instanceof Date;
}, Ee = function(e) {
  return wt(e) && !isNaN(e.getTime());
}, ze = function(e) {
  return i = xt, t = e.getTime() - i.getTime(), Math.round(t / bt);
  var i, t;
}, kt = function(e) {
  return new Date(xt.getTime() + e * bt);
}, ma = function(e) {
  var i = e.getUTCMonth();
  return i === 1 && ke(e.getUTCFullYear()) ? 29 : pa[i];
}, we = function(e) {
  return ga[e.getUTCDay()];
}, Ze = function(e, i) {
  var t = me(e, i + 1, 1);
  return [we(t), ma(t)];
}, Et = function(e, i) {
  return i = i || e, new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), i.getHours(), i.getMinutes(), i.getSeconds(), i.getMilliseconds()));
}, qe = function(e) {
  return new Date(e.getTime());
}, Qe = function(e) {
  for (var i = [], t = 0; t < e.length; t++)
    i.push(qe(e[t]));
  return i;
}, De = function(e) {
  e.sort(function(i, t) {
    return i.getTime() - t.getTime();
  });
}, Ve = function(e, i) {
  i === void 0 && (i = !0);
  var t = new Date(e);
  return [ye(t.getUTCFullYear().toString(), 4, "0"), ye(t.getUTCMonth() + 1, 2, "0"), ye(t.getUTCDate(), 2, "0"), "T", ye(t.getUTCHours(), 2, "0"), ye(t.getUTCMinutes(), 2, "0"), ye(t.getUTCSeconds(), 2, "0"), i ? "Z" : ""].join("");
}, Fe = function(e) {
  var i = /^(\d{4})(\d{2})(\d{2})(T(\d{2})(\d{2})(\d{2})Z?)?$/.exec(e);
  if (!i)
    throw new Error("Invalid UNTIL value: ".concat(e));
  return new Date(Date.UTC(parseInt(i[1], 10), parseInt(i[2], 10) - 1, parseInt(i[3], 10), parseInt(i[5], 10) || 0, parseInt(i[6], 10) || 0, parseInt(i[7], 10) || 0));
}, et = function(e, i) {
  return e.toLocaleString("sv-SE", { timeZone: i }).replace(" ", "T") + "Z";
}, xe = function() {
  function e(i, t) {
    this.minDate = null, this.maxDate = null, this._result = [], this.total = 0, this.method = i, this.args = t, i === "between" ? (this.maxDate = t.inc ? t.before : new Date(t.before.getTime() - 1), this.minDate = t.inc ? t.after : new Date(t.after.getTime() + 1)) : i === "before" ? this.maxDate = t.inc ? t.dt : new Date(t.dt.getTime() - 1) : i === "after" && (this.minDate = t.inc ? t.dt : new Date(t.dt.getTime() + 1));
  }
  return e.prototype.accept = function(i) {
    ++this.total;
    var t = this.minDate && i < this.minDate, n = this.maxDate && i > this.maxDate;
    if (this.method === "between") {
      if (t)
        return !0;
      if (n)
        return !1;
    } else if (this.method === "before") {
      if (n)
        return !1;
    } else if (this.method === "after")
      return !!t || (this.add(i), !1);
    return this.add(i);
  }, e.prototype.add = function(i) {
    return this._result.push(i), !0;
  }, e.prototype.getValue = function() {
    var i = this._result;
    switch (this.method) {
      case "all":
      case "between":
        return i;
      default:
        return i.length ? i[i.length - 1] : null;
    }
  }, e.prototype.clone = function() {
    return new e(this.method, this.args);
  }, e;
}(), je = function(e, i) {
  return je = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(t, n) {
    t.__proto__ = n;
  } || function(t, n) {
    for (var s in n)
      Object.prototype.hasOwnProperty.call(n, s) && (t[s] = n[s]);
  }, je(e, i);
};
function Be(e, i) {
  if (typeof i != "function" && i !== null)
    throw new TypeError("Class extends value " + String(i) + " is not a constructor or null");
  function t() {
    this.constructor = e;
  }
  je(e, i), e.prototype = i === null ? Object.create(i) : (t.prototype = i.prototype, new t());
}
var ee = function() {
  return ee = Object.assign || function(e) {
    for (var i, t = 1, n = arguments.length; t < n; t++)
      for (var s in i = arguments[t])
        Object.prototype.hasOwnProperty.call(i, s) && (e[s] = i[s]);
    return e;
  }, ee.apply(this, arguments);
};
function q(e, i, t) {
  if (t || arguments.length === 2)
    for (var n, s = 0, a = i.length; s < a; s++)
      !n && s in i || (n || (n = Array.prototype.slice.call(i, 0, s)), n[s] = i[s]);
  return e.concat(n || Array.prototype.slice.call(i));
}
var V, tt = function(e) {
  function i(t, n, s) {
    var a = e.call(this, t, n) || this;
    return a.iterator = s, a;
  }
  return Be(i, e), i.prototype.add = function(t) {
    return !!this.iterator(t, this._result.length) && (this._result.push(t), !0);
  }, i;
}(xe), Se = { dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], tokens: { SKIP: /^[ \r\n\t]+|^\.$/, number: /^[1-9][0-9]*/, numberAsText: /^(one|two|three)/i, every: /^every/i, "day(s)": /^days?/i, "weekday(s)": /^weekdays?/i, "week(s)": /^weeks?/i, "hour(s)": /^hours?/i, "minute(s)": /^minutes?/i, "month(s)": /^months?/i, "year(s)": /^years?/i, on: /^(on|in)/i, at: /^(at)/i, the: /^the/i, first: /^first/i, second: /^second/i, third: /^third/i, nth: /^([1-9][0-9]*)(\.|th|nd|rd|st)/i, last: /^last/i, for: /^for/i, "time(s)": /^times?/i, until: /^(un)?til/i, monday: /^mo(n(day)?)?/i, tuesday: /^tu(e(s(day)?)?)?/i, wednesday: /^we(d(n(esday)?)?)?/i, thursday: /^th(u(r(sday)?)?)?/i, friday: /^fr(i(day)?)?/i, saturday: /^sa(t(urday)?)?/i, sunday: /^su(n(day)?)?/i, january: /^jan(uary)?/i, february: /^feb(ruary)?/i, march: /^mar(ch)?/i, april: /^apr(il)?/i, may: /^may/i, june: /^june?/i, july: /^july?/i, august: /^aug(ust)?/i, september: /^sep(t(ember)?)?/i, october: /^oct(ober)?/i, november: /^nov(ember)?/i, december: /^dec(ember)?/i, comma: /^(,\s*|(and|or)\s*)+/i } }, at = function(e, i) {
  return e.indexOf(i) !== -1;
}, va = function(e) {
  return e.toString();
}, ya = function(e, i, t) {
  return "".concat(i, " ").concat(t, ", ").concat(e);
}, _e = function() {
  function e(i, t, n, s) {
    if (t === void 0 && (t = va), n === void 0 && (n = Se), s === void 0 && (s = ya), this.text = [], this.language = n || Se, this.gettext = t, this.dateFormatter = s, this.rrule = i, this.options = i.options, this.origOptions = i.origOptions, this.origOptions.bymonthday) {
      var a = [].concat(this.options.bymonthday), o = [].concat(this.options.bynmonthday);
      a.sort(function(_, h) {
        return _ - h;
      }), o.sort(function(_, h) {
        return h - _;
      }), this.bymonthday = a.concat(o), this.bymonthday.length || (this.bymonthday = null);
    }
    if (J(this.origOptions.byweekday)) {
      var d = Q(this.origOptions.byweekday) ? this.origOptions.byweekday : [this.origOptions.byweekday], r = String(d);
      this.byweekday = { allWeeks: d.filter(function(_) {
        return !_.n;
      }), someWeeks: d.filter(function(_) {
        return !!_.n;
      }), isWeekdays: r.indexOf("MO") !== -1 && r.indexOf("TU") !== -1 && r.indexOf("WE") !== -1 && r.indexOf("TH") !== -1 && r.indexOf("FR") !== -1 && r.indexOf("SA") === -1 && r.indexOf("SU") === -1, isEveryDay: r.indexOf("MO") !== -1 && r.indexOf("TU") !== -1 && r.indexOf("WE") !== -1 && r.indexOf("TH") !== -1 && r.indexOf("FR") !== -1 && r.indexOf("SA") !== -1 && r.indexOf("SU") !== -1 };
      var l = function(_, h) {
        return _.weekday - h.weekday;
      };
      this.byweekday.allWeeks.sort(l), this.byweekday.someWeeks.sort(l), this.byweekday.allWeeks.length || (this.byweekday.allWeeks = null), this.byweekday.someWeeks.length || (this.byweekday.someWeeks = null);
    } else
      this.byweekday = null;
  }
  return e.isFullyConvertible = function(i) {
    if (!(i.options.freq in e.IMPLEMENTED) || i.origOptions.until && i.origOptions.count)
      return !1;
    for (var t in i.origOptions) {
      if (at(["dtstart", "tzid", "wkst", "freq"], t))
        return !0;
      if (!at(e.IMPLEMENTED[i.options.freq], t))
        return !1;
    }
    return !0;
  }, e.prototype.isFullyConvertible = function() {
    return e.isFullyConvertible(this.rrule);
  }, e.prototype.toString = function() {
    var i = this.gettext;
    if (!(this.options.freq in e.IMPLEMENTED))
      return i("RRule error: Unable to fully convert this rrule to text");
    if (this.text = [i("every")], this[z.FREQUENCIES[this.options.freq]](), this.options.until) {
      this.add(i("until"));
      var t = this.options.until;
      this.add(this.dateFormatter(t.getUTCFullYear(), this.language.monthNames[t.getUTCMonth()], t.getUTCDate()));
    } else
      this.options.count && this.add(i("for")).add(this.options.count.toString()).add(this.plural(this.options.count) ? i("times") : i("time"));
    return this.isFullyConvertible() || this.add(i("(~ approximate)")), this.text.join("");
  }, e.prototype.HOURLY = function() {
    var i = this.gettext;
    this.options.interval !== 1 && this.add(this.options.interval.toString()), this.add(this.plural(this.options.interval) ? i("hours") : i("hour"));
  }, e.prototype.MINUTELY = function() {
    var i = this.gettext;
    this.options.interval !== 1 && this.add(this.options.interval.toString()), this.add(this.plural(this.options.interval) ? i("minutes") : i("minute"));
  }, e.prototype.DAILY = function() {
    var i = this.gettext;
    this.options.interval !== 1 && this.add(this.options.interval.toString()), this.byweekday && this.byweekday.isWeekdays ? this.add(this.plural(this.options.interval) ? i("weekdays") : i("weekday")) : this.add(this.plural(this.options.interval) ? i("days") : i("day")), this.origOptions.bymonth && (this.add(i("in")), this._bymonth()), this.bymonthday ? this._bymonthday() : this.byweekday ? this._byweekday() : this.origOptions.byhour && this._byhour();
  }, e.prototype.WEEKLY = function() {
    var i = this.gettext;
    this.options.interval !== 1 && this.add(this.options.interval.toString()).add(this.plural(this.options.interval) ? i("weeks") : i("week")), this.byweekday && this.byweekday.isWeekdays ? this.options.interval === 1 ? this.add(this.plural(this.options.interval) ? i("weekdays") : i("weekday")) : this.add(i("on")).add(i("weekdays")) : this.byweekday && this.byweekday.isEveryDay ? this.add(this.plural(this.options.interval) ? i("days") : i("day")) : (this.options.interval === 1 && this.add(i("week")), this.origOptions.bymonth && (this.add(i("in")), this._bymonth()), this.bymonthday ? this._bymonthday() : this.byweekday && this._byweekday(), this.origOptions.byhour && this._byhour());
  }, e.prototype.MONTHLY = function() {
    var i = this.gettext;
    this.origOptions.bymonth ? (this.options.interval !== 1 && (this.add(this.options.interval.toString()).add(i("months")), this.plural(this.options.interval) && this.add(i("in"))), this._bymonth()) : (this.options.interval !== 1 && this.add(this.options.interval.toString()), this.add(this.plural(this.options.interval) ? i("months") : i("month"))), this.bymonthday ? this._bymonthday() : this.byweekday && this.byweekday.isWeekdays ? this.add(i("on")).add(i("weekdays")) : this.byweekday && this._byweekday();
  }, e.prototype.YEARLY = function() {
    var i = this.gettext;
    this.origOptions.bymonth ? (this.options.interval !== 1 && (this.add(this.options.interval.toString()), this.add(i("years"))), this._bymonth()) : (this.options.interval !== 1 && this.add(this.options.interval.toString()), this.add(this.plural(this.options.interval) ? i("years") : i("year"))), this.bymonthday ? this._bymonthday() : this.byweekday && this._byweekday(), this.options.byyearday && this.add(i("on the")).add(this.list(this.options.byyearday, this.nth, i("and"))).add(i("day")), this.options.byweekno && this.add(i("in")).add(this.plural(this.options.byweekno.length) ? i("weeks") : i("week")).add(this.list(this.options.byweekno, void 0, i("and")));
  }, e.prototype._bymonthday = function() {
    var i = this.gettext;
    this.byweekday && this.byweekday.allWeeks ? this.add(i("on")).add(this.list(this.byweekday.allWeeks, this.weekdaytext, i("or"))).add(i("the")).add(this.list(this.bymonthday, this.nth, i("or"))) : this.add(i("on the")).add(this.list(this.bymonthday, this.nth, i("and")));
  }, e.prototype._byweekday = function() {
    var i = this.gettext;
    this.byweekday.allWeeks && !this.byweekday.isWeekdays && this.add(i("on")).add(this.list(this.byweekday.allWeeks, this.weekdaytext)), this.byweekday.someWeeks && (this.byweekday.allWeeks && this.add(i("and")), this.add(i("on the")).add(this.list(this.byweekday.someWeeks, this.weekdaytext, i("and"))));
  }, e.prototype._byhour = function() {
    var i = this.gettext;
    this.add(i("at")).add(this.list(this.origOptions.byhour, void 0, i("and")));
  }, e.prototype._bymonth = function() {
    this.add(this.list(this.options.bymonth, this.monthtext, this.gettext("and")));
  }, e.prototype.nth = function(i) {
    var t;
    i = parseInt(i.toString(), 10);
    var n = this.gettext;
    if (i === -1)
      return n("last");
    var s = Math.abs(i);
    switch (s) {
      case 1:
      case 21:
      case 31:
        t = s + n("st");
        break;
      case 2:
      case 22:
        t = s + n("nd");
        break;
      case 3:
      case 23:
        t = s + n("rd");
        break;
      default:
        t = s + n("th");
    }
    return i < 0 ? t + " " + n("last") : t;
  }, e.prototype.monthtext = function(i) {
    return this.language.monthNames[i - 1];
  }, e.prototype.weekdaytext = function(i) {
    var t = re(i) ? (i + 1) % 7 : i.getJsWeekday();
    return (i.n ? this.nth(i.n) + " " : "") + this.language.dayNames[t];
  }, e.prototype.plural = function(i) {
    return i % 100 != 1;
  }, e.prototype.add = function(i) {
    return this.text.push(" "), this.text.push(i), this;
  }, e.prototype.list = function(i, t, n, s) {
    var a = this;
    s === void 0 && (s = ","), Q(i) || (i = [i]), t = t || function(d) {
      return d.toString();
    };
    var o = function(d) {
      return t && t.call(a, d);
    };
    return n ? function(d, r, l) {
      for (var _ = "", h = 0; h < d.length; h++)
        h !== 0 && (h === d.length - 1 ? _ += " " + l + " " : _ += r + " "), _ += d[h];
      return _;
    }(i.map(o), s, n) : i.map(o).join(s + " ");
  }, e;
}(), ba = function() {
  function e(i) {
    this.done = !0, this.rules = i;
  }
  return e.prototype.start = function(i) {
    return this.text = i, this.done = !1, this.nextSymbol();
  }, e.prototype.isDone = function() {
    return this.done && this.symbol === null;
  }, e.prototype.nextSymbol = function() {
    var i, t;
    this.symbol = null, this.value = null;
    do {
      if (this.done)
        return !1;
      for (var n in i = null, this.rules) {
        var s = this.rules[n].exec(this.text);
        s && (i === null || s[0].length > i[0].length) && (i = s, t = n);
      }
      if (i != null && (this.text = this.text.substr(i[0].length), this.text === "" && (this.done = !0)), i == null)
        return this.done = !0, this.symbol = null, void (this.value = null);
    } while (t === "SKIP");
    return this.symbol = t, this.value = i, !0;
  }, e.prototype.accept = function(i) {
    if (this.symbol === i) {
      if (this.value) {
        var t = this.value;
        return this.nextSymbol(), t;
      }
      return this.nextSymbol(), !0;
    }
    return !1;
  }, e.prototype.acceptNumber = function() {
    return this.accept("number");
  }, e.prototype.expect = function(i) {
    if (this.accept(i))
      return !0;
    throw new Error("expected " + i + " but found " + this.symbol);
  }, e;
}();
function Dt(e, i) {
  i === void 0 && (i = Se);
  var t = {}, n = new ba(i.tokens);
  return n.start(e) ? (function() {
    n.expect("every");
    var _ = n.acceptNumber();
    if (_ && (t.interval = parseInt(_[0], 10)), n.isDone())
      throw new Error("Unexpected end");
    switch (n.symbol) {
      case "day(s)":
        t.freq = z.DAILY, n.nextSymbol() && (a(), l());
        break;
      case "weekday(s)":
        t.freq = z.WEEKLY, t.byweekday = [z.MO, z.TU, z.WE, z.TH, z.FR], n.nextSymbol(), a(), l();
        break;
      case "week(s)":
        t.freq = z.WEEKLY, n.nextSymbol() && (s(), a(), l());
        break;
      case "hour(s)":
        t.freq = z.HOURLY, n.nextSymbol() && (s(), l());
        break;
      case "minute(s)":
        t.freq = z.MINUTELY, n.nextSymbol() && (s(), l());
        break;
      case "month(s)":
        t.freq = z.MONTHLY, n.nextSymbol() && (s(), l());
        break;
      case "year(s)":
        t.freq = z.YEARLY, n.nextSymbol() && (s(), l());
        break;
      case "monday":
      case "tuesday":
      case "wednesday":
      case "thursday":
      case "friday":
      case "saturday":
      case "sunday":
        t.freq = z.WEEKLY;
        var h = n.symbol.substr(0, 2).toUpperCase();
        if (t.byweekday = [z[h]], !n.nextSymbol())
          return;
        for (; n.accept("comma"); ) {
          if (n.isDone())
            throw new Error("Unexpected end");
          var p = d();
          if (!p)
            throw new Error("Unexpected symbol " + n.symbol + ", expected weekday");
          t.byweekday.push(z[p]), n.nextSymbol();
        }
        a(), function() {
          n.accept("on"), n.accept("the");
          var g = r();
          if (g)
            for (t.bymonthday = [g], n.nextSymbol(); n.accept("comma"); ) {
              if (!(g = r()))
                throw new Error("Unexpected symbol " + n.symbol + "; expected monthday");
              t.bymonthday.push(g), n.nextSymbol();
            }
        }(), l();
        break;
      case "january":
      case "february":
      case "march":
      case "april":
      case "may":
      case "june":
      case "july":
      case "august":
      case "september":
      case "october":
      case "november":
      case "december":
        if (t.freq = z.YEARLY, t.bymonth = [o()], !n.nextSymbol())
          return;
        for (; n.accept("comma"); ) {
          if (n.isDone())
            throw new Error("Unexpected end");
          var v = o();
          if (!v)
            throw new Error("Unexpected symbol " + n.symbol + ", expected month");
          t.bymonth.push(v), n.nextSymbol();
        }
        s(), l();
        break;
      default:
        throw new Error("Unknown symbol");
    }
  }(), t) : null;
  function s() {
    var _ = n.accept("on"), h = n.accept("the");
    if (_ || h)
      do {
        var p = r(), v = d(), g = o();
        if (p)
          v ? (n.nextSymbol(), t.byweekday || (t.byweekday = []), t.byweekday.push(z[v].nth(p))) : (t.bymonthday || (t.bymonthday = []), t.bymonthday.push(p), n.accept("day(s)"));
        else if (v)
          n.nextSymbol(), t.byweekday || (t.byweekday = []), t.byweekday.push(z[v]);
        else if (n.symbol === "weekday(s)")
          n.nextSymbol(), t.byweekday || (t.byweekday = [z.MO, z.TU, z.WE, z.TH, z.FR]);
        else if (n.symbol === "week(s)") {
          n.nextSymbol();
          var c = n.acceptNumber();
          if (!c)
            throw new Error("Unexpected symbol " + n.symbol + ", expected week number");
          for (t.byweekno = [parseInt(c[0], 10)]; n.accept("comma"); ) {
            if (!(c = n.acceptNumber()))
              throw new Error("Unexpected symbol " + n.symbol + "; expected monthday");
            t.byweekno.push(parseInt(c[0], 10));
          }
        } else {
          if (!g)
            return;
          n.nextSymbol(), t.bymonth || (t.bymonth = []), t.bymonth.push(g);
        }
      } while (n.accept("comma") || n.accept("the") || n.accept("on"));
  }
  function a() {
    if (n.accept("at"))
      do {
        var _ = n.acceptNumber();
        if (!_)
          throw new Error("Unexpected symbol " + n.symbol + ", expected hour");
        for (t.byhour = [parseInt(_[0], 10)]; n.accept("comma"); ) {
          if (!(_ = n.acceptNumber()))
            throw new Error("Unexpected symbol " + n.symbol + "; expected hour");
          t.byhour.push(parseInt(_[0], 10));
        }
      } while (n.accept("comma") || n.accept("at"));
  }
  function o() {
    switch (n.symbol) {
      case "january":
        return 1;
      case "february":
        return 2;
      case "march":
        return 3;
      case "april":
        return 4;
      case "may":
        return 5;
      case "june":
        return 6;
      case "july":
        return 7;
      case "august":
        return 8;
      case "september":
        return 9;
      case "october":
        return 10;
      case "november":
        return 11;
      case "december":
        return 12;
      default:
        return !1;
    }
  }
  function d() {
    switch (n.symbol) {
      case "monday":
      case "tuesday":
      case "wednesday":
      case "thursday":
      case "friday":
      case "saturday":
      case "sunday":
        return n.symbol.substr(0, 2).toUpperCase();
      default:
        return !1;
    }
  }
  function r() {
    switch (n.symbol) {
      case "last":
        return n.nextSymbol(), -1;
      case "first":
        return n.nextSymbol(), 1;
      case "second":
        return n.nextSymbol(), n.accept("last") ? -2 : 2;
      case "third":
        return n.nextSymbol(), n.accept("last") ? -3 : 3;
      case "nth":
        var _ = parseInt(n.value[1], 10);
        if (_ < -366 || _ > 366)
          throw new Error("Nth out of range: " + _);
        return n.nextSymbol(), n.accept("last") ? -_ : _;
      default:
        return !1;
    }
  }
  function l() {
    if (n.symbol === "until") {
      var _ = Date.parse(n.text);
      if (!_)
        throw new Error("Cannot parse until date:" + n.text);
      t.until = new Date(_);
    } else
      n.accept("for") && (t.count = parseInt(n.value[0], 10), n.expect("number"));
  }
}
function Oe(e) {
  return e < V.HOURLY;
}
(function(e) {
  e[e.YEARLY = 0] = "YEARLY", e[e.MONTHLY = 1] = "MONTHLY", e[e.WEEKLY = 2] = "WEEKLY", e[e.DAILY = 3] = "DAILY", e[e.HOURLY = 4] = "HOURLY", e[e.MINUTELY = 5] = "MINUTELY", e[e.SECONDLY = 6] = "SECONDLY";
})(V || (V = {}));
var xa = function(e, i) {
  return i === void 0 && (i = Se), new z(Dt(e, i) || void 0);
}, be = ["count", "until", "interval", "byweekday", "bymonthday", "bymonth"];
_e.IMPLEMENTED = [], _e.IMPLEMENTED[V.HOURLY] = be, _e.IMPLEMENTED[V.MINUTELY] = be, _e.IMPLEMENTED[V.DAILY] = ["byhour"].concat(be), _e.IMPLEMENTED[V.WEEKLY] = be, _e.IMPLEMENTED[V.MONTHLY] = be, _e.IMPLEMENTED[V.YEARLY] = ["byweekno", "byyearday"].concat(be);
var wa = _e.isFullyConvertible, Me = function() {
  function e(i, t, n, s) {
    this.hour = i, this.minute = t, this.second = n, this.millisecond = s || 0;
  }
  return e.prototype.getHours = function() {
    return this.hour;
  }, e.prototype.getMinutes = function() {
    return this.minute;
  }, e.prototype.getSeconds = function() {
    return this.second;
  }, e.prototype.getMilliseconds = function() {
    return this.millisecond;
  }, e.prototype.getTime = function() {
    return 1e3 * (60 * this.hour * 60 + 60 * this.minute + this.second) + this.millisecond;
  }, e;
}(), ka = function(e) {
  function i(t, n, s, a, o, d, r) {
    var l = e.call(this, a, o, d, r) || this;
    return l.year = t, l.month = n, l.day = s, l;
  }
  return Be(i, e), i.fromDate = function(t) {
    return new this(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate(), t.getUTCHours(), t.getUTCMinutes(), t.getUTCSeconds(), t.valueOf() % 1e3);
  }, i.prototype.getWeekday = function() {
    return we(new Date(this.getTime()));
  }, i.prototype.getTime = function() {
    return new Date(Date.UTC(this.year, this.month - 1, this.day, this.hour, this.minute, this.second, this.millisecond)).getTime();
  }, i.prototype.getDay = function() {
    return this.day;
  }, i.prototype.getMonth = function() {
    return this.month;
  }, i.prototype.getYear = function() {
    return this.year;
  }, i.prototype.addYears = function(t) {
    this.year += t;
  }, i.prototype.addMonths = function(t) {
    if (this.month += t, this.month > 12) {
      var n = Math.floor(this.month / 12), s = te(this.month, 12);
      this.month = s, this.year += n, this.month === 0 && (this.month = 12, --this.year);
    }
  }, i.prototype.addWeekly = function(t, n) {
    n > this.getWeekday() ? this.day += -(this.getWeekday() + 1 + (6 - n)) + 7 * t : this.day += -(this.getWeekday() - n) + 7 * t, this.fixDay();
  }, i.prototype.addDaily = function(t) {
    this.day += t, this.fixDay();
  }, i.prototype.addHours = function(t, n, s) {
    for (n && (this.hour += Math.floor((23 - this.hour) / t) * t); ; ) {
      this.hour += t;
      var a = Ce(this.hour, 24), o = a.div, d = a.mod;
      if (o && (this.hour = d, this.addDaily(o)), ie(s) || F(s, this.hour))
        break;
    }
  }, i.prototype.addMinutes = function(t, n, s, a) {
    for (n && (this.minute += Math.floor((1439 - (60 * this.hour + this.minute)) / t) * t); ; ) {
      this.minute += t;
      var o = Ce(this.minute, 60), d = o.div, r = o.mod;
      if (d && (this.minute = r, this.addHours(d, !1, s)), (ie(s) || F(s, this.hour)) && (ie(a) || F(a, this.minute)))
        break;
    }
  }, i.prototype.addSeconds = function(t, n, s, a, o) {
    for (n && (this.second += Math.floor((86399 - (3600 * this.hour + 60 * this.minute + this.second)) / t) * t); ; ) {
      this.second += t;
      var d = Ce(this.second, 60), r = d.div, l = d.mod;
      if (r && (this.second = l, this.addMinutes(r, !1, s, a)), (ie(s) || F(s, this.hour)) && (ie(a) || F(a, this.minute)) && (ie(o) || F(o, this.second)))
        break;
    }
  }, i.prototype.fixDay = function() {
    if (!(this.day <= 28)) {
      var t = Ze(this.year, this.month - 1)[1];
      if (!(this.day <= t))
        for (; this.day > t; ) {
          if (this.day -= t, ++this.month, this.month === 13 && (this.month = 1, ++this.year, this.year > 9999))
            return;
          t = Ze(this.year, this.month - 1)[1];
        }
    }
  }, i.prototype.add = function(t, n) {
    var s = t.freq, a = t.interval, o = t.wkst, d = t.byhour, r = t.byminute, l = t.bysecond;
    switch (s) {
      case V.YEARLY:
        return this.addYears(a);
      case V.MONTHLY:
        return this.addMonths(a);
      case V.WEEKLY:
        return this.addWeekly(a, o);
      case V.DAILY:
        return this.addDaily(a);
      case V.HOURLY:
        return this.addHours(a, n, d);
      case V.MINUTELY:
        return this.addMinutes(a, n, d, r);
      case V.SECONDLY:
        return this.addSeconds(a, n, d, r, l);
    }
  }, i;
}(Me);
function St(e) {
  for (var i = [], t = 0, n = Object.keys(e); t < n.length; t++) {
    var s = n[t];
    F(Ba, s) || i.push(s), wt(e[s]) && !Ee(e[s]) && i.push(s);
  }
  if (i.length)
    throw new Error("Invalid options: " + i.join(", "));
  return ee({}, e);
}
function Ea(e) {
  var i = ee(ee({}, Je), St(e));
  if (J(i.byeaster) && (i.freq = z.YEARLY), !J(i.freq) || !z.FREQUENCIES[i.freq])
    throw new Error("Invalid frequency: ".concat(i.freq, " ").concat(e.freq));
  if (i.dtstart || (i.dtstart = new Date((/* @__PURE__ */ new Date()).setMilliseconds(0))), J(i.wkst) ? re(i.wkst) || (i.wkst = i.wkst.weekday) : i.wkst = z.MO.weekday, J(i.bysetpos)) {
    re(i.bysetpos) && (i.bysetpos = [i.bysetpos]);
    for (var t = 0; t < i.bysetpos.length; t++)
      if ((a = i.bysetpos[t]) === 0 || !(a >= -366 && a <= 366))
        throw new Error("bysetpos must be between 1 and 366, or between -366 and -1");
  }
  if (!(i.byweekno || K(i.byweekno) || K(i.byyearday) || i.bymonthday || K(i.bymonthday) || J(i.byweekday) || J(i.byeaster)))
    switch (i.freq) {
      case z.YEARLY:
        i.bymonth || (i.bymonth = i.dtstart.getUTCMonth() + 1), i.bymonthday = i.dtstart.getUTCDate();
        break;
      case z.MONTHLY:
        i.bymonthday = i.dtstart.getUTCDate();
        break;
      case z.WEEKLY:
        i.byweekday = [we(i.dtstart)];
    }
  if (J(i.bymonth) && !Q(i.bymonth) && (i.bymonth = [i.bymonth]), J(i.byyearday) && !Q(i.byyearday) && re(i.byyearday) && (i.byyearday = [i.byyearday]), J(i.bymonthday))
    if (Q(i.bymonthday)) {
      var n = [], s = [];
      for (t = 0; t < i.bymonthday.length; t++) {
        var a;
        (a = i.bymonthday[t]) > 0 ? n.push(a) : a < 0 && s.push(a);
      }
      i.bymonthday = n, i.bynmonthday = s;
    } else
      i.bymonthday < 0 ? (i.bynmonthday = [i.bymonthday], i.bymonthday = []) : (i.bynmonthday = [], i.bymonthday = [i.bymonthday]);
  else
    i.bymonthday = [], i.bynmonthday = [];
  if (J(i.byweekno) && !Q(i.byweekno) && (i.byweekno = [i.byweekno]), J(i.byweekday))
    if (re(i.byweekday))
      i.byweekday = [i.byweekday], i.bynweekday = null;
    else if (Xe(i.byweekday))
      i.byweekday = [Z.fromStr(i.byweekday).weekday], i.bynweekday = null;
    else if (i.byweekday instanceof Z)
      !i.byweekday.n || i.freq > z.MONTHLY ? (i.byweekday = [i.byweekday.weekday], i.bynweekday = null) : (i.bynweekday = [[i.byweekday.weekday, i.byweekday.n]], i.byweekday = null);
    else {
      var o = [], d = [];
      for (t = 0; t < i.byweekday.length; t++) {
        var r = i.byweekday[t];
        re(r) ? o.push(r) : Xe(r) ? o.push(Z.fromStr(r).weekday) : !r.n || i.freq > z.MONTHLY ? o.push(r.weekday) : d.push([r.weekday, r.n]);
      }
      i.byweekday = K(o) ? o : null, i.bynweekday = K(d) ? d : null;
    }
  else
    i.bynweekday = null;
  return J(i.byhour) ? re(i.byhour) && (i.byhour = [i.byhour]) : i.byhour = i.freq < z.HOURLY ? [i.dtstart.getUTCHours()] : null, J(i.byminute) ? re(i.byminute) && (i.byminute = [i.byminute]) : i.byminute = i.freq < z.MINUTELY ? [i.dtstart.getUTCMinutes()] : null, J(i.bysecond) ? re(i.bysecond) && (i.bysecond = [i.bysecond]) : i.bysecond = i.freq < z.SECONDLY ? [i.dtstart.getUTCSeconds()] : null, { parsedOptions: i };
}
function Ie(e) {
  var i = e.split(`
`).map(Da).filter(function(t) {
    return t !== null;
  });
  return ee(ee({}, i[0]), i[1]);
}
function Ne(e) {
  var i = {}, t = /DTSTART(?:;TZID=([^:=]+?))?(?::|=)([^;\s]+)/i.exec(e);
  if (!t)
    return i;
  var n = t[1], s = t[2];
  return n && (i.tzid = n), i.dtstart = Fe(s), i;
}
function Da(e) {
  if (!(e = e.replace(/^\s+|\s+$/, "")).length)
    return null;
  var i = /^([A-Z]+?)[:;]/.exec(e.toUpperCase());
  if (!i)
    return nt(e);
  var t = i[1];
  switch (t.toUpperCase()) {
    case "RRULE":
    case "EXRULE":
      return nt(e);
    case "DTSTART":
      return Ne(e);
    default:
      throw new Error("Unsupported RFC prop ".concat(t, " in ").concat(e));
  }
}
function nt(e) {
  var i = Ne(e.replace(/^RRULE:/i, ""));
  return e.replace(/^(?:RRULE|EXRULE):/i, "").split(";").forEach(function(t) {
    var n = t.split("="), s = n[0], a = n[1];
    switch (s.toUpperCase()) {
      case "FREQ":
        i.freq = V[a.toUpperCase()];
        break;
      case "WKST":
        i.wkst = ae[a.toUpperCase()];
        break;
      case "COUNT":
      case "INTERVAL":
      case "BYSETPOS":
      case "BYMONTH":
      case "BYMONTHDAY":
      case "BYYEARDAY":
      case "BYWEEKNO":
      case "BYHOUR":
      case "BYMINUTE":
      case "BYSECOND":
        var o = function(l) {
          return l.indexOf(",") !== -1 ? l.split(",").map(rt) : rt(l);
        }(a), d = s.toLowerCase();
        i[d] = o;
        break;
      case "BYWEEKDAY":
      case "BYDAY":
        i.byweekday = function(l) {
          var _ = l.split(",");
          return _.map(function(h) {
            if (h.length === 2)
              return ae[h];
            var p = h.match(/^([+-]?\d{1,2})([A-Z]{2})$/);
            if (!p || p.length < 3)
              throw new SyntaxError("Invalid weekday string: ".concat(h));
            var v = Number(p[1]), g = p[2], c = ae[g].weekday;
            return new Z(c, v);
          });
        }(a);
        break;
      case "DTSTART":
      case "TZID":
        var r = Ne(e);
        i.tzid = r.tzid, i.dtstart = r.dtstart;
        break;
      case "UNTIL":
        i.until = Fe(a);
        break;
      case "BYEASTER":
        i.byeaster = Number(a);
        break;
      default:
        throw new Error("Unknown RRULE property '" + s + "'");
    }
  }), i;
}
function rt(e) {
  return /^[+-]?\d+$/.test(e) ? Number(e) : e;
}
var Te = function() {
  function e(i, t) {
    if (isNaN(i.getTime()))
      throw new RangeError("Invalid date passed to DateWithZone");
    this.date = i, this.tzid = t;
  }
  return Object.defineProperty(e.prototype, "isUTC", { get: function() {
    return !this.tzid || this.tzid.toUpperCase() === "UTC";
  }, enumerable: !1, configurable: !0 }), e.prototype.toString = function() {
    var i = Ve(this.date.getTime(), this.isUTC);
    return this.isUTC ? ":".concat(i) : ";TZID=".concat(this.tzid, ":").concat(i);
  }, e.prototype.getTime = function() {
    return this.date.getTime();
  }, e.prototype.rezonedDate = function() {
    return this.isUTC ? this.date : (i = this.date, t = this.tzid, n = Intl.DateTimeFormat().resolvedOptions().timeZone, s = new Date(et(i, n)), a = new Date(et(i, t ?? "UTC")).getTime() - s.getTime(), new Date(i.getTime() - a));
    var i, t, n, s, a;
  }, e;
}();
function Pe(e) {
  for (var i = [], t = "", n = Object.keys(e), s = Object.keys(Je), a = 0; a < n.length; a++)
    if (n[a] !== "tzid" && F(s, n[a])) {
      var o = n[a].toUpperCase(), d = e[n[a]], r = "";
      if (J(d) && (!Q(d) || d.length)) {
        switch (o) {
          case "FREQ":
            r = z.FREQUENCIES[e.freq];
            break;
          case "WKST":
            r = re(d) ? new Z(d).toString() : d.toString();
            break;
          case "BYWEEKDAY":
            o = "BYDAY", r = fa(d).map(function(v) {
              return v instanceof Z ? v : Q(v) ? new Z(v[0], v[1]) : new Z(v);
            }).toString();
            break;
          case "DTSTART":
            t = Sa(d, e.tzid);
            break;
          case "UNTIL":
            r = Ve(d, !e.tzid);
            break;
          default:
            if (Q(d)) {
              for (var l = [], _ = 0; _ < d.length; _++)
                l[_] = String(d[_]);
              r = l.toString();
            } else
              r = String(d);
        }
        r && i.push([o, r]);
      }
    }
  var h = i.map(function(v) {
    var g = v[0], c = v[1];
    return "".concat(g, "=").concat(c.toString());
  }).join(";"), p = "";
  return h !== "" && (p = "RRULE:".concat(h)), [t, p].filter(function(v) {
    return !!v;
  }).join(`
`);
}
function Sa(e, i) {
  return e ? "DTSTART" + new Te(new Date(e), i).toString() : "";
}
function Ma(e, i) {
  return Array.isArray(e) ? !!Array.isArray(i) && e.length === i.length && e.every(function(t, n) {
    return t.getTime() === i[n].getTime();
  }) : e instanceof Date ? i instanceof Date && e.getTime() === i.getTime() : e === i;
}
var Na = function() {
  function e() {
    this.all = !1, this.before = [], this.after = [], this.between = [];
  }
  return e.prototype._cacheAdd = function(i, t, n) {
    t && (t = t instanceof Date ? qe(t) : Qe(t)), i === "all" ? this.all = t : (n._value = t, this[i].push(n));
  }, e.prototype._cacheGet = function(i, t) {
    var n = !1, s = t ? Object.keys(t) : [], a = function(_) {
      for (var h = 0; h < s.length; h++) {
        var p = s[h];
        if (!Ma(t[p], _[p]))
          return !0;
      }
      return !1;
    }, o = this[i];
    if (i === "all")
      n = this.all;
    else if (Q(o))
      for (var d = 0; d < o.length; d++) {
        var r = o[d];
        if (!s.length || !a(r)) {
          n = r._value;
          break;
        }
      }
    if (!n && this.all) {
      var l = new xe(i, t);
      for (d = 0; d < this.all.length && l.accept(this.all[d]); d++)
        ;
      n = l.getValue(), this._cacheAdd(i, n, t);
    }
    return Q(n) ? Qe(n) : n instanceof Date ? qe(n) : n;
  }, e;
}(), Ta = q(q(q(q(q(q(q(q(q(q(q(q(q([], Y(1, 31), !0), Y(2, 28), !0), Y(3, 31), !0), Y(4, 30), !0), Y(5, 31), !0), Y(6, 30), !0), Y(7, 31), !0), Y(8, 31), !0), Y(9, 30), !0), Y(10, 31), !0), Y(11, 30), !0), Y(12, 31), !0), Y(1, 7), !0), Aa = q(q(q(q(q(q(q(q(q(q(q(q(q([], Y(1, 31), !0), Y(2, 29), !0), Y(3, 31), !0), Y(4, 30), !0), Y(5, 31), !0), Y(6, 30), !0), Y(7, 31), !0), Y(8, 31), !0), Y(9, 30), !0), Y(10, 31), !0), Y(11, 30), !0), Y(12, 31), !0), Y(1, 7), !0), Ca = oe(1, 29), Oa = oe(1, 30), ue = oe(1, 31), G = oe(1, 32), La = q(q(q(q(q(q(q(q(q(q(q(q(q([], G, !0), Oa, !0), G, !0), ue, !0), G, !0), ue, !0), G, !0), G, !0), ue, !0), G, !0), ue, !0), G, !0), G.slice(0, 7), !0), $a = q(q(q(q(q(q(q(q(q(q(q(q(q([], G, !0), Ca, !0), G, !0), ue, !0), G, !0), ue, !0), G, !0), G, !0), ue, !0), G, !0), ue, !0), G, !0), G.slice(0, 7), !0), Ha = oe(-28, 0), za = oe(-29, 0), fe = oe(-30, 0), X = oe(-31, 0), qa = q(q(q(q(q(q(q(q(q(q(q(q(q([], X, !0), za, !0), X, !0), fe, !0), X, !0), fe, !0), X, !0), X, !0), fe, !0), X, !0), fe, !0), X, !0), X.slice(0, 7), !0), ja = q(q(q(q(q(q(q(q(q(q(q(q(q([], X, !0), Ha, !0), X, !0), fe, !0), X, !0), fe, !0), X, !0), X, !0), fe, !0), X, !0), fe, !0), X, !0), X.slice(0, 7), !0), Ia = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366], Pa = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365], it = function() {
  for (var e = [], i = 0; i < 55; i++)
    e = e.concat(oe(7));
  return e;
}();
function Ra(e, i) {
  var t, n, s = me(e, 1, 1), a = ke(e) ? 366 : 365, o = ke(e + 1) ? 366 : 365, d = ze(s), r = we(s), l = ee(ee({ yearlen: a, nextyearlen: o, yearordinal: d, yearweekday: r }, function(N) {
    var m = ke(N) ? 366 : 365, x = me(N, 1, 1), b = we(x);
    return m === 365 ? { mmask: Ta, mdaymask: $a, nmdaymask: ja, wdaymask: it.slice(b), mrange: Pa } : { mmask: Aa, mdaymask: La, nmdaymask: qa, wdaymask: it.slice(b), mrange: Ia };
  }(e)), { wnomask: null });
  if (ie(i.byweekno))
    return l;
  l.wnomask = Y(0, a + 7);
  var _ = t = te(7 - r + i.wkst, 7);
  _ >= 4 ? (_ = 0, n = l.yearlen + te(r - i.wkst, 7)) : n = a - _;
  for (var h = Math.floor(n / 7), p = te(n, 7), v = Math.floor(h + p / 4), g = 0; g < i.byweekno.length; g++) {
    var c = i.byweekno[g];
    if (c < 0 && (c += v + 1), c > 0 && c <= v) {
      var f = void 0;
      c > 1 ? (f = _ + 7 * (c - 1), _ !== t && (f -= 7 - t)) : f = _;
      for (var u = 0; u < 7 && (l.wnomask[f] = 1, f++, l.wdaymask[f] !== i.wkst); u++)
        ;
    }
  }
  if (F(i.byweekno, 1) && (f = _ + 7 * v, _ !== t && (f -= 7 - t), f < a))
    for (g = 0; g < 7 && (l.wnomask[f] = 1, f += 1, l.wdaymask[f] !== i.wkst); g++)
      ;
  if (_) {
    var y = void 0;
    if (F(i.byweekno, -1))
      y = -1;
    else {
      var w = we(me(e - 1, 1, 1)), D = te(7 - w.valueOf() + i.wkst, 7), M = ke(e - 1) ? 366 : 365, k = void 0;
      D >= 4 ? (D = 0, k = M + te(w - i.wkst, 7)) : k = a - _, y = Math.floor(52 + te(k, 7) / 4);
    }
    if (F(i.byweekno, y))
      for (f = 0; f < _; f++)
        l.wnomask[f] = 1;
  }
  return l;
}
var Ua = function() {
  function e(i) {
    this.options = i;
  }
  return e.prototype.rebuild = function(i, t) {
    var n = this.options;
    if (i !== this.lastyear && (this.yearinfo = Ra(i, n)), K(n.bynweekday) && (t !== this.lastmonth || i !== this.lastyear)) {
      var s = this.yearinfo, a = s.yearlen, o = s.mrange, d = s.wdaymask;
      this.monthinfo = function(r, l, _, h, p, v) {
        var g = { lastyear: r, lastmonth: l, nwdaymask: [] }, c = [];
        if (v.freq === z.YEARLY)
          if (ie(v.bymonth))
            c = [[0, _]];
          else
            for (var f = 0; f < v.bymonth.length; f++)
              l = v.bymonth[f], c.push(h.slice(l - 1, l + 1));
        else
          v.freq === z.MONTHLY && (c = [h.slice(l - 1, l + 1)]);
        if (ie(c))
          return g;
        for (g.nwdaymask = Y(0, _), f = 0; f < c.length; f++)
          for (var u = c[f], y = u[0], w = u[1] - 1, D = 0; D < v.bynweekday.length; D++) {
            var M = void 0, k = v.bynweekday[D], N = k[0], m = k[1];
            m < 0 ? (M = w + 7 * (m + 1), M -= te(p[M] - N, 7)) : (M = y + 7 * (m - 1), M += te(7 - p[M] + N, 7)), y <= M && M <= w && (g.nwdaymask[M] = 1);
          }
        return g;
      }(i, t, a, o, d, n);
    }
    J(n.byeaster) && (this.eastermask = function(r, l) {
      l === void 0 && (l = 0);
      var _ = r % 19, h = Math.floor(r / 100), p = r % 100, v = Math.floor(h / 4), g = h % 4, c = Math.floor((h + 8) / 25), f = Math.floor((h - c + 1) / 3), u = Math.floor(19 * _ + h - v - f + 15) % 30, y = Math.floor(p / 4), w = p % 4, D = Math.floor(32 + 2 * g + 2 * y - u - w) % 7, M = Math.floor((_ + 11 * u + 22 * D) / 451), k = Math.floor((u + D - 7 * M + 114) / 31), N = (u + D - 7 * M + 114) % 31 + 1, m = Date.UTC(r, k - 1, N + l), x = Date.UTC(r, 0, 1);
      return [Math.ceil((m - x) / 864e5)];
    }(i, n.byeaster));
  }, Object.defineProperty(e.prototype, "lastyear", { get: function() {
    return this.monthinfo ? this.monthinfo.lastyear : null;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "lastmonth", { get: function() {
    return this.monthinfo ? this.monthinfo.lastmonth : null;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "yearlen", { get: function() {
    return this.yearinfo.yearlen;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "yearordinal", { get: function() {
    return this.yearinfo.yearordinal;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "mrange", { get: function() {
    return this.yearinfo.mrange;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "wdaymask", { get: function() {
    return this.yearinfo.wdaymask;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "mmask", { get: function() {
    return this.yearinfo.mmask;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "wnomask", { get: function() {
    return this.yearinfo.wnomask;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "nwdaymask", { get: function() {
    return this.monthinfo ? this.monthinfo.nwdaymask : [];
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "nextyearlen", { get: function() {
    return this.yearinfo.nextyearlen;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "mdaymask", { get: function() {
    return this.yearinfo.mdaymask;
  }, enumerable: !1, configurable: !0 }), Object.defineProperty(e.prototype, "nmdaymask", { get: function() {
    return this.yearinfo.nmdaymask;
  }, enumerable: !1, configurable: !0 }), e.prototype.ydayset = function() {
    return [oe(this.yearlen), 0, this.yearlen];
  }, e.prototype.mdayset = function(i, t) {
    for (var n = this.mrange[t - 1], s = this.mrange[t], a = Y(null, this.yearlen), o = n; o < s; o++)
      a[o] = o;
    return [a, n, s];
  }, e.prototype.wdayset = function(i, t, n) {
    for (var s = Y(null, this.yearlen + 7), a = ze(me(i, t, n)) - this.yearordinal, o = a, d = 0; d < 7 && (s[a] = a, ++a, this.wdaymask[a] !== this.options.wkst); d++)
      ;
    return [s, o, a];
  }, e.prototype.ddayset = function(i, t, n) {
    var s = Y(null, this.yearlen), a = ze(me(i, t, n)) - this.yearordinal;
    return s[a] = a, [s, a, a + 1];
  }, e.prototype.htimeset = function(i, t, n, s) {
    var a = this, o = [];
    return this.options.byminute.forEach(function(d) {
      o = o.concat(a.mtimeset(i, d, n, s));
    }), De(o), o;
  }, e.prototype.mtimeset = function(i, t, n, s) {
    var a = this.options.bysecond.map(function(o) {
      return new Me(i, t, o, s);
    });
    return De(a), a;
  }, e.prototype.stimeset = function(i, t, n, s) {
    return [new Me(i, t, n, s)];
  }, e.prototype.getdayset = function(i) {
    switch (i) {
      case V.YEARLY:
        return this.ydayset.bind(this);
      case V.MONTHLY:
        return this.mdayset.bind(this);
      case V.WEEKLY:
        return this.wdayset.bind(this);
      case V.DAILY:
      default:
        return this.ddayset.bind(this);
    }
  }, e.prototype.gettimeset = function(i) {
    switch (i) {
      case V.HOURLY:
        return this.htimeset.bind(this);
      case V.MINUTELY:
        return this.mtimeset.bind(this);
      case V.SECONDLY:
        return this.stimeset.bind(this);
    }
  }, e;
}();
function Ya(e, i, t, n, s, a) {
  for (var o = [], d = 0; d < e.length; d++) {
    var r = void 0, l = void 0, _ = e[d];
    _ < 0 ? (r = Math.floor(_ / i.length), l = te(_, i.length)) : (r = Math.floor((_ - 1) / i.length), l = te(_ - 1, i.length));
    for (var h = [], p = t; p < n; p++) {
      var v = a[p];
      J(v) && h.push(v);
    }
    var g = void 0;
    g = r < 0 ? h.slice(r)[0] : h[r];
    var c = i[l], f = kt(s.yearordinal + g), u = Et(f, c);
    F(o, u) || o.push(u);
  }
  return De(o), o;
}
function Mt(e, i) {
  var t = i.dtstart, n = i.freq, s = i.interval, a = i.until, o = i.bysetpos, d = i.count;
  if (d === 0 || s === 0)
    return de(e);
  var r = ka.fromDate(t), l = new Ua(i);
  l.rebuild(r.year, r.month);
  for (var _ = function(m, x, b) {
    var E = b.freq, S = b.byhour, T = b.byminute, C = b.bysecond;
    return Oe(E) ? function(A) {
      var $ = A.dtstart.getTime() % 1e3;
      if (!Oe(A.freq))
        return [];
      var H = [];
      return A.byhour.forEach(function(O) {
        A.byminute.forEach(function(P) {
          A.bysecond.forEach(function(R) {
            H.push(new Me(O, P, R, $));
          });
        });
      }), H;
    }(b) : E >= z.HOURLY && K(S) && !F(S, x.hour) || E >= z.MINUTELY && K(T) && !F(T, x.minute) || E >= z.SECONDLY && K(C) && !F(C, x.second) ? [] : m.gettimeset(E)(x.hour, x.minute, x.second, x.millisecond);
  }(l, r, i); ; ) {
    var h = l.getdayset(n)(r.year, r.month, r.day), p = h[0], v = h[1], g = h[2], c = Fa(p, v, g, l, i);
    if (K(o))
      for (var f = Ya(o, _, v, g, l, p), u = 0; u < f.length; u++) {
        var y = f[u];
        if (a && y > a)
          return de(e);
        if (y >= t) {
          var w = ot(y, i);
          if (!e.accept(w) || d && !--d)
            return de(e);
        }
      }
    else
      for (u = v; u < g; u++) {
        var D = p[u];
        if (J(D))
          for (var M = kt(l.yearordinal + D), k = 0; k < _.length; k++) {
            var N = _[k];
            if (y = Et(M, N), a && y > a || y >= t && (w = ot(y, i), !e.accept(w) || d && !--d))
              return de(e);
          }
      }
    if (i.interval === 0 || (r.add(i, c), r.year > 9999))
      return de(e);
    Oe(n) || (_ = l.gettimeset(n)(r.hour, r.minute, r.second, 0)), l.rebuild(r.year, r.month);
  }
}
function Va(e, i, t) {
  var n = t.bymonth, s = t.byweekno, a = t.byweekday, o = t.byeaster, d = t.bymonthday, r = t.bynmonthday, l = t.byyearday;
  return K(n) && !F(n, e.mmask[i]) || K(s) && !e.wnomask[i] || K(a) && !F(a, e.wdaymask[i]) || K(e.nwdaymask) && !e.nwdaymask[i] || o !== null && !F(e.eastermask, i) || (K(d) || K(r)) && !F(d, e.mdaymask[i]) && !F(r, e.nmdaymask[i]) || K(l) && (i < e.yearlen && !F(l, i + 1) && !F(l, -e.yearlen + i) || i >= e.yearlen && !F(l, i + 1 - e.yearlen) && !F(l, -e.nextyearlen + i - e.yearlen));
}
function ot(e, i) {
  return new Te(e, i.tzid).rezonedDate();
}
function de(e) {
  return e.getValue();
}
function Fa(e, i, t, n, s) {
  for (var a = !1, o = i; o < t; o++) {
    var d = e[o];
    (a = Va(n, d, s)) && (e[d] = null);
  }
  return a;
}
var ae = { MO: new Z(0), TU: new Z(1), WE: new Z(2), TH: new Z(3), FR: new Z(4), SA: new Z(5), SU: new Z(6) }, Je = { freq: V.YEARLY, dtstart: null, interval: 1, wkst: ae.MO, count: null, until: null, tzid: null, bysetpos: null, bymonth: null, bymonthday: null, bynmonthday: null, byyearday: null, byweekno: null, byweekday: null, bynweekday: null, byhour: null, byminute: null, bysecond: null, byeaster: null }, Ba = Object.keys(Je), z = function() {
  function e(i, t) {
    i === void 0 && (i = {}), t === void 0 && (t = !1), this._cache = t ? null : new Na(), this.origOptions = St(i);
    var n = Ea(i).parsedOptions;
    this.options = n;
  }
  return e.parseText = function(i, t) {
    return Dt(i, t);
  }, e.fromText = function(i, t) {
    return xa(i, t);
  }, e.fromString = function(i) {
    return new e(e.parseString(i) || void 0);
  }, e.prototype._iter = function(i) {
    return Mt(i, this.options);
  }, e.prototype._cacheGet = function(i, t) {
    return !!this._cache && this._cache._cacheGet(i, t);
  }, e.prototype._cacheAdd = function(i, t, n) {
    if (this._cache)
      return this._cache._cacheAdd(i, t, n);
  }, e.prototype.all = function(i) {
    if (i)
      return this._iter(new tt("all", {}, i));
    var t = this._cacheGet("all");
    return t === !1 && (t = this._iter(new xe("all", {})), this._cacheAdd("all", t)), t;
  }, e.prototype.between = function(i, t, n, s) {
    if (n === void 0 && (n = !1), !Ee(i) || !Ee(t))
      throw new Error("Invalid date passed in to RRule.between");
    var a = { before: t, after: i, inc: n };
    if (s)
      return this._iter(new tt("between", a, s));
    var o = this._cacheGet("between", a);
    return o === !1 && (o = this._iter(new xe("between", a)), this._cacheAdd("between", o, a)), o;
  }, e.prototype.before = function(i, t) {
    if (t === void 0 && (t = !1), !Ee(i))
      throw new Error("Invalid date passed in to RRule.before");
    var n = { dt: i, inc: t }, s = this._cacheGet("before", n);
    return s === !1 && (s = this._iter(new xe("before", n)), this._cacheAdd("before", s, n)), s;
  }, e.prototype.after = function(i, t) {
    if (t === void 0 && (t = !1), !Ee(i))
      throw new Error("Invalid date passed in to RRule.after");
    var n = { dt: i, inc: t }, s = this._cacheGet("after", n);
    return s === !1 && (s = this._iter(new xe("after", n)), this._cacheAdd("after", s, n)), s;
  }, e.prototype.count = function() {
    return this.all().length;
  }, e.prototype.toString = function() {
    return Pe(this.origOptions);
  }, e.prototype.toText = function(i, t, n) {
    return function(s, a, o, d) {
      return new _e(s, a, o, d).toString();
    }(this, i, t, n);
  }, e.prototype.isFullyConvertibleToText = function() {
    return wa(this);
  }, e.prototype.clone = function() {
    return new e(this.origOptions);
  }, e.FREQUENCIES = ["YEARLY", "MONTHLY", "WEEKLY", "DAILY", "HOURLY", "MINUTELY", "SECONDLY"], e.YEARLY = V.YEARLY, e.MONTHLY = V.MONTHLY, e.WEEKLY = V.WEEKLY, e.DAILY = V.DAILY, e.HOURLY = V.HOURLY, e.MINUTELY = V.MINUTELY, e.SECONDLY = V.SECONDLY, e.MO = ae.MO, e.TU = ae.TU, e.WE = ae.WE, e.TH = ae.TH, e.FR = ae.FR, e.SA = ae.SA, e.SU = ae.SU, e.parseString = Ie, e.optionsToString = Pe, e;
}(), st = { dtstart: null, cache: !1, unfold: !1, forceset: !1, compatible: !1, tzid: null };
function Ja(e, i) {
  var t = [], n = [], s = [], a = [], o = Ne(e), d = o.dtstart, r = o.tzid, l = function(_, h) {
    if (h === void 0 && (h = !1), _ = _ && _.trim(), !_)
      throw new Error("Invalid empty string");
    if (!h)
      return _.split(/\s/);
    for (var p = _.split(`
`), v = 0; v < p.length; ) {
      var g = p[v] = p[v].replace(/\s+$/g, "");
      g ? v > 0 && g[0] === " " ? (p[v - 1] += g.slice(1), p.splice(v, 1)) : v += 1 : p.splice(v, 1);
    }
    return p;
  }(e, i.unfold);
  return l.forEach(function(_) {
    var h;
    if (_) {
      var p = function(u) {
        var y = function(k) {
          if (k.indexOf(":") === -1)
            return { name: "RRULE", value: k };
          var N = (b = k, E = ":", S = 1, T = b.split(E), S ? T.slice(0, S).concat([T.slice(S).join(E)]) : T), m = N[0], x = N[1], b, E, S, T;
          return { name: m, value: x };
        }(u), w = y.name, D = y.value, M = w.split(";");
        if (!M)
          throw new Error("empty property name");
        return { name: M[0].toUpperCase(), parms: M.slice(1), value: D };
      }(_), v = p.name, g = p.parms, c = p.value;
      switch (v.toUpperCase()) {
        case "RRULE":
          if (g.length)
            throw new Error("unsupported RRULE parm: ".concat(g.join(",")));
          t.push(Ie(_));
          break;
        case "RDATE":
          var f = ((h = /RDATE(?:;TZID=([^:=]+))?/i.exec(_)) !== null && h !== void 0 ? h : [])[1];
          f && !r && (r = f), n = n.concat(dt(c, g));
          break;
        case "EXRULE":
          if (g.length)
            throw new Error("unsupported EXRULE parm: ".concat(g.join(",")));
          s.push(Ie(c));
          break;
        case "EXDATE":
          a = a.concat(dt(c, g));
          break;
        case "DTSTART":
          break;
        default:
          throw new Error("unsupported property: " + v);
      }
    }
  }), { dtstart: d, tzid: r, rrulevals: t, rdatevals: n, exrulevals: s, exdatevals: a };
}
function ge(e, i) {
  return i === void 0 && (i = {}), function(t, n) {
    var s = Ja(t, n), a = s.rrulevals, o = s.rdatevals, d = s.exrulevals, r = s.exdatevals, l = s.dtstart, _ = s.tzid, h = n.cache === !1;
    if (n.compatible && (n.forceset = !0, n.unfold = !0), n.forceset || a.length > 1 || o.length || d.length || r.length) {
      var p = new Wa(h);
      return p.dtstart(l), p.tzid(_ || void 0), a.forEach(function(g) {
        p.rrule(new z(Le(g, l, _), h));
      }), o.forEach(function(g) {
        p.rdate(g);
      }), d.forEach(function(g) {
        p.exrule(new z(Le(g, l, _), h));
      }), r.forEach(function(g) {
        p.exdate(g);
      }), n.compatible && n.dtstart && p.rdate(l), p;
    }
    var v = a[0] || {};
    return new z(Le(v, v.dtstart || n.dtstart || l, v.tzid || n.tzid || _), h);
  }(e, function(t) {
    var n = [], s = Object.keys(t), a = Object.keys(st);
    if (s.forEach(function(o) {
      F(a, o) || n.push(o);
    }), n.length)
      throw new Error("Invalid options: " + n.join(", "));
    return ee(ee({}, st), t);
  }(i));
}
function Le(e, i, t) {
  return ee(ee({}, e), { dtstart: i, tzid: t });
}
function dt(e, i) {
  return function(t) {
    t.forEach(function(n) {
      if (!/(VALUE=DATE(-TIME)?)|(TZID=)/.test(n))
        throw new Error("unsupported RDATE/EXDATE parm: " + n);
    });
  }(i), e.split(",").map(function(t) {
    return Fe(t);
  });
}
function _t(e) {
  var i = this;
  return function(t) {
    if (t !== void 0 && (i["_".concat(e)] = t), i["_".concat(e)] !== void 0)
      return i["_".concat(e)];
    for (var n = 0; n < i._rrule.length; n++) {
      var s = i._rrule[n].origOptions[e];
      if (s)
        return s;
    }
  };
}
var Wa = function(e) {
  function i(t) {
    t === void 0 && (t = !1);
    var n = e.call(this, {}, t) || this;
    return n.dtstart = _t.apply(n, ["dtstart"]), n.tzid = _t.apply(n, ["tzid"]), n._rrule = [], n._rdate = [], n._exrule = [], n._exdate = [], n;
  }
  return Be(i, e), i.prototype._iter = function(t) {
    return function(n, s, a, o, d, r) {
      var l = {}, _ = n.accept;
      function h(c, f) {
        a.forEach(function(u) {
          u.between(c, f, !0).forEach(function(y) {
            l[Number(y)] = !0;
          });
        });
      }
      d.forEach(function(c) {
        var f = new Te(c, r).rezonedDate();
        l[Number(f)] = !0;
      }), n.accept = function(c) {
        var f = Number(c);
        return isNaN(f) ? _.call(this, c) : !(!l[f] && (h(new Date(f - 1), new Date(f + 1)), !l[f])) || (l[f] = !0, _.call(this, c));
      }, n.method === "between" && (h(n.args.after, n.args.before), n.accept = function(c) {
        var f = Number(c);
        return !!l[f] || (l[f] = !0, _.call(this, c));
      });
      for (var p = 0; p < o.length; p++) {
        var v = new Te(o[p], r).rezonedDate();
        if (!n.accept(new Date(v.getTime())))
          break;
      }
      s.forEach(function(c) {
        Mt(n, c.options);
      });
      var g = n._result;
      switch (De(g), n.method) {
        case "all":
        case "between":
          return g;
        case "before":
          return g.length && g[g.length - 1] || null;
        default:
          return g.length && g[0] || null;
      }
    }(t, this._rrule, this._exrule, this._rdate, this._exdate, this.tzid());
  }, i.prototype.rrule = function(t) {
    lt(t, this._rrule);
  }, i.prototype.exrule = function(t) {
    lt(t, this._exrule);
  }, i.prototype.rdate = function(t) {
    ct(t, this._rdate);
  }, i.prototype.exdate = function(t) {
    ct(t, this._exdate);
  }, i.prototype.rrules = function() {
    return this._rrule.map(function(t) {
      return ge(t.toString());
    });
  }, i.prototype.exrules = function() {
    return this._exrule.map(function(t) {
      return ge(t.toString());
    });
  }, i.prototype.rdates = function() {
    return this._rdate.map(function(t) {
      return new Date(t.getTime());
    });
  }, i.prototype.exdates = function() {
    return this._exdate.map(function(t) {
      return new Date(t.getTime());
    });
  }, i.prototype.valueOf = function() {
    var t = [];
    return !this._rrule.length && this._dtstart && (t = t.concat(Pe({ dtstart: this._dtstart }))), this._rrule.forEach(function(n) {
      t = t.concat(n.toString().split(`
`));
    }), this._exrule.forEach(function(n) {
      t = t.concat(n.toString().split(`
`).map(function(s) {
        return s.replace(/^RRULE:/, "EXRULE:");
      }).filter(function(s) {
        return !/^DTSTART/.test(s);
      }));
    }), this._rdate.length && t.push(ht("RDATE", this._rdate, this.tzid())), this._exdate.length && t.push(ht("EXDATE", this._exdate, this.tzid())), t;
  }, i.prototype.toString = function() {
    return this.valueOf().join(`
`);
  }, i.prototype.clone = function() {
    var t = new i(!!this._cache);
    return this._rrule.forEach(function(n) {
      return t.rrule(n.clone());
    }), this._exrule.forEach(function(n) {
      return t.exrule(n.clone());
    }), this._rdate.forEach(function(n) {
      return t.rdate(new Date(n.getTime()));
    }), this._exdate.forEach(function(n) {
      return t.exdate(new Date(n.getTime()));
    }), t;
  }, i;
}(z);
function lt(e, i) {
  if (!(e instanceof z))
    throw new TypeError(String(e) + " is not RRule instance");
  F(i.map(String), String(e)) || i.push(e);
}
function ct(e, i) {
  if (!(e instanceof Date))
    throw new TypeError(String(e) + " is not Date instance");
  F(i.map(Number), Number(e)) || (i.push(e), De(i));
}
function ht(e, i, t) {
  var n = !t || t.toUpperCase() === "UTC", s = n ? "".concat(e, ":") : "".concat(e, ";TZID=").concat(t, ":"), a = i.map(function(o) {
    return Ve(o.valueOf(), n);
  }).join(",");
  return "".concat(s).concat(a);
}
class Ka {
  constructor(i) {
    this._scheduler = i;
  }
  getNode() {
    const i = this._scheduler;
    return this._tooltipNode || (this._tooltipNode = document.createElement("div"), this._tooltipNode.className = "dhtmlXTooltip scheduler_tooltip tooltip", i._waiAria.tooltipAttr(this._tooltipNode)), i.config.rtl ? this._tooltipNode.classList.add("dhtmlXTooltip_rtl") : this._tooltipNode.classList.remove("dhtmlXTooltip_rtl"), this._tooltipNode;
  }
  setViewport(i) {
    return this._root = i, this;
  }
  show(i, t) {
    const n = this._scheduler, s = n.$domHelpers, a = document.body, o = this.getNode();
    if (s.isChildOf(o, a) || (this.hide(), a.appendChild(o)), this._isLikeMouseEvent(i)) {
      const d = this._calculateTooltipPosition(i);
      t = d.top, i = d.left;
    }
    return o.style.top = t + "px", o.style.left = i + "px", n._waiAria.tooltipVisibleAttr(o), this;
  }
  hide() {
    const i = this._scheduler, t = this.getNode();
    return t && t.parentNode && t.parentNode.removeChild(t), i._waiAria.tooltipHiddenAttr(t), this;
  }
  setContent(i) {
    return this.getNode().innerHTML = i, this;
  }
  _isLikeMouseEvent(i) {
    return !(!i || typeof i != "object") && "clientX" in i && "clientY" in i;
  }
  _getViewPort() {
    return this._root || document.body;
  }
  _calculateTooltipPosition(i) {
    const t = this._scheduler, n = t.$domHelpers, s = this._getViewPortSize(), a = this.getNode(), o = { top: 0, left: 0, width: a.offsetWidth, height: a.offsetHeight, bottom: 0, right: 0 }, d = t.config.tooltip_offset_x, r = t.config.tooltip_offset_y, l = document.body, _ = n.getRelativeEventPosition(i, l), h = n.getNodePosition(l);
    _.y += h.y, o.top = _.y, o.left = _.x, o.top += r, o.left += d, o.bottom = o.top + o.height, o.right = o.left + o.width;
    const p = window.scrollY + l.scrollTop;
    return o.top < s.top - p ? (o.top = s.top, o.bottom = o.top + o.height) : o.bottom > s.bottom && (o.bottom = s.bottom, o.top = o.bottom - o.height), o.left < s.left ? (o.left = s.left, o.right = s.left + o.width) : o.right > s.right && (o.right = s.right, o.left = o.right - o.width), _.x >= o.left && _.x <= o.right && (o.left = _.x - o.width - d, o.right = o.left + o.width), _.y >= o.top && _.y <= o.bottom && (o.top = _.y - o.height - r, o.bottom = o.top + o.height), o.left < 0 && (o.left = 0), o.right < 0 && (o.right = 0), o;
  }
  _getViewPortSize() {
    const i = this._scheduler, t = i.$domHelpers, n = this._getViewPort();
    let s, a = n, o = window.scrollY + document.body.scrollTop, d = window.scrollX + document.body.scrollLeft;
    return n === i.$event_data ? (a = i.$event, o = 0, d = 0, s = t.getNodePosition(i.$event)) : s = t.getNodePosition(a), { left: s.x + d, top: s.y + o, width: s.width, height: s.height, bottom: s.y + s.height + o, right: s.x + s.width + d };
  }
}
class Ga {
  constructor(i) {
    this._listeners = {}, this.tooltip = new Ka(i), this._scheduler = i, this._domEvents = i._createDomEventScope(), this._initDelayedFunctions();
  }
  destructor() {
    this.tooltip.hide(), this._domEvents.detachAll();
  }
  hideTooltip() {
    this.delayHide();
  }
  attach(i) {
    let t = document.body;
    const n = this._scheduler, s = n.$domHelpers;
    i.global || (t = n.$root);
    let a = null;
    const o = (d) => {
      const r = s.getTargetNode(d), l = s.closest(r, i.selector);
      if (s.isChildOf(r, this.tooltip.getNode()))
        return;
      const _ = () => {
        a = l, i.onmouseenter(d, l);
      };
      n._mobile && n.config.touch_tooltip && (l ? _() : i.onmouseleave(d, l)), a ? l && l === a ? i.onmousemove(d, l) : (i.onmouseleave(d, a), a = null, l && l !== a && _()) : l && _();
    };
    this.detach(i.selector), this._domEvents.attach(t, "mousemove", o), this._listeners[i.selector] = { node: t, handler: o };
  }
  detach(i) {
    const t = this._listeners[i];
    t && this._domEvents.detach(t.node, "mousemove", t.handler);
  }
  tooltipFor(i) {
    const t = (n) => {
      let s = n;
      return document.createEventObject && !document.createEvent && (s = document.createEventObject(n)), s;
    };
    this._initDelayedFunctions(), this.attach({ selector: i.selector, global: i.global, onmouseenter: (n, s) => {
      const a = i.html(n, s);
      a && this.delayShow(t(n), a);
    }, onmousemove: (n, s) => {
      const a = i.html(n, s);
      a ? this.delayShow(t(n), a) : (this.delayShow.$cancelTimeout(), this.delayHide());
    }, onmouseleave: () => {
      this.delayShow.$cancelTimeout(), this.delayHide();
    } });
  }
  _initDelayedFunctions() {
    const i = this._scheduler;
    this.delayShow && this.delayShow.$cancelTimeout(), this.delayHide && this.delayHide.$cancelTimeout(), this.tooltip.hide(), this.delayShow = ne.delay((t, n) => {
      i.callEvent("onBeforeTooltip", [t]) === !1 ? this.tooltip.hide() : (this.tooltip.setContent(n), this.tooltip.show(t));
    }, i.config.tooltip_timeout || 1), this.delayHide = ne.delay(() => {
      this.delayShow.$cancelTimeout(), this.tooltip.hide();
    }, i.config.tooltip_hide_timeout || 1);
  }
}
const Xa = { active_links: function(e) {
  e.config.active_link_view = "day", e._active_link_click = function(i) {
    var t = i.target.getAttribute("data-link-date"), n = e.date.str_to_date(e.config.api_date, !1, !0);
    if (t)
      return e.setCurrentView(n(t), e.config.active_link_view), i && i.preventDefault && i.preventDefault(), !1;
  }, e.attachEvent("onTemplatesReady", function() {
    var i = function(n, s) {
      s = s || n + "_scale_date", e.templates["_active_links_old_" + s] || (e.templates["_active_links_old_" + s] = e.templates[s]);
      var a = e.templates["_active_links_old_" + s], o = e.date.date_to_str(e.config.api_date);
      e.templates[s] = function(d) {
        return "<a data-link-date='" + o(d) + "' href='#'>" + a(d) + "</a>";
      };
    };
    if (i("week"), i("", "month_day"), this.matrix)
      for (var t in this.matrix)
        i(t);
    this._detachDomEvent(this._obj, "click", e._active_link_click), e.event(this._obj, "click", e._active_link_click);
  });
}, agenda_legacy: function(e) {
  e.date.add_agenda_legacy = function(i) {
    return e.date.add(i, 1, "year");
  }, e.templates.agenda_legacy_time = function(i, t, n) {
    return n._timed ? this.day_date(n.start_date, n.end_date, n) + " " + this.event_date(i) : e.templates.day_date(i) + " &ndash; " + e.templates.day_date(t);
  }, e.templates.agenda_legacy_text = function(i, t, n) {
    return n.text;
  }, e.templates.agenda_legacy_date = function() {
    return "";
  }, e.date.agenda_legacy_start = function() {
    return e.date.date_part(e._currentDate());
  }, e.attachEvent("onTemplatesReady", function() {
    var i = e.dblclick_dhx_cal_data;
    e.dblclick_dhx_cal_data = function() {
      if (this._mode == "agenda_legacy")
        !this.config.readonly && this.config.dblclick_create && this.addEventNow();
      else if (i)
        return i.apply(this, arguments);
    };
    var t = e.render_data;
    e.render_data = function(a) {
      if (this._mode != "agenda_legacy")
        return t.apply(this, arguments);
      s();
    };
    var n = e.render_view_data;
    function s() {
      var a = e.get_visible_events();
      a.sort(function(u, y) {
        return u.start_date > y.start_date ? 1 : -1;
      });
      for (var o, d = "<div class='dhx_agenda_area' " + e._waiAria.agendaDataAttrString() + ">", r = 0; r < a.length; r++) {
        var l = a[r], _ = l.color ? "--dhx-scheduler-event-background:" + l.color + ";" : "", h = l.textColor ? "--dhx-scheduler-event-color:" + l.textColor + ";" : "", p = e.templates.event_class(l.start_date, l.end_date, l);
        o = e._waiAria.agendaEventAttrString(l);
        var v = e._waiAria.agendaDetailsBtnString();
        d += "<div " + o + " class='dhx_agenda_line" + (p ? " " + p : "") + "' event_id='" + l.id + "' " + e.config.event_attribute + "='" + l.id + "' style='" + h + _ + (l._text_style || "") + "'><div class='dhx_agenda_event_time'>" + (e.config.rtl ? e.templates.agenda_time(l.end_date, l.start_date, l) : e.templates.agenda_time(l.start_date, l.end_date, l)) + "</div>", d += `<div ${v} class='dhx_event_icon icon_details'><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M15.4444 16.4H4.55556V7.6H15.4444V16.4ZM13.1111 2V3.6H6.88889V2H5.33333V3.6H4.55556C3.69222 3.6 3 4.312 3 5.2V16.4C3 16.8243 3.16389 17.2313 3.45561 17.5314C3.74733 17.8314 4.143 18 4.55556 18H15.4444C15.857 18 16.2527 17.8314 16.5444 17.5314C16.8361 17.2313 17 16.8243 17 16.4V5.2C17 4.312 16.3 3.6 15.4444 3.6H14.6667V2H13.1111ZM13.8889 10.8H10V14.8H13.8889V10.8Z" fill="#A1A4A6"/>
			</svg></div>`, d += "<span>" + e.templates.agenda_text(l.start_date, l.end_date, l) + "</span></div>";
      }
      d += "<div class='dhx_v_border'></div></div>", e._els.dhx_cal_data[0].innerHTML = d, e._els.dhx_cal_data[0].childNodes[0].scrollTop = e._agendaScrollTop || 0;
      var g = e._els.dhx_cal_data[0].childNodes[0];
      g.childNodes[g.childNodes.length - 1].style.height = g.offsetHeight < e._els.dhx_cal_data[0].offsetHeight ? "100%" : g.offsetHeight + "px";
      var c = e._els.dhx_cal_data[0].firstChild.childNodes, f = e._getNavDateElement();
      for (f && (f.innerHTML = e.templates.agenda_date(e._min_date, e._max_date, e._mode)), e._reset_rendered_events(), r = 0; r < c.length - 1; r++)
        e._rendered[r] = c[r];
    }
    e.render_view_data = function() {
      return this._mode == "agenda_legacy" && (e._agendaScrollTop = e._els.dhx_cal_data[0].childNodes[0].scrollTop, e._els.dhx_cal_data[0].childNodes[0].scrollTop = 0), n.apply(this, arguments);
    }, e.agenda_legacy_view = function(a) {
      e._min_date = e.config.agenda_start || e.date.agenda_legacy_start(e._date), e._max_date = e.config.agenda_end || e.date.add_agenda_legacy(e._min_date, 1), function(o) {
        if (o) {
          var d = e.locale.labels, r = e._waiAria.agendaHeadAttrString(), l = e._waiAria.agendaHeadDateString(d.date), _ = e._waiAria.agendaHeadDescriptionString(d.description);
          e._els.dhx_cal_header[0].innerHTML = "<div " + r + " class='dhx_agenda_line dhx_agenda_line_header'><div " + l + ">" + d.date + "</div><span class = 'description_header' style='padding-left:25px' " + _ + ">" + d.description + "</span></div>", e._table_view = !0, e.set_sizes();
        }
      }(a), a ? (e._cols = null, e._colsS = null, e._table_view = !0, s()) : e._table_view = !1;
    };
  });
}, agenda_view: function(e) {
  e.date.add_agenda = function(s, a) {
    return e.date.add(s, 1 * a, "month");
  }, e.templates.agenda_time = function(s, a, o) {
    return o._timed ? `${this.event_date(s)} - ${this.event_date(a)}` : e.locale.labels.full_day;
  }, e.templates.agenda_text = function(s, a, o) {
    return o.text;
  };
  const i = e.date.date_to_str("%F %j"), t = e.date.date_to_str("%l");
  e.templates.agenda_day = function(s) {
    return `<div class="dhx_agenda_day_date">${i(s)}</div>
		<div class="dhx_agenda_day_dow">${t(s)}</div>`;
  }, e.templates.agenda_date = function(s, a) {
    return e.templates.month_date(e.getState().date);
  }, e.date.agenda_start = function(s) {
    return e.date.month_start(new Date(s));
  };
  let n = 0;
  e.attachEvent("onTemplatesReady", function() {
    var s = e.dblclick_dhx_cal_data;
    e.dblclick_dhx_cal_data = function() {
      if (this._mode == "agenda")
        !this.config.readonly && this.config.dblclick_create && this.addEventNow();
      else if (s)
        return s.apply(this, arguments);
    };
    var a = e.render_data;
    e.render_data = function(l) {
      if (this._mode != "agenda")
        return a.apply(this, arguments);
      d();
    };
    var o = e.render_view_data;
    function d() {
      const l = e.get_visible_events();
      l.sort(function(f, u) {
        return f.start_date > u.start_date ? 1 : -1;
      });
      const _ = {};
      let h = e.getState().min_date;
      const p = e.getState().max_date;
      for (; h.valueOf() < p.valueOf(); )
        _[h.valueOf()] = [], h = e.date.add(h, 1, "day");
      let v = !1;
      if (l.forEach((f) => {
        let u = e.date.day_start(new Date(f.start_date));
        for (; u.valueOf() < f.end_date.valueOf(); )
          _[u.valueOf()] && (_[u.valueOf()].push(f), v = !0), u = e.date.day_start(e.date.add(u, 1, "day"));
      }), v) {
        let f = "";
        for (let u in _)
          e.ignore_agenda && e.ignore_agenda(new Date(1 * u)) || (f += r(new Date(1 * u), _[u]));
        e._els.dhx_cal_data[0].innerHTML = f;
      } else
        e._els.dhx_cal_data[0].innerHTML = `<div class="dhx_cal_agenda_no_events">${e.locale.labels.agenda_tab}</div>`;
      e._els.dhx_cal_data[0].scrollTop = n;
      let g = e._els.dhx_cal_data[0].querySelectorAll(".dhx_cal_agenda_event_line");
      e._reset_rendered_events();
      for (var c = 0; c < g.length - 1; c++)
        e._rendered[c] = g[c];
    }
    function r(l, _) {
      if (!_.length)
        return "";
      let h = `
<div class="dhx_cal_agenda_day" data-date="${e.templates.format_date(l)}" data-day="${l.getDay()}">
	<div class="dhx_cal_agenda_day_header">${e.templates.agenda_day(l)}</div>
	<div class="dhx_cal_agenda_day_events">
`;
      return _.forEach((p) => {
        h += function(v, g) {
          const c = e.templates.agenda_time(g.start_date, g.end_date, g), f = e.getState().select_id, u = e.templates.event_class(g.start_date, g.end_date, g), y = e.templates.agenda_text(g.start_date, g.end_date, g);
          let w = "";
          return (g.color || g.textColor) && (w = ` style="${g.color ? "--dhx-scheduler-event-background:" + g.color + ";" : ""}${g.textColor ? "--dhx-scheduler-event-color:" + g.textColor + ";" : ""}" `), `<div class="dhx_cal_agenda_event_line ${u || ""} ${g.id == f ? "dhx_cal_agenda_event_line_selected" : ""}" ${w} ${e.config.event_attribute}="${g.id}">
	<div class="dhx_cal_agenda_event_line_marker"></div>
	<div class="dhx_cal_agenda_event_line_time">${c}</div>
	<div class="dhx_cal_agenda_event_line_text">${y}</div>
</div>`;
        }(0, p);
      }), h += "</div></div>", h;
    }
    e.render_view_data = function() {
      return this._mode == "agenda" && (n = e._els.dhx_cal_data[0].scrollTop, e._els.dhx_cal_data[0].scrollTop = 0), o.apply(this, arguments);
    }, e.agenda_view = function(l) {
      if (l) {
        e._min_date = e.config.agenda_start || e.date.agenda_start(e._date), e._max_date = e.config.agenda_end || e.date.add_agenda(e._min_date, 1), e._cols = null, e._colsS = null, e._table_view = !0;
        const _ = e._getNavDateElement();
        _ && (_.innerHTML = e.templates.agenda_date(e._date)), e.set_sizes(), d();
      } else
        e._table_view = !1;
    };
  });
}, all_timed: function(e) {
  e.config.all_timed = "short", e.config.all_timed_month = !1, e.ext.allTimed = { isMainAreaEvent: function(d) {
    return !!(d._timed || e.config.all_timed === !0 || e.config.all_timed == "short" && i(d));
  } };
  var i = function(d) {
    return !((d.end_date - d.start_date) / 36e5 >= 24) || e._drag_mode == "resize" && e._drag_id == d.id;
  };
  e._safe_copy = function(d) {
    var r = null, l = e._copy_event(d);
    return d.event_pid && (r = e.getEvent(d.event_pid)), r && r.isPrototypeOf(d) && (delete l.event_length, delete l.event_pid, delete l.rec_pattern, delete l.rec_type), l;
  };
  var t = e._pre_render_events_line, n = e._pre_render_events_table, s = function(d, r) {
    return this._table_view ? n.call(this, d, r) : t.call(this, d, r);
  };
  e._pre_render_events_line = e._pre_render_events_table = function(d, r) {
    if (!this.config.all_timed || this._table_view && this._mode != "month" || this._mode == "month" && !this.config.all_timed_month)
      return s.call(this, d, r);
    for (var l = 0; l < d.length; l++) {
      var _ = d[l];
      if (!_._timed)
        if (this.config.all_timed != "short" || i(_)) {
          var h = this._safe_copy(_);
          _._virtual ? h._first_chunk = !1 : h._first_chunk = !0, h._drag_resize = !1, h._virtual = !0, h.start_date = new Date(h.start_date), c(_) ? (h.end_date = f(h.start_date), this.config.last_hour != 24 && (h.end_date = u(h.start_date, this.config.last_hour))) : h.end_date = new Date(_.end_date);
          var p = !1;
          h.start_date < this._max_date && h.end_date > this._min_date && h.start_date < h.end_date && (d[l] = h, p = !0);
          var v = this._safe_copy(_);
          if (v._virtual = !0, v.end_date = new Date(v.end_date), v.start_date < this._min_date ? v.start_date = u(this._min_date, this.config.first_hour) : v.start_date = u(f(_.start_date), this.config.first_hour), v.start_date < this._max_date && v.start_date < v.end_date) {
            if (!p) {
              d[l--] = v;
              continue;
            }
            d.splice(l + 1, 0, v), v._last_chunk = !1;
          } else
            h._last_chunk = !0, h._drag_resize = !0;
        } else
          this._mode != "month" && d.splice(l--, 1);
    }
    var g = this._drag_mode != "move" && r;
    return s.call(this, d, g);
    function c(y) {
      var w = f(y.start_date);
      return +y.end_date > +w;
    }
    function f(y) {
      var w = e.date.add(y, 1, "day");
      return w = e.date.date_part(w);
    }
    function u(y, w) {
      var D = e.date.date_part(new Date(y));
      return D.setHours(w), D;
    }
  };
  var a = e.get_visible_events;
  e.get_visible_events = function(d) {
    return this.config.all_timed && this.config.multi_day ? a.call(this, !1) : a.call(this, d);
  }, e.attachEvent("onBeforeViewChange", function(d, r, l, _) {
    return e._allow_dnd = l == "day" || l == "week" || e.getView(l), !0;
  }), e._is_main_area_event = function(d) {
    return e.ext.allTimed.isMainAreaEvent(d);
  };
  var o = e.updateEvent;
  e.updateEvent = function(d) {
    var r, l, _ = e.getEvent(d);
    _ && (r = e.config.all_timed && !(e.isOneDayEvent(e._events[d]) || e.getState().drag_id)) && (l = e.config.update_render, e.config.update_render = !0), o.apply(e, arguments), _ && r && (e.config.update_render = l);
  };
}, collision: function(e) {
  let i, t;
  function n(s) {
    e._get_section_view() && s && (i = e.getEvent(s)[e._get_section_property()]);
  }
  e.config.collision_limit = 1, e.attachEvent("onBeforeDrag", function(s) {
    return n(s), !0;
  }), e.attachEvent("onBeforeLightbox", function(s) {
    const a = e.getEvent(s);
    return t = [a.start_date, a.end_date], n(s), !0;
  }), e.attachEvent("onEventChanged", function(s) {
    if (!s || !e.getEvent(s))
      return !0;
    const a = e.getEvent(s);
    if (!e.checkCollision(a)) {
      if (!t)
        return !1;
      a.start_date = t[0], a.end_date = t[1], a._timed = this.isOneDayEvent(a);
    }
    return !0;
  }), e.attachEvent("onBeforeEventChanged", function(s, a, o) {
    return e.checkCollision(s);
  }), e.attachEvent("onEventAdded", function(s, a) {
    e.checkCollision(a) || e.deleteEvent(s);
  }), e.attachEvent("onEventSave", function(s, a, o) {
    if ((a = e._lame_clone(a)).id = s, !a.start_date || !a.end_date) {
      const d = e.getEvent(s);
      a.start_date = new Date(d.start_date), a.end_date = new Date(d.end_date);
    }
    return (a.rrule && !a.recurring_event_id || a.rec_type) && e._roll_back_dates(a), e.checkCollision(a);
  }), e._check_sections_collision = function(s, a) {
    const o = e._get_section_property();
    return s[o] == a[o] && s.id != a.id;
  }, e.checkCollision = function(s) {
    let a = [];
    const o = e.config.collision_limit;
    if (s.rec_type) {
      let _ = e.getRecDates(s);
      for (let h = 0; h < _.length; h++) {
        let p = e.getEvents(_[h].start_date, _[h].end_date);
        for (let v = 0; v < p.length; v++)
          (p[v].event_pid || p[v].id) != s.id && a.push(p[v]);
      }
    } else if (s.rrule) {
      let _ = e.getRecDates(s);
      for (let h = 0; h < _.length; h++) {
        let p = e.getEvents(_[h].start_date, _[h].end_date);
        for (let v = 0; v < p.length; v++)
          (String(p[v].id).split("#")[0] || p[v].id) != s.id && a.push(p[v]);
      }
    } else {
      a = e.getEvents(s.start_date, s.end_date);
      for (let _ = 0; _ < a.length; _++) {
        let h = a[_];
        if (h.id == s.id || h.event_length && [h.event_pid, h.event_length].join("#") == s.id) {
          a.splice(_, 1);
          break;
        }
        if (h.recurring_event_id && [h.recurring_event_id, h._pid_time].join("#") == s.id) {
          a.splice(_, 1);
          break;
        }
        if (h.id && String(h.id).split("#")[0] == s.id) {
          a.splice(_, 1);
          break;
        }
      }
    }
    const d = e._get_section_view(), r = e._get_section_property();
    let l = !0;
    if (d) {
      let _ = 0;
      for (let h = 0; h < a.length; h++)
        a[h].id != s.id && this._check_sections_collision(a[h], s) && _++;
      _ >= o && (l = !1);
    } else
      a.length >= o && (l = !1);
    if (!l) {
      let _ = !e.callEvent("onEventCollision", [s, a]);
      return _ || (s[r] = i || s[r]), _;
    }
    return l;
  };
}, container_autoresize: function(e) {
  e.config.container_autoresize = !0, e.config.month_day_min_height = 90, e.config.min_grid_size = 25, e.config.min_map_size = 400;
  var i = e._pre_render_events, t = !0, n = 0, s = 0;
  e._pre_render_events = function(h, p) {
    if (!e.config.container_autoresize || !t)
      return i.apply(this, arguments);
    var v = this.xy.bar_height, g = this._colsS.heights, c = this._colsS.heights = [0, 0, 0, 0, 0, 0, 0], f = this._els.dhx_cal_data[0];
    if (h = this._table_view ? this._pre_render_events_table(h, p) : this._pre_render_events_line(h, p), this._table_view)
      if (p)
        this._colsS.heights = g;
      else {
        var u = f.firstChild;
        const m = u.querySelectorAll(".dhx_cal_month_row");
        if (m && m.length) {
          for (var y = 0; y < m.length; y++) {
            if (c[y]++, c[y] * v > this._colsS.height - this.xy.month_head_height) {
              var w = m[y].querySelectorAll(".dhx_cal_month_cell"), D = this._colsS.height - this.xy.month_head_height;
              1 * this.config.max_month_events !== this.config.max_month_events || c[y] <= this.config.max_month_events ? D = c[y] * v : (this.config.max_month_events + 1) * v > this._colsS.height - this.xy.month_head_height && (D = (this.config.max_month_events + 1) * v), m[y].style.height = D + this.xy.month_head_height + "px";
              for (var M = 0; M < w.length; M++)
                w[M].childNodes[1].style.height = D + "px";
              c[y] = (c[y - 1] || 0) + w[0].offsetHeight;
            }
            c[y] = (c[y - 1] || 0) + m[y].querySelectorAll(".dhx_cal_month_cell")[0].offsetHeight;
          }
          c.unshift(0), u.parentNode.offsetHeight < u.parentNode.scrollHeight && u._h_fix;
        } else if (h.length || this._els.dhx_multi_day[0].style.visibility != "visible" || (c[0] = -1), h.length || c[0] == -1) {
          var k = (c[0] + 1) * v + 1;
          s != k + 1 && (this._obj.style.height = n - s + k - 1 + "px"), k += "px";
          const x = this._els.dhx_cal_navline[0].offsetHeight, b = this._els.dhx_cal_header[0].offsetHeight;
          f.style.height = this._obj.offsetHeight - x - b - (this.xy.margin_top || 0) + "px";
          var N = this._els.dhx_multi_day[0];
          N.style.height = k, N.style.visibility = c[0] == -1 ? "hidden" : "visible", N.style.display = c[0] == -1 ? "none" : "", (N = this._els.dhx_multi_day[1]).style.height = k, N.style.visibility = c[0] == -1 ? "hidden" : "visible", N.style.display = c[0] == -1 ? "none" : "", N.className = c[0] ? "dhx_multi_day_icon" : "dhx_multi_day_icon_small", this._dy_shift = (c[0] + 1) * v, c[0] = 0;
        }
      }
    return h;
  };
  var a = ["dhx_cal_navline", "dhx_cal_header", "dhx_multi_day", "dhx_cal_data"], o = function(h) {
    n = 0;
    for (var p = 0; p < a.length; p++) {
      var v = a[p], g = e._els[v] ? e._els[v][0] : null, c = 0;
      switch (v) {
        case "dhx_cal_navline":
        case "dhx_cal_header":
          c = g.offsetHeight;
          break;
        case "dhx_multi_day":
          c = g ? g.offsetHeight - 1 : 0, s = c;
          break;
        case "dhx_cal_data":
          var f = e.getState().mode;
          if (g.childNodes[1] && f != "month") {
            let k = 0;
            for (let N = 0; N < g.childNodes.length; N++)
              g.childNodes[N].offsetHeight > k && (k = g.childNodes[N].offsetHeight);
            c = k;
          } else
            c = Math.max(g.offsetHeight - 1, g.scrollHeight);
          if (f == "month")
            e.config.month_day_min_height && !h && (c = g.querySelectorAll(".dhx_cal_month_row").length * e.config.month_day_min_height), h && (g.style.height = c + "px");
          else if (f == "year")
            c = 190 * e.config.year_y;
          else if (f == "agenda") {
            if (c = 0, g.children && g.children.length)
              if (g.children.length === 1 && g.children[0].classList.contains("dhx_cal_agenda_no_events"))
                c = 300;
              else
                for (var u = 0; u < g.children.length; u++)
                  c += g.children[u].offsetHeight;
            c + 2 < e.config.min_grid_size ? c = e.config.min_grid_size : c += 2;
          } else if (f == "week_agenda") {
            let k = _(), N = g.querySelector(".dhx_wa_ev_body") || 0, m = window.getComputedStyle(g.querySelector(".dhx_wa_scale_bar")).getPropertyValue("--dhx-scheduler-week-agenda-scale-height") || 35;
            c = k * (1.1 * N.offsetHeight) + 4 * (parseInt(m) + 10);
          } else if (f == "map") {
            c = 0;
            var y = g.querySelectorAll(".dhx_map_line");
            for (u = 0; u < y.length; u++)
              c += y[u].offsetHeight;
            c + 2 < e.config.min_map_size ? c = e.config.min_map_size : c += 2;
          } else if (e._gridView)
            if (c = 0, g.childNodes[1].childNodes[0].childNodes && g.childNodes[1].childNodes[0].childNodes.length) {
              for (y = g.childNodes[1].childNodes[0].childNodes[0].childNodes, u = 0; u < y.length; u++)
                c += y[u].offsetHeight;
              (c += 2) < e.config.min_grid_size && (c = e.config.min_grid_size);
            } else
              c = e.config.min_grid_size;
          if (e.matrix && e.matrix[f]) {
            if (h)
              c += 0, g.style.height = c + "px";
            else {
              c = 0;
              for (var w = e.matrix[f], D = w.y_unit, M = 0; M < D.length; M++)
                c += w.getSectionHeight(D[M].key);
              e.$container.clientWidth != e.$container.scrollWidth && (c += l());
            }
            c -= 1;
          }
          (f == "day" || f == "week" || e._props && e._props[f]) && (c += 2);
      }
      n += c += 1;
    }
    e._obj.style.height = n + "px", h || e.updateView();
  };
  function d() {
    t = !1, e.callEvent("onAfterSchedulerResize", []), t = !0;
  }
  var r = function() {
    if (!e.config.container_autoresize || !t || e._drag_mode && e._drag_mode === "create" && e._mobile)
      return !0;
    var h = e.getState().mode;
    if (!h)
      return !0;
    var p = window.requestAnimationFrame || window.setTimeout, v = document.documentElement.scrollTop;
    p(function() {
      !e.$destroyed && e.$initialized && o();
    }), e.matrix && e.matrix[h] || h == "month" ? p(function() {
      !e.$destroyed && e.$initialized && (o(!0), document.documentElement.scrollTop = v, d());
    }, 1) : d();
  };
  function l() {
    var h = document.createElement("div");
    h.style.cssText = "visibility:hidden;position:absolute;left:-1000px;width:100px;padding:0px;margin:0px;height:110px;min-height:100px;overflow-y:scroll;", document.body.appendChild(h);
    var p = h.offsetWidth - h.clientWidth;
    return document.body.removeChild(h), p;
  }
  function _() {
    const h = document.querySelectorAll(".dhx_wa_row_autoresize"), p = [];
    return h.forEach((v) => {
      let g = 0;
      v.querySelectorAll(".dhx_wa_day_cont").forEach((c) => {
        const f = c.querySelectorAll(".dhx_wa_ev_body").length;
        f > g && (g = f);
      }), p.push(g);
    }), p.reduce((v, g) => v + g, 0);
  }
  e.attachEvent("onBeforeViewChange", function() {
    var h = e.config.container_autoresize;
    if (e.xy.$original_scroll_width || (e.xy.$original_scroll_width = e.xy.scroll_width), e.xy.scroll_width = h ? 0 : e.xy.$original_scroll_width, e.matrix)
      for (var p in e.matrix) {
        var v = e.matrix[p];
        v.$original_section_autoheight || (v.$original_section_autoheight = v.section_autoheight), v.section_autoheight = !h && v.$original_section_autoheight;
      }
    return !0;
  }), e.attachEvent("onViewChange", r), e.attachEvent("onXLE", r), e.attachEvent("onEventChanged", r), e.attachEvent("onEventCreated", r), e.attachEvent("onEventAdded", r), e.attachEvent("onEventDeleted", r), e.attachEvent("onAfterSchedulerResize", r), e.attachEvent("onClearAll", r), e.attachEvent("onBeforeExpand", function() {
    return t = !1, !0;
  }), e.attachEvent("onBeforeCollapse", function() {
    return t = !0, !0;
  });
}, cookie: function(e) {
  function i() {
    return (e._obj.id || "scheduler") + "_settings";
  }
  const t = e.date.date_to_str("%Y-%m-%d %H:%i"), n = e.date.str_to_date("%Y-%m-%d %H:%i");
  function s() {
    const o = function(l) {
      try {
        return window.localStorage.getItem(l);
      } catch {
        return null;
      }
    }(i());
    if (!o)
      return { date: null, mode: null };
    let d;
    try {
      d = JSON.parse(o);
    } catch {
      return { date: null, mode: null };
    }
    if (!d || typeof d != "object")
      return { date: null, mode: null };
    let r = null;
    if (typeof d.date == "string" && d.date.length > 0)
      try {
        r = n(d.date), isNaN(+r) && (r = null);
      } catch {
        r = null;
      }
    return { date: r, mode: typeof d.mode == "string" ? d.mode : null };
  }
  const a = e._getInitialState;
  e._getInitialState = function(o) {
    const d = a.call(this, o);
    if (function() {
      if (!e._get_url_nav)
        return !1;
      const _ = e._get_url_nav();
      return !!_ && !!(_.date || _.mode || _.event);
    }())
      return d;
    const r = s(), l = { date: d.date, mode: d.mode };
    if (r.date && (l.date = r.date), r.mode)
      try {
        this.isViewExists(r.mode) && (l.mode = r.mode);
      } catch {
      }
    return l;
  }, e.attachEvent("onViewChange", function(o, d) {
    const r = i(), l = { date: t(d), mode: o };
    return function(_, h) {
      try {
        return window.localStorage.setItem(_, h), !0;
      } catch {
        return !1;
      }
    }(r, JSON.stringify(l)), !0;
  });
}, daytimeline: function(e) {
  ce("Day Timeline", e.assert);
}, drag_between: function(e) {
  ce("Drag Between", e.assert);
}, editors: function(e) {
  e.form_blocks.combo = { render: function(i) {
    i.cached_options || (i.cached_options = {});
    const t = i.height ? `style='height:${i.height}px;'` : "";
    var n = "";
    return n += `<div class='${i.type}' ${t}></div>`;
  }, set_value: function(i, t, n, s) {
    (function() {
      v();
      var p = e.attachEvent("onAfterLightbox", function() {
        v(), e.detachEvent(p);
      });
      function v() {
        if (i._combo && i._combo.DOMParent) {
          var g = i._combo;
          g.unload ? g.unload() : g.destructor && g.destructor(), g.DOMParent = g.DOMelem = null;
        }
      }
    })(), window.dhx_globalImgPath = s.image_path || "/", i._combo = new dhtmlXCombo(i, s.name, i.offsetWidth - 8), s.onchange && i._combo.attachEvent("onChange", s.onchange), s.options_height && i._combo.setOptionHeight(s.options_height);
    var a = i._combo;
    if (a.enableFilteringMode(s.filtering, s.script_path || null, !!s.cache), s.script_path) {
      var o = n[s.map_to];
      o ? s.cached_options[o] ? (a.addOption(o, s.cached_options[o]), a.disable(1), a.selectOption(0), a.disable(0)) : e.ajax.get(s.script_path + "?id=" + o + "&uid=" + e.uid(), function(p) {
        var v, g = p.xmlDoc.responseText;
        try {
          v = JSON.parse(g).options[0].text;
        } catch {
          v = e.ajax.xpath("//option", p.xmlDoc)[0].childNodes[0].nodeValue;
        }
        s.cached_options[o] = v, a.addOption(o, v), a.disable(1), a.selectOption(0), a.disable(0);
      }) : a.setComboValue("");
    } else {
      for (var d = [], r = 0; r < s.options.length; r++) {
        var l = s.options[r], _ = [l.key, l.label, l.css];
        d.push(_);
      }
      if (a.addOption(d), n[s.map_to]) {
        var h = a.getIndexByValue(n[s.map_to]);
        a.selectOption(h);
      }
    }
  }, get_value: function(i, t, n) {
    var s = i._combo.getSelectedValue();
    return n.script_path && (n.cached_options[s] = i._combo.getSelectedText()), s;
  }, focus: function(i) {
  } }, e.form_blocks.radio = { render: function(i) {
    var t = "";
    t += `<div class='dhx_cal_ltext dhx_cal_radio ${i.vertical ? "dhx_cal_radio_vertical" : ""}' style='height:${i.height}px;'>`;
    for (var n = 0; n < i.options.length; n++) {
      var s = e.uid();
      t += "<label class='dhx_cal_radio_item' for='" + s + "'><input id='" + s + "' type='radio' name='" + i.name + "' value='" + i.options[n].key + "'><span> " + i.options[n].label + "</span></label>";
    }
    return t += "</div>";
  }, set_value: function(i, t, n, s) {
    for (var a = i.getElementsByTagName("input"), o = 0; o < a.length; o++) {
      a[o].checked = !1;
      var d = n[s.map_to] || t;
      a[o].value == d && (a[o].checked = !0);
    }
  }, get_value: function(i, t, n) {
    for (var s = i.getElementsByTagName("input"), a = 0; a < s.length; a++)
      if (s[a].checked)
        return s[a].value;
  }, focus: function(i) {
  } }, e.form_blocks.checkbox = { render: function(i) {
    return e.config.wide_form ? '<div class="dhx_cal_wide_checkbox"></div>' : "";
  }, set_value: function(i, t, n, s) {
    i = e._lightbox.querySelector(`#${s.id}`), s.height && (i.style.height = `${s.height}px`);
    var a = e.uid(), o = s.checked_value !== void 0 ? t == s.checked_value : !!t;
    i.className += " dhx_cal_checkbox";
    var d = "<input id='" + a + "' type='checkbox' value='true' name='" + s.name + "'" + (o ? "checked='true'" : "") + "'>", r = "<label for='" + a + "'>" + (e.locale.labels["section_" + s.name] || s.name) + "</label>";
    if (e.config.wide_form ? (i.innerHTML = r, i.nextSibling.innerHTML = d) : i.innerHTML = d + r, s.handler) {
      var l = i.getElementsByTagName("input")[0];
      if (l.$_eventAttached)
        return;
      l.$_eventAttached = !0, e.event(l, "click", s.handler);
    }
  }, get_value: function(i, t, n) {
    var s = (i = e._lightbox.querySelector(`#${n.id}`)).getElementsByTagName("input")[0];
    return s || (s = i.nextSibling.getElementsByTagName("input")[0]), s.checked ? n.checked_value || !0 : n.unchecked_value || !1;
  }, focus: function(i) {
  } };
}, expand: function(e) {
  e.ext.fullscreen = { toggleIcon: null }, e.expand = function() {
    if (e.callEvent("onBeforeExpand", [])) {
      var i = e._obj;
      do
        i._position = i.style.position || "", i.style.position = "static";
      while ((i = i.parentNode) && i.style);
      (i = e._obj).style.position = "absolute", i._width = i.style.width, i._height = i.style.height, i.style.width = i.style.height = "100%", i.style.top = i.style.left = "0px";
      var t = document.body;
      t.scrollTop = 0, (t = t.parentNode) && (t.scrollTop = 0), document.body._overflow = document.body.style.overflow || "", document.body.style.overflow = "hidden", e._maximize(), e.callEvent("onExpand", []);
    }
  }, e.collapse = function() {
    if (e.callEvent("onBeforeCollapse", [])) {
      var i = e._obj;
      do
        i.style.position = i._position;
      while ((i = i.parentNode) && i.style);
      (i = e._obj).style.width = i._width, i.style.height = i._height, document.body.style.overflow = document.body._overflow, e._maximize(), e.callEvent("onCollapse", []);
    }
  }, e.attachEvent("onTemplatesReady", function() {
    var i = document.createElement("div");
    i.className = "dhx_expand_icon", e.ext.fullscreen.toggleIcon = i, i.innerHTML = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
	<g>
	<line x1="0.5" y1="5" x2="0.5" y2="3.0598e-08" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line y1="0.5" x2="5" y2="0.5" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line x1="0.5" y1="11" x2="0.5" y2="16" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line y1="15.5" x2="5" y2="15.5" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line x1="11" y1="0.5" x2="16" y2="0.5" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line x1="15.5" y1="2.18557e-08" x2="15.5" y2="5" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line x1="11" y1="15.5" x2="16" y2="15.5" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	<line x1="15.5" y1="16" x2="15.5" y2="11" stroke="var(--dhx-scheduler-base-colors-icons)"/>
	</g>
	</svg>
	`, e._obj.appendChild(i), e.event(i, "click", function() {
      e.expanded ? e.collapse() : e.expand();
    });
  }), e._maximize = function() {
    this.expanded = !this.expanded, this.expanded ? this.ext.fullscreen.toggleIcon.classList.add("dhx_expand_icon--expanded") : this.ext.fullscreen.toggleIcon.classList.remove("dhx_expand_icon--expanded");
    for (var i = ["left", "top"], t = 0; t < i.length; t++) {
      var n = e["_prev_margin_" + i[t]];
      e.xy["margin_" + i[t]] ? (e["_prev_margin_" + i[t]] = e.xy["margin_" + i[t]], e.xy["margin_" + i[t]] = 0) : n && (e.xy["margin_" + i[t]] = e["_prev_margin_" + i[t]], delete e["_prev_margin_" + i[t]]);
    }
    e.setCurrentView();
  };
}, export_api: function(e) {
  (function() {
    function i(n, s) {
      for (var a in s)
        n[a] || (n[a] = s[a]);
      return n;
    }
    function t(n, s) {
      var a = {};
      return (n = s._els[n]) && n[0] ? (a.x = n[0].scrollWidth, a.y = n[0].scrollHeight) : (a.x = 0, a.y = 0), a;
    }
    window.dhtmlxAjax || (window.dhtmlxAjax = { post: function(n, s, a) {
      return window.dhx4.ajax.post(n, s, a);
    }, get: function(n, s) {
      return window.ajax.get(n, s);
    } }), function(n) {
      function s() {
        var a = n.getState().mode;
        return n.matrix && n.matrix[a] ? n.matrix[a] : null;
      }
      n.exportToPDF = function(a) {
        (a = i(a || {}, { name: "calendar.pdf", format: "A4", orientation: "landscape", dpi: 96, zoom: 1, rtl: n.config.rtl })).html = this._export_html(a), a.mode = this.getState().mode, this._send_to_export(a, "pdf");
      }, n.exportToPNG = function(a) {
        (a = i(a || {}, { name: "calendar.png", format: "A4", orientation: "landscape", dpi: 96, zoom: 1, rtl: n.config.rtl })).html = this._export_html(a), a.mode = this.getState().mode, this._send_to_export(a, "png");
      }, n.exportToICal = function(a) {
        a = i(a || {}, { name: "calendar.ical", data: this._serialize_plain(null, a) }), this._send_to_export(a, "ical");
      }, n.exportToExcel = function(a) {
        a = i(a || {}, { name: "calendar.xlsx", title: "Events", data: this._serialize_plain(this.templates.xml_format, a), columns: this._serialize_columns() }), this._send_to_export(a, "excel");
      }, n._ajax_to_export = function(a, o, d) {
        delete a.callback;
        var r = a.server || "https://export.dhtmlx.com/scheduler";
        window.dhtmlxAjax.post(r, "type=" + o + "&store=1&data=" + encodeURIComponent(JSON.stringify(a)), function(l) {
          var _ = null;
          if (!(l.xmlDoc.status > 400))
            try {
              _ = JSON.parse(l.xmlDoc.responseText);
            } catch {
            }
          d(_);
        });
      }, n._plain_export_copy = function(a, o) {
        var d = {};
        for (var r in a)
          d[r] = a[r];
        return d.start_date = o(d.start_date), d.end_date = o(d.end_date), d.$text = this.templates.event_text(a.start_date, a.end_date, a), d;
      }, n._serialize_plain = function(a, o) {
        var d;
        a = a || n.date.date_to_str("%Y%m%dT%H%i%s", !0), d = o && o.start && o.end ? n.getEvents(o.start, o.end) : n.getEvents();
        for (var r = [], l = 0; l < d.length; l++)
          r[l] = this._plain_export_copy(d[l], a);
        return r;
      }, n._serialize_columns = function() {
        return [{ id: "start_date", header: "Start Date", width: 30 }, { id: "end_date", header: "End Date", width: 30 }, { id: "$text", header: "Text", width: 100 }];
      }, n._send_to_export = function(a, o) {
        if (a.version || (a.version = n.version), a.skin || (a.skin = n.skin), a.callback)
          return n._ajax_to_export(a, o, a.callback);
        var d = this._create_hidden_form();
        d.firstChild.action = a.server || "https://export.dhtmlx.com/scheduler", d.firstChild.childNodes[0].value = JSON.stringify(a), d.firstChild.childNodes[1].value = o, d.firstChild.submit();
      }, n._create_hidden_form = function() {
        if (!this._hidden_export_form) {
          var a = this._hidden_export_form = document.createElement("div");
          a.style.display = "none", a.innerHTML = "<form method='POST' target='_blank'><input type='text' name='data'><input type='hidden' name='type' value=''></form>", document.body.appendChild(a);
        }
        return this._hidden_export_form;
      }, n._get_export_size = function(a, o, d, r, l, _, h) {
        r = parseInt(r) / 25.4 || 4;
        var p = { A5: { x: 148, y: 210 }, A4: { x: 210, y: 297 }, A3: { x: 297, y: 420 }, A2: { x: 420, y: 594 }, A1: { x: 594, y: 841 }, A0: { x: 841, y: 1189 } }, v = t("dhx_cal_data", this).x, g = { y: t("dhx_cal_data", this).y + t("dhx_cal_header", this).y + t("dhx_multi_day", this).y };
        return g.x = a === "full" ? v : Math.floor((o === "landscape" ? p[a].y : p[a].x) * r), h && (g.x *= parseFloat(h.x) || 1, g.y *= parseFloat(h.y) || 1), g;
      }, n._export_html = function(a) {
        var o, d, r, l = (o = void 0, d = void 0, (r = s()) && (d = r.scrollable, o = r.smart_rendering), { nav_height: n.xy.nav_height, scroll_width: n.xy.scroll_width, style_width: n._obj.style.width, style_height: n._obj.style.height, timeline_scrollable: d, timeline_smart_rendering: o }), _ = n._get_export_size(a.format, a.orientation, a.zoom, a.dpi, a.header, a.footer, a.scales), h = "";
        try {
          (function(p, v) {
            n._obj.style.width = p.x + "px", n._obj.style.height = p.y + "px", n.xy.nav_height = 0, n.xy.scroll_width = 0;
            var g = s();
            (v.timeline_scrollable || v.timeline_smart_rendering) && (g.scrollable = !1, g.smart_rendering = !1);
          })(_, l), n.setCurrentView(), h = n._obj.innerHTML;
        } catch (p) {
          console.error(p);
        } finally {
          (function(p) {
            n.xy.scroll_width = p.scroll_width, n.xy.nav_height = p.nav_height, n._obj.style.width = p.style_width, n._obj.style.height = p.style_height;
            var v = s();
            (p.timeline_scrollable || p.timeline_smart_rendering) && (v.scrollable = p.timeline_scrollable, v.smart_rendering = p.timeline_smart_rendering);
          })(l), n.setCurrentView();
        }
        return h;
      };
    }(e);
  })();
}, grid_view: function(e) {
  ce("Grid", e.assert);
}, html_templates: function(e) {
  e.attachEvent("onTemplatesReady", function() {
    for (var i = document.body.getElementsByTagName("DIV"), t = 0; t < i.length; t++) {
      var n = i[t].className || "";
      if ((n = n.split(":")).length == 2 && n[0] == "template") {
        var s = 'return "' + (i[t].innerHTML || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\n\r]+/g, "") + '";';
        s = unescape(s).replace(/\{event\.([a-z]+)\}/g, function(a, o) {
          return '"+ev.' + o + '+"';
        }), e.templates[n[1]] = Function("start", "end", "ev", s), i[t].style.display = "none";
      }
    }
  });
}, key_nav: function(e) {
  function i(t) {
    var n = { minicalButton: e.$keyboardNavigation.MinicalButton, minicalDate: e.$keyboardNavigation.MinicalCell, scheduler: e.$keyboardNavigation.SchedulerNode, dataArea: e.$keyboardNavigation.DataArea, timeSlot: e.$keyboardNavigation.TimeSlot, event: e.$keyboardNavigation.Event }, s = {};
    for (var a in n)
      s[a.toLowerCase()] = n[a];
    return s[t = (t + "").toLowerCase()] || n.scheduler;
  }
  e.config.key_nav = !0, e.config.key_nav_step = 30, e.addShortcut = function(t, n, s) {
    var a = i(s);
    a && a.prototype.bind(t, n);
  }, e.getShortcutHandler = function(t, n) {
    var s = i(n);
    if (s) {
      var a = e.$keyboardNavigation.shortcuts.parse(t);
      if (a.length)
        return s.prototype.findHandler(a[0]);
    }
  }, e.removeShortcut = function(t, n) {
    var s = i(n);
    s && s.prototype.unbind(t);
  }, e.focus = function() {
    if (e.config.key_nav) {
      var t = e.$keyboardNavigation.dispatcher;
      t.enable();
      var n = t.getActiveNode();
      !n || n instanceof e.$keyboardNavigation.MinicalButton || n instanceof e.$keyboardNavigation.MinicalCell ? t.setDefaultNode() : t.focusNode(t.getActiveNode());
    }
  }, e.$keyboardNavigation = {}, e._compose = function() {
    for (var t = Array.prototype.slice.call(arguments, 0), n = {}, s = 0; s < t.length; s++) {
      var a = t[s];
      for (var o in typeof a == "function" && (a = new a()), a)
        n[o] = a[o];
    }
    return n;
  }, function(t) {
    t.$keyboardNavigation.shortcuts = { createCommand: function() {
      return { modifiers: { shift: !1, alt: !1, ctrl: !1, meta: !1 }, keyCode: null };
    }, parse: function(n) {
      for (var s = [], a = this.getExpressions(this.trim(n)), o = 0; o < a.length; o++) {
        for (var d = this.getWords(a[o]), r = this.createCommand(), l = 0; l < d.length; l++)
          this.commandKeys[d[l]] ? r.modifiers[d[l]] = !0 : this.specialKeys[d[l]] ? r.keyCode = this.specialKeys[d[l]] : r.keyCode = d[l].charCodeAt(0);
        s.push(r);
      }
      return s;
    }, getCommandFromEvent: function(n) {
      var s = this.createCommand();
      s.modifiers.shift = !!n.shiftKey, s.modifiers.alt = !!n.altKey, s.modifiers.ctrl = !!n.ctrlKey, s.modifiers.meta = !!n.metaKey, s.keyCode = n.which || n.keyCode, s.keyCode >= 96 && s.keyCode <= 105 && (s.keyCode -= 48);
      var a = String.fromCharCode(s.keyCode);
      return a && (s.keyCode = a.toLowerCase().charCodeAt(0)), s;
    }, getHashFromEvent: function(n) {
      return this.getHash(this.getCommandFromEvent(n));
    }, getHash: function(n) {
      var s = [];
      for (var a in n.modifiers)
        n.modifiers[a] && s.push(a);
      return s.push(n.keyCode), s.join(this.junctionChar);
    }, getExpressions: function(n) {
      return n.split(this.junctionChar);
    }, getWords: function(n) {
      return n.split(this.combinationChar);
    }, trim: function(n) {
      return n.replace(/\s/g, "");
    }, junctionChar: ",", combinationChar: "+", commandKeys: { shift: 16, alt: 18, ctrl: 17, meta: !0 }, specialKeys: { backspace: 8, tab: 9, enter: 13, esc: 27, space: 32, up: 38, down: 40, left: 37, right: 39, home: 36, end: 35, pageup: 33, pagedown: 34, delete: 46, insert: 45, plus: 107, f1: 112, f2: 113, f3: 114, f4: 115, f5: 116, f6: 117, f7: 118, f8: 119, f9: 120, f10: 121, f11: 122, f12: 123 } };
  }(e), function(t) {
    t.$keyboardNavigation.EventHandler = { _handlers: null, findHandler: function(n) {
      this._handlers || (this._handlers = {});
      var s = t.$keyboardNavigation.shortcuts.getHash(n);
      return this._handlers[s];
    }, doAction: function(n, s) {
      var a = this.findHandler(n);
      a && (a.call(this, s), s.preventDefault ? s.preventDefault() : s.returnValue = !1);
    }, bind: function(n, s) {
      this._handlers || (this._handlers = {});
      for (var a = t.$keyboardNavigation.shortcuts, o = a.parse(n), d = 0; d < o.length; d++)
        this._handlers[a.getHash(o[d])] = s;
    }, unbind: function(n) {
      for (var s = t.$keyboardNavigation.shortcuts, a = s.parse(n), o = 0; o < a.length; o++)
        this._handlers[s.getHash(a[o])] && delete this._handlers[s.getHash(a[o])];
    }, bindAll: function(n) {
      for (var s in n)
        this.bind(s, n[s]);
    }, initKeys: function() {
      this._handlers || (this._handlers = {}), this.keys && this.bindAll(this.keys);
    } };
  }(e), function(t) {
    t.$keyboardNavigation.getFocusableNodes = t._getFocusableNodes, t.$keyboardNavigation.trapFocus = function(n, s) {
      if (s.keyCode != 9)
        return !1;
      for (var a, o = t.$keyboardNavigation.getFocusableNodes(n), d = document.activeElement, r = -1, l = 0; l < o.length; l++)
        if (o[l] == d) {
          r = l;
          break;
        }
      if (s.shiftKey) {
        if (a = o[r <= 0 ? o.length - 1 : r - 1])
          return a.focus(), s.preventDefault(), !0;
      } else if (a = o[r >= o.length - 1 ? 0 : r + 1])
        return a.focus(), s.preventDefault(), !0;
      return !1;
    };
  }(e), function(t) {
    t.$keyboardNavigation.marker = { clear: function() {
      for (var n = t.$container.querySelectorAll(".dhx_focus_slot"), s = 0; s < n.length; s++)
        n[s].parentNode.removeChild(n[s]);
    }, createElement: function() {
      var n = document.createElement("div");
      return n.setAttribute("tabindex", -1), n.className = "dhx_focus_slot", n;
    }, renderMultiple: function(n, s, a) {
      for (var o = [], d = new Date(n), r = new Date(Math.min(s.valueOf(), t.date.add(t.date.day_start(new Date(n)), 1, "day").valueOf())); d.valueOf() < s.valueOf(); )
        o = o.concat(a.call(this, d, new Date(Math.min(r.valueOf(), s.valueOf())))), d = t.date.day_start(t.date.add(d, 1, "day")), r = t.date.day_start(t.date.add(d, 1, "day")), r = new Date(Math.min(r.valueOf(), s.valueOf()));
      return o;
    }, render: function(n, s, a) {
      this.clear();
      var o = [], d = t.$keyboardNavigation.TimeSlot.prototype._modes;
      switch (t.$keyboardNavigation.TimeSlot.prototype._getMode()) {
        case d.units:
          o = this.renderVerticalMarker(n, s, a);
          break;
        case d.timeline:
          o = this.renderTimelineMarker(n, s, a);
          break;
        case d.year:
          o = o.concat(this.renderMultiple(n, s, this.renderYearMarker));
          break;
        case d.month:
          o = this.renderMonthMarker(n, s);
          break;
        case d.weekAgenda:
          o = o.concat(this.renderMultiple(n, s, this.renderWeekAgendaMarker));
          break;
        case d.list:
          o = this.renderAgendaMarker(n, s);
          break;
        case d.dayColumns:
          o = o.concat(this.renderMultiple(n, s, this.renderVerticalMarker));
      }
      this.addWaiAriaLabel(o, n, s, a), this.addDataAttributes(o, n, s, a);
      for (var r = o.length - 1; r >= 0; r--)
        if (o[r].offsetWidth)
          return o[r];
      return null;
    }, addDataAttributes: function(n, s, a, o) {
      for (var d = t.date.date_to_str(t.config.api_date), r = d(s), l = d(a), _ = 0; _ < n.length; _++)
        n[_].setAttribute("data-start-date", r), n[_].setAttribute("data-end-date", l), o && n[_].setAttribute("data-section", o);
    }, addWaiAriaLabel: function(n, s, a, o) {
      var d = "", r = t.getState().mode, l = !1;
      if (d += t.templates.day_date(s), t.date.day_start(new Date(s)).valueOf() != s.valueOf() && (d += " " + t.templates.hour_scale(s), l = !0), t.date.day_start(new Date(s)).valueOf() != t.date.day_start(new Date(a)).valueOf() && (d += " - " + t.templates.day_date(a), (l || t.date.day_start(new Date(a)).valueOf() != a.valueOf()) && (d += " " + t.templates.hour_scale(a))), o) {
        if (t.matrix && t.matrix[r]) {
          const h = t.matrix[r], p = h.y_unit[h.order[o]];
          d += ", " + t.templates[r + "_scale_label"](p.key, p.label, p);
        } else if (t._props && t._props[r]) {
          const h = t._props[r], p = h.options[h.order[o]];
          d += ", " + t.templates[r + "_scale_text"](p.key, p.label, p);
        }
      }
      for (var _ = 0; _ < n.length; _++)
        t._waiAria.setAttributes(n[_], { "aria-label": d, "aria-live": "polite" });
    }, renderWeekAgendaMarker: function(n, s) {
      for (var a = t.$container.querySelectorAll(".dhx_wa_day_cont .dhx_wa_scale_bar"), o = t.date.week_start(new Date(t.getState().min_date)), d = -1, r = t.date.day_start(new Date(n)), l = 0; l < a.length && (d++, t.date.day_start(new Date(o)).valueOf() != r.valueOf()); l++)
        o = t.date.add(o, 1, "day");
      return d != -1 ? this._wrapDiv(a[d]) : [];
    }, _wrapDiv: function(n) {
      var s = this.createElement();
      return s.style.top = n.offsetTop + "px", s.style.left = n.offsetLeft + "px", s.style.width = n.offsetWidth + "px", s.style.height = n.offsetHeight + "px", n.appendChild(s), [s];
    }, renderYearMarker: function(n, s) {
      var a = t._get_year_cell(n);
      a.style.position = "relative";
      var o = this.createElement();
      return o.style.top = "0px", o.style.left = "0px", o.style.width = "100%", o.style.height = "100%", a.appendChild(o), [o];
    }, renderAgendaMarker: function(n, s) {
      var a = this.createElement();
      return a.style.height = "1px", a.style.width = "100%", a.style.opacity = 1, a.style.top = "0px", a.style.left = "0px", t.$container.querySelector(".dhx_cal_data").appendChild(a), [a];
    }, renderTimelineMarker: function(n, s, a) {
      var o = t._lame_copy({}, t.matrix[t._mode]), d = o._scales;
      o.round_position = !1;
      var r = [], l = n ? new Date(n) : t._min_date, _ = s ? new Date(s) : t._max_date;
      if (l.valueOf() < t._min_date.valueOf() && (l = new Date(t._min_date)), _.valueOf() > t._max_date.valueOf() && (_ = new Date(t._max_date)), !o._trace_x)
        return r;
      for (var h = 0; h < o._trace_x.length && !t._is_column_visible(o._trace_x[h]); h++)
        ;
      if (h == o._trace_x.length)
        return r;
      var p = d[a];
      if (!(l < s && _ > n))
        return r;
      var v = this.createElement();
      let g, c;
      function f(M, k) {
        k.setDate(1), k.setFullYear(M.getFullYear()), k.setMonth(M.getMonth()), k.setDate(M.getDate());
      }
      if (t.getView().days) {
        const M = new Date(n);
        f(t._min_date, M);
        const k = new Date(s);
        f(t._min_date, k), g = t._timeline_getX({ start_date: M }, !1, o), c = t._timeline_getX({ start_date: k }, !1, o);
      } else
        g = t._timeline_getX({ start_date: n }, !1, o), c = t._timeline_getX({ start_date: s }, !1, o);
      var u = o._section_height[a] - 1 || o.dy - 1, y = 0;
      t._isRender("cell") && (y = p.offsetTop, g += o.dx, c += o.dx, p = t.$container.querySelector(".dhx_cal_data"));
      var w = Math.max(1, c - g - 1);
      let D = "left";
      return t.config.rtl && (D = "right"), v.style.cssText = `height:${u}px; ${D}:${g}px; width:${w}px; top:${y}px;`, p && (p.appendChild(v), r.push(v)), r;
    }, renderMonthCell: function(n) {
      for (var s = t.$container.querySelectorAll(".dhx_month_head"), a = [], o = 0; o < s.length; o++)
        a.push(s[o].parentNode);
      var d = -1, r = 0, l = -1, _ = t.date.week_start(new Date(t.getState().min_date)), h = t.date.day_start(new Date(n));
      for (o = 0; o < a.length && (d++, l == 6 ? (r++, l = 0) : l++, t.date.day_start(new Date(_)).valueOf() != h.valueOf()); o++)
        _ = t.date.add(_, 1, "day");
      if (d == -1)
        return [];
      var p = t._colsS[l], v = t._colsS.heights[r], g = this.createElement();
      g.style.top = v + "px", g.style.left = p + "px", g.style.width = t._cols[l] + "px", g.style.height = (t._colsS.heights[r + 1] - v || t._colsS.height) + "px";
      var c = t.$container.querySelector(".dhx_cal_data"), f = c.querySelector(".dhx_cal_month_table");
      return f.nextSibling ? c.insertBefore(g, f.nextSibling) : c.appendChild(g), g;
    }, renderMonthMarker: function(n, s) {
      for (var a = [], o = n; o.valueOf() < s.valueOf(); )
        a.push(this.renderMonthCell(o)), o = t.date.add(o, 1, "day");
      return a;
    }, renderVerticalMarker: function(n, s, a) {
      var o = t.locate_holder_day(n), d = [], r = null, l = t.config;
      if (t._ignores[o])
        return d;
      if (t._props && t._props[t._mode] && a) {
        var _ = t._props[t._mode];
        o = _.order[a];
        var h = _.order[a];
        _.days > 1 ? o = t.locate_holder_day(n) + h : (o = h, _.size && o > _.position + _.size && (o = 0));
      }
      if (!(r = t.locate_holder(o)) || r.querySelector(".dhx_scale_hour"))
        return document.createElement("div");
      var p = Math.max(60 * n.getHours() + n.getMinutes(), 60 * l.first_hour), v = Math.min(60 * s.getHours() + s.getMinutes(), 60 * l.last_hour);
      if (!v && t.date.day_start(new Date(s)).valueOf() > t.date.day_start(new Date(n)).valueOf() && (v = 60 * l.last_hour), v <= p)
        return [];
      var g = this.createElement(), c = t.config.hour_size_px * l.last_hour + 1, f = 36e5;
      return g.style.top = Math.round((60 * p * 1e3 - t.config.first_hour * f) * t.config.hour_size_px / f) % c + "px", g.style.lineHeight = g.style.height = Math.max(Math.round(60 * (v - p) * 1e3 * t.config.hour_size_px / f) % c, 1) + "px", g.style.width = "100%", r.appendChild(g), d.push(g), d[0];
    } };
  }(e), function(t) {
    t.$keyboardNavigation.SchedulerNode = function() {
    }, t.$keyboardNavigation.SchedulerNode.prototype = t._compose(t.$keyboardNavigation.EventHandler, { getDefaultNode: function() {
      var n = new t.$keyboardNavigation.TimeSlot();
      return n.isValid() || (n = n.fallback()), n;
    }, _modes: { month: "month", year: "year", dayColumns: "dayColumns", timeline: "timeline", units: "units", weekAgenda: "weekAgenda", list: "list" }, getMode: function() {
      var n = t.getState().mode;
      return t.matrix && t.matrix[n] ? this._modes.timeline : t._props && t._props[n] ? this._modes.units : n == "month" ? this._modes.month : n == "year" ? this._modes.year : n == "week_agenda" ? this._modes.weekAgenda : n == "map" || n == "agenda" || t._grid && t["grid_" + n] ? this._modes.list : this._modes.dayColumns;
    }, focus: function() {
      t.focus();
    }, blur: function() {
    }, disable: function() {
      t.$container.setAttribute("tabindex", "0");
    }, enable: function() {
      t.$container && t.$container.removeAttribute("tabindex");
    }, isEnabled: function() {
      return t.$container.hasAttribute("tabindex");
    }, _compareEvents: function(n, s) {
      return n.start_date.valueOf() == s.start_date.valueOf() ? n.id > s.id ? 1 : -1 : n.start_date.valueOf() > s.start_date.valueOf() ? 1 : -1;
    }, _pickEvent: function(n, s, a, o) {
      var d = t.getState();
      n = new Date(Math.max(d.min_date.valueOf(), n.valueOf())), s = new Date(Math.min(d.max_date.valueOf(), s.valueOf()));
      var r = t.getEvents(n, s);
      r.sort(this._compareEvents), o && (r = r.reverse());
      for (var l = !!a, _ = 0; _ < r.length && l; _++)
        r[_].id == a && (l = !1), r.splice(_, 1), _--;
      for (_ = 0; _ < r.length; _++)
        if (new t.$keyboardNavigation.Event(r[_].id).getNode())
          return r[_];
      return null;
    }, nextEventHandler: function(n) {
      var s = t.$keyboardNavigation.dispatcher.activeNode, a = n || s && s.eventId, o = null;
      if (a && t.getEvent(a)) {
        var d = t.getEvent(a);
        o = t.$keyboardNavigation.SchedulerNode.prototype._pickEvent(d.start_date, t.date.add(d.start_date, 1, "year"), d.id, !1);
      }
      if (!o && !n) {
        var r = t.getState();
        o = t.$keyboardNavigation.SchedulerNode.prototype._pickEvent(r.min_date, t.date.add(r.min_date, 1, "year"), null, !1);
      }
      if (o) {
        var l = new t.$keyboardNavigation.Event(o.id);
        l.isValid() ? (s && s.blur(), t.$keyboardNavigation.dispatcher.setActiveNode(l)) : this.nextEventHandler(o.id);
      }
    }, prevEventHandler: function(n) {
      var s = t.$keyboardNavigation.dispatcher.activeNode, a = n || s && s.eventId, o = null;
      if (a && t.getEvent(a)) {
        var d = t.getEvent(a);
        o = t.$keyboardNavigation.SchedulerNode.prototype._pickEvent(t.date.add(d.end_date, -1, "year"), d.end_date, d.id, !0);
      }
      if (!o && !n) {
        var r = t.getState();
        o = t.$keyboardNavigation.SchedulerNode.prototype._pickEvent(t.date.add(r.max_date, -1, "year"), r.max_date, null, !0);
      }
      if (o) {
        var l = new t.$keyboardNavigation.Event(o.id);
        l.isValid() ? (s && s.blur(), t.$keyboardNavigation.dispatcher.setActiveNode(l)) : this.prevEventHandler(o.id);
      }
    }, keys: { "alt+1, alt+2, alt+3, alt+4, alt+5, alt+6, alt+7, alt+8, alt+9": function(n) {
      const s = t.$keyboardNavigation.HeaderCell.prototype.getNodes(".dhx_cal_navline .dhx_cal_tab"), a = n.code;
      let o = parseInt(a.replace("Digit", ""));
      s[o - 1] && s[o - 1].click();
    }, "ctrl+left,meta+left": function(n) {
      t._click.dhx_cal_prev_button();
    }, "ctrl+right,meta+right": function(n) {
      t._click.dhx_cal_next_button();
    }, "ctrl+up,meta+up": function(n) {
      t.$container.querySelector(".dhx_cal_data").scrollTop -= 20;
    }, "ctrl+down,meta+down": function(n) {
      t.$container.querySelector(".dhx_cal_data").scrollTop += 20;
    }, e: function() {
      this.nextEventHandler();
    }, home: function() {
      t.setCurrentView(/* @__PURE__ */ new Date());
    }, "shift+e": function() {
      this.prevEventHandler();
    }, "ctrl+enter,meta+enter": function() {
      t.addEventNow({ start_date: new Date(t.getState().date) });
    }, "ctrl+c,meta+c": function(n) {
      t._key_nav_copy_paste(n);
    }, "ctrl+v,meta+v": function(n) {
      t._key_nav_copy_paste(n);
    }, "ctrl+x,meta+x": function(n) {
      t._key_nav_copy_paste(n);
    } } }), t.$keyboardNavigation.SchedulerNode.prototype.bindAll(t.$keyboardNavigation.SchedulerNode.prototype.keys);
  }(e), function(t) {
    t.$keyboardNavigation.KeyNavNode = function() {
    }, t.$keyboardNavigation.KeyNavNode.prototype = t._compose(t.$keyboardNavigation.EventHandler, { isValid: function() {
      return !0;
    }, fallback: function() {
      return null;
    }, moveTo: function(n) {
      t.$keyboardNavigation.dispatcher.setActiveNode(n);
    }, compareTo: function(n) {
      if (!n)
        return !1;
      for (var s in this) {
        if (!!this[s] != !!n[s])
          return !1;
        var a = !(!this[s] || !this[s].toString), o = !(!n[s] || !n[s].toString);
        if (o != a)
          return !1;
        if (o && a) {
          if (n[s].toString() != this[s].toString())
            return !1;
        } else if (n[s] != this[s])
          return !1;
      }
      return !0;
    }, getNode: function() {
    }, focus: function() {
      var n = this.getNode();
      n && (n.setAttribute("tabindex", "-1"), n.focus && n.focus());
    }, blur: function() {
      var n = this.getNode();
      n && n.setAttribute("tabindex", "-1");
    } });
  }(e), function(t) {
    t.$keyboardNavigation.HeaderCell = function(n) {
      this.index = n || 0;
    }, t.$keyboardNavigation.HeaderCell.prototype = t._compose(t.$keyboardNavigation.KeyNavNode, { getNode: function(n) {
      n = n || this.index || 0;
      var s = this.getNodes();
      if (s[n])
        return s[n];
    }, getNodes: function(n) {
      n = n || [".dhx_cal_navline .dhx_cal_prev_button", ".dhx_cal_navline .dhx_cal_next_button", ".dhx_cal_navline .dhx_cal_today_button", ".dhx_cal_navline .dhx_cal_tab"].join(", ");
      var s = Array.prototype.slice.call(t.$container.querySelectorAll(n));
      return s.sort(function(a, o) {
        return a.offsetLeft - o.offsetLeft;
      }), s;
    }, _handlers: null, isValid: function() {
      return !!this.getNode(this.index);
    }, fallback: function() {
      var n = this.getNode(0);
      return n || (n = new t.$keyboardNavigation.TimeSlot()), n;
    }, keys: { left: function() {
      var n = this.index - 1;
      n < 0 && (n = this.getNodes().length - 1), this.moveTo(new t.$keyboardNavigation.HeaderCell(n));
    }, right: function() {
      var n = this.index + 1;
      n >= this.getNodes().length && (n = 0), this.moveTo(new t.$keyboardNavigation.HeaderCell(n));
    }, down: function() {
      this.moveTo(new t.$keyboardNavigation.TimeSlot());
    }, enter: function() {
      var n = this.getNode();
      n && n.click();
    } } }), t.$keyboardNavigation.HeaderCell.prototype.bindAll(t.$keyboardNavigation.HeaderCell.prototype.keys);
  }(e), function(t) {
    t.$keyboardNavigation.Event = function(n) {
      if (this.eventId = null, t.getEvent(n)) {
        var s = t.getEvent(n);
        this.start = new Date(s.start_date), this.end = new Date(s.end_date), this.section = this._getSection(s), this.eventId = n;
      }
    }, t.$keyboardNavigation.Event.prototype = t._compose(t.$keyboardNavigation.KeyNavNode, { _getNodes: function() {
      return Array.prototype.slice.call(t.$container.querySelectorAll("[" + t.config.event_attribute + "]"));
    }, _modes: t.$keyboardNavigation.SchedulerNode.prototype._modes, getMode: t.$keyboardNavigation.SchedulerNode.prototype.getMode, _handlers: null, isValid: function() {
      return !(!t.getEvent(this.eventId) || !this.getNode());
    }, fallback: function() {
      var n = this._getNodes()[0], s = null;
      if (n && t._locate_event(n)) {
        var a = t._locate_event(n);
        s = new t.$keyboardNavigation.Event(a);
      } else
        s = new t.$keyboardNavigation.TimeSlot();
      return s;
    }, isScrolledIntoView: function(n) {
      var s = n.getBoundingClientRect(), a = t.$container.querySelector(".dhx_cal_data").getBoundingClientRect();
      return !(s.bottom < a.top || s.top > a.bottom);
    }, getNode: function() {
      var n = "[" + t.config.event_attribute + "='" + this.eventId + "']", s = t.$keyboardNavigation.dispatcher.getInlineEditor(this.eventId);
      if (s)
        return s;
      if (t.isMultisectionEvent && t.isMultisectionEvent(t.getEvent(this.eventId))) {
        for (var a = t.$container.querySelectorAll(n), o = 0; o < a.length; o++)
          if (this.isScrolledIntoView(a[o]))
            return a[o];
        return a[0];
      }
      return t.$container.querySelector(n);
    }, focus: function() {
      var n = t.getEvent(this.eventId), s = t.getState();
      (n.start_date.valueOf() > s.max_date.valueOf() || n.end_date.valueOf() <= s.min_date.valueOf()) && t.setCurrentView(n.start_date);
      var a = this.getNode();
      this.isScrolledIntoView(a) ? t.$keyboardNavigation.dispatcher.keepScrollPosition((function() {
        t.$keyboardNavigation.KeyNavNode.prototype.focus.apply(this);
      }).bind(this)) : t.$keyboardNavigation.KeyNavNode.prototype.focus.apply(this);
    }, blur: function() {
      t.$keyboardNavigation.KeyNavNode.prototype.blur.apply(this);
    }, _getSection: function(n) {
      var s = null, a = t.getState().mode;
      return t.matrix && t.matrix[a] ? s = n[t.matrix[t.getState().mode].y_property] : t._props && t._props[a] && (s = n[t._props[a].map_to]), s;
    }, _moveToSlot: function(n) {
      var s = t.getEvent(this.eventId);
      if (s) {
        var a = this._getSection(s), o = new t.$keyboardNavigation.TimeSlot(s.start_date, null, a);
        this.moveTo(o.nextSlot(o, n));
      } else
        this.moveTo(new t.$keyboardNavigation.TimeSlot());
    }, keys: { left: function() {
      this._moveToSlot("left");
    }, right: function() {
      this._moveToSlot("right");
    }, down: function() {
      this.getMode() == this._modes.list ? t.$keyboardNavigation.SchedulerNode.prototype.nextEventHandler() : this._moveToSlot("down");
    }, space: function() {
      var n = this.getNode();
      n && n.click ? n.click() : this.moveTo(new t.$keyboardNavigation.TimeSlot());
    }, up: function() {
      this.getMode() == this._modes.list ? t.$keyboardNavigation.SchedulerNode.prototype.prevEventHandler() : this._moveToSlot("up");
    }, delete: function() {
      t.getEvent(this.eventId) ? t._click.buttons.delete(this.eventId) : this.moveTo(new t.$keyboardNavigation.TimeSlot());
    }, enter: function() {
      t.getEvent(this.eventId) ? t.showLightbox(this.eventId) : this.moveTo(new t.$keyboardNavigation.TimeSlot());
    } } }), t.$keyboardNavigation.Event.prototype.bindAll(t.$keyboardNavigation.Event.prototype.keys);
  }(e), function(t) {
    t.$keyboardNavigation.TimeSlot = function(n, s, a, o) {
      var d = t.getState(), r = t.matrix && t.matrix[d.mode];
      n || (n = this.getDefaultDate()), s || (s = r ? t.date.add(n, r.x_step, r.x_unit) : t.date.add(n, t.config.key_nav_step, "minute")), this.section = a || this._getDefaultSection(), this.start_date = new Date(n), this.end_date = new Date(s), this.movingDate = o || null;
    }, t.$keyboardNavigation.TimeSlot.prototype = t._compose(t.$keyboardNavigation.KeyNavNode, { _handlers: null, getDefaultDate: function() {
      var n, s = t.getState(), a = new Date(s.date);
      a.setSeconds(0), a.setMilliseconds(0);
      var o = /* @__PURE__ */ new Date();
      o.setSeconds(0), o.setMilliseconds(0);
      var d = t.matrix && t.matrix[s.mode], r = !1;
      if (a.valueOf() === o.valueOf() && (r = !0), d)
        r ? (d.x_unit === "day" ? (o.setHours(0), o.setMinutes(0)) : d.x_unit === "hour" && o.setMinutes(0), n = o) : n = t.date[d.name + "_start"](new Date(s.date)), n = this.findVisibleColumn(n);
      else if (n = new Date(t.getState().min_date), r && (n = o), n = this.findVisibleColumn(n), r || n.setHours(t.config.first_hour), !t._table_view) {
        var l = t.$container.querySelector(".dhx_cal_data");
        l.scrollTop && n.setHours(t.config.first_hour + Math.ceil(l.scrollTop / t.config.hour_size_px));
      }
      return n;
    }, clone: function(n) {
      return new t.$keyboardNavigation.TimeSlot(n.start_date, n.end_date, n.section, n.movingDate);
    }, _getMultisectionView: function() {
      var n, s = t.getState();
      return t._props && t._props[s.mode] ? n = t._props[s.mode] : t.matrix && t.matrix[s.mode] && (n = t.matrix[s.mode]), n;
    }, _getDefaultSection: function() {
      var n = null;
      return this._getMultisectionView() && !n && (n = this._getNextSection()), n;
    }, _getNextSection: function(n, s) {
      var a = this._getMultisectionView(), o = a.order[n], d = o;
      (d = o !== void 0 ? o + s : a.size && a.position ? a.position : 0) < 0 && (d = 0);
      var r = a.options || a.y_unit;
      return d >= r.length && (d = r.length - 1), r[d] ? r[d].key : null;
    }, isValid: function() {
      var n = t.getState();
      if (this.start_date.valueOf() < n.min_date.valueOf() || this.start_date.valueOf() >= n.max_date.valueOf() || !this.isVisible(this.start_date, this.end_date))
        return !1;
      var s = this._getMultisectionView();
      return !s || s.order[this.section] !== void 0;
    }, fallback: function() {
      var n = new t.$keyboardNavigation.TimeSlot();
      return n.isValid() ? n : new t.$keyboardNavigation.DataArea();
    }, getNodes: function() {
      return Array.prototype.slice.call(t.$container.querySelectorAll(".dhx_focus_slot"));
    }, getNode: function() {
      return this.getNodes()[0];
    }, focus: function() {
      this.section && t.getView() && t.getView().smart_rendering && t.getView().scrollTo && !t.$container.querySelector(`[data-section-id="${this.section}"]`) && t.getView().scrollTo({ section: this.section }), t.$keyboardNavigation.marker.render(this.start_date, this.end_date, this.section), t.$keyboardNavigation.KeyNavNode.prototype.focus.apply(this), t.$keyboardNavigation._pasteDate = this.start_date, t.$keyboardNavigation._pasteSection = this.section;
    }, blur: function() {
      t.$keyboardNavigation.KeyNavNode.prototype.blur.apply(this), t.$keyboardNavigation.marker.clear();
    }, _modes: t.$keyboardNavigation.SchedulerNode.prototype._modes, _getMode: t.$keyboardNavigation.SchedulerNode.prototype.getMode, addMonthDate: function(n, s, a) {
      var o;
      switch (s) {
        case "up":
          o = t.date.add(n, -1, "week");
          break;
        case "down":
          o = t.date.add(n, 1, "week");
          break;
        case "left":
          o = t.date.day_start(t.date.add(n, -1, "day")), o = this.findVisibleColumn(o, -1);
          break;
        case "right":
          o = t.date.day_start(t.date.add(n, 1, "day")), o = this.findVisibleColumn(o, 1);
          break;
        default:
          o = t.date.day_start(new Date(n));
      }
      var d = t.getState();
      return (n.valueOf() < d.min_date.valueOf() || !a && n.valueOf() >= d.max_date.valueOf()) && (o = new Date(d.min_date)), o;
    }, nextMonthSlot: function(n, s, a) {
      var o, d;
      return (o = this.addMonthDate(n.start_date, s, a)).setHours(t.config.first_hour), (d = new Date(o)).setHours(t.config.last_hour), { start_date: o, end_date: d };
    }, _alignTimeSlot: function(n, s, a, o) {
      for (var d = new Date(s); d.valueOf() < n.valueOf(); )
        d = t.date.add(d, o, a);
      return d.valueOf() > n.valueOf() && (d = t.date.add(d, -o, a)), d;
    }, nextTimelineSlot: function(n, s, a) {
      var o = t.getState(), d = t.matrix[o.mode], r = this._alignTimeSlot(n.start_date, t.date[d.name + "_start"](new Date(n.start_date)), d.x_unit, d.x_step), l = this._alignTimeSlot(n.end_date, t.date[d.name + "_start"](new Date(n.end_date)), d.x_unit, d.x_step);
      l.valueOf() <= r.valueOf() && (l = t.date.add(r, d.x_step, d.x_unit));
      var _ = this.clone(n);
      switch (_.start_date = r, _.end_date = l, _.section = n.section || this._getNextSection(), s) {
        case "up":
          _.section = this._getNextSection(n.section, -1);
          break;
        case "down":
          _.section = this._getNextSection(n.section, 1);
          break;
        case "left":
          _.start_date = this.findVisibleColumn(t.date.add(_.start_date, -d.x_step, d.x_unit), -1), _.end_date = t.date.add(_.start_date, d.x_step, d.x_unit);
          break;
        case "right":
          _.start_date = this.findVisibleColumn(t.date.add(_.start_date, d.x_step, d.x_unit), 1), _.end_date = t.date.add(_.start_date, d.x_step, d.x_unit);
      }
      return (_.start_date.valueOf() < o.min_date.valueOf() || _.start_date.valueOf() >= o.max_date.valueOf()) && (a && _.start_date.valueOf() >= o.max_date.valueOf() ? _.start_date = new Date(o.max_date) : (_.start_date = t.date[o.mode + "_start"](t.date.add(o.date, s == "left" ? -1 : 1, o.mode)), _.end_date = t.date.add(_.start_date, d.x_step, d.x_unit))), _;
    }, nextUnitsSlot: function(n, s, a) {
      var o = this.clone(n);
      o.section = n.section || this._getNextSection();
      var d = n.section || this._getNextSection(), r = t.getState(), l = t._props[r.mode];
      switch (s) {
        case "left":
          d = this._getNextSection(n.section, -1);
          var _ = l.size ? l.size - 1 : l.options.length;
          l.days > 1 && l.order[d] == _ - 1 && t.date.add(n.start_date, -1, "day").valueOf() >= r.min_date.valueOf() && (o = this.nextDaySlot(n, s, a));
          break;
        case "right":
          d = this._getNextSection(n.section, 1), l.days > 1 && !l.order[d] && t.date.add(n.start_date, 1, "day").valueOf() < r.max_date.valueOf() && (o = this.nextDaySlot(n, s, a));
          break;
        default:
          o = this.nextDaySlot(n, s, a), d = n.section;
      }
      return o.section = d, o;
    }, _moveDate: function(n, s) {
      var a = this.findVisibleColumn(t.date.add(n, s, "day"), s);
      return a.setHours(n.getHours()), a.setMinutes(n.getMinutes()), a;
    }, isBeforeLastHour: function(n, s) {
      var a = n.getMinutes(), o = n.getHours(), d = t.config.last_hour;
      return o < d || !s && (d == 24 || o == d) && !a;
    }, isAfterFirstHour: function(n, s) {
      var a = n.getMinutes(), o = n.getHours(), d = t.config.first_hour, r = t.config.last_hour;
      return o >= d || !s && !a && (!o && r == 24 || o == r);
    }, isInVisibleDayTime: function(n, s) {
      return this.isBeforeLastHour(n, s) && this.isAfterFirstHour(n, s);
    }, nextDaySlot: function(n, s, a) {
      var o, d, r = t.config.key_nav_step, l = this._alignTimeSlot(n.start_date, t.date.day_start(new Date(n.start_date)), "minute", r), _ = n.start_date;
      switch (s) {
        case "up":
          if (o = t.date.add(l, -r, "minute"), !this.isInVisibleDayTime(o, !0) && (!a || this.isInVisibleDayTime(_, !0))) {
            var h = !0;
            a && t.date.date_part(new Date(o)).valueOf() != t.date.date_part(new Date(_)).valueOf() && (h = !1), h && (o = this.findVisibleColumn(t.date.add(n.start_date, -1, "day"), -1)), o.setHours(t.config.last_hour), o.setMinutes(0), o = t.date.add(o, -r, "minute");
          }
          d = t.date.add(o, r, "minute");
          break;
        case "down":
          o = t.date.add(l, r, "minute");
          var p = a ? o : t.date.add(o, r, "minute");
          this.isInVisibleDayTime(p, !1) || a && !this.isInVisibleDayTime(_, !1) || (a ? (h = !0, t.date.date_part(new Date(_)).valueOf() == _.valueOf() && (h = !1), h && (o = this.findVisibleColumn(t.date.add(n.start_date, 1, "day"), 1)), o.setHours(t.config.first_hour), o.setMinutes(0), o = t.date.add(o, r, "minute")) : ((o = this.findVisibleColumn(t.date.add(n.start_date, 1, "day"), 1)).setHours(t.config.first_hour), o.setMinutes(0))), d = t.date.add(o, r, "minute");
          break;
        case "left":
          o = this._moveDate(n.start_date, -1), d = this._moveDate(n.end_date, -1);
          break;
        case "right":
          o = this._moveDate(n.start_date, 1), d = this._moveDate(n.end_date, 1);
          break;
        default:
          o = l, d = t.date.add(o, r, "minute");
      }
      return { start_date: o, end_date: d };
    }, nextWeekAgendaSlot: function(n, s) {
      var a, o, d = t.getState();
      switch (s) {
        case "down":
        case "left":
          a = t.date.day_start(t.date.add(n.start_date, -1, "day")), a = this.findVisibleColumn(a, -1);
          break;
        case "up":
        case "right":
          a = t.date.day_start(t.date.add(n.start_date, 1, "day")), a = this.findVisibleColumn(a, 1);
          break;
        default:
          a = t.date.day_start(n.start_date);
      }
      return (n.start_date.valueOf() < d.min_date.valueOf() || n.start_date.valueOf() >= d.max_date.valueOf()) && (a = new Date(d.min_date)), (o = new Date(a)).setHours(t.config.last_hour), { start_date: a, end_date: o };
    }, nextAgendaSlot: function(n, s) {
      return { start_date: n.start_date, end_date: n.end_date };
    }, isDateVisible: function(n) {
      if (!t._ignores_detected)
        return !0;
      var s, a = t.matrix && t.matrix[t.getState().mode];
      return s = a ? t._get_date_index(a, n) : t.locate_holder_day(n), !t._ignores[s];
    }, findVisibleColumn: function(n, s) {
      var a = n;
      s = s || 1;
      for (var o = t.getState(); !this.isDateVisible(a) && (s > 0 && a.valueOf() <= o.max_date.valueOf() || s < 0 && a.valueOf() >= o.min_date.valueOf()); )
        a = this.nextDateColumn(a, s);
      return a;
    }, nextDateColumn: function(n, s) {
      s = s || 1;
      var a = t.matrix && t.matrix[t.getState().mode];
      return a ? t.date.add(n, s * a.x_step, a.x_unit) : t.date.day_start(t.date.add(n, s, "day"));
    }, isVisible: function(n, s) {
      if (!t._ignores_detected)
        return !0;
      for (var a = new Date(n); a.valueOf() < s.valueOf(); ) {
        if (this.isDateVisible(a))
          return !0;
        a = this.nextDateColumn(a);
      }
      return !1;
    }, nextSlot: function(n, s, a, o) {
      var d;
      a = a || this._getMode();
      var r = t.$keyboardNavigation.TimeSlot.prototype.clone(n);
      switch (a) {
        case this._modes.units:
          d = this.nextUnitsSlot(r, s, o);
          break;
        case this._modes.timeline:
          d = this.nextTimelineSlot(r, s, o);
          break;
        case this._modes.year:
        case this._modes.month:
          d = this.nextMonthSlot(r, s, o);
          break;
        case this._modes.weekAgenda:
          d = this.nextWeekAgendaSlot(r, s, o);
          break;
        case this._modes.list:
          d = this.nextAgendaSlot(r, s, o);
          break;
        case this._modes.dayColumns:
          d = this.nextDaySlot(r, s, o);
      }
      return d.start_date.valueOf() >= d.end_date.valueOf() && (d = this.nextSlot(d, s, a)), t.$keyboardNavigation.TimeSlot.prototype.clone(d);
    }, extendSlot: function(n, s) {
      var a;
      switch (this._getMode()) {
        case this._modes.units:
          a = s == "left" || s == "right" ? this.nextUnitsSlot(n, s) : this.extendUnitsSlot(n, s);
          break;
        case this._modes.timeline:
          a = s == "down" || s == "up" ? this.nextTimelineSlot(n, s) : this.extendTimelineSlot(n, s);
          break;
        case this._modes.year:
        case this._modes.month:
          a = this.extendMonthSlot(n, s);
          break;
        case this._modes.dayColumns:
          a = this.extendDaySlot(n, s);
          break;
        case this._modes.weekAgenda:
          a = this.extendWeekAgendaSlot(n, s);
          break;
        default:
          a = n;
      }
      var o = t.getState();
      return a.start_date.valueOf() < o.min_date.valueOf() && (a.start_date = this.findVisibleColumn(o.min_date), a.start_date.setHours(t.config.first_hour)), a.end_date.valueOf() > o.max_date.valueOf() && (a.end_date = this.findVisibleColumn(o.max_date, -1)), t.$keyboardNavigation.TimeSlot.prototype.clone(a);
    }, extendTimelineSlot: function(n, s) {
      return this.extendGenericSlot({ left: "start_date", right: "end_date" }, n, s, "timeline");
    }, extendWeekAgendaSlot: function(n, s) {
      return this.extendGenericSlot({ left: "start_date", right: "end_date" }, n, s, "weekAgenda");
    }, extendGenericSlot: function(n, s, a, o) {
      var d, r = s.movingDate;
      if (r || (r = n[a]), !r || !n[a])
        return s;
      if (!a)
        return t.$keyboardNavigation.TimeSlot.prototype.clone(s);
      (d = this.nextSlot({ start_date: s[r], section: s.section }, a, o, !0)).start_date.valueOf() == s.start_date.valueOf() && (d = this.nextSlot({ start_date: d.start_date, section: d.section }, a, o, !0)), d.movingDate = r;
      var l = this.extendSlotDates(s, d, d.movingDate);
      return l.end_date.valueOf() <= l.start_date.valueOf() && (d.movingDate = d.movingDate == "end_date" ? "start_date" : "end_date"), l = this.extendSlotDates(s, d, d.movingDate), d.start_date = l.start_date, d.end_date = l.end_date, d;
    }, extendSlotDates: function(n, s, a) {
      var o = { start_date: null, end_date: null };
      return a == "start_date" ? (o.start_date = s.start_date, o.end_date = n.end_date) : (o.start_date = n.start_date, o.end_date = s.start_date), o;
    }, extendMonthSlot: function(n, s) {
      return (n = this.extendGenericSlot({ up: "start_date", down: "end_date", left: "start_date", right: "end_date" }, n, s, "month")).start_date.setHours(t.config.first_hour), n.end_date = t.date.add(n.end_date, -1, "day"), n.end_date.setHours(t.config.last_hour), n;
    }, extendUnitsSlot: function(n, s) {
      var a;
      switch (s) {
        case "down":
        case "up":
          a = this.extendDaySlot(n, s);
          break;
        default:
          a = n;
      }
      return a.section = n.section, a;
    }, extendDaySlot: function(n, s) {
      return this.extendGenericSlot({ up: "start_date", down: "end_date", left: "start_date", right: "end_date" }, n, s, "dayColumns");
    }, scrollSlot: function(n) {
      var s = t.getState(), a = this.nextSlot(this, n);
      (a.start_date.valueOf() < s.min_date.valueOf() || a.start_date.valueOf() >= s.max_date.valueOf()) && t.setCurrentView(new Date(a.start_date)), this.moveTo(a);
    }, keys: { left: function() {
      this.scrollSlot("left");
    }, right: function() {
      this.scrollSlot("right");
    }, down: function() {
      this._getMode() == this._modes.list ? t.$keyboardNavigation.SchedulerNode.prototype.nextEventHandler() : this.scrollSlot("down");
    }, up: function() {
      this._getMode() == this._modes.list ? t.$keyboardNavigation.SchedulerNode.prototype.prevEventHandler() : this.scrollSlot("up");
    }, "shift+down": function() {
      this.moveTo(this.extendSlot(this, "down"));
    }, "shift+up": function() {
      this.moveTo(this.extendSlot(this, "up"));
    }, "shift+right": function() {
      this.moveTo(this.extendSlot(this, "right"));
    }, "shift+left": function() {
      this.moveTo(this.extendSlot(this, "left"));
    }, enter: function() {
      var n = { start_date: new Date(this.start_date), end_date: new Date(this.end_date) }, s = t.getState().mode;
      t.matrix && t.matrix[s] ? n[t.matrix[t.getState().mode].y_property] = this.section : t._props && t._props[s] && (n[t._props[s].map_to] = this.section), t.addEventNow(n);
    } } }), t.$keyboardNavigation.TimeSlot.prototype.bindAll(t.$keyboardNavigation.TimeSlot.prototype.keys);
  }(e), function(t) {
    t.$keyboardNavigation.MinicalButton = function(n, s) {
      this.container = n, this.index = s || 0;
    }, t.$keyboardNavigation.MinicalButton.prototype = t._compose(t.$keyboardNavigation.KeyNavNode, { isValid: function() {
      return !!this.container.offsetWidth;
    }, fallback: function() {
      var n = new t.$keyboardNavigation.TimeSlot();
      return n.isValid() ? n : new t.$keyboardNavigation.DataArea();
    }, focus: function() {
      t.$keyboardNavigation.dispatcher.globalNode.disable(), this.container.removeAttribute("tabindex"), t.$keyboardNavigation.KeyNavNode.prototype.focus.apply(this);
    }, blur: function() {
      this.container.setAttribute("tabindex", "0"), t.$keyboardNavigation.KeyNavNode.prototype.blur.apply(this);
    }, getNode: function() {
      return this.index ? this.container.querySelector(".dhx_cal_next_button") : this.container.querySelector(".dhx_cal_prev_button");
    }, keys: { right: function(n) {
      this.moveTo(new t.$keyboardNavigation.MinicalButton(this.container, this.index ? 0 : 1));
    }, left: function(n) {
      this.moveTo(new t.$keyboardNavigation.MinicalButton(this.container, this.index ? 0 : 1));
    }, down: function() {
      var n = new t.$keyboardNavigation.MinicalCell(this.container, 0, 0);
      n && !n.isValid() && (n = n.fallback()), this.moveTo(n);
    }, enter: function(n) {
      this.getNode().click();
    } } }), t.$keyboardNavigation.MinicalButton.prototype.bindAll(t.$keyboardNavigation.MinicalButton.prototype.keys);
  }(e), function(t) {
    t.$keyboardNavigation.MinicalCell = function(n, s, a) {
      this.container = n, this.row = s || 0, this.col = a || 0;
    }, t.$keyboardNavigation.MinicalCell.prototype = t._compose(t.$keyboardNavigation.KeyNavNode, { isValid: function() {
      var n = this._getGrid();
      return !(!n[this.row] || !n[this.row][this.col]);
    }, fallback: function() {
      var n = this.row, s = this.col, a = this._getGrid();
      a[n] || (n = 0);
      var o = !0;
      if (n > a.length / 2 && (o = !1), !a[n]) {
        var d = new t.$keyboardNavigation.TimeSlot();
        return d.isValid() ? d : new t.$keyboardNavigation.DataArea();
      }
      if (o) {
        for (var r = s; a[n] && r < a[n].length; r++)
          if (a[n][r] || r != a[n].length - 1 || (n++, s = 0), a[n][r])
            return new t.$keyboardNavigation.MinicalCell(this.container, n, r);
      } else
        for (r = s; a[n] && r < a[n].length; r--)
          if (a[n][r] || r || (s = a[--n].length - 1), a[n][r])
            return new t.$keyboardNavigation.MinicalCell(this.container, n, r);
      return new t.$keyboardNavigation.MinicalButton(this.container, 0);
    }, focus: function() {
      t.$keyboardNavigation.dispatcher.globalNode.disable(), this.container.removeAttribute("tabindex"), t.$keyboardNavigation.KeyNavNode.prototype.focus.apply(this);
    }, blur: function() {
      this.container.setAttribute("tabindex", "0"), t.$keyboardNavigation.KeyNavNode.prototype.blur.apply(this);
    }, _getNode: function(n, s) {
      return this.container.querySelector(".dhx_year_body tr:nth-child(" + (n + 1) + ") td:nth-child(" + (s + 1) + ")");
    }, getNode: function() {
      return this._getNode(this.row, this.col);
    }, _getGrid: function() {
      for (var n = this.container.querySelectorAll(".dhx_year_body tr"), s = [], a = 0; a < n.length; a++) {
        s[a] = [];
        for (var o = n[a].querySelectorAll("td"), d = 0; d < o.length; d++) {
          var r = o[d], l = !0, _ = t._getClassName(r);
          (_.indexOf("dhx_after") > -1 || _.indexOf("dhx_before") > -1 || _.indexOf("dhx_scale_ignore") > -1) && (l = !1), s[a][d] = l;
        }
      }
      return s;
    }, keys: { right: function(n) {
      var s = this._getGrid(), a = this.row, o = this.col + 1;
      s[a] && s[a][o] || (s[a + 1] ? (a += 1, o = 0) : o = this.col);
      var d = new t.$keyboardNavigation.MinicalCell(this.container, a, o);
      d.isValid() || (d = d.fallback()), this.moveTo(d);
    }, left: function(n) {
      var s = this._getGrid(), a = this.row, o = this.col - 1;
      s[a] && s[a][o] || (o = s[a - 1] ? s[a -= 1].length - 1 : this.col);
      var d = new t.$keyboardNavigation.MinicalCell(this.container, a, o);
      d.isValid() || (d = d.fallback()), this.moveTo(d);
    }, down: function() {
      var n = this._getGrid(), s = this.row + 1, a = this.col;
      n[s] && n[s][a] || (s = this.row);
      var o = new t.$keyboardNavigation.MinicalCell(this.container, s, a);
      o.isValid() || (o = o.fallback()), this.moveTo(o);
    }, up: function() {
      var n = this._getGrid(), s = this.row - 1, a = this.col;
      if (n[s] && n[s][a]) {
        var o = new t.$keyboardNavigation.MinicalCell(this.container, s, a);
        o.isValid() || (o = o.fallback()), this.moveTo(o);
      } else {
        var d = 0;
        this.col > n[this.row].length / 2 && (d = 1), this.moveTo(new t.$keyboardNavigation.MinicalButton(this.container, d));
      }
    }, enter: function(n) {
      this.getNode().querySelector(".dhx_month_head").click();
    } } }), t.$keyboardNavigation.MinicalCell.prototype.bindAll(t.$keyboardNavigation.MinicalCell.prototype.keys);
  }(e), function(t) {
    t.$keyboardNavigation.DataArea = function(n) {
      this.index = n || 0;
    }, t.$keyboardNavigation.DataArea.prototype = t._compose(t.$keyboardNavigation.KeyNavNode, { getNode: function(n) {
      return t.$container.querySelector(".dhx_cal_data");
    }, _handlers: null, isValid: function() {
      return !0;
    }, fallback: function() {
      return this;
    }, keys: { "up,down,right,left": function() {
      this.moveTo(new t.$keyboardNavigation.TimeSlot());
    } } }), t.$keyboardNavigation.DataArea.prototype.bindAll(t.$keyboardNavigation.DataArea.prototype.keys);
  }(e), da(e), function(t) {
    t.$keyboardNavigation.dispatcher = { isActive: !1, activeNode: null, globalNode: new t.$keyboardNavigation.SchedulerNode(), keepScrollPosition: function(n) {
      var s, a, o = t.$container.querySelector(".dhx_timeline_scrollable_data");
      o || (o = t.$container.querySelector(".dhx_cal_data")), o && (s = o.scrollTop, a = o.scrollLeft), n(), o && (o.scrollTop = s, o.scrollLeft = a);
    }, enable: function() {
      if (t.$container) {
        this.isActive = !0;
        var n = this;
        this.keepScrollPosition(function() {
          n.globalNode.enable(), n.setActiveNode(n.getActiveNode());
        });
      }
    }, disable: function() {
      this.isActive = !1, this.globalNode.disable();
    }, isEnabled: function() {
      return !!this.isActive;
    }, getDefaultNode: function() {
      return this.globalNode.getDefaultNode();
    }, setDefaultNode: function() {
      this.setActiveNode(this.getDefaultNode());
    }, getActiveNode: function() {
      var n = this.activeNode;
      return n && !n.isValid() && (n = n.fallback()), n;
    }, focusGlobalNode: function() {
      this.blurNode(this.globalNode), this.focusNode(this.globalNode);
    }, setActiveNode: function(n) {
      n && n.isValid() && (this.activeNode && this.activeNode.compareTo(n) || this.isEnabled() && (this.blurNode(this.activeNode), this.activeNode = n, this.focusNode(this.activeNode)));
    }, focusNode: function(n) {
      n && n.focus && (n.focus(), n.getNode && document.activeElement != n.getNode() && this.setActiveNode(new t.$keyboardNavigation.DataArea()));
    }, blurNode: function(n) {
      n && n.blur && n.blur();
    }, getInlineEditor: function(n) {
      var s = t.$container.querySelector(".dhx_cal_editor[" + t.config.event_attribute + "='" + n + "'] textarea");
      return s && s.offsetWidth ? s : null;
    }, keyDownHandler: function(n) {
      if (!n.defaultPrevented) {
        var s = this.getActiveNode();
        if ((!t.$keyboardNavigation.isModal() || s && s.container && t.utils.dom.locateCss({ target: s.container }, "dhx_minical_popup", !1)) && (!t.getState().editor_id || !this.getInlineEditor(t.getState().editor_id)) && this.isEnabled()) {
          n = n || window.event;
          var a = this.globalNode, o = t.$keyboardNavigation.shortcuts.getCommandFromEvent(n);
          s ? s.findHandler(o) ? s.doAction(o, n) : a.findHandler(o) && a.doAction(o, n) : this.setDefaultNode();
        }
      }
    }, _timeout: null, delay: function(n, s) {
      clearTimeout(this._timeout), this._timeout = setTimeout(n, s || 1);
    } };
  }(e), _a(e), function() {
    la(e), function(d) {
      d.$keyboardNavigation._minicalendars = [], d.$keyboardNavigation.isMinical = function(r) {
        for (var l = d.$keyboardNavigation._minicalendars, _ = 0; _ < l.length; _++)
          if (this.isChildOf(r, l[_]))
            return !0;
        return !1;
      }, d.$keyboardNavigation.isChildOf = function(r, l) {
        for (; r && r !== l; )
          r = r.parentNode;
        return r === l;
      }, d.$keyboardNavigation.patchMinicalendar = function() {
        var r = d.$keyboardNavigation.dispatcher;
        function l(v) {
          var g = v.target;
          r.enable(), r.setActiveNode(new d.$keyboardNavigation.MinicalButton(g, 0));
        }
        function _(v) {
          var g = v.target || v.srcElement, c = d.utils.dom.locateCss(v, "dhx_cal_prev_button", !1), f = d.utils.dom.locateCss(v, "dhx_cal_next_button", !1), u = d.utils.dom.locateCss(v, "dhx_year_body", !1), y = 0, w = 0;
          if (u) {
            for (var D, M, k = g; k && k.tagName.toLowerCase() != "td"; )
              k = k.parentNode;
            if (k && (D = (M = k).parentNode), D && M) {
              for (var N = D.parentNode.querySelectorAll("tr"), m = 0; m < N.length; m++)
                if (N[m] == D) {
                  y = m;
                  break;
                }
              var x = D.querySelectorAll("td");
              for (m = 0; m < x.length; m++)
                if (x[m] == M) {
                  w = m;
                  break;
                }
            }
          }
          var b = v.currentTarget;
          r.delay(function() {
            var E;
            (c || f || u) && (c ? (E = new d.$keyboardNavigation.MinicalButton(b, 0), r.setActiveNode(new d.$keyboardNavigation.MinicalButton(b, 0))) : f ? E = new d.$keyboardNavigation.MinicalButton(b, 1) : u && (E = new d.$keyboardNavigation.MinicalCell(b, y, w)), E && (r.enable(), E.isValid() && (r.activeNode = null, r.setActiveNode(E))));
          });
        }
        if (d.renderCalendar) {
          var h = d.renderCalendar;
          d.renderCalendar = function() {
            var v = h.apply(this, arguments), g = d.$keyboardNavigation._minicalendars;
            d.eventRemove(v, "click", _), d.event(v, "click", _), d.eventRemove(v, "focus", l), d.event(v, "focus", l);
            for (var c = !1, f = 0; f < g.length; f++)
              if (g[f] == v) {
                c = !0;
                break;
              }
            if (c || g.push(v), r.isEnabled()) {
              var u = r.getActiveNode();
              u && u.container == v ? r.focusNode(u) : v.setAttribute("tabindex", "0");
            } else
              v.setAttribute("tabindex", "0");
            return v;
          };
        }
        if (d.destroyCalendar) {
          var p = d.destroyCalendar;
          d.destroyCalendar = function(v, g) {
            v = v || (d._def_count ? d._def_count.firstChild : null);
            var c = p.apply(this, arguments);
            if (!v || !v.parentNode)
              for (var f = d.$keyboardNavigation._minicalendars, u = 0; u < f.length; u++)
                f[u] == v && (d.eventRemove(f[u], "focus", l), f.splice(u, 1), u--);
            return c;
          };
        }
      };
    }(e);
    var t = e.$keyboardNavigation.dispatcher;
    if (e.$keyboardNavigation.attachSchedulerHandlers(), e.renderCalendar)
      e.$keyboardNavigation.patchMinicalendar();
    else
      var n = e.attachEvent("onSchedulerReady", function() {
        e.detachEvent(n), e.$keyboardNavigation.patchMinicalendar();
      });
    function s() {
      if (e.config.key_nav) {
        var d = document.activeElement;
        return !(!d || e.utils.dom.locateCss(d, "dhx_cal_quick_info", !1)) && (e.$keyboardNavigation.isChildOf(d, e.$container) || e.$keyboardNavigation.isMinical(d));
      }
    }
    function a(d) {
      d && !t.isEnabled() ? t.enable() : !d && t.isEnabled() && t.disable();
    }
    const o = setInterval(function() {
      if (e.$container && e.$keyboardNavigation.isChildOf(e.$container, document.body)) {
        var d = s();
        d ? a(d) : !d && t.isEnabled() && setTimeout(function() {
          e.$destroyed || (e.config.key_nav ? a(s()) : e.$container.removeAttribute("tabindex"));
        }, 100);
      }
    }, 500);
    e.attachEvent("onDestroy", function() {
      clearInterval(o);
    });
  }();
}, layer: function(e) {
  e.attachEvent("onTemplatesReady", function() {
    this.layers.sort(function(t, n) {
      return t.zIndex - n.zIndex;
    }), e._dp_init = function(t) {
      t._methods = ["_set_event_text_style", "", "changeEventId", "deleteEvent"], this.attachEvent("onEventAdded", function(n) {
        !this._loading && this.validId(n) && this.getEvent(n) && this.getEvent(n).layer == t.layer && t.setUpdated(n, !0, "inserted");
      }), this.attachEvent("onBeforeEventDelete", function(n) {
        if (this.getEvent(n) && this.getEvent(n).layer == t.layer) {
          if (!this.validId(n))
            return;
          var s = t.getState(n);
          return s == "inserted" || this._new_event ? (t.setUpdated(n, !1), !0) : s != "deleted" && (s == "true_deleted" || (t.setUpdated(n, !0, "deleted"), !1));
        }
        return !0;
      }), this.attachEvent("onEventChanged", function(n) {
        !this._loading && this.validId(n) && this.getEvent(n) && this.getEvent(n).layer == t.layer && t.setUpdated(n, !0, "updated");
      }), t._getRowData = function(n, s) {
        var a = this.obj.getEvent(n), o = {};
        for (var d in a)
          d.indexOf("_") !== 0 && (a[d] && a[d].getUTCFullYear ? o[d] = this.obj._helpers.formatDate(a[d]) : o[d] = a[d]);
        return o;
      }, t._clearUpdateFlag = function() {
      }, t.attachEvent("insertCallback", e._update_callback), t.attachEvent("updateCallback", e._update_callback), t.attachEvent("deleteCallback", function(n, s) {
        this.obj.setUserData(s, this.action_param, "true_deleted"), this.obj.deleteEvent(s);
      });
    }, function() {
      var t = function(a) {
        if (a === null || typeof a != "object")
          return a;
        var o = new a.constructor();
        for (var d in a)
          o[d] = t(a[d]);
        return o;
      };
      e._dataprocessors = [], e._layers_zindex = {};
      for (var n = 0; n < e.layers.length; n++) {
        if (e.config["lightbox_" + e.layers[n].name] = {}, e.config["lightbox_" + e.layers[n].name].sections = t(e.config.lightbox.sections), e._layers_zindex[e.layers[n].name] = e.config.initial_layer_zindex || 5 + 3 * n, e.layers[n].url) {
          var s = e.createDataProcessor({ url: e.layers[n].url });
          s.layer = e.layers[n].name, e._dataprocessors.push(s), e._dataprocessors[n].init(e);
        }
        e.layers[n].isDefault && (e.defaultLayer = e.layers[n].name);
      }
    }(), e.showLayer = function(t) {
      this.toggleLayer(t, !0);
    }, e.hideLayer = function(t) {
      this.toggleLayer(t, !1);
    }, e.toggleLayer = function(t, n) {
      var s = this.getLayer(t);
      s.visible = n !== void 0 ? !!n : !s.visible, this.setCurrentView(this._date, this._mode);
    }, e.getLayer = function(t) {
      var n, s;
      typeof t == "string" && (s = t), typeof t == "object" && (s = t.layer);
      for (var a = 0; a < e.layers.length; a++)
        e.layers[a].name == s && (n = e.layers[a]);
      return n;
    }, e.attachEvent("onBeforeLightbox", function(t) {
      var n = this.getEvent(t);
      return this.config.lightbox.sections = this.config["lightbox_" + n.layer].sections, e.resetLightbox(), !0;
    }), e.attachEvent("onClick", function(t, n) {
      var s = e.getEvent(t);
      return !e.getLayer(s.layer).noMenu;
    }), e.attachEvent("onEventCollision", function(t, n) {
      var s = this.getLayer(t);
      if (!s.checkCollision)
        return !1;
      for (var a = 0, o = 0; o < n.length; o++)
        n[o].layer == s.name && n[o].id != t.id && a++;
      return a >= e.config.collision_limit;
    }), e.addEvent = function(t, n, s, a, o) {
      var d = t;
      arguments.length != 1 && ((d = o || {}).start_date = t, d.end_date = n, d.text = s, d.id = a, d.layer = this.defaultLayer), d.id = d.id || e.uid(), d.text = d.text || "", typeof d.start_date == "string" && (d.start_date = this.templates.api_date(d.start_date)), typeof d.end_date == "string" && (d.end_date = this.templates.api_date(d.end_date)), d._timed = this.isOneDayEvent(d);
      var r = !this._events[d.id];
      this._events[d.id] = d, this.event_updated(d), this._loading || this.callEvent(r ? "onEventAdded" : "onEventChanged", [d.id, d]);
    }, this._evs_layer = {};
    for (var i = 0; i < this.layers.length; i++)
      this._evs_layer[this.layers[i].name] = [];
    e.addEventNow = function(t, n, s) {
      var a = {};
      typeof t == "object" && (a = t, t = null);
      var o = 6e4 * (this.config.event_duration || this.config.time_step);
      t || (t = Math.round(e._currentDate().valueOf() / o) * o);
      var d = new Date(t);
      if (!n) {
        var r = this.config.first_hour;
        r > d.getHours() && (d.setHours(r), t = d.valueOf()), n = t + o;
      }
      a.start_date = a.start_date || d, a.end_date = a.end_date || new Date(n), a.text = a.text || this.locale.labels.new_event, a.id = this._drag_id = this.uid(), a.layer = this.defaultLayer, this._drag_mode = "new-size", this._loading = !0, this.addEvent(a), this.callEvent("onEventCreated", [this._drag_id, s]), this._loading = !1, this._drag_event = {}, this._on_mouse_up(s);
    }, e._t_render_view_data = function(t) {
      if (this.config.multi_day && !this._table_view) {
        for (var n = [], s = [], a = 0; a < t.length; a++)
          t[a]._timed ? n.push(t[a]) : s.push(t[a]);
        this._table_view = !0, this.render_data(s), this._table_view = !1, this.render_data(n);
      } else
        this.render_data(t);
    }, e.render_view_data = function() {
      if (this._not_render)
        this._render_wait = !0;
      else {
        this._render_wait = !1, this.clear_view(), this._evs_layer = {};
        for (var t = 0; t < this.layers.length; t++)
          this._evs_layer[this.layers[t].name] = [];
        var n = this.get_visible_events();
        for (t = 0; t < n.length; t++)
          this._evs_layer[n[t].layer] && this._evs_layer[n[t].layer].push(n[t]);
        if (this._mode == "month") {
          var s = [];
          for (t = 0; t < this.layers.length; t++)
            this.layers[t].visible && (s = s.concat(this._evs_layer[this.layers[t].name]));
          this._t_render_view_data(s);
        } else
          for (t = 0; t < this.layers.length; t++)
            if (this.layers[t].visible) {
              var a = this._evs_layer[this.layers[t].name];
              this._t_render_view_data(a);
            }
      }
    }, e._render_v_bar = function(t, n, s, a, o, d, r, l, _) {
      var h = t.id;
      r.indexOf("<div class=") == -1 && (r = e.templates["event_header_" + t.layer] ? e.templates["event_header_" + t.layer](t.start_date, t.end_date, t) : r), l.indexOf("<div class=") == -1 && (l = e.templates["event_text_" + t.layer] ? e.templates["event_text_" + t.layer](t.start_date, t.end_date, t) : l);
      var p = document.createElement("div"), v = "dhx_cal_event", g = e.templates["event_class_" + t.layer] ? e.templates["event_class_" + t.layer](t.start_date, t.end_date, t) : e.templates.event_class(t.start_date, t.end_date, t);
      g && (v = v + " " + g);
      var c = e._border_box_events(), f = a - 2, u = c ? f : a - 4, y = c ? f : a - 6, w = c ? f : a - 14, D = c ? f - 2 : a - 8, M = c ? o - this.xy.event_header_height : o - 30 + 1, k = '<div event_id="' + h + '" ' + e.config.event_attribute + '="' + h + '" class="' + v + '" style="position:absolute; top:' + s + "px; left:" + n + "px; width:" + u + "px; height:" + o + "px;" + (d || "") + '">';
      return k += '<div class="dhx_header" style=" width:' + y + 'px;" >&nbsp;</div>', k += '<div class="dhx_title">' + r + "</div>", k += '<div class="dhx_body" style=" width:' + w + "px; height:" + M + 'px;">' + l + "</div>", k += '<div class="dhx_footer" style=" width:' + D + "px;" + (_ ? " margin-top:-1px;" : "") + '" ></div></div>', p.innerHTML = k, p.style.zIndex = 100, p.firstChild;
    }, e.render_event_bar = function(t) {
      var n = this._els.dhx_cal_data[0], s = this._colsS[t._sday], a = this._colsS[t._eday];
      a == s && (a = this._colsS[t._eday + 1]);
      var o = this.xy.bar_height, d = this._colsS.heights[t._sweek] + (this._colsS.height ? this.xy.month_scale_height + 2 : 2) + t._sorder * o, r = document.createElement("div"), l = t._timed ? "dhx_cal_event_clear" : "dhx_cal_event_line", _ = e.templates["event_class_" + t.layer] ? e.templates["event_class_" + t.layer](t.start_date, t.end_date, t) : e.templates.event_class(t.start_date, t.end_date, t);
      _ && (l = l + " " + _);
      var h = '<div event_id="' + t.id + '" ' + this.config.event_attribute + '="' + t.id + '" class="' + l + '" style="position:absolute; top:' + d + "px; left:" + s + "px; width:" + (a - s - 15) + "px;" + (t._text_style || "") + '">';
      t._timed && (h += e.templates["event_bar_date_" + t.layer] ? e.templates["event_bar_date_" + t.layer](t.start_date, t.end_date, t) : e.templates.event_bar_date(t.start_date, t.end_date, t)), h += e.templates["event_bar_text_" + t.layer] ? e.templates["event_bar_text_" + t.layer](t.start_date, t.end_date, t) : e.templates.event_bar_text(t.start_date, t.end_date, t) + "</div>)", h += "</div>", r.innerHTML = h, this._rendered.push(r.firstChild), n.appendChild(r.firstChild);
    }, e.render_event = function(t) {
      var n = e.xy.menu_width;
      if (e.getLayer(t.layer).noMenu && (n = 0), !(t._sday < 0)) {
        var s = e.locate_holder(t._sday);
        if (s) {
          var a = 60 * t.start_date.getHours() + t.start_date.getMinutes(), o = 60 * t.end_date.getHours() + t.end_date.getMinutes() || 60 * e.config.last_hour, d = Math.round((60 * a * 1e3 - 60 * this.config.first_hour * 60 * 1e3) * this.config.hour_size_px / 36e5) % (24 * this.config.hour_size_px) + 1, r = Math.max(e.xy.min_event_height, (o - a) * this.config.hour_size_px / 60) + 1, l = Math.floor((s.clientWidth - n) / t._count), _ = t._sorder * l + 1;
          t._inner || (l *= t._count - t._sorder);
          var h = this._render_v_bar(t.id, n + _, d, l, r, t._text_style, e.templates.event_header(t.start_date, t.end_date, t), e.templates.event_text(t.start_date, t.end_date, t));
          if (this._rendered.push(h), s.appendChild(h), _ = _ + parseInt(s.style.left, 10) + n, d += this._dy_shift, h.style.zIndex = this._layers_zindex[t.layer], this._edit_id == t.id) {
            h.style.zIndex = parseInt(h.style.zIndex) + 1;
            var p = h.style.zIndex;
            l = Math.max(l - 4, e.xy.editor_width), (h = document.createElement("div")).setAttribute("event_id", t.id), h.setAttribute(this.config.event_attribute, t.id), this.set_xy(h, l, r - 20, _, d + 14), h.className = "dhx_cal_editor", h.style.zIndex = p;
            var v = document.createElement("div");
            this.set_xy(v, l - 6, r - 26), v.style.cssText += ";margin:2px 2px 2px 2px;overflow:hidden;", v.style.zIndex = p, h.appendChild(v), this._els.dhx_cal_data[0].appendChild(h), this._rendered.push(h), v.innerHTML = "<textarea class='dhx_cal_editor'>" + t.text + "</textarea>", this._editor = v.firstChild, this._editor.addEventListener("keypress", function(y) {
              if (y.shiftKey)
                return !0;
              var w = y.keyCode;
              w == e.keys.edit_save && e.editStop(!0), w == e.keys.edit_cancel && e.editStop(!1);
            }), this._editor.addEventListener("selectstart", function(y) {
              return y.cancelBubble = !0, !0;
            }), v.firstChild.focus(), this._els.dhx_cal_data[0].scrollLeft = 0, v.firstChild.select();
          }
          if (this._select_id == t.id) {
            h.style.zIndex = parseInt(h.style.zIndex) + 1;
            for (var g = this.config["icons_" + (this._edit_id == t.id ? "edit" : "select")], c = "", f = 0; f < g.length; f++)
              c += "<div class='dhx_menu_icon " + g[f] + "' title='" + this.locale.labels[g[f]] + "'></div>";
            var u = this._render_v_bar(t.id, _ - n + 1, d, n, 20 * g.length + 26, "", "<div class='dhx_menu_head'></div>", c, !0);
            u.style.left = _ - n + 1, u.style.zIndex = h.style.zIndex, this._els.dhx_cal_data[0].appendChild(u), this._rendered.push(u);
          }
        }
      }
    }, e.filter_agenda = function(t, n) {
      var s = e.getLayer(n.layer);
      return s && s.visible;
    };
  });
}, limit: function(e) {
  e.config.limit_start = null, e.config.limit_end = null, e.config.limit_view = !1, e.config.check_limits = !0, e._temp_limit_scope = function() {
    var i = null;
    e.attachEvent("onBeforeViewChange", function(t, n, s, a) {
      function o(d, r) {
        var l = e.config.limit_start, _ = e.config.limit_end, h = e.date.add(d, 1, r);
        return d.valueOf() > _.valueOf() || h <= l.valueOf();
      }
      return !e.config.limit_view || !o(a = a || n, s = s || t) || n.valueOf() == a.valueOf() || (setTimeout(function() {
        if (e.$destroyed)
          return !0;
        var d = o(n, s) ? e.config.limit_start : n;
        e.setCurrentView(o(d, s) ? null : d, s);
      }, 1), !1);
    }), e.attachEvent("onMouseDown", function(t) {
      return t != "dhx_time_block";
    }), e.attachEvent("onBeforeDrag", function(t) {
      return !t || e.checkLimitViolation(e.getEvent(t));
    }), e.attachEvent("onClick", function(t, n) {
      return e.checkLimitViolation(e.getEvent(t));
    }), e.attachEvent("onBeforeLightbox", function(t) {
      var n = e.getEvent(t);
      return i = [n.start_date, n.end_date], e.checkLimitViolation(n);
    }), e.attachEvent("onEventSave", function(t, n, s) {
      if (!n.start_date || !n.end_date) {
        var a = e.getEvent(t);
        n.start_date = new Date(a.start_date), n.end_date = new Date(a.end_date);
      }
      if (n.rec_type) {
        var o = e._lame_clone(n);
        return e._roll_back_dates(o), e.checkLimitViolation(o);
      }
      return e.checkLimitViolation(n);
    }), e.attachEvent("onEventAdded", function(t) {
      if (!t)
        return !0;
      var n = e.getEvent(t);
      return !e.checkLimitViolation(n) && e.config.limit_start && e.config.limit_end && (n.start_date < e.config.limit_start && (n.start_date = new Date(e.config.limit_start)), n.start_date.valueOf() >= e.config.limit_end.valueOf() && (n.start_date = this.date.add(e.config.limit_end, -1, "day")), n.end_date < e.config.limit_start && (n.end_date = new Date(e.config.limit_start)), n.end_date.valueOf() >= e.config.limit_end.valueOf() && (n.end_date = this.date.add(e.config.limit_end, -1, "day")), n.start_date.valueOf() >= n.end_date.valueOf() && (n.end_date = this.date.add(n.start_date, this.config.event_duration || this.config.time_step, "minute")), n._timed = this.isOneDayEvent(n)), !0;
    }), e.attachEvent("onEventChanged", function(t) {
      if (!t)
        return !0;
      var n = e.getEvent(t);
      if (!e.checkLimitViolation(n)) {
        if (!i)
          return !1;
        n.start_date = i[0], n.end_date = i[1], n._timed = this.isOneDayEvent(n);
      }
      return !0;
    }), e.attachEvent("onBeforeEventChanged", function(t, n, s) {
      return e.checkLimitViolation(t);
    }), e.attachEvent("onBeforeEventCreated", function(t) {
      var n = e.getActionData(t).date, s = { _timed: !0, start_date: n, end_date: e.date.add(n, e.config.time_step, "minute") };
      return e.checkLimitViolation(s);
    }), e.attachEvent("onViewChange", function() {
      e._mark_now();
    }), e.attachEvent("onAfterSchedulerResize", function() {
      return window.setTimeout(function() {
        if (e.$destroyed)
          return !0;
        e._mark_now();
      }, 1), !0;
    }), e.attachEvent("onTemplatesReady", function() {
      e._mark_now_timer = window.setInterval(function() {
        e._is_initialized() && e._mark_now();
      }, 6e4);
    }), e.attachEvent("onDestroy", function() {
      clearInterval(e._mark_now_timer);
    });
  }, e._temp_limit_scope();
}, map_view: function(e) {
  let i = null, t = [];
  const n = { googleMap: new ca(e), openStreetMaps: new ha(e), mapbox: new ua(e) };
  function s(o) {
    i = o.ext.mapView.createAdapter(), t.push(e.attachEvent("onEventSave", function(d, r, l) {
      let _ = e.getEvent(d);
      return _ && _.event_location != r.event_location && (e._eventLocationChanged = !0), !0;
    }), e.attachEvent("onEventChanged", (d, r) => {
      const { start_date: l, end_date: _ } = r, { min_date: h, max_date: p } = e.getState();
      return l.valueOf() < p.valueOf() && _.valueOf() > h.valueOf() && i && (e.config.map_settings.resolve_event_location && r.event_location && !e._latLngUpdate ? a(r, i) : i.updateEventMarker(r)), e._latLngUpdate = !1, !0;
    }), e.attachEvent("onEventIdChange", function(d, r) {
      let l = e.getEvent(r);
      i == null || i.removeEventMarker(d), i == null || i.addEventMarker(l);
    }), e.attachEvent("onEventAdded", (d, r) => {
      const { start_date: l, end_date: _ } = r, { min_date: h, max_date: p } = e.getState();
      l.valueOf() < p.valueOf() && _.valueOf() > h.valueOf() && i && (e.config.map_settings.resolve_event_location && r.event_location && e._eventLocationChanged ? (a(r, i), e._eventLocationChanged = !1) : (i.addEventMarker(r), i.onEventClick(r)));
    }), e.attachEvent("onClick", function(d, r) {
      const l = e.getEvent(d);
      return i && l && i.onEventClick(l), !1;
    }), e.attachEvent("onBeforeEventDelete", (d, r) => (i && i.removeEventMarker(d), !0)));
  }
  async function a(o, d) {
    let r = await d.resolveAddress(o.event_location);
    return o.lat = r.lat, o.lng = r.lng, d.removeEventMarker(String(o.id)), d.addEventMarker(o), o;
  }
  e.ext || (e.ext = {}), e.ext.mapView = { createAdapter: function() {
    return n[e.config.map_view_provider];
  }, createMarker: function(o) {
    return new google.maps.Marker(o);
  }, currentAdapter: null, adapters: n }, e._latLngUpdate = !1, e._eventLocationChanged = !1, e.config.map_view_provider = "googleMap", e.config.map_settings = { initial_position: { lat: 48.724, lng: 8.215 }, error_position: { lat: 15, lng: 15 }, initial_zoom: 1, zoom_after_resolve: 15, info_window_max_width: 300, resolve_user_location: !0, resolve_event_location: !0, view_provider: "googleMap" }, e.config.map_initial_position && (e.config.map_settings.initial_position = { lat: e.config.map_initial_position.lat(), lng: e.config.map_initial_position.lng() }), e.config.map_error_position && (e.config.map_settings.error_position = { lat: e.config.map_error_position.lat(), lng: e.config.map_error_position.lng() }), e.xy.map_date_width = 188, e.xy.map_icon_width = 25, e.xy.map_description_width = 400, e.date.add_map = function(o, d, r) {
    return new Date(o.valueOf());
  }, e.templates.map_date = function(o, d, r) {
    return "";
  }, e.templates.map_time = function(o, d, r) {
    return e.config.rtl && !r._timed ? e.templates.day_date(d) + " &ndash; " + e.templates.day_date(o) : r._timed ? this.day_date(r.start_date, r.end_date, r) + " " + this.event_date(o) : e.templates.day_date(o) + " &ndash; " + e.templates.day_date(d);
  }, e.templates.map_text = function(o, d, r) {
    return r.text;
  }, e.templates.map_info_content = function(o) {
    return `<div><b>Event's text:</b> ${o.text}
				<div><b>Location:</b> ${o.event_location}</div>
				<div><b>Starts:</b> ${e.templates.tooltip_date_format(o.start_date)}</div>
				<div><b>Ends:</b> ${e.templates.tooltip_date_format(o.end_date)}</div>
			</div>`;
  }, e.date.map_start = function(o) {
    return o;
  }, e.dblclick_dhx_map_area = function(o) {
    let d = o.target.closest(`[${e.config.event_attribute}]`);
    if (d) {
      let r = d.getAttribute(`${e.config.event_attribute}`);
      e.showLightbox(r);
    }
    this.config.readonly || !this.config.dblclick_create || d || this.addEventNow({ start_date: e.config.map_start, end_date: e.date.add(e.config.map_start, e.config.time_step, "minute") });
  }, e.attachEvent("onSchedulerReady", function() {
    e.config.map_initial_zoom !== void 0 && (e.config.map_settings.initial_zoom = e.config.map_initial_zoom), e.config.map_zoom_after_resolve !== void 0 && (e.config.map_settings.zoom_after_resolve = e.config.map_zoom_after_resolve), e.config.map_infowindow_max_width !== void 0 && (e.config.map_settings.info_window_max_width = e.config.map_infowindow_max_width), e.config.map_resolve_user_location !== void 0 && (e.config.map_settings.resolve_user_location = e.config.map_resolve_user_location), e.config.map_view_provider !== void 0 && (e.config.map_settings.view_provider = e.config.map_view_provider), e.config.map_type !== void 0 && (e.config.map_settings.type = e.config.map_type), e.config.map_resolve_event_location !== void 0 && (e.config.map_settings.resolve_event_location = e.config.map_resolve_event_location), e.ext.mapView.currentAdapter = e.config.map_view_provider;
    let o = document.createElement("div");
    o.className = "mapContainer", o.id = "mapContainer", o.style.display = "none", o.style.zIndex = "1", e._obj.appendChild(o);
    const d = e.render_data;
    function r() {
      let _ = e.get_visible_events();
      _.sort(function(g, c) {
        return g.start_date.valueOf() == c.start_date.valueOf() ? g.id > c.id ? 1 : -1 : g.start_date > c.start_date ? 1 : -1;
      });
      let h = "<div " + e._waiAria.mapAttrString() + " class='dhx_map_area'>";
      for (let g = 0; g < _.length; g++) {
        let c = _[g], f = c.id == e._selected_event_id ? "dhx_map_line highlight" : "dhx_map_line", u = c.color ? "--dhx-scheduler-event-background:" + c.color + ";" : "", y = c.textColor ? "--dhx-scheduler-event-color:" + c.textColor + ";" : "", w = e._waiAria.mapRowAttrString(c), D = e._waiAria.mapDetailsBtnString();
        h += "<div " + w + " class='" + f + "' event_id='" + c.id + "' " + e.config.event_attribute + "='" + c.id + "' style='" + u + y + (c._text_style || "") + " width: " + (e.xy.map_date_width + e.xy.map_description_width + 2) + "px;'><div class='dhx_map_event_time' style='width: " + e.xy.map_date_width + "px;' >" + e.templates.map_time(c.start_date, c.end_date, c) + "</div>", h += `<div ${D} class='dhx_event_icon icon_details'><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
			<path d="M15.4444 16.4H4.55556V7.6H15.4444V16.4ZM13.1111 2V3.6H6.88889V2H5.33333V3.6H4.55556C3.69222 3.6 3 4.312 3 5.2V16.4C3 16.8243 3.16389 17.2313 3.45561 17.5314C3.74733 17.8314 4.143 18 4.55556 18H15.4444C15.857 18 16.2527 17.8314 16.5444 17.5314C16.8361 17.2313 17 16.8243 17 16.4V5.2C17 4.312 16.3 3.6 15.4444 3.6H14.6667V2H13.1111ZM13.8889 10.8H10V14.8H13.8889V10.8Z" fill="#A1A4A6"/>
			</svg></div>`, h += "<div class='line_description' style='width:" + (e.xy.map_description_width - e.xy.map_icon_width) + "px;'>" + e.templates.map_text(c.start_date, c.end_date, c) + "</div></div>";
      }
      h += "<div class='dhx_v_border' style=" + (e.config.rtl ? "'right: " : "'left: ") + (e.xy.map_date_width - 1) + "px;'></div><div class='dhx_v_border_description'></div></div>", e._els.dhx_cal_data[0].scrollTop = 0, e._els.dhx_cal_data[0].innerHTML = h;
      let p = e._els.dhx_cal_data[0].firstChild.childNodes, v = e._getNavDateElement();
      v && (v.innerHTML = e.templates[e._mode + "_date"](e._min_date, e._max_date, e._mode)), e._reset_rendered_events();
      for (let g = 0; g < p.length - 2; g++)
        e._rendered[g] = p[g];
    }
    e.render_data = function(_, h) {
      if (this._mode != "map")
        return d.apply(this, arguments);
      {
        r();
        let p = e.get_visible_events();
        i && (i.clearEventMarkers(), p.forEach((v) => i == null ? void 0 : i.addEventMarker(v)));
      }
    }, e.map_view = function(_) {
      e._els.dhx_cal_data[0].style.width = e.xy.map_date_width + e.xy.map_description_width + 1 + "px", e._min_date = e.config.map_start || e._currentDate(), e._max_date = e.config.map_end || e.date.add(e._currentDate(), 1, "year"), e._table_view = !0, function(g) {
        if (g) {
          const c = e.locale.labels;
          e._els.dhx_cal_header[0].innerHTML = "<div class='dhx_map_head' style='width: " + (e.xy.map_date_width + e.xy.map_description_width + 2) + "px;' ><div class='headline_date' style='width: " + e.xy.map_date_width + "px;'>" + c.date + "</div><div class='headline_description' style='width: " + e.xy.map_description_width + "px;'>" + c.description + "</div></div>", e._table_view = !0, e.set_sizes();
        }
      }(_);
      let h = document.getElementById("mapContainer");
      var p, v;
      (function(g) {
        let c = document.getElementById(g);
        if (c) {
          const f = e.$container.querySelector(".dhx_cal_navline").offsetHeight;
          let u = e.$container.querySelector(".dhx_cal_data").offsetHeight + e.$container.querySelector(".dhx_cal_header").offsetHeight;
          u < 0 && (u = 0);
          let y = e._x - e.xy.map_date_width - e.xy.map_description_width - 1;
          y < 0 && (y = 0), c.style.height = u + "px", c.style.width = y + "px", c.style.position = "absolute", c.style.top = f + "px", e.config.rtl ? c.style.marginRight = e.xy.map_date_width + e.xy.map_description_width + 1 + "px" : c.style.marginLeft = e.xy.map_date_width + e.xy.map_description_width + 1 + "px", c.style.marginTop = e.xy.nav_height + 2 + "px";
        }
      })("mapContainer"), _ && h ? (o.style.display = "block", r(), e.config.map_view_provider == e.ext.mapView.currentAdapter ? (i == null || i.destroy(h), s(e), i == null || i.initialize(h, e.config.map_settings)) : (i == null || i.destroy(h), s(e), i == null || i.initialize(h, e.config.map_settings), e.ext.mapView.currentAdapter = e.config.map_view_provider), i && (p = e.config.map_settings, v = i, p.resolve_user_location ? navigator.geolocation && navigator.geolocation.getCurrentPosition(function(g) {
        v.setView(g.coords.latitude, g.coords.longitude, p.zoom_after_resolve || p.initial_zoom);
      }) : v.setView(p.initial_position.lat, p.initial_position.lng, p.initial_zoom))) : (o.style.display = "none", e._els.dhx_cal_data[0].style.width = "100%", i && h && (i.destroy(h), i = null, e.ext.mapView.currentAdapter = e.config.map_view_provider), t.forEach((g) => e.detachEvent(g)), t = []);
    }, e.attachEvent("onLocationError", function(_) {
      return alert("Location can't be found"), google.maps.LatLng(51.47784, -1492e-6);
    });
    let l = async function(_) {
      if (i) {
        const h = await i.resolveAddress(_.event_location);
        h.lat && h.lng ? (_.lat = +h.lat, _.lng = +h.lng) : (e.callEvent("onLocationError", [_.id]), _.lng = e.config.map_settings.error_position.lng, _.lat = e.config.map_settings.error_position.lat), e._latLngUpdate = !0, e.callEvent("onEventChanged", [_.id, _]);
      }
    };
    e._event_resolve_delay = 1500, e.attachEvent("onEventLoading", function(_) {
      return _.lat && _.lng && (_.lat = +_.lat, _.lng = +_.lng), e.config.map_settings.resolve_event_location && _.event_location && !_.lat && !_.lng && (e._event_resolve_delay += 1500, function(h, p, v, g) {
        setTimeout(function() {
          if (e.$destroyed)
            return !0;
          let c = h.apply(p, v);
          return h = p = v = null, c;
        }, g || 1);
      }(l, this, [_], e._event_resolve_delay)), !0;
    });
  });
}, minical: function(e) {
  const i = e._createDomEventScope();
  e.config.minicalendar = { mark_events: !0 }, e._synced_minicalendars = [], e.renderCalendar = function(t, n, s) {
    var a = null, o = t.date || e._currentDate();
    if (typeof o == "string" && (o = this.templates.api_date(o)), n)
      a = this._render_calendar(n.parentNode, o, t, n), e.unmarkCalendar(a);
    else {
      var d = t.container, r = t.position;
      if (typeof d == "string" && (d = document.getElementById(d)), typeof r == "string" && (r = document.getElementById(r)), r && r.left === void 0 && r.right === void 0) {
        var l = e.$domHelpers.getOffset(r);
        r = { top: l.top + r.offsetHeight, left: l.left };
      }
      d || (d = e._get_def_cont(r)), (a = this._render_calendar(d, o, t)).$_eventAttached || (a.$_eventAttached = !0, i.attach(a, "click", (function(y) {
        var w = y.target || y.srcElement, D = e.$domHelpers;
        if (D.closest(w, ".dhx_month_head") && !D.closest(w, ".dhx_after") && !D.closest(w, ".dhx_before")) {
          var M = D.closest(w, "[data-cell-date]").getAttribute("data-cell-date"), k = e.templates.parse_date(M);
          e.unmarkCalendar(this), e.markCalendar(this, k, "dhx_calendar_click"), this._last_date = k, this.conf.events && this.conf.events.onDateClick && this.conf.events.onDateClick.call(this, k, y), this.conf.handler && this.conf.handler.call(e, k, this);
        }
      }).bind(a)), i.attach(a, "mouseover", (function(y) {
        const w = y.target;
        if (w.classList.contains("dhx_cal_month_cell")) {
          var D = w.getAttribute("data-cell-date"), M = e.templates.parse_date(D);
          this.conf.events && this.conf.events.onDateMouseOver && this.conf.events.onDateMouseOver.call(this, M, y);
        }
      }).bind(a)));
    }
    if (e.config.minicalendar.mark_events)
      for (var _ = e.date.month_start(o), h = e.date.add(_, 1, "month"), p = this.getEvents(_, h), v = this["filter_" + this._mode], g = {}, c = 0; c < p.length; c++) {
        var f = p[c];
        if (!v || v(f.id, f)) {
          var u = f.start_date;
          for (u.valueOf() < _.valueOf() && (u = _), u = e.date.date_part(new Date(u.valueOf())); u < f.end_date && (g[+u] || (g[+u] = !0, this.markCalendar(a, u, "dhx_year_event")), !((u = this.date.add(u, 1, "day")).valueOf() >= h.valueOf())); )
            ;
        }
      }
    return this._markCalendarCurrentDate(a), a.conf = t, t.sync && !s && this._synced_minicalendars.push(a), a.conf._on_xle_handler || (a.conf._on_xle_handler = e.attachEvent("onXLE", function() {
      e.updateCalendar(a, a.conf.date);
    })), this.config.wai_aria_attributes && this.config.wai_aria_application_role && a.setAttribute("role", "application"), a;
  }, e._get_def_cont = function(t) {
    return this._def_count || (this._def_count = document.createElement("div"), this._def_count.className = "dhx_minical_popup", e.event(this._def_count, "click", function(n) {
      n.cancelBubble = !0;
    }), document.body.appendChild(this._def_count)), t.left && (this._def_count.style.left = t.left + "px"), t.right && (this._def_count.style.right = t.right + "px"), t.top && (this._def_count.style.top = t.top + "px"), t.bottom && (this._def_count.style.bottom = t.bottom + "px"), this._def_count._created = /* @__PURE__ */ new Date(), this._def_count;
  }, e._locateCalendar = function(t, n) {
    if (typeof n == "string" && (n = e.templates.api_date(n)), +n > +t._max_date || +n < +t._min_date)
      return null;
    for (var s = t.querySelector(".dhx_year_body").childNodes[0], a = 0, o = new Date(t._min_date); +this.date.add(o, 1, "week") <= +n; )
      o = this.date.add(o, 1, "week"), a++;
    var d = e.config.start_on_monday, r = (n.getDay() || (d ? 7 : 0)) - (d ? 1 : 0);
    const l = s.querySelector(`.dhx_cal_month_row:nth-child(${a + 1}) .dhx_cal_month_cell:nth-child(${r + 1})`);
    return l ? l.firstChild : null;
  }, e.markCalendar = function(t, n, s) {
    var a = this._locateCalendar(t, n);
    a && (a.className += " " + s);
  }, e.unmarkCalendar = function(t, n, s) {
    if (s = s || "dhx_calendar_click", n = n || t._last_date) {
      var a = this._locateCalendar(t, n);
      a && (a.className = (a.className || "").replace(RegExp(s, "g")));
    }
  }, e._week_template = function(t) {
    for (var n = t || 250, s = 0, a = document.createElement("div"), o = this.date.week_start(e._currentDate()), d = 0; d < 7; d++)
      this._cols[d] = Math.floor(n / (7 - d)), this._render_x_header(d, s, o, a), o = this.date.add(o, 1, "day"), n -= this._cols[d], s += this._cols[d];
    return a.lastChild.className += " dhx_scale_bar_last", a;
  }, e.updateCalendar = function(t, n) {
    if (t.conf.date && t.conf.events && t.conf.events.onBeforeMonthChange && t.conf.events.onBeforeMonthChange.call(t, t.conf.date, n, t) === !1)
      return;
    const s = t.conf.date;
    t.conf.date = n, this.renderCalendar(t.conf, t, !0), t.conf.events && t.conf.events.onMonthChange && t.conf.events.onMonthChange.call(t, s, n);
  }, e._mini_cal_arrows = ["&nbsp;", "&nbsp;"], e._render_calendar = function(t, n, s, a) {
    var o = e.templates, d = this._cols;
    this._cols = [];
    var r = this._mode;
    this._mode = "calendar";
    var l = this._colsS;
    this._colsS = { height: 0 };
    var _ = new Date(this._min_date), h = new Date(this._max_date), p = new Date(e._date), v = o.month_day, g = this._ignores_detected;
    this._ignores_detected = 0, o.month_day = o.calendar_date, n = this.date.month_start(n);
    var c, f = this._week_template(t.offsetWidth - 1 - this.config.minicalendar.padding);
    a ? c = a : ((c = document.createElement("div")).className = "dhx_cal_container dhx_mini_calendar", this.config.rtl && (c.className += " dhx_cal_container_rtl")), c.setAttribute("date", this._helpers.formatDate(n)), c.innerHTML = "<div class='dhx_year_month'></div><div class='dhx_year_grid" + (e.config.rtl ? " dhx_grid_rtl'>" : "'>") + "<div class='dhx_year_week'>" + (f ? f.innerHTML : "") + "</div><div class='dhx_year_body'></div></div>";
    var u = c.querySelector(".dhx_year_month"), y = c.querySelector(".dhx_year_week"), w = c.querySelector(".dhx_year_body");
    if (u.innerHTML = this.templates.calendar_month(n), s.navigation)
      for (var D = function(O, P) {
        var R = e.date.add(O._date, P, "month");
        e.updateCalendar(O, R), e._date.getMonth() == O._date.getMonth() && e._date.getFullYear() == O._date.getFullYear() && e._markCalendarCurrentDate(O);
      }, M = ["dhx_cal_prev_button", "dhx_cal_next_button"], k = ["left:1px;top:4px;position:absolute;", "left:auto; right:1px;top:4px;position:absolute;"], N = [-1, 1], m = function(O) {
        return function() {
          if (s.sync)
            for (var P = e._synced_minicalendars, R = 0; R < P.length; R++)
              D(P[R], O);
          else
            e.config.rtl && (O = -O), D(c, O);
        };
      }, x = [e.locale.labels.prev, e.locale.labels.next], b = 0; b < 2; b++) {
        var E = document.createElement("div");
        E.className = M[b], e._waiAria.headerButtonsAttributes(E, x[b]), E.style.cssText = k[b], E.innerHTML = this._mini_cal_arrows[b], u.appendChild(E), i.attach(E, "click", m(N[b]));
      }
    c._date = new Date(n), c.week_start = (n.getDay() - (this.config.start_on_monday ? 1 : 0) + 7) % 7;
    var S = c._min_date = this.date.week_start(n);
    c._max_date = this.date.add(c._min_date, 6, "week"), this._reset_month_scale(w, n, S, 6), a || t.appendChild(c), y.style.height = y.childNodes[0].offsetHeight - 1 + "px";
    var T = e.uid();
    e._waiAria.minicalHeader(u, T), e._waiAria.minicalGrid(c.querySelector(".dhx_year_grid"), T), e._waiAria.minicalRow(y);
    for (var C = y.querySelectorAll(".dhx_scale_bar"), A = 0; A < C.length; A++)
      e._waiAria.minicalHeadCell(C[A]);
    var $ = w.querySelectorAll(".dhx_cal_month_cell"), H = new Date(S);
    for (A = 0; A < $.length; A++)
      e._waiAria.minicalDayCell($[A], new Date(H)), H = e.date.add(H, 1, "day");
    return e._waiAria.minicalHeader(u, T), this._cols = d, this._mode = r, this._colsS = l, this._min_date = _, this._max_date = h, e._date = p, o.month_day = v, this._ignores_detected = g, c;
  }, e.destroyCalendar = function(t, n) {
    !t && this._def_count && this._def_count.firstChild && (n || (/* @__PURE__ */ new Date()).valueOf() - this._def_count._created.valueOf() > 500) && (t = this._def_count.firstChild), t && (i.detachAll(), t.innerHTML = "", t.parentNode && t.parentNode.removeChild(t), this._def_count && (this._def_count.style.top = "-1000px"), t.conf && t.conf._on_xle_handler && e.detachEvent(t.conf._on_xle_handler));
  }, e.isCalendarVisible = function() {
    return !!(this._def_count && parseInt(this._def_count.style.top, 10) > 0) && this._def_count;
  }, e.attachEvent("onTemplatesReady", function() {
    e.event(document.body, "click", function() {
      e.destroyCalendar();
    });
  }, { once: !0 }), e.form_blocks.calendar_time = { render: function(t) {
    var n = "<span class='dhx_minical_input_wrapper'><input class='dhx_readonly dhx_minical_input' type='text' readonly='true'></span>", s = e.config, a = this.date.date_part(e._currentDate()), o = 1440, d = 0;
    s.limit_time_select && (d = 60 * s.first_hour, o = 60 * s.last_hour + 1), a.setHours(d / 60), t._time_values = [], n += " <select class='dhx_lightbox_time_select'>";
    for (var r = d; r < o; r += 1 * this.config.time_step)
      n += "<option value='" + r + "'>" + this.templates.time_picker(a) + "</option>", t._time_values.push(r), a = this.date.add(a, this.config.time_step, "minute");
    return "<div class='dhx_section_time dhx_lightbox_minical'>" + (n += "</select>") + "<span class='dhx_lightbox_minical_spacer'> &nbsp;&ndash;&nbsp; </span>" + n + "</div>";
  }, set_value: function(t, n, s, a) {
    var o, d, r = t.getElementsByTagName("input"), l = t.getElementsByTagName("select"), _ = function(u, y, w) {
      e.event(u, "click", function() {
        e.destroyCalendar(null, !0), e.renderCalendar({ position: u, date: new Date(this._date), navigation: !0, handler: function(D) {
          u.value = e.templates.calendar_time(D), u._date = new Date(D), e.destroyCalendar(), e.config.event_duration && e.config.auto_end_date && w === 0 && g();
        } });
      });
    };
    if (e.config.full_day) {
      if (!t._full_day) {
        var h = "<label class='dhx_fullday'><input type='checkbox' name='full_day' value='true'> " + e.locale.labels.full_day + "&nbsp;</label></input>";
        e.config.wide_form || (h = t.previousSibling.innerHTML + h), t.previousSibling.innerHTML = h, t._full_day = !0;
      }
      var p = t.previousSibling.getElementsByTagName("input")[0], v = e.date.time_part(s.start_date) === 0 && e.date.time_part(s.end_date) === 0;
      p.checked = v, l[0].disabled = p.checked, l[1].disabled = p.checked, p.$_eventAttached || (p.$_eventAttached = !0, e.event(p, "click", function() {
        if (p.checked === !0) {
          var u = {};
          e.form_blocks.calendar_time.get_value(t, u), o = e.date.date_part(u.start_date), (+(d = e.date.date_part(u.end_date)) == +o || +d >= +o && (s.end_date.getHours() !== 0 || s.end_date.getMinutes() !== 0)) && (d = e.date.add(d, 1, "day"));
        } else
          o = null, d = null;
        var y = o || s.start_date, w = d || s.end_date;
        c(r[0], y), c(r[1], w), l[0].value = 60 * y.getHours() + y.getMinutes(), l[1].value = 60 * w.getHours() + w.getMinutes(), l[0].disabled = p.checked, l[1].disabled = p.checked;
      }));
    }
    if (e.config.event_duration && e.config.auto_end_date) {
      var g = function() {
        e.config.auto_end_date && e.config.event_duration && (o = e.date.add(r[0]._date, l[0].value, "minute"), d = new Date(o.getTime() + 60 * e.config.event_duration * 1e3), r[1].value = e.templates.calendar_time(d), r[1]._date = e.date.date_part(new Date(d)), l[1].value = 60 * d.getHours() + d.getMinutes());
      };
      l[0].$_eventAttached || l[0].addEventListener("change", g);
    }
    function c(u, y, w) {
      _(u, y, w), u.value = e.templates.calendar_time(y), u._date = e.date.date_part(new Date(y));
    }
    function f(u) {
      for (var y = a._time_values, w = 60 * u.getHours() + u.getMinutes(), D = w, M = !1, k = 0; k < y.length; k++) {
        var N = y[k];
        if (N === w) {
          M = !0;
          break;
        }
        N < w && (D = N);
      }
      return M || D ? M ? w : D : -1;
    }
    c(r[0], s.start_date, 0), c(r[1], s.end_date, 1), _ = function() {
    }, l[0].value = f(s.start_date), l[1].value = f(s.end_date);
  }, get_value: function(t, n) {
    var s = t.getElementsByTagName("input"), a = t.getElementsByTagName("select");
    return n.start_date = e.date.add(s[0]._date, a[0].value, "minute"), n.end_date = e.date.add(s[1]._date, a[1].value, "minute"), n.end_date <= n.start_date && (n.end_date = e.date.add(n.start_date, e.config.time_step, "minute")), { start_date: new Date(n.start_date), end_date: new Date(n.end_date) };
  }, focus: function(t) {
  } }, e.linkCalendar = function(t, n) {
    var s = function() {
      var a = e._date, o = new Date(a.valueOf());
      return n && (o = n(o)), o.setDate(1), e.updateCalendar(t, o), !0;
    };
    e.attachEvent("onViewChange", s), e.attachEvent("onXLE", s), e.attachEvent("onEventAdded", s), e.attachEvent("onEventChanged", s), e.attachEvent("onEventDeleted", s), s();
  }, e._markCalendarCurrentDate = function(t) {
    var n = e.getState(), s = n.min_date, a = n.max_date, o = n.mode, d = e.date.month_start(new Date(t._date)), r = e.date.add(d, 1, "month");
    if (!({ month: !0, year: !0, agenda: !0, grid: !0 }[o] || s.valueOf() <= d.valueOf() && a.valueOf() >= r.valueOf()))
      for (var l = s; l.valueOf() < a.valueOf(); )
        d.valueOf() <= l.valueOf() && r > l && e.markCalendar(t, l, "dhx_calendar_click"), l = e.date.add(l, 1, "day");
  }, e.attachEvent("onEventCancel", function() {
    e.destroyCalendar(null, !0);
  }), e.attachEvent("onDestroy", function() {
    e.destroyCalendar();
  });
}, monthheight: function(e) {
  e.attachEvent("onTemplatesReady", function() {
    e.xy.scroll_width = 0;
    var i = e.render_view_data;
    e.render_view_data = function() {
      var n = this._els.dhx_cal_data[0];
      n.firstChild._h_fix = !0, i.apply(e, arguments);
      var s = parseInt(n.style.height);
      n.style.height = "1px", n.style.height = n.scrollHeight + "px", this._obj.style.height = this._obj.clientHeight + n.scrollHeight - s + "px";
    };
    var t = e._reset_month_scale;
    e._reset_month_scale = function(n, s, a, o) {
      var d = { clientHeight: 100 };
      t.apply(e, [d, s, a, o]), n.innerHTML = d.innerHTML;
    };
  });
}, multisection: function(e) {
  ce("Multisection", e.assert);
}, multiselect: function(e) {
  e.form_blocks.multiselect = { render: function(i) {
    var t = "dhx_multi_select_control dhx_multi_select_" + i.name;
    i.vertical && (t += " dhx_multi_select_control_vertical");
    for (var n = "<div class='" + t + "' style='overflow: auto; height: " + i.height + "px; position: relative;' >", s = 0; s < i.options.length; s++)
      n += "<label><input type='checkbox' value='" + i.options[s].key + "'/>" + i.options[s].label + "</label>";
    return n += "</div>";
  }, set_value: function(i, t, n, s) {
    for (var a = i.getElementsByTagName("input"), o = 0; o < a.length; o++)
      a[o].checked = !1;
    function d(p) {
      for (var v = i.getElementsByTagName("input"), g = 0; g < v.length; g++)
        v[g].checked = !!p[v[g].value];
    }
    var r = {};
    if (n[s.map_to]) {
      var l = (n[s.map_to] + "").split(s.delimiter || e.config.section_delimiter || ",");
      for (o = 0; o < l.length; o++)
        r[l[o]] = !0;
      d(r);
    } else {
      if (e._new_event || !s.script_url)
        return;
      var _ = document.createElement("div");
      _.className = "dhx_loading", _.style.cssText = "position: absolute; top: 40%; left: 40%;", i.appendChild(_);
      var h = [s.script_url, s.script_url.indexOf("?") == -1 ? "?" : "&", "dhx_crosslink_" + s.map_to + "=" + n.id + "&uid=" + e.uid()].join("");
      e.ajax.get(h, function(p) {
        var v = function(g) {
          try {
            for (var c = JSON.parse(g.xmlDoc.responseText), f = {}, u = 0; u < c.length; u++) {
              var y = c[u];
              f[y.value || y.key || y.id] = !0;
            }
            return f;
          } catch {
            return null;
          }
        }(p);
        v || (v = function(g, c) {
          for (var f = e.ajax.xpath("//data/item", g.xmlDoc), u = {}, y = 0; y < f.length; y++)
            u[f[y].getAttribute(c.map_to)] = !0;
          return u;
        }(p, s)), d(v), i.removeChild(_);
      });
    }
  }, get_value: function(i, t, n) {
    for (var s = [], a = i.getElementsByTagName("input"), o = 0; o < a.length; o++)
      a[o].checked && s.push(a[o].value);
    return s.join(n.delimiter || e.config.section_delimiter || ",");
  }, focus: function(i) {
  } };
}, multisource: function(e) {
  var i = e._load;
  e._load = function(t, n) {
    if (typeof (t = t || this._load_url) == "object")
      for (var s = function(o) {
        var d = function() {
        };
        return d.prototype = o, d;
      }(this._loaded), a = 0; a < t.length; a++)
        this._loaded = new s(), i.call(this, t[a], n);
    else
      i.apply(this, arguments);
  };
}, mvc: function(e) {
  var i, t = { use_id: !1 };
  function n(o) {
    var d = {};
    for (var r in o)
      r.indexOf("_") !== 0 && (d[r] = o[r]);
    return t.use_id || delete d.id, d;
  }
  function s(o) {
    o._not_render = !1, o._render_wait && o.render_view_data(), o._loading = !1, o.callEvent("onXLE", []);
  }
  function a(o) {
    return t.use_id ? o.id : o.cid;
  }
  e.backbone = function(o, d) {
    d && (t = d), o.bind("change", function(_, h) {
      var p = a(_), v = e._events[p] = _.toJSON();
      v.id = p, e._init_event(v), clearTimeout(i), i = setTimeout(function() {
        if (e.$destroyed)
          return !0;
        e.updateView();
      }, 1);
    }), o.bind("remove", function(_, h) {
      var p = a(_);
      e._events[p] && e.deleteEvent(p);
    });
    var r = [];
    function l() {
      if (e.$destroyed)
        return !0;
      r.length && (e.parse(r, "json"), r = []);
    }
    o.bind("add", function(_, h) {
      var p = a(_);
      if (!e._events[p]) {
        var v = _.toJSON();
        v.id = p, e._init_event(v), r.push(v), r.length == 1 && setTimeout(l, 1);
      }
    }), o.bind("request", function(_) {
      var h;
      _ instanceof Backbone.Collection && ((h = e)._loading = !0, h._not_render = !0, h.callEvent("onXLS", []));
    }), o.bind("sync", function(_) {
      _ instanceof Backbone.Collection && s(e);
    }), o.bind("error", function(_) {
      _ instanceof Backbone.Collection && s(e);
    }), e.attachEvent("onEventCreated", function(_) {
      var h = new o.model(e.getEvent(_));
      return e._events[_] = h.toJSON(), e._events[_].id = _, !0;
    }), e.attachEvent("onEventAdded", function(_) {
      if (!o.get(_)) {
        var h = n(e.getEvent(_)), p = new o.model(h), v = a(p);
        v != _ && this.changeEventId(_, v), o.add(p), o.trigger("scheduler:add", p);
      }
      return !0;
    }), e.attachEvent("onEventChanged", function(_) {
      var h = o.get(_), p = n(e.getEvent(_));
      return h.set(p), o.trigger("scheduler:change", h), !0;
    }), e.attachEvent("onEventDeleted", function(_) {
      var h = o.get(_);
      return h && (o.trigger("scheduler:remove", h), o.remove(_)), !0;
    });
  };
}, outerdrag: function(e) {
  e.attachEvent("onTemplatesReady", function() {
    var i, t = new dhtmlDragAndDropObject(), n = t.stopDrag;
    function s(a, o, d, r) {
      if (!e.checkEvent("onBeforeExternalDragIn") || e.callEvent("onBeforeExternalDragIn", [a, o, d, r, i])) {
        var l = e.attachEvent("onEventCreated", function(g) {
          e.callEvent("onExternalDragIn", [g, a, i]) || (this._drag_mode = this._drag_id = null, this.deleteEvent(g));
        }), _ = e.getActionData(i), h = { start_date: new Date(_.date) };
        if (e.matrix && e.matrix[e._mode]) {
          var p = e.matrix[e._mode];
          h[p.y_property] = _.section;
          var v = e._locate_cell_timeline(i);
          h.start_date = p._trace_x[v.x], h.end_date = e.date.add(h.start_date, p.x_step, p.x_unit);
        }
        e._props && e._props[e._mode] && (h[e._props[e._mode].map_to] = _.section), e.addEventNow(h), e.detachEvent(l);
      }
    }
    t.stopDrag = function(a) {
      return i = a, n.apply(this, arguments);
    }, t.addDragLanding(e._els.dhx_cal_data[0], { _drag: function(a, o, d, r) {
      s(a, o, d, r);
    }, _dragIn: function(a, o) {
      return a;
    }, _dragOut: function(a) {
      return this;
    } }), dhtmlx.DragControl && dhtmlx.DragControl.addDrop(e._els.dhx_cal_data[0], { onDrop: function(a, o, d, r) {
      var l = dhtmlx.DragControl.getMaster(a);
      i = r, s(a, l, o, r.target || r.srcElement);
    }, onDragIn: function(a, o, d) {
      return o;
    } }, !0);
  });
}, pdf: function(e) {
  var i, t, n = new RegExp("<[^>]*>", "g"), s = new RegExp("<br[^>]*>", "g");
  function a(k) {
    return k.replace(s, `
`).replace(n, "");
  }
  function o(k, N) {
    k = parseFloat(k), N = parseFloat(N), isNaN(N) || (k -= N);
    var m = r(k);
    return k = k - m.width + m.cols * i, isNaN(k) ? "auto" : 100 * k / i;
  }
  function d(k, N, m) {
    k = parseFloat(k), N = parseFloat(N), !isNaN(N) && m && (k -= N);
    var x = r(k);
    return k = k - x.width + x.cols * i, isNaN(k) ? "auto" : 100 * k / (i - (isNaN(N) ? 0 : N));
  }
  function r(k) {
    for (var N = 0, m = e._els.dhx_cal_header[0].childNodes, x = m[1] ? m[1].childNodes : m[0].childNodes, b = 0; b < x.length; b++) {
      var E = x[b].style ? x[b] : x[b].parentNode, S = parseFloat(E.style.width);
      if (!(k > S))
        break;
      k -= S + 1, N += S + 1;
    }
    return { width: N, cols: b };
  }
  function l(k) {
    return k = parseFloat(k), isNaN(k) ? "auto" : 100 * k / t;
  }
  function _(k, N) {
    return (window.getComputedStyle ? window.getComputedStyle(k, null)[N] : k.currentStyle ? k.currentStyle[N] : null) || "";
  }
  function h(k, N) {
    for (var m = parseInt(k.style.left, 10), x = 0; x < e._cols.length; x++)
      if ((m -= e._cols[x]) < 0)
        return x;
    return N;
  }
  function p(k, N) {
    for (var m = parseInt(k.style.top, 10), x = 0; x < e._colsS.heights.length; x++)
      if (e._colsS.heights[x] > m)
        return x;
    return N;
  }
  function v(k) {
    return k ? "<" + k + ">" : "";
  }
  function g(k) {
    return k ? "</" + k + ">" : "";
  }
  function c(k, N, m, x) {
    var b = "<" + k + " profile='" + N + "'";
    return m && (b += " header='" + m + "'"), x && (b += " footer='" + x + "'"), b += ">";
  }
  function f() {
    var k = "", N = e._mode;
    if (e.matrix && e.matrix[e._mode] && (N = e.matrix[e._mode].render == "cell" ? "matrix" : "timeline"), k += "<scale mode='" + N + "' today='" + e._els.dhx_cal_date[0].innerHTML + "'>", e._mode == "week_agenda")
      for (var m = e._els.dhx_cal_data[0].getElementsByTagName("DIV"), x = 0; x < m.length; x++)
        m[x].className == "dhx_wa_scale_bar" && (k += "<column>" + a(m[x].innerHTML) + "</column>");
    else if (e._mode == "agenda" || e._mode == "map")
      k += "<column>" + a((m = e._els.dhx_cal_header[0].childNodes[0].childNodes)[0].innerHTML) + "</column><column>" + a(m[1].innerHTML) + "</column>";
    else if (e._mode == "year")
      for (m = e._els.dhx_cal_data[0].childNodes, x = 0; x < m.length; x++)
        k += "<month label='" + a(m[x].querySelector(".dhx_year_month").innerHTML) + "'>", k += y(m[x].querySelector(".dhx_year_week").childNodes), k += u(m[x].querySelector(".dhx_year_body")), k += "</month>";
    else {
      k += "<x>", k += y(m = e._els.dhx_cal_header[0].childNodes), k += "</x>";
      var b = e._els.dhx_cal_data[0];
      if (e.matrix && e.matrix[e._mode]) {
        for (k += "<y>", x = 0; x < b.firstChild.rows.length; x++)
          k += "<row><![CDATA[" + a(b.firstChild.rows[x].cells[0].innerHTML) + "]]></row>";
        k += "</y>", t = b.firstChild.rows[0].cells[0].offsetHeight;
      } else if (b.firstChild.tagName == "TABLE")
        k += u(b);
      else {
        for (b = b.childNodes[b.childNodes.length - 1]; b.className.indexOf("dhx_scale_holder") == -1; )
          b = b.previousSibling;
        for (b = b.childNodes, k += "<y>", x = 0; x < b.length; x++)
          k += `
<row><![CDATA[` + a(b[x].innerHTML) + "]]></row>";
        k += "</y>", t = b[0].offsetHeight;
      }
    }
    return k += "</scale>";
  }
  function u(k) {
    for (var N = "", m = k.querySelectorAll("tr"), x = 0; x < m.length; x++) {
      for (var b = [], E = m[x].querySelectorAll("td"), S = 0; S < E.length; S++)
        b.push(E[S].querySelector(".dhx_month_head").innerHTML);
      N += `
<row height='` + E[0].offsetHeight + "'><![CDATA[" + a(b.join("|")) + "]]></row>", t = E[0].offsetHeight;
    }
    return N;
  }
  function y(k) {
    var N, m = "";
    e.matrix && e.matrix[e._mode] && (e.matrix[e._mode].second_scale && (N = k[1].childNodes), k = k[0].childNodes);
    for (var x = 0; x < k.length; x++)
      m += `
<column><![CDATA[` + a(k[x].innerHTML) + "]]></column>";
    if (i = k[0].offsetWidth, N) {
      var b = 0, E = k[0].offsetWidth, S = 1;
      for (x = 0; x < N.length; x++)
        m += `
<column second_scale='` + S + "'><![CDATA[" + a(N[x].innerHTML) + "]]></column>", (b += N[x].offsetWidth) >= E && (E += k[S] ? k[S].offsetWidth : 0, S++), i = N[0].offsetWidth;
    }
    return m;
  }
  function w(k) {
    var N = "", m = e._rendered, x = e.matrix && e.matrix[e._mode];
    if (e._mode == "agenda" || e._mode == "map")
      for (var b = 0; b < m.length; b++)
        N += "<event><head><![CDATA[" + a(m[b].childNodes[0].innerHTML) + "]]></head><body><![CDATA[" + a(m[b].childNodes[2].innerHTML) + "]]></body></event>";
    else if (e._mode == "week_agenda")
      for (b = 0; b < m.length; b++)
        N += "<event day='" + m[b].parentNode.getAttribute("day") + "'><body>" + a(m[b].innerHTML) + "</body></event>";
    else if (e._mode == "year")
      for (m = e.get_visible_events(), b = 0; b < m.length; b++) {
        var E = m[b].start_date;
        for (E.valueOf() < e._min_date.valueOf() && (E = e._min_date); E < m[b].end_date; ) {
          var S = E.getMonth() + 12 * (E.getFullYear() - e._min_date.getFullYear()) - e.week_starts._month, T = e.week_starts[S] + E.getDate() - 1, C = k ? _(e._get_year_cell(E), "color") : "", A = k ? _(e._get_year_cell(E), "backgroundColor") : "";
          if (N += "<event day='" + T % 7 + "' week='" + Math.floor(T / 7) + "' month='" + S + "' backgroundColor='" + A + "' color='" + C + "'></event>", (E = e.date.add(E, 1, "day")).valueOf() >= e._max_date.valueOf())
            break;
        }
      }
    else if (x && x.render == "cell")
      for (m = e._els.dhx_cal_data[0].getElementsByTagName("TD"), b = 0; b < m.length; b++)
        C = k ? _(m[b], "color") : "", N += `
<event><body backgroundColor='` + (A = k ? _(m[b], "backgroundColor") : "") + "' color='" + C + "'><![CDATA[" + a(m[b].innerHTML) + "]]></body></event>";
    else
      for (b = 0; b < m.length; b++) {
        var $, H;
        if (e.matrix && e.matrix[e._mode])
          $ = o(m[b].style.left), H = o(m[b].offsetWidth) - 1;
        else {
          var O = e.config.use_select_menu_space ? 0 : 26;
          $ = d(m[b].style.left, O, !0), H = d(m[b].style.width, O) - 1;
        }
        if (!isNaN(1 * H)) {
          var P = l(m[b].style.top), R = l(m[b].style.height), j = m[b].className.split(" ")[0].replace("dhx_cal_", "");
          if (j !== "dhx_tooltip_line") {
            var I = e.getEvent(m[b].getAttribute(e.config.event_attribute));
            if (I) {
              T = I._sday;
              var U = I._sweek, B = I._length || 0;
              if (e._mode == "month")
                R = parseInt(m[b].offsetHeight, 10), P = parseInt(m[b].style.top, 10) - e.xy.month_head_height, T = h(m[b], T), U = p(m[b], U);
              else if (e.matrix && e.matrix[e._mode]) {
                T = 0, U = m[b].parentNode.parentNode.parentNode.rowIndex;
                var W = t;
                t = m[b].parentNode.offsetHeight, P = l(m[b].style.top), P -= 0.2 * P, t = W;
              } else {
                if (m[b].parentNode == e._els.dhx_cal_data[0])
                  continue;
                var pe = e._els.dhx_cal_data[0].childNodes[0], Nt = parseFloat(pe.className.indexOf("dhx_scale_holder") != -1 ? pe.style.left : 0);
                $ += o(m[b].parentNode.style.left, Nt);
              }
              N += `
<event week='` + U + "' day='" + T + "' type='" + j + "' x='" + $ + "' y='" + P + "' width='" + H + "' height='" + R + "' len='" + B + "'>", j == "event" ? (N += "<header><![CDATA[" + a(m[b].childNodes[1].innerHTML) + "]]></header>", C = k ? _(m[b].childNodes[2], "color") : "", N += "<body backgroundColor='" + (A = k ? _(m[b].childNodes[2], "backgroundColor") : "") + "' color='" + C + "'><![CDATA[" + a(m[b].childNodes[2].innerHTML) + "]]></body>") : (C = k ? _(m[b], "color") : "", N += "<body backgroundColor='" + (A = k ? _(m[b], "backgroundColor") : "") + "' color='" + C + "'><![CDATA[" + a(m[b].innerHTML) + "]]></body>"), N += "</event>";
            }
          }
        }
      }
    return N;
  }
  function D(k, N, m, x, b, E) {
    var S = !1;
    x == "fullcolor" && (S = !0, x = "color"), x = x || "color";
    var T = "";
    if (k) {
      var C = e._date, A = e._mode;
      N = e.date[m + "_start"](N), N = e.date["get_" + m + "_end"] ? e.date["get_" + m + "_end"](N) : e.date.add(N, 1, m), T = c("pages", x, b, E);
      for (var $ = new Date(k); +$ < +N; $ = this.date.add($, 1, m))
        this.setCurrentView($, m), T += v("page") + f().replace("–", "-") + w(S) + g("page");
      T += g("pages"), this.setCurrentView(C, A);
    } else
      T = c("data", x, b, E) + f().replace("–", "-") + w(S) + g("data");
    return T;
  }
  function M(k, N, m, x, b, E, S) {
    (function(T, C) {
      var A = e.uid(), $ = document.createElement("div");
      $.style.display = "none", document.body.appendChild($), $.innerHTML = '<form id="' + A + '" method="post" target="_blank" action="' + C + '" accept-charset="utf-8" enctype="application/x-www-form-urlencoded"><input type="hidden" name="mycoolxmlbody"/> </form>', document.getElementById(A).firstChild.value = encodeURIComponent(T), document.getElementById(A).submit(), $.parentNode.removeChild($);
    })(typeof b == "object" ? function(T) {
      for (var C = "<data>", A = 0; A < T.length; A++)
        C += T[A].source.getPDFData(T[A].start, T[A].end, T[A].view, T[A].mode, T[A].header, T[A].footer);
      return C += "</data>", C;
    }(b) : D.apply(this, [k, N, m, b, E, S]), x);
  }
  e.getPDFData = D, e.toPDF = function(k, N, m, x) {
    return M.apply(this, [null, null, null, k, N, m, x]);
  }, e.toPDFRange = function(k, N, m, x, b, E, S) {
    return typeof k == "string" && (k = e.templates.api_date(k), N = e.templates.api_date(N)), M.apply(this, arguments);
  };
}, quick_info: function(e) {
  e.config.icons_select = ["icon_form", "icon_delete"], e.config.details_on_create = !0, e.config.show_quick_info = !0, e.xy.menu_width = 0;
  let i = null;
  function t(s) {
    const a = s.getBoundingClientRect(), o = e.$container.getBoundingClientRect().bottom - a.bottom;
    o < 0 && (s.style.top = `${parseFloat(s.style.top) + o}px`);
  }
  function n(s) {
    let a = 0, o = 0, d = s;
    for (; d && d != e._obj; )
      a += d.offsetLeft, o += d.offsetTop - d.scrollTop, d = d.offsetParent;
    return d ? { left: a, top: o, dx: a + s.offsetWidth / 2 > e._x / 2 ? 1 : 0, dy: o + s.offsetHeight / 2 > e._y / 2 ? 1 : 0, width: s.offsetWidth, height: s.offsetHeight } : 0;
  }
  e.attachEvent("onSchedulerReady", function() {
    const s = e.$container;
    s._$quickInfoHandler || (s._$quickInfoHandler = !0, e.event(s, "mousedown", function(a) {
      const o = a.target.closest(`[${e.config.event_attribute}]`);
      o && (i = { id: o.getAttribute(e.config.event_attribute), position: n(o) });
    }), e.attachEvent("onDestroy", () => {
      delete s._$quickInfoHandler;
    }));
  }), e.attachEvent("onClick", function(s) {
    if (e.config.show_quick_info)
      return e.showQuickInfo(s), !0;
  }), function() {
    for (var s = ["onEmptyClick", "onViewChange", "onLightbox", "onBeforeEventDelete", "onBeforeDrag"], a = function() {
      return e.hideQuickInfo(!0), !0;
    }, o = 0; o < s.length; o++)
      e.attachEvent(s[o], a);
  }(), e.templates.quick_info_title = function(s, a, o) {
    return o.text.substr(0, 50);
  }, e.templates.quick_info_content = function(s, a, o) {
    return o.details || "";
  }, e.templates.quick_info_date = function(s, a, o) {
    return e.isOneDayEvent(o) && e.config.rtl ? e.templates.day_date(s, a, o) + " " + e.templates.event_header(a, s, o) : e.isOneDayEvent(o) ? e.templates.day_date(s, a, o) + " " + e.templates.event_header(s, a, o) : e.config.rtl ? e.templates.week_date(a, s, o) : e.templates.week_date(s, a, o);
  }, e.showQuickInfo = function(s) {
    if (s == this._quick_info_box_id || (this.hideQuickInfo(!0), this.callEvent("onBeforeQuickInfo", [s]) === !1))
      return;
    let a;
    a = i && i.id == s ? i.position : this._get_event_counter_part(s), a && (this._quick_info_box = this._init_quick_info(a), this._fill_quick_data(s), this._show_quick_info(a), this.callEvent("onQuickInfo", [s]));
  }, function() {
    function s(a) {
      a = a || "";
      var o, d = parseFloat(a), r = a.match(/m?s/);
      switch (r && (r = r[0]), r) {
        case "s":
          o = 1e3 * d;
          break;
        case "ms":
          o = d;
          break;
        default:
          o = 0;
      }
      return o;
    }
    e.hideQuickInfo = function(a) {
      var o = this._quick_info_box, d = this._quick_info_box_id;
      if (this._quick_info_box_id = 0, o && o.parentNode) {
        var r = o.offsetWidth;
        if (e.config.quick_info_detached)
          return this.callEvent("onAfterQuickInfo", [d]), o.parentNode.removeChild(o);
        if (o.style.right == "auto" ? o.style.left = -r + "px" : o.style.right = -r + "px", a)
          o.parentNode.removeChild(o);
        else {
          var l;
          window.getComputedStyle ? l = window.getComputedStyle(o, null) : o.currentStyle && (l = o.currentStyle);
          var _ = s(l["transition-delay"]) + s(l["transition-duration"]);
          setTimeout(function() {
            o.parentNode && o.parentNode.removeChild(o);
          }, _);
        }
        this.callEvent("onAfterQuickInfo", [d]);
      }
    };
  }(), e.event(window, "keydown", function(s) {
    s.keyCode == 27 && e.hideQuickInfo();
  }), e._show_quick_info = function(s) {
    var a = e._quick_info_box;
    e._obj.appendChild(a);
    var o = a.offsetWidth, d = a.offsetHeight;
    if (e.config.quick_info_detached) {
      var r = s.left - s.dx * (o - s.width);
      e.getView() && e.getView()._x_scroll && (e.config.rtl ? r += e.getView()._x_scroll : r -= e.getView()._x_scroll), r + o > window.innerWidth && (r = window.innerWidth - o), r = Math.max(0, r), a.style.left = r + "px", a.style.top = s.top - (s.dy ? d : -s.height) + "px";
    } else {
      const l = e.$container.querySelector(".dhx_cal_data").offsetTop;
      a.style.top = l + 20 + "px", s.dx == 1 ? (a.style.right = "auto", a.style.left = -o + "px", setTimeout(function() {
        a.style.left = "-10px";
      }, 1)) : (a.style.left = "auto", a.style.right = -o + "px", setTimeout(function() {
        a.style.right = "-10px";
      }, 1)), a.className = a.className.replace(" dhx_qi_left", "").replace(" dhx_qi_right", "") + " dhx_qi_" + (s.dx == 1 ? "left" : "right");
    }
    a.ontransitionend = () => {
      t(a), a.ontransitionend = null;
    }, setTimeout(() => {
      t(a);
    }, 1);
  }, e.attachEvent("onTemplatesReady", function() {
    if (e.hideQuickInfo(), this._quick_info_box) {
      var s = this._quick_info_box;
      s.parentNode && s.parentNode.removeChild(s), this._quick_info_box = null;
    }
  }), e._quick_info_onscroll_handler = function(s) {
    e.hideQuickInfo();
  }, e._init_quick_info = function() {
    let s = this._quick_info_box = document.createElement("div");
    this._waiAria.quickInfoAttr(s), s.className = "dhx_cal_quick_info", e.$testmode && (s.className += " dhx_no_animate"), e.config.rtl && (s.className += " dhx_quick_info_rtl");
    let a = `
	<div class="dhx_cal_qi_tcontrols">
		<a class="dhx_cal_qi_close_btn scheduler_icon close"></a>
	</div>
	<div class="dhx_cal_qi_title" ${this._waiAria.quickInfoHeaderAttrString()}>
			
			<div class="dhx_cal_qi_tcontent"></div>
			<div class="dhx_cal_qi_tdate"></div>
		</div>
		<div class="dhx_cal_qi_content"></div>`;
    a += '<div class="dhx_cal_qi_controls">';
    let o = e.config.icons_select;
    for (let d = 0; d < o.length; d++)
      a += `<div ${this._waiAria.quickInfoButtonAttrString(this.locale.labels[o[d]])} class="dhx_qi_big_icon ${o[d]}" title="${e.locale.labels[o[d]]}">
			<div class='dhx_menu_icon ${o[d]}'></div><div>${e.locale.labels[o[d]]}</div></div>`;
    return a += "</div>", s.innerHTML = a, e.event(s, "click", function(d) {
      e._qi_button_click(d.target || d.srcElement);
    }), e.config.quick_info_detached && (e._detachDomEvent(e._els.dhx_cal_data[0], "scroll", e._quick_info_onscroll_handler), e.event(e._els.dhx_cal_data[0], "scroll", e._quick_info_onscroll_handler)), this._quick_info_box;
  }, e._qi_button_click = function(s) {
    var a = e._quick_info_box;
    if (s && s != a)
      if (s.closest(".dhx_cal_qi_close_btn"))
        e.hideQuickInfo();
      else {
        var o = e._getClassName(s);
        if (o.indexOf("_icon") != -1) {
          var d = e._quick_info_box_id;
          e._click.buttons[o.split(" ")[1].replace("icon_", "")](d);
        } else
          e._qi_button_click(s.parentNode);
      }
  }, e._get_event_counter_part = function(s) {
    return n(e.getRenderedEvent(s));
  }, e._fill_quick_data = function(s) {
    var a = e.getEvent(s), o = e._quick_info_box;
    e._quick_info_box_id = s;
    var d = { content: e.templates.quick_info_title(a.start_date, a.end_date, a), date: e.templates.quick_info_date(a.start_date, a.end_date, a) };
    o.querySelector(".dhx_cal_qi_tcontent").innerHTML = `<span>${d.content}</span>`, o.querySelector(".dhx_cal_qi_tdate").innerHTML = d.date, e._waiAria.quickInfoHeader(o, [d.content, d.date].join(" "));
    var r = o.querySelector(".dhx_cal_qi_content");
    const l = e.templates.quick_info_content(a.start_date, a.end_date, a);
    l ? (r.classList.remove("dhx_hidden"), r.innerHTML = l) : r.classList.add("dhx_hidden");
  };
}, readonly: function(e) {
  e.attachEvent("onTemplatesReady", function() {
    var i;
    e.form_blocks.recurring && (i = e.form_blocks.recurring.set_value);
    var t = e.config.buttons_left.slice(), n = e.config.buttons_right.slice();
    function s(d, r, l, _) {
      for (var h = r.getElementsByTagName(d), p = l.getElementsByTagName(d), v = p.length - 1; v >= 0; v--)
        if (l = p[v], _) {
          var g = document.createElement("span");
          g.className = "dhx_text_disabled", g.innerHTML = _(h[v]), l.parentNode.insertBefore(g, l), l.parentNode.removeChild(l);
        } else
          l.disabled = !0, r.checked && (l.checked = !0);
    }
    e.attachEvent("onBeforeLightbox", function(d) {
      if (this.config.readonly_form || this.getEvent(d).readonly ? this.config.readonly_active = !0 : (this.config.readonly_active = !1, e.config.buttons_left = t.slice(), e.config.buttons_right = n.slice(), e.form_blocks.recurring && (e.form_blocks.recurring.set_value = i)), this.config.readonly_active)
        for (var r = ["dhx_delete_btn", "dhx_save_btn"], l = [e.config.buttons_left, e.config.buttons_right], _ = 0; _ < r.length; _++)
          for (var h = r[_], p = 0; p < l.length; p++) {
            for (var v = l[p], g = -1, c = 0; c < v.length; c++)
              if (v[c] == h) {
                g = c;
                break;
              }
            g != -1 && v.splice(g, 1);
          }
      return this.resetLightbox(), !0;
    });
    var a = e._fill_lightbox;
    e._fill_lightbox = function() {
      var d = this.getLightbox();
      this.config.readonly_active && (d.style.visibility = "hidden", d.style.display = "block");
      var r = a.apply(this, arguments);
      if (this.config.readonly_active && (d.style.visibility = "", d.style.display = "none"), this.config.readonly_active) {
        var l = this.getLightbox(), _ = this._lightbox_r = l.cloneNode(!0);
        _.id = e.uid(), _.className += " dhx_cal_light_readonly", s("textarea", l, _, function(h) {
          return h.value;
        }), s("input", l, _, !1), s("select", l, _, function(h) {
          return h.options.length ? h.options[Math.max(h.selectedIndex || 0, 0)].text : "";
        }), l.parentNode.insertBefore(_, l), this.showCover(_), e._lightbox && e._lightbox.parentNode.removeChild(e._lightbox), this._lightbox = _, e.config.drag_lightbox && e.event(_.firstChild, "mousedown", e._ready_to_dnd), e._init_lightbox_events(), this.setLightboxSize();
      }
      return r;
    };
    var o = e.hide_lightbox;
    e.hide_lightbox = function() {
      return this._lightbox_r && (this._lightbox_r.parentNode.removeChild(this._lightbox_r), this._lightbox_r = this._lightbox = null), o.apply(this, arguments);
    };
  });
}, recurring: function(e) {
  function i(m, x) {
    return m === "occurrence" ? x.occurrence || e.locale.labels.button_edit_occurrence : m === "following" ? x.following || e.locale.labels.button_edit_occurrence_and_following : m === "series" ? x.series || e.locale.labels.button_edit_series : m;
  }
  function t(m) {
    return new Date(m.getFullYear(), m.getMonth(), m.getDate(), m.getHours(), m.getMinutes(), m.getSeconds(), 0);
  }
  function n(m) {
    return !!m.rrule && !m.recurring_event_id;
  }
  function s(m) {
    return new Date(Date.UTC(m.getFullYear(), m.getMonth(), m.getDate(), m.getHours(), m.getMinutes(), m.getSeconds()));
  }
  function a(m) {
    return new Date(m.getUTCFullYear(), m.getUTCMonth(), m.getUTCDate(), m.getUTCHours(), m.getUTCMinutes(), m.getUTCSeconds());
  }
  function o(m) {
    let x;
    m.rrule.includes(";UNTIL=") && (m.rrule = m.rrule.split(";UNTIL=")[0]), m.rrule.includes(";COUNT=") ? (x = ge(`RRULE:${m.rrule};UNTIL=${c(a(m._shorten_end_date))}`, { dtstart: m.start_date }), delete x.origOptions.count) : x = ge(`RRULE:${m.rrule};UNTIL=${c(a(m._end_date || m.end_date))}`, { dtstart: m.start_date }), m.rrule = new z(x.origOptions).toString().replace("RRULE:", "").split(`
`)[1];
  }
  function d(m, x) {
    x || (x = e.getEvent(m));
    let b, E = x.rrule.split(";"), S = [];
    for (let T = 0; T < E.length; T++) {
      let C = E[T].split("="), A = C[0], $ = C[1];
      if (A !== "BYDAY" || x.rrule.includes("WEEKLY") && $.length > 3) {
        if (A === "UNTIL" && ge(x.rrule).options.until.valueOf() < x.start_date.valueOf() && (x._end_date = x.end_date), A === "INTERVAL" && (b = Number($)), A === "COUNT" && x._shorten_end_date) {
          const H = e.date.date_part(new Date(x._start_date)), O = e.date.date_part(new Date(x._shorten_end_date));
          $ -= Math.floor((O - H) / (864e5 * b)) + 1;
        }
        S.push(A), S.push("="), S.push($), S.push(";");
      }
    }
    S.pop(), x.rrule = S.join("");
  }
  function r(m, x) {
    m._end_date = m.end_date, e._isExceptionFirstOccurrence(x) ? (m.start_date = x.start_date, m.end_date = new Date(x.start_date.valueOf() + 1e3 * m.duration), m._start_date = x.original_start, m._modified = !0) : (m.end_date = new Date(x.start_date.valueOf() + 1e3 * m.duration), m.start_date = x.start_date, m._firstOccurrence = !0), m._thisAndFollowing = x.id;
  }
  function l(m, x, b, E) {
    const S = b._modified ? E.id : m;
    e._events[S] = { ...E, ...x, end_date: E._end_date, _start_date: E.start_date, _thisAndFollowing: null, _end_date: null }, b._modified && delete e._events[m], e.callEvent("onEventChanged", [e._events[S].id, e._events[S]]);
  }
  function _(m) {
    for (const x in e._events)
      e._events[x].id == m.id && delete e._events[x];
  }
  function h(m, x) {
    for (let b in e._events) {
      let E = e._events[b];
      (E.recurring_event_id == m || e._is_virtual_event(E.id) && E.id.split("#")[0] == m) && E.start_date.valueOf() >= x.start_date.valueOf() && (E.text = x.text, e.updateEvent(E.id));
    }
  }
  function p(m, x) {
    let b = m, E = new Date(x.original_start).valueOf();
    m = String(b).split("#") || x._pid_time || E;
    let S = e.uid(), T = m[1] ? m[1] : x._pid_time || E, C = e._copy_event(x);
    C.id = S, C.recurring_event_id = x.recurring_event_id || m[0], C.original_start = new Date(Number(T)), C.deleted = !0, e.addEvent(C);
  }
  function v() {
    for (const m in e._events)
      m === "$dnd_recurring_placeholder" && delete e._events[m];
    e.render();
  }
  function g() {
    const m = {};
    for (const x in e._events) {
      const b = e._events[x];
      b.recurring_event_id && b.original_start && (m[b.recurring_event_id] || (m[b.recurring_event_id] = {}), m[b.recurring_event_id][b.original_start.valueOf()] = b);
    }
    return m;
  }
  e.ext.recurring = { confirm: function(m) {
  }, confirmDefault: function(m) {
    const x = m.labels || {}, b = Array.isArray(m.options) ? m.options : [];
    if (b.length === 0)
      return Promise.resolve(null);
    if (b.length === 1)
      return Promise.resolve(b[0]);
    const E = b.map((S, T) => ({ value: S, label: i(S, x), checked: T === 0 }));
    return new Promise((S) => {
      e.modalbox({ text: `<div class="dhx_edit_recurrence_options">
			${E.map((T) => `<label class="dhx_styled_radio">
				<input type="radio" value="${T.value}" name="option" ${T.checked ? "checked" : ""}>
				${T.label}
				</label>`).join("")}
			</div>`, type: "recurring_mode", title: x.title || e.locale.labels.confirm_recurring, width: "auto", position: "middle", buttons: [{ label: x.ok || e.locale.labels.message_ok, value: "ok", css: "rec_ok" }, { label: x.cancel || e.locale.labels.message_cancel, value: "cancel" }], callback: function(T, C) {
        if (T === "cancel")
          return void S(null);
        const A = C.target.closest(".scheduler_modal_box"), $ = A && A.querySelector("input[type='radio']:checked"), H = $ ? $.value : null;
        S(H || null);
      } });
    });
  }, _getDecision: async function(m) {
    const x = e.ext.recurring.confirm;
    let b;
    return b = typeof x == "function" ? await x(m) : void 0, b === void 0 && (b = await e.ext.recurring.confirmDefault(m)), b === null ? null : m.options && m.options.length > 0 && m.options.indexOf(b) === -1 ? (console.warning(`[recurring extension] - the custom confirm handler returned a value ("${b}") which is not in the allowed options list. The allowed options are: [${m.options.join(", ")}]. The operation will be cancelled.`), null) : b;
  } }, e.ext.recurring.confirm = e.ext.recurring.confirmDefault, e._isFollowing = function(m) {
    let x = e.getEvent(m);
    return !(!x || !x._thisAndFollowing);
  }, e._isFirstOccurrence = function(m) {
    if (e._is_virtual_event(m.id)) {
      let x = m.id.split("#")[0];
      return e.getEvent(x).start_date.valueOf() === m.start_date.valueOf();
    }
  }, e._isExceptionFirstOccurrence = function(m) {
    if (e._is_modified_occurrence(m)) {
      let x = m.recurring_event_id, b = e.getEvent(x);
      return !(!m.original_start || !m.original_start.valueOf() || m.original_start.valueOf() !== b.start_date.valueOf());
    }
  }, e._rec_temp = [], e._rec_markers_pull = {}, e._rec_markers = {}, e._add_rec_marker = function(m, x) {
    m._pid_time = x, this._rec_markers[m.id] = m, this._rec_markers_pull[m.event_pid] || (this._rec_markers_pull[m.event_pid] = {}), this._rec_markers_pull[m.event_pid][x] = m;
  }, e._get_rec_marker = function(m, x) {
    let b = this._rec_markers_pull[x];
    return b ? b[m] : null;
  }, e._get_rec_markers = function(m) {
    return this._rec_markers_pull[m] || [];
  }, function() {
    let m = e.addEvent;
    e.addEvent = function(x, b, E, S, T) {
      const C = m.apply(this, arguments);
      if (C && e.getEvent(C)) {
        const A = e.getEvent(C);
        A.start_date && (A.start_date = t(A.start_date)), A.end_date && (A.end_date = t(A.end_date));
      }
      return C;
    };
  }(), e.attachEvent("onEventLoading", function(m) {
    return m.original_start && !m.original_start.getFullYear && (m.original_start = e.templates.parse_date(m.original_start)), !0;
  }), e.attachEvent("onEventIdChange", function(m, x) {
    if (this._ignore_call)
      return;
    this._ignore_call = !0, e._rec_markers[m] && (e._rec_markers[x] = e._rec_markers[m], delete e._rec_markers[m]), e._rec_markers_pull[m] && (e._rec_markers_pull[x] = e._rec_markers_pull[m], delete e._rec_markers_pull[m]);
    for (let E = 0; E < this._rec_temp.length; E++) {
      let S = this._rec_temp[E];
      this._is_virtual_event(S.id) && S.id.split("#")[0] == m && (S.recurring_event_id = x, this.changeEventId(S.id, x + "#" + S.id.split("#")[1]));
    }
    for (let E in this._rec_markers) {
      let S = this._rec_markers[E];
      S.recurring_event_id == m && (S.recurring_event_id = x, S._pid_changed = !0);
    }
    let b = e._rec_markers[x];
    b && b._pid_changed && (delete b._pid_changed, setTimeout(function() {
      if (e.$destroyed)
        return !0;
      e.callEvent("onEventChanged", [x, e.getEvent(x)]);
    }, 1)), delete this._ignore_call;
  }), e.attachEvent("onConfirmedBeforeEventDelete", function(m) {
    const x = this.getEvent(m);
    if (this._is_virtual_event(m) || this._is_modified_occurrence(x) && !function(b) {
      return !!b.deleted;
    }(x))
      p(m, x);
    else {
      n(x) && this._lightbox_id && this._roll_back_dates(x);
      const b = this._get_rec_markers(m);
      for (let E in b)
        b.hasOwnProperty(E) && (m = b[E].id, this.getEvent(m) && this.deleteEvent(m, !0));
    }
    return !0;
  }), e.attachEvent("onEventDeleted", function(m, x) {
    !this._is_virtual_event(m) && this._is_modified_occurrence(x) && (e._events[m] || (x.deleted = !0, this.setEvent(m, x), e.render()));
  }), e.attachEvent("onBeforeEventChanged", function(m, x, b, E) {
    return !(!b && m && (e._is_virtual_event(m.id) || e._is_modified_occurrence(m)) && (E.start_date.getDate() !== m.start_date.getDate() ? m._beforeEventChangedFlag = "edit" : m._beforeEventChangedFlag = "ask", !e.config.collision_limit || e.checkCollision(m))) || (e._events.$dnd_recurring_placeholder = e._lame_clone(m), e._showRequiredModalBox(m.id, m._beforeEventChangedFlag), !1);
  }), e.attachEvent("onEventChanged", function(m, x) {
    if (this._loading)
      return !0;
    let b = this.getEvent(m);
    if (this._is_virtual_event(m))
      (function(E) {
        let S = E.id.split("#"), T = e.uid();
        e._not_render = !0;
        let C = e._copy_event(E);
        C.id = T, C.recurring_event_id = S[0];
        let A = S[1];
        C.original_start = new Date(Number(A)), e._add_rec_marker(C, A), e.addEvent(C), e._not_render = !1;
      })(b);
    else {
      b.start_date && (b.start_date = t(b.start_date)), b.end_date && (b.end_date = t(b.end_date)), n(b) && this._lightbox_id && (b._removeFollowing || this._isFollowing(m) ? b._removeFollowing = null : this._roll_back_dates(b));
      const E = this._get_rec_markers(m);
      for (let T in E)
        E.hasOwnProperty(T) && (delete this._rec_markers[E[T].id], this.deleteEvent(E[T].id, !0));
      delete this._rec_markers_pull[m];
      let S = !1;
      for (let T = 0; T < this._rendered.length; T++)
        this._rendered[T].getAttribute(this.config.event_attribute) == m && (S = !0);
      S || (this._select_id = null);
    }
    return v(), !0;
  }), e.attachEvent("onEventAdded", function(m) {
    if (!this._loading) {
      const x = this.getEvent(m);
      n(x) && this._roll_back_dates(x);
    }
    return !0;
  }), e.attachEvent("onRecurringEventSave", function(m, x, b) {
    let E = this.getEvent(m), S = e._lame_clone(E), T = e._lame_clone(x);
    if (E && n(E) && n(T)) {
      if (!b && this._isFollowing(m)) {
        if (E._removeFollowing) {
          if (e.getEvent(E._thisAndFollowing) && (E._firstOccurrence || E._modified))
            return e.hideLightbox(), e.deleteEvent(E.id), !1;
          if (E.end_date = new Date(E.start_date.valueOf() - 1e3), E._end_date = E._shorten_end_date, E.start_date = E._start_date, E._shorten = !0, o(E), e.callEvent("onEventChanged", [E.id, E]), e.getEvent(E._thisAndFollowing))
            for (const C in e._events) {
              let A = e._events[C];
              A.recurring_event_id === m && A.start_date.valueOf() > S.start_date.valueOf() && p(A.id, A);
            }
          return e.hideLightbox(), !1;
        }
        {
          let C = e.getEvent(E._thisAndFollowing);
          if (C && E._firstOccurrence)
            for (const A in e._events)
              e._events[A].id == E.id && l(A, x, E, S);
          else if (C && E._modified)
            for (const A in e._events) {
              let $ = e._events[A];
              $.recurring_event_id == m && $.id == S._thisAndFollowing && l(A, x, E, S);
            }
          else {
            e._is_modified_occurrence(C) && _(C), E.end_date = E._shorten_end_date, E._end_date = E._shorten_end_date, E.start_date = E._start_date, E._shorten = !0, o(E), e.callEvent("onEventChanged", [E.id, E]);
            let A = { ...T };
            A._end_date = S._end_date, A._start_date = null, A.id = e.uid(), e.addEvent(A.start_date, A.end_date, A.text, A.id, A);
          }
          return b || h(m, x), e.hideLightbox(), !1;
        }
      }
    } else
      e._roll_back_dates(E);
    return b || h(m, x), S._ocr && S._beforeEventChangedFlag ? (E.start_date = S.start_date, E.end_date = S.end_date, E._start_date = S._start_date, E._end_date = S._end_date, e.updateEvent(E.id), !0) : (this._select_id = null, v(), !0);
  }), e.attachEvent("onEventCreated", function(m) {
    const x = this.getEvent(m);
    return n(x) || function(b) {
      b.rrule = "", b.original_start = null, b.recurring_event_id = null, b.duration = null, b.deleted = null;
    }(x), !0;
  }), e.attachEvent("onEventCancel", function(m) {
    const x = this.getEvent(m);
    n(x) && (this._roll_back_dates(x), this.render_view_data()), v();
  }), e.attachEvent("onLightbox", function(m) {
    const x = e.getEvent(m);
    if (e._is_virtual_event(x.id)) {
      const b = e.formSection("recurring");
      if (b && b.node) {
        const E = b.node.querySelector("select");
        E && (E.disabled = !0);
      }
    }
  }), e._roll_back_dates = function(m) {
    m.start_date && (m.start_date = t(m.start_date)), m.end_date && (m.end_date = t(m.end_date)), m._end_date && (m._shorten || (m.duration = Math.round((m.end_date.valueOf() - m.start_date.valueOf()) / 1e3)), m.end_date = m._end_date), m._start_date && (m.start_date.setMonth(0), m.start_date.setDate(m._start_date.getDate()), m.start_date.setMonth(m._start_date.getMonth()), m.start_date.setFullYear(m._start_date.getFullYear()), this._isFollowing(m.id) && (m.start_date.setHours(m._start_date.getHours()), m.start_date.setMinutes(m._start_date.getMinutes()), m.start_date.setSeconds(m._start_date.getSeconds()))), m._thisAndFollowing = null, m._shorten_end_date && (m._shorten_end_date = null), m._removeFollowing && (m._removeFollowing = null), m._firstOccurrence && (m._firstOccurrence = null), m._modified && (m._modified = null);
  }, e._is_virtual_event = function(m) {
    return m.toString().indexOf("#") != -1;
  }, e._is_modified_occurrence = function(m) {
    return m.recurring_event_id && m.recurring_event_id != "0";
  }, e.showLightbox_rec = e.showLightbox, e.showLightbox = function(m) {
    const x = this.locale;
    let b = e.config.lightbox_recurring, E = this.getEvent(m), S = E.recurring_event_id, T = this._is_virtual_event(m);
    T && (S = m.split("#")[0]);
    const C = function(A, $) {
      const H = e.getEvent(A), O = e.getEvent(S), P = e.getView();
      if (P && H[P.y_property] && (O[P.y_property] = H[P.y_property]), P && H[P.property] && (O[P.property] = H[P.property]), $ === "Occurrence")
        return e.showLightbox_rec(A);
      if ($ === "Following") {
        if (e._isExceptionFirstOccurrence(H) || e._isFirstOccurrence(H))
          return r(O, H), e.showLightbox_rec(S);
        {
          O._end_date = O.end_date;
          const R = H.original_start || H.start_date;
          return O._shorten_end_date = new Date(R.valueOf() - 1e3), O.end_date = new Date(H.start_date.valueOf() + 1e3 * O.duration), O._start_date = O.start_date, O.start_date = H.start_date, O._thisAndFollowing = H.id, E._beforeEventChangedFlag && (O._beforeEventChangedFlag = E._beforeEventChangedFlag, O._shorten_end_date = new Date(R.valueOf() - 1e3)), e.showLightbox_rec(S);
        }
      }
      if ($ === "AllEvents") {
        if (e._isExceptionFirstOccurrence(H) || e._isFirstOccurrence(H))
          return r(O, H), e.showLightbox_rec(S);
        const R = new Date(O.start_date);
        return O._end_date = O.end_date, O._start_date = R, O.start_date.setHours(H.start_date.getHours()), O.start_date.setMinutes(H.start_date.getMinutes()), O.start_date.setSeconds(H.start_date.getSeconds()), O.end_date = new Date(O.start_date.valueOf() + 1e3 * O.duration), O._thisAndFollowing = null, e.showLightbox_rec(S);
      }
    };
    if ((S || 1 * S == 0) && n(E))
      return C(m, "AllEvents");
    if (!S || S === "0" || !x.labels.confirm_recurring || b == "instance" || b == "series" && !T)
      return this.showLightbox_rec(m);
    b === "ask" && async function(A, $) {
      const H = e.locale, O = e.getEvent(A), P = e.getEvent($), R = { origin: "lightbox", occurrence: O, series: P, labels: { title: H.labels.confirm_recurring, ok: H.labels.message_ok, cancel: H.labels.message_cancel, occurrence: H.labels.button_edit_occurrence, following: H.labels.button_edit_occurrence_and_following, series: H.labels.button_edit_series }, options: ["occurrence", "following", "series"] }, j = await e.ext.recurring._getDecision(R);
      if (j !== null) {
        if (j === "occurrence")
          return C(A, "Occurrence");
        if (j === "following")
          return C(A, "Following");
        j === "series" && C(A, "AllEvents");
      }
    }(m, S);
  }, e._showRequiredModalBox = function(m, x) {
    let b;
    const E = e.locale;
    let S = e.getEvent(m), T = S.recurring_event_id;
    e._is_virtual_event(S.id) && (T = S.id.split("#")[0]);
    let C = e.getEvent(T);
    const A = e.getView();
    let $, H, O = e._lame_clone(C);
    A && S[A.y_property] && (O[A.y_property] = S[A.y_property]), A && S[A.property] && (O[A.property] = S[A.property]), S && S._beforeEventChangedFlag && ($ = S.start_date, H = S.end_date), b = x === "ask" ? ["occurrence", "following", "series"] : ["occurrence", "following"];
    const P = { origin: "dnd", occurrence: S, series: C, labels: { title: E.labels.confirm_recurring, ok: E.labels.message_ok, cancel: E.labels.message_cancel, occurrence: E.labels.button_edit_occurrence, following: E.labels.button_edit_occurrence_and_following, series: E.labels.button_edit_series }, options: b };
    Promise.resolve(e.ext.recurring._getDecision(P)).then((R) => {
      if (R)
        switch (R) {
          case "occurrence":
            (function(j) {
              let I = { ...C, ...e.getEvent("$dnd_recurring_placeholder") };
              if (H && $ && (I.start_date = $, I.end_date = H, I._beforeEventChangedFlag = j._beforeEventChangedFlag, I._ocr = !0), !e.config.collision_limit || e.checkCollision(I))
                for (const U in e._events) {
                  let B = e._events[U];
                  U !== "$dnd_recurring_placeholder" && B.id == I.id && (e._events[U] = { ...I }, e.callEvent("onEventChanged", [e._events[U].id, e._events[U]]));
                }
            })(S);
            break;
          case "following":
            (function(j) {
              let I = e._lame_clone(j);
              if (H && $ && (j._start_date = j.start_date, j.start_date = $, j.end_date = H), e._isFirstOccurrence(I) || e._isExceptionFirstOccurrence(I)) {
                if (e._isExceptionFirstOccurrence(I) && _(I), O._start_date = C.start_date, O.start_date = j.start_date, O.duration = (+j.end_date - +j.start_date) / 1e3, O._beforeEventChangedFlag = j._beforeEventChangedFlag, O.rrule && d(O.id, O), !e.config.collision_limit || e.checkCollision(O))
                  for (const U in e._events)
                    e._events[U].id == O.id && (e._events[U] = { ...O }, e.callEvent("onEventChanged", [e._events[U].id, e._events[U]]));
              } else {
                O._end_date = C.end_date;
                const U = j.original_start || e.date.date_part(new Date(j._start_date));
                O._shorten_end_date = new Date(U.valueOf() - 1e3), O.end_date = j.end_date, O._start_date = C.start_date, O.start_date = j.start_date, O._thisAndFollowing = j.id, O.rrule && d(O.id, O);
                let B = O.end_date;
                if (O.end_date = O._end_date, !e.config.collision_limit || e.checkCollision(O)) {
                  O.end_date = B;
                  for (const W in e._events)
                    e._events[W].id == O.id && (e._events[W] = { ...O }, e.callEvent("onRecurringEventSave", [e._events[W].id, e._events[W], e._new_event]), e.callEvent("onEventChanged", [e._events[W].id, e._events[W]]));
                }
              }
            })(S);
            break;
          case "series":
            (function(j) {
              let I = e._lame_clone(j);
              if (e._isExceptionFirstOccurrence(I) && _(I), H && $ && (O.start_date.setHours($.getHours()), O.start_date.setMinutes($.getMinutes()), O.start_date.setSeconds($.getSeconds()), O.duration = (+H - +$) / 1e3), O._beforeEventChangedFlag = j._beforeEventChangedFlag, O._thisAndFollowing = null, !e.config.collision_limit || e.checkCollision(O))
                for (const U in e._events)
                  e._events[U].id == O.id && (e._events[U] = { ...O }, e.callEvent("onEventChanged", [e._events[U].id, e._events[U]]));
            })(S);
            break;
          default:
            return void v();
        }
      else
        v();
    });
  }, e.get_visible_events_rec = e.get_visible_events, e.get_visible_events = function(m) {
    for (let S = 0; S < this._rec_temp.length; S++)
      delete this._events[this._rec_temp[S].id];
    this._rec_temp = [];
    const x = g();
    let b = this.get_visible_events_rec(m), E = [];
    for (let S = 0; S < b.length; S++)
      b[S].deleted || b[S].recurring_event_id || (n(b[S]) ? this.repeat_date(b[S], E, void 0, void 0, void 0, void 0, x) : E.push(b[S]));
    return function(S) {
      const T = {};
      return S.forEach((C) => {
        const A = T[C.id];
        (!A || A._beforeEventChangedFlag || C._beforeEventChangedFlag) && (T[C.id] = C);
      }), Object.values(T);
    }(E);
  }, function() {
    let m = e.isOneDayEvent;
    e.isOneDayEvent = function(b) {
      return !!n(b) || m.call(this, b);
    };
    const x = e.updateEvent;
    e.updateEvent = function(b) {
      const E = e.getEvent(b);
      E && n(E) && !this._is_virtual_event(b) ? e.update_view() : x.call(this, b);
    };
  }();
  const c = e.date.date_to_str("%Y%m%dT%H%i%s");
  function f(m) {
    const x = m.getDay(), b = m.getDate();
    return { dayOfWeek: x, dayNumber: Math.ceil(b / 7) };
  }
  e.repeat_date = function(m, x, b, E, S, T, C) {
    if (!m.rrule)
      return;
    let A = C ? C[m.id] : g()[m.id];
    A || (A = {}), E = s(E || new Date(e._min_date.valueOf() - 6048e5)), S = s(S || new Date(e._max_date.valueOf() - 1e3));
    const $ = s(m.start_date);
    let H;
    H = ge(T ? `RRULE:${m.rrule};UNTIL=${c(m.end_date)};COUNT=${T}` : `RRULE:${m.rrule};UNTIL=${c(m.end_date)}`, { dtstart: $ });
    const O = H.between(E, S, !0).map((j) => {
      const I = a(j);
      return I.setHours(m.start_date.getHours()), I.setMinutes(m.start_date.getMinutes()), I.setSeconds(m.start_date.getSeconds()), I;
    });
    let P = 0;
    const R = m.duration;
    for (let j = 0; j < O.length && !(T && P >= T); j++) {
      const I = O[j];
      let U = A[I.valueOf()];
      if (U) {
        if (U.deleted || U.end_date.valueOf() < e._min_date.valueOf() || !e.filter_event(U.id, U))
          continue;
        P++, x.push(U);
      } else {
        const B = e._copy_event(m);
        if (B.text = m.text, B.start_date = I, B.id = m.id + "#" + Math.ceil(I.valueOf()), B.end_date = new Date(I.valueOf() + 1e3 * R), B.end_date.valueOf() <= e._min_date.valueOf() || (B.end_date = e._fix_daylight_saving_date(B.start_date, B.end_date, m, I, B.end_date), B._timed = e.isOneDayEvent(B), !B._timed && !e._table_view && !e.config.multi_day))
          continue;
        x.push(B), b || (e._events[B.id] = B, e._rec_temp.push(B)), P++;
      }
    }
    if (A && O.length == 0)
      for (let j in A) {
        let I = A[j];
        if (I) {
          if (I.deleted || I.end_date.valueOf() < e._min_date.valueOf() || !e.filter_event(I.id, I))
            continue;
          E && S && I.start_date < S && I.end_date > E && x.push(I);
        }
      }
  }, e._fix_daylight_saving_date = function(m, x, b, E, S) {
    let T = m.getTimezoneOffset() - x.getTimezoneOffset();
    return T ? T > 0 ? new Date(E.valueOf() + 1e3 * b.duration - 60 * T * 1e3) : new Date(x.valueOf() - 60 * T * 1e3) : new Date(S.valueOf());
  }, e.getRecDates = function(m, x) {
    let b = typeof m == "object" ? m : e.getEvent(m), E = [];
    if (x = x || 100, !n(b))
      return [{ start_date: b.start_date, end_date: b.end_date }];
    if (b.deleted)
      return [];
    e.repeat_date(b, E, !0, b.start_date, b.end_date, x);
    let S = [];
    for (let T = 0; T < E.length; T++)
      E[T].deleted || S.push({ start_date: E[T].start_date, end_date: E[T].end_date });
    return S;
  }, e.getEvents = function(m, x) {
    let b = [];
    const E = g();
    for (let S in this._events) {
      let T = this._events[S];
      if (!T.recurring_event_id)
        if (m && x && T.start_date < x && T.end_date > m)
          if (n(T)) {
            let C = [];
            this.repeat_date(T, C, !0, m, x, void 0, E), C.forEach(function(A) {
              A.start_date < x && A.end_date > m && b.push(A);
            });
          } else
            this._is_virtual_event(T.id) || b.push(T);
        else
          m || x || this._is_virtual_event(T.id) || b.push(T);
    }
    return b;
  }, e._copy_dummy = function(m) {
    const x = new Date(this.start_date), b = new Date(this.end_date);
    this.start_date = x, this.end_date = b, this.duration = this.rrule = null;
  }, e.config.include_end_by = !1, e.config.lightbox_recurring = "ask", e.config.recurring_workdays = [z.MO.weekday, z.TU.weekday, z.WE.weekday, z.TH.weekday, z.FR.weekday], e.config.repeat_date = "%m.%d.%Y", e.config.lightbox.sections = [{ name: "description", map_to: "text", type: "textarea", focus: !0 }, { name: "recurring", type: "recurring", map_to: "rrule" }, { name: "time", height: 72, type: "time", map_to: "auto" }], e.attachEvent("onClearAll", function() {
    e._rec_markers = {}, e._rec_markers_pull = {}, e._rec_temp = [];
  });
  const u = { 0: "SU", 1: "MO", 2: "TU", 3: "WE", 4: "TH", 5: "FR", 6: "SA" }, y = { 0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 0 };
  function w(m, x) {
    const b = m.querySelector("[name='repeat_interval_value']");
    b && (b.value = (x ? x.interval : 1) || 1);
  }
  function D(m) {
    switch (m) {
      case 1:
      case 31:
        return `${m}st`;
      case 2:
        return `${m}nd`;
      case 3:
        return `${m}rd`;
      default:
        return `${m}th`;
    }
  }
  e.templates.repeat_monthly_date = function(m, x) {
    return `Every ${D(m.getDate())}`;
  }, e.templates.repeat_monthly_weekday = function(m, x) {
    const b = f(m);
    return `Every ${D(b.dayNumber)} ${e.locale.date.day_full[b.dayOfWeek]}`;
  }, e.templates.repeat_yearly_month_date = function(m, x) {
    const b = m.getDate(), E = e.locale.date.month_full[m.getMonth()];
    return `Every ${D(b)} day of ${E}`;
  }, e.templates.repeat_yearly_month_weekday = function(m, x) {
    const b = f(m), E = e.locale.date.month_full[m.getMonth()];
    return `Every ${D(b.dayNumber)} ${e.locale.date.day_full[b.dayOfWeek]} of ${E}`;
  };
  const M = { MONTHLY: function(m) {
    return { rrule: { freq: z.MONTHLY, interval: 1, bymonthday: m.start.getDate() }, until: new Date(9999, 1, 1) };
  }, WEEKLY: function(m) {
    let x = m.start.getDay() - 1;
    return x == -1 && (x = 6), { rrule: { freq: z.WEEKLY, interval: 1, byweekday: [x] }, until: new Date(9999, 1, 1) };
  }, DAILY: function(m) {
    return { rrule: { freq: z.DAILY, interval: 1 }, until: new Date(9999, 1, 1) };
  }, YEARLY: function(m) {
    return { rrule: { freq: z.YEARLY, bymonth: m.start.getMonth() + 1, interval: 1, bymonthday: m.start.getDate() }, until: new Date(9999, 1, 1) };
  }, WORKDAYS: function(m) {
    return { rrule: { freq: z.WEEKLY, interval: 1, byweekday: e.config.recurring_workdays }, until: new Date(9999, 1, 1) };
  }, CUSTOM: function(m, x) {
    const b = {}, E = x.querySelector('[name="repeat_interval_unit"]').value, S = Math.max(1, x.querySelector('[name="repeat_interval_value"]').value), T = x.querySelector('[name="dhx_custom_month_option"]') ? x.querySelector('[name="dhx_custom_month_option"]').value : null, C = x.querySelector('[name="dhx_custom_year_option"]') ? x.querySelector('[name="dhx_custom_year_option"]').value : null;
    let A, $;
    switch (b.interval = S, E) {
      case "DAILY":
        b.freq = z.DAILY;
        break;
      case "WEEKLY":
        b.freq = z.WEEKLY, A = [], x.querySelectorAll('.dhx_form_repeat_custom_week [name="week_day"]').forEach((R) => {
          R.checked && A.push(R.value);
        }), b.byweekday = A.map((R) => {
          switch (R) {
            case "MO":
              return z.MO.weekday;
            case "TU":
              return z.TU.weekday;
            case "WE":
              return z.WE.weekday;
            case "TH":
              return z.TH.weekday;
            case "FR":
              return z.FR.weekday;
            case "SA":
              return z.SA.weekday;
            case "SU":
              return z.SU.weekday;
          }
        });
        break;
      case "MONTHLY":
        b.freq = z.MONTHLY, T === "month_date" ? b.bymonthday = m.start.getDate() : ($ = m.start.getDay() - 1, $ == -1 && ($ = 6), b.byweekday = [$], b.bysetpos = f(m.start).dayNumber);
        break;
      case "YEARLY":
        b.freq = z.YEARLY, b.bymonth = m.start.getMonth() + 1, C == "month_date" ? b.bymonthday = m.start.getDate() : ($ = m.start.getDay() - 1, $ == -1 && ($ = 6), b.byweekday = [$], b.bysetpos = f(m.start).dayNumber);
    }
    const H = e.date.str_to_date("%Y-%m-%d");
    let O = new Date(9999, 1, 1);
    const P = x.querySelector('[name="dhx_custom_repeat_ends"]');
    return P && P.value === "ON" ? (O = H(x.querySelector('[name="dhx_form_repeat_ends_ondate"]').value), b.until = new Date(O)) : P && P.value === "AFTER" && (b.count = Math.max(1, x.querySelector('[name="dhx_form_repeat_ends_after"]').value)), { rrule: b, until: O };
  }, NEVER: function() {
  } };
  function k(m, x, b) {
    (function(E, S) {
      w(E, S);
    })(m, x), function(E, S, T) {
      if (w(E, S), E.querySelectorAll(".dhx_form_repeat_custom_week input").forEach((C) => C.checked = !1), S && S.byweekday)
        S.byweekday.forEach((C) => {
          const A = y[C.weekday], $ = u[A], H = E.querySelector(`.dhx_form_repeat_custom_week input[value="${$}"]`);
          H && (H.checked = !0);
        });
      else {
        const C = u[T.start_date.getDay()], A = E.querySelector(`.dhx_form_repeat_custom_week input[value="${C}"]`);
        A && (A.checked = !0);
      }
    }(m, x, b), function(E, S, T) {
      w(E, S);
      const C = E.querySelector('.dhx_form_repeat_custom_month [value="month_date"]'), A = E.querySelector('.dhx_form_repeat_custom_month [value="month_nth_weekday"]');
      if (C && A) {
        C.innerText = e.templates.repeat_monthly_date(T.start_date, T), A.innerText = e.templates.repeat_monthly_weekday(T.start_date, T);
        const $ = E.querySelector('[name="dhx_custom_month_option"]');
        $ && ($.value = !S || !S.bysetpos || S.byweekday && S.byweekday.length ? "month_nth_weekday" : "month_date");
      }
    }(m, x, b), function(E, S, T) {
      const C = E.querySelector('.dhx_form_repeat_custom_year [value="month_date"]'), A = E.querySelector('.dhx_form_repeat_custom_year [value="month_nth_weekday"]');
      C && A && (C.innerText = e.templates.repeat_yearly_month_date(T.start_date, T), A.innerText = e.templates.repeat_yearly_month_weekday(T.start_date, T), S && (!S.bysetpos || S.byweekday && S.byweekday.length) ? E.querySelector('[name="dhx_custom_year_option"]').value = "month_nth_weekday" : E.querySelector('[name="dhx_custom_year_option"]').value = "month_date");
    }(m, x, b), function(E, S, T) {
      const C = E.querySelector('.dhx_form_repeat_ends_extra [name="dhx_form_repeat_ends_after"]'), A = E.querySelector('.dhx_form_repeat_ends_extra [name="dhx_form_repeat_ends_ondate"]'), $ = E.querySelector("[name='dhx_custom_repeat_ends']");
      if (C && A && $) {
        C.value = 1;
        let H = e.date.date_to_str("%Y-%m-%d");
        e.config.repeat_date_of_end || (e.config.repeat_date_of_end = H(e.date.add(e._currentDate(), 30, "day"))), A.value = e.config.repeat_date_of_end, S && S.count ? ($.value = "AFTER", C.value = S.count) : T._end_date && T._end_date.getFullYear() !== 9999 ? ($.value = "ON", A.value = H(T._end_date)) : $.value = "NEVER", $.dispatchEvent(new Event("change"));
      }
    }(m, x, b);
  }
  function N(m) {
    for (let x = 0; x < e.config.lightbox.sections.length; x++) {
      let b = e.config.lightbox.sections[x];
      if (b.type === m)
        return e.formSection(b.name);
    }
    return null;
  }
  e.form_blocks.recurring = { _get_node: function(m) {
    if (typeof m == "string") {
      let x = e._lightbox.querySelector(`#${m}`);
      x || (x = document.getElementById(m)), m = x;
    }
    return m.style.display == "none" && (m.style.display = ""), m;
  }, _outer_html: function(m) {
    return m.outerHTML || function(x) {
      let b, E = document.createElement("div");
      return E.appendChild(x.cloneNode(!0)), b = E.innerHTML, E = null, b;
    }(m);
  }, render: function(m) {
    if (m.form) {
      let b = e.form_blocks.recurring, E = b._get_node(m.form), S = b._outer_html(E);
      return E.style.display = "none", S;
    }
    let x = e.locale.labels;
    return `<div class="dhx_form_rrule">
		<div class="dhx_form_repeat_pattern">
			<select>
				<option value="NEVER">${x.repeat_never}</option>
				<option value="DAILY">${x.repeat_daily}</option>
				<option value="WEEKLY">${x.repeat_weekly}</option>
				<option value="MONTHLY">${x.repeat_monthly}</option>
				<option value="YEARLY">${x.repeat_yearly}</option>
				<option value="WORKDAYS">${x.repeat_workdays}</option>
				<option value="CUSTOM">${x.repeat_custom}</option>
			</select>
		</div>
		<div class="dhx_form_repeat_custom dhx_hidden">
			<div class="dhx_form_repeat_custom_interval">
				<input name="repeat_interval_value" type="number" min="1">
				<select name="repeat_interval_unit">
					<option value="DAILY">${x.repeat_freq_day}</option>
					<option value="WEEKLY">${x.repeat_freq_week}</option>
					<option value="MONTHLY">${x.repeat_freq_month}</option>
					<option value="YEARLY">${x.repeat_freq_year}</option>
				</select>
			</div>

			<div class="dhx_form_repeat_custom_additional">
				<div class="dhx_form_repeat_custom_week dhx_hidden">
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="MO" />${x.day_for_recurring[1]}</label>
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="TU" />${x.day_for_recurring[2]}</label>
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="WE" />${x.day_for_recurring[3]}</label>
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="TH" />${x.day_for_recurring[4]}</label>
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="FR" />${x.day_for_recurring[5]}</label>
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="SA" />${x.day_for_recurring[6]}</label>
					<label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="SU" />${x.day_for_recurring[0]}</label>
				</div>

				<div class="dhx_form_repeat_custom_month dhx_hidden">
					<select name="dhx_custom_month_option">
						<option value="month_date"></option>
						<option value="month_nth_weekday"></option>
					</select>
				</div>

				<div class="dhx_form_repeat_custom_year dhx_hidden">
					<select name="dhx_custom_year_option">
						<option value="month_date"></option>
						<option value="month_nth_weekday"></option>
					</select>
				</div>
			</div>

			<div class="dhx_form_repeat_ends">
				<div>${x.repeat_ends}</div>
				<div class="dhx_form_repeat_ends_options">
					<select name="dhx_custom_repeat_ends">
						<option value="NEVER">${x.repeat_never}</option>
						<option value="AFTER">${x.repeat_radio_end2}</option>
						<option value="ON">${x.repeat_on_date}</option>
					</select>
					<div class="dhx_form_repeat_ends_extra">
						<div class="dhx_form_repeat_ends_after dhx_hidden">
							<label><input type="number" min="1" name="dhx_form_repeat_ends_after">${x.repeat_text_occurrences_count}</label>
						</div>
						<div class="dhx_form_repeat_ends_on dhx_hidden">
							<input type="date" name="dhx_form_repeat_ends_ondate">
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>`;
  }, _init_set_value: function(m, x, b) {
    function E($) {
      $ && $.classList.add("dhx_hidden");
    }
    function S($) {
      $ && $.classList.remove("dhx_hidden");
    }
    e.form_blocks.recurring._ds = { start: b.start_date, end: b.end_date };
    const T = m.querySelector(".dhx_form_repeat_pattern select");
    T && T.addEventListener("change", function() {
      (function($) {
        const H = m.querySelector(".dhx_form_repeat_custom");
        $ === "CUSTOM" ? S(H) : E(H);
      })(this.value);
    });
    const C = m.querySelector(".dhx_form_repeat_custom_interval [name='repeat_interval_unit']");
    C && C.addEventListener("change", function() {
      (function($) {
        const H = { weekly: m.querySelector(".dhx_form_repeat_custom_week"), monthly: m.querySelector(".dhx_form_repeat_custom_month"), yearly: m.querySelector(".dhx_form_repeat_custom_year") };
        switch ($) {
          case "DAILY":
            E(H.weekly), E(H.monthly), E(H.yearly);
            break;
          case "WEEKLY":
            S(H.weekly), E(H.monthly), E(H.yearly);
            break;
          case "MONTHLY":
            E(H.weekly), S(H.monthly), E(H.yearly);
            break;
          case "YEARLY":
            E(H.weekly), E(H.monthly), S(H.yearly);
        }
      })(this.value);
    });
    const A = m.querySelector(".dhx_form_repeat_ends [name='dhx_custom_repeat_ends']");
    A && A.addEventListener("change", function() {
      (function($) {
        const H = { after: m.querySelector(".dhx_form_repeat_ends_extra .dhx_form_repeat_ends_after"), on: m.querySelector(".dhx_form_repeat_ends_extra .dhx_form_repeat_ends_on") };
        switch ($) {
          case "NEVER":
            E(H.after), E(H.on);
            break;
          case "AFTER":
            S(H.after), E(H.on);
            break;
          case "ON":
            E(H.after), S(H.on);
        }
      })(this.value);
    }), e._lightbox._rec_init_done = !0;
  }, button_click: function() {
  }, set_value: function(m, x, b) {
    let E = e.form_blocks.recurring;
    e._lightbox._rec_init_done || E._init_set_value(m, x, b), m.open = !b.rrule, m.blocked = this._is_modified_occurrence(b);
    let S = E._ds;
    if (S.start = b.start_date, S.end = b._end_date, b.rrule) {
      const C = ge(b.rrule);
      k(m, C.origOptions, b);
      const A = function($, H) {
        const O = $.options, P = O.until || H;
        return O.count || P && P.getFullYear() !== 9999 ? "CUSTOM" : O.freq !== z.DAILY || O.interval !== 1 || O.byweekday ? O.freq !== z.WEEKLY || O.interval !== 1 || O.byweekday ? O.freq !== z.MONTHLY || O.interval !== 1 || O.bysetpos ? O.freq !== z.YEARLY || O.interval !== 1 || O.bysetpos ? O.freq === z.DAILY && O.byweekday && O.byweekday.length === e.config.recurring_workdays.length && O.byweekday.includes(z.MO) && O.byweekday.includes(z.TU) && O.byweekday.includes(z.WE) && O.byweekday.includes(z.TH) && O.byweekday.includes(z.FR) ? "WORKDAYS" : "CUSTOM" : "YEARLY" : "MONTHLY" : "WEEKLY" : "DAILY";
      }(C, b._end_date);
      if (m.querySelector(".dhx_form_repeat_pattern select").value = A, A === "CUSTOM") {
        let $;
        switch (C.origOptions.freq) {
          case z.DAILY:
            $ = "DAILY";
            break;
          case z.WEEKLY:
            $ = "WEEKLY";
            break;
          case z.MONTHLY:
            $ = "MONTHLY";
            break;
          case z.YEARLY:
            $ = "YEARLY";
        }
        $ && (m.querySelector('[name="repeat_interval_unit"]').value = $, m.querySelector('[name="repeat_interval_unit"]').dispatchEvent(new Event("change")));
      }
    } else {
      k(m, null, b);
      const C = m.querySelector(".dhx_form_repeat_pattern select");
      C && (C.value = "NEVER");
    }
    const T = m.querySelector(".dhx_form_repeat_pattern select");
    T && T.dispatchEvent(new Event("change"));
  }, get_value: function(m, x) {
    const b = m.querySelector(".dhx_form_repeat_pattern select");
    if (m.blocked || b && b.value === "NEVER")
      x.rrule = x.rrule = "", x._end_date = x.end_date;
    else {
      let E = e.form_blocks.recurring._ds, S = {};
      (function() {
        let A = e.formSection("time");
        if (A || (A = N("time")), A || (A = N("calendar_time")), !A)
          throw new Error(["Can't calculate the recurring rule, the Recurring form block can't find the Time control. Make sure you have the time control in 'scheduler.config.lightbox.sections' config.", "You can use either the default time control https://docs.dhtmlx.com/scheduler/time.html, or the datepicker https://docs.dhtmlx.com/scheduler/minicalendar.html, or a custom control. ", 'In the latter case, make sure the control is named "time":', "", "scheduler.config.lightbox.sections = [", '{name:"time", height:72, type:"YOU CONTROL", map_to:"auto" }];'].join(`
`));
        return A;
      })().getValue(S), E.start = S.start_date;
      const T = b ? b.value : "CUSTOM", C = M[T](E, m);
      x.rrule = new z(C.rrule).toString().replace("RRULE:", ""), E.end = C.until, x.duration = Math.floor((S.end_date - S.start_date) / 1e3), E._start ? (x.start_date = new Date(E.start), x._start_date = new Date(E.start), E._start = !1) : x._start_date = null, x._end_date = E.end;
    }
    return x.rrule;
  }, focus: function(m) {
  } };
}, recurring_legacy: function(e) {
  function i() {
    var a = e.formSection("recurring");
    if (a || (a = t("recurring")), !a)
      throw new Error(["Can't locate the Recurring form section.", "Make sure that you have the recurring control on the lightbox configuration https://docs.dhtmlx.com/scheduler/recurring_events.html#recurringlightbox ", 'and that the recurring control has name "recurring":', "", "scheduler.config.lightbox.sections = [", '	{name:"recurring", ... }', "];"].join(`
`));
    return a;
  }
  function t(a) {
    for (var o = 0; o < e.config.lightbox.sections.length; o++) {
      var d = e.config.lightbox.sections[o];
      if (d.type === a)
        return e.formSection(d.name);
    }
    return null;
  }
  function n(a) {
    return new Date(a.getFullYear(), a.getMonth(), a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds(), 0);
  }
  var s;
  e.config.occurrence_timestamp_in_utc = !1, e.config.recurring_workdays = [1, 2, 3, 4, 5], e.form_blocks.recurring = { _get_node: function(a) {
    if (typeof a == "string") {
      let o = e._lightbox.querySelector(`#${a}`);
      o || (o = document.getElementById(a)), a = o;
    }
    return a.style.display == "none" && (a.style.display = ""), a;
  }, _outer_html: function(a) {
    return a.outerHTML || (o = a, (r = document.createElement("div")).appendChild(o.cloneNode(!0)), d = r.innerHTML, r = null, d);
    var o, d, r;
  }, render: function(a) {
    if (a.form) {
      var o = e.form_blocks.recurring, d = o._get_node(a.form), r = o._outer_html(d);
      return d.style.display = "none", r;
    }
    var l = e.locale.labels;
    return '<div class="dhx_form_repeat"> <form> <div class="dhx_repeat_left"> <div><label><input class="dhx_repeat_radio" type="radio" name="repeat" value="day" />' + l.repeat_radio_day + '</label></div> <div><label><input class="dhx_repeat_radio" type="radio" name="repeat" value="week"/>' + l.repeat_radio_week + '</label></div> <div><label><input class="dhx_repeat_radio" type="radio" name="repeat" value="month" checked />' + l.repeat_radio_month + '</label></div> <div><label><input class="dhx_repeat_radio" type="radio" name="repeat" value="year" />' + l.repeat_radio_year + '</label></div> </div> <div class="dhx_repeat_divider"></div> <div class="dhx_repeat_center"> <div style="display:none;" id="dhx_repeat_day"> <div><label><input class="dhx_repeat_radio" type="radio" name="day_type" value="d"/>' + l.repeat_radio_day_type + '</label><label><input class="dhx_repeat_text" type="text" name="day_count" value="1" />' + l.repeat_text_day_count + '</label></div> <div><label><input class="dhx_repeat_radio" type="radio" name="day_type" checked value="w"/>' + l.repeat_radio_day_type2 + '</label></div> </div> <div style="display:none;" id="dhx_repeat_week"><div><label>' + l.repeat_week + '<input class="dhx_repeat_text" type="text" name="week_count" value="1" /></label><span>' + l.repeat_text_week_count + '</span></div>  <table class="dhx_repeat_days"> <tr> <td><div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="1" />' + l.day_for_recurring[1] + '</label></div> <div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="4" />' + l.day_for_recurring[4] + '</label></div></td> <td><div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="2" />' + l.day_for_recurring[2] + '</label></div> <div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="5" />' + l.day_for_recurring[5] + '</label></div></td> <td><div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="3" />' + l.day_for_recurring[3] + '</label></div> <div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="6" />' + l.day_for_recurring[6] + '</label></div></td> <td><div><label><input class="dhx_repeat_checkbox" type="checkbox" name="week_day" value="0" />' + l.day_for_recurring[0] + '</label></div> </td> </tr> </table> </div> <div id="dhx_repeat_month"> <div><label class = "dhx_repeat_month_label"><input class="dhx_repeat_radio" type="radio" name="month_type" value="d"/>' + l.repeat_radio_month_type + '</label><label><input class="dhx_repeat_text" type="text" name="month_day" value="1" />' + l.repeat_text_month_day + '</label><label><input class="dhx_repeat_text" type="text" name="month_count" value="1" />' + l.repeat_text_month_count + '</label></div> <div><label class = "dhx_repeat_month_label"><input class="dhx_repeat_radio" type="radio" name="month_type" checked value="w"/>' + l.repeat_radio_month_start + '</label><input class="dhx_repeat_text" type="text" name="month_week2" value="1" /><label><select name="month_day2">	<option value="1" selected >' + e.locale.date.day_full[1] + '<option value="2">' + e.locale.date.day_full[2] + '<option value="3">' + e.locale.date.day_full[3] + '<option value="4">' + e.locale.date.day_full[4] + '<option value="5">' + e.locale.date.day_full[5] + '<option value="6">' + e.locale.date.day_full[6] + '<option value="0">' + e.locale.date.day_full[0] + "</select>" + l.repeat_text_month_count2_before + '</label><label><input class="dhx_repeat_text" type="text" name="month_count2" value="1" />' + l.repeat_text_month_count2_after + '</label></div> </div> <div style="display:none;" id="dhx_repeat_year"> <div><label class = "dhx_repeat_year_label"><input class="dhx_repeat_radio" type="radio" name="year_type" value="d"/>' + l.repeat_radio_day_type + '</label><label><input class="dhx_repeat_text" type="text" name="year_day" value="1" />' + l.repeat_text_year_day + '</label><label><select name="year_month"><option value="0" selected >' + l.month_for_recurring[0] + '<option value="1">' + l.month_for_recurring[1] + '<option value="2">' + l.month_for_recurring[2] + '<option value="3">' + l.month_for_recurring[3] + '<option value="4">' + l.month_for_recurring[4] + '<option value="5">' + l.month_for_recurring[5] + '<option value="6">' + l.month_for_recurring[6] + '<option value="7">' + l.month_for_recurring[7] + '<option value="8">' + l.month_for_recurring[8] + '<option value="9">' + l.month_for_recurring[9] + '<option value="10">' + l.month_for_recurring[10] + '<option value="11">' + l.month_for_recurring[11] + "</select>" + l.select_year_month + '</label></div> <div><label class = "dhx_repeat_year_label"><input class="dhx_repeat_radio" type="radio" name="year_type" checked value="w"/>' + l.repeat_year_label + '</label><input class="dhx_repeat_text" type="text" name="year_week2" value="1" /><select name="year_day2"><option value="1" selected >' + e.locale.date.day_full[1] + '<option value="2">' + e.locale.date.day_full[2] + '<option value="3">' + e.locale.date.day_full[3] + '<option value="4">' + e.locale.date.day_full[4] + '<option value="5">' + e.locale.date.day_full[5] + '<option value="6">' + e.locale.date.day_full[6] + '<option value="7">' + e.locale.date.day_full[0] + "</select>" + l.select_year_day2 + '<select name="year_month2"><option value="0" selected >' + l.month_for_recurring[0] + '<option value="1">' + l.month_for_recurring[1] + '<option value="2">' + l.month_for_recurring[2] + '<option value="3">' + l.month_for_recurring[3] + '<option value="4">' + l.month_for_recurring[4] + '<option value="5">' + l.month_for_recurring[5] + '<option value="6">' + l.month_for_recurring[6] + '<option value="7">' + l.month_for_recurring[7] + '<option value="8">' + l.month_for_recurring[8] + '<option value="9">' + l.month_for_recurring[9] + '<option value="10">' + l.month_for_recurring[10] + '<option value="11">' + l.month_for_recurring[11] + '</select></div> </div> </div> <div class="dhx_repeat_divider"></div> <div class="dhx_repeat_right"> <div><label><input class="dhx_repeat_radio" type="radio" name="end" checked/>' + l.repeat_radio_end + '</label></div> <div><label><input class="dhx_repeat_radio" type="radio" name="end" />' + l.repeat_radio_end2 + '</label><input class="dhx_repeat_text" type="text" name="occurences_count" value="1" />' + l.repeat_text_occurrences_count + '</div> <div><label><input class="dhx_repeat_radio" type="radio" name="end" />' + l.repeat_radio_end3 + '</label><input class="dhx_repeat_date" type="text" name="date_of_end" value="' + e.config.repeat_date_of_end + '" /></div> </div> </form> </div> </div>';
  }, _ds: {}, _get_form_node: function(a, o, d) {
    var r = a[o];
    if (!r)
      return null;
    if (r.nodeName)
      return r;
    if (r.length) {
      for (var l = 0; l < r.length; l++)
        if (r[l].value == d)
          return r[l];
    }
  }, _get_node_value: function(a, o, d) {
    var r = a[o];
    if (!r)
      return "";
    if (r.length) {
      if (d) {
        for (var l = [], _ = 0; _ < r.length; _++)
          r[_].checked && l.push(r[_].value);
        return l;
      }
      for (_ = 0; _ < r.length; _++)
        if (r[_].checked)
          return r[_].value;
    }
    return r.value ? d ? [r.value] : r.value : void 0;
  }, _get_node_numeric_value: function(a, o) {
    return 1 * e.form_blocks.recurring._get_node_value(a, o) || 0;
  }, _set_node_value: function(a, o, d) {
    var r = a[o];
    if (r) {
      if (r.name == o)
        r.value = d;
      else if (r.length)
        for (var l = typeof d == "object", _ = 0; _ < r.length; _++)
          (l || r[_].value == d) && (r[_].checked = l ? !!d[r[_].value] : !!d);
    }
  }, _init_set_value: function(a, o, d) {
    var r = e.form_blocks.recurring, l = r._get_node_value, _ = r._set_node_value;
    e.form_blocks.recurring._ds = { start: d.start_date, end: d._end_date };
    var h = e.date.str_to_date(e.config.repeat_date, !1, !0), p = e.date.date_to_str(e.config.repeat_date), v = a.getElementsByTagName("FORM")[0], g = {};
    function c(m) {
      for (var x = 0; x < m.length; x++) {
        var b = m[x];
        if (b.name)
          if (g[b.name])
            if (g[b.name].nodeType) {
              var E = g[b.name];
              g[b.name] = [E, b];
            } else
              g[b.name].push(b);
          else
            g[b.name] = b;
      }
    }
    if (c(v.getElementsByTagName("INPUT")), c(v.getElementsByTagName("SELECT")), !e.config.repeat_date_of_end) {
      var f = e.date.date_to_str(e.config.repeat_date);
      e.config.repeat_date_of_end = f(e.date.add(e._currentDate(), 30, "day"));
    }
    _(g, "date_of_end", e.config.repeat_date_of_end);
    var u = function(m) {
      return e._lightbox.querySelector(`#${m}`) || { style: {} };
    };
    function y() {
      u("dhx_repeat_day").style.display = "none", u("dhx_repeat_week").style.display = "none", u("dhx_repeat_month").style.display = "none", u("dhx_repeat_year").style.display = "none", u("dhx_repeat_" + this.value).style.display = "", e.setLightboxSize();
    }
    function w(m, x) {
      var b = m.end;
      if (b.length)
        if (b[0].value && b[0].value != "on")
          for (var E = 0; E < b.length; E++)
            b[E].value == x && (b[E].checked = !0);
        else {
          var S = 0;
          switch (x) {
            case "no":
              S = 0;
              break;
            case "date_of_end":
              S = 2;
              break;
            default:
              S = 1;
          }
          b[S].checked = !0;
        }
      else
        b.value = x;
    }
    e.form_blocks.recurring._get_repeat_code = function(m) {
      var x = [l(g, "repeat")];
      for (D[x[0]](x, m); x.length < 5; )
        x.push("");
      var b = "", E = function(S) {
        var T = S.end;
        if (T.length) {
          for (var C = 0; C < T.length; C++)
            if (T[C].checked)
              return T[C].value && T[C].value != "on" ? T[C].value : C ? C == 2 ? "date_of_end" : "occurences_count" : "no";
        } else if (T.value)
          return T.value;
        return "no";
      }(g);
      return E == "no" ? (m.end = new Date(9999, 1, 1), b = "no") : E == "date_of_end" ? m.end = function(S) {
        var T = h(S);
        return e.config.include_end_by && (T = e.date.add(T, 1, "day")), T;
      }(l(g, "date_of_end")) : (e.transpose_type(x.join("_")), b = Math.max(1, l(g, "occurences_count")), m.end = e.date["add_" + x.join("_")](new Date(m.start), b + 0, { start_date: m.start }) || m.start), x.join("_") + "#" + b;
    };
    var D = { month: function(m, x) {
      var b = e.form_blocks.recurring._get_node_value, E = e.form_blocks.recurring._get_node_numeric_value;
      b(g, "month_type") == "d" ? (m.push(Math.max(1, E(g, "month_count"))), x.start.setDate(b(g, "month_day"))) : (m.push(Math.max(1, E(g, "month_count2"))), m.push(b(g, "month_day2")), m.push(Math.max(1, E(g, "month_week2"))), e.config.repeat_precise || x.start.setDate(1)), x._start = !0;
    }, week: function(m, x) {
      var b = e.form_blocks.recurring._get_node_value, E = e.form_blocks.recurring._get_node_numeric_value;
      m.push(Math.max(1, E(g, "week_count"))), m.push(""), m.push("");
      for (var S = [], T = b(g, "week_day", !0), C = x.start.getDay(), A = !1, $ = 0; $ < T.length; $++)
        S.push(T[$]), A = A || T[$] == C;
      S.length || (S.push(C), A = !0), S.sort(), e.config.repeat_precise ? A || (e.transpose_day_week(x.start, S, 1, 7), x._start = !0) : (x.start = e.date.week_start(x.start), x._start = !0), m.push(S.join(","));
    }, day: function(m) {
      var x = e.form_blocks.recurring._get_node_value, b = e.form_blocks.recurring._get_node_numeric_value;
      x(g, "day_type") == "d" ? m.push(Math.max(1, b(g, "day_count"))) : (m.push("week"), m.push(1), m.push(""), m.push(""), m.push(e.config.recurring_workdays.join(",")), m.splice(0, 1));
    }, year: function(m, x) {
      var b = e.form_blocks.recurring._get_node_value;
      b(g, "year_type") == "d" ? (m.push("1"), x.start.setMonth(0), x.start.setDate(b(g, "year_day")), x.start.setMonth(b(g, "year_month"))) : (m.push("1"), m.push(b(g, "year_day2")), m.push(b(g, "year_week2")), x.start.setDate(1), x.start.setMonth(b(g, "year_month2"))), x._start = !0;
    } }, M = { week: function(m, x) {
      var b = e.form_blocks.recurring._set_node_value;
      b(g, "week_count", m[1]);
      for (var E = m[4].split(","), S = {}, T = 0; T < E.length; T++)
        S[E[T]] = !0;
      b(g, "week_day", S);
    }, month: function(m, x) {
      var b = e.form_blocks.recurring._set_node_value;
      m[2] === "" ? (b(g, "month_type", "d"), b(g, "month_count", m[1]), b(g, "month_day", x.start.getDate())) : (b(g, "month_type", "w"), b(g, "month_count2", m[1]), b(g, "month_week2", m[3]), b(g, "month_day2", m[2]));
    }, day: function(m, x) {
      var b = e.form_blocks.recurring._set_node_value;
      b(g, "day_type", "d"), b(g, "day_count", m[1]);
    }, year: function(m, x) {
      var b = e.form_blocks.recurring._set_node_value;
      m[2] === "" ? (b(g, "year_type", "d"), b(g, "year_day", x.start.getDate()), b(g, "year_month", x.start.getMonth())) : (b(g, "year_type", "w"), b(g, "year_week2", m[3]), b(g, "year_day2", m[2]), b(g, "year_month2", x.start.getMonth()));
    } };
    e.form_blocks.recurring._set_repeat_code = function(m, x) {
      var b = e.form_blocks.recurring._set_node_value, E = m.split("#");
      switch (m = E[0].split("_"), M[m[0]](m, x), E[1]) {
        case "no":
          w(g, "no");
          break;
        case "":
          w(g, "date_of_end");
          var S = x.end;
          e.config.include_end_by && (S = e.date.add(S, -1, "day")), b(g, "date_of_end", p(S));
          break;
        default:
          w(g, "occurences_count"), b(g, "occurences_count", E[1]);
      }
      b(g, "repeat", m[0]);
      var T = e.form_blocks.recurring._get_form_node(g, "repeat", m[0]);
      T.nodeName == "SELECT" ? (T.dispatchEvent(new Event("change")), T.dispatchEvent(new MouseEvent("click"))) : T.dispatchEvent(new MouseEvent("click"));
    };
    for (var k = 0; k < v.elements.length; k++) {
      var N = v.elements[k];
      N.name === "repeat" && (N.nodeName != "SELECT" || N.$_eventAttached ? N.$_eventAttached || (N.$_eventAttached = !0, N.addEventListener("click", y)) : (N.$_eventAttached = !0, N.addEventListener("change", y)));
    }
    e._lightbox._rec_init_done = !0;
  }, set_value: function(a, o, d) {
    var r = e.form_blocks.recurring;
    e._lightbox._rec_init_done || r._init_set_value(a, o, d), a.open = !d.rec_type, a.blocked = this._is_modified_occurence(d);
    var l = r._ds;
    l.start = d.start_date, l.end = d._end_date, r._toggle_block(), o && r._set_repeat_code(o, l);
  }, get_value: function(a, o) {
    if (a.open) {
      var d = e.form_blocks.recurring._ds, r = {};
      (function() {
        var l = e.formSection("time");
        if (l || (l = t("time")), l || (l = t("calendar_time")), !l)
          throw new Error(["Can't calculate the recurring rule, the Recurring form block can't find the Time control. Make sure you have the time control in 'scheduler.config.lightbox.sections' config.", "You can use either the default time control https://docs.dhtmlx.com/scheduler/time.html, or the datepicker https://docs.dhtmlx.com/scheduler/minicalendar.html, or a custom control. ", 'In the latter case, make sure the control is named "time":', "", "scheduler.config.lightbox.sections = [", '{name:"time", height:72, type:"YOU CONTROL", map_to:"auto" }];'].join(`
`));
        return l;
      })().getValue(r), d.start = r.start_date, o.rec_type = e.form_blocks.recurring._get_repeat_code(d), d._start ? (o.start_date = new Date(d.start), o._start_date = new Date(d.start), d._start = !1) : o._start_date = null, o._end_date = d.end, o.rec_pattern = o.rec_type.split("#")[0];
    } else
      o.rec_type = o.rec_pattern = "", o._end_date = o.end_date;
    return o.rec_type;
  }, _get_button: function() {
    return i().header.firstChild.firstChild;
  }, _get_form: function() {
    return i().node;
  }, open: function() {
    var a = e.form_blocks.recurring;
    a._get_form().open || a._toggle_block();
  }, close: function() {
    var a = e.form_blocks.recurring;
    a._get_form().open && a._toggle_block();
  }, _toggle_block: function() {
    var a = e.form_blocks.recurring, o = a._get_form(), d = a._get_button();
    o.open || o.blocked ? (o.style.height = "0px", d && (d.style.backgroundPosition = "-5px 20px", d.nextSibling.innerHTML = e.locale.labels.button_recurring)) : (o.style.height = "auto", d && (d.style.backgroundPosition = "-5px 0px", d.nextSibling.innerHTML = e.locale.labels.button_recurring_open)), o.open = !o.open, e.setLightboxSize();
  }, focus: function(a) {
  }, button_click: function(a, o, d) {
    e.form_blocks.recurring._get_form().blocked || e.form_blocks.recurring._toggle_block();
  } }, e._rec_markers = {}, e._rec_markers_pull = {}, e._add_rec_marker = function(a, o) {
    a._pid_time = o, this._rec_markers[a.id] = a, this._rec_markers_pull[a.event_pid] || (this._rec_markers_pull[a.event_pid] = {}), this._rec_markers_pull[a.event_pid][o] = a;
  }, e._get_rec_marker = function(a, o) {
    var d = this._rec_markers_pull[o];
    return d ? d[a] : null;
  }, e._get_rec_markers = function(a) {
    return this._rec_markers_pull[a] || [];
  }, e._rec_temp = [], s = e.addEvent, e.addEvent = function(a, o, d, r, l) {
    var _ = s.apply(this, arguments);
    if (_ && e.getEvent(_)) {
      var h = e.getEvent(_);
      h.start_date && (h.start_date = n(h.start_date)), h.end_date && (h.end_date = n(h.end_date)), this._is_modified_occurence(h) && e._add_rec_marker(h, 1e3 * h.event_length), h.rec_type && (h.rec_pattern = h.rec_type.split("#")[0]);
    }
    return _;
  }, e.attachEvent("onEventIdChange", function(a, o) {
    if (!this._ignore_call) {
      this._ignore_call = !0, e._rec_markers[a] && (e._rec_markers[o] = e._rec_markers[a], delete e._rec_markers[a]), e._rec_markers_pull[a] && (e._rec_markers_pull[o] = e._rec_markers_pull[a], delete e._rec_markers_pull[a]);
      for (var d = 0; d < this._rec_temp.length; d++)
        (r = this._rec_temp[d]).event_pid == a && (r.event_pid = o, this.changeEventId(r.id, o + "#" + r.id.split("#")[1]));
      for (var d in this._rec_markers) {
        var r;
        (r = this._rec_markers[d]).event_pid == a && (r.event_pid = o, r._pid_changed = !0);
      }
      var l = e._rec_markers[o];
      l && l._pid_changed && (delete l._pid_changed, setTimeout(function() {
        if (e.$destroyed)
          return !0;
        e.callEvent("onEventChanged", [o, e.getEvent(o)]);
      }, 1)), delete this._ignore_call;
    }
  }), e.attachEvent("onConfirmedBeforeEventDelete", function(a) {
    var o = this.getEvent(a);
    if (this._is_virtual_event(a) || this._is_modified_occurence(o) && o.rec_type && o.rec_type != "none") {
      a = a.split("#");
      var d = this.uid(), r = a[1] ? a[1] : Math.round(o._pid_time / 1e3), l = this._copy_event(o);
      l.id = d, l.event_pid = o.event_pid || a[0];
      var _ = r;
      l.event_length = _, l.rec_type = l.rec_pattern = "none", this.addEvent(l), this._add_rec_marker(l, 1e3 * _);
    } else {
      o.rec_type && this._lightbox_id && this._roll_back_dates(o);
      var h = this._get_rec_markers(a);
      for (var p in h)
        h.hasOwnProperty(p) && (a = h[p].id, this.getEvent(a) && this.deleteEvent(a, !0));
    }
    return !0;
  }), e.attachEvent("onEventDeleted", function(a, o) {
    !this._is_virtual_event(a) && this._is_modified_occurence(o) && (e._events[a] || (o.rec_type = o.rec_pattern = "none", this.setEvent(a, o)));
  }), e.attachEvent("onEventChanged", function(a, o) {
    if (this._loading)
      return !0;
    var d = this.getEvent(a);
    if (this._is_virtual_event(a)) {
      a = a.split("#");
      var r = this.uid();
      this._not_render = !0;
      var l = this._copy_event(o);
      l.id = r, l.event_pid = a[0];
      var _ = a[1];
      l.event_length = _, l.rec_type = l.rec_pattern = "", this._add_rec_marker(l, 1e3 * _), this.addEvent(l), this._not_render = !1;
    } else {
      d.start_date && (d.start_date = n(d.start_date)), d.end_date && (d.end_date = n(d.end_date)), d.rec_type && this._lightbox_id && this._roll_back_dates(d);
      var h = this._get_rec_markers(a);
      for (var p in h)
        h.hasOwnProperty(p) && (delete this._rec_markers[h[p].id], this.deleteEvent(h[p].id, !0));
      delete this._rec_markers_pull[a];
      for (var v = !1, g = 0; g < this._rendered.length; g++)
        this._rendered[g].getAttribute(this.config.event_attribute) == a && (v = !0);
      v || (this._select_id = null);
    }
    return !0;
  }), e.attachEvent("onEventAdded", function(a) {
    if (!this._loading) {
      var o = this.getEvent(a);
      o.rec_type && !o.event_length && this._roll_back_dates(o);
    }
    return !0;
  }), e.attachEvent("onEventSave", function(a, o, d) {
    return this.getEvent(a).rec_type || !o.rec_type || this._is_virtual_event(a) || (this._select_id = null), !0;
  }), e.attachEvent("onEventCreated", function(a) {
    var o = this.getEvent(a);
    return o.rec_type || (o.rec_type = o.rec_pattern = o.event_length = o.event_pid = ""), !0;
  }), e.attachEvent("onEventCancel", function(a) {
    var o = this.getEvent(a);
    o.rec_type && (this._roll_back_dates(o), this.render_view_data());
  }), e._roll_back_dates = function(a) {
    a.start_date && (a.start_date = n(a.start_date)), a.end_date && (a.end_date = n(a.end_date)), a.event_length = Math.round((a.end_date.valueOf() - a.start_date.valueOf()) / 1e3), a.end_date = a._end_date, a._start_date && (a.start_date.setMonth(0), a.start_date.setDate(a._start_date.getDate()), a.start_date.setMonth(a._start_date.getMonth()), a.start_date.setFullYear(a._start_date.getFullYear()));
  }, e._is_virtual_event = function(a) {
    return a.toString().indexOf("#") != -1;
  }, e._is_modified_occurence = function(a) {
    return a.event_pid && a.event_pid != "0";
  }, e.showLightbox_rec = e.showLightbox, e.showLightbox = function(a) {
    var o = this.locale, d = e.config.lightbox_recurring, r = this.getEvent(a), l = r.event_pid, _ = this._is_virtual_event(a);
    _ && (l = a.split("#")[0]);
    var h = function(v) {
      var g = e.getEvent(v);
      return g._end_date = g.end_date, g.end_date = new Date(g.start_date.valueOf() + 1e3 * g.event_length), e.showLightbox_rec(v);
    };
    if ((l || 1 * l == 0) && r.rec_type)
      return h(a);
    if (!l || l === "0" || !o.labels.confirm_recurring || d == "instance" || d == "series" && !_)
      return this.showLightbox_rec(a);
    if (d == "ask") {
      var p = this;
      e.modalbox({ text: o.labels.confirm_recurring, title: o.labels.title_confirm_recurring, width: "500px", position: "middle", buttons: [o.labels.button_edit_series, o.labels.button_edit_occurrence, o.labels.icon_cancel], callback: function(v) {
        switch (+v) {
          case 0:
            return h(l);
          case 1:
            return p.showLightbox_rec(a);
          case 2:
            return;
        }
      } });
    } else
      h(l);
  }, e.get_visible_events_rec = e.get_visible_events, e.get_visible_events = function(a) {
    for (var o = 0; o < this._rec_temp.length; o++)
      delete this._events[this._rec_temp[o].id];
    this._rec_temp = [];
    var d = this.get_visible_events_rec(a), r = [];
    for (o = 0; o < d.length; o++)
      d[o].rec_type ? d[o].rec_pattern != "none" && this.repeat_date(d[o], r) : r.push(d[o]);
    return r;
  }, function() {
    var a = e.isOneDayEvent;
    e.isOneDayEvent = function(d) {
      return !!d.rec_type || a.call(this, d);
    };
    var o = e.updateEvent;
    e.updateEvent = function(d) {
      var r = e.getEvent(d);
      r && r.rec_type && (r.rec_pattern = (r.rec_type || "").split("#")[0]), r && r.rec_type && !this._is_virtual_event(d) ? e.update_view() : o.call(this, d);
    };
  }(), e.transponse_size = { day: 1, week: 7, month: 1, year: 12 }, e.date.day_week = function(a, o, d) {
    a.setDate(1);
    var r = e.date.month_start(new Date(a)), l = 1 * o + (d = 7 * (d - 1)) - a.getDay() + 1;
    a.setDate(l <= d ? l + 7 : l);
    var _ = e.date.month_start(new Date(a));
    return r.valueOf() === _.valueOf();
  }, e.transpose_day_week = function(a, o, d, r, l) {
    for (var _ = (a.getDay() || (e.config.start_on_monday ? 7 : 0)) - d, h = 0; h < o.length; h++)
      if (o[h] > _)
        return a.setDate(a.getDate() + 1 * o[h] - _ - (r ? d : l));
    this.transpose_day_week(a, o, d + r, null, d);
  }, e.transpose_type = function(a) {
    var o = "transpose_" + a;
    if (!this.date[o]) {
      var d = a.split("_"), r = "add_" + a, l = this.transponse_size[d[0]] * d[1];
      if (d[0] == "day" || d[0] == "week") {
        var _ = null;
        if (d[4] && (_ = d[4].split(","), e.config.start_on_monday)) {
          for (var h = 0; h < _.length; h++)
            _[h] = 1 * _[h] || 7;
          _.sort();
        }
        this.date[o] = function(p, v) {
          var g = Math.floor((v.valueOf() - p.valueOf()) / (864e5 * l));
          return g > 0 && p.setDate(p.getDate() + g * l), _ && e.transpose_day_week(p, _, 1, l), p;
        }, this.date[r] = function(p, v) {
          var g = new Date(p.valueOf());
          if (_)
            for (var c = 0; c < v; c++)
              e.transpose_day_week(g, _, 0, l);
          else
            g.setDate(g.getDate() + v * l);
          return g;
        };
      } else
        d[0] != "month" && d[0] != "year" || (this.date[o] = function(p, v, g) {
          var c = Math.ceil((12 * v.getFullYear() + 1 * v.getMonth() + 1 - (12 * p.getFullYear() + 1 * p.getMonth() + 1)) / l - 1);
          return c >= 0 && (p.setDate(1), p.setMonth(p.getMonth() + c * l)), e.date[r](p, 0, g);
        }, this.date[r] = function(p, v, g, c) {
          if (c ? c++ : c = 1, c > 12)
            return null;
          var f = new Date(p.valueOf());
          f.setDate(1), f.setMonth(f.getMonth() + v * l);
          var u = f.getMonth(), y = f.getFullYear();
          f.setDate(g.start_date.getDate()), d[3] && e.date.day_week(f, d[2], d[3]);
          var w = e.config.recurring_overflow_instances;
          return f.getMonth() != u && w != "none" && (f = w === "lastDay" ? new Date(y, u + 1, 0, f.getHours(), f.getMinutes(), f.getSeconds(), f.getMilliseconds()) : e.date[r](new Date(y, u + 1, 0), v || 1, g, c)), f;
        });
    }
  }, e.repeat_date = function(a, o, d, r, l, _) {
    r = r || this._min_date, l = l || this._max_date;
    var h = _ || -1, p = new Date(a.start_date.valueOf()), v = p.getHours(), g = 0;
    for (!a.rec_pattern && a.rec_type && (a.rec_pattern = a.rec_type.split("#")[0]), this.transpose_type(a.rec_pattern), p = e.date["transpose_" + a.rec_pattern](p, r, a); p && (p < a.start_date || e._fix_daylight_saving_date(p, r, a, p, new Date(p.valueOf() + 1e3 * a.event_length)).valueOf() <= r.valueOf() || p.valueOf() + 1e3 * a.event_length <= r.valueOf()); )
      p = this.date["add_" + a.rec_pattern](p, 1, a);
    for (; p && p < l && p < a.end_date && (h < 0 || g < h); ) {
      p.setHours(v);
      var c = e.config.occurrence_timestamp_in_utc ? Date.UTC(p.getFullYear(), p.getMonth(), p.getDate(), p.getHours(), p.getMinutes(), p.getSeconds()) : p.valueOf(), f = this._get_rec_marker(c, a.id);
      if (f)
        d && (f.rec_type != "none" && g++, o.push(f));
      else {
        var u = new Date(p.valueOf() + 1e3 * a.event_length), y = this._copy_event(a);
        if (y.text = a.text, y.start_date = p, y.event_pid = a.id, y.id = a.id + "#" + Math.round(c / 1e3), y.end_date = u, y.end_date = e._fix_daylight_saving_date(y.start_date, y.end_date, a, p, y.end_date), y._timed = this.isOneDayEvent(y), !y._timed && !this._table_view && !this.config.multi_day)
          return;
        o.push(y), d || (this._events[y.id] = y, this._rec_temp.push(y)), g++;
      }
      p = this.date["add_" + a.rec_pattern](p, 1, a);
    }
  }, e._fix_daylight_saving_date = function(a, o, d, r, l) {
    var _ = a.getTimezoneOffset() - o.getTimezoneOffset();
    return _ ? _ > 0 ? new Date(r.valueOf() + 1e3 * d.event_length - 60 * _ * 1e3) : new Date(o.valueOf() - 60 * _ * 1e3) : new Date(l.valueOf());
  }, e.getRecDates = function(a, o) {
    var d = typeof a == "object" ? a : e.getEvent(a), r = [];
    if (o = o || 100, !d.rec_type)
      return [{ start_date: d.start_date, end_date: d.end_date }];
    if (d.rec_type == "none")
      return [];
    e.repeat_date(d, r, !0, d.start_date, d.end_date, o);
    for (var l = [], _ = 0; _ < r.length; _++)
      r[_].rec_type != "none" && l.push({ start_date: r[_].start_date, end_date: r[_].end_date });
    return l;
  }, e.getEvents = function(a, o) {
    var d = [];
    for (var r in this._events) {
      var l = this._events[r];
      if (l && l.start_date < o && l.end_date > a)
        if (l.rec_pattern) {
          if (l.rec_pattern == "none")
            continue;
          var _ = [];
          this.repeat_date(l, _, !0, a, o);
          for (var h = 0; h < _.length; h++)
            !_[h].rec_pattern && _[h].start_date < o && _[h].end_date > a && !this._rec_markers[_[h].id] && d.push(_[h]);
        } else
          this._is_virtual_event(l.id) || d.push(l);
    }
    return d;
  }, e.config.repeat_date = "%m.%d.%Y", e.config.lightbox.sections = [{ name: "description", map_to: "text", type: "textarea", focus: !0 }, { name: "recurring", type: "recurring", map_to: "rec_type", button: "recurring" }, { name: "time", height: 72, type: "time", map_to: "auto" }], e._copy_dummy = function(a) {
    var o = new Date(this.start_date), d = new Date(this.end_date);
    this.start_date = o, this.end_date = d, this.event_length = this.event_pid = this.rec_pattern = this.rec_type = null;
  }, e.config.include_end_by = !1, e.config.lightbox_recurring = "ask", e.attachEvent("onClearAll", function() {
    e._rec_markers = {}, e._rec_markers_pull = {}, e._rec_temp = [];
  });
}, serialize: function(e) {
  const i = yt(e);
  e.data_attributes = function() {
    var t = [], n = e._helpers.formatDate, s = i();
    for (var a in s) {
      var o = s[a];
      for (var d in o)
        d.substr(0, 1) != "_" && t.push([d, d == "start_date" || d == "end_date" ? n : null]);
      break;
    }
    return t;
  }, e.toXML = function(t) {
    var n = [], s = this.data_attributes(), a = i();
    for (var o in a) {
      var d = a[o];
      n.push("<event>");
      for (var r = 0; r < s.length; r++)
        n.push("<" + s[r][0] + "><![CDATA[" + (s[r][1] ? s[r][1](d[s[r][0]]) : d[s[r][0]]) + "]]></" + s[r][0] + ">");
      n.push("</event>");
    }
    return (t || "") + "<data>" + n.join(`
`) + "</data>";
  }, e._serialize_json_value = function(t) {
    return t === null || typeof t == "boolean" ? t = "" + t : (t || t === 0 || (t = ""), t = '"' + t.toString().replace(/\n/g, "").replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"'), t;
  }, e.toJSON = function() {
    return JSON.stringify(this.serialize());
  }, e.toICal = function(t) {
    var n = e.date.date_to_str("%Y%m%dT%H%i%s"), s = e.date.date_to_str("%Y%m%d"), a = [], o = i();
    for (var d in o) {
      var r = o[d];
      a.push("BEGIN:VEVENT"), r._timed && (r.start_date.getHours() || r.start_date.getMinutes()) ? a.push("DTSTART:" + n(r.start_date)) : a.push("DTSTART:" + s(r.start_date)), r._timed && (r.end_date.getHours() || r.end_date.getMinutes()) ? a.push("DTEND:" + n(r.end_date)) : a.push("DTEND:" + s(r.end_date)), a.push("SUMMARY:" + r.text), a.push("END:VEVENT");
    }
    return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//dhtmlXScheduler//NONSGML v2.2//EN
DESCRIPTION:` + (t || "") + `
` + a.join(`
`) + `
END:VCALENDAR`;
  };
}, timeline: function(e) {
  ce("Timeline", e.assert);
}, tooltip: function(e) {
  e.config.tooltip_timeout = 30, e.config.tooltip_offset_y = 20, e.config.tooltip_offset_x = 10, e.config.tooltip_hide_timeout = 30;
  const i = new Ga(e);
  e.ext.tooltips = i, e.attachEvent("onSchedulerReady", function() {
    i.tooltipFor({ selector: "[" + e.config.event_attribute + "]", html: (t) => {
      if (e._mobile && !e.config.touch_tooltip)
        return;
      const n = e._locate_event(t.target);
      if (e.getEvent(n)) {
        const s = e.getEvent(n);
        return e.templates.tooltip_text(s.start_date, s.end_date, s);
      }
      return null;
    }, global: !1 });
  }), e.attachEvent("onDestroy", function() {
    i.destructor();
  }), e.attachEvent("onLightbox", function() {
    i.hideTooltip();
  }), e.attachEvent("onBeforeDrag", function() {
    return e._mobile && e.config.touch_tooltip || i.hideTooltip(), !0;
  }), e.attachEvent("onEventDeleted", function() {
    return i.hideTooltip(), !0;
  });
}, treetimeline: function(e) {
  ce("Tree Timeline", e.assert);
}, units: function(e) {
  ce("Units", e.assert);
}, url: function(e) {
  e._get_url_nav = function() {
    return function() {
      const a = /* @__PURE__ */ Object.create(null), o = (document.location.hash || "").replace("#", "");
      if (!o)
        return a;
      const d = o.split(","), r = ["__proto__", "constructor", "prototype"];
      for (let l = 0; l < d.length; l++) {
        const _ = d[l].split("=");
        _.length !== 2 || r.includes(_[0]) || (a[_[0]] = _[1]);
      }
      return a;
    }();
  };
  const i = e.date.date_to_str("%Y-%m-%d"), t = e._getInitialState;
  function n(a) {
    const o = e._date || e.getState().date, d = e.getState().mode, r = ["date=" + i(o), "mode=" + d];
    a && r.push("event=" + a), document.location.hash = "#" + r.join(",");
  }
  e._getInitialState = function(a) {
    const o = t.call(this, a), d = e._get_url_nav ? e._get_url_nav() : null;
    if (!d)
      return o;
    const r = { date: o.date, mode: o.mode };
    if (d.date) {
      const l = e.date.str_to_date("%Y-%m-%d");
      try {
        const _ = l(d.date);
        isNaN(+_) || (r.date = _);
      } catch {
      }
    }
    if (d.mode)
      try {
        this.isViewExists(d.mode) && (r.mode = d.mode);
      } catch {
      }
    return r;
  };
  let s = null;
  e.attachEvent("onSchedulerReady", function() {
    const a = e._get_url_nav();
    return a.event && (s = a.event, function(o) {
      if (!o)
        return;
      const d = function() {
        if (!e.$destroyed)
          return !!e.getEvent(o) && (e.showEvent(o), !0);
      };
      if (d())
        return;
      const r = e.attachEvent("onParse", function() {
        return d(), e.detachEvent(r), !0;
      });
    }(a.event)), n(s), !0;
  }), e.attachEvent("onAfterEventDisplay", function() {
    return s = null, n(null), !0;
  }), e.attachEvent("onViewChange", function() {
    return n(s), !0;
  });
}, week_agenda: function(e) {
  ce("Week Agenda", e.assert);
}, wp: function(e) {
  e.attachEvent("onLightBox", function() {
    if (this._cover)
      try {
        this._cover.style.height = this.expanded ? "100%" : (document.body.parentNode || document.body).scrollHeight + "px";
      } catch {
      }
  }), e.form_blocks.select.set_value = function(i, t, n) {
    t !== void 0 && t !== "" || (t = (i.firstChild.options[0] || {}).value), i.firstChild.value = t || "";
  };
}, year_view: function(e) {
  e.templates.year_date = function(d) {
    return e.date.date_to_str(e.locale.labels.year_tab + " %Y")(d);
  }, e.templates.year_month = e.date.date_to_str("%F"), e.templates.year_scale_date = e.date.date_to_str("%D"), e.templates.year_tooltip = function(d, r, l) {
    return l.text;
  };
  const i = function() {
    return e._mode == "year";
  }, t = function(d) {
    var r = e.$domHelpers.closest(d, "[data-cell-date]");
    return r && r.hasAttribute("data-cell-date") ? e.templates.parse_date(r.getAttribute("data-cell-date")) : null;
  };
  e.dblclick_dhx_year_grid = function(d) {
    if (i()) {
      const r = d.target;
      if (e.$domHelpers.closest(r, ".dhx_before") || e.$domHelpers.closest(r, ".dhx_after"))
        return !1;
      const l = t(r);
      if (l) {
        const _ = l, h = this.date.add(_, 1, "day");
        !this.config.readonly && this.config.dblclick_create && this.addEventNow(_.valueOf(), h.valueOf(), d);
      }
    }
  }, e.attachEvent("onEventIdChange", function() {
    i() && this.year_view(!0);
  });
  var n = e.render_data;
  e.render_data = function(d) {
    if (!i())
      return n.apply(this, arguments);
    for (var r = 0; r < d.length; r++)
      this._year_render_event(d[r]);
  };
  var s = e.clear_view;
  e.clear_view = function() {
    if (!i())
      return s.apply(this, arguments);
    var d = e._year_marked_cells;
    for (var r in d)
      d.hasOwnProperty(r) && d[r].classList.remove("dhx_year_event", "dhx_cal_datepicker_event");
    e._year_marked_cells = {};
  }, e._hideToolTip = function() {
    this._tooltip && (this._tooltip.style.display = "none", this._tooltip.date = new Date(9999, 1, 1));
  }, e._showToolTip = function(d, r, l, _) {
    if (this._tooltip) {
      if (this._tooltip.date.valueOf() == d.valueOf())
        return;
      this._tooltip.innerHTML = "";
    } else {
      var h = this._tooltip = document.createElement("div");
      h.className = "dhx_year_tooltip", this.config.rtl && (h.className += " dhx_tooltip_rtl"), document.body.appendChild(h), h.addEventListener("click", e._click.dhx_cal_data), h.addEventListener("click", function(y) {
        if (y.target.closest(`[${e.config.event_attribute}]`)) {
          const w = y.target.closest(`[${e.config.event_attribute}]`).getAttribute(e.config.event_attribute);
          e.showLightbox(w);
        }
      });
    }
    for (var p = this.getEvents(d, this.date.add(d, 1, "day")), v = "", g = 0; g < p.length; g++) {
      var c = p[g];
      if (this.filter_event(c.id, c)) {
        var f = c.color ? "--dhx-scheduler-event-background:" + c.color + ";" : "", u = c.textColor ? "--dhx-scheduler-event-color:" + c.textColor + ";" : "";
        v += "<div class='dhx_tooltip_line' style='" + f + u + "' event_id='" + p[g].id + "' " + this.config.event_attribute + "='" + p[g].id + "'>", v += "<div class='dhx_tooltip_date' style='" + f + u + "'>" + (p[g]._timed ? this.templates.event_date(p[g].start_date) : "") + "</div>", v += "<div class='dhx_event_icon icon_details'>&nbsp;</div>", v += this.templates.year_tooltip(p[g].start_date, p[g].end_date, p[g]) + "</div>";
      }
    }
    this._tooltip.style.display = "", this._tooltip.style.top = "0px", document.body.offsetWidth - r.left - this._tooltip.offsetWidth < 0 ? this._tooltip.style.left = r.left - this._tooltip.offsetWidth + "px" : this._tooltip.style.left = r.left + _.offsetWidth + "px", this._tooltip.date = d, this._tooltip.innerHTML = v, document.body.offsetHeight - r.top - this._tooltip.offsetHeight < 0 ? this._tooltip.style.top = r.top - this._tooltip.offsetHeight + _.offsetHeight + "px" : this._tooltip.style.top = r.top + "px";
  }, e._year_view_tooltip_handler = function(d) {
    if (i()) {
      var r = d.target || d.srcElement;
      r.tagName.toLowerCase() == "a" && (r = r.parentNode), e._getClassName(r).indexOf("dhx_year_event") != -1 ? e._showToolTip(e.templates.parse_date(r.getAttribute("data-year-date")), e.$domHelpers.getOffset(r), d, r) : e._hideToolTip();
    }
  }, e._init_year_tooltip = function() {
    e._detachDomEvent(e._els.dhx_cal_data[0], "mouseover", e._year_view_tooltip_handler), e.event(e._els.dhx_cal_data[0], "mouseover", e._year_view_tooltip_handler);
  }, e._get_year_cell = function(d) {
    const r = e.date.day_start(d), l = e.templates.format_date(r), _ = this.$root.querySelectorAll(`.dhx_cal_data .dhx_cal_datepicker_date[data-cell-date="${l}"]`);
    for (let h = 0; h < _.length; h++)
      if (!e.$domHelpers.closest(_[h], ".dhx_after, .dhx_before"))
        return _[h];
    return null;
  }, e._year_marked_cells = {}, e._mark_year_date = function(d, r) {
    var l = e.templates.format_date(d), _ = this._get_year_cell(d);
    if (_) {
      var h = this.templates.event_class(r.start_date, r.end_date, r);
      e._year_marked_cells[l] || (_.classList.add("dhx_year_event", "dhx_cal_datepicker_event"), _.setAttribute("data-year-date", l), _.setAttribute("date", l), e._year_marked_cells[l] = _), h && _.classList.add(h);
    }
  }, e._unmark_year_date = function(d) {
    var r = this._get_year_cell(d);
    r && r.classList.remove("dhx_year_event", "dhx_cal_datepicker_event");
  }, e._year_render_event = function(d) {
    var r = d.start_date;
    for (r = r.valueOf() < this._min_date.valueOf() ? this._min_date : this.date.date_part(new Date(r)); r < d.end_date; )
      if (this._mark_year_date(r, d), (r = this.date.add(r, 1, "day")).valueOf() >= this._max_date.valueOf())
        return;
  }, e.year_view = function(d) {
    if (e.set_sizes(), e._table_view = d, !this._load_mode || !this._load())
      if (d) {
        if (e._init_year_tooltip(), e._reset_year_scale(), e._load_mode && e._load())
          return void (e._render_wait = !0);
        e.render_view_data();
      } else
        e._hideToolTip();
  }, e._reset_year_scale = function() {
    var d = this._els.dhx_cal_data[0];
    d.scrollTop = 0, d.innerHTML = "";
    let r = this.date.year_start(new Date(this._date));
    this._min_date = this.date.week_start(new Date(r));
    const l = document.createElement("div");
    l.classList.add("dhx_year_wrapper");
    let _ = r;
    for (let v = 0; v < 12; v++) {
      let g = document.createElement("div");
      g.className = "dhx_year_box", g.setAttribute("date", this._helpers.formatDate(_)), g.setAttribute("data-month-date", this._helpers.formatDate(_)), g.innerHTML = `<div class='dhx_year_month'>${this.templates.year_month(_)}</div>
			<div class='dhx_year_grid'></div>`;
      const c = g.querySelector(".dhx_year_grid"), f = e._createDatePicker(null, { date: _, filterDays: e.ignore_year, minWeeks: 6 });
      f._renderDayGrid(c), f.destructor(), l.appendChild(g), _ = this.date.add(_, 1, "month");
    }
    d.appendChild(l);
    let h = this.date.add(r, 1, "year");
    h.valueOf() != this.date.week_start(new Date(h)).valueOf() && (h = this.date.week_start(new Date(h)), h = this.date.add(h, 1, "week")), this._max_date = h;
    var p = this._getNavDateElement();
    p && (p.innerHTML = this.templates[this._mode + "_date"](r, h, this._mode));
  };
  var a = e.getActionData;
  e.getActionData = function(d) {
    return i() ? { date: t(d.target), section: null } : a.apply(e, arguments);
  };
  var o = e._locate_event;
  e._locate_event = function(d) {
    var r = o.apply(e, arguments);
    if (!i())
      return r;
    if (!r) {
      var l = t(d);
      if (!l)
        return null;
      var _ = e.getEvents(l, e.date.add(l, 1, "day"));
      if (!_.length)
        return null;
      r = _[0].id;
    }
    return r;
  }, e.attachEvent("onDestroy", function() {
    e._hideToolTip();
  });
} }, Re = new class {
  constructor(e) {
    this._seed = 0, this._schedulerPlugins = [], this._bundledExtensions = e, this._extensionsManager = new sa(e);
  }
  plugin(e) {
    this._schedulerPlugins.push(e), le.scheduler && e(le.scheduler);
  }
  getSchedulerInstance(e) {
    for (var i = oa(this._extensionsManager), t = 0; t < this._schedulerPlugins.length; t++)
      this._schedulerPlugins[t](i);
    return i._internal_id = this._seed++, this.$syncFactory && this.$syncFactory(i), e && this._initFromConfig(i, e), i;
  }
  _initFromConfig(e, i) {
    if (i.plugins && e.plugins(i.plugins), i.config && e.mixin(e.config, i.config, !0), i.templates && e.attachEvent("onTemplatesReady", function() {
      e.mixin(e.templates, i.templates, !0);
    }, { once: !0 }), i.events)
      for (const t in i.events)
        e.attachEvent(t, i.events[t]);
    i.locale && e.i18n.setLocale(i.locale), Array.isArray(i.calendars) && i.calendars.forEach(function(t) {
      e.addCalendar(t);
    }), i.container ? e.init(i.container) : e.init(), i.data && (typeof i.data == "string" ? e.load(i.data) : e.parse(i.data));
  }
}(Xa), Ue = Re.getSchedulerInstance(), ut = { plugin: Ue.bind(Re.plugin, Re) };
window.scheduler = Ue, window.Scheduler = ut, window.$dhx || (window.$dhx = {}), window.$dhx.scheduler = Ue, window.$dhx.Scheduler = ut;
export {
  ut as Scheduler,
  Ue as default,
  Ue as scheduler
};
//# sourceMappingURL=dhtmlxscheduler.es.js.map
