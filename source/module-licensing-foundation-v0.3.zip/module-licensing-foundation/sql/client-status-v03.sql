-- Apply after sql/client-schema.sql; client database only.
CREATE TABLE IF NOT EXISTS local_status_state (
 id TINYINT UNSIGNED PRIMARY KEY,
 sequence_no BIGINT UNSIGNED NOT NULL,
 issued_at DATETIME NOT NULL,
 valid_until DATETIME NOT NULL,
 status_json LONGTEXT NOT NULL,
 status_hash BINARY(32) NOT NULL,
 imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS local_revoked_licenses (
 license_code VARCHAR(64) NOT NULL PRIMARY KEY,
 sequence_no BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
