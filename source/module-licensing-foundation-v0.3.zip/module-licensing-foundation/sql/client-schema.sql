-- Import into a subsidiary-side MariaDB database, not the authority database.
CREATE TABLE IF NOT EXISTS local_license_certificates (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 license_code VARCHAR(64) NOT NULL,
 module_code VARCHAR(150) NOT NULL,
 revision_no INT UNSIGNED NOT NULL DEFAULT 1,
 certificate_hash BINARY(32) NOT NULL,
 certificate_json LONGTEXT NOT NULL,
 status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
 imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_cert_hash(certificate_hash),
 UNIQUE KEY uq_license_revision(license_code,revision_no),
 KEY idx_module_status(module_code,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS local_license_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 event_type VARCHAR(32) NOT NULL,
 license_code VARCHAR(64) NOT NULL,
 occurred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
