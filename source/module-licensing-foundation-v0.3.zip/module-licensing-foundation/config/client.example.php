<?php
return [
 'dsn' => 'mysql:host=127.0.0.1;port=3306;dbname=module_licensing_client;charset=utf8mb4',
 'user' => 'licensing_client', 'password' => 'CHANGE_ME',
 'authority_public_key_file' => __DIR__.'/../secrets/authority.public',
 'key_id' => 'demo-2026-01'
];
