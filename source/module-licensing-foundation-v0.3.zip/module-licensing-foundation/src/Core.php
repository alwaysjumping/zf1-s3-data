<?php
/** PHP 7.4; requires ext-sodium and pdo_mysql. */
function array_is_list_compat(array $a): bool {return array_keys($a)===range(0,count($a)-1) || $a===[];}
final class Core {
 public static function b64(string $x): string { return rtrim(strtr(base64_encode($x), '+/', '-_'), '='); }
 public static function unb64(string $x): string {
  if (!preg_match('/^[A-Za-z0-9_-]+$/D', $x) || strlen($x)%4===1) throw new RuntimeException('Invalid base64url');
  $v=base64_decode(strtr($x,'-_','+/').str_repeat('=',(4-strlen($x)%4)%4),true);
  if ($v===false || self::b64($v)!==$x) throw new RuntimeException('Noncanonical base64url');
  return $v;
 }
 public static function json($v): string { return json_encode($v,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR); }
 public static function parse(string $s): array {
  if(strlen($s)>65536) throw new RuntimeException('Input too large');
  $x=json_decode($s,true,512,JSON_THROW_ON_ERROR);
  if(!is_array($x)) throw new RuntimeException('Expected object');
  return $x;
 }
 public static function signLicense(array $payload,string $secret,string $kid): string {
  $encoded=self::b64(self::json($payload));
  $sig=sodium_crypto_sign_detached("S3-LICENSE-V1\n".$kid."\n".$encoded,$secret);
  return self::json(['format'=>'s3-module-license','format_version'=>1,'algorithm'=>'Ed25519','key_id'=>$kid,'payload'=>$encoded,'signature'=>self::b64($sig)]);
 }
 public static function verifyLicense(string $json,string $public,string $kid): array {
  $c=self::parse($json);
  if(($c['format']??null)!=='s3-module-license'||($c['format_version']??null)!==1||($c['algorithm']??null)!=='Ed25519'||($c['key_id']??null)!==$kid) throw new RuntimeException('Unsupported license envelope');
  if(!is_string($c['payload']??null)||!is_string($c['signature']??null)) throw new RuntimeException('Malformed license');
  $sig=self::unb64($c['signature']);
  if(strlen($sig)!==64||!sodium_crypto_sign_verify_detached($sig,"S3-LICENSE-V1\n".$kid."\n".$c['payload'],$public)) throw new RuntimeException('Bad signature');
  return self::parse(self::unb64($c['payload']));
 }

 public static function signStatus(array $payload,string $secret,string $kid): string {
  if(strlen($secret)!==SODIUM_CRYPTO_SIGN_SECRETKEYBYTES)throw new RuntimeException('Invalid authority secret key');
  $encoded=self::b64(self::json($payload));
  $signature=sodium_crypto_sign_detached("S3-STATUS-V1\n".$kid."\n".$encoded,$secret);
  return self::json(['format'=>'s3-license-status','format_version'=>1,'algorithm'=>'Ed25519','key_id'=>$kid,'payload'=>$encoded,'signature'=>self::b64($signature)]);
 }
 public static function verifyStatus(string $json,string $public,string $kid): array {
  if(strlen($public)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES)throw new RuntimeException('Invalid authority public key');
  $c=self::parse($json);
  if(array_keys($c)!==['format','format_version','algorithm','key_id','payload','signature'] || ($c['format']??null)!=='s3-license-status'||($c['format_version']??null)!==1||($c['algorithm']??null)!=='Ed25519'||($c['key_id']??null)!==$kid)throw new RuntimeException('Unsupported status envelope');
  if(!is_string($c['payload']??null)||!is_string($c['signature']??null))throw new RuntimeException('Invalid status encoding');
  $sig=self::unb64($c['signature']);
  if(strlen($sig)!==64||!sodium_crypto_sign_verify_detached($sig,"S3-STATUS-V1\n".$kid."\n".$c['payload'],$public))throw new RuntimeException('Invalid status signature');
  $p=self::parse(self::unb64($c['payload']));
  if(!is_int($p['sequence']??null)||$p['sequence']<1||!is_string($p['issued_at']??null)||!is_string($p['valid_until']??null)||!is_array($p['revoked_license_ids']??null)||!array_is_list_compat($p['revoked_license_ids']))throw new RuntimeException('Invalid status payload');
  $start=self::utcTimestamp($p['issued_at']);$end=self::utcTimestamp($p['valid_until']);
  if($end<=$start||$end<=time()||$start>time()+300)throw new RuntimeException('Status package expired or not yet valid');
  foreach($p['revoked_license_ids'] as $id)if(!is_string($id)||!preg_match('/^[A-Za-z0-9._-]{1,64}$/D',$id))throw new RuntimeException('Invalid revoked license ID');
  if(count($p['revoked_license_ids'])!==count(array_unique($p['revoked_license_ids'])))throw new RuntimeException('Duplicate revoked license ID');
  return $p;
 }
 public static function utcTimestamp(string $value): int {
  if(!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/D',$value))throw new RuntimeException('Expected UTC timestamp');
  $d=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:s\Z',$value,new DateTimeZone('UTC'));
  if(!$d||$d->format('Y-m-d\TH:i:s\Z')!==$value)throw new RuntimeException('Invalid UTC timestamp');
  return $d->getTimestamp();
 }
 public static function requestMessage(array $r): string {
  $keys=['request_id','challenge_id','installation_id','entitlement_id','nonce']; $v=[];
  foreach($keys as $key) { $s=$r[$key]??null; if(!is_string($s)||$s===''||preg_match('/[\r\n]/',$s)) throw new RuntimeException('Invalid request field '.$key); $v[]=$s; }
  return "S3-ACTIVATION-V2\n".implode("\n",$v);
 }
 public static function db(array $c): PDO { return new PDO($c['dsn'],$c['user'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false]); }
 public static function row(PDO $db,string $sql,array $args=[]): ?array { $s=$db->prepare($sql);$s->execute($args);$v=$s->fetch(PDO::FETCH_ASSOC);return $v?:null; }
 public static function exec(PDO $db,string $sql,array $args=[]): void {$s=$db->prepare($sql);$s->execute($args);}
 public static function id(string $prefix): string {return $prefix.'-'.strtoupper(bin2hex(random_bytes(12)));}
}
