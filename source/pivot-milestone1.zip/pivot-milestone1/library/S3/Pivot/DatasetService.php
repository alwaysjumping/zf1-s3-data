<?php
class S3_Pivot_DatasetService
{
    protected $db;
    public function __construct($db){ $this->db=$db; }
    public function getByCode($code) {
        $r=$this->db->fetchRow('SELECT * FROM pivot_datasets WHERE code=? AND is_active=1',array($code));
        if(!$r) throw new S3_Pivot_Exception('DATASET_NOT_FOUND');
        $rows=$this->db->fetchAll('SELECT * FROM pivot_dataset_fields WHERE dataset_id=? AND is_active=1 ORDER BY display_order,field_name',array($r['id']));
        $fields=array();
        foreach($rows as $f){
            $role=strtolower($f['field_role']);
            $x=array('id'=>(int)$f['id'],'code'=>$f['field_code'],'name'=>$f['field_name'],'role'=>$role,'type'=>strtolower($f['data_type']),
                'capabilities'=>array('row'=>(bool)$f['allow_row'],'column'=>(bool)$f['allow_column'],'filter'=>(bool)$f['allow_filter'],'value'=>(bool)$f['allow_value']));
            $x['source']=$role==='dimension'?array('key'=>$f['key_column'],'label'=>$f['label_column']):array('value'=>$f['value_column']);
            $x['aggregations']=array(); $x['dateGroups']=array();
            $fields[$x['code']]=$x;
        }
        foreach($fields as $code=>&$f){
            if($f['role']==='measure'){
                $a=$this->db->fetchAll('SELECT aggregation_code,is_default FROM pivot_field_aggregations WHERE field_id=?',array($f['id']));
                foreach($a as $v){ $agg=strtolower($v['aggregation_code']); $f['aggregations'][]=$agg; if($v['is_default'])$f['defaultAggregation']=$agg; }
            }
            if($f['type']==='date'||$f['type']==='datetime'){
                $g=$this->db->fetchAll('SELECT group_code FROM pivot_field_date_groups WHERE field_id=?',array($f['id']));
                foreach($g as $v)$f['dateGroups'][]=strtolower($v['group_code']);
            }
        } unset($f);
        return array('id'=>(int)$r['id'],'code'=>$r['code'],'name'=>$r['name'],'version'=>(int)$r['version'],
            'source'=>array('type'=>$r['source_type'],'name'=>$r['source_name']),
            'limits'=>array('maxRowDimensions'=>(int)$r['max_row_dimensions'],'maxColumnDimensions'=>(int)$r['max_column_dimensions'],'maxMeasures'=>(int)$r['max_measures'],'maxResultRows'=>(int)$r['max_result_rows'],'maxResultColumns'=>(int)$r['max_result_columns'],'maxResultCells'=>(int)$r['max_result_cells']),
            'fields'=>$fields);
    }
}
