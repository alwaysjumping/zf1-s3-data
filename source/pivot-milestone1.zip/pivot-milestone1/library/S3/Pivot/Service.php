<?php
class S3_Pivot_Service
{
    protected $db,$datasets,$validator,$planner,$builder,$results;
    public function __construct($db){ $this->db=$db; $this->datasets=new S3_Pivot_DatasetService($db); $this->validator=new S3_Pivot_DefinitionValidator(); $this->planner=new S3_Pivot_QueryPlanner(); $this->builder=new S3_Pivot_QueryBuilder(); $this->results=new S3_Pivot_ResultBuilder(); }
    public function getDataset($code){ return $this->datasets->getByCode($code); }
    public function execute(array $definition,array $userContext){
        $ds=$this->datasets->getByCode($definition['dataset']['code']); $definition=$this->validator->validate($definition,$ds);
        // Milestone 1 mandatory scope. Replace with your real authorization/security provider.
        $security=array(array('field'=>'company_id','operator'=>'eq','value'=>(int)$userContext['company_id'],'fieldMeta'=>array('role'=>'dimension','type'=>'integer','source'=>array('key'=>'company_id'))));
        $plan=$this->planner->build($definition,$ds,$security); $q=$this->builder->build($plan); $records=$this->db->fetchAll($q['sql'],$q['params']); return array('meta'=>array('dataset'=>$ds['code'],'datasetVersion'=>$ds['version']),'pivot'=>$this->results->build($plan,$records));
    }
}
