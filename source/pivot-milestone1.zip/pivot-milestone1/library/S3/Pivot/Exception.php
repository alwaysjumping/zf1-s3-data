<?php
class S3_Pivot_Exception extends RuntimeException
{
    protected $errorCode;
    protected $details;
    public function __construct($errorCode, array $details = array(), $message = '') {
        $this->errorCode=$errorCode; $this->details=$details; parent::__construct($message ?: $errorCode);
    }
    public function getErrorCode(){ return $this->errorCode; }
    public function getDetails(){ return $this->details; }
}
