<?php
class S3_Pivot_QueryBuilder
{
    protected function qi($s){ if(!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/',$s)) throw new S3_Pivot_Exception('INVALID_SOURCE_IDENTIFIER'); return '`'.$s.'`'; }
    public function build(array $p){
        $sel=$grp=$ord=$where=$params=array(); $dims=array_merge($p['rowDimensions'],$p['columnDimensions']);
        foreach($dims as $d){ $x=$this->dimension($d); $sel=array_merge($sel,$x['select']); $grp[]=$x['group']; $ord[]=$x['order']; }
        foreach($p['measures'] as $m){ $col=$this->qi($m['fieldMeta']['source']['value']); $a=$m['aggregation']; $fn=array('sum'=>'SUM','count'=>'COUNT','avg'=>'AVG','min'=>'MIN','max'=>'MAX'); if(!isset($fn[$a]))throw new S3_Pivot_Exception('UNSUPPORTED_AGGREGATION'); $sel[]=$fn[$a].'('.$col.') AS '.$m['idAlias']; }
        foreach(array_merge($p['securityFilters'],$p['userFilters']) as $f)$where[]=$this->filter($f,$params);
        $sql='SELECT '.implode(', ',$sel).' FROM '.$this->qi($p['dataset']['source']); if($where)$sql.=' WHERE '.implode(' AND ',$where); $sql.=' GROUP BY '.implode(', ',$grp).' ORDER BY '.implode(', ',$ord); return array('sql'=>$sql,'params'=>$params);
    }
    protected function dimension($d){ $f=$d['fieldMeta']; $id=$d['id']; if(!empty($d['group'])){ $c=$this->qi($f['source']['key']); switch($d['group']){ case 'year':$e='YEAR('.$c.')';$l=$e;break; case 'quarter':$e='QUARTER('.$c.')';$l="CONCAT('Q',QUARTER(".$c.'))';break; case 'month':$e='MONTH('.$c.')';$l='MONTHNAME('.$c.')';break; case 'date':$e='DATE('.$c.')';$l=$e;break; default:throw new S3_Pivot_Exception('DATE_GROUP_NOT_ALLOWED'); } return array('select'=>array($e.' AS '.$id.'_key',$l.' AS '.$id.'_label'),'group'=>$e,'order'=>$e); }
        $k=$this->qi($f['source']['key']); $l=$this->qi($f['source']['label']); return array('select'=>array($k.' AS '.$id.'_key',$l.' AS '.$id.'_label'),'group'=>$k.', '.$l,'order'=>$l);
    }
    protected function filter($f,&$params){ $meta=$f['fieldMeta']; $c=$this->qi($meta['role']==='measure'?$meta['source']['value']:$meta['source']['key']); $op=strtolower($f['operator']);
        if($meta['type']==='date'&&isset($f['group'])&&$f['group']==='year'&&$op==='eq'){ $y=(int)$f['value']; $params[]=$y.'-01-01';$params[]=($y+1).'-01-01'; return '('.$c.' >= ? AND '.$c.' < ?)'; }
        if($op==='eq'){ $params[]=$f['value']; return $c.' = ?'; }
        if($op==='in'){ if(empty($f['values']))throw new S3_Pivot_Exception('FILTER_VALUES_REQUIRED'); $q=array(); foreach($f['values'] as $v){$q[]='?';$params[]=$v;} return $c.' IN ('.implode(',',$q).')'; }
        throw new S3_Pivot_Exception('FILTER_OPERATOR_NOT_ALLOWED');
    }
}
