<?php
class S3_Pivot_ResultBuilder
{
    public function build(array $plan,array $records){
        // Milestone 1: one row dimension (Department), one quarter column, one measure.
        if(count($plan['rowDimensions'])!==1||count($plan['columnDimensions'])!==1||count($plan['measures'])!==1) throw new S3_Pivot_Exception('MILESTONE1_SHAPE_REQUIRED');
        $rows=array(); $quarters=array(1=>'Q1',2=>'Q2',3=>'Q3',4=>'Q4'); $grand=array(1=>0,2=>0,3=>0,4=>0);
        foreach($records as $r){ $rk=(string)$r['d0_key']; if(!isset($rows[$rk]))$rows[$rk]=array('id'=>'r-'.$rk,'label'=>$r['d0_label'],'q'=>array(1=>0,2=>0,3=>0,4=>0)); $q=(int)$r['d1_key']; $v=(float)$r['m0']; $rows[$rk]['q'][$q]+=$v; $grand[$q]+=$v; }
        $outRows=array(); foreach($rows as $row){ $cells=array($row['label']);$total=0;for($q=1;$q<=4;$q++){ $cells[]=$row['q'][$q];$total+=$row['q'][$q]; }$cells[]=$total;$outRows[]=array('id'=>$row['id'],'cells'=>$cells); }
        $gc=array('Grand Total');$gt=0;for($q=1;$q<=4;$q++){ $gc[]=$grand[$q];$gt+=$grand[$q]; }$gc[]=$gt;$outRows[]=array('id'=>'grand-total','cells'=>$gc,'isGrandTotal'=>true);
        return array('columns'=>array(array('id'=>'row_label','label'=>'Department','type'=>'text'),array('id'=>'q1','label'=>'Q1','type'=>'number'),array('id'=>'q2','label'=>'Q2','type'=>'number'),array('id'=>'q3','label'=>'Q3','type'=>'number'),array('id'=>'q4','label'=>'Q4','type'=>'number'),array('id'=>'total','label'=>'Grand Total','type'=>'number')),'rows'=>$outRows);
    }
}
