<?php
class S3_Pivot_QueryPlanner
{
    public function build(array $d,array $ds,array $securityFilters=array()){
        $p=array('dataset'=>array('id'=>$ds['id'],'source'=>$ds['source']['name']),'rowDimensions'=>array(),'columnDimensions'=>array(),'measures'=>array(),'userFilters'=>array(),'securityFilters'=>$securityFilters,'limits'=>$ds['limits']);
        $n=0; foreach($d['rows'] as $level=>$i)$p['rowDimensions'][]=$this->dim('d'.$n++,$level,$i,$ds);
        foreach($d['columns'] as $level=>$i)$p['columnDimensions'][]=$this->dim('d'.$n++,$level,$i,$ds);
        $m=0; foreach($d['values'] as $v){ $v['idAlias']='m'.$m++; $v['fieldMeta']=$ds['fields'][$v['field']]; $p['measures'][]=$v; }
        foreach($d['filters'] as $f){ if(empty($f['field'])||!isset($ds['fields'][$f['field']])||empty($ds['fields'][$f['field']]['capabilities']['filter'])) throw new S3_Pivot_Exception('FILTER_FIELD_NOT_ALLOWED'); $f['fieldMeta']=$ds['fields'][$f['field']]; $p['userFilters'][]=$f; }
        return $p;
    }
    protected function dim($id,$level,$i,$ds){ return array('id'=>$id,'level'=>$level,'field'=>$i['field'],'group'=>isset($i['group'])?$i['group']:null,'fieldMeta'=>$ds['fields'][$i['field']]); }
}
