<?php
class S3_Pivot_DefinitionValidator
{
    public function validate(array $d,array $ds){
        if(empty($d['dataset']['code'])||$d['dataset']['code']!==$ds['code']) throw new S3_Pivot_Exception('INVALID_DATASET');
        $d['rows']=$this->dims(isset($d['rows'])?$d['rows']:array(),$ds,'row');
        $d['columns']=$this->dims(isset($d['columns'])?$d['columns']:array(),$ds,'column');
        $d['values']=$this->values(isset($d['values'])?$d['values']:array(),$ds);
        $d['filters']=isset($d['filters'])?$d['filters']:array();
        if(!$d['values']) throw new S3_Pivot_Exception('VALUE_REQUIRED');
        if(!$d['rows']&&!$d['columns']) throw new S3_Pivot_Exception('DIMENSION_REQUIRED');
        if(count($d['rows'])>$ds['limits']['maxRowDimensions']) throw new S3_Pivot_Exception('TOO_MANY_ROW_DIMENSIONS');
        if(count($d['columns'])>$ds['limits']['maxColumnDimensions']) throw new S3_Pivot_Exception('TOO_MANY_COLUMN_DIMENSIONS');
        if(count($d['values'])>$ds['limits']['maxMeasures']) throw new S3_Pivot_Exception('TOO_MANY_MEASURES');
        return $d;
    }
    protected function dims(array $items,array $ds,$axis){
        $out=array(); foreach($items as $i){ $c=isset($i['field'])?$i['field']:null; if(!$c||!isset($ds['fields'][$c])) throw new S3_Pivot_Exception('FIELD_NOT_FOUND',array('field'=>$c));
            $f=$ds['fields'][$c]; if($f['role']!=='dimension'||empty($f['capabilities'][$axis])) throw new S3_Pivot_Exception('FIELD_NOT_ALLOWED_ON_AXIS',array('field'=>$c,'axis'=>$axis));
            $x=array('field'=>$c); if(!empty($i['group'])){ $g=strtolower($i['group']); if(!in_array($g,$f['dateGroups'],true)) throw new S3_Pivot_Exception('DATE_GROUP_NOT_ALLOWED'); $x['group']=$g; } $out[]=$x; }
        return $out;
    }
    protected function values(array $items,array $ds){
        $out=array(); foreach($items as $v){ $c=isset($v['field'])?$v['field']:null; if(!$c||!isset($ds['fields'][$c])) throw new S3_Pivot_Exception('FIELD_NOT_FOUND'); $f=$ds['fields'][$c]; if(empty($f['capabilities']['value'])) throw new S3_Pivot_Exception('FIELD_NOT_ALLOWED_AS_VALUE');
            $a=strtolower(isset($v['aggregation'])?$v['aggregation']:$f['defaultAggregation']); if(!in_array($a,$f['aggregations'],true)) throw new S3_Pivot_Exception('AGGREGATION_NOT_ALLOWED');
            $out[]=array('id'=>isset($v['id'])?$v['id']:$c.'_'.$a,'field'=>$c,'aggregation'=>$a,'label'=>isset($v['label'])?$v['label']:$f['name']); }
        return $out;
    }
}
