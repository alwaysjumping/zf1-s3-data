# Pivot Milestone 1

Working first milestone for PHP 7.4 + MariaDB + DHTMLX 3.5.

## Supported Pivot
- Rows: Department
- Columns: Order Date grouped by Quarter
- Values: SUM(Sales Amount)
- Filter: Year = 2026
- Mandatory sample security scope: company_id = 1

## Install
1. Run `database/01_schema.sql`.
2. Run `database/02_sales_dataset.sql`.
3. Run `database/03_sample_data.sql`.
4. Copy `library/S3/Pivot/*` into the application's autoloadable library path.
5. Add `Api/PivotController.php` and route `/api/pivot/dataset` and `/api/pivot/execute` using the project's existing API routing convention.
6. Copy JS/CSS resources to the corresponding public folders.
7. Ensure DHTMLX 3.5 is available locally under `/resources/dhtmlx/` and jQuery is already loaded by the application.
8. Open the Pivot page and click Run.

## Expected result
| Department | Q1 | Q2 | Q3 | Q4 | Grand Total |
|---|---:|---:|---:|---:|---:|
| Marketing | 0 | 0 | 20000 | 20000 | 40000 |
| Sales | 28000 | 31000 | 0 | 0 | 59000 |
| Support | 12000 | 15000 | 0 | 0 | 27000 |
| Grand Total | 40000 | 46000 | 20000 | 20000 | 126000 |

## Important V1 limitations
`ResultBuilder` intentionally supports exactly one row dimension, one column dimension, and one measure. The surrounding Dataset/Validator/Planner/QueryBuilder layers are structured for extension. Milestone 2 replaces ResultBuilder with the generic multi-level tree/cell engine.

The sample `company_id=1` security scope in `PivotController` must be replaced by the authenticated user's real server-side company/security context before production use.
