function S3PivotGridAdapter(container){ this.container=container; this.grid=null; }
S3PivotGridAdapter.prototype.render=function(result){ var p=result.pivot, cols=p.columns, i, widths=[], aligns=[], types=[], sorts=[], headers=[]; if(this.grid){try{this.grid.destructor();}catch(e){} this.container.innerHTML='';}
 this.grid=new dhtmlXGridObject(this.container); for(i=0;i<cols.length;i++){headers.push(cols[i].label);widths.push(i===0?'180':'120');aligns.push(i===0?'left':'right');types.push('ro');sorts.push(cols[i].type==='number'?'int':'str');}
 this.grid.setHeader(headers.join(','));this.grid.setInitWidths(widths.join(','));this.grid.setColAlign(aligns.join(','));this.grid.setColTypes(types.join(','));this.grid.setColSorting(sorts.join(','));this.grid.init();
 var rows=[];for(i=0;i<p.rows.length;i++)rows.push({id:p.rows[i].id,data:p.rows[i].cells});this.grid.parse({rows:rows},'json'); };
