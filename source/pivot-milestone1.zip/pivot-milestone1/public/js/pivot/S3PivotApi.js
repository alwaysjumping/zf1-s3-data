function S3PivotApi(baseUrl){ this.baseUrl=baseUrl; }
S3PivotApi.prototype.execute=function(definition){ return jQuery.ajax({url:this.baseUrl+'/execute',type:'POST',contentType:'application/json',dataType:'json',data:JSON.stringify(definition)}); };
