TRUNCATE TABLE rpt_sales;
INSERT INTO rpt_sales(order_date,company_id,department_id,department_name,product_id,product_name,region_code,quantity,sales_amount,profit_amount) VALUES
('2026-01-10',1,10,'Sales',100,'Product A','WEST',10,10000,2200),
('2026-03-15',1,10,'Sales',101,'Product B','NORTH',18,18000,3900),
('2026-04-10',1,10,'Sales',100,'Product A','WEST',20,20000,4500),
('2026-06-20',1,10,'Sales',101,'Product B','NORTH',11,11000,2300),
('2026-07-12',1,20,'Marketing',100,'Product A','WEST',20,20000,5100),
('2026-10-09',1,20,'Marketing',102,'Product C','NORTH',20,20000,4800),
('2026-02-05',1,30,'Support',100,'Product A','WEST',12,12000,2600),
('2026-05-18',1,30,'Support',102,'Product C','NORTH',15,15000,3300),
('2025-12-15',1,10,'Sales',100,'Product A','WEST',99,99000,20000);
