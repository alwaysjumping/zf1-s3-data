CREATE TABLE IF NOT EXISTS rpt_sales (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 order_date DATE NOT NULL,
 company_id BIGINT UNSIGNED NOT NULL,
 department_id BIGINT UNSIGNED NOT NULL,
 department_name VARCHAR(255) NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 product_name VARCHAR(255) NOT NULL,
 region_code VARCHAR(50) NULL,
 quantity DECIMAL(18,2) NOT NULL DEFAULT 0,
 sales_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
 profit_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
 PRIMARY KEY(id),
 KEY idx_company_date(company_id,order_date),
 KEY idx_department_date(department_id,order_date),
 KEY idx_product_date(product_id,order_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO pivot_datasets(code,name,description,source_type,source_name)
SELECT 'SALES','Sales Analysis','Milestone 1 sales Pivot','TABLE','rpt_sales'
WHERE NOT EXISTS (SELECT 1 FROM pivot_datasets WHERE code='SALES');
SET @ds=(SELECT id FROM pivot_datasets WHERE code='SALES');

INSERT IGNORE INTO pivot_dataset_fields(dataset_id,field_code,field_name,field_role,data_type,key_column,label_column,allow_row,allow_column,allow_filter,display_order)
VALUES
(@ds,'department','Department','DIMENSION','STRING','department_id','department_name',1,1,1,10),
(@ds,'product','Product','DIMENSION','STRING','product_id','product_name',1,1,1,20),
(@ds,'order_date','Order Date','DIMENSION','DATE','order_date','order_date',1,1,1,30);
INSERT IGNORE INTO pivot_dataset_fields(dataset_id,field_code,field_name,field_role,data_type,value_column,allow_filter,allow_value,display_order)
VALUES
(@ds,'sales_amount','Sales Amount','MEASURE','DECIMAL','sales_amount',1,1,40),
(@ds,'quantity','Quantity','MEASURE','DECIMAL','quantity',1,1,50),
(@ds,'profit_amount','Profit','MEASURE','DECIMAL','profit_amount',1,1,60);

SET @sales=(SELECT id FROM pivot_dataset_fields WHERE dataset_id=@ds AND field_code='sales_amount');
INSERT IGNORE INTO pivot_field_aggregations VALUES (@sales,'sum',1),(@sales,'avg',0),(@sales,'min',0),(@sales,'max',0);
SET @date=(SELECT id FROM pivot_dataset_fields WHERE dataset_id=@ds AND field_code='order_date');
INSERT IGNORE INTO pivot_field_date_groups VALUES (@date,'year',0),(@date,'quarter',1),(@date,'month',0),(@date,'date',0);
