<?php
class Api_PivotController extends Zend_Controller_Action
{
    protected function service(){ return new S3_Pivot_Service(Zend_Db_Table::getDefaultAdapter()); }
    protected function json($data,$status=200){ $this->getResponse()->setHttpResponseCode($status)->setHeader('Content-Type','application/json; charset=utf-8',true)->setBody(json_encode($data)); }
    public function datasetAction(){ try { $code=$this->_getParam('code','SALES'); $this->json(array('success'=>true,'data'=>$this->service()->getDataset($code))); } catch(Exception $e){ $this->error($e); } }
    public function executeAction(){ try { $body=json_decode($this->getRequest()->getRawBody(),true); if(!is_array($body)) throw new S3_Pivot_Exception('INVALID_JSON'); $userContext=array('company_id'=>1); // Replace with authenticated user context.
            $this->json(array('success'=>true,'data'=>$this->service()->execute($body,$userContext))); } catch(Exception $e){ $this->error($e); } }
    protected function error(Exception $e){ $code=$e instanceof S3_Pivot_Exception?$e->getErrorCode():'INTERNAL_ERROR'; $details=$e instanceof S3_Pivot_Exception?$e->getDetails():array(); $this->json(array('success'=>false,'error'=>array('code'=>$code,'message'=>$code,'details'=>$details)),400); }
}
