# ZF1 Product Packaging Script — Requirements v1.3

**Status:** Revised specification based on `script_requirement.md`, `product_uppererp.json`, and the example `install.json` / `install.ini` files in `zf1-s3-product.zip`, together with the three confirmed decisions (A–C).  
**Target:** Windows PowerShell 5.1, WinRAR ZIP output.

## 1. Purpose and scope

Build a deployable product ZIP by copying declared product files, resolving the latest required module ZIP packages, generating installation INI files, and archiving the prepared product directory. This **product packaging** workflow is separate from the module-building workflow.

## 2. Prerequisites

- Run from the workspace directory.
- Windows PowerShell **5.1**; avoid PowerShell 7-only syntax and APIs.
- WinRAR must be installed, accessible, and capable of creating and testing **ZIP**, not RAR, archives.
- Git must be installed and discoverable before processing, as specified by the uploaded requirement, even though no Git publishing step is currently defined for this product script.
- On missing prerequisites, print an actionable error and exit nonzero.
- Do not persist SMB passwords in plaintext. The uploaded source includes this constraint but does not specify a product SMB upload workflow; no SMB upload is implied by this revision.

## 3. Product configuration discovery

1. Find files matching `product_*.json` in the workspace.
2. If none exist, fail with a clear error.
3. Display the candidates and prompt for a selection (auto-selection for one candidate is **not specified** in the source and remains optional).
4. Parse the selected file, validate required fields, and preserve the source file unchanged.

Expected top-level sections from the sample: `product` (object), `source` (array), `module_config` (array).

### 3.1 Product metadata

Read `product.product_key`, `product.product_version`, `product.php_version`, and `product.zipfile_path`. The sample also contains `name`, `product_date`, `company`, `phone_number`, and `package`; retain them in the original JSON. The archive name is:

`<product_key>(<product_version>)_<php_version>.zip`

Sample: `Uppererp(2.0)_php7.4.zip`.

Validate that the filename components cannot escape the output directory or introduce invalid Windows filename characters.

## 4. Resolve module packages from installation JSON

The uploaded `install.json` uses `modules` as a **JSON object keyed by module identifier** (e.g. `chat`, `email`), not an array. Each module object may contain:

- `name`
- `module_key`
- `module_src_dir`
- `module_des_dir`
- `icon`

For every module:

1. Validate its `module_key`, source directory, and destination directory.
2. In `module_src_dir`, find ZIP filenames matching the **complete** module key followed by a parenthesized version: `<module_key>(<version>).zip`. Do not match other module names sharing a prefix.
3. Parse and compare dotted numeric version components numerically, not lexicographically (e.g. `2.4.10` is newer than `2.4.7`). If versions are not numeric dotted components, fail clearly unless a future version scheme is defined.
4. Select the highest valid version. Missing matches are fatal.
5. Copy the selected ZIP to `module_des_dir`, overwriting an existing file with the same name if needed.
6. Verify the copied ZIP matches the source, preferably using SHA-256, and test ZIP integrity with WinRAR.
7. **Confirmed decision B:** only after successful copy and verification, remove older ZIP files in `module_des_dir` that match the **same exact module key**. Do not delete ZIPs for other modules.
8. Record the selected ZIP filename for generation of the installation INI.

If copy or verification fails, do **not** delete pre-existing module packages. If cleanup fails, report a build failure; do not silently continue.

**Processing order:** Module resolution and verification must finish before the generated INI references the selected ZIP filenames.

## 5. Generate INI files (`module_config`)

Each `module_config` entry contains `src` (an installation JSON file) and `des` (the output INI file path).

For each entry:

1. Parse the `src` JSON, including its `modules` object.
2. Resolve and verify its module ZIP packages according to Section 4.
3. Convert the installation JSON to INI, using the **specific mapping demonstrated by the uploaded sample**, rather than generic recursive flattening for the `modules` object. Module child sections are dynamic: entries may be added or removed without script changes. Each generated `module` value must be the basename of the highest-version package selected for that module.
4. Write the generated INI to `des`, creating parent directories and overwriting an existing INI.
5. Verify the INI was written and contains the expected sections and module filenames.
6. If an `install.json` exists in the **destination directory**, remove it **only after** the corresponding `install.ini` is successfully written and verified. Never delete the source JSON.
7. Record each generated INI path and each destination `install.json` removal path as **protected output paths** for the source-copy phase (Section 6).

### 5.1 Framework mapping

For the example `framework` object, generate `[framework]` and emit its scalar properties as INI keys, preserving values.

### 5.2 Modules mapping

For each property of `modules` (e.g. `email`), generate a section named for the property (`[email]`), with:

- `name` from the module entry;
- `module` containing the **selected ZIP basename**, such as `module_email(2.4.10).zip`;
- `icon` from the module entry, if present;
- **all additional scalar properties** of the module entry, retaining their original key names and values unless they are reserved packaging properties.

Do **not** write `module_key`, `module_src_dir`, or `module_des_dir` into the generated module section. These are packaging-only properties. The generated `module` property must always be derived from the selected ZIP basename, not copied from a stale input value. If the input also defines `module`, replace its value with the selected ZIP basename. Additional scalar values include strings, numbers, and booleans; reject unsupported nested objects/arrays in module entries with a clear error rather than silently omitting them.

Example:

```ini
[email]
name = "Email"
module = "module_email(2.4.10).zip"
icon = "abbrowser.png"
```

Quote and escape string values so embedded quotes, backslashes, and line breaks cannot corrupt the INI. Unknown **scalar properties within module entries** follow the generic preservation rule above. For additional top-level installation JSON sections or non-scalar module properties, no conversion mapping has yet been agreed; fail with a clear message rather than silently dropping data.

### 5.3 Multiple installation configurations

The sample product JSON lists `media/modules/accessories/install.json`, `media/modules/base/install.json`, and `media/modules/apps/install.json` as separate inputs. Process each independently; do not assume that only the workspace-root `install.json` exists.

## 6. Copy product sources (`source`)

Each `source` entry contains `src` and `des`, representing a source file/directory and destination file/directory.

- Copy the declared file or directory, preserving its internal structure when copying directories.
- **Confirmed decision A:** overwrite existing destination files automatically, without asking.
- Create required destination directories.
- On a missing source, unreadable file, or failed copy, stop the build with a nonzero exit code.
- Record copied and overwritten files in the build log.
- Resolve paths carefully; do not allow unsafe relative-path traversal.
- **Generated configuration protection:** Before copying, expand all source file/directory mappings to their effective destination file paths and compare them with the protected output paths recorded in Section 5. Reject a source mapping that would overwrite a generated INI or reintroduce a removed destination `install.json`; do not silently skip or overwrite the protected file. This includes conflicts arising from recursive directory copies.
- Copy source data only after this conflict check succeeds. Keep the specified order: module resolution, INI generation, product source copying, then final ZIP creation.
- If a source copy fails after earlier changes, stop and log the partial changes; full rollback remains outside the current scope.

The uploaded sample uses Windows absolute paths. A source-directory-to-destination-directory copy must have an unambiguous rule: copy **contents of `src` into `des`**, not an additional directory level.

## 7. Build final product ZIP

1. Use `product.zipfile_path` as the product staging root and final ZIP destination.
2. Before modifying destinations, validate that every `module_config.des` and every `module_des_dir` used for product contents is inside `product.zipfile_path` (after resolving canonical paths and checking path boundaries). Reject any outside destination with a clear error; do not merely warn. After all copy, module, and INI steps succeed, enumerate the staging root's files and directories.
3. **Confirmed decision C:** include everything under `zipfile_path` **except existing product ZIP files and temporary build files**. Include module ZIP files as ordinary archive entries.
4. Create the product ZIP in a temporary location **outside** the staging root, so the archive cannot include itself.
5. Use ZIP format and preserve relative paths from the staging root.
6. Test archive integrity and verify the expected entries (including generated INI files and selected module ZIPs).
7. Move the verified archive into `zipfile_path` under the filename in Section 3.1; overwrite an existing product ZIP of that name only after the replacement has been successfully built and verified.
8. Fail on any archive or publish error.

**Exclusion scope:** Existing **product** ZIP files must be excluded, but module ZIPs selected in Section 4 must remain included. The precise identification of other historical product ZIP names and temporary file patterns should be configurable or explicitly documented; do not use a blanket `*.zip` exclusion.

## 8. Logging, validation, and failure safety

- Record start/end time, selected product config, source copies/overwrites, selected module versions, hash/integrity verification, deletions, generated INI files, ZIP entries, and final output path.
- Exit nonzero on validation, file-copy, module-resolution, INI-generation, cleanup, or archive errors.
- Never delete an existing module package before a verified replacement is in place.
- Never delete destination `install.json` until the generated `install.ini` is verified.
- Do not modify source JSON files.
- Avoid putting the temporary archive under the directory being archived.
- Avoid accidental deletion of unrelated ZIP files.
- Preflight destination containment and source-copy conflicts before making destructive changes wherever possible.

## 9. Acceptance tests

| Scenario | Expected result |
|---|---|
| Multiple `product_*.json` | Prompt for selection |
| Source destination already exists | Overwrite automatically |
| Missing source file | Stop with error |
| Module versions `2.4.7`, `2.4.10` | Select `2.4.10` |
| `module_email` and `module_emailplus` | Exact-key matching; no cross-deletion |
| Selected module copy fails | Keep existing module ZIPs |
| Selected module ZIP fails integrity/hash | Keep existing module ZIPs |
| Replacement succeeds | Remove outdated ZIPs of same exact module key |
| Generated `install.ini` succeeds | Remove destination `install.json`, if present |
| INI generation fails | Keep destination `install.json` |
| Multiple `module_config` entries | Generate each corresponding INI |
| Existing product ZIP under staging root | Exclude it from new archive |
| Required module ZIPs under staging root | Include them in new archive |
| Temporary files under staging root | Exclude them |
| Product archive creation fails | Do not overwrite previous final product ZIP |
| Final ZIP succeeds | Verify integrity and required contents |
| Source copy would overwrite generated INI | Fail before source copying; retain generated INI |
| Source copy would reintroduce removed destination `install.json` | Fail before source copying |
| New scalar property added to module entry | Preserve in generated INI |
| New module section added/removed | INI sections follow current `modules` object |
| Module destination or generated INI outside product root | Reject build with clear path error |

## 10. Items not defined by the supplied requirements

These are **not** silently assumed to be settled:

1. Whether old product ZIPs are retained after the new product ZIP is published (they are excluded from its contents regardless).
2. How to map additional nonstandard top-level installation JSON sections or non-scalar module properties to INI (additional scalar module properties are now covered by Section 5.2).
3. Whether a failure after some successful source overwrites requires restoring earlier destination files (the current requirement specifies stopping, not full transaction rollback).
4. Exact exclusion patterns for temporary build files and unrelated historical product ZIP filenames.
5. Whether source `install.json` files copied into staging outside the `module_config` destination directories should also be removed; the specified deletion applies only to the destination directory of each generated INI.

## 11. Sample-data consistency checks

The uploaded `product_uppererp.json` example uses `c:/des/` for `product.zipfile_path`, while its `module_config.des` values use `d:/des/...`. These may be illustrative placeholders, but **the script must not assume both are part of the same product tree**. Under v1.3, generated INI destinations and module package destinations must be inside the selected staging root; otherwise fail before modifying files. Adjust the example paths accordingly.

The uploaded root `install.ini` contains illustrative module ZIP versions. The generated INI must use the versions **actually selected at build time**, not copy the sample values.

---

**Revision history**
- **v1.3:** Protected generated INI and removed destination installation JSON paths against later source copies; preserved future scalar module properties; required INI and module ZIP destinations to remain inside the product staging root.
- **v1.2:** Moved source copying to Section 6, immediately before final product ZIP creation, and renumbered intervening sections and references.
- **v1.1:** Formalized source overwrite, verified module replacement before cleanup, and product archive exclusions; clarified `modules` object structure and sample-driven INI mapping.
