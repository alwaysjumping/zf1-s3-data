# Product packaging

`Create-ProductZip.ps1` implements `script_requirement_product_v1_3.md`.
Run from the workspace using Windows PowerShell 5.1, with Git and WinRAR installed:

```powershell
.\Create-ProductZip.ps1
# Or select a specific configuration explicitly:
.\Create-ProductZip.ps1 -ConfigPath .\product_uppererp.json
```

A single matching `product_*.json` is selected automatically. Multiple matches
are listed for interactive selection; no matches cause a clear error.

Optional parameters: `-Workspace`, `-WinRarPath`, `-LogPath`,
`-ProductZipPatterns`, and `-TemporaryPatterns`.
Relative configuration paths resolve against `Workspace`. Directory source
mappings copy their contents directly into the destination. For a file source,
an existing destination directory or a destination ending in a slash receives
the original filename; otherwise the destination is treated as the output file.
Source-copy destinations must be inside `product.zipfile_path`. Generated INIs
and module ZIPs may be prepared outside it when a declared source mapping copies
them into staging. Newly generated files and directories are included automatically.
External outputs without a staging source mapping are rejected. Parent traversal
and reparse points are rejected. Input JSON files are preserved.

For example, generate INIs and modules under
`E:/zz_production_test/module_des/accessories/`, then copy that directory to
`E:/zz_production_test/des/uppererp2.0.1_php7.4/media/modules/accessories/`
using `source`. This overrides v1.3's staging-only rule for `module_config.des`
and `module_des_dir`, as requested. Installation JSON source paths must exist.
Recursive source mappings containing a protected `install.ini` or destination
`install.json` are rejected before product files are changed.

Default product archive exclusion: `*(*)_*.zip`, at any depth, plus the exact
current output filename. This identifies the documented product naming scheme;
ordinary module archives such as `module_email(2.4.10).zip` remain included.
Historical product archives remain on disk. For other historical naming schemes,
supply additional patterns, for example:

```powershell
.\Create-ProductZip.ps1 -ProductZipPatterns '*(*)_*.zip','legacy-product-*.zip'
```

Default temporary exclusions: `*.tmp`, `*.temp`, `~*`, `.product-build-*`.
These apply to files and directory components. Override them if necessary.
Required INIs and module packages cannot be excluded. Logs default to uniquely
named files in the workspace and must remain outside the staging root.

Module copies are checked with SHA-256 and WinRAR before atomic replacement
and removal of older versions for that exact key. INIs escape backslashes,
quotes, carriage returns, line feeds, and tabs using backslash escapes.
Strings are quoted; numbers and booleans are unquoted. Unsupported sections,
null values, nested module properties, and nonnumeric module versions fail.

Exception: `module_key` equal to `module_framework` uses the exact filename
`module_framework.zip`, without numeric version selection or older-version
cleanup. Its generated INI value is `module = "module_framework.zip"`.
Hash/integrity checks, overwrite handling, and ZIP inclusion still apply.

The final ZIP is built from an approved snapshot outside staging, tested with
WinRAR, and checked against every expected file's SHA-256 before publication.
The previous final product ZIP is replaced only after the new archive is verified.
Failures return exit code 1 and log partial changes; full rollback is not provided.
Snapshotting requires temporary disk space for the included files and archive.
Temporary snapshot copies and cleanup use extended Windows paths to support
deep trees that exceed 260 characters under Windows PowerShell 5.1. This requires
a .NET Framework version supporting modern long-path handling (4.6.2 or later).

External output handling was verified using Windows PowerShell 5.1 and WinRAR, including future directories, repeat builds, external cleanup, trailing-slash paths, and generated INI/module archive entries.
