#Requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Workspace = (Get-Location).Path,
    [string]$ConfigPath,
    [string]$WinRarPath,
    [string[]]$ProductZipPatterns = @('*(*)_*.zip'),
    [string[]]$TemporaryPatterns = @('*.tmp', '*.temp', '~*', '.product-build-*'),
    [string]$LogPath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 uses .NET Framework. Enable its modern path handling
# before filesystem work; explicit extended paths avoid the MAX_PATH limit.
[AppContext]::SetSwitch('Switch.System.IO.UseLegacyPathHandling', $false)
[AppContext]::SetSwitch('Switch.System.IO.BlockLongPaths', $false)
$script:BuildTemp = $null
$script:Log = $null

function Log([string]$Message) {
    $line = '{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Write-Host $line
    if ($script:Log) { Add-Content -LiteralPath $script:Log -Value $line -Encoding UTF8 }
}
function Required($Object, [string]$Name) {
    $p = $Object.PSObject.Properties[$Name]
    if ($null -eq $p -or $null -eq $p.Value -or [string]::IsNullOrWhiteSpace([string]$p.Value)) {
        throw "Missing required property: $Name"
    }
    return $p.Value
}
function ObjectCheck($Value, [string]$Label) {
    if ($Value -isnot [pscustomobject]) { throw "$Label must be a JSON object." }
}
function PathFull([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { throw 'Empty path.' }
    if ($Value -match '(^|[\\/])\.\.([\\/]|$)') { throw "Path traversal is forbidden: $Value" }
    if (-not [IO.Path]::IsPathRooted($Value)) { $Value = Join-Path $script:Workspace $Value }
    $result = [IO.Path]::GetFullPath($Value)
    # Reject junctions/symlinks along both existing and future destination paths.
    $cursor = $result
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse point is forbidden: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor.TrimEnd('\','/'))
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
    return $result
}
function Inside([string]$Path, [string]$Root) {
    $r = $Root.TrimEnd('\','/')
    return $Path.Equals($r, [StringComparison]::OrdinalIgnoreCase) -or $Path.StartsWith($r + '\', [StringComparison]::OrdinalIgnoreCase)
}
function Destination([string]$Value) {
    $p = PathFull $Value
    if (-not (Inside $p $script:Stage)) { throw "Destination outside product staging root: $p" }
    return $p
}
function FilePart([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value) -or $Value.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or
        $Value -match '[\x00-\x1f]' -or $Value -match '[. ]$' -or $Value -in @('.', '..')) { throw "Invalid filename component: $Value" }
    return $Value
}
function IniKey([string]$Value) {
    if ($Value -notmatch '^[A-Za-z0-9_.-]+$') { throw "Unsupported INI key/section: $Value" }
    return $Value
}
function IniValue($Value) {
    if ($Value -is [string]) {
        return '"' + $Value.Replace('\','\\').Replace('"','\"').Replace("`r",'\r').Replace("`n",'\n').Replace("`t",'\t') + '"'
    }
    if ($Value -is [bool]) { return $Value.ToString().ToLowerInvariant() }
    if ($Value -is [ValueType] -and $Value -isnot [datetime]) { return [Convert]::ToString($Value, [Globalization.CultureInfo]::InvariantCulture) }
    throw 'Unsupported null, object or array INI value.'
}
function ReadJson([string]$Path) {
    $value = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    ObjectCheck $value $Path
    return $value
}
function CompareVersion([string]$A, [string]$B) {
    $aa = $A.Split('.'); $bb = $B.Split('.')
    for ($i=0; $i -lt [Math]::Max($aa.Length,$bb.Length); $i++) {
        $x = [System.Numerics.BigInteger]::Zero; $y = [System.Numerics.BigInteger]::Zero
        if ($i -lt $aa.Length) { $x = [System.Numerics.BigInteger]::Parse($aa[$i]) }
        if ($i -lt $bb.Length) { $y = [System.Numerics.BigInteger]::Parse($bb[$i]) }
        if ($x -gt $y) { return 1 }; if ($x -lt $y) { return -1 }
    }
    return 0
}
function Rar([string[]]$Arguments) {
    & $script:RarExe @Arguments | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "WinRAR failed (exit $LASTEXITCODE): $($Arguments -join ' ')" }
}
function ZipCheck([string]$Path) {
    $z = [IO.Compression.ZipFile]::OpenRead($Path)
    $z.Dispose()
    Rar @('t','-idq','-y',$Path)
    Log "ZIP integrity verified: $Path"
}
function FilesUnder([string]$Directory) {
    foreach ($item in Get-ChildItem -LiteralPath $Directory -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse point is forbidden: $($item.FullName)" }
        if ($item.PSIsContainer) { FilesUnder $item.FullName } else { $item }
    }
}
function LongPath([string]$Path) {
    if ($Path.StartsWith('\\?\')) { return $Path }
    if ($Path.StartsWith('\\')) { return '\\?\UNC\' + $Path.Substring(2) }
    return '\\?\' + [IO.Path]::GetFullPath($Path)
}
function MakeParent([string]$Path) { [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName((LongPath $Path))) | Out-Null }
function CopyFile([string]$Source, [string]$Destination) {
    MakeParent $Destination
    [IO.File]::Copy((LongPath $Source), (LongPath $Destination), $true)
}
function PublishFile([string]$Source, [string]$Destination) {
    MakeParent $Destination
    $pending = Join-Path ([IO.Path]::GetDirectoryName($Destination)) ('.product-build-' + [guid]::NewGuid().ToString('N') + '.zip')
    $backup = $pending + '.backup'
    try {
        Copy-Item -LiteralPath $Source -Destination $pending
        if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $pending -Algorithm SHA256).Hash) { throw "Publish copy hash mismatch: $Destination" }
        ZipCheck $pending
        if (Test-Path -LiteralPath $Destination) { [IO.File]::Replace($pending,$Destination,$backup) } else { [IO.File]::Move($pending,$Destination) }
    } finally {
        foreach ($tempFile in @($pending,$backup)) { if (Test-Path -LiteralPath $tempFile) { Remove-Item -LiteralPath $tempFile -Force } }
    }
}
function Excluded([string]$Relative, [bool]$Directory) {
    foreach ($part in ($Relative -split '[\\/]')) {
        foreach ($pattern in $TemporaryPatterns) { if ($part -like $pattern) { return $true } }
    }
    if (-not $Directory) {
        foreach ($pattern in $ProductZipPatterns) { if ([IO.Path]::GetFileName($Relative) -like $pattern) { return $true } }
        if ([IO.Path]::GetFileName($Relative) -ieq $script:ArchiveName) { return $true }
    }
    return $false
}

try {
    Add-Type -AssemblyName System.Numerics
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $script:Workspace = [IO.Path]::GetFullPath($Workspace)
    if (-not (Test-Path -LiteralPath $script:Workspace -PathType Container)) { throw "Workspace missing: $Workspace" }
    if (-not (Get-Command git.exe -ErrorAction SilentlyContinue)) { throw 'Git is required. Install Git and add it to PATH.' }
    if ($WinRarPath) { $script:RarExe = PathFull $WinRarPath } else {
        $command = Get-Command WinRAR.exe -ErrorAction SilentlyContinue
        if ($command) { $script:RarExe = $command.Source } else {
            $script:RarExe = @("$env:ProgramFiles\WinRAR\WinRAR.exe", "${env:ProgramFiles(x86)}\WinRAR\WinRAR.exe") |
                Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
        }
    }
    if (-not $script:RarExe -or -not (Test-Path -LiteralPath $script:RarExe -PathType Leaf)) { throw 'WinRAR is required. Install it or supply -WinRarPath.' }
    if (-not $ConfigPath) {
        $candidates = @(Get-ChildItem -LiteralPath $script:Workspace -Filter 'product_*.json' -File | Sort-Object Name)
        if ($candidates.Count -eq 0) { throw 'No product_*.json configuration found.' }
        if ($candidates.Count -eq 1) {
            $ConfigPath = $candidates[0].FullName
            Write-Host "Automatically selected configuration: $($candidates[0].Name)"
        } else {
            for ($i=0; $i -lt $candidates.Count; $i++) { Write-Host ('{0}: {1}' -f ($i+1), $candidates[$i].Name) }
            $choice = 0
            if (-not [int]::TryParse((Read-Host 'Select product number'), [ref]$choice) -or $choice -lt 1 -or $choice -gt $candidates.Count) { throw 'Invalid product selection.' }
            $ConfigPath = $candidates[$choice-1].FullName
        }
    }
    $configFile = PathFull $ConfigPath
    $config = ReadJson $configFile
    $product = Required $config 'product'; ObjectCheck $product 'product'
    foreach ($section in @('source','module_config')) {
        if ($null -eq $config.PSObject.Properties[$section] -or $config.$section -isnot [array]) { throw "$section must be a JSON array." }
    }
    $key = FilePart (Required $product 'product_key')
    $version = FilePart (Required $product 'product_version')
    $php = FilePart (Required $product 'php_version')
    $script:ArchiveName = "$key($version)_$php.zip"
    $script:Stage = (PathFull (Required $product 'zipfile_path')).TrimEnd('\','/')
    if ($script:Stage -eq [IO.Path]::GetPathRoot($script:Stage).TrimEnd('\','/')) { throw 'The staging root cannot be a drive/share root.' }
    if (-not $LogPath) { $LogPath = Join-Path $script:Workspace ('product-build-{0}-{1}.log' -f (Get-Date -Format 'yyyyMMdd-HHmmss'), [guid]::NewGuid().ToString('N').Substring(0,8)) }
    $script:Log = PathFull $LogPath
    if (Inside $script:Log $script:Stage) { throw 'Build log must be outside the staging root.' }
    MakeParent $script:Log
    Log "START config=$configFile staging=$script:Stage"

    $protected = @{}; $installPlans = @(); $modulePlans = @(); $copyPlans = @(); $directoryPlans = @()
    # Build a complete preflight plan before modifying product destinations.
    foreach ($entry in $config.module_config) {
        ObjectCheck $entry 'module_config entry'
        $src = PathFull (Required $entry 'src'); $des = PathFull (Required $entry 'des')
        if ([IO.Path]::GetFileName($des) -ine 'install.ini') { throw "INI destination must be named install.ini: $des" }
        $remove = Join-Path ([IO.Path]::GetDirectoryName($des)) 'install.json'
        if ($src -ieq $remove -or $src -ieq $des) { throw "Source JSON would be modified: $src" }
        if ($protected.ContainsKey($des)) { throw "Duplicate INI destination: $des" }
        $protected[$des] = $true; $protected[$remove] = $true
        $install = ReadJson $src
        foreach ($p in $install.PSObject.Properties) { if ($p.Name -notin @('framework','modules')) { throw "Unsupported installation section: $($p.Name)" } }
        $framework = Required $install 'framework'; ObjectCheck $framework 'framework'
        $modules = Required $install 'modules'; ObjectCheck $modules 'modules'
        $lines = New-Object 'System.Collections.Generic.List[string]'
        $lines.Add('[framework]')
        foreach ($p in $framework.PSObject.Properties) { $lines.Add(('{0} = {1}' -f (IniKey $p.Name), (IniValue $p.Value))) }
        foreach ($m in $modules.PSObject.Properties) {
            $section = IniKey $m.Name
            if ($section -ieq 'framework') { throw 'Module section conflicts with framework.' }
            ObjectCheck $m.Value "module $section"
            $module = $m.Value; $moduleKey = FilePart (Required $module 'module_key')
            $moduleSrc = PathFull (Required $module 'module_src_dir'); $moduleDes = (PathFull (Required $module 'module_des_dir')).TrimEnd('\','/')
            $name = Required $module 'name'
            foreach ($p in $module.PSObject.Properties) { $null = IniValue $p.Value; $null = IniKey $p.Name }
            $regex = '^' + [regex]::Escape($moduleKey) + '\(([^()]*)\)\.zip$'
            $versioned = $moduleKey -ine 'module_framework'
            if (-not $versioned) { $regex = '^module_framework\.zip$' }
            $packages = @(); $best = $null
            foreach ($file in Get-ChildItem -LiteralPath $moduleSrc -File -Force) {
                if ($file.Name -match $regex) {
                    $v = 'unversioned'
                    if ($versioned) {
                        $v = $Matches[1]
                        if ($v -notmatch '^\d+(\.\d+)*$') { throw "Unsupported module version: $($file.Name)" }
                    }
                    $candidate = [pscustomobject]@{ File=$file; Version=$v }
                    $packages += $candidate
                    if ($null -eq $best -or ($versioned -and (CompareVersion $v $best.Version) -gt 0)) { $best = $candidate }
                }
            }
            if ($null -eq $best) {
                $expectedPackage = "$moduleKey(version).zip"
                if (-not $versioned) { $expectedPackage = 'module_framework.zip' }
                throw "No package matching $expectedPackage in $moduleSrc"
            }
            $selected = PathFull $best.File.FullName
            $target = Join-Path $moduleDes $best.File.Name
            $modulePlans += [pscustomobject]@{ Source=$selected; Destination=$target; Directory=$moduleDes; Key=$moduleKey; Version=$best.Version; Versioned=$versioned; Regex=$regex; Hash=(Get-FileHash -LiteralPath $selected -Algorithm SHA256).Hash }
            $lines.Add(''); $lines.Add("[$section]")
            $lines.Add(('name = {0}' -f (IniValue $name)))
            $lines.Add(('module = {0}' -f (IniValue $best.File.Name)))
            foreach ($p in $module.PSObject.Properties) {
                if ($p.Name -notin @('name','module','module_key','module_src_dir','module_des_dir')) { $lines.Add(('{0} = {1}' -f (IniKey $p.Name), (IniValue $p.Value))) }
            }
        }
        $installPlans += [pscustomobject]@{ Source=$src; Destination=$des; Remove=$remove; Text=($lines -join "`r`n") + "`r`n" }
    }
    $sourceMappings = @()
    $generatedPaths = @($installPlans | ForEach-Object { $_.Destination }) + @($modulePlans | ForEach-Object { $_.Destination })
    foreach ($entry in $config.source) {
        ObjectCheck $entry 'source entry'
        $src = PathFull (Required $entry 'src'); $des = Destination (Required $entry 'des')
        $item = $null
        if (Test-Path -LiteralPath $src) { $item = Get-Item -LiteralPath $src -Force }
        $futureDirectory = @($generatedPaths | Where-Object { (Inside $_ $src) -and $_ -ine $src }).Count -gt 0
        if ($null -eq $item -and -not $futureDirectory -and $src -notin $generatedPaths) { throw "Missing source: $src" }
        if (($item -and $item.PSIsContainer) -or ($null -eq $item -and $futureDirectory)) {
            if ((Inside $des $src) -or (Inside $src $des)) { throw "Overlapping source/destination trees: $src -> $des" }
            $directoryPlans += $des
            $sourceMappings += [pscustomobject]@{ Source=$src.TrimEnd('\','/'); Destination=$des; Directory=$true }
            if ($item) {
                foreach ($dir in Get-ChildItem -LiteralPath $src -Directory -Recurse -Force) { $null = PathFull $dir.FullName; $directoryPlans += Destination (Join-Path $des $dir.FullName.Substring($src.TrimEnd('\','/').Length+1)) }
                foreach ($file in FilesUnder $src) { $copyPlans += [pscustomobject]@{ Source=$file.FullName; Destination=(Destination (Join-Path $des $file.FullName.Substring($src.TrimEnd('\','/').Length+1))) } }
            }
        } else {
            if ((Test-Path -LiteralPath $des -PathType Container) -or ([string]$entry.des -match '[\\/]$')) { $des = Join-Path $des ([IO.Path]::GetFileName($src)) }
            if ($src -ieq $des) { throw "Source equals destination: $src" }
            $copyPlans += [pscustomobject]@{ Source=$src; Destination=$des }
            $sourceMappings += [pscustomobject]@{ Source=$src; Destination=$des; Directory=$false }
        }
    }
    # Source directories are expanded before generation. Remove files scheduled
    # for cleanup and add future INIs/packages at their effective staged paths.
    $copyPlans = @($copyPlans | Where-Object {
        $copySource = $_.Source
        $deleted = @($installPlans | Where-Object { $_.Remove -ieq $copySource }).Count -gt 0
        foreach ($m in $modulePlans) {
            if ($m.Versioned -and [IO.Path]::GetDirectoryName($copySource) -ieq $m.Directory -and [IO.Path]::GetFileName($copySource) -match $m.Regex) {
                $oldVersion = $Matches[1]
                if ($oldVersion -match '^\d+(\.\d+)*$' -and (CompareVersion $oldVersion $m.Version) -lt 0) { $deleted = $true }
            }
        }
        -not $deleted
    })
    $requiredStagePaths = @(); $allowedGeneratedCopies = @{}
    foreach ($outputPath in $generatedPaths) {
        $targets = @()
        if (Inside $outputPath $script:Stage) { $targets += $outputPath }
        foreach ($mapping in $sourceMappings) {
            $target = $null
            if ($mapping.Directory -and (Inside $outputPath $mapping.Source) -and $outputPath -ine $mapping.Source) {
                $target = Destination (Join-Path $mapping.Destination $outputPath.Substring($mapping.Source.Length+1))
            } elseif (-not $mapping.Directory -and $outputPath -ieq $mapping.Source) { $target = $mapping.Destination }
            if ($target) {
                $copyPlans = @($copyPlans | Where-Object { $_.Source -ine $outputPath -or $_.Destination -ine $target })
                $copyPlans += [pscustomobject]@{ Source=$outputPath; Destination=$target }
                $allowedGeneratedCopies[$target] = $outputPath
                $targets += $target
            }
        }
        if ($targets.Count -eq 0) { throw "External generated output has no source mapping into product staging: $outputPath" }
        $requiredStagePaths += $targets
    }
    foreach ($plan in $installPlans) {
        foreach ($mapping in $sourceMappings) {
            if ($mapping.Directory -and (Inside $plan.Destination $mapping.Source)) {
                $target = Destination (Join-Path $mapping.Destination $plan.Destination.Substring($mapping.Source.Length+1))
                $protected[$target] = $true
                $protected[(Join-Path ([IO.Path]::GetDirectoryName($target)) 'install.json')] = $true
            }
        }
    }
    foreach ($copy in $copyPlans) {
        if ($protected.ContainsKey($copy.Destination) -and (-not $allowedGeneratedCopies.ContainsKey($copy.Destination) -or $allowedGeneratedCopies[$copy.Destination] -ine $copy.Source)) { throw "Source copy conflicts with protected configuration: $($copy.Source) -> $($copy.Destination)" }
        foreach ($m in $modulePlans) {
            if ($copy.Destination -ieq $m.Destination -and (Get-FileHash -LiteralPath $copy.Source -Algorithm SHA256).Hash -ne $m.Hash) { throw "Source copy would replace the selected module with different content: $($copy.Destination)" }
        }
    }
    foreach ($dir in $directoryPlans) { if ($protected.ContainsKey($dir)) { throw "Source directory conflicts with protected configuration: $dir" } }
    foreach ($inputPath in @($configFile) + @($installPlans | ForEach-Object { $_.Source })) {
        if ($protected.ContainsKey($inputPath) -or @($copyPlans | Where-Object { $_.Destination -ieq $inputPath }).Count -gt 0) { throw "Build would modify source JSON: $inputPath" }
    }
    # Validate configured exclusions against required outputs before any copies.
    foreach ($requiredPath in $requiredStagePaths) {
        if (Excluded $requiredPath.Substring($script:Stage.Length+1) $false) { throw "Archive exclusions hide a required output: $requiredPath" }
    }
    $script:BuildTemp = Join-Path ([IO.Path]::GetTempPath()) ('.product-build-' + [guid]::NewGuid().ToString('N').Substring(0,12))
    if (Inside $script:BuildTemp $script:Stage) { throw 'Temporary directory must be outside staging root.' }
    [IO.Directory]::CreateDirectory($script:BuildTemp) | Out-Null
    foreach ($m in $modulePlans) {
        Log "Selected $($m.Key) version $($m.Version): $($m.Source)"
        $hash = $m.Hash
        $candidate = Join-Path $script:BuildTemp ([guid]::NewGuid().ToString('N') + '.zip')
        Copy-Item -LiteralPath $m.Source -Destination $candidate -Force
        if ((Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash -ne $hash) { throw "Module copy hash mismatch: $($m.Source)" }
        ZipCheck $candidate
        PublishFile $candidate $m.Destination
        if ((Get-FileHash -LiteralPath $m.Destination -Algorithm SHA256).Hash -ne $hash) { throw "Destination hash mismatch: $($m.Destination)" }
        ZipCheck $m.Destination
        Log "SHA256 $hash copied $($m.Destination)"
        foreach ($old in Get-ChildItem -LiteralPath $m.Directory -File -Force) {
            if ($m.Versioned -and $old.Name -match $m.Regex -and $old.FullName -ine $m.Destination) {
                $oldVersion = $Matches[1]
                if ($oldVersion -notmatch '^\d+(\.\d+)*$') { throw "Unsupported destination module version: $($old.Name)" }
                if ((CompareVersion $oldVersion $m.Version) -lt 0) { Remove-Item -LiteralPath $old.FullName -Force; Log "Deleted old module: $($old.FullName)" }
            }
        }
    }
    foreach ($plan in $installPlans) {
        MakeParent $plan.Destination
        [IO.File]::WriteAllText($plan.Destination, $plan.Text, (New-Object Text.UTF8Encoding($false)))
        if ([IO.File]::ReadAllText($plan.Destination) -cne $plan.Text) { throw "INI verification failed: $($plan.Destination)" }
        Log "Generated and verified INI: $($plan.Destination)"
        if (Test-Path -LiteralPath $plan.Remove) { Remove-Item -LiteralPath $plan.Remove -Force; Log "Deleted destination JSON: $($plan.Remove)" }
    }
    foreach ($dir in $directoryPlans) { [IO.Directory]::CreateDirectory($dir) | Out-Null }
    foreach ($copy in $copyPlans) {
        MakeParent $copy.Destination
        $action = 'Copied'; if (Test-Path -LiteralPath $copy.Destination) { $action = 'Overwrote' }
        Copy-Item -LiteralPath $copy.Source -Destination $copy.Destination -Force
        if ((Get-FileHash -LiteralPath $copy.Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $copy.Destination -Algorithm SHA256).Hash) { throw "Source copy verification failed: $($copy.Destination)" }
        Log "$action $($copy.Source) -> $($copy.Destination)"
    }
    [IO.Directory]::CreateDirectory($script:Stage) | Out-Null
    foreach ($m in $modulePlans) {
        if ((Get-FileHash -LiteralPath $m.Destination -Algorithm SHA256).Hash -ne $m.Hash) { throw "Selected module changed during build: $($m.Destination)" }
    }
    $expected = @{}; $list = New-Object 'System.Collections.Generic.List[string]'
    foreach ($file in FilesUnder $script:Stage) {
        $relative = $file.FullName.Substring($script:Stage.Length+1)
        if (Excluded $relative $false) { Log "Excluded: $relative"; continue }
        $expected[$relative.Replace('\','/')] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
        $list.Add($relative); Log "ZIP entry: $relative"
    }
    # Explicitly add empty directories; file entries already preserve their parents.
    foreach ($dir in Get-ChildItem -LiteralPath $script:Stage -Directory -Recurse -Force) {
        $relative = $dir.FullName.Substring($script:Stage.Length+1)
        if (-not (Excluded $relative $true) -and @(Get-ChildItem -LiteralPath $dir.FullName -Force).Count -eq 0) { $list.Add($relative + '\'); Log "ZIP directory: $relative" }
    }
    if ($list.Count -eq 0) { throw 'Nothing to archive after exclusions.' }
    $listFile = Join-Path $script:BuildTemp 'entries.txt'
    [IO.File]::WriteAllLines($listFile, $list.ToArray(), (New-Object Text.UTF8Encoding($false)))
    $archive = Join-Path $script:BuildTemp $script:ArchiveName
    # Snapshot only approved entries. An absolute wildcard with -ep1 preserves
    # paths below this folder independently of WinRAR's process working directory.
    $snapshot = Join-Path $script:BuildTemp 'contents'
    [IO.Directory]::CreateDirectory($snapshot) | Out-Null
    foreach ($relative in $list) {
        $target = Join-Path $snapshot $relative
        if ($relative.EndsWith('\')) { [IO.Directory]::CreateDirectory((LongPath $target)) | Out-Null } else {
            CopyFile (Join-Path $script:Stage $relative) $target
        }
    }
    Rar @('a','-afzip','-ep1','-r','-idq','-y',$archive,(Join-Path $snapshot '*'))
    ZipCheck $archive
    $zip = [IO.Compression.ZipFile]::OpenRead($archive)
    try {
        $seen = @{}
        foreach ($entry in $zip.Entries) {
            $entryName = $entry.FullName.Replace('\','/')
            if ($entryName.EndsWith('/')) { continue }
            if (-not $expected.ContainsKey($entryName) -or $seen.ContainsKey($entryName)) { throw "Unexpected/duplicate archive entry: $entryName" }
            $stream = $entry.Open(); $sha = [Security.Cryptography.SHA256]::Create()
            try { $actual = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','') } finally { $stream.Dispose(); $sha.Dispose() }
            if ($actual -ne $expected[$entryName]) { throw "Archive content mismatch: $entryName" }
            $seen[$entryName] = $true
        }
        if ($seen.Count -ne $expected.Count) { throw 'Archive is missing expected files.' }
        foreach ($requiredPath in $requiredStagePaths) {
            if (-not $seen.ContainsKey($requiredPath.Substring($script:Stage.Length+1).Replace('\','/'))) { throw "Archive missing required output: $requiredPath" }
        }
    } finally { $zip.Dispose() }
    $final = Join-Path $script:Stage $script:ArchiveName
    # Copy verified bytes beside final output, then replace atomically on its volume.
    PublishFile $archive $final
    Log "SUCCESS output=$final"
    Log 'END'
    exit 0
} catch {
    try { Log "FAILED: $($_.Exception.Message). Earlier completed changes are not rolled back."; Log 'END' } catch { Write-Error $_ -ErrorAction Continue }
    exit 1
} finally {
    if ($script:BuildTemp -and (Test-Path -LiteralPath $script:BuildTemp)) {
        $resolvedTemp = [IO.Path]::GetFullPath($script:BuildTemp)
        $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
        if ($resolvedTemp.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetFileName($resolvedTemp) -like '.product-build-*') {
            [IO.Directory]::Delete((LongPath $resolvedTemp), $true)
        }
    }
}
