# Offline FullCalendar test project

Pure PHP 7.4, PDO MySQL, MariaDB, FullCalendar **5.11.5**. No ZF1, Composer, Node build, or runtime CDN requests. Apache and MariaDB must run locally: offline means no internet, not no server.

## XAMPP setup

1. Keep the project at `E:\www\fullcalendar`. Your Apache virtual host on port **4040** must use `E:\www\fullcalendar\public` as its document root. For other installations, point Apache at the project's **public** directory, not its root.
2. Edit `config.php`: MariaDB credentials for the existing `fullcalendar` database and a new owner password. Default XAMPP credentials are root with an empty database password. The sample owner password is `change-this-password`; replace it before sharing access.
3. Open `http://localhost:4040/setup.php`, enter the owner password and install. Only new `fc_` tables are created; existing database tables are untouched. Setup is idempotent and seeds only an empty calendar table. PHP needs PDO MySQL enabled. If your virtual host uses a custom hostname, substitute that hostname for localhost.
4. Open `http://localhost:4040/` and log in. Configuration, schema and implementation files remain outside the public document root; public PHP entry points load them.
5. Disconnect internet access. Reload and exercise the test checklist below. Keep Apache/MariaDB running.

All dependencies are in `public/vendor`. `tools/download-assets.ps1` restores the pinned assets if needed (requires internet only during download). If Windows TLS stalls and Node is available, use `node tools/download-assets.js`. Node is optional and is not needed to run the app. Never run the application from a `file://` URL. No service worker is needed.

## Features and scope

### Recurring events through the interface

Open Add event (or select a date range), enter a title, and choose Daily, Weekly, or Monthly under Repeat. Weekly exposes Sunday–Saturday checkboxes. Set the first date, interval, times (or All day), and end condition: Never, On a date (inclusive), or After a number of occurrences. Save writes the recurrence to MariaDB. Clicking an occurrence reopens the form; edits and deletion affect the whole series. Monthly recurrence uses the first date's day of month; months without that date are skipped.

Sample pages at your virtual host:
- `http://localhost:4040/weekly-recurrence.php`: Monday and Wednesday example.
- `http://localhost:4040/advanced-recurrence.php`: daily, fortnightly, and monthly examples.

These pages share the same login, database, calendars and sharing permissions. Example buttons prefill the editor; they do not insert data until Save. Existing recurrence definitions that cannot be represented by the form are kept in preserve mode rather than silently simplified. The optional advanced JSON section remains available for custom rules and properties.

- Month, week, day, list, custom four-day views; resource day/week/month; resource timeline day/week/month (premium evaluation).
- Toolbar navigation, go-to-date, navigation links, locales, RTL, week numbers, weekends, business hours, now indicator, slot intervals, overlap and business-hours constraints, popovers, print and resizing.
- Database event create/read/update/delete; selection, drag/drop, resize from either end, external drag sources; all-day/multi-day/timed events; colors, descriptions, resource assignment, background/inverse-background and hidden events.
- Simple weekly recurrence and RRule recurrence. Advanced event JSON accepts FullCalendar event properties, including recurrence, groupId, constraints, extended properties and safe HTTP(S) URLs. Series editing affects the entire recurrence. Recurring drag/resize is intentionally disabled; per-occurrence exceptions are not implemented.
- Named time zones through Moment Timezone (bundled timezone data is pinned, not automatically updated).
- Multiple calendars, database resources, event JSON import/export and callback log.
- Advanced calendar JSON options expose additional serializable v5 options. JavaScript function callbacks belong in `public/app.js`; framework adapters are unnecessary for this plain PHP application.
- Database sharing: high-entropy bearer links with read-only/edit permission, optional expiry, immediate revocation. Tokens are stored hashed. Editable links can edit all events in their calendar, but cannot manage resources, shares or calendars. Copy links when created; raw tokens cannot be recovered from the database. Use a separate private/incognito window to test shares, because the owner's existing session always has owner permissions.
- Optimistic event versions prevent silent overwrite by another editing window.
- Related events with the same groupId move/resize in one database transaction.

This is a broad v5 feature laboratory, not an implementation of every API method or integration. Google Calendar and remote iCalendar feeds require network access and are not enabled; JSON import provides offline data. Bootstrap themes, framework adapters, event transfer between two calendar instances, per-occurrence recurrence exceptions, and premium optimized-print plugin are not included. Standard browser printing is available. Add callbacks/options to app.js for specialized API experiments.

Premium scheduler assets are included for evaluation and show the upstream license notice. Set `scheduler_license_key` to your legitimate key when appropriate. See https://fullcalendar.io/license and https://legacy.fullcalendar.io/v5/premium . Bundled vendor licenses are preserved alongside the assets. Do not assume premium assets use the core MIT license.

## Sharing on a local network

A localhost link works only on the same computer. Open the app using your XAMPP computer's LAN address before generating links (for example `http://192.168.1.10:4040/`). Apache must allow LAN connections and your firewall must permit them. The network can have no internet connection. Share links are bearer credentials: anyone holding one receives its permissions. This is a local test app with one owner account, not a production multiuser authentication system.

## Browser acceptance checklist

Compatibility with **Chrome 49 and Firefox 52 is unverified until tested on those actual browsers**. Application JS uses ES5 syntax, XMLHttpRequest and plain form controls, with locally bundled core-js polyfills. Polyfills do not fix missing CSS features or browser rendering bugs.

Run each check in both required browsers and record version, outcome and console errors:

1. Cold load with internet disconnected: no missing scripts, fonts, styles, or network requests to remote hosts.
2. Every standard and premium view; previous/next/today and date navigation; window resize, event popovers and print.
3. English/Japanese/Arabic RTL; local/UTC/Tokyo/New York time zones including a DST boundary.
4. Create timed, all-day and multi-day events; exclusive end dates; refresh and verify persistence.
5. Edit colors/descriptions/resources; delete; drag, resize from either end; external drop. Confirm results after reload.
6. Business-hour restrictions and overlap controls; background/inverse-background events.
7. Simple recurrence and RRule; edit/delete an entire series and check after reload.
8. Resource views and reassignment, add/delete resource, and multiple calendars.
9. Read-only share in an unauthenticated window: view works and API saves fail. Editable share: CRUD works but owner management fails. Revoke and confirm access fails. Test expiry.
10. Two editing windows: edit the same event, save in one, then attempt stale save in the other. Expect a conflict message.
11. JSON export/import and advanced options; refresh after successful saves.

Use text ISO dates because old browser date/time inputs differ. End dates are exclusive, per FullCalendar. API feeds return all calendar events to preserve recurrence definitions (suitable for this test dataset; add range filtering/recurrence expansion for large production datasets).

Validation performed during generation: PHP 7.4.33 syntax checks; MariaDB 10.4.27 API integration tests; installed Chrome rendering every selectable view, RRule recurrence, locale and named timezone with remote requests blocked and no JavaScript errors. This does not establish Chrome 49/Firefox 52 compatibility. Optional developer checks are in `tools/test-api.js` (creates a separate named test calendar) and `tools/test-browser.js` (requires Playwright and installed Chrome). Neither is required by XAMPP.

## Troubleshooting

Readable FullCalendar JavaScript: `public/vendor/main.js` is the original unminified Scheduler 5.11.5 browser bundle currently loaded by the pages. `public/vendor/fullcalendar-standard.js` is the original unminified Standard bundle for reference (do not load both bundles together). Locales and the RRule/Moment Timezone connectors also load their unminified browser builds. Third-party Moment, RRule and core-js dependencies retain their minified distributions. App behavior is in `public/app.js` and recurrence forms in `public/recurrence.js`. Vendor headers and licensing still apply; unminified Premium code does not remove the licensing requirement.

Database error: confirm Apache/PHP 7.4, PDO MySQL, MariaDB, credentials, and setup. Check XAMPP's PHP error log. Blank calendar: inspect browser console and confirm all files in `public/vendor` exist. Changing the owner password does not invalidate already authenticated sessions; restart/clear sessions when testing this. Back up MariaDB normally; JSON export exports events only, not shares, resources, or calendars.
