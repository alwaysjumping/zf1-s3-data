<?php
$config=require __DIR__.'/config.php'; $message='';
if($_SERVER['REQUEST_METHOD']==='POST') {
 if(!hash_equals($config['admin_password'],$_POST['password']??'')) $message='Incorrect owner password.';
 else try {
  $db=new PDO($config['dsn'],$config['user'],$config['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  foreach(explode(';',file_get_contents(__DIR__.'/schema.sql')) as $sql) if(trim($sql)) $db->exec($sql);
  if(!(int)$db->query('SELECT COUNT(*) FROM fc_calendars')->fetchColumn()) {
   $db->beginTransaction(); $db->exec("INSERT INTO fc_calendars(name) VALUES ('Demo schedule')"); $cid=$db->lastInsertId();
   $r=$db->prepare('INSERT INTO fc_resources(calendar_id,payload) VALUES (?,?)');
   foreach(['Meeting room A','Meeting room B','Team'] as $title) $r->execute([$cid,json_encode(['title'=>$title])]);
   $rid=(string)$db->query('SELECT MIN(id) FROM fc_resources')->fetchColumn();
   $q=$db->prepare('INSERT INTO fc_events(calendar_id,payload) VALUES (?,?)'); $today=date('Y-m-d');
   foreach([
    ['title'=>'Welcome: click to edit','start'=>$today.'T10:00:00','end'=>$today.'T11:00:00','resourceId'=>$rid,'color'=>'#2563eb','extendedProps'=>['description'=>'Drag, resize, edit, and share this event.']],
    ['title'=>'All-day example','start'=>$today,'end'=>date('Y-m-d',strtotime('+2 days')),'allDay'=>true,'color'=>'#059669'],
    ['title'=>'Weekly standup','daysOfWeek'=>[1,3,5],'startTime'=>'09:00','endTime'=>'09:30','startRecur'=>date('Y-m-01'),'endRecur'=>date('Y-m-d',strtotime('+3 months')),'resourceId'=>$rid],
    ['title'=>'Background availability','start'=>$today.'T12:00:00','end'=>$today.'T14:00:00','display'=>'background','color'=>'#fbbf24'],
    ['title'=>'RRule weekly','rrule'=>['freq'=>'weekly','dtstart'=>$today.'T15:00:00','count'=>8],'duration'=>'01:00','color'=>'#9333ea']
   ] as $event) $q->execute([$cid,json_encode($event)]);
   $db->commit();
  }
  $message='Setup complete. Open index.php. Re-running setup preserves existing data.';
 } catch(Throwable $e) { $message='Setup failed: '.$e->getMessage(); }
}
?><!doctype html><meta charset="utf-8"><title>Calendar setup</title><h1>Calendar setup</h1><p>Creates fc_ tables in your existing fullcalendar database. Set config.php first.</p><p><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></p><form method="post"><label>Owner password <input name="password" type="password" required></label><button>Install tables and demo data</button></form><p><a href="index.php">Open calendar</a></p>
