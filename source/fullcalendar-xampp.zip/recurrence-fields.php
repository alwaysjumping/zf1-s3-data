<fieldset><legend>Repeat</legend>
<label>Repeat schedule<select id="repeatMode"><option value="none">Does not repeat</option><option value="daily">Daily</option><option value="weekly">Weekly — choose weekdays</option><option value="monthly">Monthly — same day of month</option><option value="custom">Existing advanced recurrence (preserve)</option></select></label>
<div id="repeatFields" hidden>
<label>First date<input id="repeatStart" placeholder="YYYY-MM-DD"></label>
<label>Repeat every <input id="repeatInterval" type="number" min="1" max="365" value="1"> <span id="repeatUnit">weeks</span></label>
<div id="repeatWeekdays"><p>Repeat on</p><?php foreach(['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'] as $day=>$name): ?><label class="weekday"><input type="checkbox" name="repeatDay" value="<?=$day?>"> <?=$name?></label><?php endforeach; ?></div>
<div id="repeatTimes"><label>Start time<input id="repeatTime" placeholder="HH:MM" value="09:00"></label><label>End time<input id="repeatEndTime" placeholder="HH:MM" value="10:00"></label><p>For overnight events, an end time earlier than the start is treated as the following day.</p></div>
<label>Series ends<select id="repeatEndMode"><option value="never">Never</option><option value="until">On a date (inclusive)</option><option value="count">After a number of occurrences</option></select></label>
<label id="repeatUntilRow" hidden>Last date<input id="repeatUntil" placeholder="YYYY-MM-DD"></label><label id="repeatCountRow" hidden>Occurrences<input id="repeatCount" type="number" min="1" max="10000" value="10"></label>
<p id="repeatSummary" aria-live="polite"></p>
</div><p id="customRepeatNote" hidden>This recurrence uses advanced rules. Its definition will be preserved. Choose a different repeat schedule to replace it.</p>
</fieldset><p id="editorError" role="alert" style="color:#b91c1c"></p>
