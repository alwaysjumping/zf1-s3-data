<?php
$recurrenceSample='advanced';
require dirname(__DIR__).'/index.php';
