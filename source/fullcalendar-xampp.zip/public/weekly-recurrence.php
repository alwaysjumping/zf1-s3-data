<?php
$recurrenceSample='weekly';
require dirname(__DIR__).'/index.php';
