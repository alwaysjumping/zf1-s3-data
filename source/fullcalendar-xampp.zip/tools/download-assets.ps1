$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$destination = Join-Path (Split-Path $PSScriptRoot -Parent) 'public\vendor'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
$assets = @{
 'main.js' = 'https://cdn.jsdelivr.net/npm/fullcalendar-scheduler@5.11.5/main.js'
 'fullcalendar-standard.js' = 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.js'
 'locales-all.js' = 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/locales-all.js'
 'moment-timezone-main.js' = 'https://cdn.jsdelivr.net/npm/@fullcalendar/moment-timezone@5.11.5/main.global.js'
 'rrule-main.js' = 'https://cdn.jsdelivr.net/npm/@fullcalendar/rrule@5.11.5/main.global.js'
 'main.min.js' = 'https://cdn.jsdelivr.net/npm/fullcalendar-scheduler@5.11.5/main.min.js'
 'main.min.css' = 'https://cdn.jsdelivr.net/npm/fullcalendar-scheduler@5.11.5/main.min.css'
 'locales-all.min.js' = 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/locales-all.min.js'
 'moment.min.js' = 'https://cdn.jsdelivr.net/npm/moment@2.29.4/min/moment.min.js'
 'moment-timezone-with-data.min.js' = 'https://cdn.jsdelivr.net/npm/moment-timezone@0.5.43/builds/moment-timezone-with-data.min.js'
 'moment-timezone-main.min.js' = 'https://cdn.jsdelivr.net/npm/@fullcalendar/moment-timezone@5.11.5/main.global.min.js'
 'rrule.min.js' = 'https://cdn.jsdelivr.net/npm/rrule@2.6.8/dist/es5/rrule.min.js'
 'rrule-main.min.js' = 'https://cdn.jsdelivr.net/npm/@fullcalendar/rrule@5.11.5/main.global.min.js'
 'polyfills.js' = 'https://cdn.jsdelivr.net/npm/core-js-bundle@3.37.1/minified.js'
 'fullcalendar-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/LICENSE.txt'
 'scheduler-LICENSE.md' = 'https://cdn.jsdelivr.net/npm/fullcalendar-scheduler@5.11.5/LICENSE.md'
 'moment-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/moment@2.29.4/LICENSE'
 'moment-timezone-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/moment-timezone@0.5.43/LICENSE'
 'rrule-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/rrule@2.6.8/LICENCE'
 'core-js-LICENSE.txt' = 'https://cdn.jsdelivr.net/npm/core-js-bundle@3.37.1/LICENSE'
}
foreach ($name in $assets.Keys) {
 Invoke-WebRequest -UseBasicParsing -Uri $assets[$name] -OutFile (Join-Path $destination $name)
 Write-Output "Downloaded $name"
}
Get-ChildItem -LiteralPath $destination -File | Get-FileHash -Algorithm SHA256 | Select-Object Hash,Path | ConvertTo-Json | Set-Content (Join-Path $destination 'checksums.json')
