// Optional smoke test: set NODE_PATH to your Playwright installation.
const {chromium}=require('playwright');
const assert=require('assert');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 try{
 const context=await browser.newContext({viewport:{width:1440,height:1000}});
 const page=await context.newPage();const errors=[],remote=[];
 page.on('pageerror',e=>errors.push(e.message));
 await context.route('**/*',route=>{const url=route.request().url();if(!url.startsWith('http://127.0.0.1:8097/')&&!url.startsWith('data:')&&!url.startsWith('blob:')){remote.push(url);return route.abort();}return route.continue();});
 await page.goto('http://127.0.0.1:8097/index.php');
 await page.locator('#password').fill(process.env.FC_TEST_PASSWORD||'change-this-password');await page.locator('#loginForm button').click();
 await page.locator('.fc-daygrid-day').first().waitFor();
 for(const view of ['timeGridWeek','timeGridDay','listWeek','fourDays','resourceTimeGridDay','resourceTimeGridWeek','resourceDayGridMonth','resourceTimelineDay','resourceTimelineWeek','resourceTimelineMonth','dayGridMonth']){
  await page.selectOption('#view',view);await page.waitForTimeout(200);assert(await page.locator('.fc-view').count()>0);console.log('View rendered: '+view);
 }
 await page.selectOption('#zone','Asia/Tokyo');await page.selectOption('#locale','ja');await page.waitForTimeout(200);
 await page.screenshot({path:'public/smoke-test.png',fullPage:true});
 assert.deepEqual(errors,[]);assert.deepEqual(remote,[]);console.log('PASS: all views rendered, named timezone/locale, no JavaScript errors, remote requests blocked');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
