const {chromium}=require('playwright');
const assert=require('assert');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});let cid;
 try{
 const context=await browser.newContext();const page=await context.newPage();const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await context.route('**/*',r=>r.request().url().startsWith('http://127.0.0.1:8097/')?r.continue():r.abort());
 await page.goto('http://127.0.0.1:8097/weekly-recurrence.php');await page.locator('#password').fill(process.env.FC_TEST_PASSWORD||'change-this-password');await page.locator('#loginForm button').click();await page.locator('.fc-view').waitFor();
 const s=await (await page.request.get('http://127.0.0.1:8097/api.php?action=state')).json();
 const response=await page.request.post('http://127.0.0.1:8097/api.php?action=calendar',{headers:{'X-CSRF-Token':s.csrf},data:{name:'Recurrence UI automated test'}});cid=(await response.json()).id;assert(cid);
 await page.goto('http://127.0.0.1:8097/weekly-recurrence.php?calendar='+cid);await page.locator('.fc-view').waitFor();await page.locator('#sampleWeekly').click();
 assert(await page.locator('input[name=repeatDay][value="1"]').isChecked());assert(await page.locator('input[name=repeatDay][value="3"]').isChecked());assert(await page.locator('#start').isDisabled());
 await page.locator('#title').fill('UI weekly test');await page.locator('#repeatEndMode').selectOption('until');await page.locator('#repeatStart').fill('2026-10-01');await page.locator('#repeatUntil').fill('2026-10-31');await page.locator('#save').click();await page.locator('#modal').waitFor({state:'hidden'});
 let data=await (await page.request.get('http://127.0.0.1:8097/api.php?action=events&calendar='+cid)).json();assert.equal(data.length,1);assert.deepEqual(data[0].rrule.byweekday,['mo','we']);assert.equal(data[0].rrule.until,'2026-10-31T23:59:59');assert(!data[0].start);
 await page.reload();await page.locator('.fc-event').filter({hasText:'UI weekly test'}).first().click();assert.equal(await page.locator('#repeatMode').inputValue(),'weekly');assert.equal(await page.locator('#repeatUntil').inputValue(),'2026-10-31');
 await page.locator('#repeatInterval').fill('2');await page.locator('#save').click();await page.locator('#modal').waitFor({state:'hidden'});data=await (await page.request.get('http://127.0.0.1:8097/api.php?action=events&calendar='+cid)).json();assert.equal(data[0].rrule.interval,2);
 await page.goto('http://127.0.0.1:8097/advanced-recurrence.php?calendar='+cid);await page.locator('.fc-view').waitFor();await page.locator('#sampleDaily').click();await page.locator('#save').click();await page.locator('#modal').waitFor({state:'hidden'});
 await page.locator('#sampleMonthly').click();await page.locator('#allDay').check();await page.locator('#save').click();await page.locator('#modal').waitFor({state:'hidden'});
 await page.locator('#sampleWeekly').click();await page.locator('input[name=repeatDay][value="1"]').uncheck();await page.locator('input[name=repeatDay][value="3"]').uncheck();await page.locator('#save').click();assert((await page.locator('#editorError').textContent()).includes('weekday'));await page.locator('#close').click();
 data=await (await page.request.get('http://127.0.0.1:8097/api.php?action=events&calendar='+cid)).json();assert.equal(data.length,3);assert(data.some(e=>e.rrule.freq==='daily'&&e.rrule.count===10));assert(data.some(e=>e.rrule.freq==='monthly'&&e.allDay));assert.deepEqual(errors,[]);
 console.log('PASS: weekday selection, inclusive end date, persistence after reload, series editing, interval, daily count, monthly all-day, form validation, offline pages');
 }finally{
  await browser.close();if(cid){const result=require('child_process').spawnSync('php',['-r','$c=require "config.php";$d=new PDO($c["dsn"],$c["user"],$c["password"]);$q=$d->prepare("DELETE FROM fc_calendars WHERE id=? AND name=?");$q->execute(['+Number(cid)+',"Recurrence UI automated test"]);'],{cwd:require('path').join(__dirname,'..'),encoding:'utf8'});if(result.status!==0)throw Error('Test calendar cleanup failed');}
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
