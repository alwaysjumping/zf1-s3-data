// Run against a local PHP server only. Creates an isolated test calendar.
const assert=require('assert');
const base=process.argv[2]||'http://127.0.0.1:8097/';
const password=process.env.FC_TEST_PASSWORD||'change-this-password';
let ownerCookie='',guestCookie='',csrf='',guestCsrf='',cid=1;
async function call(action,data,guest=false,token=''){
 const r=await fetch(base+'api.php?action='+action+'&calendar='+cid+'&token='+token,{method:data?'POST':'GET',headers:{Cookie:guest?guestCookie:ownerCookie,...(data?{'Content-Type':'application/json','X-CSRF-Token':guest?guestCsrf:csrf}:{})},body:data?JSON.stringify(data):undefined});
 const cookie=r.headers.get('set-cookie');if(cookie){if(guest)guestCookie=cookie.split(';')[0];else ownerCookie=cookie.split(';')[0];}
 return {status:r.status,body:await r.json()};
}
(async()=>{
 const setup=await fetch(base+'setup.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'password='+encodeURIComponent(password)});assert((await setup.text()).includes('Setup complete'));
 let r=await call('state');csrf=r.body.csrf;assert(r.body.login);
 r=await call('login',{password});assert.equal(r.status,200);
 r=await call('calendar',{name:'API test '+Date.now()});cid=Number(r.body.id);assert(cid>0);console.log('TEST_CALENDAR_ID='+cid);
 r=await call('save',{event:{title:'API persistence test',start:'2026-10-12T10:00:00',end:'2026-10-12T11:00:00'}});assert.equal(r.status,200);const id=r.body.id;
 r=await call('events');assert.equal(r.body.length,1);assert.equal(r.body[0].title,'API persistence test');const version=r.body[0].extendedProps.version;
 r=await call('save',{id,version,event:{title:'Updated',start:'2026-10-12'}});assert.equal(r.status,200);
 r=await call('move',{events:[{id,version:version+1,start:'2026-10-13T10:00:00',end:'2026-10-13T11:00:00',allDay:false,resourceIds:[]}]});assert.equal(r.status,200);
 r=await call('events');assert.equal(r.body[0].start,'2026-10-13T10:00:00');
 r=await call('save',{event:{title:'Invalid dates',start:'2026-02-30'}});assert.equal(r.status,422);
 r=await call('save',{id,version,event:{title:'Stale',start:'2026-10-12'}});assert.equal(r.status,409);
 r=await call('share',{label:'Read test',edit:false});const read=r.body.token;assert(read);
 r=await call('state',null,true,read);guestCsrf=r.body.csrf;assert.equal(r.body.editable,false);
 r=await call('save',{event:{title:'Denied',start:'2026-10-12'}},true,read);assert.equal(r.status,403);
 r=await call('share',{label:'Edit test',edit:true});const edit=r.body.token;
 r=await call('state',null,true,edit);assert.equal(r.body.editable,true);
 r=await call('save',{event:{title:'Guest edit',daysOfWeek:[1],startTime:'09:00',endTime:'10:00'}},true,edit);assert.equal(r.status,200);
 r=await call('resource',{resource:{title:'Forbidden'}},true,edit);assert.equal(r.status,403);
 r=await call('shares');const share=r.body.find(x=>x.label==='Edit test');
 r=await call('revoke',{id:share.id});assert.equal(r.status,200);
 r=await call('events',null,true,edit);assert.equal(r.status,403);
 r=await call('share',{label:'Expired test',expires:'2020-01-01'});const expired=r.body.token;
 r=await call('events',null,true,expired);assert.equal(r.status,403);
 r=await call('events');const updated=r.body.find(x=>Number(x.id)===id);
 r=await call('delete',{id,version:updated.extendedProps.version});assert.equal(r.status,200);
 console.log('PASS: setup, login, persistence, move, date validation, conflict detection, read-only/edit shares, owner restrictions, expiry, revocation, deletion');
})().catch(e=>{console.error(e);process.exitCode=1;});
