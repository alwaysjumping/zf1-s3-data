// Optional Node downloader when Windows PowerShell TLS stalls.
const fs = require('fs');
const path = require('path');
const dest = path.join(__dirname, '..', 'public', 'vendor');
const assets = {
 'main.js':'fullcalendar-scheduler@5.11.5/main.js',
 'fullcalendar-standard.js':'fullcalendar@5.11.5/main.js',
 'locales-all.js':'fullcalendar@5.11.5/locales-all.js',
 'moment-timezone-main.js':'@fullcalendar/moment-timezone@5.11.5/main.global.js',
 'rrule-main.js':'@fullcalendar/rrule@5.11.5/main.global.js',
 'main.min.js':'fullcalendar-scheduler@5.11.5/main.min.js',
 'main.min.css':'fullcalendar-scheduler@5.11.5/main.min.css',
 'locales-all.min.js':'fullcalendar@5.11.5/locales-all.min.js',
 'moment.min.js':'moment@2.29.4/min/moment.min.js',
 'moment-timezone-with-data.min.js':'moment-timezone@0.5.43/builds/moment-timezone-with-data.min.js',
 'moment-timezone-main.min.js':'@fullcalendar/moment-timezone@5.11.5/main.global.min.js',
 'rrule.min.js':'rrule@2.6.8/dist/es5/rrule.min.js',
 'rrule-main.min.js':'@fullcalendar/rrule@5.11.5/main.global.min.js',
 'polyfills.js':'core-js-bundle@3.37.1/minified.js',
 'fullcalendar-LICENSE.txt':'fullcalendar@5.11.5/LICENSE.txt',
 'scheduler-LICENSE.md':'fullcalendar-scheduler@5.11.5/LICENSE.md',
 'moment-LICENSE.txt':'moment@2.29.4/LICENSE',
 'moment-timezone-LICENSE.txt':'moment-timezone@0.5.43/LICENSE',
 'rrule-LICENSE.txt':'rrule@2.6.8/LICENCE',
 'core-js-LICENSE.txt':'core-js-bundle@3.37.1/LICENSE'
};
(async function(){
 fs.mkdirSync(dest,{recursive:true});
 const results=await Promise.allSettled(Object.entries(assets).map(async ([name,pkg])=>{
  if(fs.existsSync(path.join(dest,name)) && fs.statSync(path.join(dest,name)).size>0){console.log(name+' already present');return;}
  const r=await fetch('https://cdn.jsdelivr.net/npm/'+pkg,{signal:AbortSignal.timeout(30000)});
  if(!r.ok)throw Error(name+': HTTP '+r.status);
  const data=Buffer.from(await r.arrayBuffer());if(!data.length)throw Error(name+': empty response');
  fs.writeFileSync(path.join(dest,name),data);console.log(name+' '+data.length);
 }));
 results.forEach(r=>{if(r.status==='rejected'){console.error(r.reason.message);process.exitCode=1;}});
 const hashes=Object.keys(assets).filter(n=>fs.existsSync(path.join(dest,n))).map(n=>({file:n,sha256:require('crypto').createHash('sha256').update(fs.readFileSync(path.join(dest,n))).digest('hex')}));
 fs.writeFileSync(path.join(dest,'checksums.json'),JSON.stringify(hashes,null,2));
})();
