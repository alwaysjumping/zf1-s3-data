<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function respond($data, int $status = 200): void { http_response_code($status); echo json_encode($data); exit; }
function validDate($value): bool {
 if(!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:\d{2})?)?$/D',$value)) return false;
 try { $d=new DateTimeImmutable($value); return $d->format('Y-m-d')===substr($value,0,10); } catch(Throwable $e) { return false; }
}
$config = require __DIR__ . '/config.php';
try {
 $db = new PDO($config['dsn'], $config['user'], $config['password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES=>false]);
 $action = $_GET['action'] ?? 'state';
 $post = $_SERVER['REQUEST_METHOD'] === 'POST';
 $input = $post ? json_decode(file_get_contents('php://input'), true) : [];
 if ($post && !is_array($input)) respond(['error'=>'Invalid JSON'],400);
 if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
 if ($post && !hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) respond(['error'=>'Reload the page before saving'],403);
 if ($action === 'login' && $post) {
  if (!hash_equals($config['admin_password'], (string)($input['password'] ?? ''))) respond(['error'=>'Incorrect password'],403);
  session_regenerate_id(true); $_SESSION['admin']=true; respond(['ok'=>true]);
 }
 if ($action === 'logout' && $post) { unset($_SESSION['admin']); respond(['ok'=>true]); }
 $admin = !empty($_SESSION['admin']);
 $cid = (int)($_GET['calendar'] ?? 1);
 $edit = $admin;
 if (!$admin) {
  $token = $_GET['token'] ?? '';
  $q=$db->prepare('SELECT * FROM fc_shares WHERE token_hash=? AND (expires_at IS NULL OR expires_at>UTC_TIMESTAMP())');
  $q->execute([hash('sha256',$token)]); $share=$q->fetch(PDO::FETCH_ASSOC);
  if (!$share) { if ($action==='state') respond(['login'=>true,'csrf'=>$_SESSION['csrf']]); respond(['error'=>'Login required or share link expired'],403); }
  $cid=(int)$share['calendar_id']; $edit=(bool)$share['can_edit'];
 }
 if ($action==='state') {
  $q=$db->prepare('SELECT id,name FROM fc_calendars WHERE id=?'); $q->execute([$cid]); $cal=$q->fetch(PDO::FETCH_ASSOC);
  if (!$cal) respond(['error'=>'Run setup.php first'],404);
  respond(['csrf'=>$_SESSION['csrf'],'admin'=>$admin,'editable'=>$edit,'calendar'=>$cal,'calendars'=>$admin?$db->query('SELECT id,name FROM fc_calendars')->fetchAll(PDO::FETCH_ASSOC):[$cal]]);
 }
 if (in_array($action,['events','resources'],true) && !$post) {
  $table=$action==='events'?'fc_events':'fc_resources'; $q=$db->prepare("SELECT * FROM $table WHERE calendar_id=?"); $q->execute([$cid]); $out=[];
  foreach($q as $row) { $item=json_decode($row['payload'],true); $item['id']=(string)$row['id']; if($action==='events') { $item['extendedProps']['version']=(int)$row['version']; } $out[]=$item; } respond($out);
 }
 if ($action==='shares' && $admin && !$post) { $q=$db->prepare('SELECT id,label,can_edit,expires_at FROM fc_shares WHERE calendar_id=?'); $q->execute([$cid]); respond($q->fetchAll(PDO::FETCH_ASSOC)); }
 if (!$post) respond(['error'=>'Unknown request'],400);
 if (!$edit) respond(['error'=>'This share is read-only'],403);
 if ($action==='move') {
  $items=$input['events']??[];
  if(!is_array($items)||!count($items)||count($items)>100) respond(['error'=>'Invalid move batch'],422);
  foreach($items as $item) if(!validDate($item['start']??null)||(!empty($item['end'])&&(!validDate($item['end'])||new DateTimeImmutable($item['end'])<=new DateTimeImmutable($item['start'])))) respond(['error'=>'Invalid start/end date'],422);
  $db->beginTransaction();
  foreach($items as $item) {
   $q=$db->prepare('SELECT payload FROM fc_events WHERE id=? AND calendar_id=? AND version=? FOR UPDATE'); $q->execute([(int)$item['id'],$cid,(int)$item['version']]); $json=$q->fetchColumn();
   if(!$json) { $db->rollBack(); respond(['error'=>'An event changed in another window. Reload before moving.'],409); }
   $p=json_decode($json,true);
   if(isset($p['rrule'])||isset($p['daysOfWeek'])) { $db->rollBack(); respond(['error'=>'Edit recurrence through the event editor'],422); }
   $p['start']=$item['start'];$p['end']=$item['end']??null;$p['allDay']=!empty($item['allDay']);$p['resourceIds']=$item['resourceIds']??[];unset($p['resourceId']);
   $q=$db->prepare('UPDATE fc_events SET payload=?,version=version+1 WHERE id=? AND calendar_id=?');$q->execute([json_encode($p),(int)$item['id'],$cid]);
  }
  $db->commit();respond(['ok'=>true]);
 }
 if ($action==='save') {
  $event=$input['event']??null;
  if (!is_array($event) || empty($event['title']) || strlen($event['title'])>500 || (!isset($event['start']) && !isset($event['daysOfWeek']) && !isset($event['rrule']))) respond(['error'=>'An event needs a title and start date or recurrence'],422);
  if(isset($event['start'])&&!validDate($event['start'])) respond(['error'=>'Start must be an ISO date/time'],422);
  if(!empty($event['end'])&&(!validDate($event['end'])||(isset($event['start'])&&new DateTimeImmutable($event['end'])<=new DateTimeImmutable($event['start'])))) respond(['error'=>'End must be a valid ISO date/time after start (exclusive)'],422);
  if(isset($event['extendedProps'])&&!is_array($event['extendedProps'])) respond(['error'=>'extendedProps must be an object'],422);
  if (isset($event['url']) && !preg_match('~^https?://~i',$event['url'])) respond(['error'=>'Event URLs must use http or https'],422);
  $id=(int)($input['id']??0); $version=(int)($input['version']??0); unset($event['id']); unset($event['extendedProps']['version']);
  $json=json_encode($event); if(strlen($json)>65536) respond(['error'=>'Event too large'],422);
  if($id) { $q=$db->prepare('UPDATE fc_events SET payload=?,version=version+1 WHERE id=? AND calendar_id=? AND version=?'); $q->execute([$json,$id,$cid,$version]); if(!$q->rowCount()) respond(['error'=>'Event changed in another window. Reload before editing.'],409); }
  else { $q=$db->prepare('INSERT INTO fc_events(calendar_id,payload) VALUES (?,?)'); $q->execute([$cid,$json]); $id=(int)$db->lastInsertId(); }
  respond(['id'=>$id,'ok'=>true]);
 }
 if($action==='delete') { $q=$db->prepare('DELETE FROM fc_events WHERE id=? AND calendar_id=? AND version=?'); $q->execute([(int)$input['id'],$cid,(int)$input['version']]); if(!$q->rowCount()) respond(['error'=>'Event changed. Reload first.'],409); respond(['ok'=>true]); }
 if(!$admin) respond(['error'=>'Owner access required'],403);
 if($action==='calendar') { $name=trim($input['name']??''); if(!$name || strlen($name)>160) respond(['error'=>'Calendar name required (maximum 160 bytes)'],422); $q=$db->prepare('INSERT INTO fc_calendars(name) VALUES (?)'); $q->execute([$name]); respond(['id'=>$db->lastInsertId()]); }
 if($action==='resource') { $r=$input['resource']??[]; if(empty($r['title'])) respond(['error'=>'Resource title required'],422); unset($r['id']); $q=$db->prepare('INSERT INTO fc_resources(calendar_id,payload) VALUES (?,?)'); $q->execute([$cid,json_encode($r)]); respond(['ok'=>true]); }
 if($action==='deleteResource') { $q=$db->prepare('DELETE FROM fc_resources WHERE id=? AND calendar_id=?'); $q->execute([(int)$input['id'],$cid]); respond(['ok'=>true]); }
 if($action==='share') {
  $token=bin2hex(random_bytes(32)); $expires=null;
  if(!empty($input['expires'])) { $dt=DateTime::createFromFormat('!Y-m-d',$input['expires'],new DateTimeZone('UTC')); if(!$dt || $dt->format('Y-m-d')!==$input['expires']) respond(['error'=>'Invalid expiration date'],422); $expires=$dt->format('Y-m-d 00:00:00'); }
  $q=$db->prepare('INSERT INTO fc_shares(calendar_id,token_hash,label,can_edit,expires_at) VALUES (?,?,?,?,?)'); $q->execute([$cid,hash('sha256',$token),substr($input['label']??'Share',0,160),!empty($input['edit'])?1:0,$expires]); respond(['token'=>$token]);
 }
 if($action==='revoke') { $q=$db->prepare('DELETE FROM fc_shares WHERE id=? AND calendar_id=?'); $q->execute([(int)$input['id'],$cid]); respond(['ok'=>true]); }
 respond(['error'=>'Unknown action'],400);
} catch (Throwable $e) { error_log((string)$e); respond(['error'=>'Database operation failed. Check config.php, run setup.php, and inspect the PHP error log.'],500); }
