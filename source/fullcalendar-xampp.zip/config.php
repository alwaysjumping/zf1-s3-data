<?php
// PHP 7.4. Change these values for your XAMPP installation.
return [
    'dsn' => 'mysql:host=127.0.0.1;dbname=fullcalendar;charset=utf8mb4',
    'user' => 'root',
    'password' => '',
    'admin_password' => 'change-this-password',
    'scheduler_license_key' => '', // Blank enables the local evaluation notice.
];
