# Tour Studio

PHP 7.4 + MariaDB + locally vendored Intro.js 8.6.0. Open http://localhost:4050/ with document root E:/www/interactive_product_tour/public.

## Database
Import database/schema.sql into MariaDB. Defaults in app/config.php are 127.0.0.1:3306, database interactive_product_tour, root with an empty password (local XAMPP only). Override with TOUR_DB_HOST, TOUR_DB_PORT, TOUR_DB_NAME, TOUR_DB_USER, TOUR_DB_PASSWORD or edit the config. Use a dedicated database account outside local development. No public installer is exposed.

## Examples and feature coverage
- Essentials: programmatic steps, floating welcome, titles, HTML, per-step positions, buttons, bullets, progress, step numbers and keyboard navigation.
- HTML-driven: data-intro, data-title, data-step; hints support data-hint, data-hint-position and data-hint-animation via introJs.hint().addHints() without a hints array.
- Advanced: per-step tooltip/highlight classes, disableInteraction, auto-position, scroll behavior.
- Async: promise-based onBeforeChange, cancel a transition by returning false, wait for content, refresh layout.
- Dynamic: addSteps, addStep, goToStep and goToStepNumber (enter 10 for the appended step).
- Hints: addHints, hideHints, showHints, removeHints, click and dialog-close callbacks; all public hint options in the editor. Individual hints can be controlled with showHint(index), hideHint(index), removeHint(index), showHintDialog(index), hideHintDialog().
- Every tour option in 8.6.0 is exposed in the JSON editor, including labels, classes, grouping, padding, opacity, cookies, themes, languages, position precedence and HTML rendering. Structured steps are supplied by each example. Built-in light/dark/auto themes plus a custom CSS class example.
- Live controls: previousStep, nextStep, refresh, exit, jump and resume.
- Lifecycle log: onStart, onBeforeChange, onChange, onAfterChange, onBeforeExit, onComplete, onSkip, onExit, onHintsAdded, onHintClick, onHintDialogClose.
- Progress and events stored in MariaDB, scoped to anonymous PHP sessions. Writes use CSRF tokens, validation, prepared statements and transactions. Database failure is shown in the UI; tours still run.

Additional public API methods: setOption/getOption, setOptions, clone, getSteps/getStep, setSteps, getCurrentStep, getDirection, isActive, hasStarted, isLastStep, setDontShowAgain, setTheme/getTheme. They are available through the live `tour`/`hints` variables in the browser developer console. Framework adapters and licensed services are outside this plain PHP test project.

Intro.js is AGPL-3.0; review https://introjs.com/ licensing before commercial use. Vendor license is in public/assets/vendor/LICENSE. No build system or Composer dependencies are required.

## Verification
PHP 7.4 syntax checks and real-browser integration checks passed: six examples, guarded async transition, dynamic jump, individual hint dialog, persisted resume, Modern theme loading, invalid CSRF token (403), invalid payload (422), and mobile width. `verify.cjs` uses this machine's bundled Playwright runtime and installed Microsoft Edge.

All six distributed CSS themes and the RTL stylesheet are vendored locally. The theme selector offers light/dark/system, Modern, Royal, Nassim, Nazanin, Flattener and Studio custom. The More public API methods panel accepts JSON argument arrays: e.g. `[0]` for hints.showHintDialog, `["showProgress", true]` for tour.setOption, or `["dark"]` for tour.setTheme. Introspection results appear in the event log.

The library's jump methods in this version do not await their internal step changes. The application prepares the preceding step before calling goToStep/goToStepNumber so the jump and resume buttons work reliably.
