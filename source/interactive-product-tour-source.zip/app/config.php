<?php
return [
    'host' => getenv('TOUR_DB_HOST') ?: '127.0.0.1',
    'port' => getenv('TOUR_DB_PORT') ?: '3306',
    'name' => getenv('TOUR_DB_NAME') ?: 'interactive_product_tour',
    'user' => getenv('TOUR_DB_USER') ?: 'root',
    'password' => getenv('TOUR_DB_PASSWORD') ?: '',
];
