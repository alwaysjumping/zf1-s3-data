<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require __DIR__ . '/../app/database.php';
if (!isset($_SESSION['visitor'])) { $_SESSION['visitor'] = bin2hex(random_bytes(16)); }
if (!isset($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(24)); }
try {
    $db = database();
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $q = $db->prepare('SELECT tour_key, step_index, status, updated_at FROM tour_progress WHERE visitor_id=?');
        $q->execute([$_SESSION['visitor']]);
        echo json_encode(['connected'=>true, 'progress'=>$q->fetchAll(PDO::FETCH_ASSOC)]); exit;
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
    if (!hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) { http_response_code(403); echo json_encode(['error'=>'Invalid session token']); exit; }
    $data = json_decode(file_get_contents('php://input'), true);
    $key = $data['tour'] ?? ''; $event = $data['event'] ?? ''; $step = $data['step'] ?? 0;
    if (!in_array($key, ['welcome','attributes','advanced','async','dynamic','hints'], true) || !in_array($event, ['start','change','complete','exit','skip','hintClick','hintClose','reset'], true) || !is_int($step) || $step < 0 || $step > 100) { http_response_code(422); echo json_encode(['error'=>'Invalid event']); exit; }
    $db->beginTransaction();
    if ($event === 'reset') {
        $q=$db->prepare('DELETE FROM tour_progress WHERE visitor_id=?'); $q->execute([$_SESSION['visitor']]);
    } else {
        $q=$db->prepare('INSERT INTO tour_events(visitor_id,tour_key,event_name,step_index) VALUES(?,?,?,?)');
        $q->execute([$_SESSION['visitor'],$key,$event,$step]);
        if ($key !== 'hints') {
            $status = $event === 'complete' ? 'completed' : ($event === 'exit' || $event === 'skip' ? 'paused' : 'started');
            $q=$db->prepare("INSERT INTO tour_progress(visitor_id,tour_key,step_index,status) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE step_index=VALUES(step_index),status=IF(status='completed' AND VALUES(status)='paused',status,VALUES(status))");
            $q->execute([$_SESSION['visitor'],$key,$step,$status]);
        }
    }
    $db->commit(); echo json_encode(['saved'=>true]);
} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) { $db->rollBack(); }
    http_response_code(503); echo json_encode(['connected'=>false,'error'=>'MariaDB is unavailable. Check app/config.php and import database/schema.sql.']);
}
