# Deployment

## Requirements
- PHP 7.4 with PDO MySQL and sessions enabled.
- MariaDB with access to create/import tables.
- Apache or another PHP-capable web server.
- No Composer, npm, or build step is required. Intro.js assets are bundled.

## Deploy
1. Extract this archive into the application directory on your server.
2. Set the website document root to the extracted `public` directory. Keep `app` and `database` outside the public document root.
3. Import `database/schema.sql` into MariaDB. It creates the `interactive_product_tour` database and both tables. On hosting with a pre-created database, select that database and import only the CREATE TABLE statements, omitting CREATE DATABASE and USE.
4. Edit `app/config.php` with your server's database host, port, database name, username, and password. Alternatively configure TOUR_DB_HOST, TOUR_DB_PORT, TOUR_DB_NAME, TOUR_DB_USER, and TOUR_DB_PASSWORD in the PHP process environment. An .env file is not automatically loaded.
5. Use a database account with SELECT, INSERT, UPDATE, DELETE privileges on the application database. The schema import account needs separate creation privileges.
6. Enable HTTPS and make sure PHP's session save directory is writable by the PHP process. Application source files only need read access.
7. Open the site. Confirm “MariaDB connected”, complete a tour, and test resume after leaving another tour midway.

Progress belongs to an anonymous PHP session. Deploying the source does not migrate existing session progress. No database records or local credentials are included in this archive; app/config.php contains the original XAMPP defaults and must be configured on the destination.

## Apache example
Replace the domain and filesystem paths for your server. Configure PHP handling using your server's existing PHP module or PHP-FPM setup.

```apache
<VirtualHost *:80>
    ServerName tour.example.com
    DocumentRoot "/var/www/interactive_product_tour/public"
    <Directory "/var/www/interactive_product_tour/public">
        DirectoryIndex index.php
        Options -Indexes
        AllowOverride None
        Require all granted
    </Directory>
</VirtualHost>
```

Use your hosting panel or server configuration for the HTTPS virtual host. URL rewriting is not needed.

## Included source
- public/index.php: playground page
- public/api.php: progress and event API
- public/assets/app.js: tour examples and controls
- public/assets/style.css: interface styles
- public/assets/vendor/: Intro.js, themes, RTL styles and license
- app/config.php: database settings
- app/database.php: PDO connection
- database/schema.sql: database schema
- README.md: feature documentation

Intro.js's license is included in public/assets/vendor/LICENSE.
