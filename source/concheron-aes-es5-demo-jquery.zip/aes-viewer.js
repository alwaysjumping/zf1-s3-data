(function ($, window, document) {
    'use strict';

    function base64ToBytes(value) {
        var binary = window.atob(value);
        var bytes = new Uint8Array(binary.length);
        var i;
        for (i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }

    function decryptImage(data) {
        var keyBytes = base64ToBytes(data.key);
        var iv = base64ToBytes(data.iv);
        var ciphertext = base64ToBytes(data.ciphertext);
        var tag = base64ToBytes(data.tag);
        var combined = new Uint8Array(ciphertext.length + tag.length);

        if (keyBytes.length !== 32 || iv.length !== 12 || tag.length !== 16) {
            throw new Error('Invalid AES-256-GCM parameters');
        }

        combined.set(ciphertext, 0);
        combined.set(tag, ciphertext.length);

        return window.crypto.subtle.importKey(
            'raw', keyBytes, { name: 'AES-GCM' }, false, ['decrypt']
        ).then(function (key) {
            return window.crypto.subtle.decrypt(
                { name: 'AES-GCM', iv: iv, tagLength: 128 },
                key,
                combined
            );
        }).then(function (plaintext) {
            return new Blob([plaintext], { type: 'image/png' });
        });
    }

    function showImage(blob) {
        var image = document.getElementById('sec-page');
        var imageUrl = window.URL.createObjectURL(blob);
        image.onload = function () {
            window.URL.revokeObjectURL(imageUrl);
        };
        image.onerror = function () {
            window.URL.revokeObjectURL(imageUrl);
            $('#status').text('Unable to display decrypted image.');
        };
        image.src = imageUrl;
    }

    function loadEncryptedImage() {
        if (!window.crypto || !window.crypto.subtle) {
            $('#status').text('Web Crypto unavailable. Use HTTPS or localhost in a supported browser.');
            return;
        }

        $('#status').text('Loading encrypted image...');
        $.ajax({
            url: 'encrypt-image.php',
            type: 'GET',
            dataType: 'json',
            cache: false,
            timeout: 30000,
            success: function (response) {
                try {
                    decryptImage(response).then(function (blob) {
                        showImage(blob);
                        $('#status').text('Decrypted successfully.');
                    }, function (error) {
                        $('#status').text('AES decryption failed: ' + error.message);
                    });
                } catch (error) {
                    $('#status').text('Invalid encrypted response: ' + error.message);
                }
            },
            error: function (xhr, status, error) {
                $('#status').text('AJAX failed: ' + (error || status) + ' (HTTP ' + xhr.status + ')');
            }
        });
    }

    $(loadEncryptedImage);
}(jQuery, window, document));
