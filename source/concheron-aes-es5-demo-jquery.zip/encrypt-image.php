<?php
declare(strict_types=1);
header('Content-Type: application/json');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$image = @file_get_contents(__DIR__ . '/AES-970x1024.jpg');
if ($image === false) { http_response_code(404); echo json_encode(array('error'=>'Image not found')); exit; }
$key = random_bytes(32);
$iv = random_bytes(12);
$tag = '';
$ciphertext = openssl_encrypt($image, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
if ($ciphertext === false) { http_response_code(500); echo json_encode(array('error'=>'Encryption failed')); exit; }
echo json_encode(array('key'=>base64_encode($key), 'iv'=>base64_encode($iv), 'ciphertext'=>base64_encode($ciphertext), 'tag'=>base64_encode($tag), 'mimeType'=>'image/png'));
