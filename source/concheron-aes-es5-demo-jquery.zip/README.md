# Concheron AES-256-GCM image demonstration — jQuery AJAX

- PHP 7.4-compatible OpenSSL AES-256-GCM server encryption.
- JavaScript written in ES5 syntax; Web Crypto API for AES decryption.
- jQuery 3.6.1 included locally under `js/jquery.min.js` (OpenJS Foundation; MIT license).
- Uses `$.ajax()` instead of direct `XMLHttpRequest`.

## Run

1. Put an already-watermarked PNG at `watermarked-page.png` (a tiny sample PNG is included).
2. From the extracted folder, run `php -S 127.0.0.1:8000`.
3. Open `http://localhost:8000/index.html` in a modern Firefox ESR browser.
4. For network deployment use HTTPS and authenticated SEC APIs.

## Security warning

**Demonstration only.** The server returns the AES key in the same JSON response as the ciphertext. This is not production key management and does not stop an authorized client from obtaining decrypted pixels. Add authentication, authorization, server-side watermarking, and proper key management before SEC use.

PHP OpenSSL returns the GCM ciphertext and 16-byte tag separately; Web Crypto expects the tag appended to ciphertext. The IV is a fresh random 12 bytes for each encryption.
