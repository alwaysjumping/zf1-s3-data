<?php
class S3_Pivot_AxisTree
{
    public $root; private $prefix; private $nodes=array(); private $pathIndex=array();
    public function __construct($prefix) {
        $this->prefix=$prefix; $this->root=array('id'=>$prefix.':root','key'=>null,'label'=>'Grand Total','field'=>null,'level'=>-1,'parentId'=>null,'children'=>array());
        $this->nodes[$this->root['id']]=$this->root;
    }
    public function insertPath(array $parts) {
        $parent=$this->root['id']; $path='';
        foreach ($parts as $level=>$p) {
            $path.='|'.$p['field'].'='.json_encode($p['key']); $id=$this->prefix.':'.substr(hash('sha256',$path),0,20);
            if (!isset($this->nodes[$id])) {
                $node=array('id'=>$id,'key'=>$p['key'],'label'=>$p['label'],'field'=>$p['field'],'level'=>$level,'parentId'=>$parent,'children'=>array());
                $this->nodes[$id]=$node; $this->nodes[$parent]['children'][]=$id;
            }
            $parent=$id;
        }
        return $parent;
    }
    public function ancestorsInclusive($id) { $out=array(); while ($id!==null && isset($this->nodes[$id])) { $out[]=$id; $id=$this->nodes[$id]['parentId']; } return $out; }
    public function exportNode($id) { $n=$this->nodes[$id]; $children=array(); foreach($n['children'] as $cid)$children[]=$this->exportNode($cid); $n['children']=$children; return $n; }
    public function export() { return $this->exportNode($this->root['id']); }
}
