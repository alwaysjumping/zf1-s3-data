<?php
class S3_Pivot_DefinitionValidator
{
    public function validate(array $definition, array $dataset)
    {
        $errors = array();
        $fields = $dataset['fields'];
        if (empty($definition['values'])) {
            $errors[] = array('code' => 'VALUE_REQUIRED', 'message' => 'At least one value is required.');
        }
        if (empty($definition['rows']) && empty($definition['columns'])) {
            $errors[] = array('code' => 'AXIS_REQUIRED', 'message' => 'At least one row or column field is required.');
        }
        foreach (array('rows','columns','filters','values') as $zone) {
            foreach (isset($definition[$zone]) ? $definition[$zone] : array() as $item) {
                $code = isset($item['field']) ? $item['field'] : '';
                if (!isset($fields[$code])) {
                    $errors[] = array('code' => 'FIELD_NOT_FOUND', 'message' => 'Unknown field: ' . $code);
                    continue;
                }
                if ($zone === 'values') {
                    $agg = strtolower(isset($item['aggregation']) ? $item['aggregation'] : '');
                    if (!in_array($agg, $fields[$code]['aggregations'], true)) {
                        $errors[] = array('code' => 'AGGREGATION_NOT_ALLOWED', 'message' => 'Aggregation is not allowed for ' . $code);
                    }
                }
            }
        }
        if ($errors) {
            throw new InvalidArgumentException(json_encode($errors));
        }
        return true;
    }
}
