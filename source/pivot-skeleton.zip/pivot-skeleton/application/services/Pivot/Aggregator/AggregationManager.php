<?php
class S3_Pivot_AggregationManager
{
    public function stateFromRecord(array $record, array $measure, $index) {
        $agg=strtolower($measure['aggregation']);
        if ($agg==='avg') return array('sum'=>(float)$record['m'.$index.'_sum'], 'count'=>(int)$record['m'.$index.'_count']);
        $v=isset($record['m'.$index]) ? $record['m'.$index] : null;
        if ($agg==='sum') return array('sum'=>(float)$v);
        if ($agg==='count') return array('count'=>(int)$v);
        if ($agg==='min') return array('min'=>$v===null?null:(float)$v);
        if ($agg==='max') return array('max'=>$v===null?null:(float)$v);
        throw new InvalidArgumentException('Unsupported aggregation.');
    }
    public function merge($left,$right,$agg) {
        if ($left===null) return $right; $agg=strtolower($agg);
        if ($agg==='sum') return array('sum'=>$left['sum']+$right['sum']);
        if ($agg==='count') return array('count'=>$left['count']+$right['count']);
        if ($agg==='avg') return array('sum'=>$left['sum']+$right['sum'],'count'=>$left['count']+$right['count']);
        if ($agg==='min') return array('min'=>$left['min']===null?$right['min']:($right['min']===null?$left['min']:min($left['min'],$right['min'])));
        if ($agg==='max') return array('max'=>$left['max']===null?$right['max']:($right['max']===null?$left['max']:max($left['max'],$right['max'])));
    }
    public function finalize($state,$agg) {
        if ($state===null) return null; $agg=strtolower($agg);
        if ($agg==='sum') return $state['sum']; if ($agg==='count') return $state['count'];
        if ($agg==='avg') return $state['count'] ? $state['sum']/$state['count'] : null;
        if ($agg==='min') return $state['min']; if ($agg==='max') return $state['max']; return null;
    }
}
