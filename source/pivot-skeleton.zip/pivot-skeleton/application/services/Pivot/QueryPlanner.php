<?php
class S3_Pivot_QueryPlanner
{
    public function build(array $definition, array $dataset, array $securityFilters)
    {
        return array(
            'source'=>$dataset['source'], 'fields'=>$dataset['fields'],
            'rows'=>isset($definition['rows'])?$definition['rows']:array(),
            'columns'=>isset($definition['columns'])?$definition['columns']:array(),
            'values'=>isset($definition['values'])?$definition['values']:array(),
            'filters'=>isset($definition['filters'])?$definition['filters']:array(),
            'securityFilters'=>$securityFilters,
        );
    }
}
