<?php
require_once __DIR__.'/AxisTree.php';
require_once __DIR__.'/Aggregator/AggregationManager.php';
class S3_Pivot_ResultBuilder
{
    public function build(array $records,array $plan) {
        $rows=new S3_Pivot_AxisTree('r'); $cols=new S3_Pivot_AxisTree('c'); $mgr=new S3_Pivot_AggregationManager(); $cells=array();
        $rowCount=count($plan['rows']); $allDims=array_merge($plan['rows'],$plan['columns']);
        foreach($records as $record) {
            $rp=array(); $cp=array();
            foreach($allDims as $i=>$d) { $p=array('field'=>$d['field'],'key'=>$record['d'.$i.'_key'],'label'=>$record['d'.$i.'_label']); if($i<$rowCount)$rp[]=$p; else $cp[]=$p; }
            $rid=$rows->insertPath($rp); $cid=$cols->insertPath($cp);
            foreach($plan['values'] as $mi=>$m) {
                $state=$mgr->stateFromRecord($record,$m,$mi);
                foreach($rows->ancestorsInclusive($rid) as $ra) foreach($cols->ancestorsInclusive($cid) as $ca) {
                    $key=$ra.'|'.$ca.'|'.$m['id']; $old=isset($cells[$key])?$cells[$key]:null; $cells[$key]=$mgr->merge($old,$state,$m['aggregation']);
                }
            }
        }
        $outCells=array(); foreach($cells as $key=>$state) { list($r,$c,$mid)=explode('|',$key,3); $measure=null; foreach($plan['values'] as $m)if($m['id']===$mid){$measure=$m;break;} $outCells[]=array('rowId'=>$r,'columnId'=>$c,'measureId'=>$mid,'value'=>$mgr->finalize($state,$measure['aggregation'])); }
        return array('rows'=>$rows->export(),'columns'=>$cols->export(),'measures'=>$plan['values'],'cells'=>$outCells);
    }
}
