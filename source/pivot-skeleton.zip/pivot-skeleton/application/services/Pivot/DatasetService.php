<?php
class S3_Pivot_DatasetService
{
    public function get($code)
    {
        if ($code !== 'SALES') {
            throw new InvalidArgumentException('Dataset not found.');
        }
        return array(
            'code' => 'SALES', 'version' => 1, 'name' => 'Sales', 'source' => 'rpt_sales',
            'fields' => array(
                'department' => array('code'=>'department','name'=>'Department','role'=>'dimension','type'=>'string','key'=>'department_id','label'=>'department_name','allowRow'=>true,'allowColumn'=>true,'allowFilter'=>true,'allowValue'=>false,'aggregations'=>array()),
                'product' => array('code'=>'product','name'=>'Product','role'=>'dimension','type'=>'string','key'=>'product_id','label'=>'product_name','allowRow'=>true,'allowColumn'=>true,'allowFilter'=>true,'allowValue'=>false,'aggregations'=>array()),
                'order_date' => array('code'=>'order_date','name'=>'Order Date','role'=>'dimension','type'=>'date','key'=>'order_date','label'=>'order_date','allowRow'=>true,'allowColumn'=>true,'allowFilter'=>true,'allowValue'=>false,'dateGroups'=>array('year','quarter','month','day'),'aggregations'=>array()),
                'sales_amount' => array('code'=>'sales_amount','name'=>'Sales Amount','role'=>'measure','type'=>'decimal','value'=>'sales_amount','allowRow'=>false,'allowColumn'=>false,'allowFilter'=>true,'allowValue'=>true,'aggregations'=>array('sum','count','avg','min','max')),
                'profit_amount' => array('code'=>'profit_amount','name'=>'Profit Amount','role'=>'measure','type'=>'decimal','value'=>'profit_amount','allowRow'=>false,'allowColumn'=>false,'allowFilter'=>true,'allowValue'=>true,'aggregations'=>array('sum','count','avg','min','max')),
            )
        );
    }
}
