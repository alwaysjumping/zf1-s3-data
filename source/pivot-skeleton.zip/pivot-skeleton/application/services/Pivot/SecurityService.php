<?php
class S3_Pivot_SecurityService
{
    public function getMandatoryFilters(array $user, array $dataset)
    {
        // Replace this demo rule with your real authorization provider.
        if (isset($user['company_id'])) {
            return array(array('column'=>'company_id','operator'=>'eq','value'=>(int)$user['company_id']));
        }
        return array();
    }
}
