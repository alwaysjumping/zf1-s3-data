<?php
class S3_Pivot_QueryBuilder
{
    private function qi($id) {
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $id)) throw new InvalidArgumentException('Unsafe identifier.');
        return '`'.$id.'`';
    }
    public function build(array $plan)
    {
        $select=array(); $group=array(); $where=array(); $params=array(); $dim=0;
        foreach (array_merge($plan['rows'],$plan['columns']) as $item) {
            $f=$plan['fields'][$item['field']]; $groupCode=isset($item['group'])?$item['group']:null;
            if ($f['type']==='date' && $groupCode) {
                $col=$this->qi($f['key']);
                if ($groupCode==='year') {$expr='YEAR('.$col.')'; $label=$expr;}
                elseif ($groupCode==='quarter') {$expr='QUARTER('.$col.')'; $label="CONCAT('Q',QUARTER(".$col."))";}
                elseif ($groupCode==='month') {$expr='MONTH('.$col.')'; $label="DATE_FORMAT(".$col.",'%b')";}
                else {$expr='DATE('.$col.')'; $label=$expr;}
                $select[]="$expr AS d{$dim}_key"; $select[]="$label AS d{$dim}_label"; $group[]=$expr;
            } else {
                $key=$this->qi($f['key']); $label=$this->qi($f['label']);
                $select[]="$key AS d{$dim}_key"; $select[]="$label AS d{$dim}_label"; $group[]=$key; $group[]=$label;
            }
            $dim++;
        }
        foreach ($plan['values'] as $i=>$item) {
            $f=$plan['fields'][$item['field']]; $col=$this->qi($f['value']); $agg=strtolower($item['aggregation']);
            if ($agg==='avg') { $select[]="SUM($col) AS m{$i}_sum"; $select[]="COUNT($col) AS m{$i}_count"; }
            else { $fn=strtoupper($agg); $select[]="$fn($col) AS m{$i}"; }
        }
        foreach ($plan['filters'] as $filter) {
            $f=$plan['fields'][$filter['field']]; $col=$this->qi(isset($f['value'])?$f['value']:$f['key']);
            if ($f['type']==='date' && isset($filter['group']) && $filter['group']==='year' && $filter['operator']==='eq') {
                $y=(int)$filter['value']; $where[]="$col >= ? AND $col < ?"; $params[]=sprintf('%04d-01-01',$y); $params[]=sprintf('%04d-01-01',$y+1);
            } elseif ($filter['operator']==='eq') { $where[]="$col = ?"; $params[]=$filter['value']; }
            else { throw new InvalidArgumentException('Filter operator not implemented in skeleton.'); }
        }
        foreach ($plan['securityFilters'] as $filter) {
            $col=$this->qi($filter['column']); $where[]="$col = ?"; $params[]=$filter['value'];
        }
        $sql='SELECT '.implode(', ',$select).' FROM '.$this->qi($plan['source']);
        if ($where) $sql.=' WHERE '.implode(' AND ',$where);
        if ($group) $sql.=' GROUP BY '.implode(', ',$group);
        $sql.=' LIMIT 10001';
        return array('sql'=>$sql,'params'=>$params);
    }
}
