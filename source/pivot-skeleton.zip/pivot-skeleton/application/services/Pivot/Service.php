<?php
require_once __DIR__.'/DatasetService.php'; require_once __DIR__.'/DefinitionValidator.php'; require_once __DIR__.'/SecurityService.php'; require_once __DIR__.'/QueryPlanner.php'; require_once __DIR__.'/QueryBuilder.php'; require_once __DIR__.'/ResultBuilder.php';
class S3_Pivot_Service
{
    private $pdo;
    public function __construct(PDO $pdo){$this->pdo=$pdo;}
    public function execute(array $definition,array $user) {
        $ds=(new S3_Pivot_DatasetService())->get($definition['dataset']['code']);
        (new S3_Pivot_DefinitionValidator())->validate($definition,$ds);
        $security=(new S3_Pivot_SecurityService())->getMandatoryFilters($user,$ds);
        $plan=(new S3_Pivot_QueryPlanner())->build($definition,$ds,$security);
        $query=(new S3_Pivot_QueryBuilder())->build($plan); $st=$this->pdo->prepare($query['sql']); $st->execute($query['params']); $records=$st->fetchAll(PDO::FETCH_ASSOC);
        if(count($records)>10000) throw new RuntimeException('RESULT_TOO_LARGE');
        $result=(new S3_Pivot_ResultBuilder())->build($records,$plan);
        $result['meta']=array('dataset'=>$ds['code'],'aggregateRows'=>count($records),'executionId'=>'PVT-'.bin2hex(random_bytes(8)));
        return $result;
    }
}
