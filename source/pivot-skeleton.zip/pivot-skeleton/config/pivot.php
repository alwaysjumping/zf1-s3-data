<?php
return array(
    'db' => array(
        'dsn' => 'mysql:host=127.0.0.1;dbname=pivot_demo;charset=utf8mb4',
        'username' => 'pivot_user',
        'password' => 'change_me',
    ),
    'limits' => array(
        'max_aggregate_rows' => 10001,
        'max_result_rows' => 10000,
        'max_result_columns' => 500,
        'max_result_cells' => 200000,
    ),
);
