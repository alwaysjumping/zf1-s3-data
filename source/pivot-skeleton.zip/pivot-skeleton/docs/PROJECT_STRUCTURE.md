# Project Structure

```text
pivot-skeleton/
├── application/
│   └── services/Pivot/
│       ├── Service.php
│       ├── DatasetService.php
│       ├── DefinitionValidator.php
│       ├── SecurityService.php
│       ├── QueryPlanner.php
│       ├── QueryBuilder.php
│       ├── AxisTree.php
│       ├── ResultBuilder.php
│       └── Aggregator/
│           └── AggregationManager.php
├── config/
│   └── pivot.php
├── public/
│   ├── api.php
│   ├── index.html
│   ├── css/pivot.css
│   ├── js/pivot/
│   │   ├── S3PivotApi.js
│   │   ├── S3PivotController.js
│   │   └── S3PivotGridAdapter.js
│   └── vendor/dhtmlx/README.txt
├── sql/
│   ├── 001_schema.sql
│   └── 002_sample_data.sql
└── README.md
```

## Request Flow

```text
index.html
  ↓
S3PivotController
  ↓
S3PivotApi
  ↓
api.php
  ↓
S3_Pivot_Service
  ├─ DatasetService
  ├─ DefinitionValidator
  ├─ SecurityService
  ├─ QueryPlanner
  ├─ QueryBuilder
  │      ↓
  │   MariaDB
  │      ↓
  └─ ResultBuilder
       ├─ AxisTree
       └─ AggregationManager
              ↓
          Pivot JSON
              ↓
      S3PivotGridAdapter
              ↓
          dhtmlxGrid
```

## Production Integration
The API entry point is intentionally framework-neutral. In an existing MVC application, move its dispatch logic into the application's API controller while keeping the Pivot service classes independent.
