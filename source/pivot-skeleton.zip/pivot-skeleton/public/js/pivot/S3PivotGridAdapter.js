(function(global){
 function GridAdapter(cell){this.cell=cell;this.grid=null;}
 GridAdapter.prototype.render=function(result){
   this.cell.detachObject(true); this.grid=this.cell.attachGrid();
   var cols=[], labels=['Rows'], widths=['220'], types=['ro'], aligns=['left'];
   function leaves(n,out){if(!n.children||!n.children.length){out.push(n);return;} for(var i=0;i<n.children.length;i++)leaves(n.children[i],out);}
   var cleaves=[]; leaves(result.columns,cleaves); if(cleaves.length===1&&cleaves[0].id==='c:root') cleaves=[result.columns];
   for(var c=0;c<cleaves.length;c++) for(var m=0;m<result.measures.length;m++){cols.push({c:cleaves[c],m:result.measures[m]});labels.push((cleaves[c].label||'Total')+' / '+(result.measures[m].label||result.measures[m].id));widths.push('130');types.push('ron');aligns.push('right');}
   this.grid.setHeader(labels.join(',')); this.grid.setInitWidths(widths.join(',')); this.grid.setColTypes(types.join(',')); this.grid.setColAlign(aligns.join(',')); this.grid.init();
   var map={}; for(var i=0;i<result.cells.length;i++){var x=result.cells[i];map[x.rowId+'|'+x.columnId+'|'+x.measureId]=x.value;}
   var rows=[]; function walk(n,depth){if(n.id!=='r:root'){var data=[Array(depth+1).join('   ')+n.label];for(var j=0;j<cols.length;j++){var k=n.id+'|'+cols[j].c.id+'|'+cols[j].m.id;data.push(map.hasOwnProperty(k)?map[k]:'');}rows.push({id:n.id,data:data});}for(var z=0;z<(n.children||[]).length;z++)walk(n.children[z],depth+1);} walk(result.rows,0);
   var grand=['Grand Total'];for(var q=0;q<cols.length;q++){var g='r:root|'+cols[q].c.id+'|'+cols[q].m.id;grand.push(map.hasOwnProperty(g)?map[g]:'');}rows.push({id:'grand',data:grand});
   this.grid.parse({rows:rows},'json');
 };
 global.S3PivotGridAdapter=GridAdapter;
}(window));
