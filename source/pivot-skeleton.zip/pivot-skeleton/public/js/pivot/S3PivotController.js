(function(global){
 function Controller(api,grid){this.api=api;this.grid=grid;this.definition={version:1,dataset:{code:'SALES',version:1},rows:[{field:'department',subtotal:true},{field:'product',subtotal:true}],columns:[{field:'order_date',group:'year'},{field:'order_date',group:'quarter'}],values:[{id:'revenue',field:'sales_amount',aggregation:'sum',label:'Revenue'},{id:'profit',field:'profit_amount',aggregation:'sum',label:'Profit'}],filters:[{field:'order_date',group:'year',operator:'eq',value:2026}],options:{subtotals:true,rowGrandTotal:true,columnGrandTotal:true}};}
 Controller.prototype.run=function(){var self=this;this.api.execute(this.definition,function(r){if(!r.success){alert(r.error.message||'Pivot error');return;}self.grid.render(r.data);});};
 global.S3PivotController=Controller;
}(window));
