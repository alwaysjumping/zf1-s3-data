(function(global){
  function Api(base){this.base=base||'api.php?path=';}
  Api.prototype.getDataset=function(cb){dhtmlxAjax.get(this.base+'dataset/SALES',function(r){cb(JSON.parse(r.xmlDoc.responseText));});};
  Api.prototype.execute=function(def,cb){dhtmlxAjax.post(this.base+'execute',JSON.stringify(def),function(r){cb(JSON.parse(r.xmlDoc.responseText));});};
  global.S3PivotApi=Api;
}(window));
