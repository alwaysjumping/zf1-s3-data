<?php
header('Content-Type: application/json; charset=utf-8');
$config=require dirname(__DIR__).'/config/pivot.php';
require_once dirname(__DIR__).'/application/services/Pivot/Service.php';
require_once dirname(__DIR__).'/application/services/Pivot/DatasetService.php';
try {
    $path=isset($_GET['path'])?$_GET['path']:'';
    if ($path==='dataset/SALES') { echo json_encode(array('success'=>true,'data'=>(new S3_Pivot_DatasetService())->get('SALES'))); exit; }
    if ($path==='execute' && $_SERVER['REQUEST_METHOD']==='POST') {
        $definition=json_decode(file_get_contents('php://input'),true); if(!is_array($definition)) throw new InvalidArgumentException('Invalid JSON.');
        $pdo=new PDO($config['db']['dsn'],$config['db']['username'],$config['db']['password'],array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        // Demo identity only. Replace with your application's authenticated user context.
        $user=array('id'=>1,'company_id'=>1);
        $data=(new S3_Pivot_Service($pdo))->execute($definition,$user); echo json_encode(array('success'=>true,'data'=>$data)); exit;
    }
    http_response_code(404); echo json_encode(array('success'=>false,'error'=>array('code'=>'NOT_FOUND')));
} catch(Exception $e) { http_response_code(400); echo json_encode(array('success'=>false,'error'=>array('code'=>'PIVOT_ERROR','message'=>$e->getMessage()))); }
