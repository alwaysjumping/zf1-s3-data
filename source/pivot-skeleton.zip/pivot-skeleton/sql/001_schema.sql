CREATE DATABASE IF NOT EXISTS pivot_demo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pivot_demo;

CREATE TABLE rpt_sales (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 order_date DATE NOT NULL,
 company_id BIGINT UNSIGNED NOT NULL,
 department_id BIGINT UNSIGNED NOT NULL,
 department_name VARCHAR(100) NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 product_name VARCHAR(100) NOT NULL,
 quantity INT NOT NULL DEFAULT 0,
 sales_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
 cost_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
 profit_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
 PRIMARY KEY(id),
 KEY idx_company_date(company_id,order_date),
 KEY idx_company_department_date(company_id,department_id,order_date),
 KEY idx_company_product_date(company_id,product_id,order_date)
) ENGINE=InnoDB;

CREATE TABLE pivot_datasets (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 code VARCHAR(100) NOT NULL, name VARCHAR(255) NOT NULL, description TEXT NULL,
 source_type VARCHAR(30) NOT NULL DEFAULT 'TABLE', source_name VARCHAR(255) NOT NULL,
 version INT UNSIGNED NOT NULL DEFAULT 1, execution_mode VARCHAR(30) NOT NULL DEFAULT 'MANUAL',
 max_row_dimensions INT UNSIGNED NOT NULL DEFAULT 5, max_column_dimensions INT UNSIGNED NOT NULL DEFAULT 3,
 max_measures INT UNSIGNED NOT NULL DEFAULT 10, max_result_rows INT UNSIGNED NOT NULL DEFAULT 10000,
 max_result_columns INT UNSIGNED NOT NULL DEFAULT 500, max_result_cells INT UNSIGNED NOT NULL DEFAULT 200000,
 allow_drilldown TINYINT(1) NOT NULL DEFAULT 1, allow_export TINYINT(1) NOT NULL DEFAULT 1,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 PRIMARY KEY(id), UNIQUE KEY uq_pivot_dataset_code(code)
) ENGINE=InnoDB;

CREATE TABLE pivot_reports (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, dataset_code VARCHAR(100) NOT NULL,
 owner_user_id BIGINT UNSIGNED NOT NULL, name VARCHAR(255) NOT NULL, description TEXT NULL,
 configuration_json LONGTEXT NOT NULL, dataset_version INT UNSIGNED NOT NULL,
 visibility VARCHAR(30) NOT NULL DEFAULT 'PRIVATE', current_version INT UNSIGNED NOT NULL DEFAULT 1,
 is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
 PRIMARY KEY(id), KEY idx_owner(owner_user_id), KEY idx_dataset(dataset_code)
) ENGINE=InnoDB;
