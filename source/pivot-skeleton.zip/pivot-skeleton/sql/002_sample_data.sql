USE pivot_demo;
INSERT INTO rpt_sales(order_date,company_id,department_id,department_name,product_id,product_name,quantity,sales_amount,cost_amount,profit_amount) VALUES
('2026-01-10',1,10,'Sales',100,'Product A',10,28000,18000,10000),
('2026-04-12',1,10,'Sales',101,'Product B',11,31000,20000,11000),
('2026-01-15',1,20,'Support',100,'Product A',5,12000,8000,4000),
('2026-04-18',1,20,'Support',102,'Product C',6,15000,9000,6000),
('2026-07-05',1,30,'Marketing',103,'Product D',8,20000,13000,7000),
('2026-10-07',1,30,'Marketing',104,'Product E',8,20000,12000,8000);
