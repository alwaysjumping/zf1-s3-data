# S3 Pivot Skeleton Project

Skeleton implementation for the Enterprise Pivot Analysis platform.

## Environment
- PHP 7.4+
- MariaDB
- DHTMLX 3.5, hosted locally
- No Internet/CDN dependency

## Included
- SALES dataset metadata service
- definition validation
- mandatory security filter channel
- query planner and MariaDB query builder
- date Year/Quarter/Month/Day grouping
- SUM/COUNT/AVG/MIN/MAX
- AVG support state using SUM+COUNT
- generic row and column AxisTree
- sparse cell aggregation with ancestor subtotal/grand-total propagation
- simple REST entry point
- DHTMLX result grid adapter
- initial controller/definition
- sample reporting table/data
- metadata/report table starters

## Quick Start
1. Run `sql/001_schema.sql` and `sql/002_sample_data.sql`.
2. Create/configure a MariaDB user and edit `config/pivot.php`.
3. Copy your licensed DHTMLX 3.5 local files to `public/vendor/dhtmlx/`.
4. Configure the web server document root to `public/`.
5. Open `index.html` and click **Run Pivot**.

## Demo Result
The sample definition is:
- Rows: Department → Product
- Columns: Year → Quarter
- Values: SUM Sales Amount, SUM Profit Amount
- Filter: Year = 2026

## Security Warning
`public/api.php` currently contains a demo identity:

```php
$user = array('id' => 1, 'company_id' => 1);
```

Replace it with the authenticated user context from your application before any production use.

## Skeleton Boundaries
This is deliberately a foundation rather than a finished BI product. The next implementation work is:
1. full metadata tables/repositories instead of hard-coded SALES metadata;
2. complete filter operator implementation;
3. full Milestone 3 interactive field-zone designer;
4. saved reports/versioning;
5. execution persistence + secure cell IDs;
6. drill-down;
7. export/background jobs;
8. reporting DB/cache/charts/dashboard.

See `docs/PROJECT_STRUCTURE.md`.
