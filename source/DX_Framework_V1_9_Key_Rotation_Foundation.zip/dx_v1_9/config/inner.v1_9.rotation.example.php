<?php
// Merge into inner_pki. Paths are placeholders, never store production secrets in repository.
return array('decryption_keyring'=>array(
 'KEY-B-ENC-2026-NEW'=>array('state'=>'ACTIVE','private_key_file'=>'/etc/dx/private/decrypt-new.pem','accept_until'=>1893456000),
 'KEY-B-ENC-2026-OLD'=>array('state'=>'DECRYPT_ONLY','private_key_file'=>'/etc/dx/private/decrypt-old.pem','accept_until'=>1798761600),
));
