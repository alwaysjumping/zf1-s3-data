<?php
return array(
 'site_id'=>'COMPANY_A.OUTER', 'role'=>'OUTER',
 'dsn'=>'mysql:host=127.0.0.1;dbname=dx_a_outer;charset=utf8mb4',
 'db_user'=>'dx','db_password'=>'REPLACE',
 'root'=>'/var/lib/dx-a-outer',
 'signer_keys'=>array('COMPANY_A.INNER'=>'/secure/trust/a-inner-sign.pem','COMPANY_B.INNER'=>'/secure/trust/b-inner-sign.pem'),
 'mtls'=>array('ca_file'=>'/secure/tls/outer-ca.pem','client_cert'=>'/secure/tls/a-outer.crt','client_key'=>'/secure/tls/a-outer.key'),
 'peers'=>array('PARENT.OUTER'=>array('url'=>'https://parent-outer.example.internal/dx/receive.php','receipt_public_key'=>'/secure/trust/parent-receipt.pem')),
 // Apache SSL_CLIENT_CERT fingerprint authorization. Add actual approved peers only.
 'peer_client_cert_fingerprints'=>array('PARENT.OUTER'=>'REPLACE_WITH_64_HEX_DIGITS'),
 'receipt_private_key'=>'/secure/keys/a-outer-receipt.key'
);
