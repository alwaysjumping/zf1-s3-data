<?php
return [
 'site_id' => getenv('DX_SITE_ID') ?: 'COMPANY_A.INNER',
 'dsn' => getenv('DX_DSN') ?: 'mysql:host=127.0.0.1;dbname=dx_a;charset=utf8mb4',
 'db_user' => getenv('DX_DB_USER') ?: 'dx',
 'db_password' => getenv('DX_DB_PASSWORD') ?: '',
 'root' => getenv('DX_ROOT') ?: dirname(__DIR__) . '/var',
 'sign_private' => getenv('DX_SIGN_PRIVATE') ?: '',
 'sign_public' => getenv('DX_SIGN_PUBLIC') ?: '',
 'decrypt_private' => getenv('DX_DECRYPT_PRIVATE') ?: '',
 'recipient_keys' => [], // site ID => ['sign_public'=>PEM filepath,'encrypt_public'=>PEM filepath]
];
