<?php
return array(
 'site_id'=>'PARENT.OUTER',
 'role'=>'PARENT_OUTER', // or OUTER
 'dsn'=>'mysql:host=127.0.0.1;dbname=dx_parent_outer;charset=utf8mb4',
 'db_user'=>'dx', 'db_password'=>'',
 'root'=>dirname(__DIR__).'/var',
 // Approved offline-pinned public signing keys. No private decryption keys at gateways.
 'signer_keys'=>array(
   'COMPANY_A.INNER'=>'/secure/trust/company_a_sign_public.pem',
   'COMPANY_B.INNER'=>'/secure/trust/company_b_sign_public.pem'
 )
);
