<?php
// Merge this array into each Outer gateway config. NO fallback in enabled mode.
return array(
 'pki'=>array(
   'enabled'=>true,'required'=>true,'environment'=>'test',
   'trust_root'=>'/etc/dx/trust/accepted',
   'authority_public_key'=>'/etc/dx/trust/authority-pinned.pub',
   'ca_file'=>'/etc/dx/trust/enterprise-ca-chain.pem'
 ),
 // Add 'receipt_key_id'=>'KEY-PARENT-RECEIPT-2026' to every Outer peer entry.
 // The signed trust directory MUST contain matching site signing certificates.
);
