<?php
return array('inner_pki'=>array('required'=>true,'trust_root'=>'/etc/dx/trust','authority_public_key'=>'/etc/dx/pinned-authority.pub.pem','ca_file'=>'/etc/dx/enterprise-ca-chain.pem','environment'=>'test','signer_key_id'=>'KEY-A-SIGN-2026-02','decryption_key_id'=>'KEY-A-ENC-2026-01'));
