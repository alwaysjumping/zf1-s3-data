<?php
/** V1.9 explicit offline CRL policy gate. Integrate only at reviewed call sites. */
require_once __DIR__.'/DxOfflineCrl.php';
final class DxCrlPolicy {
    private $ca;private $entries;private $maxAge;
    public function __construct($caFile,array $issuerCrlFiles,$maxAgeSeconds=86400) {
        if (!is_file($caFile) || !$issuerCrlFiles || !is_int($maxAgeSeconds) || $maxAgeSeconds<1) throw new RuntimeException('Invalid CRL policy');
        foreach ($issuerCrlFiles as $issuer=>$file) if (!is_string($issuer)||!is_string($file)||!is_file($file)) throw new RuntimeException('CRL issuer mapping missing');
        $this->ca=$caFile;$this->entries=$issuerCrlFiles;$this->maxAge=$maxAgeSeconds;
    }
    public function checkCertificateFile($certificateFile,$issuer) {
        if (!isset($this->entries[$issuer])) throw new RuntimeException('No approved CRL for issuer');
        $file=$this->entries[$issuer];
        $proc=proc_open(array('openssl','crl','-in',$file,'-noout','-lastupdate'),array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w')),$pipes);
        if (!is_resource($proc)) throw new RuntimeException('OpenSSL unavailable');
        fclose($pipes[0]);$out=stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);
        if (proc_close($proc)!==0 || !preg_match('/lastUpdate\s*=\s*([^\r\n]+)/i',$out,$m)) throw new RuntimeException('CRL lastUpdate invalid');
        $issued=strtotime(trim($m[1]));
        if ($issued===false || $issued>time()+300 || time()-$issued>$this->maxAge) throw new RuntimeException('CRL policy freshness failed');
        return DxOfflineCrl::check($certificateFile,$this->ca,$file);
    }
}
