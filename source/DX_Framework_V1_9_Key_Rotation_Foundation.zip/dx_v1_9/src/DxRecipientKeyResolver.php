<?php
/** Resolve recipient encryption public key from signed directory; no private key material. */
final class DxRecipientKeyResolver {
    private $directory; private $caFile;
    public function __construct(array $directory,$caFile) {$this->directory=$directory;$this->caFile=$caFile;}
    public function resolve($destination,$keyId) {
        if (!is_string($destination)||!is_string($keyId)||$keyId==='') throw new RuntimeException('Invalid recipient/key ID');
        $site=$this->directory['sites'][$destination]??null;
        if (!is_array($site)||($site['role']??'')!=='INNER') throw new RuntimeException('Recipient is not an authorized Inner site');
        $entry=$site['encryption'][$keyId]??null;
        if (!is_array($entry)||empty($entry['certificate_pem'])||empty($entry['sha256'])) throw new RuntimeException('Recipient encryption key not trusted');
        $cert=DxCertificateValidator::validate($entry['certificate_pem'],$this->caFile,$destination,'ENCRYPT',$entry['sha256'],$this->directory['revoked_serials']??array());
        $pub=openssl_pkey_get_public($cert);
        if (!$pub) throw new RuntimeException('Recipient public key unavailable');
        $details=openssl_pkey_get_details($pub);
        if (!is_array($details)||($details['type']??null)!==OPENSSL_KEYTYPE_RSA) throw new RuntimeException('DX-V1-DEMO requires RSA recipient encryption certificate');
        return array('key_id'=>$keyId,'certificate_sha256'=>$entry['sha256'],'public_key_pem'=>$details['key']);
    }
}
