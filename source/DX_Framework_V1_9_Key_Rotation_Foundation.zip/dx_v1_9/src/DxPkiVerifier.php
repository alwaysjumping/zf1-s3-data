<?php
/** Trust-directory-aware verifier for existing DX-V1-DEMO signed envelopes.
 * Does not change the immutable V1.x package protocol or final DXPP suite. */
final class DxPkiVerifier {
    private $directory; private $caFile;
    public function __construct(array $directory,$caFile) {$this->directory=$directory;$this->caFile=$caFile;}
    private function canon($v) {
        if (is_array($v)) {if (count($v) && array_keys($v)!==range(0,count($v)-1)) ksort($v,SORT_STRING);foreach ($v as $k=>$x) $v[$k]=$this->canon($x);}return $v;
    }
    public function verifyEnvelope($bytes,$allowedKinds=array('EVENT','EACK','HACK')) {
        if (!is_string($bytes) || strlen($bytes)>10485760) throw new RuntimeException('Envelope size');
        $e=json_decode($bytes,true,32,JSON_THROW_ON_ERROR);
        if (!is_array($e) || !is_array($e['meta']??null) || !is_string($e['signature']??null)) throw new RuntimeException('Invalid envelope');
        $m=$e['meta'];$site=$m['source']??'';$kid=$m['signer_key_id']??'';
        if (($m['protocol']??'')!=='DX-V1-DEMO' || !in_array($m['kind']??'', $allowedKinds,true)) throw new RuntimeException('Protocol/kind rejected');
        if (!is_string($site) || !is_string($kid) || !isset($this->directory['sites'][$site]['signing'][$kid])) throw new RuntimeException('Signer not authorized');
        $entry=$this->directory['sites'][$site];
        if (!in_array($entry['role'],array('INNER','OUTER','PARENT_OUTER'),true)) throw new RuntimeException('Signer role invalid');
        if (($m['kind']??'')==='EVENT' && $entry['role']!=='INNER') throw new RuntimeException('Business event must originate at Inner site');
        if (($m['kind']??'')==='EACK' && $entry['role']!=='INNER') throw new RuntimeException('E-ACK must originate at final Inner site');
        if (!isset($this->directory['sites'][$m['destination']??''])) throw new RuntimeException('Destination not in trust directory');
        $v=$entry['signing'][$kid];
        $cert=DxCertificateValidator::validate($v['certificate_pem'],$this->caFile,$site,'SIGN',$v['sha256'],$this->directory['revoked_serials']??array());
        $sig=base64_decode($e['signature'],true);
        if ($sig===false) throw new RuntimeException('Signature encoding invalid');
        $canonical=json_encode($this->canon($m),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
        if (openssl_verify('DX-V1-SIGNED|'.$canonical,$sig,openssl_pkey_get_public($cert),OPENSSL_ALGO_SHA256)!==1) throw new RuntimeException('Envelope signature invalid');
        return $m;
    }
}
