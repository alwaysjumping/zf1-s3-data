<?php
/**
 * V1.6 detached-signature trust directory. The offline metadata signing public
 * key MUST be installed independently; never load it from the received bundle.
 * File-backed acceptance is for a single local host. Shared deployments need
 * a serialized MariaDB state and independently anchored rollback checkpoints.
 */
final class DxTrustDirectory {
    private $root;
    private $authorityPublicKey;
    public function __construct($root, $authorityPublicKey) {
        $this->root=rtrim($root, '/');
        $this->authorityPublicKey=$authorityPublicKey;
        if (!is_dir($this->root) && !mkdir($this->root,0700,true) && !is_dir($this->root)) throw new RuntimeException('Trust store directory');
        if (!is_file($authorityPublicKey)) throw new RuntimeException('Pinned authority public key missing');
    }
    private function parse($bytes) {
        if (strlen($bytes)>1048576) throw new RuntimeException('Trust directory too large');
        $d=json_decode($bytes,true,32,JSON_THROW_ON_ERROR);
        if (!is_array($d) || ($d['schema_version']??null)!==1 || !isset($d['directory_version'],$d['environment'],$d['expires_at'],$d['sites'])) throw new RuntimeException('Invalid trust directory');
        if (!is_int($d['directory_version']) || $d['directory_version']<1 || !is_array($d['sites'])) throw new RuntimeException('Invalid trust directory version/sites');
        if (!is_string($d['environment']) || !is_string($d['expires_at'])) throw new RuntimeException('Invalid trust metadata');
        $expires=strtotime($d['expires_at']);
        if ($expires===false || $expires<=time()) throw new RuntimeException('Expired trust directory');
        foreach ($d['sites'] as $id=>$entry) {
            if (!is_string($id) || !preg_match('/^[A-Z0-9_.-]{3,100}$/D',$id) || !is_array($entry)) throw new RuntimeException('Invalid site entry');
            if (!in_array($entry['role']??null,array('INNER','OUTER','PARENT_OUTER'),true)) throw new RuntimeException('Invalid site role');
            if (!is_array($entry['signing']??null)) throw new RuntimeException('Missing signing keys');
            foreach ($entry['signing'] as $kid=>$v) {
                if (!is_string($kid) || !preg_match('/^[A-Za-z0-9_.-]{1,100}$/D',$kid) || !is_array($v) || !isset($v['certificate_pem'],$v['sha256'])) throw new RuntimeException('Malformed signer');
                if (!is_string($v['certificate_pem']) || !is_string($v['sha256']) || !preg_match('/^[a-f0-9]{64}$/D',$v['sha256'])) throw new RuntimeException('Malformed certificate metadata');
            }
        }
        return $d;
    }
    public function verify($bytes,$signature) {
        $key=openssl_pkey_get_public(file_get_contents($this->authorityPublicKey));
        if (!$key || openssl_verify("DX-TRUST-DIRECTORY-V1.6\0".$bytes,$signature,$key,OPENSSL_ALGO_SHA256)!==1) throw new RuntimeException('Trust directory signature invalid');
        return $this->parse($bytes);
    }
    public function accept($bytes,$signature,$environment) {
        $d=$this->verify($bytes,$signature);
        if (!hash_equals($environment,$d['environment'])) throw new RuntimeException('Wrong environment');
        $lock=fopen($this->root.'/.update.lock','c');
        if (!$lock || !flock($lock,LOCK_EX)) throw new RuntimeException('Cannot lock trust store');
        try {
            $old=$this->loadState(); $sha=hash('sha256',$bytes);
            if ($d['directory_version']<$old['version']) throw new RuntimeException('Trust directory rollback');
            if ($d['directory_version']===$old['version']) {
                if (!hash_equals($old['sha256'],$sha)) throw new RuntimeException('Same-version trust conflict');
                return $d;
            }
            // Publish immutable versioned bundle, then update state pointer last.
            $name='bundle-'.$d['directory_version'].'-'.$sha;
            $this->atomicWrite($this->root.'/'.$name.'.json',$bytes);
            $this->atomicWrite($this->root.'/'.$name.'.sig',base64_encode($signature));
            $this->atomicWrite($this->root.'/state.json',json_encode(array('version'=>$d['directory_version'],'sha256'=>$sha,'bundle'=>$name),JSON_THROW_ON_ERROR));
            return $d;
        } finally {flock($lock,LOCK_UN);fclose($lock);}
    }
    private function atomicWrite($path,$data) {
        $tmp=$path.'.tmp.'.bin2hex(random_bytes(8));
        $fp=fopen($tmp,'xb');if (!$fp) throw new RuntimeException('Cannot stage trust file');
        try {if (fwrite($fp,$data)!==strlen($data)) throw new RuntimeException('Trust file short write');fflush($fp);if (function_exists('fsync')) fsync($fp);} finally {fclose($fp);}
        chmod($tmp,0600);
        if (!rename($tmp,$path)) throw new RuntimeException('Cannot publish trust file');
    }
    private function loadState() {
        $f=$this->root.'/state.json';
        if (!is_file($f)) return array('version'=>0,'sha256'=>'','bundle'=>'');
        $s=json_decode(file_get_contents($f),true,16,JSON_THROW_ON_ERROR);
        if (!isset($s['version'],$s['sha256'],$s['bundle']) || !is_int($s['version'])) throw new RuntimeException('Corrupt trust state');
        return $s;
    }
    public function current($environment) {
        $s=$this->loadState();if ($s['version']===0) throw new RuntimeException('Trust directory not installed');
        $path=$this->root.'/'.$s['bundle'];
        $bytes=file_get_contents($path.'.json');$sig=base64_decode(file_get_contents($path.'.sig'),true);
        if ($bytes===false || $sig===false || !hash_equals($s['sha256'],hash('sha256',$bytes))) throw new RuntimeException('Trust state tampered');
        $d=$this->verify($bytes,$sig);
        if ($d['directory_version']!==$s['version'] || !hash_equals($d['environment'],$environment)) throw new RuntimeException('Trust state mismatch');
        return $d;
    }
}
