<?php
/** Apache mTLS-protected Outer receiver. No Inner site may expose this endpoint. */
final class DxHttpReceiver {
    private $db; private $cfg;
    public function __construct(array $cfg) {
        if (!in_array($cfg['role']??'',array('OUTER','PARENT_OUTER'),true))throw new RuntimeException('Only Outer sites accept HTTPS');
        $this->cfg=$cfg;
        $this->db=new PDO($cfg['dsn'],$cfg['db_user'],$cfg['db_password'],array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false));
    }
    public function receive() {
        if (($_SERVER['REQUEST_METHOD']??'')!=='POST')throw new RuntimeException('POST required');
        // Apache mod_ssl environment variables; do not replace with client-supplied headers.
        if (($_SERVER['SSL_CLIENT_VERIFY']??'')!=='SUCCESS'||empty($_SERVER['SSL_CLIENT_CERT']))throw new RuntimeException('Client TLS certificate not verified');
        $cert=openssl_x509_read($_SERVER['SSL_CLIENT_CERT']);
        if (!$cert)throw new RuntimeException('Client certificate unreadable');
        $fingerprint=strtolower(openssl_x509_fingerprint($cert,'sha256'));
        $source=null;
        foreach (($this->cfg['peer_client_cert_fingerprints']??array()) as $site=>$expected) {
            if (hash_equals(strtolower(str_replace(':','',$expected)),str_replace(':','',$fingerprint))) {$source=$site;break;}
        }
        if (!$source)throw new RuntimeException('Unauthorized TLS client certificate');
        $len=(int)($_SERVER['CONTENT_LENGTH']??0);
        if ($len<=0||$len>10485760)throw new RuntimeException('Invalid content length');
        $stream=fopen('php://input','rb');
        $body='';
        while (!feof($stream)&&strlen($body)<=10485760) {$chunk=fread($stream,65536);if ($chunk===false)throw new RuntimeException('Read failure');$body.=$chunk;}
        fclose($stream);
        if (strlen($body)!==$len||strlen($body)>10485760)throw new RuntimeException('Body size mismatch');
        $sha=hash('sha256',$body);
        if (!hash_equals($sha,$_SERVER['HTTP_X_DX_SHA256']??''))throw new RuntimeException('Body hash mismatch');
        $root=rtrim($this->cfg['root'],'/').'/gateway_in';
        if (!is_dir($root)&&!mkdir($root,0700,true)&&!is_dir($root))throw new RuntimeException('Cannot create custody directory');
        $target=$root.'/'.$sha.'.pkg';
        if (is_file($target)) {
            if (!hash_equals($sha,hash_file('sha256',$target)))throw new RuntimeException('Existing custody file hash mismatch');
        } else {
            $tmp=$root.'/.'.$sha.'.'.bin2hex(random_bytes(8)).'.tmp';
            $fp=fopen($tmp,'xb');if (!$fp)throw new RuntimeException('Cannot create staging file');
            try {
                if (fwrite($fp,$body)!==strlen($body))throw new RuntimeException('Short write');
                fflush($fp);
                if (function_exists('fsync'))fsync($fp);
            } finally {fclose($fp);}
            chmod($tmp,0600);
            if (!rename($tmp,$target))throw new RuntimeException('Atomic rename failed');
            // Directory fsync is not portable in PHP; platform-specific durable handoff remains a release gate.
        }
        $q=$this->db->prepare('SELECT upstream_site FROM dx_http_receipts WHERE sha256=?');
        $q->execute(array($sha));$prior=$q->fetchColumn();
        if ($prior!==false && $prior!==$source)throw new RuntimeException('Custody replay from different upstream');
        $this->db->prepare('INSERT IGNORE INTO dx_http_receipts(sha256,upstream_site,received_at) VALUES(?,?,UTC_TIMESTAMP())')->execute(array($sha,$source));
        $v=array('protocol'=>'DX-HOP-RECEIPT-V1.5','sender'=>$source,'receiver'=>$this->cfg['site_id'],'sha256'=>$sha,'status'=>'DURABLE');
        $key=openssl_pkey_get_private(file_get_contents($this->cfg['receipt_private_key']));
        if (!$key)throw new RuntimeException('Receipt signing key unavailable');
        $signature='';
        if (!openssl_sign('DX-HOP-RECEIPT-V1.5|'.json_encode($v,JSON_UNESCAPED_SLASHES),$signature,$key,OPENSSL_ALGO_SHA256))throw new RuntimeException('Receipt signing failed');
        return array('signed'=>$v,'signature'=>base64_encode($signature));
    }
}
