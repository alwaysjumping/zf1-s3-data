<?php
/** Certificate verification with pinned CA, leaf fingerprint, identity, purpose,
 * and directory revocation. Offline CRL freshness remains a production gate. */
final class DxCertificateValidator {
    public static function validate($pem,$caFile,$siteId,$purpose,$expectedSha256,array $revokedSerials=array()) {
        if (!is_file($caFile) || !is_string($pem) || strlen($pem)>65536) throw new RuntimeException('Certificate input invalid');
        $cert=openssl_x509_read($pem);
        if (!$cert) throw new RuntimeException('Certificate parse failed');
        $sha=strtolower(str_replace(':','',openssl_x509_fingerprint($cert,'sha256')));
        if (!hash_equals(strtolower($expectedSha256),$sha)) throw new RuntimeException('Certificate fingerprint mismatch');
        $p=openssl_x509_parse($cert);
        if (!$p || time()<($p['validFrom_time_t']??0) || time()>=($p['validTo_time_t']??0)) throw new RuntimeException('Certificate validity failure');
        if (($p['extensions']['basicConstraints']??'')!=='CA:FALSE') throw new RuntimeException('Expected leaf certificate');
        $san=$p['extensions']['subjectAltName']??'';
        $expected='URI:urn:dx:site:'.$siteId;
        if (!in_array($expected,array_map('trim',explode(',',$san)),true)) throw new RuntimeException('Site SAN mismatch');
        $usage=$p['extensions']['keyUsage']??'';
        if ($purpose==='SIGN' && strpos($usage,'Digital Signature')===false) throw new RuntimeException('Certificate signing usage mismatch');
        if ($purpose==='ENCRYPT' && strpos($usage,'Key Encipherment')===false && strpos($usage,'Key Agreement')===false) throw new RuntimeException('Certificate encryption usage mismatch');
        if ($purpose==='TLS') {
            $eku=$p['extensions']['extendedKeyUsage']??'';
            if (strpos($eku,'TLS Web Client Authentication')===false && strpos($eku,'TLS Web Server Authentication')===false) throw new RuntimeException('TLS purpose mismatch');
        }
        $serial=strtoupper(ltrim($p['serialNumberHex']??'','0'));
        foreach ($revokedSerials as $revoked) if (hash_equals($serial,strtoupper(ltrim($revoked,'0')))) throw new RuntimeException('Revoked certificate');
        // OpenSSL checks signature chain and time; SAN/role/purpose are enforced above.
        if (openssl_x509_checkpurpose($cert, X509_PURPOSE_ANY, array($caFile))!==true) throw new RuntimeException('Certificate chain failure');
        return $cert;
    }
}
