<?php
/** V1.9 strict destination key-ID routing for in-flight encrypted packages.
 * Does not search arbitrary private keys. PHP 7.4 compatible.
 */
final class DxDecryptionKeyring {
    private $keys;
    public function __construct(array $keys) {
        if (!$keys) throw new RuntimeException('Empty decryption keyring');
        $this->keys=array();
        foreach ($keys as $id=>$row) {
            if (!is_string($id) || !preg_match('/^[A-Za-z0-9_.-]{1,100}$/D',$id) || !is_array($row)) throw new RuntimeException('Invalid keyring entry');
            if (!in_array($row['state']??'',array('ACTIVE','DECRYPT_ONLY'),true)) throw new RuntimeException('Invalid decryption key state');
            if (!is_string($row['private_key_file']??null) || !is_file($row['private_key_file']) || !is_readable($row['private_key_file'])) throw new RuntimeException('Decryption key file unavailable');
            if (!is_int($row['accept_until']??null) || $row['accept_until']<=0) throw new RuntimeException('Invalid key acceptance cutoff');
            $this->keys[$id]=$row;
        }
    }
    public function select($keyId,$now=null) {
        if (!is_string($keyId) || !isset($this->keys[$keyId])) throw new RuntimeException('Unknown decryption key ID');
        $row=$this->keys[$keyId];$now=$now===null?time():(int)$now;
        if ($now>=$row['accept_until']) throw new RuntimeException('Decryption key acceptance expired');
        return $row['private_key_file'];
    }
    public function states(){return array_map(function($v){return $v['state'];},$this->keys);}
}
