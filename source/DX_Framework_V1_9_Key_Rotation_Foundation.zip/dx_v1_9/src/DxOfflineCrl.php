<?php
/** Offline CRL freshness/chain verification using OpenSSL CLI. Fail-closed helper.
 * Caller supplies CA-issued CRL, approved CA bundle, and certificate file.
 * This is a separate validation gate; not wired into every receiver path. */
final class DxOfflineCrl {
    private static function run(array $args) {
        $pipes=array();$proc=proc_open($args,array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w')),$pipes);
        if (!is_resource($proc)) throw new RuntimeException('OpenSSL CLI unavailable');
        fclose($pipes[0]);$out=stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);
        if (proc_close($proc)!==0) throw new RuntimeException('CRL validation failed: '.substr($err,0,180));
        return $out;
    }
    public static function check($certificateFile,$caFile,$crlFile,$maximumRemainingSkewSeconds=300) {
        foreach (array($certificateFile,$caFile,$crlFile) as $path) if (!is_file($path)) throw new RuntimeException('CRL input file missing');
        $info=self::run(array('openssl','crl','-in',$crlFile,'-noout','-nextupdate','-lastupdate'));
        if (!preg_match('/nextUpdate\s*=\s*([^\r\n]+)/i',$info,$match)) throw new RuntimeException('CRL nextUpdate unavailable');
        $expiry=strtotime(trim($match[1]));
        if ($expiry===false || $expiry <= time()+max(0,(int)$maximumRemainingSkewSeconds)) throw new RuntimeException('CRL expired or too near expiration');
        // -crl_check verifies the leaf against the CA-issued CRL, including
        // signature validation as part of OpenSSL's chain verification.
        self::run(array('openssl','verify','-CAfile',$caFile,'-CRLfile',$crlFile,'-crl_check',$certificateFile));
        return true;
    }
}
