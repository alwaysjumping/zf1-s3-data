<?php
/** V1.8 strict Inner Site PKI security policy. PHP 7.4-compatible. */
require_once __DIR__.'/DxTrustDirectory.php';
require_once __DIR__.'/DxCertificateValidator.php';
require_once __DIR__.'/DxPkiVerifier.php';
require_once __DIR__.'/DxRecipientKeyResolver.php';
require_once __DIR__.'/DxDecryptionKeyring.php';
final class DxInnerPki {
    private $cfg; private $directory; private $ca; private $keyring = null;
    public function __construct(array $cfg) {
        $this->cfg=$cfg;
        foreach (array('trust_root','authority_public_key','ca_file','environment','signer_key_id','decryption_key_id') as $k)
            if (!isset($cfg[$k]) || !is_string($cfg[$k]) || $cfg[$k]==='') throw new RuntimeException('Strict Inner PKI config missing '.$k);
        $this->ca=$cfg['ca_file'];
        $t=new DxTrustDirectory($cfg['trust_root'],$cfg['authority_public_key']);
        $this->directory=$t->current($cfg['environment']);
        if (($this->directory['sites'][$cfg['site_id']]['role']??'')!=='INNER') throw new RuntimeException('Local identity is not an Inner Site');
        if (!empty($cfg['decryption_keyring'])) $this->keyring=new DxDecryptionKeyring($cfg['decryption_keyring']);
        $this->checkLocalSigning();
    }
    public function directory(){return $this->directory;}
    public function verifyEnvelope($bytes,$kind,$expectedSource=null) {
        $v=new DxPkiVerifier($this->directory,$this->ca);
        $meta=$v->verifyEnvelope($bytes,array($kind));
        if (($meta['destination']??'')!==$this->cfg['site_id']) throw new RuntimeException('PKI envelope destination mismatch');
        if ($expectedSource!==null && ($meta['source']??'')!==$expectedSource) throw new RuntimeException('PKI envelope source mismatch');
        return $meta;
    }
    public function encryptionKey($destination) {
        $site=$this->directory['sites'][$destination]??null;
        if (!is_array($site) || ($site['role']??'')!=='INNER') throw new RuntimeException('Untrusted Inner recipient');
        $keyId=$site['active_encryption_key_id']??'';
        if (!is_string($keyId)||$keyId==='') throw new RuntimeException('No active encryption key for recipient');
        $r=new DxRecipientKeyResolver($this->directory,$this->ca);
        return $r->resolve($destination,$keyId);
    }
    public function checkLocalSigning() {
        $site=$this->cfg['site_id'];$kid=$this->cfg['signer_key_id'];
        $entry=$this->directory['sites'][$site]['signing'][$kid]??null;
        if (!is_array($entry)) throw new RuntimeException('Local signing key not trusted');
        $cert=DxCertificateValidator::validate($entry['certificate_pem'],$this->ca,$site,'SIGN',$entry['sha256'],$this->directory['revoked_serials']??array());
        $challenge=random_bytes(32);$key=openssl_pkey_get_private(file_get_contents($this->cfg['sign_private']));
        if (!$key || !openssl_sign($challenge,$sig,$key,OPENSSL_ALGO_SHA256) || openssl_verify($challenge,$sig,openssl_pkey_get_public($cert),OPENSSL_ALGO_SHA256)!==1)
            throw new RuntimeException('Local signing private key does not match trusted certificate');
    }
    public function decryptionKeyFile($keyId) {
        return $this->keyring ? $this->keyring->select($keyId) : $this->cfg['decrypt_private'];
    }
    public function assertLocalDecryptKey($keyId) {
        $keyFile=$this->keyring ? $this->keyring->select($keyId) : $this->cfg['decrypt_private'];
        if (!$this->keyring && !hash_equals($this->cfg['decryption_key_id'],(string)$keyId)) throw new RuntimeException('Package encryption key ID does not match configured private key');
        $site=$this->cfg['site_id'];
        $entry=$this->directory['sites'][$site]['encryption'][$keyId]??null;
        if (!is_array($entry)) throw new RuntimeException('Local decryption key not trusted');
        $cert=DxCertificateValidator::validate($entry['certificate_pem'],$this->ca,$site,'ENCRYPT',$entry['sha256'],$this->directory['revoked_serials']??array());
        $public=openssl_pkey_get_public($cert);$private=openssl_pkey_get_private(file_get_contents($keyFile));
        if (!$private || !$public) throw new RuntimeException('Local decryption key unavailable');
        $pubDetails=openssl_pkey_get_details($public);$privDetails=openssl_pkey_get_details($private);
        if (!isset($pubDetails['key'],$privDetails['key']) || !hash_equals($pubDetails['key'],$privDetails['key'])) throw new RuntimeException('Decryption key does not match trusted certificate');
    }
}
