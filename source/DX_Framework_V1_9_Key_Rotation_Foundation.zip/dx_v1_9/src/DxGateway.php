<?php
/**
 * DX V1.4 opaque store-and-forward gateway for OUTER sites only.
 * No Inner/Outer network connection. This gateway NEVER decrypts a payload.
 * It validates the sender signature using a pinned site->public-key map.
 * Requires PHP >= 7.4 and MariaDB/InnoDB.
 */
final class DxGateway {
    private $db; private $cfg; private $pkiVerifier;
    public function __construct(array $cfg) {
        if (!in_array($cfg['role'] ?? '', array('OUTER','PARENT_OUTER'), true)) {
            throw new RuntimeException('Gateway role must be OUTER or PARENT_OUTER');
        }
        $this->cfg=$cfg;
        // V1.7 strict mode: the gateway MUST use the currently accepted signed directory.
        $this->pkiVerifier=null;
        if (!empty($cfg['pki']['enabled'])) {
            require_once __DIR__.'/DxTrustDirectory.php';
            require_once __DIR__.'/DxCertificateValidator.php';
            require_once __DIR__.'/DxPkiVerifier.php';
            $p=$cfg['pki'];
            foreach (array('trust_root','authority_public_key','ca_file','environment') as $required) {
                if (empty($p[$required])) throw new RuntimeException('Missing PKI configuration: '.$required);
            }
            $store=new DxTrustDirectory($p['trust_root'],$p['authority_public_key']);
            $directory=$store->current($p['environment']); // fail closed if absent/expired
            $this->pkiVerifier=new DxPkiVerifier($directory,$p['ca_file']);
        } elseif (!empty($cfg['pki']['required'])) {
            throw new RuntimeException('PKI is required but not enabled');
        }
        $this->db=new PDO($cfg['dsn'],$cfg['db_user'],$cfg['db_password'],array(
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false));
        foreach (array('gateway_in','gateway_out','gateway_quarantine') as $name) {
            $dir=$this->dir($name);
            if (!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir)) throw new RuntimeException('mkdir failed');
        }
    }
    public function db(){return $this->db;}
    private function dir($name){return rtrim($this->cfg['root'],'/').'/'.$name;}
    private function canon($value){
        if (is_array($value)) {
            if (count($value) && array_keys($value)!==range(0,count($value)-1)) ksort($value,SORT_STRING);
            foreach ($value as $key=>$item) $value[$key]=$this->canon($item);
        }
        return $value;
    }
    private function json($value){return json_encode($this->canon($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
    private function inspect($bytes) {
        if (strlen($bytes)>10485760) throw new RuntimeException('Envelope size limit');
        $obj=json_decode($bytes,true,32,JSON_THROW_ON_ERROR);
        if (!is_array($obj) || !isset($obj['meta'],$obj['signature']) || !is_array($obj['meta'])) throw new RuntimeException('Envelope shape');
        $m=$obj['meta'];
        if (($m['protocol']??'')!=='DX-V1-DEMO' || !in_array($m['kind']??'',array('EVENT','EACK','HACK'),true)) throw new RuntimeException('Unsupported protocol/kind');
        foreach (array('source','destination') as $k) {
            if (!isset($m[$k]) || !is_string($m[$k]) || !preg_match('/^[A-Z0-9_.-]{3,100}$/D',$m[$k])) throw new RuntimeException('Invalid site');
        }
        if ($this->pkiVerifier!==null) {
            // No fallback to manually pinned keys after PKI rejection.
            $verified=$this->pkiVerifier->verifyEnvelope($bytes,array('EVENT','EACK','HACK'));
            if ($verified['source']!==$m['source'] || $verified['destination']!==$m['destination']) {
                throw new RuntimeException('Authenticated envelope identity mismatch');
            }
            return $verified;
        }
        $keyfile=$this->cfg['signer_keys'][$m['source']]??null;
        if (!$keyfile || !is_file($keyfile)) throw new RuntimeException('Unknown source signing key');
        $pub=openssl_pkey_get_public(file_get_contents($keyfile));
        $sig=base64_decode($obj['signature'],true);
        if (!$pub || $sig===false || openssl_verify('DX-V1-SIGNED|'.$this->json($m),$sig,$pub,OPENSSL_ALGO_SHA256)!==1) throw new RuntimeException('Invalid signature');
        // V1.4 only authenticates the envelope's source; full X.509 PKI/CRL is NOT implemented.
        return $m;
    }
    private function route($source,$destination,$kind){
        $q=$this->db->prepare('SELECT next_hop FROM dx_gateway_routes WHERE source_site=? AND destination_site=? AND message_kind=? AND enabled=1');
        $q->execute(array($source,$destination,$kind));
        $row=$q->fetch();
        if (!$row) throw new RuntimeException('No authorized gateway route');
        if ($row['next_hop']===$this->cfg['site_id']) throw new RuntimeException('Self-routing forbidden');
        return $row['next_hop'];
    }
    public function ingest(){
        $count=0;
        foreach (glob($this->dir('gateway_in').'/*.pkg')?:array() as $file) {
            try {
                if (!is_file($file) || is_link($file) || filesize($file)>10485760) throw new RuntimeException('Invalid incoming file');
                $bytes=file_get_contents($file);
                if ($bytes===false) throw new RuntimeException('Cannot read incoming file');
                $m=$this->inspect($bytes);
                $next=$this->route($m['source'],$m['destination'],$m['kind']);
                $sha=hash('sha256',$bytes);
                $q=$this->db->prepare('SELECT id,next_hop FROM dx_gateway_custody WHERE artifact_sha256=?');
                $q->execute(array($sha));$old=$q->fetch();
                if (!$old) {
                    $this->db->prepare('INSERT INTO dx_gateway_custody(artifact_sha256,origin_site,final_destination,message_kind,next_hop,state) VALUES(?,?,?,?,?,?)')
                        ->execute(array($sha,$m['source'],$m['destination'],$m['kind'],$next,'RECEIVED'));
                } elseif ($old['next_hop']!==$next) {
                    throw new RuntimeException('Route changed for existing artifact; operator review');
                }
                // Incoming file is kept for custody/replay; source handoff may redeliver it.
                $count++;
            } catch (Throwable $e) {
                fwrite(STDERR,'Gateway ingest hold '.basename($file).': '.$e->getMessage()."\n");
            }
        }
        return $count;
    }
    public function forward(){
        $count=0;
        $q=$this->db->query("SELECT * FROM dx_gateway_custody WHERE state='RECEIVED' ORDER BY id LIMIT 100");
        foreach ($q->fetchAll() as $row) {
            try {
                // Match by content hash, not by a sender-controlled filename.
                $bytes=null;
                foreach (glob($this->dir('gateway_in').'/*.pkg')?:array() as $candidate) {
                    if (is_file($candidate) && !is_link($candidate) && filesize($candidate)<=10485760 && hash_file('sha256',$candidate)===$row['artifact_sha256']) {
                        $bytes=file_get_contents($candidate);break;
                    }
                }
                if ($bytes===null || $bytes===false) throw new RuntimeException('Custody input missing');
                $next=$row['next_hop'];
                $target=$this->dir('gateway_out').'/'.$row['artifact_sha256'].'.pkg';
                if (is_file($target)) {
                    if (!hash_equals($row['artifact_sha256'],hash_file('sha256',$target))) throw new RuntimeException('Output hash conflict');
                } else {
                    $tmp=$target.'.tmp.'.bin2hex(random_bytes(8));
                    if (file_put_contents($tmp,$bytes,LOCK_EX)!==strlen($bytes)) throw new RuntimeException('Short write');
                    chmod($tmp,0600);
                    if (!rename($tmp,$target)) throw new RuntimeException('Atomic rename failed');
                }
                $u=$this->db->prepare("UPDATE dx_gateway_custody SET state='READY',output_path=? WHERE id=? AND state='RECEIVED'");
                $u->execute(array($target,$row['id']));
                if ($u->rowCount()===1) $count++;
            } catch (Throwable $e) {fwrite(STDERR,'Gateway forward hold '.$row['id'].': '.$e->getMessage()."\n");}
        }
        return $count;
    }
    public function status(){return $this->db->query('SELECT artifact_sha256,origin_site,final_destination,message_kind,next_hop,state,output_path FROM dx_gateway_custody ORDER BY id DESC LIMIT 100')->fetchAll();}
}
