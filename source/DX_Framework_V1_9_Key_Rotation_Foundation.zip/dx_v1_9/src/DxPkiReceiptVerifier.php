<?php
/** Verify V1.5 custody receipts against a signed-directory authorized receiver. */
final class DxPkiReceiptVerifier {
    private $directory; private $caFile;
    public function __construct(array $directory,$caFile) {$this->directory=$directory;$this->caFile=$caFile;}
    public function verify(array $receipt,$sender,$receiver,$sha256,$keyId) {
        $v=$receipt['signed']??null;
        if (!is_array($v)||($v['protocol']??'')!=='DX-HOP-RECEIPT-V1.5'||($v['sender']??'')!==$sender||($v['receiver']??'')!==$receiver||($v['sha256']??'')!==$sha256||($v['status']??'')!=='DURABLE') throw new RuntimeException('Receipt binding invalid');
        $site=$this->directory['sites'][$receiver]??null;
        if (!is_array($site)||!in_array($site['role']??'',array('OUTER','PARENT_OUTER'),true)) throw new RuntimeException('Receipt signer role invalid');
        $entry=$site['signing'][$keyId]??null;
        if (!is_array($entry)) throw new RuntimeException('Receipt signer key unauthorized');
        $cert=DxCertificateValidator::validate($entry['certificate_pem'],$this->caFile,$receiver,'SIGN',$entry['sha256'],$this->directory['revoked_serials']??array());
        $sig=base64_decode($receipt['signature']??'',true);
        if ($sig===false||openssl_verify('DX-HOP-RECEIPT-V1.5|'.json_encode($v,JSON_UNESCAPED_SLASHES),$sig,openssl_pkey_get_public($cert),OPENSSL_ALGO_SHA256)!==1) throw new RuntimeException('Receipt signature invalid');
        return true;
    }
}
