<?php
require_once __DIR__.'/DxInnerPki.php';
/** DX V1 prototype; NOT the finalized DXPP production protocol. PHP >=7.4. */
class Dx {
 private $cfg; private $db; private $innerPki = null;
 private function audit($worker,$ref,$action,$detail=''){
  $q=$this->db->prepare('INSERT INTO dx_worker_audit(worker_name,reference_id,action,detail) VALUES(?,?,?,?)');
  $q->execute([$worker,$ref,$action,substr($detail,0,500)]);
 }
 private function backoff($attempt){return min(3600, (int)pow(2,min(10,max(1,$attempt)))+random_int(0,10));}
 private function claim($table,$worker,$limit=50){
  if(!in_array($table,['dx_outbox','dx_ack_outbox','dx_inbox','dx_hack_outbox'],true))throw new RuntimeException('Invalid queue');
  $claimed=[]; $limit=max(1,min(50,(int)$limit));
  // Conditional UPDATE is atomic even with competing PHP workers.
  $rows=$this->db->query("SELECT id FROM $table WHERE state='PENDING' AND (next_attempt_at IS NULL OR next_attempt_at<=UTC_TIMESTAMP()) ORDER BY id LIMIT ".$limit)->fetchAll();
  foreach($rows as $r){
   $token=$this->uuid();
   $q=$this->db->prepare("UPDATE $table SET state='CLAIMED',claim_token=?,lease_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 300 SECOND),attempts=attempts+1 WHERE id=? AND state='PENDING' AND (next_attempt_at IS NULL OR next_attempt_at<=UTC_TIMESTAMP())");
   $q->execute([$token,$r['id']]);
   if($q->rowCount()===1){$q=$this->db->prepare("SELECT * FROM $table WHERE id=? AND claim_token=?");$q->execute([$r['id'],$token]);$claimed[]=$q->fetch();}
  }
  return $claimed;
 }
 private function leaseValid($table,$row){
  $q=$this->db->prepare("SELECT 1 FROM $table WHERE id=? AND state='CLAIMED' AND claim_token=? AND lease_until>UTC_TIMESTAMP()");
  $q->execute([$row['id'],$row['claim_token']]);return (bool)$q->fetchColumn();
 }
 private function failClaim($table,$row,$error){
  if ((int)$row['attempts'] >= 12) {
   $q=$this->db->prepare("UPDATE $table SET state='QUARANTINED',claim_token=NULL,lease_until=NULL,last_error=? WHERE id=? AND state='CLAIMED' AND claim_token=?");
   $q->execute([substr($error,0,500),$row['id'],$row['claim_token']]);
   if($q->rowCount()===1)$this->audit($table,(string)$row['id'],'POISON_QUARANTINED',$error);
   return;
  }
  $seconds=$this->backoff((int)$row['attempts']);
  $q=$this->db->prepare("UPDATE $table SET state='PENDING',claim_token=NULL,lease_until=NULL,next_attempt_at=DATE_ADD(UTC_TIMESTAMP(),INTERVAL $seconds SECOND),last_error=? WHERE id=? AND state='CLAIMED' AND claim_token=?");
  $q->execute([substr($error,0,500),$row['id'],$row['claim_token']]);
  if($q->rowCount()===1)$this->audit($table,(string)$row['id'],'RETRY_SCHEDULED',$error);
 }
 public function recover(){
  $counts=[];
  foreach(['dx_outbox','dx_ack_outbox','dx_inbox','dx_hack_outbox'] as $table){
   $q=$this->db->exec("UPDATE $table SET state='PENDING',claim_token=NULL,lease_until=NULL WHERE state='CLAIMED' AND lease_until<UTC_TIMESTAMP()");
   $counts[$table]=$q; $this->audit('recover',$table,'LEASES_RECOVERED',(string)$q);
  }
  // A missing READY file is an operator incident: never silently rebuild a
  // potentially distributed package under the same identity.
  $missing=0;
  foreach($this->db->query("SELECT package_id,file_path FROM dx_packages WHERE state='READY'") as $r){
   if(!is_file($r['file_path'])){$missing++;$this->audit('recover',$r['package_id'],'MISSING_PACKAGE_FILE','Manual reconciliation required');}
  }
  $counts['missing_ready_files']=$missing;return $counts;
 }
 public function __construct(array $cfg) {
  $this->cfg=$cfg;
  if (!empty($cfg['inner_pki']['required'])) {
   $pkiCfg=$cfg['inner_pki'];$pkiCfg['site_id']=$cfg['site_id'];
   $pkiCfg['sign_private']=$cfg['sign_private'];$pkiCfg['decrypt_private']=$cfg['decrypt_private'];
   $this->innerPki=new DxInnerPki($pkiCfg);
   $this->cfg['signer_key_id']=$pkiCfg['signer_key_id'];
  }
  foreach (['sign_private','sign_public','decrypt_private'] as $k) if (!is_file($cfg[$k])) throw new RuntimeException('Missing key: '.$k);
  $this->db=new PDO($cfg['dsn'],$cfg['db_user'],$cfg['db_password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  foreach (['out','in','inbox','acks_out','acks_in','hacks_out','hacks_in','quarantine'] as $d) { $dir=$cfg['root'].'/'.$d; if (!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir)) throw new RuntimeException('Cannot mkdir '.$dir); }
 }
 public function db(){return $this->db;}
 private function uuid(){return bin2hex(random_bytes(16));}
 private function canonical($v){if(is_array($v)){if(array_keys($v)!==range(0,count($v)-1)){ksort($v,SORT_STRING);} foreach($v as $k=>$x)$v[$k]=$this->canonical($x);}return $v;}
 private function json($v){return json_encode($this->canonical($v),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);}
 private function key($path,$private=false){$s=file_get_contents($path);$k=$private?openssl_pkey_get_private($s):openssl_pkey_get_public($s);if(!$k)throw new RuntimeException('Invalid key');return $k;}
 private function sign($s){if(!openssl_sign($s,$sig,$this->key($this->cfg['sign_private'],true),OPENSSL_ALGO_SHA256))throw new RuntimeException('Sign failed');return base64_encode($sig);}
 private function verify($s,$sig,$site){$path=$this->cfg['recipient_keys'][$site]['sign_public']??null;if(!$path||!is_file($path))throw new RuntimeException('Unknown signer '.$site);return openssl_verify($s,base64_decode($sig,true),$this->key($path),OPENSSL_ALGO_SHA256)===1;}
 private function recipient($site){$path=$this->cfg['recipient_keys'][$site]['encrypt_public']??null;if(!$path||!is_file($path))throw new RuntimeException('Unknown destination encryption key: '.$site);return $path;}
 public function publish($eventType,$destination,array $payload,$eventId=null){
  if($eventType!=='email.deliver')throw new RuntimeException('Unregistered event type');
  if($this->innerPki){$this->innerPki->encryptionKey($destination);}
  elseif(!isset($this->cfg['recipient_keys'][$destination]))throw new RuntimeException('Unauthorized destination');
  $id=$eventId?:$this->uuid();$q=$this->db->prepare('INSERT INTO dx_outbox(event_id,event_type,destination,payload) VALUES(?,?,?,?)');
  $q->execute([$id,$eventType,$destination,$this->json($payload)]);return $id;
 }
 private function envelope($data,$destination,$kind){
  $raw=$this->json($data);$nonce=random_bytes(12);$cek=random_bytes(32);$aad='DX-V1|'.$kind.'|'.$this->cfg['site_id'].'|'.$destination;
  $tag='';$cipher=openssl_encrypt($raw,'aes-256-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag,$aad,16);
  if($cipher===false)throw new RuntimeException('Encrypt failed');
  // Explicit OAEP SHA-256/MGF1 SHA-256 through openssl pkeyutl CLI, not PHP openssl_public_encrypt.
  $recipientKeyId=null;$tempPub=null;
  if($this->innerPki){
   $resolved=$this->innerPki->encryptionKey($destination);$recipientKeyId=$resolved['key_id'];
   $tempPub=tempnam(sys_get_temp_dir(),'dxpub_');if($tempPub===false)throw new RuntimeException('Cannot stage public key');
   chmod($tempPub,0600);file_put_contents($tempPub,$resolved['public_key_pem']);
   try{$wrapped=$this->oaep($cek,$tempPub,false);}finally{unlink($tempPub);}
  }else{$wrapped=$this->oaep($cek,$this->recipient($destination),false);}
  $meta=['protocol'=>'DX-V1-DEMO','kind'=>$kind,'source'=>$this->cfg['site_id'],'destination'=>$destination,
   'nonce'=>base64_encode($nonce),'tag'=>base64_encode($tag),'wrapped_cek'=>base64_encode($wrapped),
   'ciphertext'=>base64_encode($cipher),'cipher_sha256'=>hash('sha256',$cipher)];
  if($recipientKeyId!==null)$meta['recipient_key_id']=$recipientKeyId;
  if (!empty($this->cfg['signer_key_id'])) {
   if (!preg_match('/^[A-Za-z0-9_.-]{1,100}$/D',$this->cfg['signer_key_id'])) throw new RuntimeException('Invalid signer key ID');
   $meta['signer_key_id']=$this->cfg['signer_key_id'];
  }
  return $this->json(['meta'=>$meta,'signature'=>$this->sign('DX-V1-SIGNED|'.$this->json($meta))]);
 }
 private function oaep($bytes,$keyPath,$decrypt){
  $cmd=['openssl','pkeyutl',$decrypt?'-decrypt':'-encrypt',$decrypt?'-inkey':'-pubin', $decrypt?$keyPath:'-inkey',$keyPath,
    '-pkeyopt','rsa_padding_mode:oaep','-pkeyopt','rsa_oaep_md:sha256','-pkeyopt','rsa_mgf1_md:sha256'];
  $des=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];$proc=proc_open($cmd,$des,$pipes);
  if(!is_resource($proc))throw new RuntimeException('OpenSSL pkeyutl unavailable');
  fwrite($pipes[0],$bytes);fclose($pipes[0]);$out=stream_get_contents($pipes[1]);fclose($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[2]);$rc=proc_close($proc);
  if($rc!==0)throw new RuntimeException('OAEP operation failed: '.substr($err,0,150));return $out;
 }
 private function openEnvelope($bytes,$expectedKind){
  if(strlen($bytes)>10485760)throw new RuntimeException('Oversized envelope');
  $e=json_decode($bytes,true,32,JSON_THROW_ON_ERROR);if(!isset($e['meta'],$e['signature']))throw new RuntimeException('Invalid envelope');
  $m=$e['meta'];if($this->innerPki){$this->innerPki->verifyEnvelope($bytes,$expectedKind);$this->innerPki->assertLocalDecryptKey($m['recipient_key_id']??'');}
  if(($m['protocol']??'')!=='DX-V1-DEMO'||($m['kind']??'')!==$expectedKind||($m['destination']??'')!==$this->cfg['site_id'])throw new RuntimeException('Wrong envelope type/destination');
  if(!$this->verify('DX-V1-SIGNED|'.$this->json($m),$e['signature'],$m['source']))throw new RuntimeException('Signature invalid');
  $cipher=base64_decode($m['ciphertext'],true);$nonce=base64_decode($m['nonce'],true);$tag=base64_decode($m['tag'],true);$wrapped=base64_decode($m['wrapped_cek'],true);
  if($cipher===false||$nonce===false||$tag===false||$wrapped===false||strlen($nonce)!==12||strlen($tag)!==16||hash('sha256',$cipher)!==$m['cipher_sha256'])throw new RuntimeException('Invalid ciphertext metadata');
  $decryptFile=$this->innerPki ? $this->innerPki->decryptionKeyFile($m['recipient_key_id']??'') : $this->cfg['decrypt_private'];
  $cek=$this->oaep($wrapped,$decryptFile,true);if(strlen($cek)!==32)throw new RuntimeException('Invalid CEK');
  $aad='DX-V1|'.$expectedKind.'|'.$m['source'].'|'.$m['destination'];
  $raw=openssl_decrypt($cipher,'aes-256-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag,$aad);
  if($raw===false)throw new RuntimeException('AEAD authentication failed');
  return [$m,json_decode($raw,true,32,JSON_THROW_ON_ERROR)];
 }
 private function save($dir,$id,$data){if(!preg_match('/^[a-f0-9]{32}$/',$id))throw new RuntimeException('Invalid id');$target=$this->cfg['root'].'/'.$dir.'/'.$id.'.pkg';$temp=$target.'.tmp.'.$this->uuid();if(file_put_contents($temp,$data,LOCK_EX)===false)throw new RuntimeException('Write failed');chmod($temp,0600);if(is_file($target)){unlink($temp);throw new RuntimeException('Immutable package filename already exists');}if(!rename($temp,$target))throw new RuntimeException('Rename failed');return $target;}
 public function build(){
  $rows=$this->claim('dx_outbox','build');$n=0;
  foreach($rows as $r){
   try{
    // Stable identity across retries. Never publish a second ciphertext under this identity.
    $id=substr(hash('sha256','DX-V1.2|'.$this->cfg['site_id'].'|'.$r['destination'].'|'.$r['event_id']),0,32);
    $path=$this->cfg['root'].'/out/'.$id.'.pkg';
    if(is_file($path)){
     // A previous worker may have published it. Manual reconciliation required.
     throw new RuntimeException('Existing immutable package; run reconcile, do not rebuild');
    }
    if(!$this->leaseValid('dx_outbox',$r))throw new RuntimeException('Lease expired before build');
    $event=['package_id'=>$id,'event_id'=>$r['event_id'],'event_type'=>$r['event_type'],'payload'=>json_decode($r['payload'],true,32,JSON_THROW_ON_ERROR)];
    $bytes=$this->envelope($event,$r['destination'],'EVENT');
    if(!$this->leaseValid('dx_outbox',$r))throw new RuntimeException('Lease expired before filesystem publish');
    $path=$this->save('out',$id,$bytes);
    $this->db->beginTransaction();
    try{
     $q=$this->db->prepare("SELECT 1 FROM dx_outbox WHERE id=? AND state='CLAIMED' AND claim_token=? AND lease_until>UTC_TIMESTAMP() FOR UPDATE");
     $q->execute([$r['id'],$r['claim_token']]);if(!$q->fetchColumn())throw new RuntimeException('Lease lost before DB commit');
     $this->db->prepare('INSERT INTO dx_packages(package_id,event_id,source_site,destination,package_hash,state,file_path) VALUES(?,?,?,?,?,?,?)')->execute([$id,$r['event_id'],$this->cfg['site_id'],$r['destination'],hash('sha256',$bytes),'READY',$path]);
     $q=$this->db->prepare("UPDATE dx_outbox SET state='BUILT',package_id=?,claim_token=NULL,lease_until=NULL WHERE id=? AND claim_token=?");
     $q->execute([$id,$r['id'],$r['claim_token']]);if($q->rowCount()!==1)throw new RuntimeException('Fencing update failed');
     $this->db->commit();$n++;
    }catch(Throwable $e){$this->db->rollBack();throw $e;}
   }catch(Throwable $e){$this->failClaim('dx_outbox',$r,$e->getMessage());fwrite(STDERR,'Build retry/hold: '.$e->getMessage()."\n");}
  }return $n;
 }
 public function reconcile(){
  $report=['orphan_out_files'=>[],'missing_ready_files'=>[],'pending_with_output'=>[], 'orphan_hack_files'=>[], 'missing_hack_files'=>[], 'orphan_ack_files'=>[], 'missing_ack_files'=>[], 'inbox_missing_files'=>[], 'inbox_orphan_files'=>[]];
  $hacks=[];
  foreach($this->db->query('SELECT hack_id,state,artifact_hash FROM dx_hack_outbox') as $r){
   $id=substr($r['hack_id'],0,32);$hacks[$id]=true;
   $file=$this->cfg['root'].'/hacks_out/'.$id.'.pkg';
   if($r['state']==='BUILT' && (!is_file($file) || ($r['artifact_hash']!==null && !hash_equals($r['artifact_hash'],hash_file('sha256',$file)))))$report['missing_hack_files'][]=$id;
  }
  foreach(glob($this->cfg['root'].'/hacks_out/*.pkg')?:[] as $file)if(!isset($hacks[basename($file,'.pkg')]))$report['orphan_hack_files'][]=basename($file);
  $acks=[];
  foreach($this->db->query('SELECT ack_id,state FROM dx_ack_outbox') as $r){
   $id=substr($r['ack_id'],0,32);$acks[$id]=true;
   if($r['state']==='BUILT' && !is_file($this->cfg['root'].'/acks_out/'.$id.'.pkg'))$report['missing_ack_files'][]=$id;
  }
  foreach(glob($this->cfg['root'].'/acks_out/*.pkg')?:[] as $file)if(!isset($acks[basename($file,'.pkg')]))$report['orphan_ack_files'][]=basename($file);
  $inbox=[];
  foreach($this->db->query('SELECT package_id,package_hash,file_path FROM dx_inbox') as $r){
   $inbox[$r['package_id']]=true;
   if(!is_file($r['file_path']) || !hash_equals($r['package_hash'],hash_file('sha256',$r['file_path'])))$report['inbox_missing_files'][]=$r['package_id'];
  }
  foreach(glob($this->cfg['root'].'/inbox/*.pkg')?:[] as $file)if(!isset($inbox[basename($file,'.pkg')]))$report['inbox_orphan_files'][]=basename($file);
  $known=[];
  foreach($this->db->query('SELECT package_id,file_path,state FROM dx_packages') as $r){
   $known[$r['package_id']]=true;
   if(in_array($r['state'],['READY','DELIVERED'],true)&&!is_file($r['file_path']))$report['missing_ready_files'][]=$r['package_id'];
  }
  foreach(glob($this->cfg['root'].'/out/*.pkg')?:[] as $file){
   $id=basename($file,'.pkg');if(!isset($known[$id]))$report['orphan_out_files'][]=$id;
  }
  foreach($this->db->query("SELECT event_id,destination FROM dx_outbox WHERE state IN ('PENDING','CLAIMED')") as $r){
   $id=substr(hash('sha256','DX-V1.2|'.$this->cfg['site_id'].'|'.$r['destination'].'|'.$r['event_id']),0,32);
   if(is_file($this->cfg['root'].'/out/'.$id.'.pkg'))$report['pending_with_output'][]=$id;
  }
  return $report;
 }
 public function receive(){
  $files=glob($this->cfg['root'].'/in/*.pkg')?:[];$n=0;
  foreach($files as $file){try{if(filesize($file)>10485760)throw new RuntimeException('Oversized package');$bytes=file_get_contents($file);list($m,$event)=$this->openEnvelope($bytes,'EVENT');
   if(($event['event_type']??'')!=='email.deliver'||!preg_match('/^[a-f0-9]{32}$/',$event['package_id']??'')||!is_string($event['event_id']??null)||strlen($event['event_id'])>100)throw new RuntimeException('Invalid event');
   $packageId=$event['package_id'];$hash=hash('sha256',$bytes);$eventHash=hash('sha256',$this->json($event));
   $this->db->beginTransaction();try{
    $q=$this->db->prepare('SELECT package_hash FROM dx_received WHERE package_id=? FOR UPDATE');$q->execute([$packageId]);$old=$q->fetchColumn();if($old!==false&&$old!==$hash)throw new RuntimeException('Package ID hash conflict');
    if($old===false)$this->db->prepare('INSERT INTO dx_received(package_id,package_hash,source_site) VALUES(?,?,?)')->execute([$packageId,$hash,$m['source']]);
    $q=$this->db->prepare('SELECT event_hash FROM dx_processed WHERE source_site=? AND event_id=? FOR UPDATE');$q->execute([$m['source'],$event['event_id']]);$oldEvent=$q->fetchColumn();if($oldEvent!==false&&$oldEvent!==$eventHash)throw new RuntimeException('Event ID hash conflict');
    if($oldEvent===false){$mail=$event['payload'];foreach(['sender','recipient','subject','body'] as $k)if(!isset($mail[$k])||!is_string($mail[$k]))throw new RuntimeException('Invalid email field '.$k);
     $this->db->prepare('INSERT INTO dx_mailbox(source_site,event_id,sender,recipient,subject,body) VALUES(?,?,?,?,?,?)')->execute([$m['source'],$event['event_id'],$mail['sender'],$mail['recipient'],$mail['subject'],$mail['body']]);
     $this->db->prepare('INSERT INTO dx_processed(source_site,event_id,event_hash) VALUES(?,?,?)')->execute([$m['source'],$event['event_id'],$eventHash]);}
    $ackId=hash('sha256','ACK|'.$packageId);$this->db->prepare('INSERT IGNORE INTO dx_ack_outbox(ack_id,package_id,source_site,destination,result,original_package_hash) VALUES(?,?,?,?,?,?)')->execute([$ackId,$packageId,$this->cfg['site_id'],$m['source'],'SUCCESS',$hash]);
    $this->db->commit();}catch(Throwable $e){$this->db->rollBack();throw $e;}
   unlink($file);$n++;
  }catch(Throwable $e){$to=$this->cfg['root'].'/quarantine/'.basename($file);rename($file,$to);fwrite(STDERR,'Quarantined '.basename($file).': '.$e->getMessage()."\n");}}
  return $n;
 }
 public function buildAcks(){
  $rows=$this->claim('dx_ack_outbox','build-acks');$n=0;
  foreach($rows as $r){try{$data=['ack_id'=>$r['ack_id'],'package_id'=>$r['package_id'],'original_package_hash'=>$r['original_package_hash'],'result'=>$r['result']];$bytes=$this->envelope($data,$r['destination'],'EACK');$this->save('acks_out',substr($r['ack_id'],0,32),$bytes);$q=$this->db->prepare("UPDATE dx_ack_outbox SET state='BUILT',claim_token=NULL,lease_until=NULL WHERE id=? AND state='CLAIMED' AND claim_token=? AND lease_until>UTC_TIMESTAMP()");$q->execute([$r['id'],$r['claim_token']]);if($q->rowCount()!==1)throw new RuntimeException('ACK lease lost');$n++;}catch(Throwable $e){$this->failClaim('dx_ack_outbox',$r,$e->getMessage());fwrite(STDERR,'ACK retry: '.$e->getMessage()."\n");}}return $n;
 }
 public function receiveAcks(){
  $files=glob($this->cfg['root'].'/acks_in/*.pkg')?:[];$n=0;
  foreach($files as $file){try{if(filesize($file)>10485760)throw new RuntimeException('Oversized ACK');$bytes=file_get_contents($file);list($m,$ack)=$this->openEnvelope($bytes,'EACK');$q=$this->db->prepare('SELECT destination,package_hash FROM dx_packages WHERE package_id=?');$q->execute([$ack['package_id']]);$original=$q->fetch();if(!$original||$original['destination']!==$m['source']||$ack['result']!=='SUCCESS'||!hash_equals($original['package_hash'],(string)($ack['original_package_hash']??'')))throw new RuntimeException('ACK not authorized or package hash mismatch');
   $hash=hash('sha256',$bytes);$q=$this->db->prepare('SELECT ack_hash,package_id,original_package_hash,result FROM dx_acks WHERE ack_id=?');$q->execute([$ack['ack_id']]);$old=$q->fetch();
   if($old && ($old['ack_hash']!==$hash || $old['package_id']!==$ack['package_id'] || $old['original_package_hash']!==$ack['original_package_hash'] || $old['result']!==$ack['result']))throw new RuntimeException('ACK conflict');
   $this->db->beginTransaction();try{$this->db->prepare('INSERT IGNORE INTO dx_acks(ack_id,package_id,ack_hash,result,original_package_hash) VALUES(?,?,?,?,?)')->execute([$ack['ack_id'],$ack['package_id'],$hash,$ack['result'],$ack['original_package_hash']]);$this->db->prepare("UPDATE dx_packages SET state='DELIVERED' WHERE package_id=?")->execute([$ack['package_id']]);$this->db->commit();}catch(Throwable $e){$this->db->rollBack();throw $e;}
   unlink($file);$n++;
  }catch(Throwable $e){rename($file,$this->cfg['root'].'/quarantine/'.basename($file));fwrite(STDERR,'ACK quarantined: '.$e->getMessage()."\n");}}
  return $n;
 }
 public function ingest(){
  $n=0;
  foreach(glob($this->cfg['root'].'/in/*.pkg')?:[] as $file){
   try{
    if(filesize($file)>10485760)throw new RuntimeException('Oversized incoming file');
    $bytes=file_get_contents($file);list($meta,$event)=$this->openEnvelope($bytes,'EVENT');
    $id=$event['package_id']??'';
    if(!is_string($id)||!preg_match('/^[a-f0-9]{32}$/',$id))throw new RuntimeException('Invalid package ID');
    $hash=hash('sha256',$bytes);
    $q=$this->db->prepare('SELECT package_hash FROM dx_inbox WHERE package_id=?');$q->execute([$id]);$old=$q->fetchColumn();
    if($old!==false&&$old!==$hash)throw new RuntimeException('Inbox package ID hash conflict');
    $path=$this->cfg['root'].'/inbox/'.$id.'.pkg';
    if(!is_file($path))$this->save('inbox',$id,$bytes);
    elseif(!hash_equals($hash,hash_file('sha256',$path)))throw new RuntimeException('Inbox file hash conflict');
    $this->db->beginTransaction();try{
     $this->db->prepare('INSERT IGNORE INTO dx_inbox(package_id,package_hash,source_site,file_path,state) VALUES(?,?,?,?,?)')->execute([$id,$hash,$meta['source'],$path,'PENDING']);
     // H-ACK is signed later; its outbox is committed with durable inbox custody.
     $this->db->prepare('INSERT IGNORE INTO dx_hack_outbox(hack_id,package_id,package_hash,destination) VALUES(?,?,?,?)')->execute([hash('sha256','HACK|'.$id),$id,$hash,$meta['source']]);
     $this->db->commit();
    }catch(Throwable $e){$this->db->rollBack();throw $e;}
    unlink($file);$n++;
   }catch(Throwable $e){$to=$this->cfg['root'].'/quarantine/'.basename($file);if(is_file($to))$to.='.conflict.'.bin2hex(random_bytes(4));rename($file,$to);fwrite(STDERR,'Ingest quarantined: '.$e->getMessage()."\n");}
  }return $n;
 }
 public function processInbox(){
  $n=0;
  $rows=$this->claim('dx_inbox','process-inbox');
  foreach($rows as $r){
   try{
    if(!$this->leaseValid('dx_inbox',$r))throw new RuntimeException('Inbox lease expired');
    if(!is_file($r['file_path'])||!hash_equals($r['package_hash'],hash_file('sha256',$r['file_path'])))throw new RuntimeException('Inbox artifact missing or modified');
    $bytes=file_get_contents($r['file_path']);list($m,$event)=$this->openEnvelope($bytes,'EVENT');
    if(($event['package_id']??null)!==$r['package_id']||$m['source']!==$r['source_site']||($event['event_type']??'')!=='email.deliver')throw new RuntimeException('Inbox binding invalid');
    $eventHash=hash('sha256',$this->json($event));
    $this->db->beginTransaction();try{
     $q=$this->db->prepare("SELECT 1 FROM dx_inbox WHERE id=? AND claim_token=? AND state='CLAIMED' AND lease_until>UTC_TIMESTAMP() FOR UPDATE");$q->execute([$r['id'],$r['claim_token']]);if(!$q->fetchColumn())throw new RuntimeException('Inbox fence lost');
     $q=$this->db->prepare('SELECT event_hash FROM dx_processed WHERE source_site=? AND event_id=? FOR UPDATE');$q->execute([$m['source'],$event['event_id']]);$old=$q->fetchColumn();
     if($old!==false&&!hash_equals($old,$eventHash))throw new RuntimeException('Event ID content conflict');
     if($old===false){
      $mail=$event['payload'];foreach(['sender','recipient','subject','body'] as $k)if(!isset($mail[$k])||!is_string($mail[$k]))throw new RuntimeException('Invalid email field '.$k);
      $this->db->prepare('INSERT INTO dx_mailbox(source_site,event_id,sender,recipient,subject,body) VALUES(?,?,?,?,?,?)')->execute([$m['source'],$event['event_id'],$mail['sender'],$mail['recipient'],$mail['subject'],$mail['body']]);
      $this->db->prepare('INSERT INTO dx_processed(source_site,event_id,event_hash) VALUES(?,?,?)')->execute([$m['source'],$event['event_id'],$eventHash]);
     }
     $this->db->prepare('INSERT IGNORE INTO dx_received(package_id,package_hash,source_site) VALUES(?,?,?)')->execute([$r['package_id'],$r['package_hash'],$m['source']]);
     $ackId=hash('sha256','ACK|'.$r['package_id']);
     $this->db->prepare('INSERT IGNORE INTO dx_ack_outbox(ack_id,package_id,source_site,destination,result,original_package_hash) VALUES(?,?,?,?,?,?)')->execute([$ackId,$r['package_id'],$this->cfg['site_id'],$m['source'],'SUCCESS',$r['package_hash']]);
     $q=$this->db->prepare("UPDATE dx_inbox SET state='PROCESSED',claim_token=NULL,lease_until=NULL WHERE id=? AND claim_token=?");$q->execute([$r['id'],$r['claim_token']]);if($q->rowCount()!==1)throw new RuntimeException('Inbox update fence lost');
     $this->db->commit();$n++;
    }catch(Throwable $e){$this->db->rollBack();throw $e;}
   }catch(Throwable $e){$this->failClaim('dx_inbox',$r,$e->getMessage());fwrite(STDERR,'Inbox retry: '.$e->getMessage()."\n");}
  }return $n;
 }
 public function buildHacks(){
  $n=0;
  foreach($this->claim('dx_hack_outbox','build-hacks') as $r){
   try{
    if(!$this->leaseValid('dx_hack_outbox',$r))throw new RuntimeException('HACK lease lost');
    $data=['hack_id'=>$r['hack_id'],'package_id'=>$r['package_id'],'original_package_hash'=>$r['package_hash'],'custodian'=>$this->cfg['site_id'],'result'=>'CUSTODY_ACCEPTED'];
    $bytes=$this->envelope($data,$r['destination'],'HACK');
    $id=substr($r['hack_id'],0,32);
    $path=$this->cfg['root'].'/hacks_out/'.$id.'.pkg';
    // Same bytes are never regenerated after a published H-ACK file exists.
    if(is_file($path))throw new RuntimeException('Existing HACK artifact; run reconcile');
    if(!$this->leaseValid('dx_hack_outbox',$r))throw new RuntimeException('HACK lease expired');
    $this->save('hacks_out',$id,$bytes);
    $q=$this->db->prepare("UPDATE dx_hack_outbox SET state='BUILT',claim_token=NULL,lease_until=NULL,artifact_hash=? WHERE id=? AND state='CLAIMED' AND claim_token=? AND lease_until>UTC_TIMESTAMP()");
    $q->execute([hash('sha256',$bytes),$r['id'],$r['claim_token']]);
    if($q->rowCount()!==1)throw new RuntimeException('HACK DB fence lost; reconcile artifact');
    $n++;
   }catch(Throwable $e){$this->failClaim('dx_hack_outbox',$r,$e->getMessage());fwrite(STDERR,'HACK retry: '.$e->getMessage()."\n");}
  }return $n;
 }
 public function receiveHacks(){
  $n=0;
  foreach(glob($this->cfg['root'].'/hacks_in/*.pkg')?:[] as $file){
   try{
    if(filesize($file)>10485760)throw new RuntimeException('Oversized HACK');
    list($m,$hack)=$this->openEnvelope(file_get_contents($file),'HACK');
    $q=$this->db->prepare('SELECT destination,package_hash FROM dx_packages WHERE package_id=?');$q->execute([$hack['package_id']??'']);$original=$q->fetch();
    if(!$original||$original['destination']!==$m['source']||!hash_equals($original['package_hash'],(string)($hack['original_package_hash']??''))||($hack['custodian']??'')!==$m['source']||($hack['result']??'')!=='CUSTODY_ACCEPTED')throw new RuntimeException('HACK identity/hash mismatch');
    $q=$this->db->prepare('SELECT package_id,package_hash,custodian FROM dx_hacks WHERE hack_id=?');$q->execute([$hack['hack_id']]);$prior=$q->fetch();
    if($prior && ($prior['package_id']!==$hack['package_id'] || !hash_equals($prior['package_hash'],$hack['original_package_hash']) || $prior['custodian']!==$m['source']))throw new RuntimeException('HACK ID conflict');
    if(!$prior)$this->db->prepare('INSERT INTO dx_hacks(hack_id,package_id,package_hash,custodian) VALUES(?,?,?,?)')->execute([$hack['hack_id'],$hack['package_id'],$hack['original_package_hash'],$m['source']]);
    unlink($file);$n++;
   }catch(Throwable $e){rename($file,$this->cfg['root'].'/quarantine/'.basename($file));fwrite(STDERR,'HACK quarantined: '.$e->getMessage()."\n");}
  }return $n;
 }

}
