<?php
/** V1.5 OUTER-to-OUTER mTLS transport and signed durable custody receipt. */
final class DxTransport {
    private $db; private $cfg; private $receiptVerifier;
    public function __construct(PDO $db, array $cfg) {
        if (!in_array($cfg['role'] ?? '', array('OUTER','PARENT_OUTER'),true)) throw new RuntimeException('Outer role required');
        $this->db=$db; $this->cfg=$cfg; $this->receiptVerifier=null;
        if (!empty($cfg['pki']['enabled'])) {
            require_once __DIR__.'/DxTrustDirectory.php';
            require_once __DIR__.'/DxCertificateValidator.php';
            require_once __DIR__.'/DxPkiReceiptVerifier.php';
            $p=$cfg['pki'];
            foreach (array('trust_root','authority_public_key','ca_file','environment') as $required) {
                if (empty($p[$required])) throw new RuntimeException('Missing PKI configuration: '.$required);
            }
            $directory=(new DxTrustDirectory($p['trust_root'],$p['authority_public_key']))->current($p['environment']);
            $this->receiptVerifier=new DxPkiReceiptVerifier($directory,$p['ca_file']);
        } elseif (!empty($cfg['pki']['required'])) throw new RuntimeException('PKI is required but not enabled');
    }
    private function peer($site) {
        $p=$this->cfg['peers'][$site]??null;
        if (!is_array($p)) throw new RuntimeException('Unconfigured next-hop peer');
        return $p;
    }
    public function enqueue() {
        $q=$this->db->query("SELECT id,artifact_sha256,next_hop,output_path FROM dx_gateway_custody WHERE state='READY' ORDER BY id LIMIT 100");
        $count=0;
        foreach ($q as $row) {
            // Never attempt HTTPS delivery to an Inner Site; approved handoff is external.
            if (substr($row['next_hop'],-6)==='.INNER') continue;
            $this->peer($row['next_hop']);
            $s=$this->db->prepare("INSERT IGNORE INTO dx_transport_jobs(custody_id,artifact_sha256,next_hop,source_path,state,next_attempt_at) VALUES(?,?,?,?,'PENDING',UTC_TIMESTAMP())");
            $s->execute(array($row['id'],$row['artifact_sha256'],$row['next_hop'],$row['output_path']));
            $count+=$s->rowCount();
        }
        return $count;
    }
    private function claim() {
        $this->db->beginTransaction();
        try {
            $q=$this->db->query("SELECT * FROM dx_transport_jobs WHERE (state IN ('PENDING','RETRY') AND next_attempt_at<=UTC_TIMESTAMP()) OR (state='CLAIMED' AND lease_until<UTC_TIMESTAMP()) ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED");
            $row=$q->fetch(PDO::FETCH_ASSOC);
            if (!$row) {$this->db->commit();return null;}
            $token=bin2hex(random_bytes(16));
            $s=$this->db->prepare("UPDATE dx_transport_jobs SET state='CLAIMED',lease_token=?,lease_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 120 SECOND),attempts=attempts+1 WHERE id=?");
            $s->execute(array($token,$row['id']));$this->db->commit();
            $row['lease_token']=$token;return $row;
        } catch(Throwable $e) {if ($this->db->inTransaction()) $this->db->rollBack();throw $e;}
    }
    public function deliverOne() {
        if (!function_exists('curl_init')) throw new RuntimeException('cURL extension required');
        $job=$this->claim(); if (!$job)return false;
        try {
            $peer=$this->peer($job['next_hop']);
            $file=$job['source_path'];
            if (!is_file($file)||is_link($file)||filesize($file)>10485760||!hash_equals($job['artifact_sha256'],hash_file('sha256',$file))) throw new RuntimeException('Outgoing immutable file missing/modified');
            $body=file_get_contents($file);
            if ($body===false)throw new RuntimeException('File read failed');
            $ch=curl_init($peer['url']);
            curl_setopt_array($ch,array(
                CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_HTTPHEADER=>array('Content-Type: application/octet-stream','X-DX-SHA256: '.$job['artifact_sha256'],'Expect:'),
                CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,
                CURLOPT_CAINFO=>$this->cfg['mtls']['ca_file'],
                CURLOPT_SSLCERT=>$this->cfg['mtls']['client_cert'],
                CURLOPT_SSLKEY=>$this->cfg['mtls']['client_key'],
                CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>60,
                CURLOPT_FOLLOWLOCATION=>false,CURLOPT_MAXREDIRS=>0
            ));
            $response=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
            $err=curl_error($ch);curl_close($ch);
            if ($response===false||$code!==200) throw new RuntimeException('mTLS HTTP transfer failed: '.$code.' '.$err);
            $receipt=json_decode($response,true,16,JSON_THROW_ON_ERROR);
            $this->verifyReceipt($receipt,$job,$peer);
            $s=$this->db->prepare("UPDATE dx_transport_jobs SET state='CUSTODY_CONFIRMED',receipt_json=?,lease_token=NULL,lease_until=NULL,last_error=NULL WHERE id=? AND lease_token=? AND state='CLAIMED'");
            $s->execute(array($response,$job['id'],$job['lease_token']));
            if ($s->rowCount()!==1)throw new RuntimeException('Worker lease lost; receipt outcome must be reconciled');
            return true;
        } catch(Throwable $e) {
            $s=$this->db->prepare("UPDATE dx_transport_jobs SET state=IF(attempts>=12,'QUARANTINED','RETRY'),next_attempt_at=DATE_ADD(UTC_TIMESTAMP(),INTERVAL LEAST(3600,POW(2,LEAST(attempts,10))*5) SECOND),lease_token=NULL,lease_until=NULL,last_error=? WHERE id=? AND lease_token=? AND state='CLAIMED'");
            $s->execute(array(substr($e->getMessage(),0,900),$job['id'],$job['lease_token']));
            fwrite(STDERR,'Delivery retry/hold: '.$e->getMessage()."\n");return false;
        }
    }
    private function verifyReceipt($r,$job,$peer) {
        if (!is_array($r)||!isset($r['signed'],$r['signature']))throw new RuntimeException('Malformed custody receipt');
        $v=$r['signed'];
        if (($v['protocol']??'')!=='DX-HOP-RECEIPT-V1.5'||($v['receiver']??'')!==$job['next_hop']||($v['sender']??'')!==$this->cfg['site_id']||($v['sha256']??'')!==$job['artifact_sha256']||($v['status']??'')!=='DURABLE')throw new RuntimeException('Custody receipt binding mismatch');
        if ($this->receiptVerifier!==null) {
            if (empty($peer['receipt_key_id'])) throw new RuntimeException('Missing trusted receipt key ID');
            $this->receiptVerifier->verify($r,$this->cfg['site_id'],$job['next_hop'],$job['artifact_sha256'],$peer['receipt_key_id']);
            return;
        }
        $key=openssl_pkey_get_public(file_get_contents($peer['receipt_public_key']));
        $sig=base64_decode($r['signature'],true);
        if (!$key||$sig===false||openssl_verify('DX-HOP-RECEIPT-V1.5|'.json_encode($v,JSON_UNESCAPED_SLASHES),$sig,$key,OPENSSL_ALGO_SHA256)!==1)throw new RuntimeException('Invalid receipt signature');
    }
    public function status(){return $this->db->query('SELECT id,artifact_sha256,next_hop,state,attempts,next_attempt_at,last_error FROM dx_transport_jobs ORDER BY id DESC LIMIT 100')->fetchAll(PDO::FETCH_ASSOC);}
}
