-- Run ONCE after V1.1 upgrade, independently on EACH site database. Backup first.
CREATE TABLE dx_inbox (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 package_id CHAR(32) NOT NULL, package_hash CHAR(64) NOT NULL,
 source_site VARCHAR(100) NOT NULL, file_path VARCHAR(1024) NOT NULL,
 state VARCHAR(30) NOT NULL DEFAULT 'PENDING', attempts INT UNSIGNED NOT NULL DEFAULT 0,
 claim_token CHAR(32) NULL, lease_until DATETIME NULL, next_attempt_at DATETIME NULL,
 last_error VARCHAR(500) NULL, received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_inbox_package(package_id), KEY ix_inbox_claim(state,next_attempt_at,lease_until,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE dx_hack_outbox (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 hack_id CHAR(64) NOT NULL, package_id CHAR(32) NOT NULL,
 package_hash CHAR(64) NOT NULL, destination VARCHAR(100) NOT NULL,
 state VARCHAR(30) NOT NULL DEFAULT 'PENDING', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_hack_id(hack_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE dx_hacks (
 hack_id CHAR(64) PRIMARY KEY, package_id CHAR(32) NOT NULL,
 package_hash CHAR(64) NOT NULL, custodian VARCHAR(100) NOT NULL,
 received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
