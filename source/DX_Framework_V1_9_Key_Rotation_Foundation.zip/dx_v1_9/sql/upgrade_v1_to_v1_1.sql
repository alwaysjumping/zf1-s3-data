-- Run once on EACH site's own database after backing up.
ALTER TABLE dx_outbox
 ADD COLUMN attempts INT UNSIGNED NOT NULL DEFAULT 0,
 ADD COLUMN claim_token CHAR(32) NULL,
 ADD COLUMN lease_until DATETIME NULL,
 ADD COLUMN next_attempt_at DATETIME NULL,
 ADD COLUMN last_error VARCHAR(500) NULL,
 ADD KEY ix_outbox_claim (state,next_attempt_at,lease_until,id);
ALTER TABLE dx_ack_outbox
 ADD COLUMN attempts INT UNSIGNED NOT NULL DEFAULT 0,
 ADD COLUMN claim_token CHAR(32) NULL,
 ADD COLUMN lease_until DATETIME NULL,
 ADD COLUMN next_attempt_at DATETIME NULL,
 ADD COLUMN last_error VARCHAR(500) NULL,
 ADD KEY ix_ack_claim (state,next_attempt_at,lease_until,id);
ALTER TABLE dx_acks ADD COLUMN original_package_hash CHAR(64) NULL;
ALTER TABLE dx_ack_outbox ADD COLUMN original_package_hash CHAR(64) NULL;
CREATE TABLE dx_worker_audit (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 worker_name VARCHAR(50) NOT NULL,
 reference_id VARCHAR(100) NULL,
 action VARCHAR(50) NOT NULL,
 detail VARCHAR(500) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY ix_worker_time(worker_name,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
