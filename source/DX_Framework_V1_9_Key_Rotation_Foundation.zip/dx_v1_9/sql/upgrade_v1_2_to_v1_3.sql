-- Apply once to each site AFTER the V1.2 migrations. Back up first.
ALTER TABLE dx_hack_outbox
 ADD COLUMN attempts INT UNSIGNED NOT NULL DEFAULT 0,
 ADD COLUMN claim_token CHAR(32) NULL,
 ADD COLUMN lease_until DATETIME NULL,
 ADD COLUMN next_attempt_at DATETIME NULL,
 ADD COLUMN last_error VARCHAR(500) NULL,
 ADD COLUMN artifact_hash CHAR(64) NULL,
 ADD KEY ix_hack_claim (state,next_attempt_at,lease_until,id);
-- The existing queue tables support QUARANTINED as a VARCHAR state.
