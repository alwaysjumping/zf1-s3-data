-- Execute on each OUTER gateway database. A separate DB per site is mandatory.
CREATE TABLE IF NOT EXISTS dx_gateway_routes (
 source_site VARCHAR(100) NOT NULL,
 destination_site VARCHAR(100) NOT NULL,
 message_kind VARCHAR(12) NOT NULL,
 next_hop VARCHAR(100) NOT NULL,
 enabled TINYINT(1) NOT NULL DEFAULT 1,
 PRIMARY KEY(source_site,destination_site,message_kind),
 KEY ix_gateway_next_hop(next_hop)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS dx_gateway_custody (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 artifact_sha256 CHAR(64) NOT NULL,
 origin_site VARCHAR(100) NOT NULL,
 final_destination VARCHAR(100) NOT NULL,
 message_kind VARCHAR(12) NOT NULL,
 next_hop VARCHAR(100) NOT NULL,
 state VARCHAR(24) NOT NULL DEFAULT 'RECEIVED',
 output_path VARCHAR(1024) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_gateway_artifact(artifact_sha256),
 KEY ix_gateway_state(state,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
