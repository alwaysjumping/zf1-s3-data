-- Apply ONLY to each Outer gateway database; separate DB per site.
CREATE TABLE IF NOT EXISTS dx_transport_jobs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 custody_id BIGINT UNSIGNED NOT NULL,
 artifact_sha256 CHAR(64) NOT NULL,
 next_hop VARCHAR(100) NOT NULL,
 source_path VARCHAR(1024) NOT NULL,
 state VARCHAR(32) NOT NULL DEFAULT 'PENDING',
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 next_attempt_at DATETIME NOT NULL,
 lease_token CHAR(32) NULL,
 lease_until DATETIME NULL,
 last_error VARCHAR(1000) NULL,
 receipt_json TEXT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_transport_custody(custody_id),
 KEY ix_transport_due(state,next_attempt_at,id),
 KEY ix_transport_lease(state,lease_until)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS dx_http_receipts (
 sha256 CHAR(64) NOT NULL PRIMARY KEY,
 upstream_site VARCHAR(100) NOT NULL,
 received_at DATETIME NOT NULL,
 KEY ix_upstream(upstream_site)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
