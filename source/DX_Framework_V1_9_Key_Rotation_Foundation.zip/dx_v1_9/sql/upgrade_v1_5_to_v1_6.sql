-- Apply to Outer databases after V1.5. Metadata only; no private keys in DB.
CREATE TABLE IF NOT EXISTS dx_trust_acceptance (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 directory_version BIGINT UNSIGNED NOT NULL,
 bundle_sha256 CHAR(64) NOT NULL,
 environment VARCHAR(50) NOT NULL,
 accepted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uk_environment_version(environment,directory_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS dx_site_certificates (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 site_id VARCHAR(100) NOT NULL,
 key_id VARCHAR(100) NOT NULL,
 purpose VARCHAR(24) NOT NULL,
 certificate_sha256 CHAR(64) NOT NULL,
 serial_hex VARCHAR(100) NOT NULL,
 status VARCHAR(24) NOT NULL,
 directory_version BIGINT UNSIGNED NOT NULL,
 UNIQUE KEY uk_key_id(key_id),
 KEY idx_site_purpose(site_id,purpose,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
