<?php
/** Only publish behind Apache TLS with SSLVerifyClient require; see docs. */
require dirname(__DIR__).'/src/DxHttpReceiver.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');
try {
    $cfgfile=getenv('DX_GATEWAY_CONFIG')?:dirname(__DIR__).'/config/gateway.php';
    if (!is_file($cfgfile))throw new RuntimeException('Gateway configuration unavailable');
    $receiver=new DxHttpReceiver(require $cfgfile);
    echo json_encode($receiver->receive(),JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
} catch(Throwable $e) {
    http_response_code(403);
    error_log('DX receive rejected: '.$e->getMessage());
    echo json_encode(array('error'=>'rejected'));
}
