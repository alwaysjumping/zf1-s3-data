# DX Framework V1.9 — In-flight Encryption-Key Rotation Foundation

**Status:** PHP 7.4-oriented **development prototype**, NOT production approved. Contains all prior V1.8 files and functionality.

## Changes

- `src/DxDecryptionKeyring.php`: strict recipient key-ID → authorized private-key file mapping. Only `ACTIVE` and `DECRYPT_ONLY` keys are selectable, each with an explicit `accept_until` UTC Unix timestamp. Unknown and expired key IDs fail closed. The keyring **never tries all keys** and does not alter the signed package.
- `src/DxInnerPki.php`: if `inner_pki.decryption_keyring` is provided, verify the exact matching certificate/key pair for the **signed** recipient key ID. Existing single-key mode remains for legacy test installations.
- `src/Dx.php`: unwraps the CEK with the key file selected for the signed recipient key ID after strict Inner PKI verification. Existing package builder still selects the current active recipient certificate from the signed directory.
- `src/DxCrlPolicy.php`: **optional standalone** offline CRL freshness gate; maps approved issuer IDs to CA-issued CRL files, verifies lastUpdate age, then invokes the existing OpenSSL CRL validation. This helper is **not globally enforced**; no claim of complete revocation coverage.
- `tests/v1_9_static.php`: keyring selection, unknown-key, expired-key and revoked-state negative tests without MariaDB.
- `config/inner.v1_9.rotation.example.php`: rotation example. Replace dates/paths and install trusted certificates before use.

## Critical rotation procedure

1. Generate and issue new destination encryption certificate using approved enterprise CA and security procedures.
2. Publish it through a verified, signed, higher-version trust directory; confirm senders accepted the update.
3. Configure the receiving Inner Site keyring with `ACTIVE` new and `DECRYPT_ONLY` old key. **Both keys require matching trusted certificate entries** in the accepted directory.
4. Set `active_encryption_key_id` in the recipient's signed trust-directory entry to the new key; only newly built packages use it.
5. Continue accepting in-flight old-key packages until the documented cutoff. Key-ID binding is covered by the original package signature.
6. After all outstanding packages are reconciled, remove old private key from active runtime and follow secure retirement procedures.
7. On suspected compromise, revoke/suspend keys and routes immediately; do not use ordinary grace-period logic.

## Run offline static tests

```sh
php tests/v1_9_static.php
php tests/v1_8_static.php
php tests/v1_7_static.php
php tests/pki-selftest.php
```

## Known gaps / release blockers

1. **CRL enforcement is not integrated everywhere.** `DxCrlPolicy` is a building block, not complete revocation handling. Before production, wire verified issuer-specific CRLs and max-age policy into every signing, encryption, gateway, mTLS and ACK certificate validation boundary. Review intermediate CA revocation and historical-signature policy.
2. **Keyring uses file paths**, not an HSM or managed key provider; permissions, secrets, audit and backup need hardening.
3. **Trust-directory key lifecycle metadata** currently does not fully model key activation, historical validity, or compromise effective time. A revoked key must not be accepted just because it appears in a keyring.
4. Existing **legacy `Dx.php` signature verification also uses a configured public-key map**; strict PKI and legacy verification paths need an explicit migration review.
5. The original `DX-V1-DEMO` envelope format is not the finalized DXPP protocol; canonical serialization and cryptographic interoperability remain release gates.
6. No complete two-DB or five-site MariaDB/mTLS integration run in this environment; PHP 7.4 runtime compatibility must be tested on target machines.
7. Strict network isolation remains unchanged: Inner↔Outer transfer only via approved external file handoff, Outer↔Outer via HTTPS/mTLS.

## Recommended V2.0

Build a complete five-site integration harness with independent databases, CA-issued test certificates, strict trust directories, controlled manual handoff, failure injection, and end-to-end ACK reconciliation; then finish global CRL enforcement and enterprise policy checks.
