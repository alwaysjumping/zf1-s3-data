<?php
/** ZF1-compatible facade. IMPORTANT: use the same PDO as the business transaction. */
class S3_DataExchange_Api {
    private $pdo;
    private $siteId;
    private $destinations;
    public function __construct(PDO $pdo, $siteId, array $destinations) {
        $this->pdo=$pdo; $this->siteId=$siteId; $this->destinations=$destinations;
    }
    public function publish($eventType, $destinationSite, array $payload, array $options=array()) {
        if ($eventType !== 'email.deliver') throw new InvalidArgumentException('Unsupported event type');
        if (!isset($this->destinations[$destinationSite])) throw new InvalidArgumentException('Destination not authorized');
        foreach (array('sender','recipient','subject','body') as $field) {
            if (!isset($payload[$field]) || !is_string($payload[$field])) throw new InvalidArgumentException('Invalid email payload');
        }
        $eventId=isset($options['event_id']) ? $options['event_id'] : bin2hex(random_bytes(16));
        if (!is_string($eventId) || !preg_match('/^[A-Za-z0-9_.:-]{1,100}$/D', $eventId)) throw new InvalidArgumentException('Invalid event ID');
        $json=json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $stmt=$this->pdo->prepare('INSERT INTO dx_outbox(event_id,event_type,destination,payload) VALUES(?,?,?,?)');
        $stmt->execute(array($eventId,$eventType,$destinationSite,$json));
        // NO COMMIT here: business caller owns its transaction.
        return $eventId;
    }
}
