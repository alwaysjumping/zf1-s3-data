#!/usr/bin/env bash
set -euo pipefail
php -l src/Dx.php
php -l bin/dx.php
php -r 'if (!extension_loaded("openssl") || !extension_loaded("pdo_mysql")) exit(1); echo "Extensions OK\n";'
echo 'Smoke prerequisites OK; see README for full DB round trip.'
