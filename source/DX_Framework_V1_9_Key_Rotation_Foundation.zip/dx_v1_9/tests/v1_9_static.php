<?php
require_once __DIR__.'/../src/DxDecryptionKeyring.php';
function expectFailure($f,$label){try{$f();throw new RuntimeException('Accepted invalid '.$label);}catch(RuntimeException $e){if(strpos($e->getMessage(),'Accepted invalid')===0)throw $e;}}
$tmp=tempnam(sys_get_temp_dir(),'dx-key-');file_put_contents($tmp,'TEST-ONLY-NOT-A-KEY');
try {
 $r=new DxDecryptionKeyring(array('NEW'=>array('state'=>'ACTIVE','private_key_file'=>$tmp,'accept_until'=>2000000000),'OLD'=>array('state'=>'DECRYPT_ONLY','private_key_file'=>$tmp,'accept_until'=>1900000000)));
 if($r->select('NEW',1800000000)!==$tmp || $r->select('OLD',1800000000)!==$tmp)throw new RuntimeException('Key selection failed');
 expectFailure(function()use($r){$r->select('UNKNOWN',1800000000);},'unknown key');
 expectFailure(function()use($r){$r->select('OLD',1950000000);},'expired key');
 expectFailure(function()use($tmp){new DxDecryptionKeyring(array('X'=>array('state'=>'REVOKED','private_key_file'=>$tmp,'accept_until'=>2000000000)));},'revoked key');
 echo "V1.9 keyring tests PASS\n";
}finally{unlink($tmp);}
