<?php
require_once __DIR__.'/../src/DxTrustDirectory.php';
function check($v,$why) {if (!$v) throw new RuntimeException('FAILED: '.$why);}
$base=sys_get_temp_dir().'/dx-pki-'.bin2hex(random_bytes(6));mkdir($base,0700,true);
$key=openssl_pkey_new(array('private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1'));
if (!$key) throw new RuntimeException('EC OpenSSL support required');
openssl_pkey_export($key,$private);
$pub=openssl_pkey_get_details($key)['key'];file_put_contents($base.'/authority.pub',$pub);
$t=new DxTrustDirectory($base.'/trust',$base.'/authority.pub');
$d=array('schema_version'=>1,'directory_version'=>1,'environment'=>'test','expires_at'=>gmdate('c',time()+3600),'sites'=>array());
$bytes=json_encode($d,JSON_THROW_ON_ERROR);$sig='';openssl_sign("DX-TRUST-DIRECTORY-V1.6\0".$bytes,$sig,$key,OPENSSL_ALGO_SHA256);
check($t->accept($bytes,$sig,'test')['directory_version']===1,'accept v1');
check($t->current('test')['directory_version']===1,'read current');
check($t->accept($bytes,$sig,'test')['directory_version']===1,'identical replay');
$bad=$bytes.' ';
try {$t->accept($bad,$sig,'test');throw new RuntimeException('Tampered signature accepted');}catch (RuntimeException $e) {check($e->getMessage()!=='Tampered signature accepted','tamper rejected');}
$d['directory_version']=2;$bytes2=json_encode($d,JSON_THROW_ON_ERROR);$sig2='';openssl_sign("DX-TRUST-DIRECTORY-V1.6\0".$bytes2,$sig2,$key,OPENSSL_ALGO_SHA256);
check($t->accept($bytes2,$sig2,'test')['directory_version']===2,'accept v2');
try {$t->accept($bytes,$sig,'test');throw new RuntimeException('Rollback accepted');}catch (RuntimeException $e) {check($e->getMessage()!=='Rollback accepted','rollback rejected');}
$d['expires_at']=gmdate('c',time()-3600);$expired=json_encode($d,JSON_THROW_ON_ERROR);$esig='';openssl_sign("DX-TRUST-DIRECTORY-V1.6\0".$expired,$esig,$key,OPENSSL_ALGO_SHA256);
try {$t->accept($expired,$esig,'test');throw new RuntimeException('Expired bundle accepted');}catch (RuntimeException $e) {check($e->getMessage()!=='Expired bundle accepted','expiry rejected');}
echo "PASS: signed trust bundle, replay, tamper, rollback, expiry\n";
