<?php
require dirname(__DIR__).'/src/DxTransport.php';
require dirname(__DIR__).'/src/DxHttpReceiver.php';
if (!class_exists('DxTransport')||!class_exists('DxHttpReceiver'))exit(1);
$code=file_get_contents(dirname(__DIR__).'/src/DxTransport.php');
if (strpos($code,'CURLOPT_SSL_VERIFYPEER=>true')===false||strpos($code,'CURLOPT_SSL_VERIFYHOST=>2')===false)exit(2);
$receiver=file_get_contents(dirname(__DIR__).'/src/DxHttpReceiver.php');
if (strpos($receiver,"SSL_CLIENT_VERIFY")===false)exit(3);
echo "V1.5 static checks passed (not an integration test)\n";
