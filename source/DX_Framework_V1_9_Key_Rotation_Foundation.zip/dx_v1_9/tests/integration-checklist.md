# DX 1.1 integration checklist (execute with separate MariaDB site databases)

1. Apply V1 schema and `sql/upgrade_v1_to_v1_1.sql` to BOTH sites.
2. Publish 1 email on A, build on A; assert exactly one READY package and BUILT outbox row.
3. Manually copy the file to B `in/`, run receive; assert exactly one `dx_mailbox` row, one `dx_processed` row and one `dx_ack_outbox` row.
4. Copy the identical event package to B again, receive; assert mailbox row count stays 1 and no duplicate ACK outbox row.
5. Build ACK on B, copy to A `acks_in/`, receive ACK; assert `dx_packages.state=DELIVERED`.
6. Modify one byte of a package, deliver to B; assert quarantine and no mailbox insert.
7. Replace ACK `original_package_hash` in its signed data (without re-signing); assert quarantine.
8. Inject an untrusted signer key; assert quarantine.
9. Set an outbox row `state='CLAIMED',lease_until=UTC_TIMESTAMP()-INTERVAL 1 SECOND`; run `recover`; assert row is PENDING and claim_token NULL.
10. Force build error (invalid recipient public key path); assert row returns to PENDING, attempts increases and next_attempt_at is in the future.
11. Start two build workers concurrently with many outbox rows; assert each row has at most one successful `dx_packages` reference and no duplicate business effects.
12. Delete a READY package in the isolated test fixture; run `recover`; assert `missing_ready_files` count and `dx_worker_audit` entry. Restore from approved backup; do not regenerate with same ID.
13. Repeat tests after process termination at file write, DB commit, and ACK build stages. Review staging leftovers manually.

**Caution:** Some of these are acceptance tests for work still required (notably crash-point cleanup and fully fenced multi-worker execution). Do not treat this checklist as evidence that tests have passed.
