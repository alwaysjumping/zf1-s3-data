<?php
require dirname(__DIR__).'/src/DxRecipientKeyResolver.php';
require dirname(__DIR__).'/src/DxPkiReceiptVerifier.php';
require dirname(__DIR__).'/src/DxPkiVerifier.php';
require dirname(__DIR__).'/src/DxGateway.php';
require dirname(__DIR__).'/src/DxTransport.php';
$ref=new ReflectionClass('DxGateway');
if (!$ref->hasMethod('ingest')) throw new RuntimeException('Gateway ingest missing');
$resolver=new DxRecipientKeyResolver(array('sites'=>array()),'/no/ca');
try {$resolver->resolve('UNKNOWN.INNER','bad');throw new RuntimeException('Unknown key accepted');}
catch(RuntimeException $e) {if ($e->getMessage()==='Unknown key accepted') throw $e;}
$verifier=new DxPkiReceiptVerifier(array('sites'=>array()),'/no/ca');
try {$verifier->verify(array('signed'=>array()),'A.OUTER','PARENT.OUTER',str_repeat('0',64),'bad');throw new RuntimeException('Forged receipt accepted');}
catch(RuntimeException $e) {if ($e->getMessage()==='Forged receipt accepted') throw $e;}
echo "V1.7 static and rejection checks passed\n";
