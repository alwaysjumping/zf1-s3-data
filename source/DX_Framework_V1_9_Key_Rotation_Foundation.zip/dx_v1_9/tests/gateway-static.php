<?php
require dirname(__DIR__).'/src/DxGateway.php';
$reflection=new ReflectionClass('DxGateway');
foreach (array('ingest','forward','status') as $name) {
 if (!$reflection->hasMethod($name)) throw new RuntimeException('Missing '.$name);
}
echo "Gateway API static smoke test passed\n";
