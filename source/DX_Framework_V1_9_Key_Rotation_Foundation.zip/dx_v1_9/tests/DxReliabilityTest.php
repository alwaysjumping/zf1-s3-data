<?php
// PHPUnit 9.x (PHP 7.4 compatible) reference unit tests.
require_once dirname(__DIR__).'/src/Dx.php';
use PHPUnit\Framework\TestCase;
final class DxReliabilityTest extends TestCase {
    private function withoutConstructor() {
        return (new ReflectionClass(Dx::class))->newInstanceWithoutConstructor();
    }
    public function testBackoffBoundedAndPositive() {
        $dx=$this->withoutConstructor();
        $method=new ReflectionMethod(Dx::class,'backoff');
        $method->setAccessible(true);
        foreach ([1,2,3,10,100] as $attempt) {
            $seconds=$method->invoke($dx,$attempt);
            $this->assertGreaterThan(0,$seconds);
            $this->assertLessThanOrEqual(3600,$seconds);
        }
    }
    public function testClaimRejectsUnexpectedTable() {
        $dx=$this->withoutConstructor();
        $method=new ReflectionMethod(Dx::class,'claim');
        $method->setAccessible(true);
        $this->expectException(RuntimeException::class);
        $method->invoke($dx,'users; DROP TABLE users');
    }
}
