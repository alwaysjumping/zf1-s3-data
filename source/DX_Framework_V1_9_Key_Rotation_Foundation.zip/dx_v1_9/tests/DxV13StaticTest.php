<?php
use PHPUnit\Framework\TestCase;
require_once dirname(__DIR__).'/library/S3/DataExchange/Api.php';
final class DxV13StaticTest extends TestCase {
    public function testRejectsUnknownEventBeforeDatabaseWrite(): void {
        $pdo=$this->createMock(PDO::class);
        $api=new S3_DataExchange_Api($pdo,'COMPANY_A.INNER',array('COMPANY_B.INNER'=>true));
        $this->expectException(InvalidArgumentException::class);
        $api->publish('unknown.event','COMPANY_B.INNER',array());
    }
    public function testRejectsUnauthorizedDestination(): void {
        $pdo=$this->createMock(PDO::class);
        $api=new S3_DataExchange_Api($pdo,'COMPANY_A.INNER',array());
        $this->expectException(InvalidArgumentException::class);
        $api->publish('email.deliver','UNAUTHORIZED.INNER',array());
    }
}
