<?php
require dirname(__DIR__).'/src/DxInnerPki.php';
require dirname(__DIR__).'/src/Dx.php';
function rejects($callable,$label) {
    try {$callable();}catch (RuntimeException $e){echo 'PASS '.$label.': '.$e->getMessage()."\n";return;}
    throw new RuntimeException('FAIL open '.$label);
}
rejects(function(){new DxInnerPki(array());},'missing strict configuration');
rejects(function(){new DxInnerPki(array('trust_root'=>'/no/trust','authority_public_key'=>'/no/authority','ca_file'=>'/no/ca','environment'=>'test','signer_key_id'=>'x','decryption_key_id'=>'y','site_id'=>'A.INNER','sign_private'=>'/no/sign','decrypt_private'=>'/no/dec'));},'untrusted authority');
$reflection=new ReflectionClass('DxInnerPki');
foreach (array('verifyEnvelope','encryptionKey','assertLocalDecryptKey','checkLocalSigning') as $name) if (!$reflection->hasMethod($name)) throw new RuntimeException('Missing method '.$name);
echo "V1.8 strict-mode rejection and API tests passed\n";
