# Version 1.3 MariaDB integration and fault-injection plan

These are **manual acceptance procedures**, not claims of executed tests.

1. Apply all migrations in sequence to two isolated databases; use independent private keys.
2. Publish an email inside an existing business PDO transaction; roll it back and verify no `dx_outbox` row exists.
3. Commit another business mutation plus `S3_DataExchange_Api::publish()` and verify both commit together.
4. Build and handoff the package; ingest, process, build H-ACK and E-ACK; return and verify both.
5. Start two `build-hacks` workers simultaneously; exactly one may claim the H-ACK row.
6. Kill H-ACK builder after file rename but before DB update; `reconcile` must expose the artifact and builder must not overwrite it.
7. Change a stored H-ACK hash or identity; receiver must quarantine conflict.
8. Force repeated transient failures to 12 attempts; queue must enter `QUARANTINED` and stop retrying.
9. Remove a BUILT H-ACK file; `reconcile` must report missing artifact.
10. Remove an inbox file; `reconcile` must report missing or modified artifact.
11. Duplicate E-ACK and H-ACK: verify idempotent results and no duplicate business commits.
12. Stop workers mid-transaction and after file rename; recover and reconcile; never regenerate an existing immutable file.
13. Execute under actual PHP 7.4 and MariaDB 10.11 with concurrent processes and constrained filesystem permissions.

**Known gaps:** This prototype has no full durable journal, automatic recovery of every crash window, end-to-end integration harness, final PKI, complete authorization or multi-hop routing. Do not use in production.
