<?php

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../src/Calculator.php';

class CalculatorTest extends TestCase
{
    public function testAdd()
    {
        $calculator = new Calculator();

        $result = $calculator->add(10, 20);

        $this->assertEquals(30, $result);
    }

    public function testSubtract()
    {
        $calculator = new Calculator();

        $result = $calculator->subtract(20, 5);

        $this->assertEquals(15, $result);
    }

    public function testDivide()
    {
        $calculator = new Calculator();

        $result = $calculator->divide(20, 4);

        $this->assertEquals(5, $result);
    }

    public function testDivideByZero()
    {
        $calculator = new Calculator();

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Cannot divide by zero.');

        $calculator->divide(10, 0);
    }
}