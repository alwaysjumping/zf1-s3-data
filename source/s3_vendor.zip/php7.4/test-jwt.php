<?php

require_once __DIR__ . '/vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$key = 'replace-this-with-a-long-random-secret';

$payload = array(
    'sub' => '123',
    'iat' => time(),
    'exp' => time() + 900
);

$token = JWT::encode(
    $payload,
    $key,
    'HS256'
);

echo "JWT:\n";
echo $token;
echo "\n\n";

$decoded = JWT::decode(
    $token,
    new Key($key, 'HS256')
);

print_r($decoded);