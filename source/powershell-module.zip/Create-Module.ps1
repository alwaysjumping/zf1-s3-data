#requires -version 5.1
<#
Version 4.8: required JSON/INI choice for all configurations; archive semantic verification.
Run from the workspace. See README-Package-Module.md for usage.
#>
[CmdletBinding()]
param(
    [string]$WinRarPath = '',
    [string]$GitPath = '',
    [string]$ConfigFile = '',
    [ValidateSet('','Suite','Single')][string]$PackageType = '',
    [string]$ChildKey = '',
    [ValidateSet('', 'Development', 'Production')][string]$BuildType = '',
    [string]$ExpectedRemoteUrl = 'https://github.com/Shardj/zf1-future.git',
    [string]$GitRemoteName = 'origin',
    [string]$LocalGitRepository = 'C:\module-repository',
    [string]$ModuleUploadPath = 'modules',
    [ValidateSet('Ask','Yes','No')][string]$SmbUpload = 'Ask',
    [ValidateSet('Ask','Yes','No')][string]$GitPublish = 'Ask',
    [switch]$BuildOnly,
    [switch]$ValidateOnly
)
$DefaultSmbPath = '\\172.16.61.1\resource$'
$DefaultSmbUsername = 'ourman'
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
function Find-Application([string]$ExplicitPath, [string]$Name, [string[]]$RelativePaths) {
    if ($ExplicitPath) {
        $full = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ExplicitPath)
        if ([IO.File]::Exists($full) -and [IO.Path]::GetFileName($full) -ieq $Name) { return $full }
        return $null
    }
    $commands = @(Get-Command $Name -CommandType Application -ErrorAction SilentlyContinue)
    if ($commands.Count -gt 0) { return $commands[0].Definition }
    foreach ($variable in @('ProgramFiles','ProgramFiles(x86)','LOCALAPPDATA')) {
        $base = [Environment]::GetEnvironmentVariable($variable)
        if ($base) {
            foreach ($relative in $RelativePaths) {
                $candidate = Join-Path $base $relative
                if ([IO.File]::Exists($candidate)) { return $candidate }
            }
        }
    }
    return $null
}

function Initialize-Helpers {
    if ('ModulePackageV412.Json' -as [type]) { return }
    # Embedded helpers use the .NET Framework supplied with Windows PowerShell 5.1.
    # Strict parser avoids the non-JSON extensions accepted by JavaScriptSerializer.
    Add-Type -TypeDefinition @"
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Security;
using System.Runtime.InteropServices;
using System.ComponentModel;
namespace ModulePackageV412 {
    public static class Files {
        public static void CheckContained(string root, string candidate) {
            string boundary = Path.GetFullPath(root).TrimEnd('\\');
            string full = Path.GetFullPath(candidate).TrimEnd('\\');
            if (!full.Equals(boundary, StringComparison.OrdinalIgnoreCase) &&
                !full.StartsWith(boundary + "\\", StringComparison.OrdinalIgnoreCase))
                throw new IOException("Path resolves outside the allowed root.");
            string current = full;
            while (true) {
                try {
                    if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                        throw new IOException("Path contains a symbolic link or junction: " + current);
                } catch (FileNotFoundException) { } catch (DirectoryNotFoundException) { }
                if (current.TrimEnd('\\').Equals(boundary, StringComparison.OrdinalIgnoreCase)) break;
                current = Path.GetDirectoryName(current);
            }
        }
        public static void ReplaceBackup(string source, string destination, string backup) {
            File.Replace(source, destination, backup);
        }
        public static void Replace(string source, string destination) {
            // C# passes a real null rather than an empty backup-file path.
            File.Replace(source, destination, null);
        }
    }
    public sealed class Number {
        private string value;
        public Number(string text) { value = text; }
        public override string ToString() { return value; }
    }
    public sealed class Json {
        private string text;
        private int pos;
        private Json(string input) { text = input; }
        private void Fail(string reason) {
            int line = 1, column = 1;
            for (int i = 0; i < pos; i++) { if (text[i] == '\n') { line++; column = 1; } else column++; }
            throw new FormatException("Invalid JSON at line " + line + ", column " + column + ": " + reason);
        }
        private void White() { while (pos < text.Length && (text[pos] == ' ' || text[pos] == '\t' || text[pos] == '\r' || text[pos] == '\n')) pos++; }
        private bool Take(char c) { White(); if (pos < text.Length && text[pos] == c) { pos++; return true; } return false; }
        private void Need(char c) { if (!Take(c)) Fail("Expected '" + c + "'."); }
        private string StringValue() {
            Need('"'); StringBuilder result = new StringBuilder();
            while (pos < text.Length) {
                char c = text[pos++];
                if (c == '"') return result.ToString();
                if (c < 32) Fail("Unescaped control character in string.");
                if (c != '\\') { result.Append(c); continue; }
                if (pos == text.Length) Fail("Incomplete string escape.");
                c = text[pos++];
                switch (c) {
                    case '"': case '\\': case '/': result.Append(c); break;
                    case 'b': result.Append('\b'); break;
                    case 'f': result.Append('\f'); break;
                    case 'n': result.Append('\n'); break;
                    case 'r': result.Append('\r'); break;
                    case 't': result.Append('\t'); break;
                    case 'u':
                        if (pos + 4 > text.Length || !Regex.IsMatch(text.Substring(pos, 4), "^[0-9a-fA-F]{4}$")) Fail("Invalid Unicode escape.");
                        result.Append((char)Convert.ToInt32(text.Substring(pos, 4), 16)); pos += 4; break;
                    default: Fail("Unknown string escape."); break;
                }
            }
            Fail("Unterminated string."); return null;
        }
        private object Value(int depth) {
            White(); if (depth > 100) Fail("Nesting exceeds 100 levels.");
            if (pos == text.Length) { Fail("Expected a value."); return null; }
            char c = text[pos];
            if (c == '"') return StringValue();
            if (c == '{') {
                pos++; OrderedDictionary map = new OrderedDictionary(StringComparer.Ordinal);
                if (Take('}')) return map;
                do {
                    White(); if (pos == text.Length || text[pos] != '"') Fail("Object keys must be double-quoted.");
                    string key = StringValue(); if (map.Contains(key)) Fail("Duplicate key: " + key);
                    Need(':'); map.Add(key, Value(depth + 1));
                    if (Take('}')) return map;
                    Need(',');
                } while (true);
            }
            if (c == '[') {
                pos++; ArrayList list = new ArrayList(); if (Take(']')) return list;
                do { list.Add(Value(depth + 1)); if (Take(']')) return list; Need(','); } while (true);
            }
            foreach (string word in new string[] { "true", "false", "null" }) {
                if (text.Length - pos >= word.Length && text.Substring(pos, word.Length) == word) {
                    pos += word.Length; if (word == "null") return null; return word == "true";
                }
            }
            Match number = Regex.Match(text.Substring(pos), @"^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?");
            if (number.Success) { pos += number.Length; return new Number(number.Value); }
            Fail("Expected a JSON value."); return null;
        }
        public static object Parse(string input) {
            Json parser = new Json(input); object result = parser.Value(0); parser.White();
            if (parser.pos != input.Length) parser.Fail("Unexpected characters after the value.");
            return result;
        }
    }
    public static class Smb {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct Resource {
            public int Scope, Type, Display, Usage;
            public string Local, Remote, Comment, Provider;
        }
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
        private static extern int WNetAddConnection2W(ref Resource resource, IntPtr password, string username, int flags);
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
        private static extern int WNetCancelConnection2W(string name, int flags, bool force);
        public static string Connect(string share, string username, SecureString password) {
            IntPtr pointer = Marshal.SecureStringToGlobalAllocUnicode(password);
            try {
                string[] used = Directory.GetLogicalDrives();
                for (char letter = 'Z'; letter >= 'D'; letter--) {
                    string drive = letter + ":"; if (Array.IndexOf(used, drive + "\\") >= 0) continue;
                    Resource resource = new Resource(); resource.Type = 1; resource.Local = drive; resource.Remote = share;
                    int code = WNetAddConnection2W(ref resource, pointer, username, 0);
                    if (code == 0) return drive;
                    if (code != 85) throw new Win32Exception(code);
                }
                throw new IOException("No free drive letter is available for SMB.");
            } finally { Marshal.ZeroFreeGlobalAllocUnicode(pointer); }
        }
        public static int Disconnect(string drive) { return WNetCancelConnection2W(drive, 0, false); }
    }
}
"@
}

function Require-Object($Value, [string]$Location) {
    if (-not ($Value -is [Collections.IDictionary])) { throw "$Location must be a JSON object." }
}

function Require-Array($Value, [string]$Location) {
    if (-not ($Value -is [Collections.IList])) { throw "$Location must be a JSON array." }
}

function Require-Fields($Object, [string[]]$Fields, [string]$Location) {
    Require-Object $Object $Location
    foreach ($field in $Fields) { if (-not $Object.Contains($field)) { throw "Required value is missing: $Location.$field" } }
}

function Require-Text($Value, [string]$Location, [bool]$AllowEmpty) {
    if (-not ($Value -is [string]) -or (-not $AllowEmpty -and $Value.Trim().Length -eq 0)) { throw "$Location must be a string with an appropriate value." }
}

function Get-NextBuild($Value) {
    if (-not ($Value -is [string]) -and -not ($Value -is [ModulePackageV412.Number])) { throw 'Target build_no must be a non-negative Int64 integer.' }
    $text = $Value.ToString()
    [long]$number = 0
    if ($text -notmatch '^[0-9]+$' -or -not [long]::TryParse($text, [ref]$number) -or $number -eq [long]::MaxValue) { throw 'Target build_no is invalid or would overflow Int64.' }
    return ($number + [long]1).ToString([Globalization.CultureInfo]::InvariantCulture)
}

function ConvertTo-JsonText($Value, [int]$Depth = 0) {
    if ($null -eq $Value) { return 'null' }
    $nl = [Environment]::NewLine
    if ($Value -is [Collections.IDictionary]) {
        $items = @()
        foreach ($key in $Value.Keys) { $items += (' ' * (($Depth+1)*2)) + (ConvertTo-Json -InputObject ([string]$key) -Compress) + ': ' + (ConvertTo-JsonText $Value[$key] ($Depth+1)) }
        if ($items.Count -eq 0) { return '{}' }
        return '{' + $nl + ($items -join (','+$nl)) + $nl + (' ' * ($Depth*2)) + '}'
    }
    if ($Value -is [Collections.IList]) {
        $items = @()
        foreach ($item in $Value) { $items += ConvertTo-JsonText $item ($Depth+1) }
        return '[' + ($items -join ', ') + ']'
    }
    if ($Value -is [ModulePackageV412.Number]) { return $Value.ToString() }
    return ConvertTo-Json -InputObject $Value -Compress
}

function Read-JsonDocument([string]$Path) {
    $bytes = [IO.File]::ReadAllBytes($Path)
    $encoding = New-Object Text.UTF8Encoding($false,$true)
    $skip = 0
    if ($bytes.Length -ge 4 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254 -and $bytes[2] -eq 0 -and $bytes[3] -eq 0) {
        $encoding = New-Object Text.UTF32Encoding($false,$true,$true); $skip=4
    } elseif ($bytes.Length -ge 4 -and $bytes[0] -eq 0 -and $bytes[1] -eq 0 -and $bytes[2] -eq 254 -and $bytes[3] -eq 255) {
        $encoding = New-Object Text.UTF32Encoding($true,$true,$true); $skip=4
    } elseif ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) {
        $encoding = New-Object Text.UTF8Encoding($true,$true); $skip=3
    } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254) {
        $encoding = New-Object Text.UnicodeEncoding($false,$true,$true); $skip=2
    } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 254 -and $bytes[1] -eq 255) {
        $encoding = New-Object Text.UnicodeEncoding($true,$true,$true); $skip=2
    }
    return @{Text=$encoding.GetString($bytes,$skip,$bytes.Length-$skip);Encoding=$encoding;Bytes=$bytes;Digest=(Get-BytesDigest $bytes)}
}

function Read-Default([string]$Prompt, [string]$Default) {
    $value = Read-Host "$Prompt [$Default]"
    if ($value.Trim().Length -eq 0) { return $Default }; return $value.Trim()
}

function Ask-YesNo([string]$Prompt, [string]$Choice) {
    if ($Choice -eq 'Yes') { return $true }
    if ($Choice -eq 'No') { return $false }
    while ($true) {
        $answer = (Read-Default "$Prompt (y/n)" 'n').ToLowerInvariant()
        if ($answer -eq 'y' -or $answer -eq 'yes') { return $true }
        if ($answer -eq 'n' -or $answer -eq 'no') { return $false }
        Write-Host 'Please enter y or n.'
    }
}

function Replace-GeneratedFile([string]$NewFile, [string]$Destination) {
    if ([IO.File]::Exists($Destination)) {
        if (((Get-Item -LiteralPath $Destination -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Refusing to replace a symbolic link: $Destination" }
        [ModulePackageV412.Files]::Replace($NewFile, $Destination)
    } else { [IO.File]::Move($NewFile, $Destination) }
}

function Invoke-WinRar([string[]]$Arguments, [string]$WorkingDirectory) {
    $quoted = @()
    foreach ($argument in $Arguments) {
        # Windows command-line quoting; escape backslashes only before quotes/end.
        $value = [regex]::Replace($argument, '(\\*)"', '$1$1\"')
        $value = [regex]::Replace($value, '(\\+)$', '$1$1')
        $quoted += '"' + $value + '"'
    }
    $process = Start-Process -FilePath $WinRarPath -ArgumentList ($quoted -join ' ') -WorkingDirectory $WorkingDirectory -WindowStyle Hidden -PassThru -Wait
    try { if ($process.ExitCode -ne 0) { throw "WinRAR failed (exit code $($process.ExitCode)); archive was not published." } }
    finally { $process.Dispose() }
}

function Invoke-Git([string[]]$Arguments, [int[]]$AllowedExitCodes = @(0)) {
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $messages = @(& $GitPath @Arguments 2>&1); $code = $LASTEXITCODE }
    finally { $ErrorActionPreference = $old }
    $script:LastGitExitCode = $code
    if ($AllowedExitCodes -notcontains $code) { throw "Git failed: $($Arguments -join ' ')`n$($messages -join "`n")" }
    return $messages
}

function Send-Smb([string]$Archive) {
    $path = Read-Default 'SMB directory' $DefaultSmbPath
    $username = Read-Default 'SMB username' $DefaultSmbUsername
    if ($path -notmatch '^(\\\\[^\\]+\\[^\\]+)(\\.*)?$') { throw 'SMB path must be a UNC directory such as \\server\share\folder.' }
    $share = $Matches[1]; $suffix = [string]$Matches[2]
    if ($suffix -match '(^|\\)\.\.($|\\)') { throw 'SMB path cannot contain parent traversal.' }
    $password = Read-Host 'SMB password' -AsSecureString
    $drive = $null; $partial = $null
    try {
        $drive = [ModulePackageV412.Smb]::Connect($share, $username, $password)
        $folder = $drive + '\' + $suffix.TrimStart([char]'\')
        if (-not [IO.Directory]::Exists($folder)) { throw "SMB directory does not exist: $path" }
        $destination = [IO.Path]::Combine($folder, [IO.Path]::GetFileName($Archive))
        if ([IO.File]::Exists($destination)) { throw "SMB ZIP already exists: $path\$([IO.Path]::GetFileName($Archive))" }
        $partial = $destination + '.' + [Guid]::NewGuid().ToString('N') + '.uploading'
        [IO.File]::Copy($Archive, $partial, $false)
        [IO.File]::Move($partial, $destination); $partial = $null
        Write-Host "Uploaded to $path"
    } finally {
        $password.Dispose()
        if ($partial -and [IO.File]::Exists($partial)) { try { [IO.File]::Delete($partial) } catch { Write-Warning "Temporary upload remains: $partial" } }
        if ($drive) { $result = [ModulePackageV412.Smb]::Disconnect($drive); if ($result -ne 0) { Write-Warning "Could not disconnect $drive (error $result)." } }
    }
}

function Send-Git([string]$Archive) {
    if (-not $LocalGitRepository) { throw 'Configure LocalGitRepository before publishing.' }
    $repository = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($LocalGitRepository)
    if (-not [IO.Directory]::Exists($repository)) { throw "Local Git repository directory does not exist: $repository" }
    if (-not $ModuleUploadPath -or $ModuleUploadPath.Trim().Length -eq 0) { throw 'ModuleUploadPath must be a nonempty relative directory.' }
    $upload = $ModuleUploadPath.Replace('/', '\')
    if ([IO.Path]::IsPathRooted($upload) -or $upload -match '[:*?"<>|\x00-\x1F]') { throw 'ModuleUploadPath must be a relative path inside the local Git repository.' }
    foreach ($part in $upload.Split([char]'\')) {
        if ($part -eq '.git') { throw 'ModuleUploadPath must not point into Git metadata.' }
        if ($part -ne '.' -and $part -ne '..' -and $part -match '[. ]$') { throw 'ModuleUploadPath segments cannot end in dots or spaces.' }
    }
    $directory = [IO.Path]::GetFullPath([IO.Path]::Combine($repository, $upload))
    $name = [IO.Path]::GetFileName($Archive)
    $destination = [IO.Path]::Combine($directory, $name)
    [ModulePackageV412.Files]::CheckContained($repository, $destination)
    if (-not $ExpectedRemoteUrl -or $ExpectedRemoteUrl.StartsWith('-')) { throw 'Set ExpectedRemoteUrl to the intended Git repository URL.' }
    if (-not $GitRemoteName -or $GitRemoteName.StartsWith('-')) { throw 'GitRemoteName is invalid.' }
    $pendingCopy = $null
    Push-Location -LiteralPath $repository
    try {
        # Read-only Git inspection is necessary to verify repository and effective URL.
        # No directory creation, copy, staging, commit or push occurs until it passes.
        $root = [string](Invoke-Git @('rev-parse','--show-toplevel'))
        if ([IO.Path]::GetFullPath($root).TrimEnd('\') -ine $repository.TrimEnd('\')) { throw 'LocalGitRepository must be the root of a valid Git working repository.' }
        $urls = @(Invoke-Git @('remote','get-url','--push','--all',$GitRemoteName))
        if ($urls.Count -ne 1 -or [string]$urls[0] -cne $ExpectedRemoteUrl) { throw "The push URL for '$GitRemoteName' does not match ExpectedRemoteUrl, or it has multiple push URLs. No ZIP was copied, staged or committed." }
        $branch = [string](Invoke-Git @('symbolic-ref','--quiet','--short','HEAD'))
        $unmerged = @(Invoke-Git @('ls-files','--unmerged'))
        if ($unmerged.Count -gt 0) { throw 'Resolve Git merge conflicts before publishing.' }

        try {
            [ModulePackageV412.Files]::CheckContained($repository, $destination)
            [IO.Directory]::CreateDirectory($directory) | Out-Null
            [ModulePackageV412.Files]::CheckContained($repository, $destination)
            $pendingCopy = Join-Path $directory ('.module-copy-' + [Guid]::NewGuid().ToString('N') + '.tmp')
            [IO.File]::Copy($Archive, $pendingCopy, $false)
            Replace-GeneratedFile $pendingCopy $destination
            $pendingCopy = $null
        } catch { throw ('Failed to copy ZIP into the local Git repository: ' + $_.Exception.Message) }
        Write-Host "Copied ZIP to: $destination"
        $relative = $destination.Substring($repository.TrimEnd('\').Length + 1).Replace('\', '/')
        Invoke-Git @('add','--',$relative) | Out-Host
        Invoke-Git @('diff','--cached','--quiet','--',$relative) @(0,1) | Out-Host
        if ($script:LastGitExitCode -eq 1) {
            # Only the copied ZIP enters the commit; unrelated staged work is retained.
            Invoke-Git @('commit','--only','-m',('Added ' + $name),'--',$relative) | Out-Host
            Write-Host "Committed: Added $name"
        } else { Write-Host 'ZIP is unchanged in Git; no new commit was needed.' }
        Invoke-Git @('-c','push.followTags=false','push',$ExpectedRemoteUrl,('HEAD:refs/heads/' + $branch)) | Out-Host
        Write-Host "Pushed branch $branch successfully."
    } finally {
        if ($pendingCopy -and [IO.File]::Exists($pendingCopy)) { try { [IO.File]::Delete($pendingCopy) } catch { Write-Warning "Temporary copy remains: $pendingCopy" } }
        Pop-Location
    }
}
function Get-BytesDigest([byte[]]$Bytes) {
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-','') }
    finally { $sha.Dispose() }
}
function Get-FileDigest([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Resolve-SafePath([string]$Relative,[string]$Root) {
    if ([string]::IsNullOrWhiteSpace($Relative)) { throw 'A relative path is required.' }
    $value=$Relative.Replace('/','\')
    if ([IO.Path]::IsPathRooted($value) -or $value -match '[:*?"<>|\x00-\x1F]' -or $value -match '\\\\') { throw "Unsafe relative path: $Relative" }
    foreach($segment in $value.Split([char]'\')) {
        if (-not $segment -or $segment -eq '.' -or $segment -eq '..' -or $segment -match '[. ]$' -or $segment -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\.|$)') {
            throw "Unsafe relative path: $Relative"
        }
    }
    $full=[IO.Path]::GetFullPath([IO.Path]::Combine($Root,$value))
    [ModulePackageV412.Files]::CheckContained($Root,$full)
    return $full
}
function Read-Configuration([string]$Path) {
    [ModulePackageV412.Files]::CheckContained($Workspace,$Path)
    if (-not [IO.File]::Exists($Path)) { throw "Configuration does not exist: $Path" }
    $document=Read-JsonDocument $Path
    $config=[ModulePackageV412.Json]::Parse($document.Text)
    Require-Object $config $Path
    foreach($section in $config.Keys){
        if(-not ($config[$section] -is [Collections.IDictionary]) -and -not ($config[$section] -is [Collections.IList])){
            throw "Top-level configuration section must be an object or array: $Path/$section"
        }
    }
    $hasSuite=$config.Contains('suite'); $hasModule=$config.Contains('module')
    if ($hasSuite -eq $hasModule) { throw "Configuration must contain exactly one of suite or module: $Path" }
    $kind='module'; $keyField='key'
    if($hasSuite){$kind='suite';$keyField='module_key'}
    $metadata=$config[$kind]
    Require-Fields $metadata @($keyField,'name','version','framework_version','build_no','build_info') "$Path/$kind"
    foreach($field in @($keyField,'name','version','framework_version','build_info')) {
        Require-Text $metadata[$field] "$Path/$kind.$field" ($field -eq 'build_info')
    }
    $identifier=$metadata[$keyField]
    if($identifier -notmatch '^[A-Za-z0-9][A-Za-z0-9_-]*$'){throw "Unsafe module identifier: $identifier"}
    if($metadata['version'] -notmatch '^[A-Za-z0-9][A-Za-z0-9_.+-]*$'){throw "Unsafe version in $Path"}
    # Non-target dependencies need a valid number, but need not be incrementable.
    $value=$metadata['build_no']; [long]$number=0
    if((-not ($value -is [string]) -and -not ($value -is [ModulePackageV412.Number])) -or $value.ToString() -notmatch '^[0-9]+$' -or -not [long]::TryParse($value.ToString(),[ref]$number)) {
        throw "Invalid nonnegative Int64 build_no in $Path"
    }
    $exclusions=@{}
    if($config.Contains('source_exclude_extension')){
        Require-Array $config['source_exclude_extension'] "$Path/source_exclude_extension"
        foreach($extension in $config['source_exclude_extension']){
            Require-Text $extension 'Excluded extension' $false
            $normalized=$extension.TrimStart([char]'.')
            if($normalized -notmatch '^[A-Za-z0-9_-]+$'){throw "Invalid excluded extension: $extension"}
            $exclusions[$normalized.ToLowerInvariant()]=$true
        }
    }
    return @{Path=$Path;Document=$document;Config=$config;Kind=$kind;Metadata=$metadata;Key=$identifier;Exclusions=$exclusions}
}
function Select-Number([string]$Prompt,[int]$Count) {
    while($true){
        $answer=Read-Host $Prompt
        [int]$number=0
        if([int]::TryParse($answer,[ref]$number) -and $number -ge 1 -and $number -le $Count){return $number-1}
        Write-Host "Please enter a number from 1 to $Count."
    }
}
function Select-Configuration {
    $candidates=@(Get-ChildItem -LiteralPath $Workspace -File -Filter 'config*.json' | Sort-Object Name)
    if($candidates.Count -eq 0){throw 'No config*.json file exists in the workspace.'}
    if($ConfigFile){
        $matches=@($candidates | Where-Object {$_.Name -ieq $ConfigFile})
        if($matches.Count -ne 1){throw '-ConfigFile must name one discovered config*.json file without a directory path.'}
        return Read-Configuration $matches[0].FullName
    }
    if($candidates.Count -eq 1){Write-Host "Selected: $($candidates[0].Name)";return Read-Configuration $candidates[0].FullName}
    for($i=0;$i -lt $candidates.Count;$i++){
        $description='invalid configuration'
        try{$preview=Read-Configuration $candidates[$i].FullName;$description="$($preview.Kind): $($preview.Metadata['name']), $($preview.Metadata['version'])"}
        catch{$description='invalid: '+$_.Exception.Message}
        Write-Host ('{0}. {1} ({2})' -f ($i+1),$candidates[$i].Name,$description)
    }
    $index=Select-Number 'Select configuration' $candidates.Count
    return Read-Configuration $candidates[$index].FullName
}
function Get-SuiteChildren($Suite) {
    $metadata=$Suite.Metadata
    Require-Fields $metadata @('count') 'suite'
    $raw=$metadata['count'];[int]$count=0
    if((-not ($raw -is [string]) -and -not ($raw -is [ModulePackageV412.Number])) -or $raw.ToString() -notmatch '^[1-9][0-9]*$' -or -not [int]::TryParse($raw.ToString(),[ref]$count)){throw 'suite.count must be a positive integer.'}
    $numbered=@($metadata.Keys | Where-Object {[string]$_ -match '^[0-9]+$'})
    if($numbered.Count -ne $count){throw 'suite.count does not match the number of listed children.'}
    $seen=@{};$children=New-Object Collections.ArrayList
    for($i=1;$i -le $count;$i++){
        $index=$i.ToString([Globalization.CultureInfo]::InvariantCulture)
        if(-not $metadata.Contains($index)){throw "Missing suite child index: $index"}
        $key=$metadata[$index]
        Require-Text $key "suite.$index" $false
        if($key -notmatch '^[A-Za-z0-9][A-Za-z0-9_-]*$' -or $seen.ContainsKey($key) -or $key -ieq $Suite.Key){throw "Unsafe or duplicate suite child identifier: $key"}
        $seen[$key]=$true;[void]$children.Add($key)
    }
    return ,$children
}
# Manifest records are explicit paths plus immutable content hashes captured before staging.
function Add-ManifestFile($Manifest,[string]$Relative,[string]$Path,[string]$Owner,[string]$Role) {
    $relativeName=$Relative.Replace('\','/')
    $null=Resolve-SafePath $relativeName $Workspace
    if(-not [IO.File]::Exists($Path)){throw "Required file does not exist: $Relative"}
    [ModulePackageV412.Files]::CheckContained($Workspace,$Path)
    $digest=Get-FileDigest $Path
    if($Manifest.ContainsKey($relativeName)){
        $old=$Manifest[$relativeName]
        # The same required SQL dependency may already be ordinary source.
        if($Role -eq 'sql' -and ($old.Role -eq 'source' -or $old.Role -eq 'sql') -and $old.Relative -ceq $relativeName -and $old.Path -ieq $Path -and $old.Digest -ceq $digest){
            $old.Role='sql';return
        }
        throw "Duplicate or conflicting ZIP entry mapping: $relativeName"
    }
    $Manifest.Add($relativeName,@{Relative=$relativeName;Path=$Path;Digest=$digest;Owner=$Owner;Role=$Role})
}
function Add-RequiredSql($Target,$Manifest) {
    if(-not $Target.Config.Contains('tables')){return}
    $tables=$Target.Config['tables']
    Require-Array $tables 'tables'
    $seen=@{}
    foreach($table in $tables){
        Require-Text $table 'Table name' $false
        if($table -match '[\\/:*?"<>|\x00-\x1F]' -or $table.Contains('..') -or $table -match '[. ]$' -or $table -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\.|$)'){
            throw "Unsafe table name: $table"
        }
        if($seen.ContainsKey($table)){if($seen[$table] -cne $table){throw "Conflicting table name capitalization: $table"};continue}
        $seen[$table]=$table
        $relative='tables/mysql/'+$table+'.sql'
        $full=Resolve-SafePath $relative $Workspace
        $sqlRoot=[IO.Path]::Combine($Workspace,'tables\mysql')
        [ModulePackageV412.Files]::CheckContained($sqlRoot,$full)
        if(-not [IO.File]::Exists($full)){throw "Required SQL file does not exist: $relative. Configuration: $($Target.Path). Module: $($Target.Key). Table: $table. No original configuration files were modified."}
        Add-ManifestFile $Manifest $relative $full $Target.Key 'sql'
    }
}
function Test-ZipManifest([string]$Zip,$Manifest,[string]$PrimaryDigest,[string]$PrimaryName) {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $expected=New-Object 'Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
    $expected.Add($PrimaryName,$PrimaryDigest)
    foreach($record in $Manifest.Values){$expected.Add($record.Relative,$record.Digest)}
    $seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $archive=[IO.Compression.ZipFile]::Open($Zip,[IO.Compression.ZipArchiveMode]::Read,[Text.Encoding]::GetEncoding(437))
    try {
        foreach($entry in $archive.Entries){
            $name=$entry.FullName
            if(-not $seen.Add($name) -or -not $expected.ContainsKey($name)){throw "Unexpected, duplicate or unsafe ZIP entry: $name"}
            $stream=$entry.Open();$sha=[Security.Cryptography.SHA256]::Create()
            try{$hash=[BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','')}
            finally{$stream.Dispose();$sha.Dispose()}
            if($hash -cne $expected[$name]){throw "ZIP content mismatch: $name"}
            $null=$expected.Remove($name)
        }
        if($expected.Count){throw ('Missing ZIP entries: '+($expected.Keys -join ', '))}
    } finally {$archive.Dispose()}
}
function New-TargetJson($Target,[DateTime]$Timestamp,[bool]$RetainTemplate) {
    # Clone from the read snapshot; original files and dependency objects remain untouched.
    $staged=[ModulePackageV412.Json]::Parse($Target.Document.Text)
    $metadata=$staged[$Target.Kind]
    $next=Get-NextBuild $metadata['build_no']
    $wasString=$metadata['build_no'] -is [string]
    if($wasString){$metadata['build_no']=$next}
    else{$metadata['build_no']=New-Object ModulePackageV412.Number $next}
    $metadata['install_date']=$Timestamp.ToString('yyyy-MM-dd HH:mm:ss',[Globalization.CultureInfo]::InvariantCulture)
    $template=$metadata['build_info']
    if($metadata.Contains('build_info_template')){
        Require-Text $metadata['build_info_template'] 'build_info_template' $true
        $template=$metadata['build_info_template']
    } elseif($RetainTemplate) {$metadata.Add('build_info_template',$template)}
    $metadata['build_info']=$template.Replace('@framework_version',$metadata['framework_version']).Replace('@build_no',$next).Replace('@current_date',$Timestamp.ToString('yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture))
    $text=(ConvertTo-JsonText $staged)+[Environment]::NewLine
    $null=[ModulePackageV412.Json]::Parse($text)
    return $text
}
function Commit-LocalBuild($Target,[string]$StagedJson,[string]$VerifiedZip,[string]$FinalZip) {
    # Two replacements are not a filesystem transaction; keep a recovery backup.
    $original=$Target.Path
    $directory=[IO.Path]::GetDirectoryName($original)
    $temporary=Join-Path $directory ('.module-'+[Guid]::NewGuid().ToString('N')+'.json.tmp')
    $backup=Join-Path $directory ('.module-'+[Guid]::NewGuid().ToString('N')+'.json.backup')
    $updated=$false
    try {
        [ModulePackageV412.Files]::CheckContained($Workspace,$original)
        if((Get-FileDigest $original) -cne $Target.Document.Digest){throw "Target JSON changed since it was read; refusing to overwrite: $original"}
        [IO.File]::WriteAllText($temporary,$StagedJson,$Target.Document.Encoding)
        [IO.File]::Copy($original,$backup,$false)
        if((Get-FileDigest $backup) -cne $Target.Document.Digest -or (Get-FileDigest $original) -cne $Target.Document.Digest){
            throw "Target JSON changed while preparing its backup; refusing to overwrite: $original"
        }
        try {
            [ModulePackageV412.Files]::Replace($temporary,$original)
            $updated=$true
        } catch {
            $saveFailure=$_.Exception.Message
            # File.Replace failure normally leaves destination intact. Restore only if it changed.
            if([IO.File]::Exists($original) -and (Get-FileDigest $original) -cne $Target.Document.Digest){
                try{[ModulePackageV412.Files]::Replace($backup,$original)}
                catch{throw "JSON save failed: $saveFailure. Recovery failed; original snapshot retained at $backup"}
            }
            throw "Failed to save target JSON; ZIP will not be published. $saveFailure"
        }
        try { Replace-GeneratedFile $VerifiedZip $FinalZip }
        catch {
            $placementFailure=$_.Exception.Message
            try {
                [ModulePackageV412.Files]::Replace($backup,$original)
                $updated=$false
            } catch { throw "ZIP placement failed: $placementFailure. JSON recovery failed; restore the backup at $backup" }
            throw "ZIP placement failed; original target JSON restored. $placementFailure"
        }
        if([IO.File]::Exists($backup)){[IO.File]::Delete($backup)}
    } finally {
        if([IO.File]::Exists($temporary)){[IO.File]::Delete($temporary)}
        # A failed rollback retains backup; untouched/restored destinations need no recovery copy.
        if(-not $updated -and [IO.File]::Exists($backup) -and [IO.File]::Exists($original) -and (Get-FileDigest $original) -ceq $Target.Document.Digest){
            [IO.File]::Delete($backup)
        }
    }
}
function Test-ReservedSource([string]$Relative) {
    $parts=$Relative.Replace('\','/').Split([char]'/')
    foreach($part in $parts){
        if($part -match '^(\.git|output|tmp|temp|staging)$' -or $part -like '.module-*' -or $part -like 'ModulePackage-*'){return $true}
    }
    return $Relative -match '(?i)(\.tmp|\.temp|\.bak|\.backup|\.uploading|~)$'
}
function Get-OwnerCandidates($Owner,$ReservedConfigs) {
    $config=$Owner.Config
    if(-not $config.Contains('source')){
        if($Owner.Kind -eq 'module'){throw "Required source array is missing: $($Owner.Path)"}
        return ,(New-Object Collections.ArrayList)
    }
    Require-Array $config['source'] "$($Owner.Path)/source"
    $result=New-Object Collections.ArrayList
    $seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach($entry in $config['source']){
        Require-Text $entry 'source entry' $false
        $full=Resolve-SafePath $entry $Workspace
        if(-not [IO.File]::Exists($full) -and -not [IO.Directory]::Exists($full)){throw "Source path does not exist: $entry"}
        # Output is never a source. Other reserved paths need an exact explicit entry.
        $relative=$full.Substring($Workspace.TrimEnd('\').Length+1).Replace('\','/')
        if($relative -match '^output(/|$)'){throw "The workspace output directory cannot be packaged: $entry"}
        $stack=New-Object Collections.Stack
        $stack.Push(@{Path=$full;Explicit=$true})
        while($stack.Count){
            $frame=$stack.Pop();$path=[string]$frame.Path
            [ModulePackageV412.Files]::CheckContained($Workspace,$path)
            $relative=$path.Substring($Workspace.TrimEnd('\').Length+1).Replace('\','/')
            if($relative -match '^output(/|$)'){continue}
            if(-not $frame.Explicit){
                $beneathEntry=$path.Substring($full.TrimEnd('\').Length+1).Replace('\','/')
                if(Test-ReservedSource $beneathEntry){continue}
            }
            if([IO.Directory]::Exists($path)){
                # Stable ordinal order, depth first, for every expanded directory.
                [string[]]$entries=@(Get-ChildItem -LiteralPath $path -Force | ForEach-Object {$_.FullName})
                [Array]::Sort($entries,[StringComparer]::Ordinal)
                for($i=$entries.Count-1;$i -ge 0;$i--){$stack.Push(@{Path=$entries[$i];Explicit=$false})}
            } else {
                if($ReservedConfigs.ContainsKey($path) -or $relative -match '(?i)^(config\.(json|ini)|history(?:_[^/]+)?\.json)(/|$)'){
                    throw "Source/configuration collision: $relative"
                }
                if($seen.Add($relative)){
                    $extension=[IO.Path]::GetExtension($path).TrimStart([char]'.').ToLowerInvariant()
                    [void]$result.Add(@{
                        Relative=$relative;Path=$path;Digest=(Get-FileDigest $path)
                        Excluded=($BuildType -eq 'Production' -and $Owner.Exclusions.ContainsKey($extension))
                    })
                }
            }
        }
    }
    return ,$result
}
function Collect-Sources($Owners,$ReservedConfigs,$Manifest) {
    $all=New-Object 'Collections.Generic.Dictionary[string,object]' ([StringComparer]::OrdinalIgnoreCase)
    # Validate ownership before excluding any candidate, including excluded files.
    foreach($owner in $Owners){
        $owner.Candidates=Get-OwnerCandidates $owner $ReservedConfigs
        foreach($candidate in $owner.Candidates){
            if($all.ContainsKey($candidate.Relative)){
                $existing=$all[$candidate.Relative]
                throw "Source ownership conflict: $($candidate.Relative). Owners: $($existing.Key) ($($existing.Path)) and $($owner.Key) ($($owner.Path)). Packaging aborted before ZIP creation."
            }
            $all.Add($candidate.Relative,$owner)
        }
    }
    foreach($owner in $Owners){
        $owner.PackagedSources=New-Object Collections.ArrayList
        foreach($candidate in $owner.Candidates){
            if($candidate.Excluded){continue}
            [void]$owner.PackagedSources.Add($candidate.Relative)
            Add-ManifestFile $Manifest $candidate.Relative $candidate.Path $owner.Key 'source'
            if($Manifest[$candidate.Relative].Digest -cne $candidate.Digest){throw "Source changed during selection: $($candidate.Relative)"}
        }
    }
}
function New-PackagedJson($Owner,[string]$MetadataJson) {
    $copy=[ModulePackageV412.Json]::Parse($MetadataJson)
    $list=New-Object Collections.ArrayList
    foreach($path in $Owner.PackagedSources){[void]$list.Add([string]$path)}
    if($Owner.Config.Contains('source')){$copy['source']=$list}
    if($copy.Contains('source_exclude_extension')){$copy.Remove('source_exclude_extension')}
    return (ConvertTo-JsonText $copy)+[Environment]::NewLine
}
function Test-PackagedJson($Owner,[string]$Text,[string]$MetadataJson,$Manifest) {
    $copy=[ModulePackageV412.Json]::Parse($Text)
    if($copy.Contains('source_exclude_extension')){throw "Packaged exclusions remain for $($Owner.Key)"}
    if($copy.Contains('source') -ne $Owner.Config.Contains('source')){throw "Packaged source presence mismatch for $($Owner.Key)"}
    if($copy.Contains('source')){
    Require-Array $copy['source'] 'packaged source'
    if($copy['source'].Count -ne $Owner.PackagedSources.Count){throw "Packaged source count mismatch for $($Owner.Key)"}
    for($i=0;$i -lt $copy['source'].Count;$i++){
        $path=[string]$copy['source'][$i]
        if($path -cne $Owner.PackagedSources[$i] -or -not $Manifest.ContainsKey($path)){throw "Packaged source differs from archive manifest: $path"}
    }
    }
    # Remove only the two authorized packaging fields and compare everything else.
    $original=[ModulePackageV412.Json]::Parse($MetadataJson)
    foreach($key in @('source','source_exclude_extension')){
        if($copy.Contains($key)){$copy.Remove($key)}
        if($original.Contains($key)){$original.Remove($key)}
    }
    if((ConvertTo-JsonText $copy) -cne (ConvertTo-JsonText $original)){throw "Unexpected non-source configuration change for $($Owner.Key)"}
}
function Select-BuildType {
    if($BuildType){return $BuildType}
    Write-Host '1. Development (include all declared source extensions)'
    Write-Host '2. Production (apply configured extension exclusions) [default]'
    while($true){
        $answer=Read-Default 'Select build type (1/2)' '2'
        if($answer -eq '1'){return 'Development'}
        if($answer -eq '2'){return 'Production'}
        Write-Host 'Please enter 1 or 2.'
    }
}
function Resolve-Children($Suite) {
    $keys=Get-SuiteChildren $Suite
    $children=New-Object Collections.ArrayList
    foreach($key in $keys){
        # Confirmed mapping: exact child key + .json, directly under workspace.
        $filename=$key+'.json'
        $path=Resolve-SafePath $filename $Workspace
        $child=Read-Configuration $path
        if($child.Kind -ne 'module' -or $child.Key -cne $key){throw "Child $filename must be a regular module with module.key exactly '$key'."}
        $child.IsSuiteChild=$true
        [void]$children.Add($child)
    }
    return ,$children
}
function Test-IniValues($Value, [string]$Location) {
    if ($null -eq $Value) { throw "Null is unsupported at $Location." }
    if ($Value -is [Collections.IDictionary]) {
        foreach ($key in $Value.Keys) {
            if ([string]$key -notmatch '^[A-Za-z0-9_-]+$') { throw "Unsupported INI key at ${Location}: $key" }
            Test-IniValues $Value[$key] "$Location.$key"
        }
    } elseif ($Value -is [Collections.IList]) {
        foreach ($item in $Value) { Test-IniValues $item $Location }
    } elseif ($Value -is [string] -and $Value -match '[\x00-\x08\x0B\x0C\x0E-\x1F]') { throw "Unsupported INI control character at $Location" }
}

function Add-Ini($Lines, [string]$Key, $Value) {
    if ($Key -match '^(null|yes|no|true|false|on|off|none)$') { throw "INI reserved key cannot be represented: $Key" }
    if ($null -eq $Value) { throw 'Null has no INI mapping.' }
    elseif ($Value -is [bool]) { if ($Value) { $text = '1' } else { $text = '0' } }
    else { $text = $Value.ToString() }
    $text = $text.Replace('\','\\').Replace('"','\"').Replace('$','\$')
    [void]$Lines.Add($Key + ' = "' + $text + '"')
}

function Flatten-Ini($Lines, [string]$Prefix, $Value) {
    if ($Value -is [Collections.IDictionary]) {
        foreach ($key in $Value.Keys) {
            $next = [string]$key; if ($Prefix) { $next = $Prefix + '.' + $next }
            Flatten-Ini $Lines $next $Value[$key]
        }
    } elseif ($Value -is [Collections.IList]) {
        for ($i = 0; $i -lt $Value.Count; $i++) {
            $next = [string]$i; if ($Prefix) { $next = $Prefix + '.' + $next }
            Flatten-Ini $Lines $next $Value[$i]
        }
    } else { Add-Ini $Lines $Prefix $Value }
}

function Write-Menus($Lines, $Nodes, [object[]]$Parents, $Counter) {
    foreach ($node in $Nodes) {
        if (-not $node.Contains('children') -or $node['children'].Count -eq 0) {
            $Counter.Value++
            $chain = @($node) + $Parents
            for ($i = 0; $i -lt $chain.Count; $i++) {
                foreach ($key in $chain[$i].Keys) {
                    if ($key -cne 'children') { Flatten-Ini $Lines ($Counter.Value.ToString() + '.' + $i + '.' + $key) $chain[$i][$key] }
                }
            }
        }
        if($node.Contains('children')){Write-Menus $Lines $node['children'] (@($node) + $Parents) $Counter}
    }
}

function New-IniText($Config) {
    $lines = New-Object Collections.ArrayList
    foreach ($section in $Config.Keys) {
        [void]$lines.Add('[' + $section + ']')
        if ($section -ceq 'menus') { Write-Menus $lines $Config[$section] @() @{ Value = 0 } }
        else { Flatten-Ini $lines '' $Config[$section] }
        [void]$lines.Add('')
    }
    return ([string[]]$lines.ToArray() -join [Environment]::NewLine)
}

function Get-IniScalar($Value) {
    if ($null -eq $Value) { throw 'Null has no INI mapping.' }
    if ($Value -is [bool]) { if ($Value) { return '1' }; return '0' }
    return $Value.ToString()
}

function Test-GeneratedIni([string]$Text, $Config) {
    $parsed = New-Object Collections.Specialized.OrderedDictionary ([StringComparer]::Ordinal)
    $pattern = '\G(?:\[(?<section>[A-Za-z0-9_-]+)\]\r?\n|(?<key>[A-Za-z0-9_.-]+) = "(?<value>(?:\\[\\$"]|[^"\\])*)"(?:\r?\n|$)|\r?\n)'
    $regex = New-Object Text.RegularExpressions.Regex($pattern)
    $position = 0; $current = $null
    while ($position -lt $Text.Length) {
        $match = $regex.Match($Text,$position)
        if (-not $match.Success -or $match.Index -ne $position) { throw "Generated INI syntax is invalid at offset $position." }
        $position += $match.Length
        if ($match.Groups['section'].Success) {
            $current = $match.Groups['section'].Value
            if ($parsed.Contains($current)) { throw 'Duplicate INI section.' }
            $parsed.Add($current,(New-Object Collections.Specialized.OrderedDictionary ([StringComparer]::Ordinal)))
        } elseif ($match.Groups['key'].Success) {
            if ($null -eq $current) { throw 'INI key outside a section.' }
            $key = $match.Groups['key'].Value
            if ($parsed[$current].Contains($key)) { throw "Duplicate INI key: $key" }
            $decoded = [regex]::Replace($match.Groups['value'].Value,'\\([\\$"])','$1')
            $parsed[$current].Add($key,$decoded)
        }
    }
    # A separate iterative tree traversal checks every menu group and ancestor.
    function Compare-IniValue($Value,[string]$Prefix,$Map,$Count) {
        if ($Value -is [Collections.IDictionary]) {
            foreach ($key in $Value.Keys) {
                $next = [string]$key; if ($Prefix) { $next = "$Prefix.$key" }
                Compare-IniValue $Value[$key] $next $Map $Count
            }
        } elseif ($Value -is [Collections.IList]) {
            for ($i=0; $i -lt $Value.Count; $i++) {
                $next = [string]$i; if ($Prefix) { $next = "$Prefix.$i" }
                Compare-IniValue $Value[$i] $next $Map $Count
            }
        } else {
            if (-not $Map.Contains($Prefix) -or $Map[$Prefix] -cne (Get-IniScalar $Value)) { throw "Generated INI value mismatch: $Prefix" }
            $Count.Value++
        }
    }
    if ($parsed.Count -ne $Config.Count) { throw 'Generated INI section count mismatch.' }
    foreach ($section in $Config.Keys) {
        if (-not $parsed.Contains($section)) { throw "Missing INI section: $section" }
        $count = @{Value=0}
        if ($section -ceq 'menus') {
            $stack = New-Object Collections.Stack
            for ($i=$Config['menus'].Count-1; $i -ge 0; $i--) { $stack.Push(@{Node=$Config['menus'][$i];Parents=@()}) }
            $group = 0
            while ($stack.Count -gt 0) {
                $frame = $stack.Pop(); $node = $frame.Node
                if (-not $node.Contains('children') -or $node['children'].Count -eq 0) {
                    $group++
                    $chain = @($node) + @($frame.Parents)
                    for ($level=0; $level -lt $chain.Count; $level++) {
                        foreach ($key in $chain[$level].Keys) {
                            if ($key -cne 'children') { Compare-IniValue $chain[$level][$key] "$group.$level.$key" $parsed[$section] $count }
                        }
                    }
                }
                if($node.Contains('children')){for ($i=$node['children'].Count-1; $i -ge 0; $i--) { $stack.Push(@{Node=$node['children'][$i];Parents=(@($node)+@($frame.Parents))}) }}
            }
        } else { Compare-IniValue $Config[$section] '' $parsed[$section] $count }
        if ($count.Value -ne $parsed[$section].Count) { throw "Unexpected INI entries in section $section." }
    }
}
function Test-IniShape($Config) {
    Require-Object $Config 'INI configuration'
    foreach($section in $Config.Keys){
        if(-not ($Config[$section] -is [Collections.IDictionary]) -and -not ($Config[$section] -is [Collections.IList])){
            throw "INI section must be an object or array: $section"
        }
    }
    Test-IniValues $Config 'config'
    if($Config.Contains('menus')){
        function Test-MenuNodes($Nodes){
            Require-Array $Nodes 'menus/children'
            foreach($node in $Nodes){
                Require-Object $node 'menu node'

                if($node.Contains('children')){Test-MenuNodes $node['children']}
            }
        }
        Test-MenuNodes $Config['menus']
    }
}
function Select-ConfigFormat {
    Write-Host 'Select configuration format:'
    Write-Host '1. JSON (default)'
    Write-Host '2. INI'
    while($true){
        $answer=Read-Default 'Enter selection' '1'
        if($answer -eq '1'){return 'json'}
        if($answer -eq '2'){return 'ini'}
        Write-Host 'Please enter 1 or 2.'
    }
}
function Convert-PackagedConfig([string]$CleanJson,[string]$Format) {
    $config=[ModulePackageV412.Json]::Parse($CleanJson)
    if($Format -eq 'json'){return $CleanJson}
    Test-IniShape $config
    $text=New-IniText $config
    Test-GeneratedIni $text $config
    return $text
}
function Test-ArchivedConfigurations([string]$Zip,$Copies,[string]$Format) {
    $archive=[IO.Compression.ZipFile]::Open($Zip,[IO.Compression.ZipArchiveMode]::Read,[Text.Encoding]::GetEncoding(437))
    try{
        foreach($copy in $Copies){
            $entry=$archive.GetEntry($copy.Relative)
            if($null -eq $entry){throw "Missing archived configuration: $($copy.Relative)"}
            $stream=$entry.Open()
            $reader=New-Object IO.StreamReader($stream,(New-Object Text.UTF8Encoding($false,$true)),$true)
            try{$text=$reader.ReadToEnd()}finally{$reader.Dispose();$stream.Dispose()}
            $expected=[ModulePackageV412.Json]::Parse($copy.CleanJson)
            if($Format -eq 'ini'){
                Test-GeneratedIni $text $expected
            } else {
                $actual=[ModulePackageV412.Json]::Parse($text)
                if((ConvertTo-JsonText $actual) -cne (ConvertTo-JsonText $expected)){
                    throw "Archived JSON semantics differ: $($copy.Relative)"
                }
            }
        }
    }finally{$archive.Dispose()}
}
function Compare-HistoryVersion([string]$Left,[string]$Right) {
    # Arbitrary-length numeric components; missing trailing components mean zero.
    $a=$Left.Split([char]'.');$b=$Right.Split([char]'.')
    for($i=0;$i -lt [Math]::Max($a.Length,$b.Length);$i++){
        $x='0';$y='0'
        if($i -lt $a.Length){$x=$a[$i].TrimStart([char]'0');if(-not $x){$x='0'}}
        if($i -lt $b.Length){$y=$b[$i].TrimStart([char]'0');if(-not $y){$y='0'}}
        if($x.Length -ne $y.Length){return $x.Length.CompareTo($y.Length)}
        $result=[StringComparer]::Ordinal.Compare($x,$y)
        if($result -ne 0){return $result}
    }
    return 0
}
function Test-HistoryBytes([byte[]]$Bytes,$Owner,[string]$Location) {
    try{
        $utf8=New-Object Text.UTF8Encoding($false,$true)
        $skip=0
        if($Bytes.Length -ge 3 -and $Bytes[0] -eq 239 -and $Bytes[1] -eq 187 -and $Bytes[2] -eq 191){$skip=3}
        $data=[ModulePackageV412.Json]::Parse($utf8.GetString($Bytes,$skip,$Bytes.Length-$skip))
        Require-Fields $data @('module_key','history') 'history document'
        Require-Text $data['module_key'] 'history.module_key' $false
        if($data['module_key'] -cne $Owner.Key){throw "module_key must exactly match '$($Owner.Key)'."}
        Require-Array $data['history'] 'history'
        if($data['history'].Count -eq 0){throw 'history must be nonempty.'}
        $previous=$null
        foreach($entry in $data['history']){
            Require-Fields $entry @('version','date','changes') 'history entry'
            Require-Text $entry['version'] 'history version' $false
            if($entry['version'] -notmatch '^[0-9]+(\.[0-9]+)*$'){throw "Unsupported history version '$($entry['version'])'; use dotted numeric components."}
            Require-Text $entry['date'] 'history date' $false
            $date=[DateTime]::MinValue
            if($entry['date'] -notmatch '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' -or -not [DateTime]::TryParseExact($entry['date'],'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw 'History date must be a valid YYYY-MM-DD calendar date.'}
            Require-Array $entry['changes'] 'history changes'
            if($entry['changes'].Count -eq 0){throw 'History changes must be nonempty.'}
            foreach($change in $entry['changes']){Require-Text $change 'history change' $false}
            if($null -eq $previous){
                if($entry['version'] -cne $Owner.Metadata['version']){throw "Latest history version '$($entry['version'])' must exactly match configured version '$($Owner.Metadata['version'])'."}
            }elseif((Compare-HistoryVersion $previous $entry['version']) -le 0){
                throw 'History versions must be strictly newest first; duplicate or out-of-order versions are invalid.'
            }
            $previous=$entry['version']
        }
    }catch{throw "Invalid required history for $($Owner.Key) at $Location : $($_.Exception.Message)"}
}
function Get-HistoryName($Owner) {
    $name=[IO.Path]::GetFileName($Owner.Path)
    if($name -ieq 'config.json'){return 'history.json'}
    if($name -imatch '^config_(.+)\.json$'){
        $identifier=$Matches[1]
        if($identifier -notmatch '^[A-Za-z0-9][A-Za-z0-9_-]*$'){throw "Unsafe history identifier in configuration filename: $name"}
        return 'history_'+$identifier+'.json'
    }
    if($Owner.ContainsKey('IsSuiteChild') -and $Owner.IsSuiteChild){return 'history_'+$Owner.Key+'.json'}
    throw "No unambiguous history mapping for configuration: $name"
}
function Add-RequiredHistories($Owners,$Target,$Manifest) {
    $paths=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach($owner in $Owners){
        $name=Get-HistoryName $owner
        $path=Resolve-SafePath $name $Workspace
        if(-not $paths.Add($path)){throw "Duplicate history ownership: $name ($($owner.Key))."}
        if(-not [IO.File]::Exists($path)){throw "Required history does not exist: $path. Owner: $($owner.Key) ($($owner.Path))."}
        $bytes=[IO.File]::ReadAllBytes($path)
        Test-HistoryBytes $bytes $owner $path
        $entry=$name
        if($owner.Path -ieq $Target.Path){$entry='history.json'}
        # Histories are required immutable artifacts; never deduplicate with source.
        Add-ManifestFile $Manifest $entry $path $owner.Key 'history'
        $record=$Manifest[$entry]
        if($record.Digest -cne (Get-BytesDigest $bytes)){throw "History changed during validation: $path"}
        $record.HistoryOwner=$owner
    }
}
function Test-ArchivedHistories([string]$Zip,$Manifest) {
    $archive=[IO.Compression.ZipFile]::Open($Zip,[IO.Compression.ZipArchiveMode]::Read,[Text.Encoding]::GetEncoding(437))
    try{
        foreach($record in $Manifest.Values){
            if($record.Role -ne 'history'){continue}
            $entries=@($archive.Entries|Where-Object {$_.FullName -ceq $record.Relative})
            if($entries.Count -ne 1){throw "Expected exactly one archived history: $($record.Relative)"}
            $stream=$entries[0].Open();$memory=New-Object IO.MemoryStream
            try{$stream.CopyTo($memory);$bytes=$memory.ToArray()}finally{$stream.Dispose();$memory.Dispose()}
            if((Get-BytesDigest $bytes) -cne $record.Digest){throw "Archived history bytes differ: $($record.Relative)"}
            Test-HistoryBytes $bytes $record.HistoryOwner ('ZIP/'+$record.Relative)
        }
    }finally{$archive.Dispose()}
}
function Invoke-Build {
    if((Get-Location).Provider.Name -ne 'FileSystem'){throw 'Run from a filesystem workspace directory.'}
    $script:Workspace=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath('.')
    $script:WinRarPath=Find-Application $WinRarPath 'WinRAR.exe' @('WinRAR\WinRAR.exe','Programs\WinRAR\WinRAR.exe')
    $script:GitPath=Find-Application $GitPath 'git.exe' @('Git\cmd\git.exe','Git\bin\git.exe','Programs\Git\cmd\git.exe')
    if(-not $WinRarPath){throw 'WinRAR is not installed or could not be found. Supply -WinRarPath.'}
    if(-not $GitPath){throw 'Git is not installed or could not be found. Supply -GitPath.'}
    Initialize-Helpers
    $selected=Select-Configuration
    $target=$selected;$dependencies=@();$owners=@($selected)
    if($selected.Kind -eq 'suite'){
        $children=Resolve-Children $selected
        $choice=$PackageType
        if(-not $choice){
            Write-Host '1. Suite Module'
            Write-Host '2. Single Module'
            $number=Select-Number 'Select packaging type' 2
            if($number -eq 0){$choice='Suite'}else{$choice='Single'}
        }
        if($choice -eq 'Single'){
            if($ChildKey){
                $matches=@($children|Where-Object {$_.Key -ceq $ChildKey})
                if($matches.Count -ne 1){throw "ChildKey is not in the selected suite: $ChildKey"}
                $target=$matches[0]
            } else {
                for($i=0;$i -lt $children.Count;$i++){Write-Host ('{0}. {1} ({2})' -f ($i+1),$children[$i].Key,$children[$i].Metadata['version'])}
                $index=Select-Number 'Select child module' $children.Count
                $target=$children[$index]
            }
            $owners=@($target)
        } else {
            if($ChildKey){throw '-ChildKey cannot be used with Suite packaging.'}
            $dependencies=@($children);$owners=@($selected)+@($children)
        }
    } elseif($PackageType -eq 'Suite' -or $ChildKey){throw 'Suite packaging and ChildKey require a suite configuration.'}
    $null=Get-NextBuild $target.Metadata['build_no']
    $script:BuildType=Select-BuildType
    $reserved=@{}
    # Reserve root module configurations, even unselected sibling configurations.
    foreach($file in Get-ChildItem -LiteralPath $Workspace -File -Filter '*.json'){
        if($file.Name -like 'config*.json'){$reserved[$file.FullName]=$true;continue}
        try {
            $candidate=[ModulePackageV412.Json]::Parse((Read-JsonDocument $file.FullName).Text)
            if($candidate -is [Collections.IDictionary] -and ($candidate.Contains('module') -or $candidate.Contains('suite'))){$reserved[$file.FullName]=$true}
        } catch {
            # Unknown non-config JSON is not a dependency; explicit source rules still apply.
        }
    }
    foreach($configPath in @($reserved.Keys)){
        $reserved[[IO.Path]::ChangeExtension($configPath,'.ini')]=$true
    }
    $manifest=New-Object 'Collections.Generic.Dictionary[string,object]' ([StringComparer]::OrdinalIgnoreCase)
    foreach($child in $dependencies){
        $entry=[IO.Path]::GetFileName($child.Path)
        if($entry -ieq 'config.json'){throw 'A child configuration collides with primary config.json.'}
    }
    # Root histories are required artifacts, never ordinary source, even if excluded.
    foreach($file in Get-ChildItem -LiteralPath $Workspace -File -Filter 'history*.json'){
        if($file.Name -imatch '^history(?:_.+)?\.json$'){$reserved[$file.FullName]=$true}
    }
    Collect-Sources $owners $reserved $manifest
    Add-RequiredHistories $owners $target $manifest
    foreach($owner in $owners){Add-RequiredSql $owner $manifest}
    Write-Host ("Validated {0} target {1}; {2} source/SQL/history files. Version remains {3}." -f $BuildType,$target.Key,$manifest.Count,$target.Metadata['version'])

    $buildTime=Get-Date
    # Original target: only metadata is changed; no source cleanup is persisted.
    # Reuse an existing build_info_template but do not add fields to original JSON.
    $json=New-TargetJson $target $buildTime $false
    $primaryText=New-PackagedJson $target $json
    Test-PackagedJson $target $primaryText $json $manifest
    $format=Select-ConfigFormat
    $primaryName='config.'+$format
    $primaryCleanJson=$primaryText
    $primaryText=Convert-PackagedConfig $primaryCleanJson $format
    $packageEncoding=$target.Document.Encoding
    if($format -eq 'ini'){$packageEncoding=New-Object Text.UTF8Encoding($false,$true)}
    $configurationCopies=New-Object Collections.ArrayList
    foreach($child in $dependencies){
        $text=New-PackagedJson $child $child.Document.Text
        Test-PackagedJson $child $text $child.Document.Text $manifest
        $entry=[IO.Path]::GetFileNameWithoutExtension($child.Path)+'.'+$format
        if($manifest.ContainsKey($entry)){throw "Child configuration/source collision: $entry"}
        $childEncoding=$child.Document.Encoding
        if($format -eq 'ini'){$childEncoding=New-Object Text.UTF8Encoding($false,$true)}
        [void]$configurationCopies.Add(@{Owner=$child;Relative=$entry;CleanJson=$text;Text=(Convert-PackagedConfig $text $format);Encoding=$childEncoding})
    }
    $allConfigurationCopies=@(@{Relative=$primaryName;CleanJson=$primaryCleanJson})+@($configurationCopies)
    if($ValidateOnly){Write-Host "Configuration conversion to $format is valid; validation only, no files changed.";return}
    $output=Join-Path $Workspace 'output'
    [ModulePackageV412.Files]::CheckContained($Workspace,$output)
    if([IO.File]::Exists($output)){throw 'output must be a directory.'}
    [IO.Directory]::CreateDirectory($output)|Out-Null
    $name='module_'+$target.Key+'('+$target.Metadata['version']+').zip'
    $archive=Join-Path $output $name
    $temporary=Join-Path ([IO.Path]::GetTempPath()) ('ModulePackage-'+[Guid]::NewGuid().ToString('N'))
    $payload=Join-Path $temporary 'payload'
    $pendingZip=Join-Path $output ('.module-'+[Guid]::NewGuid().ToString('N')+'.zip')
    try {
        [IO.Directory]::CreateDirectory($payload)|Out-Null
        foreach($record in $manifest.Values){
            [ModulePackageV412.Files]::CheckContained($Workspace,$record.Path)
            if((Get-FileDigest $record.Path) -cne $record.Digest){throw "Input changed after validation: $($record.Relative)"}
            $destination=Resolve-SafePath $record.Relative $payload
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destination))|Out-Null
            [IO.File]::Copy($record.Path,$destination,$false)
            if((Get-FileDigest $destination) -cne $record.Digest){throw "Staged bytes differ from validated input: $($record.Relative)"}
        }
        $primary=Join-Path $payload $primaryName
        [IO.File]::WriteAllText($primary,$primaryText,$packageEncoding)
        $primaryDigest=Get-FileDigest $primary
        foreach($copy in $configurationCopies){
            $destination=Resolve-SafePath $copy.Relative $payload
            [IO.File]::WriteAllText($destination,$copy.Text,$copy.Encoding)
            $manifest.Add($copy.Relative,@{
                Relative=$copy.Relative;Path=$copy.Owner.Path;Digest=(Get-FileDigest $destination)
                Owner=$copy.Owner.Key;Role='configuration';OriginalDigest=$copy.Owner.Document.Digest
            })
        }
        Invoke-WinRar @('a','-cfg-','-afzip','-r','-ep1','-ed','-inul','-y',$pendingZip,'*') $payload
        Invoke-WinRar @('t','-cfg-','-inul','-y','-p-',$pendingZip) $payload
        Test-ZipManifest $pendingZip $manifest $primaryDigest $primaryName
        Test-ArchivedConfigurations $pendingZip $allConfigurationCopies $format
        Test-ArchivedHistories $pendingZip $manifest
        # Original child files are checked against original, not sanitized, bytes.
        foreach($record in $manifest.Values){
            $expectedOriginal=$record.Digest
            if($record.Role -eq 'configuration'){$expectedOriginal=$record.OriginalDigest}
            if((Get-FileDigest $record.Path) -cne $expectedOriginal){throw "Input changed during packaging: $($record.Relative)"}
        }
        Commit-LocalBuild $target $json $pendingZip $archive
        Write-Host "Created: $archive"
        Write-Host "Updated only: $($target.Path)"
        $smbChoice=$SmbUpload;$gitChoice=$GitPublish
        if($BuildOnly){$smbChoice='No';$gitChoice='No'}
        if(Ask-YesNo 'Upload the ZIP to SMB?' $smbChoice){Send-Smb $archive}else{Write-Host 'SMB upload skipped.'}
        if(Ask-YesNo 'Commit and push the ZIP to Git?' $gitChoice){Send-Git $archive}else{Write-Host 'Git publishing skipped.'}
        Write-Host 'Completed all selected operations successfully.'
        Write-Output $archive
    } finally {
        if([IO.File]::Exists($pendingZip)){try{[IO.File]::Delete($pendingZip)}catch{Write-Warning "Temporary ZIP remains: $pendingZip"}}
        if([IO.Directory]::Exists($temporary)){
            $resolved=[IO.Path]::GetFullPath($temporary)
            $tempRoot=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')
            if([IO.Path]::GetDirectoryName($resolved).TrimEnd('\') -ieq $tempRoot -and [IO.Path]::GetFileName($resolved) -match '^ModulePackage-[a-f0-9]{32}$'){
                try{Remove-Item -LiteralPath $resolved -Recurse -Force}catch{Write-Warning "Staging directory remains: $resolved"}
            } else {Write-Warning "Refusing cleanup of an unexpected staging path: $temporary"}
        }
    }
}
# Dot-sourcing loads functions for maintenance/tests; execute normally to build.
if($MyInvocation.InvocationName -ne '.'){
    try{Invoke-Build}
    catch{[Console]::Error.WriteLine('ERROR: '+$_.Exception.Message);exit 1}
}
