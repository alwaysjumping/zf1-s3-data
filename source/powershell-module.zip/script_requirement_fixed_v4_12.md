# PowerShell Module Packaging Script — Requirements Version 4.12

## 1. Purpose and scope

Build ZIP packages for independent modules and suites of child modules using Windows PowerShell 5.1 and WinRAR. A suite can be built as one complete package or one of its children can be built independently. Preserve file paths, apply production-only source exclusions, include required SQL table files for single-module and complete-suite builds, verify archives, and optionally publish to SMB and Git.

**Controlling metadata rule:** A build updates the metadata of **only its build target**. A complete suite build updates only the suite configuration; a single-child build updates only that child's configuration. The target's original JSON is saved **only after successful ZIP creation and verification**. The `version` field is never automatically modified.

### 1.1 Workspace

The script is run from `<workspace>`; its working root is `<workspace>` (not `<workspace>\source` unless a future configuration explicitly changes the root). Source files and configuration files are resolved relative to this root. ZIPs are written to `<workspace>\output\`.

```text
<workspace>\
  build-module.ps1
  config.json
  config_framework.json
  config_dockbook.json
  applications\...
  public\...
  output\
```

These filenames are examples. Actual child configurations may have other names, such as `draft.json`. Never assume that an example file is present.

## 2. Compatibility and prerequisites

- Windows PowerShell **5.1** only; no PowerShell 7-only features.
- **WinRAR** must create ZIP-format archives (not RAR archives). Verify its executable and exit status.
- **Git** must be installed and locatable before module processing, even if publishing is later declined (retained from Version 4.4).
- Display an actionable error and exit nonzero if either prerequisite is missing.
- Do not store SMB passwords in plaintext; prompt securely at runtime.

## 3. Discover and select configuration

1. Search the workspace configuration directory for filenames matching `config*.json` (nonrecursive unless separately configured).
2. If none match, stop with a clear error.
3. If exactly one matches, select it automatically without a prompt.
4. If multiple match, display their filenames and, when valid, type, name, and version; prompt for one. Reject invalid selections and prompt again.
5. Parse the selected JSON and detect its type: `suite` section means a suite configuration; `module` section means an independent/child module configuration. Reject ambiguous configurations containing both, or neither.
6. The selected configuration is the authoritative source for that build. A selected filename need not literally be `config.json`.

A suite configuration lists its children by identifiers (e.g., `suite.count`, `suite.1`, `suite.2`, `suite.3`). Preserve the listed order; validate count, uniqueness, and nonempty child identifiers. Resolve each child identifier to exactly one child JSON configuration using a **documented mapping rule**; do not guess or silently select an unrelated JSON file. See §15 for a remaining mapping decision.

## 4. Select packaging type

### 4.1 Selected configuration is a regular module

Build that module as a single module without displaying the suite/single choice.

### 4.2 Selected configuration is a suite

Prompt:

```text
1. Suite Module
2. Single Module
```

For **Suite Module**, the build target is the suite. For **Single Module**, display all children from the suite manifest, prompt for one, resolve and validate its JSON configuration, and make that child the build target. The suite configuration is not part of a single-child package.

## 5. Metadata updates: ownership and timing

### 5.1 Fields

For the **build target only**, stage the following changes in memory or temporary files:

| Field | Behavior |
|---|---|
| `version` | **Read unchanged**. User edits it manually outside the script. No automatic increment or prompt to replace it. |
| `install_date` | Set to build timestamp in local `yyyy-MM-dd HH:mm:ss` format. |
| `build_no` | Parse existing value as a nonnegative integer and increment by one; reject missing, invalid, or overflowed values. Preserve the JSON field's intended numeric representation consistently. |
| `build_info` | Replace `@framework_version`, `@build_no`, and `@current_date` with the target's `framework_version`, new build number, and local `yyyy-MM-dd` date. Preserve other text. |
| All other fields | Preserve existing values. |

For regular modules, these fields are under `module`; for suites, they are under `suite`. Validate required metadata before proceeding. Use one captured build timestamp consistently throughout the build.

### 5.2 Strict ownership matrix

| Build target | Target JSON updated after verification | Other JSON files |
|---|---|---|
| Single `draft` | `draft.json` | Suite, `docbookcore.json`, `docdist.json` unchanged |
| Suite `docbook` | Selected suite JSON | All child JSONs unchanged |
| Standalone `email` | Selected email JSON | All other JSONs unchanged |

- A suite ZIP must include each child JSON with its **existing metadata unchanged**. Packaged child copies may normalize `source` and remove `source_exclude_extension` as required by §6.3; original child JSON files are never modified.
- Do not update child metadata or save changes to original child configurations during a suite build; create sanitized staging copies solely for ZIP packaging (§6.3).
- Do not update the suite configuration when building an individual child.
- Do not save any original JSON before ZIP creation and verification both succeed.
- If ZIP creation or verification fails, **no original configuration file changes**.
- After verification, atomically replace **only the target's original JSON** with the staged updated content. Make a temporary backup and restore on save failure; if save fails, stop and do not publish.
- Protect against concurrent edits: before saving, verify that the original target JSON has not changed since it was read. If changed, abort rather than overwriting another edit.

## 6. Source file detection and build-type exclusions

### 6.1 Authoritative `source` manifest

- **Retain `source`** as the authoritative configuration property identifying source files and directories owned by a module. Do **not** replace or deprecate it.
- For single-module configurations, require a JSON `source` array of safe, workspace-relative file or directory paths; an empty array is valid. For suite configurations, `source` is **optional**: absence means the suite declares no suite-owned ordinary source files. If a suite `source` array is added in the future, process it using the same collection rules. Reject a present `source` property with an invalid type.
- Resolve each path relative to `<workspace>`; reject absolute paths, `..` traversal, escaping paths, and missing listed paths. Expand listed directories recursively, retaining workspace-relative paths. Within a single owner, resolve overlapping file/directory entries without duplicate ZIP entries; across different owners, overlapping resolved source files are forbidden (§6.5).
- For a single-module build, collect the selected target module's `source` entries only. For a complete suite, collect source entries from the suite configuration (if present) and all listed child configurations, after enforcing unique ownership of each resolved source file (§6.5). Never include unrelated workspace files.
- Complete path validation and source collection before creating the ZIP. Source files are read-only; do not modify or delete any of them.

### 6.2 Select Development or Production build

Ask the user to choose the build type, **Development** or **Production**, for either single-module or suite packaging. The default can be Production; display the choice explicitly.

- **Development:** Include all files selected by `source` without extension exclusions.
- **Production:** Filter selected files using the corresponding configuration's `source_exclude_extension` array. Entries are extensions such as `ts` or `scss` (normalize optional leading dots; compare case-insensitively). Filter files recursively expanded from directory entries as well as explicit file entries.
- For a complete suite Production build, apply each child's own exclusion list to files contributed by that child; apply the suite's list to suite-owned files. A resolved source file must have exactly one owner across the suite and its children; if multiple owners declare the same file, stop with a fatal ownership-conflict error (§6.5). Never combine exclusion rules across owners. Explicit required SQL dependencies (§6.4) and configuration files are not ordinary source entries and cannot be excluded by this filter.
- If `source_exclude_extension` is missing or empty, no files are excluded. Reject invalid extension-list types or unsafe values.

### 6.3 Packaged configuration cleanup versus original configuration

**Original JSON:** Keep the full, unchanged `source` array and the unchanged `source_exclude_extension` array. After ZIP verification, save **only** the build target's updated `install_date`, `build_no`, and `build_info` fields (§5); do not change its `version` or source-related fields.

**Packaged JSON:** In every configuration JSON included in the ZIP, whether primary suite/module or a suite's child configuration:

1. **If and only if the original configuration contains `source`**, set its packaged `source` to the workspace-relative file paths actually included from that configuration's entries, after directory expansion and Production exclusions. Do not retain directory entries that implicitly include excluded files. Preserve deterministic original enumeration order and deduplicate paths. **If the original suite configuration has no `source`, do not invent one in its packaged JSON or INI.**
2. **Remove the `source_exclude_extension` property entirely**, in both Development and Production builds. Do not emit it as an empty array or null.
3. For the **primary build target**, use staged updated metadata (§5) and package as ZIP-root `config.json`.
4. For **suite child configurations**, preserve the original child metadata values exactly; apply only the packaging-specific `source` normalization and removal of `source_exclude_extension` to their **staged ZIP copies**. Never save these transformations to original child JSON files.
5. Keep all other configuration fields and values unchanged. The `source` list is a manifest of ordinary module source files, not a list of the separately required `tables/mysql/*.sql` dependencies.

The previous requirement to package child JSON files *byte-for-byte unchanged* is superseded **only for the packaging-only cleanup of `source` and `source_exclude_extension`**. Child metadata must still match their original configurations.

### 6.3.1 Path and file safety

- Reject unsafe source paths, symlink/reparse-point escapes, and collisions among archive entries (including `config.json` renaming). Validate cross-module source ownership before filtering (§6.5).
- Exclude output, staging, `.git`, and temporary build files unless they are explicitly valid, intended source entries; never recursively package the output directory.
- Ensure the ZIP manifest and the packaged `source` arrays agree exactly on ordinary source entries.

## 6.5 Independent source ownership and collision detection (Version 4.11)

- Every suite child and the suite itself (if it declares `source`) is a separate **source owner**. Only the owner's explicitly declared `source` files/directories may contribute ordinary source files. A single-module package includes only its selected module's ordinary source files, its generated configuration, and its required SQL dependencies.
- Expand every owner's source paths to canonical, workspace-relative **file paths** before Production filtering. Compare paths case-insensitively on Windows, normalize separators, and resolve directory/file overlap and reparse-point aliases safely. If the **same resolved file** is declared by two different owners, report both owners and the conflicting path, then **fail the entire build before ZIP creation**. This applies even when one owner would exclude that file in Production.
- Overlapping entries **within the same owner's** `source` manifest are permitted and deduplicated, but entries from different owners must not overlap on any resolved source file. A directory overlap is a conflict when it results in a shared file; directory names alone without common resolved files do not constitute a file conflict.
- After successful ownership validation, apply `source_exclude_extension` **only to the declaring owner**. Never use one module's exclusion list to remove another module's files.
- Keep each packaged configuration's `source` array limited to its own included files. Do not invent a missing `source` section. No file may appear in the ordinary source manifests of two packaged module configurations.
- **Exception for SQL dependencies:** Multiple owners may name the same table in `tables`. Include the corresponding `tables/mysql/<table>.sql` once in the suite ZIP, preserving its bytes. These shared *dependencies* are not shared ordinary source ownership. If a required SQL archive path also appears as an ordinary source path, include one byte-identical archive entry and enforce the required-SQL verification rules; reject incompatible mappings or content.
- Generated configuration files are packaging artifacts, not ordinary module source files; detect and reject archive path collisions with them separately.

## 6.4 Required SQL table files for single-module and complete-suite builds

For a **single-module build**, collect table SQL files from the selected module's `tables` array. For a **complete-suite build**, collect the union of `tables` arrays from **all child-module configurations** and also from the suite configuration **if it contains a `tables` array**. Deduplicate repeated table names and ZIP paths; never include unrelated SQL files. Suite SQL collection is required, not optional.

1. Read the applicable configuration JSON files' top-level `tables` properties according to the build type above. If every applicable `tables` property is missing or empty, skip SQL collection without error.
2. If present, `tables` must be an array of nonempty table-name strings. Reject invalid types and unsafe names; deduplicate repeated names across suite/child configurations and reject conflicting mappings. A table name is a filename stem, not a path: reject separators, `..`, absolute paths, and characters unsafe for the target filesystem. Do not accept directory traversal.
3. For each distinct table name `<table>`, require the file at exactly `<workspace>\tables\mysql\<table>.sql`. Resolve and validate its path inside the allowed workspace SQL directory. Do not substitute similarly named files or search unrelated folders.
4. Include **every** required SQL file under the same relative archive path: `tables/mysql/<table>.sql`. Preserve file bytes unchanged. Do not include SQL files for tables absent from the applicable module/suite `tables` arrays through this feature.
5. **Missing referenced SQL file is fatal**: report the missing table, owning configuration, and expected path, terminate before ZIP creation, return a nonzero exit code, and leave all original configuration and SQL files unchanged. Do not publish anything.
6. Treat explicitly listed SQL files as required dependencies: `source_exclude_extension` applies to ordinary source discovery and must not remove a required table SQL file, even if `sql` is listed as an excluded extension.
7. Detect duplicate ZIP entry paths if ordinary source discovery also selects a required SQL file; include the required file exactly once and reject conflicting content or mappings.
8. ZIP verification must confirm that each required SQL file is present at its exact path and matches the original file's bytes. No unrelated SQL file may be included *through this feature*.

Example target configuration:

```json
{
  "tables": ["draft", "draft_history", "draft_attachments"]
}
```

Required ZIP entries:

```text
tables/mysql/draft.sql
tables/mysql/draft_history.sql
tables/mysql/draft_attachments.sql
```

Example failure:

```text
ERROR: Required SQL file does not exist: tables/mysql/draft_history.sql
Module: draft
Table: draft_history
Packaging aborted; no original configuration files were modified.
```

## 7. ZIP contents and configuration filenames

### 7.1 Single module

Include exactly one primary configuration as `config.json` at ZIP root, regardless of the source filename; include only the selected module's required source files (Production: after exclusions; Development: all listed files) and its required `tables/mysql/*.sql` files listed in the selected target's `tables` array. Do not include the suite manifest or sibling configurations.

```text
module_draft(2.1.1).zip
  config.json           # staged draft.json
  applications\...      # draft-owned files only
  public\...            # draft-owned files only
  tables\mysql\draft.sql # when listed in tables
```

### 7.2 Complete suite

Include the **staged suite configuration** as `config.json` at ZIP root. Include **staged child configurations with original metadata unchanged** under their prescribed child filenames; clean up only the packaged `source` and `source_exclude_extension` fields (§6.3). Include all required suite/child source files (Production: after exclusions; Development: all listed files). **Include all required `tables/mysql/*.sql` files declared by any child and, if present, by the suite itself.** The suite's packaged primary configuration must preserve its original `menus`, `staff`, and all other ordinary sections; do not synthesize a `source` section if absent.

```text
module_docbook(2.1.1).zip
  config.json           # staged suite config
  docbookcore.json      # child metadata unchanged; packaged source manifest cleaned
  draft.json            # child metadata unchanged; packaged source manifest cleaned
  docdist.json          # child metadata unchanged; packaged source manifest cleaned
  applications\...
  public\...
  tables\mysql\...   # union of required suite/child table SQL files
```

These filenames illustrate the intended output. Resolve actual filenames from the agreed child configuration mapping. Do not rename child JSON files to `config.json` in a complete suite.

### 7.3 Archive name

Use `module_<identifier>(<version>).zip`, where the identifier is the target's `module.key` (regular/child) or suite's designated `suite.module_key` (suite); `version` is the target's unchanged manually maintained version. Validate the identifier and version for safe filenames. The examples above are illustrative.

## 8. Configuration format selection — JSON or INI (required)

After selecting the build target (suite or single module) and Development/Production build type, **always prompt** for the configuration format:

```text
Select configuration format:
1. JSON (default)
2. INI
Enter selection [1]:
```

- Pressing Enter selects JSON. Invalid input must be re-prompted.
- The selected format applies to **all packaged configurations** in the current build, including suite children; do not mix JSON and INI configurations in one ZIP.
- Original JSON configuration files remain authoritative, regardless of selected packaging format. **Never overwrite any original INI file.**
- The sole original JSON metadata update policy (§5) is unchanged and applies even when INI is selected.

### 8.1 Output filenames

| Build | JSON selected | INI selected |
|---|---|---|
| Single module | `config.json` | `config.ini` |
| Complete suite primary | `config.json` | `config.ini` |
| Complete suite children | `<child-key>.json` (e.g. `draft.json`) | `<child-key>.ini` (e.g. `draft.ini`) |

Only the selected primary configuration format may appear at the ZIP root (`config.json` **or** `config.ini`, never both). Child configuration basenames are preserved according to the validated child mapping, with the selected extension.

### 8.2 Prepare cleaned configuration before serialization

For **every** configuration included in a ZIP, first prepare an in-memory/staged JSON representation:

1. Start from the authoritative original JSON.
2. Update `install_date`, `build_no`, and `build_info` **only for the build target**; preserve `version` and all child metadata.
3. Resolve `source` into the actual included file paths; apply `source_exclude_extension` only for Production builds.
4. Replace the **packaged** `source` array with only included ordinary source files **only when `source` exists in that original configuration**; never add a missing `source` property to a suite.
5. Remove `source_exclude_extension` from the **packaged** representation for both Development and Production.
6. Serialize the resulting representation to the selected JSON or INI format. The original configuration's full `source` and exclusion lists must not be modified.

### 8.3 JSON conversion

Serialize the staged representation as valid JSON. The target becomes `config.json`; complete-suite child configurations use their corresponding `.json` filenames. Verify the packaged JSON parses and matches the expected staged values.

### 8.4 INI conversion (Zend Framework 1)

Generate each INI from its **cleaned staged JSON representation**, not from an existing INI file. For all configurations, including suite children:

- Require **every top-level configuration value to be an object or array** (including future sections); reject top-level scalar values with a clear validation error. Represent future scalar settings as members of a top-level object or array, rather than silently wrapping or changing the original JSON.
- Write `[section]` headings for top-level sections, including empty sections as applicable.
- Recursively flatten ordinary nested objects into dot-separated keys; index arrays starting at `0` and preserve their order.
- Escape and quote values so the target ZF1 INI parser reads the intended values. Reject unsupported or ambiguous types rather than silently changing values.
- For the special `[menus]` section, traverse the entire menu tree depth-first in JSON order. **Every leaf node (a node with no children or an empty `children` array) creates exactly one group**, regardless of its `menutype` value; do not filter by `menutype`. Number groups sequentially from `1`. Emit the leaf node at level `0`, its immediate parent at level `1`, grandparent at level `2`, and so on, using `<group>.<level>.<property>` keys. Do not emit the `children` property. Preserve all other menu property names and values exactly, including arbitrary `menutype` strings and capitalization. Non-leaf nodes appear only as ancestors, not as independent groups. Support multiple roots and arbitrary nesting depth.
- No `source_exclude_extension` section may appear in generated INI. If the original configuration has a `source` section, `[source]` must enumerate only the included source files; if a suite has no `source` section, **do not generate `[source]`**. For suite `menus`, no leaf node may be dropped because of its `menutype` value. The `config_dockbook.json` → `config_docbook.ini` menu hierarchy (Manager setting → Setting → Document management) is a reference test case; the JSON remains authoritative for values.
- Validate the generated INI's syntax and semantics, including the complete `menus` hierarchy, before ZIP creation; then verify the archived INI after creation.

Example complete suite in INI mode:

```text
module_docbook(2.1.1).zip
  config.ini
  docbookcore.ini
  draft.ini
  docdist.ini
  applications\...
  public\...
```

The SQL table inclusion rule for **single modules and complete suites** (§6.4) applies identically in JSON and INI modes.

## 8.5 Future configuration sections and special `menus` behavior

- **Preserve the complete original JSON object** in staging by default, including suite `staff`, `menus`, and any future top-level object/array sections. Do not rebuild suite configurations from a hardcoded allowlist of section names.
- Apply targeted transformations only to defined fields: build-target metadata; existing `source` arrays; removal of `source_exclude_extension` in packaged copies; and special `menus` conversion for INI. All other sections and values must survive packaging unchanged semantically.
- New ordinary top-level object/array sections must be copied to JSON packages and converted generically to INI using the recursive dot-key rules. Top-level scalars are invalid and must be corrected in the authoritative JSON, not silently transformed. If a future section contains types or keys that cannot be represented safely in ZF1 INI, fail clearly instead of silently discarding data. A new section requiring custom semantics needs an explicit new rule.
- The suite `menus` tree must remain intact in packaged JSON, regardless of `menutype`. For INI, create a group for each leaf node based solely on the `children` tree structure, and retain its ancestor path. For example, `config_dockbook.json` contains **Document management → Setting → Manager setting (`url`)**; its generated `[menus]` must not be empty. Preserve original menu names and other properties.
- Do not synthesize a missing `source`, `tables`, or any other configuration section. A future explicitly added `source` or `tables` must be recognized and processed according to the existing rules.
- Verify preservation by comparing parsed staged/archived configuration with the original, allowing only the documented build-target metadata and packaged-manifest transformations.

## 9. Build preparation and ZIP creation

1. Validate tools, configuration selection, child resolution, metadata, `source` manifests, exclusions, and source paths. For single-module and suite builds, validate every applicable `tables` array and all referenced SQL files before ZIP creation.
2. Capture a single timestamp and prepare an updated **temporary target JSON**. Keep all dependency/child JSONs unchanged.
3. Assemble a clean staging directory mirroring exact intended archive-relative paths. Stage the cleaned target and child configuration representations according to the chosen JSON/INI format (§8). For every packaged configuration that originally has `source`, restrict its `source` list to actual included files and omit `source_exclude_extension`; leave original JSON source fields untouched.
4. Generate the ZIP with **WinRAR** in a temporary output path; do not update an existing ZIP in place.
5. Check WinRAR exit status. A nonzero status is a failure.
6. Verify ZIP integrity and full manifest (§10).
7. Save only the target's original JSON after verification (§5).
8. Publish the verified ZIP to the final `<workspace>\output\` path only after successful metadata save, replacing any previous same-name archive safely; never mix old and new entries.
9. Offer optional SMB and Git publishing.

If the final ZIP cannot be published locally, report failure and do not start remote publishing. Remove staging artifacts on completion or failure; preserve diagnostic information only when explicitly configured.

## 10. ZIP verification before original metadata save

The verification phase must confirm:

1. ZIP is readable and WinRAR's archive test succeeds.
2. Archive contains exactly one primary configuration at root: `config.json` for JSON mode or `config.ini` for INI mode; the other must be absent.
3. Primary packaged configuration contains expected updated target metadata, including unchanged `version`, after parsing with the selected format.
4. A suite ZIP contains exactly the expected child configurations with the selected extension under the required filenames; a single-module ZIP contains none of the other modules' configurations.
5. Suite child metadata and other non-source fields match the original child JSON files semantically; only staged `source` normalization and removal of `source_exclude_extension` are permitted, plus serialization to INI when selected.
6. All selected source files are present under correct relative paths. Development includes all files from `source`; Production excludes matching extensions. Every packaged configuration **that originally has `source`** has a `source` section listing only its included ordinary source files; suite configurations originally lacking `source` still lack it. **No packaged configuration may contain `source_exclude_extension`.** For single-module and complete-suite builds, all required SQL files listed in applicable `tables` arrays are present at `tables/mysql/<table>.sql` and match their original bytes.
7. No unexpected, duplicate, unsafe, or stale archive entries are present.

Any failure prevents saving the target JSON and prevents SMB/Git publishing. Return a nonzero exit status.

## 11. Optional SMB upload (retained)

After successful local build, ask whether to upload the ZIP. Configure default SMB path and username near the top of the script; allow Enter to accept defaults. Prompt securely for password at runtime. Copy only the verified final ZIP. Validate success and clean up temporary SMB connections. If upload fails, report it and return a nonzero exit code; do not claim success.

Example defaults:

```text
SMB path: \\172.16.61.1\resource$
Username: ourman
```

## 12. Optional Git publishing (retained)

Configure the local Git repository, expected remote URL, and a repository-relative module upload directory (e.g., `modules\email`). Validate that the repository exists and is a valid Git repository; verify the configured remote URL before any repository mutation. Reject destination paths escaping the repository root. Create the destination directory if needed; copy the verified final ZIP there.

Stage **only that ZIP**, not unrelated files; ensure unrelated pre-staged changes are not accidentally included in the commit. Commit message:

```text
Added module_<identifier>(<version>).zip
```

Push to the configured remote. Check every exit status; stop and return nonzero on copy, stage, commit, or push failure. Never report a failed push as successful.

## 13. Required processing order

```text
 1. Determine workspace root.
 2. Verify WinRAR and Git prerequisites.
 3. Discover config*.json files; auto-select one or display selection menu.
 4. Parse and validate selected configuration and detect module/suite type.
 5. For a suite, prompt Suite Module or Single Module.
 6. If Single Module, choose and resolve the child JSON configuration.
 7. Identify the sole build target and any read-only dependency configurations.
 8. Prompt for Development or Production; validate module metadata, child list, `source` manifests, paths, and exclusions. For both single-module and suite builds, resolve and validate every required `tables/mysql/<table>.sql` file from the applicable configurations; abort if any is missing.
 9. Read version unchanged; prepare target-only metadata changes in staging.
10. Prompt for JSON or INI configuration format (default JSON); prepare cleaned staged configurations for that format (§8). Expand source directories and apply extension exclusions only for Production; rewrite packaged `source` lists and remove packaged `source_exclude_extension`; include all required single-module or suite SQL files at their original workspace-relative paths.
11. Convert and validate staged configurations in the selected format; create a fresh ZIP with WinRAR in temporary output.
12. Test ZIP integrity, parse packaged JSON/INI, and verify complete contents.
13. Confirm original target JSON has not changed concurrently.
14. Atomically save ONLY the target's original JSON with staged metadata.
15. Move verified ZIP to the final output directory safely.
16. Optionally upload the final ZIP to SMB.
17. Optionally copy, stage, commit, and push final ZIP to Git.
18. Report the result of each requested operation accurately.
```

## 14. Failure handling and acceptance tests

### 14.1 Failure handling

- Fail with actionable messages and a nonzero exit code on critical errors.
- No original JSON is changed on selection, validation, staging, WinRAR, or ZIP-verification failure.
- On a successful suite build, exactly one original JSON changes: the suite JSON.
- On a successful single-module build, exactly one original JSON changes: the selected module JSON.
- If saving that JSON fails, do not publish the ZIP; restore the original when possible.
- If SMB or Git publishing fails, retain the already successful local build and its target metadata, but report the publishing failure distinctly.

### 14.2 Minimum tests

| Test | Expected result |
|---|---|
| One `config*.json` | Selected automatically |
| Configuration format prompt: Enter | JSON selected |
| Configuration format prompt: 2 | INI selected for primary and all suite children |
| JSON single-module ZIP | Only root `config.json`, not `config.ini` |
| INI single-module ZIP | Only root `config.ini`, not `config.json`; special `[menus]` conversion verified |
| INI complete suite ZIP | `config.ini` and child `<child-key>.ini` files; child metadata unchanged |
| Multiple `config*.json` | Selection menu |
| Suite selected → complete suite | Suite target staged and updated; child metadata unchanged; child JSONs packaged with cleaned source manifests |
| Suite selected → `draft` only | `draft` staged as ZIP `config.json`; suite and siblings excluded and unchanged |
| Build twice without manual version edit | Version unchanged; target `build_no` increments once per successful build |
| WinRAR fails or ZIP verification fails | No original JSON changed |
| Production with `source_exclude_extension = ["ts", "scss"]` | Matching source files absent from ZIP and packaged `source`; original files untouched |
| Development with same exclusion list | All files in `source` included, including `.ts` and `.scss` |
| Either build type and either configuration format | No packaged configuration contains `source_exclude_extension`; packaged `source` lists exactly the included ordinary source files |
| Original target after successful build | Only build metadata changed; original full `source` and exclusion list preserved |
| Existing output ZIP | Replaced safely, never appended to |
| Missing child config or ambiguous ownership | Clear failure before ZIP creation |
| Single module lists three tables and all SQL files exist | Include exactly those three required files at `tables/mysql/*.sql` |
| Single module lists a missing SQL file | Fatal error before ZIP creation; original JSON and SQL files unchanged |
| Single module has missing or empty `tables` array | Skip SQL collection |
| `sql` is excluded in `source_exclude_extension` but a table SQL file is required | Required table SQL file is still included |
| Suite build with child `tables` arrays | Collect union of required child SQL files (and suite-owned `tables` if present) at `tables/mysql/*.sql` |
| Suite build missing required SQL file | Fatal error before ZIP creation; no original JSON modified |
| Suite JSON has `menus` with `menutype = "url"` | Preserve full original tree in JSON; emit the leaf menu path in INI regardless of `menutype` |
| Menu leaf uses an arbitrary `menutype` such as `custom`, `class`, or a future value | Create its INI group and preserve its `menutype` exactly; no hardcoded menu-type filter |
| Menu node has children | Do not create an independent INI group for that node; include it as an ancestor of each descendant leaf |
| Suite JSON has no `source` | No `source` property in packaged JSON and no `[source]` in packaged INI |
| Suite JSON later adds `source` | Apply ordinary source collection/filtering and package its filtered manifest |
| Suite JSON later adds arbitrary ordinary sections | Preserve all sections/values in JSON and recursively flatten them in INI |
| Git repository has unrelated changes | Only package ZIP staged/committed |

## 15. Outstanding specification decisions (do not invent implementation rules)

The following notes distinguish resolved rules from remaining choices; resolved items do not require confirmation. **Single-module and suite SQL discovery, missing-file failure behavior, and ZIP paths are fully specified in §6.4 and are not open decisions.**

1. **Child configuration discovery.** The suite lists child keys (`docbookcore`, `draft`, `docdist`), but the example archive does not establish where `docbookcore.json`, `draft.json`, and `docdist.json` live. Define a search location and exact key-to-filename mapping, including collision handling.
2. **Module source ownership is resolved:** the `source` array is authoritative. A module with no source files may use an empty `source` array. The script must not infer additional ownership beyond the declared manifests. A suite may omit `source` entirely; no section is invented.
3. **Suite-specific exclusions are resolved:** apply each configuration's own exclusions to its source entries during Production; overlapping source files across different owners are fatal before filtering; each owner’s exclusion list applies only to its own files (§6.5).
4. **JSON versus INI choice is resolved:** always prompt for JSON (default) or INI; apply the selected format to the primary and every child configuration in a suite (§8).
5. **Target metadata persistence format.** Confirm whether `build_no` must remain the same JSON type as the existing file (string versus number) and whether JSON formatting/key order must be preserved when saving. The semantic values are specified; formatting is not.

These questions do not change the confirmed rule: **only the current build target's original JSON may be updated, and only after ZIP creation and verification.**

## 16. Version 4.10 clarification — dynamic menu types

The `menutype` property is **data, not a filter**. JSON-to-INI conversion must select menu groups by **leaf-node structure only**, never by matching `menutype` against a fixed list such as `biz` or `url`. A node is a leaf if `children` is missing or is an empty array; a present non-array `children` value is invalid and must produce a clear error. Empty `menus` produces an empty `[menus]` section. For each leaf, output its own non-`children` properties at level `0`, followed by its ancestors at levels `1`, `2`, etc., in reverse path order. Preserve values and traversal order. This rule supersedes all earlier `menutype`-restricted conversion rules.

Example:

```json
{
  "menus": [{
    "name": "Document Management",
    "menutype": "class",
    "children": [
      {"name": "Open Document", "menutype": "url", "children": []},
      {"name": "Document Search", "menutype": "custom", "children": []}
    ]
  }]
}
```

```ini
[menus]
1.0.name = "Open Document"
1.0.menutype = "url"
1.1.name = "Document Management"
1.1.menutype = "class"
2.0.name = "Document Search"
2.0.menutype = "custom"
2.1.name = "Document Management"
2.1.menutype = "class"
```

## 17. Version 4.11 clarification — future INI sections and independent module files

These rules supersede any conflicting language in previous versions:

1. **Future sections:** New top-level sections are allowed without script changes when represented as JSON objects or arrays. A top-level scalar is invalid. The script must preserve new sections in JSON and recursively flatten them in INI, subject to safe Zend Framework 1 INI serialization. For example, use `"settings": {"enabled": true}` instead of `"enabled": true` at the root. Do not auto-wrap scalars or invent sections.
2. **Strict ownership:** Each module's `source` is authoritative and independent. In a complete suite, expand and validate all source declarations before applying Production exclusions. If the same file belongs to more than one owner, fail with an explicit ownership-conflict error. One owner's exclusion rules never affect another owner's files.
3. **SQL sharing exception:** Duplicate `tables` dependencies across modules are allowed; include each required SQL file once, verify it, and do not treat this as ordinary source sharing.
4. **No implementation claim:** These are updated *requirements*. Existing `Create-Module.ps1` must be separately checked and modified as necessary to comply.

### Version 4.11 acceptance tests

| Scenario | Expected result |
|---|---|
| Future top-level object `settings` with nested values | JSON preserved; valid recursive `[settings]` INI conversion |
| Future top-level array `permissions` | JSON preserved; valid indexed `[permissions]` INI conversion |
| Top-level scalar `enabled: true` | Clear validation failure; no silent conversion |
| Two child modules declare the same file | Fatal ownership conflict before ZIP creation, even if excluded in Production by one owner |
| Two children declare directories containing a common file | Fatal ownership conflict naming both owners and the file |
| One owner declares overlapping file and directory entries | Deduplicate within that owner; no duplicate archive entry |
| Two owners have disjoint source files and different exclusion lists | Apply exclusions independently; only each owner's selected files packaged |
| Two children list the same SQL table | One `tables/mysql/<table>.sql` archive entry; verify bytes |
| Suite has no `source` | Do not invent a suite `source` section |


## 18. Version 4.12 — Dynamic module history (`history.json`)

**Status:** Agreed requirements. This section extends Version 4.11 and supersedes any earlier example implying that module names or history filenames are hardcoded. These rules apply to **every** existing or future module and suite; `email`, `draft`, `docbook`, `customer`, and `production` are examples only.

### 18.1 History file purpose and structure

Each build owner (single module, suite, and each suite child) has its own **required**, developer-maintained JSON history file. A history file records the owner's releases and changes. It is **not** part of the owner's `source` manifest: the packager discovers, validates, and includes it separately, like a required configuration artifact.

Use UTF-8 JSON with this shape:

```json
{
  "module_key": "draft",
  "history": [
    {
      "version": "2.5.6",
      "date": "2026-10-13",
      "changes": [
        "Describe the actual changes in this release."
      ]
    }
  ]
}
```

The example change text is a **placeholder**, not an assertion about a real Draft release. `module_key` identifies the owning module or suite. `history` is an array ordered newest first. Each entry requires `version` (nonempty string), `date` (valid `YYYY-MM-DD` calendar date), and `changes` (nonempty array of nonempty strings). A history file may retain previous releases; the script must never invent release entries or rewrite their descriptions.

### 18.2 Generic history discovery — no hardcoded module list

Resolve the history filename using the *actual configuration filename and owner metadata*, not a fixed set of module names:

1. A configuration file literally named `config.json` maps to `history.json`.
2. A configuration file named `config_<identifier>.json` maps to `history_<identifier>.json` (retain the literal identifier, including when it differs from the module key).
3. A suite child configuration with a standalone name such as `<identifier>.json` maps to `history_<module_key>.json`, where `<module_key>` is read from that child's `module.key` field. The child key must be valid for a filename. This rule applies only to configurations resolved as suite children, not arbitrary JSON files.
4. Reject ambiguous or unsafe mappings (missing history, duplicate history ownership, invalid names, or mismatched metadata). Do not silently substitute another history file.

Examples from the sample workspace:

| Owner/configuration | Required source history |
|---|---|
| Email: `config.json` | `history.json` |
| Framework: `config_framework.json` | `history_framework.json` |
| Docbook suite: `config_dockbook.json` | `history_docbook.json` |
| Docbook Core child: `docbookcore.json` | `history_docbookcore.json` |
| Draft child: `draft.json` | `history_draft.json` |
| Document Distribution child: `docdist.json` | `history_docdist.json` |
| Future standalone: `config_customer.json` | `history_customer.json` |
| Future suite child: `production.json`, `module.key=production` | `history_production.json` |

**Note:** `config_dockbook.json` is deliberately spelled `dockbook` while its suite key may be `docbook`. The filename-derived history is therefore `history_docbook.json`; never silently normalize its spelling to `history_docbook.json`.

### 18.3 ZIP names and ownership

**Independent module build**, including a child selected via the suite's **Single Module** option:

- Include the selected owner's history at ZIP root under the canonical name **`history.json`**, regardless of its source filename.
- Include only that owner's history; do not also include `history_<identifier>.json` or any sibling/suite histories.
- Rename **inside the ZIP only**. Do not rename or modify the source history file.

**Complete suite build:**

- Include the suite's history at ZIP root as **`history.json`**.
- Include every child owner's history at ZIP root under its discovered filename, e.g. `history_draft.json`.
- Do not rename child histories to `history.json` and do not include a second copy of the suite history under its source filename.
- Reject archive-path collisions (including collisions with source-manifest files, configuration outputs, and other histories). A single history file cannot be used to satisfy two different owners.

Illustrative JSON-format suite archive:

```text
module_docbook(2.1.1).zip
  config.json
  history.json
  docbookcore.json
  history_docbookcore.json
  draft.json
  history_draft.json
  docdist.json
  history_docdist.json
  applications/...
  public/...
  tables/mysql/...
```

For an INI-format build, configuration filenames change according to §8, **but all history files remain JSON** with the same history naming rules.

### 18.4 Required validation and failure behavior

Validate the suite and each child independently **before creating the ZIP**:

1. The corresponding history file exists, is readable, and parses as a JSON object.
2. Its `module_key` exactly matches the corresponding configuration's `module.key` or `suite.key` (use the actual key property defined by that owner).
3. Its `history` is a nonempty array, with the required types and fields specified in §18.1.
4. The **first/latest** entry's `version` equals the configured owner's `version` exactly. This applies separately to the suite and every child; a child need not share the suite's version.
5. Entries are ordered newest first; reject duplicate versions and any out-of-order version entries according to the supported dotted-numeric version scheme. Do not silently reorder history.
6. Validate output archive names and ensure history files do not collide with other staged files.
7. After archive creation, verify each expected history entry exists **once**, is byte-identical to its original source, and passes the same JSON validation.

Any missing, invalid, mismatched, or colliding required history causes a **fatal build error**. Do not publish the ZIP or update the original configuration's build metadata when validation/verification fails. History contents and source filenames must remain unchanged on both success and failure. The script does **not** automatically update history when incrementing `build_no` or setting `install_date`.

**Release note correctness:** The packager can validate structure, module key, and version, but cannot prove that human-written descriptions reflect real changes. Developers must maintain accurate, module-specific descriptions; copied Email descriptions in unrelated histories must be corrected manually. Do not fabricate entries to make version validation pass.

### 18.5 Relationship to product packaging

`Package-Product.ps1` selects and copies complete module ZIPs unchanged. It does **not** rename, extract, rewrite, or separately regenerate their embedded history files. The product ZIP therefore retains each module package's own `history.json` content.

### 18.6 Version 4.12 acceptance tests

| Scenario | Expected result |
|---|---|
| Build `config.json` (Email) | Source `history.json` included once at ZIP root |
| Build `config_framework.json` | `history_framework.json` included as `history.json` inside ZIP; source unchanged |
| Build child `draft.json` independently | `history_draft.json` included as `history.json`; no suite/sibling histories |
| Build complete suite from `config_dockbook.json` | Suite `history_docbook.json` becomes `history.json`; child histories retain discovered names |
| Build future `config_customer.json` | Automatically discovers `history_customer.json`; no code change |
| Build future child `production.json` | Uses child's `module.key` to discover `history_production.json` |
| History `module_key` differs from config key | Fatal validation failure |
| First history version differs from owner version | Fatal validation failure; no metadata save |
| Missing history or invalid JSON | Fatal validation failure |
| Two histories map to same ZIP path | Fatal archive collision failure |
| Development vs Production | Same required history inclusion; `source_exclude_extension` cannot remove history |
| JSON vs INI configuration build | History files remain JSON |
| ZIP verification fails | No original configuration/history modified; no publish |
| Successful build | Original history bytes unchanged; only selected target's permitted metadata updated |

### 18.7 Sample history files reviewed (not automatically repaired)

The uploaded `zf1-s3-module(2).zip` contains six correctly named, parseable history files with matching `module_key` values. Their first history versions were all `2.5.0` while the corresponding sample configuration versions differed. The descriptions also reused Email-oriented text across unrelated modules. These are **sample-data corrections required before strict Version 4.12 validation**, not reasons to hardcode special cases into the script.

---

**Revision history**

- **v4.12:** Added required, dynamically discovered per-owner `history.json` packaging; independent/suite naming rules; JSON schema and version checks; immutable source histories; verification and acceptance tests. All Version 4.11 rules remain in force unless explicitly superseded above.
