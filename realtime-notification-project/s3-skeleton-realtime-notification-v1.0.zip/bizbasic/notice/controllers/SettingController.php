<?php
class Notice_SettingController extends User_Controller_Action
{
    public function indexAction()
    {
    }

    public function saveAction()
    {
        exit("Saved! <a href='/notice/setting/'>Setting...</a>");
    }

    public function initAction()
    {
    }
}
