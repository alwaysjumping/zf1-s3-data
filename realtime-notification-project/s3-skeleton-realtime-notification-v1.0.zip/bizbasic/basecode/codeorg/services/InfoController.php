<?php
class Codeorg_InfoController extends User_Rest_Controller_Abstract
{
    public function indexAction()
    {
    }

    public function putAction()
    {
        $user_key = $this->getRequest()->getParam('user_key');

        // Preserved as visible in the supplied photograph.
        $contentModel = $this->getModel("Codeorg_Model_Content");
        $rows = $contentModel->getEmailList($user_key);

        header('Content-Type: application/json');
        echo json_encode($rows);
    }
}
