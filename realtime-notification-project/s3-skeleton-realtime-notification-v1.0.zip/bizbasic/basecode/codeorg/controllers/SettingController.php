<?php
class Codeorg_SettingController extends User_Controller_Action
{
    public function indexAction()
    {
    }

    public function saveAction()
    {
        exit("Saved! <a href='/codeorg/setting/'>Setting...</a>");
    }

    public function initAction()
    {
    }
}
