<?php
class Codeorg_Model_Content extends User_Db_Table
{
    protected $_name = "codeorg_content";
    protected $_primary = "id";

    public function getEmailList($user_key = 0)
    {
        $adapter = $this->getAdapter();
        $select = $adapter->select()
            ->from(array($this->_name), array('*'))
            ->where('user_key = ?', $user_key);
        return $adapter->fetchAll($select);
    }
}
