<?php
class Draft_SettingController extends User_Controller_Action
{
    public function indexAction()
    {
    }

    public function saveAction()
    {
        exit("Saved! <a href='/draft/setting/'>Setting...</a>");
    }

    public function initAction()
    {
    }
}
