<?php
class Draft_Model_Content extends User_Db_Table
{
    protected $_name = "draft_content";
    protected $_primary = "id";

    public function getEmailList(int $user_key = 0): array
    {
        $adapter = $this->getAdapter();
        $select = $adapter->select()
            ->from(array($this->_name), array('*'))
            ->where('user_key = ?', $user_key);
        return $adapter->fetchAll($select);
    }
}
