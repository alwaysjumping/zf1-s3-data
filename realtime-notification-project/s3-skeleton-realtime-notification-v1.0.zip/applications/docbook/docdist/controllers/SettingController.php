<?php
class Docdist_SettingController extends User_Controller_Action
{
    public function indexAction()
    {
    }

    public function saveAction()
    {
        exit("Saved! <a href='/docdist/setting/'>Setting...</a>");
    }

    public function initAction()
    {
    }
}
