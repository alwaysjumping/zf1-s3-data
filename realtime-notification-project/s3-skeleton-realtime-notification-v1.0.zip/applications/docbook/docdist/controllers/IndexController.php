<?php
class Docdist_IndexController extends User_Controller_Action
{
    public function indexAction()
    {
    }

    public function inboxAction()
    {
        $email_rows = array();

        $identify = Zend_Auth::getInstance()->getIdentity();
        if (!empty($identify->user_key)) {
            $contentModel = $this->getModel("Docdist_Model_Content");
            $email_rows = $contentModel->getEmailList($identify->user_key);
        }

        $this->view->email_rows = $email_rows;
    }
}
