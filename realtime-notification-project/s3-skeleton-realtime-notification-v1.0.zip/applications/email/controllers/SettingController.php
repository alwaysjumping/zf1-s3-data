<?php
class Email_SettingController extends User_Controller_Action
{
    public function indexAction()
    {
    }

    public function saveAction()
    {
        exit("Saved! <a href='/email/setting/'>Setting...</a>");
    }

    public function initAction()
    {
    }
}
