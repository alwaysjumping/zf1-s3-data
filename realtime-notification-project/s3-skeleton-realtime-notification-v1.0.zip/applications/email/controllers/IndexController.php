<?php
class Email_IndexController extends User_Controller_Action
{
    public function indexAction()
    {
        $config = array(
            'secret' => 'temporary-test-secret',
            'algorithm' => 'HS256',
            'issuer' => 's3',
            'audience' => 's3-api',
            'accessTokenLifetime' => 900,
        );

        $jwtService = new User_Jwt_JwtService(
            $config
        );

        $token = $jwtService->createAccessToken(
            1001,
            array(
                'role' => 'manager'
            )
        );

        echo $token;

        $claims = $jwtService->verifyAccessToken(
            $token
        );

        print_r($claims);
    }

    public function inboxAction()
    {
        $email_rows = array();

        $identify = Zend_Auth::getInstance()->getIdentity();
        if (!empty($identify->user_key)) {
            $contentModel = $this->getModel("Email_Model_Content");
            $email_rows = $contentModel->getEmailList($identify->user_key);
        }

        $this->view->email_rows = $email_rows;
    }
}
