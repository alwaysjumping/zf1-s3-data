<?php
class Email_Model_Setting extends User_Db_Table
{
    protected $_name = "email_setting";
    protected $_primary = "setting_key";

    public function getEmailSetting($setting_key = '')
    {
        $adapter = $this->getAdapter();
        $select = $adapter->select()
            ->from(array($this->_name), array('setting_value'))
            ->where('setting_key = ?', $setting_key);
        return $adapter->fetchOne($select);
    }
}
