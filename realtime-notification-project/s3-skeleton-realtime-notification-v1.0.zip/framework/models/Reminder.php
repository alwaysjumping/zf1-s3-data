<?php
class Model_Reminder extends User_Db_Table
{
    protected $_name = 'reminders';
    protected $_primary = 'id';
}
