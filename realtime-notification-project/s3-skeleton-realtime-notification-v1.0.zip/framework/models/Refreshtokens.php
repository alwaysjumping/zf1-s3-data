<?php

class Model_Refreshtokens extends User_Db_Table
{
    protected $_name = "frm_refresh_tokens";
    protected $_primary = "id";

}