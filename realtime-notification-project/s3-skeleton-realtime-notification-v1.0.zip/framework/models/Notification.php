<?php
class Model_Notification extends User_Db_Table
{
    protected $_name = 'notifications';
    protected $_primary = 'id';
}
