<?php
class Model_NotificationOutbox extends User_Db_Table
{
    protected $_name = 'notification_outbox';
    protected $_primary = 'id';
}
