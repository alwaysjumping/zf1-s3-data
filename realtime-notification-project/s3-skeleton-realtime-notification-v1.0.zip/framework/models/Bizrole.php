<?php

class Model_Bizrole extends User_Db_Table
{
    protected $_name = "frm_bizroles";
    protected $_primary = "id";
}