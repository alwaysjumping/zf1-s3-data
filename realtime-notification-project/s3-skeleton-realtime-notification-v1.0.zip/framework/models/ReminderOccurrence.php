<?php
class Model_ReminderOccurrence extends User_Db_Table
{
    protected $_name = 'reminder_occurrences';
    protected $_primary = 'id';
}
