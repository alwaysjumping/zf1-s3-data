<?php
class Model_NotificationEvent extends User_Db_Table
{
    protected $_name = 'notification_events';
    protected $_primary = 'event_id';
}
