<?php

class Model_User extends User_Db_Table
{
    protected $_name = "frm_users";
    protected $_primary = "user_key";

    public function init()
    {
    }

    public function getLoginInfo($uid, $upw)
    {
        $userRow = $this->fetchRow(
            $this->select()
                ->from($this, '*')
                ->where("login_id = ?", $uid)
        );

        if (empty($userRow))
            return "NOT_REGIST";

        $user_info = $userRow->toArray();

        if ($user_info["alw"] == '0')
            return "NOT_ALLOW";

        if ($user_info["alw"] == '2')
            return "NOT_RESTORE";

        $encoded_pwd = hash('sha512', $upw);

        if ($upw !== true && $user_info["pwd"] != $encoded_pwd) {
            return "NOT_PWD";
        }

        $user_info["logintime"] = date("Y-m-d H:i:s");

        $userRow->last_vdate = date('Y-m-d H:i:s');
        $userRow->save();

        return $user_info;
    }

    public function getUsers($tObj = null)
    {
        $dObj = is_object($tObj) ? clone($tObj) : new stdClass();

        $select = $this->select()
            ->from($this)
            ->order('order_num, login_id');

        if (isset($dObj->alw))
            $select = $select->where('alw = ?', $dObj->alw);

        $users = $this->fetchAll($select)->toArray();

        return $users;
    }

    public function getUsersInfo($userKey = null)
    {
        $db = $this->getAdapter();

        $select = $db->select()
            ->from($this->_name, '*')
            ->where("alw=1")
            ->order('order_num, login_id');

        if (!is_null($userKey)) {
            if (is_array($userKey)) {
                $select->where("user_key IN (?)", $userKey);
            } else {
                $select->where("user_key = ?", $userKey);

                $result = $db->fetchRow($select);

                if (!$result)
                    $result = null;

                return $result;
            }
        }

        $users = $db->fetchAll($select);

        return $users;
    }
}