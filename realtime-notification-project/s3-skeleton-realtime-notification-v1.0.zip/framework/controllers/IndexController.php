<?php

Zend_Loader::loadClass('Datasocket_Factory');

class IndexController extends User_Controller_Action
{
    public function init()
    {
        $request = $this->getRequest();

        $this->view->controllerName =
            $request->getControllerName();

        $this->view->actionName =
            $request->getActionName();

        $this->view->moduleName =
            $request->getModuleName();
    }

    public function indexAction()
    {
        $identify = Zend_Auth::getInstance()->getIdentity();

        if (empty($identify->user_key)) {
            $userModel = $this->getModel("Model_User");
            $user_rows = $userModel->getUsers();

            $this->view->user_rows = $user_rows;
            $this->setLayout(__FILE__);
        } else {
            header('Location: /default/index/welcome');
        }
    }

    public function welcomeAction()
    {
        $identify = Zend_Auth::getInstance()->getIdentity();

        if (empty($identify->user_key)) {
            header('Location: /');
            exit;
        }

        $userModel = $this->getModel("Model_User");
        $user_row =
            $userModel->getUsersInfo($identify->user_key);

        $this->view->user_row = $user_row;
        $this->view->user_name = $identify->user_name;
    }

    public function loginAction()
    {
        $login_id = $this->getParam('login_id');
        $login_pwd = $this->getParam('login_pwd');

        $userModel = $this->getModel("Model_User");

        $user_info =
            $userModel->getLoginInfo($login_id, $login_pwd);

        if (isset($user_info['user_key'])) {
            $identity = new stdClass();

            $identity->user_key = $user_info['user_key'];
            $identity->login_id = $user_info['login_id'];
            $identity->user_name = $user_info['name'];
            $identity->job = $user_info['job'];

            $auth = Zend_Auth::getInstance();
            $auth->clearIdentity();

            $storage = $auth->getStorage();
            $storage->write($identity);

            header('Location: /default/index/welcome');
            exit;
        } else {
            $this->view->login_result = $user_info;
            $this->setLayout(__FILE__, 'index');
        }
    }

    public function logoutAction()
    {
        $auth = Zend_Auth::getInstance();

        $auth->clearIdentity();

        header('Location: /');
        exit;
    }
}