<?php
class RemindersController extends User_Controller_Api
{
 protected $svc; public function init(){parent::init();$this->svc=new User_Reminder_Service();}
 public function indexAction(){ $u=$this->userId();if(!$u)return;if($this->getRequest()->isGet()){$this->json(200,array('reminders'=>$this->svc->listForUser($u)));return;}if($this->getRequest()->isPost()){$d=$this->body();if(empty($d['title'])||empty($d['message'])||empty($d['remind_at'])){$this->json(400,array('error'=>'invalid_request'));return;}$this->json(201,array('id'=>$this->svc->create($u,$d)));return;}$this->json(405,array('error'=>'method_not_allowed'));}
 public function dismissAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$this->json(200,array('ok'=>$this->svc->dismiss($u,(int)$this->_getParam('occurrence_id'))));}
 public function completeAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$this->json(200,array('ok'=>$this->svc->complete($u,(int)$this->_getParam('occurrence_id'))));}
 public function snoozeAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$d=$this->body();$this->json(200,array('ok'=>$this->svc->snooze($u,(int)$this->_getParam('occurrence_id'),$d['snoozed_until'])));}
 public function cancelAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$this->json(200,array('ok'=>(bool)$this->svc->cancel($u,(int)$this->_getParam('id'))));}
}
