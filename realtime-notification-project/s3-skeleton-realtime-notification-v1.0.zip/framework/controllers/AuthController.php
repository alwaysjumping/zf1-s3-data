<?php
class AuthController extends User_Controller_Action
{
    public function init()
    {
        $this->_helper
            ->viewRenderer
            ->setNoRender(true);
    }

    public function loginAction()
    {
        $this->getResponse()
            ->setHeader(
                'Content-Type',
                'application/json'
            );

        if (!$this->getRequest()->isPost()) {
            return $this->jsonError(
                405,
                'method_not_allowed',
                'POST request required.'
            );
        }

        $data = $this->getJsonBody();

        if (
            empty($data['username'])
            || empty($data['password'])
        ) {
            return $this->jsonError(
                400,
                'invalid_request',
                'Username and password are required.'
            );
        }

        $username = trim(
            $data['username']
        );

        $password =
            $data['password'];

        /*
         * Replace this with your existing
         * authentication code.
         */
        $user = $this->authenticateUser(
            $username,
            $password
        );

        if (!$user) {
            return $this->jsonError(
                401,
                'invalid_credentials',
                'Invalid username or password.'
            );
        }

        /*
         * Optional but strongly recommended:
         *
         * Check:
         * - disabled account
         * - locked account
         * - expired account
         * - deleted account
         */

        $jwtService =
            Zend_Registry::get(
                'jwtService'
            );

        $refreshService =
            Zend_Registry::get(
                'refreshTokenService'
            );

        $accessToken =
            $jwtService->createAccessToken(
                $user['id']
            );

        $refresh =
            $refreshService->create(
                $user['id'],
                $this->getClientIp(),
                $this->getUserAgent()
            );

        return $this->jsonResponse(
            200,
            array(
                'access_token' =>
                    $accessToken,

                'refresh_token' =>
                    $refresh['token'],

                'token_type' =>
                    'Bearer',

                'expires_in' =>
                    900
            )
        );
    }

    protected function getJsonBody()
    {
        $body = $this->getRequest()
            ->getRawBody();

        if ($body === '') {
            return array();
        }

        $data = json_decode(
            $body,
            true
        );

        if (!is_array($data)) {
            return array();
        }

        return $data;
    }

    protected function jsonResponse(
        $statusCode,
        array $data
    ) {
        $response =
            $this->getResponse();

        $response->setHttpResponseCode(
            $statusCode
        );

        $response->setHeader(
            'Content-Type',
            'application/json',
            true
        );

        $response->setBody(
            json_encode($data)
        );

        return;
    }

    protected function jsonError(
        $statusCode,
        $error,
        $message
    ) {
        return $this->jsonResponse(
            $statusCode,
            array(
                'error' => $error,
                'message' => $message
            )
        );
    }

    protected function authenticateUser(
        $username,
        $password
    ) {
        $users = $this->getModel("Model_User");
        $select = $users
            ->select()
            ->where(
                'login_id = ?',
                $username
            )
            ->limit(1);

        $user = $users->fetchRow(
            $select
        );

        if (!$user) {
            return false;
        }

        if (hash('sha512', $password) != $user->pwd) {
            return false;
        }

        return array(
            'id' => $user->user_key,
            'username' => $user->login_id
        );
    }

    protected function getClientIp()
    {
        return $this->getRequest()
            ->getClientIp();
    }

    protected function getUserAgent()
    {
        $userAgent =
            $this->getRequest()
                ->getHeader(
                    'User-Agent'
                );

        if (!$userAgent) {
            return null;
        }

        return substr(
            $userAgent,
            0,
            255
        );
    }

    public function refreshAction()
    {
        $this->getResponse()
            ->setHeader(
                'Content-Type',
                'application/json',
                true
            );

        if (!$this->getRequest()->isPost()) {
            return $this->jsonError(
                405,
                'method_not_allowed',
                'POST request required.'
            );
        }

        $data = $this->getJsonBody();

        if (empty($data['refresh_token'])) {
            return $this->jsonError(
                400,
                'invalid_request',
                'Refresh token is required.'
            );
        }

        $refreshService =
            Zend_Registry::get(
                'refreshTokenService'
            );

        $result =
            $refreshService->rotate(
                $data['refresh_token'],
                $this->getClientIp(),
                $this->getUserAgent()
            );

        if (!$result) {
            return $this->jsonError(
                401,
                'invalid_refresh_token',
                'Refresh token is invalid or expired.'
            );
        }

        $jwtService =
            Zend_Registry::get(
                'jwtService'
            );

        $accessToken =
            $jwtService->createAccessToken(
                $result['user_id']
            );

        return $this->jsonResponse(
            200,
            array(
                'access_token' =>
                    $accessToken,

                'refresh_token' =>
                    $result['refresh_token'],

                'token_type' =>
                    'Bearer',

                'expires_in' =>
                    900
            )
        );
    }
}