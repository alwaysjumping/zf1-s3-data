<?php
class NotificationsController extends User_Controller_Api
{
 protected $svc; public function init(){parent::init();$this->svc=new User_Notification_Service();}
 public function indexAction(){if(!$this->requireMethod('GET'))return;$u=$this->userId();if(!$u)return;$this->json(200,array('notifications'=>$this->svc->getNotifications($u,(int)$this->_getParam('limit',50),$this->_getParam('before_id',null)),'unread_count'=>$this->svc->getUnreadCount($u)));}
 public function getAction(){if(!$this->requireMethod('GET'))return;$u=$this->userId();if(!$u)return;$r=$this->svc->get($u,(int)$this->_getParam('id'));$r?$this->json(200,$r):$this->json(404,array('error'=>'not_found'));}
 public function unreadCountAction(){if(!$this->requireMethod('GET'))return;$u=$this->userId();if(!$u)return;$this->json(200,array('unread_count'=>$this->svc->getUnreadCount($u)));}
 public function readAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$r=$this->svc->markRead($u,(int)$this->_getParam('id'));$r===false?$this->json(404,array('error'=>'not_found')):$this->json(200,array('ok'=>true,'event'=>$r));}
 public function readAllAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$this->json(200,array('ok'=>true,'event'=>$this->svc->markAllRead($u)));}
}
