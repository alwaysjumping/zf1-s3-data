<?php
class RealtimeController extends User_Controller_Api
{
 public function configAction(){if(!$this->requireMethod('GET'))return;$u=$this->userId();if(!$u)return;$c=Zend_Registry::get('config');$r=$c->realtime;$this->json(200,array('enabled'=>(bool)$r->enabled,'method'=>(string)$r->method,'transport'=>(string)$r->transport,'websocket_url'=>(string)$r->websocketUrl,'polling_interval'=>(int)$r->pollingInterval,'reconciliation_interval'=>(int)$r->reconciliationInterval,'polling_fallback_enabled'=>(bool)$r->pollingFallbackEnabled));}
 public function tokenAction(){if(!$this->requireMethod('POST'))return;$u=$this->userId();if(!$u)return;$jwt=Zend_Registry::get('jwtService');$token=$jwt->createAccessToken($u,array('purpose'=>'realtime','jti'=>bin2hex(random_bytes(16))));$this->json(200,array('token'=>$token,'expires_in'=>120));}
}
