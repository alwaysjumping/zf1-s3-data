<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initAutoload()
    {
        $this->bootstrap('frontController');

        $config = new Zend_Config_Ini(CONFIG_PATH . '/application.ini');
        $config = $config->toArray();
        $suite_keyinfos = $config[APPLICATION_ENV]['resources']['frontController']['suite'];

        if (!empty($suite_keyinfos)) {
            foreach ($suite_keyinfos as $key => $suite_keyinfo) {
                $suite_keys = explode(',', $suite_keyinfo);

                foreach ($suite_keys as $suite_key) {
                    if ($suite_key != "") {
                        $dirmodule = ROOT_PATH . '/' . $key . '/' . $suite_key;

                        if (is_dir($dirmodule))
                            $this->frontController->addModuleDirectory($dirmodule);
                    }
                }
            }
        }
    }

    protected function _initJwt()
    {
        $options = $this->getOptions();

        if (!isset($options['jwt'])) {
            throw new RuntimeException(
                'JWT configuration is missing.'
            );
        }

        $secret = getenv('S3_JWT_SECRET');

        if ($secret === false || $secret === '') {
            throw new RuntimeException(
                'S3_JWT_SECRET is not configured.'
            );
        }

        $config = $options['jwt'];

        $config['secret'] = $secret;

        $jwtService = new User_Jwt_JwtService($config);

        Zend_Registry::set(
            'jwtService',
            $jwtService
        );

        return $jwtService;
    }

    protected function _initRefreshToken()
    {
        $service =
            new User_RefreshTokenService();

        Zend_Registry::set(
            'refreshTokenService',
            $service
        );

        return $service;
    }
}