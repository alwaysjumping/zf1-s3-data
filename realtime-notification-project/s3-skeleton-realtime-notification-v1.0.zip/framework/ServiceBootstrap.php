<?php

class ServiceBootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initAutoload()
    {
        Zend_Registry::set(
            'config',
            new Zend_Config($this->getApplication()->getOptions())
        );

        $this->bootstrap('frontController');
        $front = $this->getResource('frontController');

        $config_file_path = CONFIG_PATH . '/application.ini';
        $env = APPLICATION_ENV;

        $config = new Zend_Config_Ini($config_file_path);
        $config = $config->toArray();

        $suite_keyinfos =
            $config[$env]['resources']['frontController']['suite'];

        if (!is_null($suite_keyinfos)) {
            foreach ($suite_keyinfos as $key => $suite_keyinfo) {
                $suite_keys = explode(',', $suite_keyinfo);

                foreach ($suite_keys as $suite_key) {
                    if ($suite_key != "") {
                        $dirmodule =
                            ROOT_PATH . '/' . $key . '/' . $suite_key;

                        $this->frontController
                            ->addModuleDirectory($dirmodule);
                    }
                }
            }
        }

        $router = $front->getRouter();
        $router->addRoute(
            'rest',
            new User_Rest_Route($front)
        );
    }
}