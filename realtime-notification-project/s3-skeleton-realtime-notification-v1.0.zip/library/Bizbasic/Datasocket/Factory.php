<?php

abstract class Datasocket_Factory {

    public function __construct($params)
    {
        $this->_params = new stdClass();
    }

}