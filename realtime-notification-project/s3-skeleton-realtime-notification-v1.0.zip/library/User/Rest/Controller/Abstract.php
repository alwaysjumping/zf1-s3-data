<?php

abstract class User_Rest_Controller_Abstract extends Zend_Rest_Controller
{
    /**
     * @var User_Db_Adapter_Interface
     */
    protected $_db = NULL;

    /**
     * Initializes the REST Resource Controller
     *
     * @see Zend_Controller_Action::init()
     */
    public function init()
    {
        parent::init();

        // Disable layout
        if (Zend_Controller_Action_HelperBroker::hasHelper('layout')) {
            $this->_helper->layout->disableLayout();
        }

        // Disable view
        $this->_helper->viewRenderer->setNoRender(TRUE);

        $bootstrap = $this->getInvokeArg('bootstrap');

        if ($bootstrap->hasResource('db')) {
            $this->_db = $bootstrap->getResource('db');
        }
    }

    /**
     * Retrieves a model by its name
     *
     * @param string $model
     * @param array $params OPTIONAL
     * @return User_Db_Table
     */
    protected function getModel($name, $params = array())
    {
        return User_Db_Table::factory($name, $params);
    }

    public function indexAction()
    {
        $this->_response->setHttpResponseCode(405);
    }

    public function headAction()
    {
       // $this->_response->setHttpResponseCode(405);
    }

    public function getAction()
    {
        $this->_response->setHttpResponseCode(405);
    }

    public function postAction()
    {
        $this->_response->setHttpResponseCode(405);
    }

    public function putAction()
    {
        $this->_response->setHttpResponseCode(405);
    }

    public function deleteAction()
    {
        $this->_response->setHttpResponseCode(405);
    }
}