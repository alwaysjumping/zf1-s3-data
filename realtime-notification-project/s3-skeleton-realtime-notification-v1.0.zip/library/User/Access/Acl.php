<?php

/**
 * Permission class
 */
class User_Access_Acl extends Zend_Controller_Plugin_Abstract
{
    protected $_cacheObj = null;
    protected $_userKey = null;
    protected $_module = null;
    protected $_controller = null;
    protected $_action = null;

    public function preDispatch(Zend_Controller_Request_Abstract $request)
    {
        if ($this->_cacheObj == null) {
            $this->_cacheObj = Zend_Controller_Front::getInstance()
                ->getParam('bootstrap')
                ->getResource('cachemanager')
                ->getCache('acl');
        }

        $this->_initParams($request);

        $check_result = $this->checkAccess();

        if ($check_result) {
            return true;
        } else {
            exit("Sorry! You don't have the permission for this page access. <a href='/'>Home...</a>");
        }
    }

    protected function _initParams($request)
    {
        if (Zend_Auth::getInstance()->hasIdentity()) {
            $this->_userKey = Zend_Auth::getInstance()->getIdentity()->user_key;
        }

        $this->_module = $request->module;

        if (empty($this->_module))
            $this->_module = 'default';

        $this->_controller = $request->controller;
        $this->_action = $request->action;
    }

    private function checkAccess()
    {
        if (empty($this->_userKey))
            return true;

        $bizroleModel = User_Db_Table::factory('Model_Bizrole');
        $adapter = $bizroleModel->getAdapter();

        $biz_key = $this->_module . '_' . $this->_controller;
        $role_name = 'user_' . $this->_userKey;

        $cacheObj_name = sprintf('Acl_%s_%d', $this->_module, $this->_userKey);

        if (($acl = $this->_cacheObj->load($cacheObj_name)) === false) {
            $acl = new Zend_Acl();

            // Get biz list of a module
            $select = $adapter->select()
                ->from('frm_actions', '*')
                ->where('biz_key LIKE ?', $this->_module . '_%')
                ->group('biz_key');
            $biz_rows = $adapter->fetchAll($select);

            foreach ($biz_rows as $biz_row) {
                $acl->addResource(new Zend_Acl_Resource($biz_row['biz_key']));
            }

            $acl->addRole(new Zend_Acl_Role('user_' . $this->_userKey));

            // Get user privileges of module
            $select = $adapter->select()
                ->from(
                    array('br' => 'frm_bizroles'),
                    array('br.biz_key', 'power' => 'GROUP_CONCAT(br.power)')
                )
                ->joinInner(
                    array('ubr' => 'frm_user_bizroles'),
                    "ubr.bizrole_id = br.id AND ubr.user_key = " . $this->_userKey,
                    ''
                )
                ->where('biz_key LIKE ?', $this->_module . '_%')
                ->group('biz_key');

            $bizrole_rows = $adapter->fetchAll($select);

            foreach ($bizrole_rows as $bizrole_row) {
                $arr_power = explode(',', $bizrole_row['power']);
                $biz_powers = array();

                foreach ($arr_power as $power) {
                    if (!in_array($power, $biz_powers)) {
                        $biz_powers[] = $power;
                    }
                }

                // allow
                $acl->allow($role_name, $bizrole_row['biz_key'], $biz_powers);
            }

            $this->_cacheObj->save($acl, $cacheObj_name);
        }

        // Get power by biz and action
        $select = $adapter->select()
            ->from('frm_actions', 'power')
            ->where('biz_key = ?', $biz_key)
            ->where('action = ?', $this->_action);

        $action_power = $adapter->fetchOne($select);

        if (empty($action_power))
            return true;

        if ($acl->isAllowed($role_name, $biz_key, $action_power)) {
            return true;
        } else {
            return false;
        }
    }
}