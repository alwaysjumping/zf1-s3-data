<?php

class User_Controller_Action extends Zend_Controller_Action
{
    public function init()
    {
        $request = $this->getRequest();

        $this->view->controllerName = $request->getControllerName();
        $this->view->actionName = $request->getActionName();
        $this->view->moduleName = $request->getModuleName();

        $identify = Zend_Auth::getInstance()->getIdentity();

        if (empty($identify->user_key)) {
            header('Location: /');
        }
    }

    /**
     * Get instance of model class specified by name.
     *
     * @param type $className
     * @return User_Db_Table
     */
    public function getModel($className, $params=array())
    {
        return User_Db_Table::factory($className, $params);
    }

    public function setLayout($controller_path, $view = 'index')
    {
        $module_path = realpath(dirname($controller_path) . '/../');

        $options = array(
            'layoutPath' => $module_path . "/views/scripts/index",
            'layout' => $view,
        );

        Zend_Layout::startMvc($options);
    }

    /**
     * XSS filter
     */
    public function xss_clean($data)
    {
        // do xss clean ...
        return $data;
    }

    public function getParam($key, $default = '')
    {
        $data = $this->getRequest()->getParam($key, $default);

        // XSS clean
        $data = $this->xss_clean($data);

        return $data;
    }
}