<?php
class User_Controller_Api extends Zend_Controller_Action
{
 public function init(){ $this->_helper->viewRenderer->setNoRender(true); }
 protected function json($code,array $data){$this->getResponse()->setHttpResponseCode($code)->setHeader('Content-Type','application/json',true)->setBody(json_encode($data));}
 protected function body(){ $d=json_decode($this->getRequest()->getRawBody(),true); return is_array($d)?$d:array(); }
 protected function userId(){
   $auth=Zend_Auth::getInstance(); if($auth->hasIdentity()){ $i=$auth->getIdentity(); if(is_object($i)&&isset($i->user_key))return (int)$i->user_key; if(is_array($i)&&isset($i['user_key']))return (int)$i['user_key']; }
   $h=$this->getRequest()->getHeader('Authorization'); if($h && preg_match('/^Bearer\s+(.+)$/i',$h,$m) && Zend_Registry::isRegistered('jwtService')){try{$c=Zend_Registry::get('jwtService')->verifyAccessToken($m[1]);return (int)$c['sub'];}catch(Exception $e){}}
   $this->json(401,array('error'=>'unauthorized')); return null;
 }
 protected function requireMethod($method){if(strtoupper($this->getRequest()->getMethod())!==strtoupper($method)){$this->json(405,array('error'=>'method_not_allowed'));return false;}return true;}
}
