<?php
class User_Notification_Dispatcher
{
 protected $db,$client; public function __construct(Zend_Db_Adapter_Abstract $db,User_Notification_InternalSignalClient $client){$this->db=$db;$this->client=$client;}
 public function runOnce($limit=50){$rows=$this->db->fetchAll("SELECT o.id,o.event_id,e.user_id,e.notification_id,e.event_type FROM notification_outbox o JOIN notification_events e ON e.event_id=o.event_id WHERE o.status='pending' AND o.available_at<=UTC_TIMESTAMP() ORDER BY o.id ASC LIMIT ".(int)$limit);foreach($rows as $r)$this->dispatch($r);return count($rows);}
 protected function dispatch(array $r){try{$this->client->send(array('user_id'=>(int)$r['user_id'],'event_id'=>(int)$r['event_id'],'event'=>$r['event_type'],'notification_id'=>$r['notification_id']===null?null:(int)$r['notification_id']));$this->db->update('notification_outbox',array('status'=>'processed','processed_at'=>gmdate('Y-m-d H:i:s'),'last_error'=>null),array('id = ?'=>(int)$r['id']));}catch(Exception $e){$attempt=(int)$this->db->fetchOne('SELECT attempts FROM notification_outbox WHERE id=?',(int)$r['id'])+1;$delay=$this->delay($attempt);$status=$attempt>=10?'failed':'pending';$available=gmdate('Y-m-d H:i:s',time()+$delay);$this->db->update('notification_outbox',array('status'=>$status,'attempts'=>$attempt,'available_at'=>$available,'last_error'=>substr($e->getMessage(),0,4000)),array('id = ?'=>(int)$r['id']));}}
 protected function delay($a){$d=array(5,15,30,60,300);return $d[min(max($a-1,0),count($d)-1)];}
}
