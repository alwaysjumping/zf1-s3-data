<?php
class User_Notification_InternalSignalClient
{
 protected $url,$secret,$timeout; public function __construct($url,$secret,$timeout=3){$this->url=$url;$this->secret=$secret;$this->timeout=$timeout;}
 public function send(array $signal){$body=json_encode($signal);$ts=(string)time();$sig=hash_hmac('sha256',$ts.'.'.$body,$this->secret);$ch=curl_init($this->url);curl_setopt_array($ch,array(CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>array('Content-Type: application/json','X-S3-Timestamp: '.$ts,'X-S3-Signature: '.$sig),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$this->timeout));$resp=curl_exec($ch);$err=curl_error($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if($resp===false||$code<200||$code>=300)throw new RuntimeException('Internal signal failed HTTP '.$code.' '.$err);return true;}
}
