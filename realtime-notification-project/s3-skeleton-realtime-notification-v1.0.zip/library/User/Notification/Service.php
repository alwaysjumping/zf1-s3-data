<?php
class User_Notification_Service
{
    const TYPE_MESSAGE='message'; const TYPE_DOCUMENT_SHARED='document_shared'; const TYPE_TASK_ASSIGNED='task_assigned'; const TYPE_SYSTEM='system'; const TYPE_REMINDER='reminder';
    protected $db;
    public function __construct(Zend_Db_Adapter_Abstract $db=null){ $this->db=$db ?: Zend_Db_Table::getDefaultAdapter(); }
    public function create($userId,$type,$title,$message,array $options=array()){
        $this->db->beginTransaction();
        try {
            $now=gmdate('Y-m-d H:i:s');
            $this->db->insert('notifications',array('user_id'=>(int)$userId,'type'=>$type,'title'=>$title,'message'=>$message,'entity_type'=>isset($options['entity_type'])?$options['entity_type']:null,'entity_id'=>isset($options['entity_id'])?$options['entity_id']:null,'action_url'=>isset($options['action_url'])?$options['action_url']:null,'is_read'=>0,'created_at'=>$now));
            $id=(int)$this->db->lastInsertId();
            $event=$this->appendEvent($userId,$id,'notification.created',array('notification_id'=>$id));
            $this->appendOutbox($event['event_id']); $this->db->commit();
            return array('notification_id'=>$id,'event_id'=>$event['event_id']);
        } catch(Exception $e){ $this->db->rollBack(); throw $e; }
    }
    public function markRead($userId,$notificationId){
        $this->db->beginTransaction(); try {
            $row=$this->db->fetchRow('SELECT id,is_read FROM notifications WHERE id=? AND user_id=? FOR UPDATE',array((int)$notificationId,(int)$userId));
            if(!$row){$this->db->rollBack(); return false;} if((int)$row['is_read']===1){$this->db->commit(); return null;}
            $this->db->update('notifications',array('is_read'=>1,'read_at'=>gmdate('Y-m-d H:i:s')),array('id = ?'=>(int)$notificationId,'user_id = ?'=>(int)$userId));
            $e=$this->appendEvent($userId,$notificationId,'notification.read',array('notification_id'=>(int)$notificationId)); $this->appendOutbox($e['event_id']); $this->db->commit(); return $e;
        } catch(Exception $e){$this->db->rollBack();throw $e;}
    }
    public function markAllRead($userId){
        $this->db->beginTransaction(); try { $n=$this->db->update('notifications',array('is_read'=>1,'read_at'=>gmdate('Y-m-d H:i:s')),array('user_id = ?'=>(int)$userId,'is_read = ?'=>0));
            if($n){$e=$this->appendEvent($userId,null,'notification.read_all',array());$this->appendOutbox($e['event_id']);} else {$e=null;} $this->db->commit(); return $e;
        }catch(Exception $e){$this->db->rollBack();throw $e;}
    }
    public function delete($userId,$notificationId){
        $this->db->beginTransaction(); try { $n=$this->db->delete('notifications',array('id = ?'=>(int)$notificationId,'user_id = ?'=>(int)$userId)); if(!$n){$this->db->rollBack();return false;}
            $e=$this->appendEvent($userId,$notificationId,'notification.deleted',array('notification_id'=>(int)$notificationId));$this->appendOutbox($e['event_id']);$this->db->commit();return $e;
        }catch(Exception $e){$this->db->rollBack();throw $e;}
    }
    public function get($userId,$id){ return $this->db->fetchRow('SELECT * FROM notifications WHERE id=? AND user_id=?',array((int)$id,(int)$userId)); }
    public function getNotifications($userId,$limit=50,$beforeId=null){$limit=max(1,min(200,(int)$limit));$sql='SELECT * FROM notifications WHERE user_id=?';$b=array((int)$userId);if($beforeId){$sql.=' AND id < ?';$b[]=(int)$beforeId;}$sql.=' ORDER BY id DESC LIMIT '.$limit;return $this->db->fetchAll($sql,$b);}
    public function getUnreadCount($userId){return (int)$this->db->fetchOne('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0',(int)$userId);}
    public function getEventsAfter($userId,$after,$limit=200){$limit=max(1,min(500,(int)$limit));return $this->db->fetchAll('SELECT event_id,notification_id,event_type,payload_json,created_at FROM notification_events WHERE user_id=? AND event_id>? ORDER BY event_id ASC LIMIT '.$limit,array((int)$userId,(int)$after));}
    protected function appendEvent($userId,$notificationId,$type,array $payload){$this->db->insert('notification_events',array('user_id'=>(int)$userId,'notification_id'=>$notificationId,'event_type'=>$type,'payload_json'=>json_encode($payload),'created_at'=>gmdate('Y-m-d H:i:s')));return array('event_id'=>(int)$this->db->lastInsertId(),'event'=>$type,'notification_id'=>$notificationId);}
    protected function appendOutbox($eventId){$now=gmdate('Y-m-d H:i:s');$this->db->insert('notification_outbox',array('event_id'=>(int)$eventId,'status'=>'pending','attempts'=>0,'available_at'=>$now,'created_at'=>$now));}
}
