<?php

class User_Jwt_JwtException extends RuntimeException
{
    const TOKEN_INVALID = 1001;

    const TOKEN_EXPIRED = 1002;

    const TOKEN_INVALID_SIGNATURE = 1003;

    const TOKEN_NOT_YET_VALID = 1004;

    const TOKEN_INVALID_CLAIMS = 1005;

    protected $jwtErrorCode;

    protected $previousException;

    public function __construct(
        $message,
        $jwtErrorCode,
        Exception $previous = null
    ) {
        parent::__construct($message);

        $this->jwtErrorCode = $jwtErrorCode;
        $this->previousException = $previous;
    }

    public function getJwtErrorCode()
    {
        return $this->jwtErrorCode;
    }

    public function getPreviousException()
    {
        return $this->previousException;
    }
}