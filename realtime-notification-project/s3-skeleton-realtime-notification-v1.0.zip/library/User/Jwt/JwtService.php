<?php

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;
use Firebase\JWT\BeforeValidException;

class User_Jwt_JwtService
{
    protected $secret;

    protected $algorithm;

    protected $issuer;

    protected $audience;

    protected $accessTokenLifetime;

    public function __construct(array $config)
    {
        $this->secret = $config['secret'];
        $this->algorithm = $config['algorithm'];
        $this->issuer = $config['issuer'];
        $this->audience = $config['audience'];
        $this->accessTokenLifetime =
            (int) $config['accessTokenLifetime'];

        if (empty($this->secret)) {
            throw new InvalidArgumentException(
                'JWT secret is required.'
            );
        }

        if (empty($this->algorithm)) {
            throw new InvalidArgumentException(
                'JWT algorithm is required.'
            );
        }
    }

    /**
     * Create a new JWT access token.
     *
     * @param int|string $userId
     * @param array      $additionalClaims
     *
     * @return string
     */
    public function createAccessToken(
        $userId,
        array $additionalClaims = array()
    ) {
        $now = time();

        $payload = array(
            'iss' => $this->issuer,
            'aud' => $this->audience,
            'sub' => (string) $userId,
            'iat' => $now,
            'nbf' => $now,
            'exp' => $now + $this->accessTokenLifetime,
        );

        /*
         * Prevent callers from replacing security-sensitive claims.
         */
        unset(
            $additionalClaims['iss'],
            $additionalClaims['aud'],
            $additionalClaims['sub'],
            $additionalClaims['iat'],
            $additionalClaims['nbf'],
            $additionalClaims['exp']
        );

        $payload = array_merge(
            $payload,
            $additionalClaims
        );

        return JWT::encode(
            $payload,
            $this->secret,
            $this->algorithm
        );
    }

    /**
     * Verify and decode an access token.
     *
     * @param string $token
     *
     * @return array
     *
     * @throws User_Jwt_JwtException
     */
    public function verifyAccessToken($token)
    {
        if (!is_string($token) || $token === '') {
            throw new User_Jwt_JwtException(
                'JWT token is empty.',
                User_Jwt_JwtException::TOKEN_INVALID
            );
        }

        try {
            $decoded = JWT::decode(
                $token,
                new Key(
                    $this->secret,
                    $this->algorithm
                )
            );
        } catch (ExpiredException $e) {
            throw new User_Jwt_JwtException(
                'JWT token has expired.',
                User_Jwt_JwtException::TOKEN_EXPIRED,
                $e
            );
        } catch (BeforeValidException $e) {
            throw new User_Jwt_JwtException(
                'JWT token is not valid yet.',
                User_Jwt_JwtException::TOKEN_NOT_YET_VALID,
                $e
            );
        } catch (SignatureInvalidException $e) {
            throw new User_Jwt_JwtException(
                'JWT signature is invalid.',
                User_Jwt_JwtException::TOKEN_INVALID_SIGNATURE,
                $e
            );
        } catch (UnexpectedValueException $e) {
            throw new User_Jwt_JwtException(
                'JWT token is invalid.',
                User_Jwt_JwtException::TOKEN_INVALID,
                $e
            );
        } catch (DomainException $e) {
            throw new User_Jwt_JwtException(
                'JWT token could not be verified.',
                User_Jwt_JwtException::TOKEN_INVALID,
                $e
            );
        }

        $claims = (array) $decoded;

        $this->validateClaims($claims);

        return $claims;
    }

    /**
     * Validate application-specific JWT claims.
     *
     * firebase/php-jwt validates signature and time claims,
     * while we additionally validate our issuer/audience/etc.
     *
     * @param array $claims
     *
     * @return void
     *
     * @throws User_Jwt_JwtException
     */
    protected function validateClaims(array $claims)
    {
        if (
            !isset($claims['iss'])
            || $claims['iss'] !== $this->issuer
        ) {
            throw new User_Jwt_JwtException(
                'Invalid JWT issuer.',
                User_Jwt_JwtException::TOKEN_INVALID_CLAIMS
            );
        }

        if (
            !isset($claims['aud'])
            || $claims['aud'] !== $this->audience
        ) {
            throw new User_Jwt_JwtException(
                'Invalid JWT audience.',
                User_Jwt_JwtException::TOKEN_INVALID_CLAIMS
            );
        }

        if (
            !isset($claims['sub'])
            || $claims['sub'] === ''
        ) {
            throw new User_Jwt_JwtException(
                'JWT subject is missing.',
                User_Jwt_JwtException::TOKEN_INVALID_CLAIMS
            );
        }

        if (!isset($claims['exp'])) {
            throw new User_Jwt_JwtException(
                'JWT expiration is missing.',
                User_Jwt_JwtException::TOKEN_INVALID_CLAIMS
            );
        }
    }
}