<?php

class User_RefreshTokenService extends Zend_Controller_Plugin_Abstract
{
    const TOKEN_BYTES = 32;

    const TOKEN_LIFETIME = 2592000;
    // 30 days

    protected $table;

    public function __construct(
        $table = null
    )
    {
        if ($table === null) {
            // $table = User_Db_Table::factory('Model_Refreshtokens');
        }

        $this->table = $table;
    }

    public function create(
        $userId,
        $ipAddress = null,
        $userAgent = null,
        $familyId = null,
        $parentTokenId = null
    ) {
        if ($familyId === null) {
            $familyId = bin2hex(
                random_bytes(16)
            );
        }

        $token = bin2hex(
            random_bytes(self::TOKEN_BYTES)
        );

        $tokenHash = $this->hashToken(
            $token
        );

        $now = time();

        $expiresAt =
            $now + self::TOKEN_LIFETIME;

        $id = $this->table->insert(
            array(
                'user_id' => $userId,

                'family_id' => $familyId,

                'parent_token_id' =>
                    $parentTokenId,

                'token_hash' =>
                    $tokenHash,

                'created_at' =>
                    date(
                        'Y-m-d H:i:s',
                        $now
                    ),

                'expires_at' =>
                    date(
                        'Y-m-d H:i:s',
                        $expiresAt
                    ),

                'created_ip' =>
                    $ipAddress,

                'user_agent' =>
                    $userAgent
            )
        );

        return array(
            'id' => $id,
            'token' => $token,
            'family_id' => $familyId,
            'expires_at' => $expiresAt
        );
    }

    /**
     * Hash a raw refresh token.
     *
     * @param string $token
     *
     * @return string
     */
    public function hashToken($token)
    {
        return hash(
            'sha256',
            $token
        );
    }

    /**
     * Find a valid refresh token.
     *
     * @param string $token
     *
     * @return Zend_Db_Table_Row_Abstract|null
     */
    public function findValidToken($token)
    {
        $this->table = User_Db_Table::factory('Model_Refreshtokens');

        if (!is_string($token) || $token === '') {
            return null;
        }

        $tokenHash =
            $this->hashToken($token);

        $select = $this->table
            ->select()
            ->where(
                'token_hash = ?',
                $tokenHash
            )
            ->where(
                'revoked_at IS NULL'
            )
            ->where(
                'expires_at > ?',
                date('Y-m-d H:i:s')
            );

        $row = $this->table->fetchRow(
            $select
        );

        return $row ?: null;
    }

    /**
     * Revoke refresh token.
     *
     * @param string $token
     *
     * @return int
     */
    public function revoke($token)
    {
        $this->table = User_Db_Table::factory('Model_Refreshtokens');

        $tokenHash =
            $this->hashToken($token);

        return $this->table->update(
            array(
                'revoked_at' =>
                    date('Y-m-d H:i:s')
            ),
            array(
                'token_hash = ?' =>
                    $tokenHash,
                'revoked_at IS NULL'
            )
        );
    }

    public function rotate(
        $oldToken,
        $ipAddress = null,
        $userAgent = null
    ) {
        $this->table = User_Db_Table::factory('Model_Refreshtokens');

        $row = $this->findValidToken($oldToken);

        if (!$row) {
            return false;
        }

        $db = $this->table
            ->getAdapter();

        $db->beginTransaction();

        try {
            $this->table->update(
                array(
                    'revoked_at' =>
                        date('Y-m-d H:i:s'),
                    'last_used_at' =>
                        date('Y-m-d H:i:s')
                ),
                array(
                    'id = ?' => $row->id,
                    'revoked_at IS NULL'
                )
            );

            $newToken = $this->create(
                $row->user_id,
                $ipAddress,
                $userAgent
            );

            $db->commit();

            return array(
                'user_id' => $row->user_id,
                'refresh_token' =>
                    $newToken['token'],
                'refresh_token_expires_at' =>
                    $newToken['expires_at']
            );
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }
}