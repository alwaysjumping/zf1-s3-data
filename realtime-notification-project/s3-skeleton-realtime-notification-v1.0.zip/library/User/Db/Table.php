<?php

/**
 * @see Zend_Db_Table
 * Class for SQL table interface.
 *
 * @category   User
 * @package    User_Db
 * @subpackage Table
 * @version 2.0
 */
class User_Db_Table extends Zend_Db_Table_Abstract
{
    const FULLNAME = 'fullname';

    public static function factory($className, $params = array())
    {
        $instName = $className;

        if (isset($params['year'])) {
            $instName .= "_" . $params['year'];
        }

        self::loadClass($className);

        // $instance = new $className($params);
        $instance = new $className($params);

        return $instance;
    }

    /**
     * get the info of model
     */
    public static function getInfo($className = null)
    {
        if (is_null($className) && self) {
            $className = get_class(self);
        }

        $patterns = explode("_", $className);
        $module = $patterns[0];

        if ($patterns[0] == 'Model') {
            $module = 'Default';
        } else {
            array_shift($patterns);
        }

        array_shift($patterns);
        $module = strtolower($module);

        $module_dir = Zend_Controller_Front::getInstance()->getModuleDirectory($module);
        $path = isset($module_dir) ? $module_dir . "/models" : $module . "/models";

        for ($i = 0; $i < sizeof($patterns); $i++) {
            $path .= '/' . $patterns[$i];
        }

        $path = $path . ".php";

        $info = array(
            'module'    => $module,
            'classfile' => $path,
            'basename'  => implode('_', $patterns),
            'name'      => $className
        );

        return $info;
    }

    public static function loadClass($className)
    {
        $info = self::getInfo($className);

        if (!file_exists($info['classfile'])) {
            throw new User_Exception(
                'There is no required file.(' . $info['classfile'] . ')',
                20
            );
        }

        require_once($info['classfile']);
    }
}