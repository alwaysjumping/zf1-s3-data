-- S3 Realtime Notification & Reminder System v1.3
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique notification identifier',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'ID of the user who owns and receives the notification',
 type VARCHAR(50) NOT NULL COMMENT 'Notification type: message, document_shared, task_assigned, system, reminder',
 title VARCHAR(255) NOT NULL COMMENT 'Short notification title',
 message TEXT NOT NULL COMMENT 'Notification message or summary',
 entity_type VARCHAR(50) DEFAULT NULL COMMENT 'Related business entity type',
 entity_id BIGINT UNSIGNED DEFAULT NULL COMMENT 'Related business entity identifier',
 action_url VARCHAR(500) DEFAULT NULL COMMENT 'Server-controlled application URL',
 is_read TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0 unread, 1 read',
 created_at DATETIME NOT NULL COMMENT 'Creation time in UTC',
 read_at DATETIME DEFAULT NULL COMMENT 'Read time in UTC',
 PRIMARY KEY (id), KEY idx_user_read (user_id,is_read), KEY idx_user_created (user_id,created_at), KEY idx_entity (entity_type,entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notification_events (
 event_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Monotonic ordering/recovery/deduplication identifier',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'Owner user ID',
 notification_id BIGINT UNSIGNED DEFAULT NULL COMMENT 'Related notification ID, NULL for aggregate events',
 event_type VARCHAR(50) NOT NULL COMMENT 'Logical event type',
 payload_json LONGTEXT NOT NULL COMMENT 'Immutable lightweight JSON event payload',
 created_at DATETIME NOT NULL COMMENT 'Persisted time in UTC',
 PRIMARY KEY (event_id), KEY idx_user_event (user_id,event_id), KEY idx_notification (notification_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notification_outbox (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique dispatch work item',
 event_id BIGINT UNSIGNED NOT NULL COMMENT 'Event that must be signaled',
 status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT 'pending, processing, processed, failed',
 attempts INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Dispatch attempts',
 available_at DATETIME NOT NULL COMMENT 'Earliest retry time in UTC',
 locked_at DATETIME DEFAULT NULL COMMENT 'Dispatcher claim time',
 processed_at DATETIME DEFAULT NULL COMMENT 'Successful signal time',
 last_error TEXT DEFAULT NULL COMMENT 'Latest dispatch error',
 created_at DATETIME NOT NULL COMMENT 'Creation time in UTC',
 PRIMARY KEY (id), UNIQUE KEY uk_event_id (event_id), KEY idx_dispatch (status,available_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reminders (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique reminder definition identifier',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'Owner user ID',
 title VARCHAR(255) NOT NULL COMMENT 'Reminder title',
 message TEXT NOT NULL COMMENT 'Reminder message',
 remind_at DATETIME NOT NULL COMMENT 'Next absolute trigger time in UTC',
 timezone VARCHAR(64) NOT NULL DEFAULT 'UTC' COMMENT 'IANA timezone used for recurrence wall-clock rules',
 entity_type VARCHAR(50) DEFAULT NULL COMMENT 'Related business entity type',
 entity_id BIGINT UNSIGNED DEFAULT NULL COMMENT 'Related business entity ID',
 action_url VARCHAR(500) DEFAULT NULL COMMENT 'Server-controlled URL opened by client',
 status VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT 'pending, triggered, completed, cancelled',
 recurrence_type VARCHAR(20) NOT NULL DEFAULT 'none' COMMENT 'none, daily, weekly, monthly or custom',
 recurrence_rule VARCHAR(500) DEFAULT NULL COMMENT 'Application-defined recurrence rule',
 created_at DATETIME NOT NULL COMMENT 'Creation time in UTC',
 updated_at DATETIME NOT NULL COMMENT 'Last update time in UTC',
 completed_at DATETIME DEFAULT NULL COMMENT 'Completion time in UTC',
 cancelled_at DATETIME DEFAULT NULL COMMENT 'Cancellation time in UTC',
 PRIMARY KEY(id), KEY idx_user_status(user_id,status), KEY idx_due(status,remind_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reminder_occurrences (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique reminder occurrence identifier',
 reminder_id BIGINT UNSIGNED NOT NULL COMMENT 'Parent reminder definition ID',
 scheduled_at DATETIME NOT NULL COMMENT 'Original occurrence schedule in UTC',
 triggered_at DATETIME DEFAULT NULL COMMENT 'Trigger time in UTC',
 dismissed_at DATETIME DEFAULT NULL COMMENT 'Dismiss time in UTC',
 completed_at DATETIME DEFAULT NULL COMMENT 'Completion time in UTC',
 snoozed_until DATETIME DEFAULT NULL COMMENT 'Snoozed trigger time in UTC',
 PRIMARY KEY(id), KEY idx_reminder(reminder_id), KEY idx_scheduled(scheduled_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
