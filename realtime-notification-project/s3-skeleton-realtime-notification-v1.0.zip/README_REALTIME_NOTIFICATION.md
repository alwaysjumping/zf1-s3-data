# S3 Realtime Notification & Reminder Implementation

This source package implements the finalized v1.3 architecture for the supplied ZF1 skeleton.

## Important integration notes

The skeleton intentionally contains placeholder REST routing and simplified authentication. The new notification core is independent of those placeholders, but production integration must map the API URLs to the supplied controllers/actions and must apply your production CSRF middleware to cookie/session state-changing requests.

The implementation does **not** use Redis. MariaDB is the source of truth. Workerman/Node.js carry lightweight signals only; clients retrieve protected data from authenticated ZF1 APIs.

## Added components

- `database/realtime_notification.sql` — notifications, events, outbox, reminders and occurrences.
- `library/User/Notification/*` — notification service, outbox dispatcher, signed internal signal client.
- `library/User/Reminder/Service.php` — reminder creation/trigger/actions.
- `library/User/Controller/Api.php` — small API controller base supporting session or Bearer JWT identity.
- `framework/controllers/*` — notification/event/realtime/reminder APIs.
- `bin/notification-dispatcher.php` — retries outbox delivery.
- `bin/reminder-worker.php` — server-authoritative reminder scheduler.
- `public/js/realtime/*` — leader election, WebSocket/polling transports, manager and periodic reconciliation.
- `realtime/workerman` — Group B signal server.
- `realtime/node` — Group A signal server.
- `deploy/systemd` — CentOS service examples.

## Install

1. Restore your normal `vendor/` and `library/Zend/` dependencies.
2. Apply `database/realtime_notification.sql` to the application MariaDB database.
3. Add environment secrets shown in `deploy/realtime.env.example`. Use independent high-entropy values for JWT and internal signaling.
4. Configure `realtime.*` in `configs/application.ini` for each subsidiary.
5. Map the notification API controllers through your production router. The skeleton's `User_Rest_Route::match()` is hard-coded and is not production-ready.
6. Protect POST actions with the application's existing CSRF validation when browser session cookies are used.
7. Run the reminder worker and dispatcher under systemd/supervisor.
8. Run Workerman for Group B, Node.js for Group A, or set polling transport for Group C.
9. Load the five scripts in `public/js/realtime/` and initialize the manager after login.

## Browser initialization example

```javascript
fetch('/api/realtime/config', {credentials: 'same-origin'})
  .then(function (r) { return r.json(); })
  .then(function (config) {
      var coordinator = new S3TabCoordinator();
      var manager = new S3NotificationManager({baseUrl: '/api'});
      var transports = new S3NotificationTransportManager({
          coordinator: coordinator,
          manager: manager,
          config: config,
          tokenUrl: '/api/realtime/token'
      });
      manager.on('notification', function (n) {
          // Connect this event to your DHTMLX 3.5 notification UI.
          console.log('notification', n);
      });
      manager.on('unread', function (count) {
          console.log('unread', count);
      });
      transports.start();
  });
```

## Failure semantics

A healthy WebSocket does not prove the ZF1-to-realtime internal signal path is healthy. The outbox retries failed signals and the browser performs periodic `event_id` reconciliation even while WebSocket is connected. This closes the degraded-channel failure case defined in v1.3.

## Production hardening checklist

- Terminate WSS/HTTPS with your normal reverse proxy and valid TLS certificates.
- Keep the internal HTTP listener on loopback/private network only.
- Restrict firewall access to the internal listener.
- Replace example URLs and secrets.
- Add application logging/metrics for outbox backlog and health state.
- For multiple dispatcher processes, replace the simple single-worker query with an atomic claim strategy appropriate to your MariaDB version.
- Validate/allow-list `action_url` so notifications cannot introduce arbitrary external redirects.
- Validate reminder timestamps and recurrence rules server-side.
- Add retention jobs for old events/outbox rows according to your audit requirements.
- Add PHPUnit tests around service transaction semantics before production rollout.

## Deliberate skeleton-specific limitations

Because the supplied project is a structural skeleton rather than the complete production application, these hooks remain integration points rather than guessed implementations:

- final REST route mapping;
- production CSRF helper/middleware;
- exact session identity fields beyond `user_key`;
- production ACL checks for business entities;
- DHTMLX notification presentation markup;
- Windows desktop application's existing authentication shell, if one already exists.

The notification persistence, event/outbox semantics, internal signaling protocol, realtime servers, transport coordination, and reconciliation logic are provided independently of those hooks.
