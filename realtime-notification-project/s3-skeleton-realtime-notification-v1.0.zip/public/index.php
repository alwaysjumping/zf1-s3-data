<?php
defined('ROOT_PATH') || define('ROOT_PATH', realpath(dirname(__FILE__) . '/../'));
defined('CONFIG_PATH') || define('CONFIG_PATH', realpath(ROOT_PATH . '/configs/'));

// Define path to application directory
defined('APPLICATION_PATH')
|| define('APPLICATION_PATH', ROOT_PATH . '/../applications');

// Define application environment
defined('APPLICATION_ENV')
|| define('APPLICATION_ENV', (getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'development'));

$paths = array(realpath(ROOT_PATH . '/library'), realpath(ROOT_PATH . '/library/Bizbasic'));
if (function_exists('zend_deployment_library_path') && zend_deployment_library_path('Zend Framework 1')) {
    $paths[] = zend_deployment_library_path('Zend Framework 1');
}
$paths[] = get_include_path();
set_include_path(implode(PATH_SEPARATOR, $paths));

// composer autoload
$vendorAutoload = dirname(__DIR__)
    . '/vendor/autoload.php';

if (!file_exists($vendorAutoload)) {
    throw new RuntimeException(
        'Composer autoloader was not found.'
    );
}

require_once $vendorAutoload;

require_once 'Zend/Config/Ini.php';
require_once('Zend/Auth.php');

/** Zend_Application */
require_once 'Zend/Application.php';

$env = APPLICATION_ENV;
$conf = new Zend_Config_Ini(CONFIG_PATH . '/application.ini');
$conf = $conf->$env->toArray();

$wsUriMatch = sprintf('|^/%s/|', preg_quote($conf['service']['uriPrefix'], '|'));
if (preg_match($wsUriMatch, $_SERVER['REQUEST_URI'])) {    // running as a web service
    $wsConfCore = $conf['service'];

    $wsConfExt = array(
        'resources' => array(
            'db' => $conf['resources']['db'],
            'cachemanager' => $conf['resources']['cachemanager']
        )
    );

    $conf = array_merge_recursive($wsConfCore, $wsConfExt);
} else {    // running as an ordinary app
    unset($conf['service']);
}

// Create application, bootstrap, and run
$application = new Zend_Application(
    APPLICATION_ENV,
    new Zend_Config($conf)
);

$application->bootstrap()
    ->run();