var baz = 3;
