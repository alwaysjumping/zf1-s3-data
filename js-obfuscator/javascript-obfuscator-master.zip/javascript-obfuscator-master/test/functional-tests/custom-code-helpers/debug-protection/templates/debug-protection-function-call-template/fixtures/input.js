(function () {
    return 1;
})();