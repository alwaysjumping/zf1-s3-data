import { inject, injectable } from 'inversify';
import { ServiceIdentifiers } from '../../container/ServiceIdentifiers';

import { TNodeWithLexicalScope } from '../../types/node/TNodeWithLexicalScope';

import { IIdentifierNamesGenerator } from '../../interfaces/generators/identifier-names-generators/IIdentifierNamesGenerator';
import { IOptions } from '../../interfaces/options/IOptions';
import { IRandomGenerator } from '../../interfaces/utils/IRandomGenerator';

import { NodeGuards } from '../../node/NodeGuards';

@injectable()
export abstract class AbstractIdentifierNamesGenerator implements IIdentifierNamesGenerator {
    /**
     * @type {number}
     */
    private static readonly maxGenerationAttempts: number = 10000;

    /**
     * @type {IOptions}
     */
    protected readonly options: IOptions;

    /**
     * @type {IRandomGenerator}
     */
    protected readonly randomGenerator: IRandomGenerator;

    /**
     * @type {Set<string>}
     */
    protected readonly preservedNamesSet: Set<string> = new Set();

    /**
     * @type {WeakMap<TNodeWithLexicalScope, Set<string>>}
     */
    protected readonly lexicalScopesPreservedNamesMap: WeakMap<TNodeWithLexicalScope, Set<string>> = new WeakMap();

    /**
     * @type {Set<string>}
     */
    protected readonly allLexicalScopePreservedNames: Set<string> = new Set();

    /**
     * @param {IRandomGenerator} randomGenerator
     * @param {IOptions} options
     */
    public constructor(
        @inject(ServiceIdentifiers.IRandomGenerator) randomGenerator: IRandomGenerator,
        @inject(ServiceIdentifiers.IOptions) options: IOptions
    ) {
        this.randomGenerator = randomGenerator;
        this.options = options;
    }

    /**
     * @param {TNodeWithLexicalScope} lexicalScopeNode
     * @param {number} nameLength
     * @returns {string}
     */
    public generate(lexicalScopeNode: TNodeWithLexicalScope, nameLength?: number): string {
        return NodeGuards.isProgramNode(lexicalScopeNode)
            ? this.generateForGlobalScope()
            : this.generateForLexicalScope(lexicalScopeNode);
    }

    /**
     * @param {string} name
     */
    public preserveName(name: string): void {
        this.preservedNamesSet.add(name);
    }

    /**
     * @param {string} name
     * @param {TNodeWithLexicalScope} lexicalScopeNode
     */
    public preserveNameForLexicalScope(name: string, lexicalScopeNode: TNodeWithLexicalScope): void {
        const preservedNamesForLexicalScopeSet: Set<string> =
            this.lexicalScopesPreservedNamesMap.get(lexicalScopeNode) ?? new Set();

        preservedNamesForLexicalScopeSet.add(name);

        this.lexicalScopesPreservedNamesMap.set(lexicalScopeNode, preservedNamesForLexicalScopeSet);

        this.allLexicalScopePreservedNames.add(name);
    }

    /**
     * @param {string} name
     * @returns {boolean}
     */
    public isValidIdentifierName(name: string): boolean {
        return !this.isReservedName(name) && !this.preservedNamesSet.has(name);
    }

    /**
     * @param {string} name
     * @param {TNodeWithLexicalScope[]} lexicalScopeNodes
     * @returns {boolean}
     */
    public isValidIdentifierNameInLexicalScopes(name: string, lexicalScopeNodes: TNodeWithLexicalScope[]): boolean {
        if (!this.isValidIdentifierName(name)) {
            return false;
        }

        for (const lexicalScope of lexicalScopeNodes) {
            const preservedNamesForLexicalScopeSet: Set<string> | null =
                this.lexicalScopesPreservedNamesMap.get(lexicalScope) ?? null;

            if (!preservedNamesForLexicalScopeSet) {
                continue;
            }

            if (preservedNamesForLexicalScopeSet.has(name)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Checks if the name is valid and not preserved in any scope (global or lexical).
     * This is used for global scope name generation to avoid conflicts with
     * variables in any lexical scope that might shadow the global variable.
     *
     * @param {string} name
     * @returns {boolean}
     */
    public isValidIdentifierNameInAllScopes(name: string): boolean {
        if (!this.isValidIdentifierName(name)) {
            return false;
        }

        // Check if the name is preserved in any lexical scope
        return !this.allLexicalScopePreservedNames.has(name);
    }

    /**
     * @param {number} attempts
     */
    protected checkGenerationAttempts(attempts: number): void {
        if (attempts > AbstractIdentifierNamesGenerator.maxGenerationAttempts) {
            throw new Error(
                'Unable to generate a valid identifier name. ' +
                    'This is likely caused by `reservedNames` patterns that match all generated names. ' +
                    'Please check your `reservedNames` option.'
            );
        }
    }

    /**
     * @param {string} name
     * @returns {boolean}
     */
    private isReservedName(name: string): boolean {
        return this.options.reservedNames.length
            ? this.options.reservedNames.some(
                  (reservedName: string) => new RegExp(reservedName, 'g').exec(name) !== null
              )
            : false;
    }

    /**
     * @param {number} nameLength
     * @returns {string}
     */
    public abstract generateForGlobalScope(nameLength?: number): string;

    /**
     * @param {number} nameLength
     * @returns {string}
     */
    public abstract generateForGlobalScopeWithAllScopesValidation(nameLength?: number): string;

    /**
     * @param {TNodeWithLexicalScope} lexicalScopeNode
     * @param {number} nameLength
     * @returns {string}
     */
    public abstract generateForLexicalScope(lexicalScopeNode: TNodeWithLexicalScope, nameLength?: number): string;

    /**
     * @param {string} label
     * @param {number} nameLength
     * @returns {string}
     */
    public abstract generateForLabel(label: string, nameLength?: number): string;

    /**
     * @param {number} nameLength
     * @returns {string}
     */
    public abstract generateNext(nameLength?: number): string;
}
