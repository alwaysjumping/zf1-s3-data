# PDF Annotation Viewer V4.3

A browser-based PDF annotation viewer using:

- HTML
- CSS
- Plain JavaScript
- PDF.js from CDN

The annotation layer itself is implemented in plain JavaScript using HTML canvas.

## Features

### PDF input

You can open a PDF in either of these ways:

1. Select a local PDF file.
2. Enter an HTTP/HTTPS PDF URL.

### Annotation tools

- Select
- Move
- Resize rectangles
- Resize circles / ellipses
- Resize arrows using endpoint handles
- Rotate rectangles
- Rotate circles / ellipses
- Rotate arrows
- Shift-drag aspect-ratio locking for rectangles/circles
- Shift-drag 15° angle snapping for arrows
- Shift + rotation-handle snapping to 15° increments
- Rectangle
- Circle / ellipse
- Arrow
- Freehand
- Text
- Delete
- Clear
- Undo
- Redo

### Viewer

- Multi-page PDF rendering
- Zoom in
- Zoom out
- Fit
- Per-page annotation coordinates
- Normalized coordinates, so annotations remain aligned when zoom changes

#
## Shift-key controls

Hold **Shift** while drawing or resizing a rectangle/circle to lock its aspect ratio.

- When creating a rectangle or circle, Shift makes the shape square.
- When resizing an existing rectangle/circle, Shift preserves its existing aspect ratio.
- When rotating a rectangle, circle, or arrow, Shift snaps the rotation to **15° increments**.
- When drawing an arrow, Shift snaps the arrow angle to **15° increments**.

The snapping uses the current pointer state, so Shift can be pressed or released during the operation.

## JSON

Annotations are saved separately from the original PDF.

Example:

```json
{
  "version": 3,
  "type": "plain-js-pdf-annotations",
  "document": {
    "name": "example.pdf",
    "pageCount": 3
  },
  "createdAt": "2026-10-05T00:00:00.000Z",
  "annotations": [
    {
      "id": "abc",
      "page": 1,
      "type": "rect",
      "x": 0.2,
      "y": 0.3,
      "w": 0.4,
      "h": 0.15,
      "color": "#ff0000",
      "lineWidth": 2
    }
  ]
}
```

Coordinates are normalized from `0` to `1`.

For example:

```text
x = 0       left edge
x = 1       right edge

y = 0       top edge
y = 1       bottom edge
```

This makes annotations independent of the current zoom level.

## Run

The easiest way is to run a local HTTP server.

With PHP:

```powershell
cd pdf-annotation-viewer-v4.3
php -S localhost:8000
```

Then open:

```text
http://localhost:8000
```

Do not rely on `file://` if you have browser security or module-loading problems.

## Loading a PDF from a URL

Enter something like:

```text
https://example.com/document.pdf
```

and click **Load URL**.

The browser uses:

```javascript
fetch(url)
```

to download the PDF and then passes the bytes to PDF.js.

## Important: CORS

For a cross-origin PDF URL, the remote server must allow browser access.

For example, the PDF server might return:

```http
Access-Control-Allow-Origin: *
```

or:

```http
Access-Control-Allow-Origin: https://your-viewer.example.com
```

Without the appropriate CORS header, JavaScript running on your viewer cannot normally read the response.

Opening the PDF directly in a browser tab is NOT proof that `fetch()` will work.

The following can happen:

```text
Browser tab
    |
    +----> https://example.com/document.pdf
            works

JavaScript fetch()
    |
    +----> https://example.com/document.pdf
            blocked by CORS
```

## HTTP versus HTTPS

If your annotation viewer is served over HTTPS, an HTTP PDF URL can be blocked as mixed content.

Prefer:

```text
https://your-server.example.com/document.pdf
```

instead of:

```text
http://your-server.example.com/document.pdf
```

If the viewer itself is running on:

```text
http://localhost:8000
```

then HTTP URLs can be possible, subject to normal CORS rules.

## Private / authenticated PDFs

For a private company document system, do not normally let users enter arbitrary remote URLs.

A better architecture is:

```text
Browser
   |
   | authenticated request
   v
Your PHP application
   |
   | authorization + document lookup
   v
Private PDF storage
```

For example:

```text
GET /api/documents/123/pdf
```

The PHP server verifies the logged-in user and streams the permitted PDF.

The browser then loads:

```javascript
fetch("/api/documents/123/pdf")
```

This avoids requiring the browser to directly access a private storage server.

It also gives your application control over:

- Authentication
- Authorization
- Audit logging
- Document permissions
- Expiration
- Access control

### Security note

Avoid creating a public endpoint like:

```text
GET /proxy?url=https://anything.example.com/file.pdf
```

without strict validation and authorization. An unrestricted server-side URL proxy can create SSRF security risks.

For an enterprise SEC/document system, prefer a document ID:

```text
/api/documents/{documentId}/pdf
```

and resolve the actual storage location on the server.

## Architecture

```text
                    PDF input
                       |
             +---------+---------+
             |                   |
       Local File           HTTP/HTTPS URL
             |                   |
             +---------+---------+
                       |
                    PDF bytes
                       |
                       v
                    PDF.js
                       |
                PDF page rendering
                       |
                       v
             +-------------------+
             | Annotation Canvas |
             +-------------------+
                       |
          +------------+------------+
          |            |            |
        Rect         Circle       Arrow
          |            |            |
       Freehand       Text        Select
          |
          v
      annotations[]
          |
          v
       JSON file
```

## Important limitation

This project does NOT write annotations into the original PDF.

It stores annotations separately as JSON.

For example:

```text
document.pdf
document-annotations.json
```

The PDF remains unchanged.

If you eventually need:

```text
document.pdf
      +
annotations
      |
      v
annotated-document.pdf
```

then a PDF-writing library or a server-side PDF processing component is required.

## PDF.js

This sample uses PDF.js from jsDelivr:

```text
https://cdn.jsdelivr.net/npm/pdfjs-dist@6.4.299/
```

Therefore an Internet connection is required unless you download and serve PDF.js locally.


## Selection and transformation controls

### Rectangle / circle

```text
   [rotate]
       |
 [resize]---[resize]
    |       |
 [resize]---[resize]
```

The four corner handles resize the shape. The handle above the shape rotates it.

### Arrow

```text
[resize]-----------[resize]
          |
       [rotate]
```

The endpoint handles resize the arrow. The rotation handle rotates the entire arrow around its center.

### Shift behavior

- **Shift + draw rectangle/circle:** creates a square.
- **Shift + resize rectangle/circle:** preserves the shape's existing aspect ratio while keeping the opposite corner anchored.
- **Shift + rotate rectangle/circle/arrow:** snaps the resulting angle to 15° increments.
- **Shift + draw arrow:** snaps the arrow direction to 15° increments.

Shift can be pressed or released while an operation is in progress.

## Transformation implementation

V4.3 performs rectangle/circle resizing in the annotation's local, unrotated coordinate system. This keeps the opposite corner fixed correctly even when the annotation has already been rotated.

Rotation is calculated from the actual rotation handle's starting angle, rather than assuming that the handle is aligned with the object's main axis. This is especially important for arrows because the arrow rotation handle is positioned perpendicular to the arrow.

Pointer capture is kept for the complete select/resize/rotate operation so dragging does not stop unexpectedly after the first pointer movement.

## Current limitations

- Text annotations can be moved but do not have resize/rotation handles.
- Freehand annotations can be moved but do not have resize/rotation handles.
- Arrow endpoint resizing does not currently have Shift-based length/angle constraints.
- Multi-selection is not implemented.


## JSON Save / Load

- **Save JSON** downloads the current annotations as `<pdf-name>-annotations.json`.
- **Load JSON** accepts the exported JSON format or a plain annotation array.
- JSON preserves rectangle/circle rotation, arrow endpoints, freehand points, text, colors, and line widths.
- You can load JSON before the PDF; the annotations are held in memory and applied when the PDF is opened.
- Loading JSON resets the undo/redo history to the loaded state.
