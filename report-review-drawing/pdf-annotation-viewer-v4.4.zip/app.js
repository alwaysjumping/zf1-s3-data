import * as pdfjsLib from
  "https://cdn.jsdelivr.net/npm/pdfjs-dist@6.4.299/build/pdf.min.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc =
  "https://cdn.jsdelivr.net/npm/pdfjs-dist@6.4.299/build/pdf.worker.min.mjs";

const $ = (id) => document.getElementById(id);

const viewer = $("viewer");
const pdfInput = $("pdfInput");
const pdfUrl = $("pdfUrl");
const loadUrlBtn = $("loadUrlBtn");
const jsonInput = $("jsonInput");
const statusEl = $("status");

const zoomLabel = $("zoomLabel");
const colorInput = $("color");
const lineWidthInput = $("lineWidth");

let pdfData = null;
let pdfName = "document.pdf";
let pdfDoc = null;
let zoom = 1;

let activeTool = "select";
let annotations = [];
let selected = null;

let history = [];
let historyIndex = -1;

let drawing = null;
let pendingJsonAnnotations = null;

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#ff8a8a" : "";
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function makeId() {
  return crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function pushHistory() {
  history = history.slice(0, historyIndex + 1);
  history.push(clone(annotations));
  historyIndex++;
  updateHistoryButtons();
}

function restoreHistory(index) {
  if (index < 0 || index >= history.length) return;
  annotations = clone(history[index]);
  historyIndex = index;
  selected = null;
  renderAnnotations();
  updateHistoryButtons();
}

function updateHistoryButtons() {
  $("undoBtn").disabled = historyIndex <= 0;
  $("redoBtn").disabled = historyIndex >= history.length - 1;
}

function setTool(tool) {
  activeTool = tool;

  document.querySelectorAll(".tool").forEach((button) => {
    button.classList.toggle("active", button.dataset.tool === tool);
  });

  viewer.querySelectorAll(".annotation-canvas").forEach((canvas) => {
    canvas.style.cursor = tool === "select" ? "default" : "crosshair";
  });
}

document.querySelectorAll(".tool").forEach((button) => {
  button.addEventListener("click", () => setTool(button.dataset.tool));
});

$("undoBtn").addEventListener("click", () => {
  if (historyIndex > 0) restoreHistory(historyIndex - 1);
});

$("redoBtn").addEventListener("click", () => {
  if (historyIndex < history.length - 1) restoreHistory(historyIndex + 1);
});

$("deleteBtn").addEventListener("click", () => {
  if (!selected) return;

  annotations = annotations.filter(
    (a) => !(a.page === selected.page && a.id === selected.id)
  );

  selected = null;
  pushHistory();
  renderAnnotations();
});

$("clearBtn").addEventListener("click", () => {
  if (!annotations.length) return;

  annotations = [];
  selected = null;
  pushHistory();
  renderAnnotations();
});

$("zoomInBtn").addEventListener("click", () => {
  zoom = Math.min(4, zoom + 0.1);
  renderAllPages();
});

$("zoomOutBtn").addEventListener("click", () => {
  zoom = Math.max(0.25, zoom - 0.1);
  renderAllPages();
});

$("fitBtn").addEventListener("click", async () => {
  if (!pdfDoc) return;

  const firstPage = await pdfDoc.getPage(1);
  const baseViewport = firstPage.getViewport({ scale: 1 });

  const availableWidth = viewer.clientWidth - 40;
  zoom = Math.max(0.25, Math.min(4, availableWidth / baseViewport.width));

  renderAllPages();
});

pdfInput.addEventListener("change", async () => {
  const file = pdfInput.files?.[0];
  if (!file) return;

  try {
    setStatus(`Reading ${file.name}...`);
    const bytes = await file.arrayBuffer();
    await openPdfBytes(bytes, file.name);
  } catch (error) {
    console.error(error);
    setStatus(`Could not open PDF: ${error.message}`, true);
  }
});

loadUrlBtn.addEventListener("click", loadPdfFromUrl);

pdfUrl.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    loadPdfFromUrl();
  }
});


$("saveBtn").addEventListener("click", saveAnnotationsJson);

jsonInput.addEventListener("change", async () => {
  const file = jsonInput.files?.[0];
  if (!file) return;

  try {
    await loadAnnotationsJson(file);
  } finally {
    // Allow selecting the same JSON file again.
    jsonInput.value = "";
  }
});

function saveAnnotationsJson() {
  try {
    const data = {
      format: "pdf-annotation-viewer",
      version: 1,
      exportedAt: new Date().toISOString(),
      pdf: {
        name: pdfName,
        pageCount: pdfDoc ? pdfDoc.numPages : null
      },
      annotations: clone(annotations)
    };

    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], {
      type: "application/json;charset=utf-8"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    const baseName = String(pdfName || "document.pdf")
      .replace(/\.pdf$/i, "")
      .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
      .trim() || "document";

    link.href = url;
    link.download = `${baseName}-annotations.json`;
    link.style.display = "none";

    document.body.appendChild(link);
    link.click();
    link.remove();

    setTimeout(() => URL.revokeObjectURL(url), 1000);

    setStatus(
      `Saved ${annotations.length} annotation${annotations.length === 1 ? "" : "s"} to JSON.`
    );
  } catch (error) {
    console.error("Save JSON failed:", error);
    setStatus(`Save JSON failed: ${error.message}`, true);
    alert(`Save JSON failed.\n\n${error.message}`);
  }
}

async function loadAnnotationsJson(file) {
  try {
    const text = await file.text();
    const data = JSON.parse(text);

    let loaded;

    // V4.4 format.
    if (data && Array.isArray(data.annotations)) {
      loaded = data.annotations;
    // Also accept a plain annotation array.
    } else if (Array.isArray(data)) {
      loaded = data;
    } else {
      throw new Error(
        "The JSON file does not contain an 'annotations' array."
      );
    }

    // Make a clean copy so temporary transform/drag state from another
    // session cannot leak into the loaded document.
    loaded = clone(loaded).map((annotation) => {
      delete annotation.transform;
      delete annotation.drag;
      return annotation;
    });

    const invalid = loaded.find(
      (a) => !a || !Number.isInteger(Number(a.page)) || Number(a.page) < 1
    );

    if (invalid) {
      throw new Error("One or more annotations have an invalid page number.");
    }

    if (pdfDoc) {
      const invalidPage = loaded.find(
        (a) => Number(a.page) > pdfDoc.numPages
      );

      if (invalidPage) {
        throw new Error(
          `The JSON contains an annotation for page ${invalidPage.page}, ` +
          `but the current PDF only has ${pdfDoc.numPages} page(s).`
        );
      }

      annotations = loaded;
      selected = null;
      drawing = null;

      history = [];
      historyIndex = -1;
      pushHistory();

      renderAnnotations();

      setStatus(
        `Loaded ${annotations.length} annotation${annotations.length === 1 ? "" : "s"} from JSON.`
      );
    } else {
      // Keep the annotations until the user opens a PDF.
      pendingJsonAnnotations = loaded;
      annotations = loaded;
      selected = null;
      drawing = null;

      history = [];
      historyIndex = -1;
      pushHistory();

      setStatus(
        `Loaded ${loaded.length} annotation${loaded.length === 1 ? "" : "s"} into memory. ` +
        `Now open the corresponding PDF.`
      );
    }
  } catch (error) {
    console.error("Load JSON failed:", error);
    setStatus(`Load JSON failed: ${error.message}`, true);
    alert(`Could not load annotation JSON.\n\n${error.message}`);
  }
}

async function loadPdfFromUrl() {
  const rawUrl = pdfUrl.value.trim();

  if (!rawUrl) {
    setStatus("Please enter a PDF URL.", true);
    return;
  }

  let url;

  try {
    url = new URL(rawUrl);
  } catch {
    setStatus("The PDF URL is not valid.", true);
    return;
  }

  if (!["http:", "https:"].includes(url.protocol)) {
    setStatus("Only HTTP and HTTPS PDF URLs are supported.", true);
    return;
  }

  try {
    loadUrlBtn.disabled = true;
    setStatus(`Downloading PDF from ${url.href}...`);

    const response = await fetch(url.href);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status} ${response.statusText}`);
    }

    const contentType = response.headers.get("content-type") || "";

    if (
      !contentType.includes("pdf") &&
      !url.pathname.toLowerCase().endsWith(".pdf")
    ) {
      console.warn("The server did not return an obvious PDF content type.");
    }

    const bytes = await response.arrayBuffer();

    if (!bytes.byteLength) {
      throw new Error("The downloaded PDF is empty.");
    }

    const fileName = getFileNameFromUrl(url);
    await openPdfBytes(bytes, fileName);
  } catch (error) {
    console.error(error);

    let message = `Could not load PDF URL: ${error.message}`;

    if (
      error instanceof TypeError &&
      /fetch/i.test(error.message)
    ) {
      message +=
        " This may be a CORS or network restriction. The remote server must allow browser requests.";
    }

    setStatus(message, true);
  } finally {
    loadUrlBtn.disabled = false;
  }
}

function getFileNameFromUrl(url) {
  const pathname = decodeURIComponent(url.pathname);
  const name = pathname.split("/").filter(Boolean).pop();

  if (name && name.toLowerCase().endsWith(".pdf")) {
    return name;
  }

  return "remote-document.pdf";
}

async function openPdfBytes(bytes, name) {
  setStatus("Loading PDF pages...");

  pdfData = new Uint8Array(bytes);
  pdfName = name || "document.pdf";

  pdfDoc = await pdfjsLib.getDocument({
    data: pdfData
  }).promise;

  if (pendingJsonAnnotations) {
    const invalidPage = pendingJsonAnnotations.find(
      (a) => Number(a.page) > pdfDoc.numPages
    );

    if (invalidPage) {
      setStatus(
        `PDF has ${pdfDoc.numPages} page(s), but the JSON contains page ${invalidPage.page}.`,
        true
      );
      annotations = [];
      pendingJsonAnnotations = null;
    } else {
      annotations = clone(pendingJsonAnnotations);
      pendingJsonAnnotations = null;
    }
  } else {
    annotations = [];
  }

  selected = null;
  history = [];
  historyIndex = -1;
  pushHistory();

  await renderAllPages();

  setStatus(
    `Loaded ${pdfName} — ${pdfDoc.numPages} page${pdfDoc.numPages === 1 ? "" : "s"}`
  );
}

async function renderAllPages() {
  if (!pdfDoc) return;

  viewer.innerHTML = "";
  zoomLabel.textContent = `${Math.round(zoom * 100)}%`;

  for (let pageNumber = 1; pageNumber <= pdfDoc.numPages; pageNumber++) {
    await renderPage(pageNumber);
  }
}

async function renderPage(pageNumber) {
  const pdfPage = await pdfDoc.getPage(pageNumber);
  const viewport = pdfPage.getViewport({ scale: zoom });

  const dpr = window.devicePixelRatio || 1;

  const pageEl = document.createElement("div");
  pageEl.className = "page";
  pageEl.dataset.page = pageNumber;

  pageEl.style.width = `${viewport.width}px`;
  pageEl.style.height = `${viewport.height}px`;

  const pdfCanvas = document.createElement("canvas");
  pdfCanvas.className = "pdf-canvas";

  const annotationCanvas = document.createElement("canvas");
  annotationCanvas.className = "annotation-canvas";

  const label = document.createElement("div");
  label.className = "page-label";
  label.textContent = `Page ${pageNumber}`;

  pageEl.append(pdfCanvas, annotationCanvas, label);
  viewer.appendChild(pageEl);

  pdfCanvas.width = Math.ceil(viewport.width * dpr);
  pdfCanvas.height = Math.ceil(viewport.height * dpr);

  annotationCanvas.width = Math.ceil(viewport.width * dpr);
  annotationCanvas.height = Math.ceil(viewport.height * dpr);

  pdfCanvas.style.width = `${viewport.width}px`;
  pdfCanvas.style.height = `${viewport.height}px`;

  annotationCanvas.style.width = `${viewport.width}px`;
  annotationCanvas.style.height = `${viewport.height}px`;

  const pdfContext = pdfCanvas.getContext("2d");

  await pdfPage.render({
    canvasContext: pdfContext,
    viewport,
    transform: [dpr, 0, 0, dpr, 0, 0]
  }).promise;

  annotationCanvas.getContext("2d").setTransform(
    dpr, 0, 0, dpr, 0, 0
  );

  attachPointerEvents(pageEl, annotationCanvas, pageNumber);
  drawAnnotationsForPage(pageNumber);
}

function attachPointerEvents(pageEl, canvas, pageNumber) {
  canvas.addEventListener("pointerdown", (event) => {
    const point = eventToNormalizedPoint(event, canvas);

    if (activeTool === "select") {
      const currentSelected = selected
        ? annotations.find(
            (a) => a.page === selected.page && a.id === selected.id
          )
        : null;

      if (
        currentSelected &&
        ["rect", "circle", "arrow"].includes(currentSelected.type)
      ) {
        const handle = hitTestHandle(currentSelected, point);

        if (handle) {
          const transform = {
            mode: handle.type,
            handle: handle.name,
            start: point,
            original: clone(currentSelected),
            changed: false
          };

          if (handle.type === "rotate") {
            const center = getAnnotationCenter(currentSelected);
            transform.startAngle = Math.atan2(
              handle.y - center.y,
              handle.x - center.x
            );
          }

          currentSelected.transform = transform;

          canvas.setPointerCapture(event.pointerId);
          renderAnnotations();
          return;
        }
      }

      const hit = hitTest(pageNumber, point);

      selected = hit
        ? { page: pageNumber, id: hit.id }
        : null;

      if (hit) {
        hit.drag = {
          start: point,
          original: clone(hit),
          changed: false
        };
      }

      renderAnnotations();
      canvas.setPointerCapture(event.pointerId);
      return;
    }

    if (activeTool === "text") {
      const text = window.prompt("Enter annotation text:", "Text");
      if (text === null || text === "") return;

      annotations.push({
        id: makeId(),
        page: pageNumber,
        type: "text",
        x: point.x,
        y: point.y,
        text,
        color: colorInput.value,
        lineWidth: Number(lineWidthInput.value)
      });

      pushHistory();
      renderAnnotations();
      return;
    }

    drawing = {
      page: pageNumber,
      type: activeTool,
      start: point,
      points: [point]
    };

    canvas.setPointerCapture(event.pointerId);
  });

  canvas.addEventListener("pointermove", (event) => {
    const point = eventToNormalizedPoint(event, canvas);

    if (activeTool === "select" && selected) {
      const selectedAnnotation = annotations.find(
        (a) => a.page === selected.page && a.id === selected.id
      );

      if (!selectedAnnotation) return;

      if (selectedAnnotation.transform) {
        transformAnnotation(selectedAnnotation, point, event.shiftKey);

        if (
          selectedAnnotation.transform &&
          selectedAnnotation.transform.changed
        ) {
          renderAnnotations();
        }

        return;
      }

      if (selectedAnnotation.drag) {
        const dx = point.x - selectedAnnotation.drag.start.x;
        const dy = point.y - selectedAnnotation.drag.start.y;

        moveAnnotation(
          selectedAnnotation,
          selectedAnnotation.drag.original,
          dx,
          dy
        );

        selectedAnnotation.drag.changed =
          Math.abs(dx) > 0.0005 || Math.abs(dy) > 0.0005;

        renderAnnotations();
      }

      return;
    }

    if (!drawing || drawing.page !== pageNumber) return;

    if (drawing.type === "freehand") {
      drawing.points.push(point);
    } else {
      drawing.current = constrainDrawingPoint(
        drawing.start,
        point,
        drawing.type,
        event.shiftKey
      );
    }

    renderAnnotations();
  });

  canvas.addEventListener("pointerup", (event) => {
    if (activeTool === "select" && selected) {
      const selectedAnnotation = annotations.find(
        (a) => a.page === selected.page && a.id === selected.id
      );

      if (!selectedAnnotation) return;

      if (selectedAnnotation.transform) {
        const changed = selectedAnnotation.transform.changed;
        delete selectedAnnotation.transform;

        if (changed) {
          pushHistory();
        }

        renderAnnotations();

        if (canvas.hasPointerCapture(event.pointerId)) {
          canvas.releasePointerCapture(event.pointerId);
        }

        return;
      }

      if (selectedAnnotation.drag) {
        const changed = selectedAnnotation.drag.changed;
        delete selectedAnnotation.drag;

        if (changed) {
          pushHistory();
        }

        renderAnnotations();
      }

      return;
    }

    if (!drawing || drawing.page !== pageNumber) return;

    const point = eventToNormalizedPoint(event, canvas);

    if (drawing.type === "freehand") {
      drawing.points.push(point);
    } else {
      drawing.current = constrainDrawingPoint(
        drawing.start,
        point,
        drawing.type,
        event.shiftKey
      );
    }

    const annotation = createAnnotationFromDrawing(drawing);

    if (annotation) {
      annotations.push(annotation);
      pushHistory();
    }

    drawing = null;
    renderAnnotations();

    if (canvas.hasPointerCapture(event.pointerId)) {
      canvas.releasePointerCapture(event.pointerId);
    }
  });

  canvas.addEventListener("pointercancel", (event) => {
    if (selected) {
      const annotation = annotations.find(
        (a) => a.page === selected.page && a.id === selected.id
      );

      if (annotation) {
        delete annotation.transform;
        delete annotation.drag;
      }
    }

    drawing = null;
    renderAnnotations();

    if (canvas.hasPointerCapture(event.pointerId)) {
      canvas.releasePointerCapture(event.pointerId);
    }
  });
}

function hitTestHandle(annotation, point) {
  if (!["rect", "circle", "arrow"].includes(annotation.type)) {
    return null;
  }

  const handles = getTransformHandles(annotation);

  for (const handle of handles) {
    const distance = Math.hypot(
      point.x - handle.x,
      point.y - handle.y
    );

    if (distance <= handle.radius) {
      return handle;
    }
  }

  return null;
}

function getTransformHandles(a) {
  if (a.type === "arrow") {
    const x1 = a.x1;
    const y1 = a.y1;
    const x2 = a.x2;
    const y2 = a.y2;

    const cx = (x1 + x2) / 2;
    const cy = (y1 + y2) / 2;

    const dx = x2 - x1;
    const dy = y2 - y1;
    const length = Math.hypot(dx, dy) || 0.001;

    const nx = -dy / length;
    const ny = dx / length;

    const rotationDistance = 0.07;

    return [
      { name: "start", type: "resize", x: x1, y: y1, radius: 0.018 },
      { name: "end", type: "resize", x: x2, y: y2, radius: 0.018 },
      {
        name: "rotate",
        type: "rotate",
        x: cx + nx * rotationDistance,
        y: cy + ny * rotationDistance,
        radius: 0.022
      }
    ];
  }

  const rotation = a.rotation || 0;
  const cx = a.x + a.w / 2;
  const cy = a.y + a.h / 2;

  const localCorners = [
    { name: "nw", x: -a.w / 2, y: -a.h / 2 },
    { name: "ne", x: a.w / 2, y: -a.h / 2 },
    { name: "se", x: a.w / 2, y: a.h / 2 },
    { name: "sw", x: -a.w / 2, y: a.h / 2 }
  ];

  const handles = localCorners.map((corner) => {
    const p = rotatePoint(
      cx,
      cy,
      cx + corner.x,
      cy + corner.y,
      rotation
    );

    return {
      name: corner.name,
      type: "resize",
      x: p.x,
      y: p.y,
      radius: 0.018
    };
  });

  const topCenter = rotatePoint(
    cx,
    cy,
    cx,
    cy - a.h / 2,
    rotation
  );

  const rotationDistance = 0.07;

  const dx = topCenter.x - cx;
  const dy = topCenter.y - cy;
  const distance = Math.hypot(dx, dy) || 0.001;

  handles.push({
    name: "rotate",
    type: "rotate",
    x: topCenter.x + (dx / distance) * rotationDistance,
    y: topCenter.y + (dy / distance) * rotationDistance,
    radius: 0.022
  });

  return handles;
}

function transformAnnotation(a, currentPoint, shiftKey = false) {
  const transform = a.transform;

  if (!transform) return;

  if (transform.mode === "rotate") {
    rotateAnnotation(
      a,
      transform.original,
      currentPoint,
      shiftKey,
      transform.startAngle
    );
    transform.changed = true;
    return;
  }

  if (transform.mode === "resize") {
    resizeAnnotation(
      a,
      transform.original,
      transform.handle,
      currentPoint,
      shiftKey
    );

    transform.changed = true;
  }
}

function getAnnotationCenter(a) {
  if (a.type === "arrow") {
    return {
      x: (a.x1 + a.x2) / 2,
      y: (a.y1 + a.y2) / 2
    };
  }

  return {
    x: a.x + a.w / 2,
    y: a.y + a.h / 2
  };
}

function rotateAnnotation(a, original, point, snap = false, startAngle = null) {
  const center = getAnnotationCenter(original);

  const currentAngle = Math.atan2(
    point.y - center.y,
    point.x - center.x
  );

  // The rotation handle is not necessarily aligned with the object itself.
  // Measure the user's movement from the handle's actual starting angle.
  const initialHandleAngle = Number.isFinite(startAngle)
    ? startAngle
    : currentAngle;

  const delta = normalizeAngle(currentAngle - initialHandleAngle);

  if (original.type === "arrow") {
    const originalAngle = Math.atan2(
      original.y2 - original.y1,
      original.x2 - original.x1
    );

    let nextAngle = originalAngle + delta;

    if (snap) {
      nextAngle = snapAngle(nextAngle, Math.PI / 12);
    }

    const length = Math.hypot(
      original.x2 - original.x1,
      original.y2 - original.y1
    );

    const half = length / 2;

    a.x1 = center.x - Math.cos(nextAngle) * half;
    a.y1 = center.y - Math.sin(nextAngle) * half;
    a.x2 = center.x + Math.cos(nextAngle) * half;
    a.y2 = center.y + Math.sin(nextAngle) * half;
    return;
  }

  let nextRotation = (original.rotation || 0) + delta;

  if (snap) {
    nextRotation = snapAngle(nextRotation, Math.PI / 12);
  }

  a.rotation = normalizeAngle(nextRotation);
}

function resizeAnnotation(a, original, handleName, point, lockAspect = false) {
  if (original.type === "arrow") {
    if (handleName === "start") {
      a.x1 = point.x;
      a.y1 = point.y;
    } else if (handleName === "end") {
      a.x2 = point.x;
      a.y2 = point.y;
    }

    return;
  }

  const rotation = original.rotation || 0;
  const centerX = original.x + original.w / 2;
  const centerY = original.y + original.h / 2;

  // Convert the pointer from page coordinates into the annotation's local,
  // unrotated coordinate system. This makes resizing independent of rotation.
  const local = rotatePoint(
    centerX,
    centerY,
    point.x,
    point.y,
    -rotation
  );

  const px = local.x - centerX;
  const py = local.y - centerY;

  const halfW = original.w / 2;
  const halfH = original.h / 2;

  const oppositeByHandle = {
    nw: { x: halfW, y: halfH },
    ne: { x: -halfW, y: halfH },
    se: { x: -halfW, y: -halfH },
    sw: { x: halfW, y: -halfH }
  };

  const opposite = oppositeByHandle[handleName];
  if (!opposite) return;

  let dx = px - opposite.x;
  let dy = py - opposite.y;

  const minSize = 0.01;

  if (lockAspect) {
    // Preserve the original aspect ratio and keep the opposite corner fixed.
    // Choose the dimension that best follows the pointer in relative terms.
    const ratio = original.w / Math.max(original.h, minSize);
    const widthDominates =
      Math.abs(dx) / Math.max(original.w, minSize) >=
      Math.abs(dy) / Math.max(original.h, minSize);

    if (widthDominates) {
      const width = Math.max(Math.abs(dx), minSize);
      const height = Math.max(width / ratio, minSize);
      dx = Math.sign(dx || 1) * width;
      dy = Math.sign(dy || 1) * height;
    } else {
      const height = Math.max(Math.abs(dy), minSize);
      const width = Math.max(height * ratio, minSize);
      dx = Math.sign(dx || 1) * width;
      dy = Math.sign(dy || 1) * height;
    }
  } else {
    if (Math.abs(dx) < minSize) dx = Math.sign(dx || 1) * minSize;
    if (Math.abs(dy) < minSize) dy = Math.sign(dy || 1) * minSize;
  }

  const dragged = {
    x: opposite.x + dx,
    y: opposite.y + dy
  };

  const left = Math.min(opposite.x, dragged.x);
  const right = Math.max(opposite.x, dragged.x);
  const top = Math.min(opposite.y, dragged.y);
  const bottom = Math.max(opposite.y, dragged.y);

  const newWidth = Math.max(right - left, minSize);
  const newHeight = Math.max(bottom - top, minSize);

  const localCenterX = (left + right) / 2;
  const localCenterY = (top + bottom) / 2;

  // Rotate the new center back into page coordinates. The opposite corner
  // therefore remains anchored even for a rotated annotation.
  const newCenter = rotatePoint(
    centerX,
    centerY,
    centerX + localCenterX,
    centerY + localCenterY,
    rotation
  );

  a.w = newWidth;
  a.h = newHeight;
  a.x = newCenter.x - newWidth / 2;
  a.y = newCenter.y - newHeight / 2;
}

function rotatePoint(cx, cy, x, y, angle) {
  const cos = Math.cos(angle);
  const sin = Math.sin(angle);

  const dx = x - cx;
  const dy = y - cy;

  return {
    x: cx + dx * cos - dy * sin,
    y: cy + dx * sin + dy * cos
  };
}

function snapAngle(angle, increment) {
  return Math.round(angle / increment) * increment;
}

function normalizeAngle(angle) {
  while (angle > Math.PI) angle -= Math.PI * 2;
  while (angle < -Math.PI) angle += Math.PI * 2;
  return angle;
}

function eventToNormalizedPoint(event, canvas) {
  const rect = canvas.getBoundingClientRect();

  return {
    x: Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width)),
    y: Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height))
  };
}

function constrainDrawingPoint(start, point, type, shiftKey) {
  if (!shiftKey || type === "freehand" || type === "text") {
    return point;
  }

  const dx = point.x - start.x;
  const dy = point.y - start.y;

  if (type === "rect" || type === "circle") {
    const size = Math.max(Math.abs(dx), Math.abs(dy));

    return {
      x: start.x + (dx < 0 ? -size : size),
      y: start.y + (dy < 0 ? -size : size)
    };
  }

  if (type === "arrow") {
    const length = Math.hypot(dx, dy);
    if (length < 0.0001) return point;

    const angle = snapAngle(Math.atan2(dy, dx), Math.PI / 12);

    return {
      x: start.x + Math.cos(angle) * length,
      y: start.y + Math.sin(angle) * length
    };
  }

  return point;
}

function createAnnotationFromDrawing(d) {
  const end = d.current || d.points.at(-1);

  if (d.type === "freehand") {
    if (d.points.length < 2) return null;

    return {
      id: makeId(),
      page: d.page,
      type: "freehand",
      points: d.points,
      color: colorInput.value,
      lineWidth: Number(lineWidthInput.value)
    };
  }

  if (!end) return null;

  const dx = end.x - d.start.x;
  const dy = end.y - d.start.y;

  if (Math.hypot(dx, dy) < 0.005) {
    return null;
  }

  if (d.type === "rect") {
    return {
      id: makeId(),
      page: d.page,
      type: "rect",
      x: Math.min(d.start.x, end.x),
      y: Math.min(d.start.y, end.y),
      w: Math.abs(dx),
      h: Math.abs(dy),
      rotation: 0,
      color: colorInput.value,
      lineWidth: Number(lineWidthInput.value)
    };
  }

  if (d.type === "circle") {
    return {
      id: makeId(),
      page: d.page,
      type: "circle",
      x: Math.min(d.start.x, end.x),
      y: Math.min(d.start.y, end.y),
      w: Math.abs(dx),
      h: Math.abs(dy),
      rotation: 0,
      color: colorInput.value,
      lineWidth: Number(lineWidthInput.value)
    };
  }

  if (d.type === "arrow") {
    return {
      id: makeId(),
      page: d.page,
      type: "arrow",
      x1: d.start.x,
      y1: d.start.y,
      x2: end.x,
      y2: end.y,
      color: colorInput.value,
      lineWidth: Number(lineWidthInput.value)
    };
  }

  return null;
}

function moveAnnotation(annotation, original, dx, dy) {
  if (annotation.type === "rect" || annotation.type === "circle") {
    annotation.x = original.x + dx;
    annotation.y = original.y + dy;
  }

  if (annotation.type === "text") {
    annotation.x = original.x + dx;
    annotation.y = original.y + dy;
  }

  if (annotation.type === "arrow") {
    annotation.x1 = original.x1 + dx;
    annotation.y1 = original.y1 + dy;
    annotation.x2 = original.x2 + dx;
    annotation.y2 = original.y2 + dy;
  }

  if (annotation.type === "freehand") {
    annotation.points = original.points.map((p) => ({
      x: p.x + dx,
      y: p.y + dy
    }));
  }
}

function hitTest(pageNumber, point) {
  const pageAnnotations = annotations.filter(
    (a) => a.page === pageNumber
  );

  for (let i = pageAnnotations.length - 1; i >= 0; i--) {
    const a = pageAnnotations[i];

    if (a.type === "rect" || a.type === "circle") {
      const cx = a.x + a.w / 2;
      const cy = a.y + a.h / 2;

      const local = rotatePoint(
        cx,
        cy,
        point.x,
        point.y,
        -(a.rotation || 0)
      );

      if (
        local.x >= a.x &&
        local.x <= a.x + a.w &&
        local.y >= a.y &&
        local.y <= a.y + a.h
      ) {
        return a;
      }
    }

    if (a.type === "text") {
      const width = Math.max(0.06, a.text.length * 0.012);
      const height = 0.035;

      if (
        point.x >= a.x &&
        point.x <= a.x + width &&
        point.y >= a.y - height &&
        point.y <= a.y + height
      ) {
        return a;
      }
    }

    if (a.type === "arrow") {
      if (distanceToSegment(
        point.x,
        point.y,
        a.x1,
        a.y1,
        a.x2,
        a.y2
      ) < 0.02) {
        return a;
      }
    }

    if (a.type === "freehand") {
      for (let j = 1; j < a.points.length; j++) {
        const p1 = a.points[j - 1];
        const p2 = a.points[j];

        if (
          distanceToSegment(
            point.x,
            point.y,
            p1.x,
            p1.y,
            p2.x,
            p2.y
          ) < 0.02
        ) {
          return a;
        }
      }
    }
  }

  return null;
}

function distanceToSegment(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1;
  const dy = y2 - y1;

  if (dx === 0 && dy === 0) {
    return Math.hypot(px - x1, py - y1);
  }

  const t = Math.max(
    0,
    Math.min(
      1,
      ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)
    )
  );

  const x = x1 + t * dx;
  const y = y1 + t * dy;

  return Math.hypot(px - x, py - y);
}

function renderAnnotations() {
  for (const pageEl of viewer.querySelectorAll(".page")) {
    drawAnnotationsForPage(Number(pageEl.dataset.page));
  }

  if (drawing) {
    drawInProgressShape(drawing);
  }
}

function drawInProgressShape(d) {
  const pageEl = viewer.querySelector(
    `.page[data-page="${d.page}"]`
  );

  if (!pageEl) return;

  const canvas = pageEl.querySelector(".annotation-canvas");
  const ctx = canvas.getContext("2d");
  const rect = canvas.getBoundingClientRect();

  const end = d.current || d.points.at(-1);
  if (!end) return;

  const temp = createAnnotationFromDrawing(d);
  if (!temp) return;

  ctx.save();
  drawAnnotation(ctx, temp, rect.width, rect.height);
  ctx.restore();
}

function drawAnnotationsForPage(pageNumber) {
  const pageEl = viewer.querySelector(
    `.page[data-page="${pageNumber}"]`
  );

  if (!pageEl) return;

  const canvas = pageEl.querySelector(".annotation-canvas");
  const ctx = canvas.getContext("2d");

  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;

  // The backing canvas is DPR-scaled. Clear it in device pixels,
  // then restore the CSS-pixel coordinate system used by annotations.
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  const pageAnnotations = annotations.filter(
    (a) => a.page === pageNumber
  );

  for (const annotation of pageAnnotations) {
    drawAnnotation(ctx, annotation, rect.width, rect.height);

    if (
      selected &&
      selected.page === annotation.page &&
      selected.id === annotation.id
    ) {
      drawSelection(ctx, annotation, rect.width, rect.height);
    }
  }
}

function drawAnnotation(ctx, a, width, height) {
  ctx.save();
  ctx.strokeStyle = a.color || "#ff0000";
  ctx.fillStyle = a.color || "#ff0000";
  ctx.lineWidth = a.lineWidth || 2;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  if (a.type === "rect" || a.type === "circle") {
    const cx = (a.x + a.w / 2) * width;
    const cy = (a.y + a.h / 2) * height;
    const rotation = a.rotation || 0;

    ctx.translate(cx, cy);
    ctx.rotate(rotation);

    if (a.type === "rect") {
      ctx.strokeRect(
        -(a.w * width) / 2,
        -(a.h * height) / 2,
        a.w * width,
        a.h * height
      );
    } else {
      ctx.beginPath();

      ctx.ellipse(
        0,
        0,
        Math.abs(a.w * width / 2),
        Math.abs(a.h * height / 2),
        0,
        0,
        Math.PI * 2
      );

      ctx.stroke();
    }

    ctx.restore();
    return;
  }

  if (a.type === "arrow") {
    drawArrow(
      ctx,
      a.x1 * width,
      a.y1 * height,
      a.x2 * width,
      a.y2 * height
    );

    ctx.restore();
    return;
  }

  if (a.type === "freehand") {
    if (a.points.length >= 2) {
      ctx.beginPath();
      ctx.moveTo(
        a.points[0].x * width,
        a.points[0].y * height
      );

      for (const p of a.points.slice(1)) {
        ctx.lineTo(p.x * width, p.y * height);
      }

      ctx.stroke();
    }

    ctx.restore();
    return;
  }

  if (a.type === "text") {
    const fontSize = Math.max(12, Math.round(width * 0.018));

    ctx.font = `${fontSize}px Arial`;
    ctx.textBaseline = "middle";
    ctx.fillText(
      a.text,
      a.x * width,
      a.y * height
    );
  }

  ctx.restore();
}

function drawArrow(ctx, x1, y1, x2, y2) {
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const headLength = 12;

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(
    x2 - headLength * Math.cos(angle - Math.PI / 6),
    y2 - headLength * Math.sin(angle - Math.PI / 6)
  );
  ctx.lineTo(
    x2 - headLength * Math.cos(angle + Math.PI / 6),
    y2 - headLength * Math.sin(angle + Math.PI / 6)
  );
  ctx.closePath();
  ctx.fill();
}

function drawSelection(ctx, a, width, height) {
  if (!["rect", "circle", "arrow"].includes(a.type)) {
    drawSimpleSelection(ctx, a, width, height);
    return;
  }

  ctx.save();

  ctx.strokeStyle = "#0066ff";
  ctx.fillStyle = "#ffffff";
  ctx.lineWidth = 1;
  ctx.setLineDash([5, 4]);

  if (a.type === "arrow") {
    const x1 = a.x1 * width;
    const y1 = a.y1 * height;
    const x2 = a.x2 * width;
    const y2 = a.y2 * height;

    const cx = (x1 + x2) / 2;
    const cy = (y1 + y2) / 2;

    const dx = x2 - x1;
    const dy = y2 - y1;
    const length = Math.hypot(dx, dy) || 1;

    const nx = -dy / length;
    const ny = dx / length;

    const rx = cx + nx * 0.07 * width;
    const ry = cy + ny * 0.07 * height;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    ctx.setLineDash([]);

    drawHandle(ctx, x1, y1, 5);
    drawHandle(ctx, x2, y2, 5);
    drawRotationHandle(ctx, cx, cy, rx, ry);

    ctx.restore();
    return;
  }

  const rotation = a.rotation || 0;

  const cx = (a.x + a.w / 2) * width;
  const cy = (a.y + a.h / 2) * height;

  const localCorners = [
    [-a.w / 2, -a.h / 2],
    [a.w / 2, -a.h / 2],
    [a.w / 2, a.h / 2],
    [-a.w / 2, a.h / 2]
  ];

  const corners = localCorners.map(([x, y]) => {
    return rotatePoint(
      cx,
      cy,
      cx + x * width,
      cy + y * height,
      rotation
    );
  });

  ctx.beginPath();
  ctx.moveTo(corners[0].x, corners[0].y);

  for (const p of corners.slice(1)) {
    ctx.lineTo(p.x, p.y);
  }

  ctx.closePath();
  ctx.stroke();

  ctx.setLineDash([]);

  for (const p of corners) {
    drawHandle(ctx, p.x, p.y, 5);
  }

  const top = rotatePoint(
    cx,
    cy,
    cx,
    cy - a.h * height / 2,
    rotation
  );

  const rotationDistance = 0.07 * Math.min(width, height);

  const dx = top.x - cx;
  const dy = top.y - cy;
  const distance = Math.hypot(dx, dy) || 1;

  const rx = top.x + (dx / distance) * rotationDistance;
  const ry = top.y + (dy / distance) * rotationDistance;

  ctx.beginPath();
  ctx.moveTo(top.x, top.y);
  ctx.lineTo(rx, ry);
  ctx.stroke();

  drawRotationHandle(ctx, top.x, top.y, rx, ry);

  ctx.restore();
}

function drawSimpleSelection(ctx, a, width, height) {
  ctx.save();

  ctx.strokeStyle = "#0066ff";
  ctx.lineWidth = 1;
  ctx.setLineDash([5, 4]);

  let x = 0;
  let y = 0;
  let w = 0;
  let h = 0;

  if (a.type === "text") {
    x = a.x * width;
    y = (a.y - 0.025) * height;
    w = Math.max(50, a.text.length * 9);
    h = 28;
  }

  if (a.type === "freehand") {
    const xs = a.points.map((p) => p.x);
    const ys = a.points.map((p) => p.y);

    x = Math.min(...xs) * width - 6;
    y = Math.min(...ys) * height - 6;
    w = (Math.max(...xs) - Math.min(...xs)) * width + 12;
    h = (Math.max(...ys) - Math.min(...ys)) * height + 12;
  }

  ctx.strokeRect(x, y, w, h);
  ctx.restore();
}

function drawHandle(ctx, x, y, radius) {
  ctx.beginPath();
  ctx.rect(
    x - radius,
    y - radius,
    radius * 2,
    radius * 2
  );
  ctx.fill();
  ctx.stroke();
}

function drawRotationHandle(ctx, x1, y1, x2, y2) {
  ctx.beginPath();
  ctx.arc(x2, y2, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}
