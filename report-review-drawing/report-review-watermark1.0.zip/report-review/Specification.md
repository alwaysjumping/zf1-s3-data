# Report Review Drawing Test Project — Version 1 Specification

## 1. Purpose

Build a small standalone test project for drawing review annotations on a PDF report, saving the drawing data to MariaDB/MySQL, and viewing the saved drawings in a read-only page.

The project uses pure PHP 7.4, PDO, MariaDB/MySQL, HTML, CSS, and JavaScript. It does not depend on ZF1 or another PHP framework.

Version 1 has exactly two user-facing pages:

1. **Edit Review Drawings** (`edit.php`).
2. **View Review Drawings** (`view.php`).

This version is for testing by one person using one active edit tab at a time. Simultaneous editing and revision-conflict handling are outside the test scope.

The sample document is `pdfs/test_report.pdf`. Its title and author are static sample values.

## 2. Confirmed Requirements

| Item | Requirement |
| --- | --- |
| Backend | Pure PHP 7.4 |
| Database | MariaDB/MySQL through PDO |
| Document | `pdfs/test_report.pdf` |
| Layout | Left information panel and right document panel |
| Divider | User can resize panel widths |
| Metadata | Static document title and author |
| Editing | Draw and annotate over PDF pages on Page 1 |
| Saving | Explicit Save button persists drawings to the database |
| Viewing | Page 2 loads saved drawings and provides no editing controls |
| Navigation | Continuous page scrolling and zoom |
| Alignment | Drawings stay attached to their PDF page during zoom and scrolling |
| Original PDF download | Browser must not receive the original PDF bytes or a usable PDF download URL |

## 3. Original PDF Download Protection

### 3.1 Required architecture

The server must render the PDF into individual raster page images. The browser displays these images with an SVG drawing overlay over each page.

**PDF.js rendering in the browser is excluded from this version's protected design**, because it requires delivering PDF bytes to the browser. Hiding a download button cannot meet the original PDF download requirement.

The logical source path remains `pdfs/test_report.pdf`, but that directory is outside the public web root. The browser must not be able to request it directly.

Example deployment layout:

```text
report-review-test/
  config/
    database.php
  pdfs/
    test_report.pdf
  cache/
    rendered-pages/
  src/
    Database.php
    ReportService.php
    PageRenderer.php
    AnnotationService.php
    AccessGuard.php
  sql/
    database.sql
  public/
    edit.php
    view.php
    api/
      report-info.php
      page-image.php
      drawing-load.php
      drawing-save.php
    assets/
      review.css
      review.js
      drawings.js
  README.md
```

Only `public/` is exposed by Apache/Nginx or the PHP development server. PDF sources, configuration, rendered-page caches, and backend classes remain private.

### 3.2 Server controls

- No PDF download, export, print, or original-file endpoint.
- No public PDF URL, symbolic link, or static alias to the private PDF directory.
- Page-image responses contain image bytes only, never the PDF bytes.
- A session-based access guard checks every metadata, page-image, drawing-load, and drawing-save request.
- Access checks include permission for the requested report. Guessing a report ID must not grant access.
- Reject unsupported page numbers and image resolutions; do not accept arbitrary filenames or filesystem paths from the client.
- Serve images with `Cache-Control: private, no-store` and `X-Content-Type-Options: nosniff`.
- Source filenames and private paths are not returned in API errors.
- Keep generated images in a private cache and stream them through the protected endpoint.

For the standalone test, use a server-configured test access password to establish a PHP session. Each of the two pages may show an inline access form before displaying the report. This keeps the project at two user-facing pages. The form must not grant access automatically merely because a visitor opened the page. Store a password hash in private configuration, regenerate the session ID after successful access, and use CSRF protection for the access form and drawing save operation. Production integration will replace this test guard with application authentication and report permissions.

### 3.3 Browser controls and limits

The viewer has no download or print buttons. Disable image dragging and the document-area context menu as optional deterrents. A print stylesheet may hide the report content.

Do not describe these browser measures as security controls. Developer tools cannot reliably be disabled. Blocking F12 or keyboard shortcuts does not prevent inspection or downloading content already delivered to the browser.

**Protection guarantee:** the application does not expose the original PDF file to the browser. It cannot prevent screenshots, photography, saving page images, or reconstruction of a new document from displayed images. Absolute prevention of all copying is outside what a browser viewer can provide.

## 4. Page 1 — Edit Review Drawings

### 4.1 Left panel

Display these static sample values:

| Field | Sample value |
| --- | --- |
| Document title | Monthly Test Report |
| Author | John Smith |

Provide a **Save** button and a status area. The status area shows loading, unsaved changes, saving, save success, or a useful error.

The Save button is unavailable until document metadata and existing drawing data have loaded successfully. If existing drawings cannot be loaded, do not allow a save that might overwrite them.

### 4.2 Right panel

Display every PDF page in order as server-rendered page images. Each page has its own overlay, matching the image's displayed dimensions.

Provide a compact toolbar with:

- Freehand pen.
- Rectangle.
- Arrow.
- Text annotation.
- Delete a selected drawing.
- Drawing color and line width.
- Undo for local editing operations.
- Zoom selection: 75%, 100%, 125%, 150%, and 200%.

The right panel scrolls independently. Dragging on a page with a drawing tool must not drag the underlying image. Text input must preserve Unicode and must be rendered as text, never as executable HTML.

All edits are local until Save succeeds. Undo and deletion are persisted on the next Save. Warn before leaving the edit page with unsaved changes.

### 4.3 Save behavior

1. Finish the active stroke before saving.
2. Submit the full drawing snapshot with the report ID, document content hash, and data format version.
3. Validate access, CSRF token, payload structure, size, page references, coordinates, and text lengths on the server.
4. Save the complete snapshot in a database transaction using a prepared statement.
5. Return success only after the transaction commits.
6. Mark the editor clean only for the snapshot actually saved. If additional local edits occurred while saving, they remain unsaved.
7. On failure, retain local drawings and display an error. Do not show a success message.

Saving an empty drawing list must remove previously saved drawings for the report. Disable Save while a request is in progress to prevent overlapping submissions from the active edit tab.

## 5. Page 2 — View Review Drawings

Use the same metadata, two-panel layout, divider, page ordering, zoom control, and scrolling behavior as Page 1.

Display saved drawings over their associated page images. If there is no saved row, show the document normally with no drawings.

Do not display Save, drawing tools, delete, or Undo controls. Overlay elements must not accept editing events. No save request is issued by the view page.

Read-only behavior is also enforced through server permissions: a session with view-only permission cannot call the drawing-save endpoint successfully. Removing controls alone is insufficient.

Version 1 loads the latest committed drawings when opened or refreshed; it does not require live updates while another tab saves.

## 6. Resizable Layout

- Initial left panel width: approximately 280 pixels.
- Minimum left panel width: 200 pixels.
- Preserve at least 320 pixels for the right panel where viewport width permits.
- Divider supports mouse and touch dragging.
- Divider is keyboard accessible: Left/Right keys resize the panels.
- Provide separator semantics and an accessible label.
- Changing panel width does not modify annotation coordinates.
- On narrow screens, retain a usable minimum layout with horizontal scrolling if necessary.

## 7. Drawing Coordinates and Data Format

Use normalized coordinates relative to each page's displayed content rectangle:

```text
normalized x = pointer x within page / displayed page width
normalized y = pointer y within page / displayed page height
```

The coordinate origin is the top-left corner. Values are in the range 0 to 1. Page numbers are one-based. Do not include page margins, scroll offsets, borders, or toolbar positions in saved coordinates.

Store line width and text size in PDF page units, or explicitly documented base-page units, and scale them consistently at display time. Server rendering must use the same crop box and rotation at every resolution.

Example saved data:

```json
{
  "formatVersion": 1,
  "reportId": 1,
  "pdfHash": "<SHA-256 of the source PDF>",
  "drawings": [
    {
      "id": "drawing-001",
      "page": 1,
      "type": "pen",
      "color": "#d62828",
      "lineWidth": 2,
      "points": [[0.15, 0.22], [0.18, 0.25], [0.23, 0.24]]
    },
    {
      "id": "drawing-002",
      "page": 2,
      "type": "text",
      "color": "#d62828",
      "fontSize": 14,
      "position": [0.32, 0.41],
      "text": "Please check this value."
    }
  ]
}
```

For rectangles, store two normalized corner points. For arrows, store normalized start and end points. Rebuild overlay elements from validated data on load and redraw or rescale them on zoom.

Use the PDF content hash to prevent attaching old annotations to a replacement PDF with the same filename. If the file changes, refuse to load or save the old drawing set until it has been explicitly archived or reset. No document-management UI is required in Version 1.

## 8. Database Design

One row stores the current complete drawing snapshot for one report. The example supports the fixed sample report with ID `1`.

```sql
CREATE DATABASE IF NOT EXISTS report_review
  CHARACTER SET utf8 COLLATE utf8_unicode_ci;

USE report_review;

CREATE TABLE review_drawings (
    report_id INT UNSIGNED NOT NULL,
    pdf_sha256 CHAR(64) NOT NULL,
    format_version SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    drawings_json LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (report_id)
) ENGINE=InnoDB;
```

Use `LONGTEXT` for compatible JSON storage across MariaDB/MySQL configurations. Validate and encode JSON in PHP before persistence. Use PDO with exception mode and native prepared statements.

The server validates the submitted PDF hash against the current source PDF and checks any existing snapshot hash, then inserts or updates the complete snapshot in a transaction. A PDF hash mismatch returns HTTP 409. No database revision field or stale-edit conflict check is required for this single-person test.

No multi-reviewer history or per-user annotation ownership is included in this version.

## 9. Backend Endpoints

| Endpoint | Method | Purpose |
| --- | --- | --- |
| `api/report-info.php` | GET | Return static title/author, PDF hash, page count, and page dimensions |
| `api/page-image.php?reportId=1&page=1&level=standard` | GET | Stream one protected rendered page image |
| `api/drawing-load.php?reportId=1` | GET | Return current drawings, PDF hash, and data format version |
| `api/drawing-save.php` | POST | Save a validated drawing snapshot |

Metadata includes page width and height in consistent page units, with rotation applied. Allow only predefined image resolution levels, such as standard and high, to bound rendering cost. Zoom may initially scale the current image while requesting a higher-resolution replacement; replacing the image must not move annotations.

Use JSON responses for metadata, drawing operations, and API errors. An unsuccessful image request returns an error status; the client must not treat it as a successfully loaded image.

| Status | Meaning |
| --- | --- |
| 200 | Successful operation |
| 400 | Invalid payload, page number, or resolution |
| 401 | No authorized session |
| 403 | Insufficient permission or invalid CSRF token |
| 404 | Report/page unavailable |
| 409 | Changed PDF |
| 413 | Drawing payload too large |
| 500 | Server/database/rendering failure |

Suggested drawing limits: 2 MB per save, 2,000 drawings per document, 10,000 points per stroke, and 1,000 UTF-8 bytes per text annotation. Validate numeric values as finite and validate page numbers against the actual PDF page count.

## 10. Rendering and Deployment

Use a server-side PDF renderer such as Poppler's `pdftoppm`. PHP calls the fixed executable with validated arguments and a server-controlled source path. Do not interpolate user-controlled shell text.

Required environment:

- PHP 7.4 with PDO MySQL support and sessions.
- MariaDB or MySQL with InnoDB and `utf8mb4`.
- A server-side PDF renderer.
- Apache/Nginx, or PHP's built-in server for local tests only.
- A modern browser with JavaScript, SVG, and Pointer Events.

Pre-render the sample report during setup where practical. Cache rendered images by PDF hash, page number, and resolution level. Render outputs must be written atomically so concurrent requests never receive an incomplete image. Use timeouts and bounded resolutions. For large reports, load page images lazily and retain page geometry so scrolling does not jump.

Local test launch, from the project directory:

```bash
php -S 127.0.0.1:8080 -t public
```

Open `http://127.0.0.1:8080/edit.php` and `http://127.0.0.1:8080/view.php`. Import SQL, configure database credentials and test access password hash, and generate page images before testing. Do not expose the PHP development server publicly.

PHP 7.4 is the requested compatibility target. This document does not assert that it is a currently maintained runtime.

## 11. Acceptance Tests

| Test | Expected result |
| --- | --- |
| Open edit page | Static title/author, Save, divider, and all report pages appear |
| Resize divider | Both panel widths change without shifting drawings within a page |
| Draw on two pages | Each drawing stays associated with its original page |
| Zoom 100% to 200% to 75% | Drawings remain aligned, with proportional line and text sizes |
| Scroll between pages | Drawings do not drift or appear on another page |
| Save then reload edit page | Saved drawings are restored |
| Open view page | Same committed drawings appear; no editing or Save controls |
| No saved drawings | View page displays clean pages without an error |
| Delete all drawings and save | Both pages reload with no drawings |
| Save in progress | Save remains disabled until the request completes |
| Database unavailable | Save reports failure and retains local drawings |
| Drawing-load failure | Editing/save remain unavailable to avoid overwriting unknown data |
| Replace source PDF | Hash mismatch prevents reusing old drawings silently |
| Request `pdfs/test_report.pdf` in browser | Original PDF is inaccessible |
| Inspect browser network traffic | Only metadata, page images, assets, and drawing JSON; no PDF response |
| Open page-image endpoint without access | Request is rejected |
| Save with view-only permission | Server rejects the request |
| Save with missing/invalid CSRF token | Server rejects the request |
| Invalid page number or filesystem path | Server rejects the request; no arbitrary file is served |
| Unicode text annotation | Saved and reloaded text is correct |
| Keyboard resize | Divider changes panel widths accessibly |

## 12. Excluded from Version 1

- Report uploading and management.
- Approval/rejection workflow and report revisions UI.
- Reviewer assignment and notifications.
- Simultaneous editing, revision-conflict handling, and real-time collaborative editing.
- Annotation history, audit trail, and individual reviewer ownership.
- Voice comments.
- Exporting drawings into a downloadable PDF.
- ZF1 integration.
- Preventing all screenshots or copying of displayed page images.

## 13. Implementation Deliverables

The subsequent implementation should provide complete PHP/JavaScript/CSS source, SQL schema, a multi-page sample `pdfs/test_report.pdf`, server-rendering setup instructions, database configuration example, and a README covering installation and the acceptance tests above.

This file specifies the agreed behavior; it is not a claim that implementation or runtime tests have already been completed.

## 14. Technical References

- PDF.js rendering examples: https://mozilla.github.io/pdf.js/examples/ — explains browser-side PDF rendering, which is intentionally not used for the protected page-image architecture.
- PHP PDO: https://www.php.net/manual/en/book.pdo.php
- PHP sessions: https://www.php.net/manual/en/book.session.php
- Poppler: https://poppler.freedesktop.org/
