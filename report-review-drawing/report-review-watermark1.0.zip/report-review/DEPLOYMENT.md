# Deployment

Extract this archive and set your web server document root to report-review/public/.

1. Install PHP with PDO MySQL, sessions, GD with FreeType, and permission to run proc_open. Install Poppler (pdfinfo and pdftoppm). Enable PHP cURL if importing a PDF URL.
2. Import sql/database.sql into MariaDB or MySQL.
3. Copy config/local.example.php to config/local.php; set your database connection, renderer paths, and generated password hashes. Run php scripts/password.php to generate a hash. This archive contains no configured sign-in passwords.
4. Configure config/watermark.php, including a readable TrueType font path and the desired watermark opacity/count/angles. PHP controls the date/time timezone.
5. Give PHP write permission on the private cache/ directory, then run php scripts/setup.php.
6. Open /edit.php or /view.php and sign in.

Browser assets are already built. Node.js, npm, test tools, and developer dependencies are not required on the deployment server. The editable browser source and tests are included for maintenance.

Only public/ should be served over HTTP. Keep config/, pdfs/, src/, sql/, and cache/ private.

The bundled pdfs/test_report.pdf is the current sample document. Annotation database contents, local credentials, generated caches, browser executables, and temporary files are not included. See README.md and SOURCE_CODE_GUIDE.md for full configuration and maintenance instructions.