# Report Review — Source Code Guide

This guide explains the generated single-person PDF review test application. PHP prepares and saves report data, JavaScript handles drawing in the browser, and MariaDB/MySQL stores the annotations.

The original PDF is never edited. PHP embeds personalized watermarks into each PNG page image before sending it to the browser. An SVG layer over that image displays editable annotations.

Code examples below are excerpts or shortened equivalents of the implementation. Editable browser code is in `browser-src/`; `public/assets/` contains its generated ES5 deployment files. Configuration observations describe the files at the time this guide was written.

## 1. Architecture

```mermaid
flowchart LR
    PDF["Private PDF"] --> Renderer["PHP + Poppler"]
    Renderer --> Clean["Private clean-page cache"]
    Clean --> Watermark["PHP GD: personalized watermark"]
    Settings["Private watermark config + session seed"] --> Watermark
    Watermark --> Image["Watermarked PNG"]
    Image --> Browser["Browser: image + SVG drawings"]
    Browser -->|"Save drawing JSON"| API["PHP API"]
    API --> DB[("MariaDB / MySQL")]
    DB -->|"Load saved drawings"| API
    API --> Browser
```

The application has two user-facing pages:

- **Editor:** create, select, move, resize, rotate, recolor, delete, undo, and save annotations; edit text directly on the page.
- **Viewer:** display the latest saved annotations without editing controls.

Only the `public/` directory should be exposed by the web server. PHP can read the private project directories, but visitors should not be able to request them directly.

## 2. File responsibilities

| File | Responsibility |
| --- | --- |
| [public/edit.php](public/edit.php) | Opens the editor |
| [public/view.php](public/view.php) | Opens the read-only viewer |
| [public/index.php](public/index.php) | Redirects to the editor |
| [src/page.php](src/page.php) | Shared HTML, login form, sidebar, toolbar, and document area |
| [src/bootstrap.php](src/bootstrap.php) | Loads configuration/classes and handles API responses/errors |
| [src/AccessGuard.php](src/AccessGuard.php) | Password login, sessions, permissions, and CSRF checks |
| [src/ReportService.php](src/ReportService.php) | Report metadata and PDF content hash |
| [src/PageRenderer.php](src/PageRenderer.php) | Converts PDF pages into cached PNG images |
| [src/PdfSource.php](src/PdfSource.php) | Selects the bundled PDF or imports a configured HTTP/HTTPS source into a private cache |
| [src/WatermarkService.php](src/WatermarkService.php) | Generates stable random watermark positions/angles and embeds text into PNG pixels with PHP GD |
| [config/watermark.php](config/watermark.php) | Site title, username, date/time, count, opacity, rotation range, and font path |
| [public/api/page-image.php](public/api/page-image.php) | Serves authenticated, personalized PNGs without exposing the clean cache |
| [src/Database.php](src/Database.php) | Creates PDO database connections |
| [src/AnnotationService.php](src/AnnotationService.php) | Validates, loads, and saves drawings |
| [browser-src/review.js](browser-src/review.js) | Editable browser state, property controls, immediate colors, inline text, zoom, loading, and saving |
| [browser-src/drawings.js](browser-src/drawings.js) | Editable geometry helpers and SVG drawing renderer |
| [browser-src/compat.js](browser-src/compat.js) | Chrome 49 / Firefox 52 DOM, visibility, mouse/touch, UTF-8, focus, and request fallbacks |
| [public/assets/review.js](public/assets/review.js) | Generated ES5 review script; rebuild after editing source |
| [public/assets/drawings.js](public/assets/drawings.js) | Generated ES5 drawing renderer |
| [public/assets/compat.js](public/assets/compat.js) | Generated compatibility script; loaded first |
| [scripts/build-browser.cjs](scripts/build-browser.cjs) | Transpiles all browser sources with Babel; runtime helper code is included in output |
| [package.json](package.json) | Development dependencies and build/compatibility commands |
| [public/assets/review.css](public/assets/review.css) | Layout and appearance |
| [config/database.php](config/database.php) | Default application configuration |
| [config/local.example.php](config/local.example.php) | Example private configuration overrides |
| [sql/database.sql](sql/database.sql) | Database and table schema |
| [README.md](README.md) | Installation and acceptance-test instructions |

## 3. Editor and viewer entry points

The editor starts with:

```php
<?php
$mode = 'edit';
require dirname(__DIR__) . '/src/page.php';
```

The viewer uses the same shared page with a different mode:

```php
<?php
$mode = 'view';
require dirname(__DIR__) . '/src/page.php';
```

Sharing the layout avoids maintaining two nearly identical HTML files.

Inside `src/page.php`, editing is allowed only when all three conditions are true:

```php
$signedIn = !empty($_SESSION['role']);

$canEdit =
    $signedIn
    && $_SESSION['role'] === 'edit'
    && $mode === 'edit';
```

1. The visitor has signed in.
2. Their session permits editing.
3. They opened the editor page.

Someone with edit permission still sees a read-only interface when opening the viewer.

PHP passes the effective mode to JavaScript through an HTML attribute:

```php
<body data-mode="<?= $canEdit ? 'edit' : 'view' ?>">
```

JavaScript reads it:

```javascript
const editable = document.body.dataset.mode === 'edit';
```

This value describes permission to edit. A separate JavaScript `editing` flag starts as `false` and controls whether annotation input is currently enabled.

### Viewing and editing sessions

The editor opens in viewing mode. Its header contains thumbnail visibility, page selection, zoom, current-page rotation, and **Edit**/**Done** controls. The drawing toolbar is a footer with the HTML `hidden` attribute until Edit is clicked.

`setEditing(true)` shows the footer, enables drawing controls, and allows SVG pointer events. `setEditing(false)` finishes the current stroke or move, clears selection, disables annotation input, and hides the footer. Existing SVG drawings remain visible. Done does not save; the sidebar's Save drawings button handles persistence.

In Edit mode, Select lets users drag existing annotations within their page. Color, line width, and text size changes apply to the selected drawing. Edit text (or a double-click with Select) updates an existing note. These changes participate in Undo and the next saved snapshot.

## 4. Configuration and database connection

The current `config/database.php` uses this database connection:

```php
'dsn' => 'mysql:host=127.0.0.1;dbname=report_review;charset=utf8',
'user' => 'root',
'password' => '',
```

| DSN component | Meaning |
| --- | --- |
| `mysql:` | Use PDO's MySQL driver |
| `host=127.0.0.1` | Connect to the local database server |
| `dbname=report_review` | Select the database |
| `charset=utf8` | Set the connection character set |

The PDF executable settings are:

```php
'pdftoppm' => 'pdftoppm',
'pdfinfo' => 'pdfinfo',
```

These programs must be available to the PHP process. Absolute paths can also be configured:

```php
'pdftoppm' => 'C:/tools/poppler/bin/pdftoppm.exe',
'pdfinfo' => 'C:/tools/poppler/bin/pdfinfo.exe',
```

Configuration values can be overridden using `config/local.php`:

```php
return array_replace(
    [
        // Default settings...
    ],
    is_file(__DIR__ . '/local.php')
        ? require __DIR__ . '/local.php'
        : []
);
```

`array_replace()` replaces matching default values with values from the second array. This separates local settings from shared defaults.

The current configuration and SQL schema use `utf8`. For full Unicode support, including emoji, use `utf8mb4` consistently for the connection and database/table character sets. Ensure the database name in any local override matches the database you imported; the original example configuration may use `report_review_test`.

`Database::connect()` creates the PDO connection:

```php
return new PDO(
    $config['dsn'],
    $config['user'],
    $config['password'],
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
);
```

- Exception mode makes database errors catchable.
- Native prepared statements separate SQL from data values.
- Associative fetch mode returns rows keyed by column name.

## 5. Password login and sessions

The main login logic in `AccessGuard::login()` is:

```php
foreach (['edit', 'view'] as $role) {
    $hash = $config[$role . '_password_hash'];

    if ($hash !== '' && password_verify($password, $hash)) {
        session_regenerate_id(true);

        $_SESSION['role'] = $role;
        $_SESSION['csrf'] = bin2hex(random_bytes(32));

        return true;
    }
}
```

The submitted password is checked against a stored hash. The application does not need to store the original password.

After a successful match:

1. The session ID is regenerated.
2. The role is stored in the session.
3. A new CSRF token is generated.

At the time this guide was written, the configured edit and view password hashes were identical. Because the loop checks `edit` first, that password creates an edit session. Use different passwords to test separate view-only access.

Protected APIs check the session:

```php
public static function requireAccess(bool $edit = false): void
{
    self::start();

    if (empty($_SESSION['role'])) {
        throw new HttpError(401, 'Please sign in again.');
    }

    if ($edit && $_SESSION['role'] !== 'edit') {
        throw new HttpError(
            403,
            'This session has view-only access.'
        );
    }
}
```

Hiding the Save button is only the interface behavior. The save endpoint also enforces edit permission on the server.

## 6. Common API request handling

The `api()` function in `src/bootstrap.php` applies common checks to each endpoint:

```php
if ($_SERVER['REQUEST_METHOD'] !== $method) {
    throw new HttpError(405, 'Method not allowed.');
}

AccessGuard::requireAccess($edit);

if ($method === 'POST') {
    AccessGuard::checkCsrf(
        $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''
    );
}

WatermarkService::initialize();
session_write_close();

$action();
```

An endpoint can require POST and edit access like this:

```php
api(function () {
    // Endpoint-specific work...
}, 'POST', true);
```

`session_write_close()` releases PHP's session lock before rendering or database work. One browser can request several images at once, so retaining that lock would unnecessarily delay requests.

Watermark initialization runs after access and CSRF checks, before releasing the session lock. It creates a private random session seed and date/time if absent. The authenticated HTML page calls `WatermarkService::initialize(true)` to refresh the displayed date/time while retaining the seed. The image endpoint can read the session values after the lock is released; no browser watermark settings are accepted.

Expected errors become JSON responses with an appropriate HTTP status:

```json
{
  "error": "This session has view-only access."
}
```

Unexpected exceptions are logged on the server. The browser receives a general error rather than private paths or database details.

| Endpoint | Method | Result |
| --- | --- | --- |
| `api/report-info.php?reportId=1` | GET | Title, author, hash, page count, and dimensions |
| `api/page-image.php` | GET | One protected PNG page image with personalized watermark pixels |
| `api/drawing-load.php?reportId=1` | GET | Saved drawing objects |
| `api/drawing-save.php` | POST | Saves a complete drawing snapshot |

## 7. Report metadata and PDF hashes

`ReportService::info()` returns an object shaped like this:

```json
{
  "reportId": 1,
  "title": "Monthly Test Report",
  "author": "John Smith",
  "pdfHash": "a SHA-256 content hash",
  "pageCount": 17,
  "pages": [
    {
      "page": 1,
      "width": 595.28,
      "height": 841.89
    }
  ]
}
```

This is an abbreviated example: the actual response includes every page, and `pdfHash` contains the real hexadecimal hash.

The title and author are static sample values. Page count and dimensions come from the actual PDF.

The content hash is calculated with:

```php
return hash_file('sha256', $path);
```

It identifies the file's contents rather than its name:

```text
Original test_report.pdf    -> hash A
Replacement test_report.pdf -> hash B
```

The application rejects annotations that belong to a different PDF:

```php
if (!is_string($hash) || !hash_equals(self::hash(), $hash)) {
    throw new HttpError(
        409,
        'The PDF changed. Reset or archive the old drawings before continuing.'
    );
}
```

This is document-change protection, not simultaneous-editor revision tracking. Version 1 has one fixed report ID, `1`.

## 8. Rendering PDF pages

`PageRenderer` uses two Poppler programs:

- `pdfinfo` reads page count, crop boxes, and rotation.
- `pdftoppm` renders individual pages into PNG files.

The rendering arguments are constructed as an array:

```php
self::run([
    $config['pdftoppm'],
    '-f', (string)$page,
    '-l', (string)$page,
    '-cropbox',
    '-singlefile',
    '-scale-to', $level === 'high' ? '3200' : '1600',
    '-png',
    ROOT . '/pdfs/test_report.pdf',
    $prefix
]);
```

For page 2:

| Option | Purpose |
| --- | --- |
| `-f 2` | Start at page 2 |
| `-l 2` | End at page 2 |
| `-cropbox` | Render the visible crop area |
| `-singlefile` | Produce one output image |
| `-scale-to 1600` | Bound the longest image edge to 1,600 pixels |
| `-png` | Produce PNG output |

The source path is controlled by the server. The browser supplies a page number and an allowed resolution level, not a filesystem path.

The process is launched using `proc_open()` with an argument array and shell bypass enabled. The implementation reads process output, checks the exit status, and stops rendering if it exceeds 40 seconds.

The crop-box dimensions determine page width and height. Width and height are swapped for 90- or 270-degree rotation so metadata matches the rendered orientation.

### Optional HTTP/HTTPS PDF source

Set `pdf_url` in the private `config/local.php` array to a direct PDF URL, or leave it empty for the bundled PDF. `PdfSource::path()` resolves the configured source for `ReportService::hash()` and `PageRenderer`. Neither the URL nor the source PDF is sent to the browser; the same protected watermarked PNG endpoint serves imported pages.

`PdfSource::import()` uses PHP cURL with HTTP/HTTPS-only redirects (maximum five), TLS verification, a 10-second connection timeout, a 45-second total download timeout, and a streaming 50 MiB limit. It rejects invalid schemes, embedded URL credentials, non-200 final responses, non-PDF content, corrupt files, and password-protected documents. `PageRenderer::inspect($source)` checks staged metadata, page counts, and crop-box dimensions before publication.

Each URL maps to `cache/imported-pdfs/<SHA-256 of URL>/source.pdf`. A lock avoids duplicate concurrent imports; temporary downloads are removed on failure, and a validated download is renamed into place. Subsequent requests reuse that private file. The configured URL is administrator-owned, not a browser parameter; it may access hosts reachable by the PHP server. The server does not forward a user's browser cookies or request remote login credentials.

The renderer caches PNGs by PDF content hash, regardless of whether the PDF came from disk or HTTP. Existing drawing hash checks continue to reject annotations associated with another source. Before switching sources, archive/reset drawings with the existing recovery script, then run setup and reload. Remote URLs are not automatically refreshed; remove that URL's cached source while the viewer is closed to re-import updated content. Keep any old source needed for archived annotation recovery. Sample report title/author remain unchanged.

### Private rendered-image caching

Cache files are grouped by PDF content hash:

```text
cache/rendered-pages/<PDF hash>/metadata.json
cache/rendered-pages/<PDF hash>/1-standard.png
cache/rendered-pages/<PDF hash>/1-high.png
cache/rendered-pages/<PDF hash>/2-standard.png
```

A replacement PDF gets a different cache directory.

Images are written under temporary names, then renamed after rendering completes:

```php
rename($prefix . '.png', $file);
```

This prevents requests from receiving partially written images. A file lock prevents duplicate rendering of the same missing image. These protections remain useful for one tester because a browser issues multiple requests.

### Streaming an image

After checking access, page number, resolution, and hash, `page-image.php` obtains the clean cached page, composes watermarks in memory, checks the PDF hash again, and sends the resulting PNG:

```php
$file = PageRenderer::image($hash, (int)$page, $level);
$geometry = PageRenderer::metadata($hash)[(int)$page - 1];
$image = WatermarkService::image(
    $file, $geometry, WatermarkService::settings()
);
ReportService::checkHash($hash);

header('Content-Type: image/png');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header('Content-Length: ' . strlen($image));

echo $image;
```

The browser does not need the original PDF bytes. It does receive page images, which can still be saved or captured.

### Personalized watermarks in PHP

`config/watermark.php` defines the server-owned values:

```php
$site_title = "Document View";
$username = "Danny Powel";
$datetime = date('Y-m-d H:i');
$watermark_count = 3;
$watermark_opacity = 0.28;
$watermark_angle_min = -35;
$watermark_angle_max = 35;
```

| Setting | Behavior |
| --- | --- |
| Site title / username | First and second text lines; currently PHP variables, ready to replace with authenticated account data |
| Date/time | Third line; refreshed when an authenticated HTML page opens, using PHP's configured timezone |
| Count | Integer 0–100 per page; 0 disables watermarks |
| Opacity | Finite numeric value 0–1; 0 is invisible, 0.28 is 28%, 1 is fully opaque |
| Angle range | Finite numbers between −360° and 360°, with minimum ≤ maximum; each watermark gets an independent angle |
| Font | Readable TrueType font path; defaults to Arial on Windows and DejaVu Sans on Linux |

Set both angle limits to `0` for horizontal watermarks, or set both to the same number for a fixed angle. PHP GD's positive text angles rotate counterclockwise; annotation angle controls use clockwise screen coordinates. Reload the viewer after changing configuration.

`WatermarkService::layout()` splits each page into cells, shuffles their order, and chooses a random location and angle in each selected cell. Random values come from HMAC-SHA256 labels containing the page number and a private seed generated with `random_bytes(32)`. Each page therefore has independent positions and angles, and standard/high-resolution requests reproduce the same logical layout for that session.

The service measures all text lines with `imagettfbbox()`, rotates their bounding corners and baseline origins as one block, then scales that block to fit within its cell. The line count, text width, and angle all affect its bounds. This keeps the entire watermark on the page and separates marks within a page.

`WatermarkService::image()` loads the cached PNG with GD, converts PDF-point positions to image pixels, and draws rotated lines with `imagettftext()`. Opacity becomes GD alpha through `round((1 - $opacity) * 127)`. The composed image is encoded in memory; the shared clean-page cache is never replaced with a viewer's personalized image.

Both main page images and thumbnails use the same protected endpoint. Watermarks follow zoom and page rotation because they are part of the page image. They have no SVG drawing ID, cannot be selected or edited as annotations, and cannot be removed by deleting JavaScript or DOM layers. Request parameters cannot override their identity, count, opacity, or angle. A missing font or unavailable GD/FreeType fails the image request rather than silently serving a clean page.

## 9. Initial browser loading

An asynchronous initialization function near the end of `review.js` loads metadata and saved drawings:

```javascript
info = await request('report-info.php?reportId=1');

const data = await request('drawing-load.php?reportId=1');

if (
  data.pdfHash !== info.pdfHash ||
  data.formatVersion !== 1
) {
  throw new Error('The document changed. Reload the page.');
}

drawings = data.drawings;
saved = JSON.stringify(drawings);

buildPages();
ready = true;

controls(); // Enables Edit; drawing tools remain disabled until Edit is clicked.
```

The Edit button is enabled only after both requests succeed. Annotation input remains disabled until Edit is clicked. A failed load cannot silently start an empty editor that overwrites unknown saved data.

The main state variables are:

| Variable | Meaning |
| --- | --- |
| `info` | Report metadata |
| `drawings` | Current completed drawing objects |
| `saved` | Serialized copy of the last saved state |
| `active` | Stroke or move currently in progress; distinguished by `kind` |
| `editing` | Whether the user has entered Edit mode |
| `currentPage` | Page selected by navigation or scrolling |
| `selected` | Selected drawing ID |
| `undo` | Previous local drawing states |
| `ready` | Whether initial loading succeeded |
| `saving` | Whether a save request is running |
| `pageViews` | Image, SVG, and geometry references for each page |

Unsaved changes are detected by comparing snapshots:

```javascript
const dirty = () => JSON.stringify(drawings) !== saved;
```

For this small test application, serialized snapshot comparison keeps the implementation simple.

## 10. Image and SVG page layers

Each page is built with this effective structure:

```html
<div class="page">
  <div class="page-content">
    <img alt="Report page 1"><!-- PHP-watermarked PNG -->

  <svg viewBox="0 0 595.28 841.89">
    <!-- Drawing elements -->
  </svg>
    <!-- The temporary inline text editor is appended here while editing. -->
  </div>
</div>
```

CSS places the SVG exactly over the image:

```css
.page {
  position: relative;
}

.page img {
  width: 100%;
  height: 100%;
}

.page svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}
```

The `viewBox` uses page dimensions in PDF points. These logical dimensions stay fixed as the displayed page grows or shrinks.

`layoutPage()` scales `.page-content` and applies its rotation transform. The image, SVG annotations, and active inline text editor share this container. Watermarks have no separate browser overlay; PHP already composed them into the image.

## 11. Normalized coordinates

Positions are stored as fractions of the page width and height:

```javascript
function position(event, svg) {
  const point = ReviewCompat.point(svg, event.clientX, event.clientY);

  return [
    Math.max(
      0,
      Math.min(1, point.x / svg.viewBox.baseVal.width)
    ),
    Math.max(
      0,
      Math.min(1, point.y / svg.viewBox.baseVal.height)
    )
  ];
}
```

Suppose a page is displayed at 800 by 1,000 pixels. A click is 200 pixels from its left edge and 300 pixels from its top edge:

```text
x = 200 / 800  = 0.25
y = 300 / 1000 = 0.30
```

The saved position is:

```json
[0.25, 0.30]
```

If the page becomes 1,600 by 2,000 pixels:

```text
x = 0.25 × 1600 = 400 pixels
y = 0.30 × 2000 = 600 pixels
```

The annotation remains at the same place on the document.

The inverse SVG screen transform maps the pointer from screen pixels into the original page coordinate system, accounting for scrolling, sidebar width, zoom, and viewer rotation. Dividing by the viewBox dimensions produces normalized coordinates. The `Math.max()` and `Math.min()` calls clamp positions to 0–1.

## 12. Drawing data examples

A drawing is an ordinary JavaScript object.

### Rectangle

```javascript
const rectangle = {
  id: 'drawing-001',
  page: 1,
  type: 'rectangle',
  color: '#d62828',
  lineWidth: 2,
  points: [
    [0.10, 0.20],
    [0.40, 0.35]
  ]
};
```

The two points are opposite corners.

### Arrow

```javascript
const arrow = {
  id: 'drawing-002',
  page: 2,
  type: 'arrow',
  color: '#245d47',
  lineWidth: 2,
  points: [
    [0.20, 0.30],
    [0.60, 0.50]
  ]
};
```

The two points are the start and end positions.

### Freehand pen

```javascript
const pen = {
  id: 'drawing-003',
  page: 1,
  type: 'pen',
  color: '#d62828',
  lineWidth: 2,
  points: [
    [0.10, 0.20],
    [0.11, 0.21],
    [0.13, 0.23],
    [0.16, 0.24]
  ]
};
```

A pen stroke stores a sequence of points.

### Text

```javascript
const note = {
  id: 'drawing-004',
  page: 1,
  type: 'text',
  color: '#d62828',
  fontSize: 14,
  position: [0.25, 0.30],
  text: 'Please check this value.'
};
```

Text uses a top-left position. Positions are normalized; line widths and font sizes are stored in PDF page units.

## 13. Pointer events and drawing creation

Drawing follows this sequence:

```text
pointerdown -> create an active drawing
pointermove -> update points and preview
pointerup   -> add the drawing to the completed list
```

On pointer down:

```javascript
const drawing = {
  ...base(geometry, tool),
  lineWidth: Number($('line-width').value),
  points: [point, [...point]]
};

active = {
  drawing,
  svg,
  pointerId: event.pointerId
};

svg.setPointerCapture(event.pointerId);
```

Pointer capture keeps movement events directed to the SVG when a drag moves beyond its boundaries.

On pointer movement:

```javascript
if (d.type === 'pen') {
  if (d.points.length < 10000) {
    d.points.push(point);
  }
} else {
  d.points[1] = point;
}
```

A pen appends points. A rectangle or arrow preserves the first point and updates the second.

When the stroke finishes, `commit()` records an undo state and adds the object:

```javascript
function commit(drawing) {
  remember();

  drawings.push(drawing);
  selected = null;

  changed();
}
```

The complete function also enforces the 2,000-drawing limit. Nothing has been written to the database yet.

Text uses an inline editor on the PDF page instead of a dialog or drag. The Text tool opens it at the clicked normalized position; clicking an existing text note with Text edits that note. Select also offers **Edit text**, and double-clicking a note opens the same editor.

### Inline text editing

The shared HTML supplies `#inline-text-editor`, its labeled `#note-text` textarea, and Add note/Update note and Cancel buttons. `openText()` attaches that editor to the appropriate `.page-content` and stores the note ID or new-note position in `noteAt`.

`layoutTextEditor()` follows the page scale, applies the note's font size and color, and positions the editing box near its anchor. It moves the box inward near page edges so its controls remain usable; the annotation's stored anchor stays at the clicked position. The editor shares the page's display rotation.

`finishText()` validates the UTF-8 byte limit, records an Undo snapshot, and either updates an existing note or commits a new text drawing. A valid draft is applied when the user clicks Add note/Update note, presses Ctrl/⌘+Enter, clicks the PDF elsewhere, switches drawing tools, chooses Done, or saves drawings. An empty/whitespace-only draft closes without changing stored notes. Invalid nonempty drafts remain open for correction.

Escape and Cancel discard the draft. Undo cancels the draft before restoring the last applied operation. Delete cancels the active editor before deleting the selected drawing. Pending nonempty drafts participate in the navigation warning, and Save drawings applies a valid draft before taking its JSON snapshot. There is no modal text dialog.

## 14. Rendering drawing objects as SVG

`drawings.js` converts normalized points into PDF page units:

```javascript
const point = p => [
  p[0] * geometry.width,
  p[1] * geometry.height
];
```

Each page renders only its own drawings:

```javascript
if (d.page !== geometry.page) {
  continue;
}
```

### Rectangles

```javascript
const [a, b] = points;

group.append(element('rect', {
  ...style,
  x: Math.min(a[0], b[0]),
  y: Math.min(a[1], b[1]),
  width: Math.abs(a[0] - b[0]),
  height: Math.abs(a[1] - b[1])
}));
```

`Math.min()` and `Math.abs()` allow dragging in any direction.

### Pen paths

```javascript
const path =
  'M' + points.map(p => p.join(',')).join(' L');
```

An example SVG path is:

```text
M60,100 L65,110 L75,120
```

- `M` moves to the starting position.
- `L` draws a line to the next position.

A transparent wider path is also created to make thin pen and arrow strokes easier to select.

### Arrowheads

Arrows use a line plus two short lines at the endpoint. `Math.atan2()` calculates the shaft angle. The arrowhead endpoints are calculated with sine and cosine around that angle.

### Text

Text is inserted with:

```javascript
span.textContent = line || ' ';
```

For example, `Check <b>this value</b>` displays literally. It is not interpreted as HTML.

New lines become SVG `tspan` elements. Each additional line advances by 1.2 times the font size.

## 15. Zoom and lazy image loading

The image and SVG share an inner `.page-content` element. `layoutPage()` rotates this element and swaps the outer page width/height at 90 or 270 degrees, so image and annotations rotate together. Each page keeps its own display rotation. Rotation is not saved and resets on reload.

The page selector, Previous/Next buttons, and thumbnail buttons call `goToPage()`. Scrolling updates `currentPage` and the selected thumbnail. Thumbnail images are requested when the panel first opens and use lazy loading. They show the PDF page rather than an annotation preview.

Zoom changes the page's displayed dimensions:

```javascript
const scale = Number($('zoom').value) * 96 / 72;

p.page.style.width =
  p.geometry.width * scale + 'px';

p.page.style.height =
  p.geometry.height * scale + 'px';
```

PDF dimensions use 72 points per inch. The application defines 100% zoom using 96 CSS pixels per inch.

For a page approximately 595.28 points wide:

```text
100%: 595.28 × 96 / 72     ≈ 794 CSS pixels
200%: 595.28 × 2 × 96 / 72 ≈ 1,587 CSS pixels
```

The SVG scales with the container, including its positions, stroke widths, and text sizes. Saved coordinates do not change.

At 150% and 200%, visible pages request high-resolution images. Replacing a page image does not replace its SVG or change its geometry.

Images load near the visible area using `ReviewCompat.Observer`, which chooses native IntersectionObserver when available and a scroll/resize visibility fallback otherwise:

```javascript
const observer = new ReviewCompat.Observer(entries => {
  entries.forEach(entry => {
    const p = pageViews.find(
      p => p.page === entry.target
    );

    p.visible = entry.isIntersecting;

    if (p.visible) {
      loadImage(p);
    }
  });
}, {
  root: $('pages'),
  rootMargin: '600px'
});
```

The 600-pixel margin starts loading before a page enters view. Page dimensions are allocated in advance so image loading does not shift the layout.

## 16. Selection, deletion, and Undo

### Type-specific property controls

Selecting a drawing populates `#drawing-properties`. `syncProperties()` shows only the controls appropriate to its type:

| Drawing type | Editable properties |
| --- | --- |
| All types | Color, X/Y position, opacity, angle |
| Pen | Thickness, bounding width and height |
| Rectangle | Thickness, width and height |
| Arrow | Thickness, line length and direction |
| Text | Font size and text contents through the inline editor |

Dimensions and positions shown by the controls use PDF points, independent of zoom. Arrow X/Y is its start point; other X/Y values identify the unrotated top-left bounds or text anchor. Positive annotation angles turn clockwise.

`ReviewDrawings.bounds()` finds unrotated bounds. `properties()` derives display values, including arrow length and angle using actual page width/height so non-square pages are handled correctly. `update()` returns a copied drawing with a proposed property change; it rejects invalid sizes, unsupported properties, and point coordinates outside the page.

Arrow length and direction change its endpoint while preserving its start. Resizing pen/rectangle bounds scales their coordinates from the top-left corner. Position changes translate all points or the text anchor. A pen stroke with zero extent along an axis cannot be stretched along that axis. Pen and rectangle rotation is rendered around their bounds' center; text rotation uses its anchor. Rotated drawing strokes can extend beyond the page and are clipped by the SVG/page; coordinate validation concerns the stored points.

Opacity is stored from 0 to 1 but displayed as 0–100%. Every drawing's rendered children receive its opacity, while the blue selection rectangle stays visible even at 0%. Transparent wider hit paths make thin strokes selectable, and a transparent hit rectangle allows selection inside rectangles.

### Immediate color changes

The color picker listens to both `input` and `change`. `applyColor()` immediately updates the selected drawing and redraws it without waiting for another Apply, Save, or Confirm action. `colorEdit` groups a native picker's successive input events into one Undo snapshot; change or blur ends that group.

`drawingColor` separately retains the chosen default for new drawings. Selecting an existing object displays its color in the picker without overwriting that default. Deselecting or switching tools restores the chosen default, and ordinary redraws no longer reset the picker to an older drawing color. Active inline text previews also update when the chosen color changes. These changes are immediate locally; **Save drawings** persists the annotation snapshot.

### Deletion and history

Every SVG drawing group contains its ID:

```html
<g data-id="drawing-001">
  <!-- Shape -->
</g>
```

The Select tool identifies the clicked drawing:

```javascript
selected =
  event.target.closest('[data-id]')?.dataset.id || null;
```

Delete filters that drawing out of the local array:

```javascript
remember();

drawings = drawings.filter(
  d => d.id !== selected
);

selected = null;
changed();
```

Before a local change, `remember()` saves a deep copy:

```javascript
function remember() {
  undo.push(copy(drawings));

  if (undo.length > 100) {
    undo.shift();
  }
}
```

Undo restores the most recent copy:

```javascript
drawings = undo.pop();
```

A deep copy prevents future changes from modifying previous undo states. Up to 100 local operations are retained.

Undo is not database history. If you undo after a save, save again to persist the restored state. Undo history is lost when the page reloads.

## 17. Saving from JavaScript

Save captures a complete snapshot:

```javascript
const snapshot = JSON.stringify(drawings);
```

It sends that snapshot to PHP:

```javascript
await request('drawing-save.php', {
  method: 'POST',

  headers: {
    'Content-Type': 'application/json',
    'X-CSRF-Token': csrf
  },

  body: JSON.stringify({
    reportId: 1,
    pdfHash: info.pdfHash,
    formatVersion: 1,
    drawings: JSON.parse(snapshot)
  })
});
```

A request has this shape:

```json
{
  "reportId": 1,
  "pdfHash": "the current PDF hash",
  "formatVersion": 1,
  "drawings": [
    {
      "id": "drawing-001",
      "page": 1,
      "type": "rectangle",
      "color": "#d62828",
      "lineWidth": 2,
      "points": [[0.1, 0.2], [0.4, 0.35]]
    }
  ]
}
```

The real request uses the current hash supplied by the metadata endpoint.

The CSRF token is generated by PHP, included in the HTML page, and compared with the session value on submission.

Save is disabled while the request is in progress. Drawing may continue, but only the submitted snapshot is marked saved:

```javascript
saved = snapshot;
```

For example:

```text
1. You save drawings A and B.
2. While saving, you add C.
3. The server finishes saving A and B.
4. C remains an unsaved local change.
```

If the request fails, the local drawing array is retained. Leaving the page with unsaved changes triggers the browser's standard navigation warning.

## 18. Server-side drawing validation

The save endpoint limits the body to 2 MiB and decodes the JSON:

```php
$data = json_decode(
    $raw,
    true,
    64,
    JSON_THROW_ON_ERROR
);
```

The `true` argument requests associative arrays. Invalid JSON raises an exception and becomes a client error.

The endpoint then calls:

```php
AnnotationService::save(
    $data,
    ReportService::info()
);
```

Validation rules include:

| Property | Rule |
| --- | --- |
| Report ID | Must identify report `1` |
| PDF hash | Must match the current PDF |
| Format version | Must be `1` |
| Drawing count | At most 2,000 |
| Drawing ID | Unique; ASCII letters, digits, hyphens, underscores; up to 80 characters |
| Page | Must exist in the PDF |
| Color | Six-digit hexadecimal color |
| Coordinates | Finite numbers from 0 to 1 |
| Line width | 0.5–20 points |
| Font size | 6–72 points |
| Opacity | Optional finite number 0–1; absent values render at full opacity |
| Rotation | Optional finite number −360–360 for pen/rectangle/text; absent values render at 0° |
| Text | Nonempty valid UTF-8; at most 1,000 bytes |
| Pen points | Between 2 and 10,000 |
| Rectangle/arrow points | Exactly 2 |

Unknown drawing properties are rejected as well.

Arrows encode their angle in their two endpoints; a separate `rotation` field is rejected for arrows. Optional opacity and rotation are accepted and returned without changing `formatVersion: 1`, so legacy saved drawings remain compatible. Width/height, arrow length, and control values named `angle` are derived browser properties, not extra JSON fields.

For example, a rotated semi-transparent rectangle adds these optional properties to the rectangle object from section 12:

```javascript
opacity: 0.4,
rotation: 30
```

These annotation fields are independent of the private PHP watermark opacity and random angle settings.

Example point validation:

```php
private static function point($point): void
{
    if (
        !is_array($point) ||
        array_keys($point) !== [0, 1]
    ) {
        throw new HttpError(400, 'Invalid drawing point.');
    }

    self::number($point[0], 0, 1);
    self::number($point[1], 0, 1);
}
```

Browser validation improves usability. Server validation determines which data can actually be stored.

## 19. Database storage and transactions

One row stores the complete annotation set for one report:

| Column | Value |
| --- | --- |
| `report_id` | Report identifier and primary key |
| `pdf_sha256` | PDF content hash |
| `format_version` | Drawing format version |
| `drawings_json` | JSON array of drawing objects |
| `updated_at` | Last database update time |

There is no separate database row for each rectangle, arrow, or note.

The save statement inserts a new report row or updates the existing one:

```sql
INSERT INTO review_drawings (
    report_id,
    pdf_sha256,
    format_version,
    drawings_json
)
VALUES (?, ?, ?, ?)
ON DUPLICATE KEY UPDATE
    pdf_sha256 = VALUES(pdf_sha256),
    format_version = VALUES(format_version),
    drawings_json = VALUES(drawings_json)
```

The primary key on `report_id` determines whether this inserts or updates.

Parameters are supplied separately through PDO:

```php
$stmt->execute([
    1,
    $info['pdfHash'],
    1,
    json_encode(
        $drawings,
        JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
    )
]);
```

Annotation text is treated as data, not as part of the SQL statement.

Saving is wrapped in a transaction:

```php
$db->beginTransaction();

try {
    // Check the existing PDF hash.
    // Insert or replace the complete drawing snapshot.

    $db->commit();
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }

    throw $e;
}
```

The implementation checks an existing row using `SELECT ... FOR UPDATE` before saving. The endpoint reports success only after the transaction commits.

An empty drawing array clears annotations:

```json
{
  "drawings": []
}
```

This is the drawing portion of the request; the full request still needs the report ID, PDF hash, and format version. The database row remains but contains an empty list.

There is no revision counter or stale-editor check. Under the agreed single-editor scope, each successful save replaces the previous snapshot.

## 20. Loading saved drawings and read-only viewing

The load service selects the current report row:

```php
$stmt = Database::connect()->prepare(
    'SELECT pdf_sha256, format_version, drawings_json
     FROM review_drawings
     WHERE report_id = ?'
);

$stmt->execute([1]);
$row = $stmt->fetch();
```

If a row exists, PHP decodes its drawing JSON:

```php
json_decode(
    $row['drawings_json'],
    true,
    512,
    JSON_THROW_ON_ERROR
);
```

If no row exists, an empty drawing list is returned. Loaded drawings are validated before being sent to the browser.

The viewer uses the same SVG renderer as the editor but does not attach editing handlers:

```javascript
if (editable) {
  wireDrawing(svg, geometry);
} else {
  svg.style.pointerEvents = 'none';
}
```

This keeps the saved view visually consistent with the editor. Refresh the viewer after saving to load the latest committed snapshot; there are no live updates.

## 21. Resizable panel layout

The layout uses flex so it works in Chrome 49 and Firefox 52:

```css
.workspace {
  display: flex;
  height: calc(100vh - 70px);
}
#information { flex: 0 0 280px; }
#divider { flex: 0 0 8px; }
.document-panel { flex: 1 1 0%; min-width: 244px; }
```

The flex children are the information panel, divider, and document panel. Margins supply control spacing, so flex gap is not required.

JavaScript updates the width:

```javascript
document.getElementById('information').style.flexBasis = value + 'px';
```

The width is bounded so the sidebar remains usable and space is preserved for the document where possible.

The divider supports mouse/touch dragging and keyboard input:

- Left/Right: change width by 10 pixels.
- Home: use minimum width.
- End: use maximum permitted width.

The right panel scrolls independently. Resizing does not modify saved coordinates. Setting `min-height: 0` on the document panel and scrolling region allows those areas to stay within the available height rather than expanding to contain every page.

## 22. Setup, recovery, and validation scripts

| Script | Purpose |
| --- | --- |
| [scripts/password.php](scripts/password.php) | Generates a password hash from a password you enter |
| [scripts/setup.php](scripts/setup.php) | Ensures the drawing table exists and pre-renders standard images |
| [scripts/reset-drawings.php](scripts/reset-drawings.php) | Privately archives the saved row, then removes it |
| [tests/validation.php](tests/validation.php) | Checks metadata and drawing validation |
| [tests/legacy-syntax.cjs](tests/legacy-syntax.cjs) | Parses all deployed browser scripts as ES5 with Acorn |
| [tests/compat.cjs](tests/compat.cjs) | Checks legacy DOM/string/collection and Unicode byte-count fallbacks |
| [tests/legacy-environment.cjs](tests/legacy-environment.cjs) | Removes modern APIs and suppresses native pointer events in a modern test browser |
| [tests/run-legacy.cjs](tests/run-legacy.cjs) | Portable runner for `npm run test:legacy`, including the browser property suite in fallback mode |
| [tests/firefox52-browser.cjs](tests/firefox52-browser.cjs) | Native Firefox 52.0 integration checks using geckodriver 0.17 and isolated mock APIs |
| [tests/pdf-url-import.cjs](tests/pdf-url-import.cjs) | Uses local HTTP fixtures to check URL imports, redirects, private caching, validation, cleanup, and bundled-source fallback |
| [tests/watermarks.php](tests/watermarks.php) | Checks PHP watermark positions, random angles, rotated bounds, pixel opacity, identity, cache isolation, and the real page-image endpoint |
| [tests/drawing-properties.cjs](tests/drawing-properties.cjs) | Checks drawing geometry updates, bounds, rotation, opacity, and legacy rendering |
| [tests/drawing-properties-browser.cjs](tests/drawing-properties-browser.cjs) | Uses mocked APIs to check selection, property edits, immediate color input, inline text, draft validation, zoom/rotation, Undo, and Save/reload |
| [tests/viewer-controls.cjs](tests/viewer-controls.cjs) | Exercises the live viewer/editor against an empty disposable test database; saves annotations |
| [tests/image-loading.cjs](tests/image-loading.cjs) | Checks delayed, failed, and retried page-image loading with mocked image responses |

Generate a password hash:

```text
php scripts/password.php
```

Prepare the table and images after creating/configuring the database:

```text
php scripts/setup.php
```

Run validation checks:

```text
php tests/validation.php
php tests/watermarks.php
node tests/drawing-properties.cjs
node tests/drawing-properties-browser.cjs
```

The browser test requires Playwright and Chrome (or a supported `TEST_BROWSER_CHANNEL`). Node and Playwright are development tools, not application runtime dependencies. PHP watermark rendering requires GD with FreeType and the configured TrueType font. `tests/watermarks.php` tests image composition and the actual endpoint with its own temporary session, without writing annotation data to the database; it writes `tmp/watermark-preview.png` for visual inspection. Use an empty disposable database and the documented test credentials for `tests/viewer-controls.cjs`, since that live test saves drawings.

Launch the local test server from the project directory:

```text
php -S 127.0.0.1:8080 -t public
```

Open the editor at `http://127.0.0.1:8080/edit.php` and the viewer at `http://127.0.0.1:8080/view.php`.

### Replacing the PDF

1. Close the editor.
2. Replace the private PDF.
3. Archive and reset the previous drawings:

   ```text
   php scripts/reset-drawings.php --archive-and-reset
   ```

4. Render the replacement document:

   ```text
   php scripts/setup.php
   ```

5. Reopen the editor and viewer.

The reset script writes the previous database row to `cache/archives/` before removing it. Preserve that private archive directory if you need the old annotations.

## 23. Suggested reading order

### Maintaining Chrome 49 / Firefox 52 support

Only `public/assets/compat.js`, `drawings.js`, and `review.js` are shipped to the browser, in that order. `npm run build` transforms the editable `browser-src/` files into ES5 with Babel. Async/await, optional chaining, destructuring, and object spread in source are compiled before deployment; Babel's helpers are embedded, and no external CDN, client compiler, or separate regenerator runtime is required. Native Promises and the ES2015 features retained as runtime calls are available in the target browsers.

`ReviewCompat.request()` uses same-origin XMLHttpRequest, parses JSON, preserves server error messages, and reports network errors/timeouts. `ReviewCompat.point()` uses `svg.createSVGPoint()` with the inverse SVG screen transform. `utf8Length()` counts Unicode bytes, including surrogate pairs, without TextEncoder. Element append/replace methods, NodeList iteration, Object.entries, Array.includes, and String.padStart receive local fallbacks when absent.

Without Pointer Events, compatibility listeners translate mouse/touch events into the event shape expected by drawing and divider handlers. Capture is maintained locally so movement/release outside the original SVG still reaches the active drawing; cancellation and window blur release it. Touch interaction suppresses duplicate synthetic mouse input. Keyboard shortcuts and divider keys fall back to `keyCode` when `KeyboardEvent.key` is absent. Without IntersectionObserver, visibility checks use the scroll container's bounds and margins on scrolling/resizing; zoom and thumbnail visibility changes explicitly refresh them. Page scrolling and focus use older-compatible methods rather than newer scrolling option objects.

Use `npm ci`, `npm run build`, `npm run check:legacy`, and `npm run test:legacy` while maintaining browser source. The build requires Node 22.18+ in the 22.x line or Node 24.11+; deployed PHP hosting requires no Node installation. The compatibility test suite covers ES5 parsing and fallback behavior in current Chrome with newer features disabled. Native Firefox 52.0 checks also passed using `tests/firefox52-browser.cjs`: page images, selection, immediate color, opacity/angle/size, inline Unicode text, mouse drawing, zoom, rotation, thumbnails, navigation, saving, and View mode. These browser integration checks use mock APIs and do not verify a live database or PDF conversion. Chrome 49 remains unverified natively.

To repeat the native check, start geckodriver 0.17 on port 44452, set `TEST_FIREFOX_BINARY` to an actual Firefox 52.0 executable, and run `node tests/firefox52-browser.cjs`. Set `TEST_WEBDRIVER_URL` if using another driver address. The test asserts the reported browser version, uses a temporary profile with browser updates disabled, saves a screenshot to `tmp/firefox52-native.png`, and closes its browser session. The default binary location is an extracted test copy at `tmp/firefox52-tools/firefox52/core/firefox.exe`. Test tools under `tmp/` are excluded from deployment.

To follow execution from the browser page to persistence, read:

1. [public/edit.php](public/edit.php)
2. [src/page.php](src/page.php)
3. [src/bootstrap.php](src/bootstrap.php)
4. [public/assets/review.js](public/assets/review.js)
5. [public/assets/drawings.js](public/assets/drawings.js)
6. [public/api/drawing-save.php](public/api/drawing-save.php)
7. [src/AnnotationService.php](src/AnnotationService.php)
8. [src/PageRenderer.php](src/PageRenderer.php)
9. [src/WatermarkService.php](src/WatermarkService.php)
10. [config/watermark.php](config/watermark.php)

For an end-to-end example, trace a rectangle: pointer events create an object, the SVG renderer displays it, Save sends the full snapshot, PHP validates and stores it, and the viewer loads the same JSON to recreate the rectangle.

For watermark rendering, trace `src/page.php` session initialization, the page image request, `PageRenderer::image()`, `WatermarkService::settings()/layout()/image()`, and the PNG response from `public/api/page-image.php`.
