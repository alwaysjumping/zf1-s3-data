<?php
require dirname(__DIR__) . '/src/bootstrap.php';
$info = ReportService::info();
$base = ['reportId' => 1, 'formatVersion' => 1, 'pdfHash' => $info['pdfHash'], 'drawings' => []];
$text = ['id' => 'note-1', 'page' => 1, 'type' => 'text', 'color' => '#d62828', 'fontSize' => 14, 'position' => [0.2, 0.3], 'text' => "日本語 <script>alert(1)</script>\nReview"];
$valid = $base; $valid['drawings'] = [$text];
$passed = 0;
function check(bool $condition, string $name): void {
    global $passed;
    if (!$condition) throw new RuntimeException('FAILED: ' . $name);
    $passed++; echo 'PASS: ' . $name . PHP_EOL;
}
function rejected(array $data, int $status, string $name): void {
    global $info;
    try { AnnotationService::validate($data, $info); }
    catch (HttpError $e) { check($e->status === $status, $name); return; }
    throw new RuntimeException('FAILED: accepted ' . $name);
}
$styled = $valid; $styled['drawings'][0]['opacity'] = 0; $styled['drawings'][0]['rotation'] = -45;
check(AnnotationService::validate($styled, $info) === $styled['drawings'], 'Opacity and rotation preserved');
foreach ([-0.1, 1.1, INF, '0.5', null] as $value) {
    $bad = $valid; $bad['drawings'][0]['opacity'] = $value; rejected($bad, 400, 'Invalid opacity rejected');
}
foreach ([-361, 361, INF, '45', null] as $value) {
    $bad = $valid; $bad['drawings'][0]['rotation'] = $value; rejected($bad, 400, 'Invalid rotation rejected');
}
check($info['pageCount'] > 1 && $info['pages'][0]['width'] > 0, 'Multi-page PDF metadata');
check(AnnotationService::validate($base, $info) === [], 'Empty snapshot allowed');
check(AnnotationService::validate($valid, $info)[0]['text'] === $text['text'], 'Unicode and literal markup preserved');
$bad = $valid; $bad['drawings'][0]['position'] = [-0.1, 0.5]; rejected($bad, 400, 'Out-of-page coordinates rejected');
$bad = $valid; $bad['drawings'][0]['fontSize'] = INF; rejected($bad, 400, 'Non-finite size rejected');
$bad = $valid; $bad['drawings'][] = $text; rejected($bad, 400, 'Duplicate IDs rejected');
$bad = $valid; $bad['drawings'][0]['page'] = $info['pageCount'] + 1; rejected($bad, 400, 'Unknown page rejected');
$bad = $valid; $bad['drawings'][0]['text'] = str_repeat('日', 334); rejected($bad, 400, 'UTF-8 byte limit enforced');
$bad = $valid; $bad['drawings'][0]['color'] = 'url(javascript:alert(1))'; rejected($bad, 400, 'Non-hex color rejected');
$bad = $valid; $bad['pdfHash'] = str_repeat('0', 64); rejected($bad, 409, 'Changed PDF rejected');
$bad = $valid; $bad['reportId'] = 2; rejected($bad, 404, 'Unknown report rejected');
$bad = $valid; $bad['formatVersion'] = 2; rejected($bad, 400, 'Unknown format rejected');
foreach (['pen', 'rectangle', 'arrow'] as $type) {
    $shape = ['id' => $type, 'page' => 1, 'type' => $type, 'color' => '#112233', 'lineWidth' => 2, 'points' => [[0, 0], [1, 1]]];
    $data = $base; $data['drawings'] = [$shape];
    check(count(AnnotationService::validate($data, $info)) === 1, $type . ' accepted');
    $data['drawings'][0]['points'] = [[0, 0]]; rejected($data, 400, $type . ' incomplete points rejected');
}
echo $passed . " checks passed.\n";
