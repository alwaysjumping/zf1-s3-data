// Isolated browser network fixtures. TEST_SESSION_FILE must reference a session
// created specifically for this test; never reuse a user's browser session.
const {chromium} = require('playwright');
const fs = require('node:fs');
const assert = require('node:assert/strict');
(async () => {
  const session = fs.readFileSync(process.env.TEST_SESSION_FILE, 'utf8').trim();
  const browser = await chromium.launch({headless: true, channel: 'chrome'});
  const context = await browser.newContext({viewport: {width: 1300, height: 900}});
  await context.addCookies([{name: 'report_review', value: session, url: 'http://localhost:3010'}]);
  const page = await context.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aX1sAAAAASUVORK5CYII=', 'base64');
  const hash = '0'.repeat(64);
  await page.route('**/api/report-info.php*', r => r.fulfill({json: {reportId: 1, title: 'Loading test', author: 'Test', pdfHash: hash, pageCount: 2, pages: [1, 2].map(page => ({page, width: 595, height: 842}))}}));
  await page.route('**/api/drawing-load.php*', r => r.fulfill({json: {reportId: 1, pdfHash: hash, formatVersion: 1, drawings: []}}));
  let release; const delayed = new Promise(resolve => release = resolve);
  let scenario = 'delayed', attempts = 0;
  await page.route('**/api/page-image.php*', async r => {
    const url = new URL(r.request().url());
    if (url.searchParams.get('page') === '1') {
      attempts++;
      if (scenario === 'delayed') await delayed;
      if (scenario === 'failed' || (scenario === 'transient' && attempts === 1)) {
        await r.fulfill({status: 500, json: {error: 'Test rendering failure'}}); return;
      }
    }
    await r.fulfill({contentType: 'image/png', body: png});
  });
  try {
    await page.goto('http://localhost:3010/view.php');
    await page.locator('.page-placeholder').first().waitFor();
    assert.equal(await page.locator('.page img').first().isVisible(), false);
    assert.match(await page.locator('.page-placeholder').first().textContent(), /Loading/);
    release(); await page.waitForFunction(() => document.querySelector('.page')?.classList.contains('loaded'));
    assert.equal(await page.locator('.page-placeholder').first().isVisible(), false);
    assert.ok(await page.locator('.page img').first().evaluate(img => img.naturalWidth > 0));
    scenario = 'transient'; attempts = 0;
    await page.reload(); await page.waitForFunction(() => document.querySelector('.page')?.classList.contains('loaded'));
    assert.equal(attempts, 2, 'One temporary error automatically recovers');
    scenario = 'failed'; attempts = 0;
    await page.getByLabel('Zoom', {exact: true}).selectOption('2');
    await page.locator('.page.failed').first().waitFor();
    assert.equal(attempts, 3, 'Automatic retries are bounded');
    assert.equal(await page.locator('.page img').first().isVisible(), true, 'Keep existing image if sharper version fails');
    assert.equal(await page.locator('.page-placeholder').first().isVisible(), false);
    scenario = 'ok'; await page.getByRole('button', {name: 'Retry image', exact: true}).first().click();
    await page.waitForFunction(() => !document.querySelector('.page').classList.contains('failed'));
    scenario = 'failed'; attempts = 0;
    await page.getByRole('button', {name: 'Thumbnails', exact: true}).click();
    await page.waitForFunction(() => document.querySelector('.thumbnail-placeholder').textContent.includes('Preview unavailable'));
    assert.equal(await page.locator('.thumbnail img').first().isVisible(), false);
    assert.equal(attempts, 3);
    scenario = 'ok'; await page.getByRole('button', {name: 'Go to page 1', exact: true}).click();
    await page.waitForFunction(() => document.querySelector('.thumbnail-placeholder').hidden);
    assert.ok(await page.locator('.thumbnail img').first().evaluate(img => img.naturalWidth > 0));
    assert.deepEqual(errors, []);
    console.log('PASS: delayed images show a loading placeholder, no broken icons, bounded automatic retries, retained fallback image, page retry, and thumbnail recovery.');
  } finally {await browser.close();}
})().catch(e => {console.error(e); process.exit(1);});
