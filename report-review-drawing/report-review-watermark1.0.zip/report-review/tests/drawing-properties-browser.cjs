// Fully mocked APIs: does not require credentials or alter the report/database.
const {chromium} = require('playwright');
const fs = require('node:fs');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch({headless: true, channel: process.env.TEST_BROWSER_CHANNEL || 'chrome'});
  const page = await browser.newPage({viewport: {width: 1500, height: 1000}});
  const legacy = process.env.TEST_LEGACY === '1';
  if (legacy) await require('./legacy-environment.cjs')(page);
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  const hash = '0'.repeat(64);
  let snapshot = [
    {id: 'rect', page: 1, type: 'rectangle', color: '#112233', lineWidth: 2, points: [[.1, .1], [.3, .2]]},
    {id: 'arrow', page: 1, type: 'arrow', color: '#112233', lineWidth: 2, points: [[.4, .3], [.6, .3]]},
    {id: 'text', page: 1, type: 'text', color: '#112233', fontSize: 14, position: [.4, .5], text: 'Test note'},
    {id: 'pen', page: 1, type: 'pen', color: '#112233', lineWidth: 2, points: [[.1, .6], [.2, .7], [.3, .6]]}
  ];
  let html = fs.readFileSync('src/page.php', 'utf8').split('<!doctype html>')[1];
  html = '<!doctype html>' + html.replace(/<\?(?:php|=)[\s\S]*?\?>/g, '').replace('data-mode=""', 'data-mode="edit"');
  await page.route('http://drawing.test/**', async route => {
    const path = new URL(route.request().url()).pathname;
    if (path.endsWith('report-info.php')) return route.fulfill({json: {title: 'Property test', author: 'Test', pdfHash: hash, pageCount: legacy ? 2 : 1, pages: (legacy ? [1, 2] : [1]).map(page => ({page, width: 600, height: 800}))}});
    if (path.endsWith('drawing-load.php')) return route.fulfill({json: {pdfHash: hash, formatVersion: 1, drawings: snapshot}});
    if (path.endsWith('drawing-save.php')) { snapshot = route.request().postDataJSON().drawings; return route.fulfill({json: {ok: true}}); }
    if (path.endsWith('page-image.php')) return route.fulfill({contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800"><rect width="600" height="800" fill="white"/></svg>'});
    if (path.startsWith('/assets/')) {
      let body = fs.readFileSync('public' + path);
      if (legacy && path.endsWith('.css')) body = body.toString().replace(/display:grid;?|grid-template-columns:[^;}]+;?|gap:[^;}]+;?|height:calc\(100dvh[^;]+;/g, '');
      return route.fulfill({contentType: path.endsWith('.js') ? 'text/javascript' : 'text/css', body});
    }
    return route.fulfill({contentType: 'text/html', body: html});
  });
  const edit = async (label, value) => { const input = page.getByLabel(label, {exact: true}); await input.fill(String(value)); await input.press('Tab'); };
  const select = async id => {
    const node = page.locator(`g[data-id="${id}"] > :first-child`);
    await node.scrollIntoViewIfNeeded();
    const point = await node.evaluate(el => {
      const box = el.getBBox();
      const p = el.ownerSVGElement.createSVGPoint();
      const middle = el.tagName === 'path' ? el.getPointAtLength(el.getTotalLength() / 2) : {x: box.x + box.width / 2, y: box.y + box.height / 2};
      p.x = middle.x; p.y = middle.y;
      const screen = p.matrixTransform(el.getScreenCTM());
      return {x: screen.x, y: screen.y};
    });
    await page.mouse.click(point.x, point.y);
    assert.equal(await page.locator(`g[data-id="${id}"]`).getAttribute('class'), 'selected');
  };
  try {
    await page.goto('http://drawing.test/edit.php');
    await page.waitForFunction(() => document.querySelector('.page')?.classList.contains('loaded'));
    await page.getByRole('button', {name: 'Edit', exact: true}).click();
    assert.equal(await page.locator('#drawing-properties').isVisible(), false);
    await select('rect');
    assert.equal(await page.getByLabel('Line length', {exact: true}).isVisible(), false);
    await edit('Drawing width', 180); await edit('Drawing height', 100);
    await edit('Position X', 90); await edit('Position Y', 100);
    await edit('Drawing thickness', 1.25); await edit('Drawing angle', 30); await edit('Drawing opacity', 40);
    assert.match(await page.locator('g[data-id="rect"]').getAttribute('transform'), /rotate\(30/);
    await page.getByLabel('Drawing color', {exact: true}).fill('#2255aa'); await page.getByLabel('Drawing color', {exact: true}).dispatchEvent('input');
    assert.equal(await page.locator('g[data-id="rect"] rect[stroke-linecap]').getAttribute('stroke'), '#2255aa', 'Picker input applies immediately before change or blur');
    await page.getByLabel('Zoom', {exact: true}).selectOption('1.25');
    assert.equal(await page.getByLabel('Drawing color', {exact: true}).inputValue(), '#2255aa', 'Redraw does not reset chosen color');
    await page.getByLabel('Zoom', {exact: true}).selectOption('1');
    await select('arrow');
    assert.equal(await page.getByLabel('Drawing width', {exact: true}).isVisible(), false);
    await edit('Line length', 150); await edit('Drawing angle', 90);
    await edit('Line length', 10000);
    assert.match(await page.locator('#status').textContent(), /within the page/);
    assert.equal(Number(await page.getByLabel('Line length', {exact: true}).inputValue()), 150);
    await select('text');
    await page.getByRole('button', {name: 'Edit text', exact: true}).click();
    assert.equal(await page.locator('dialog').count(), 0, 'Text editing opens directly on the page');
    assert.equal(await page.locator('.page-content #inline-text-editor').count(), 1);
    await page.getByLabel('Annotation text', {exact: true}).fill('Updated 日本語\nSecond line');
    await page.getByLabel('Annotation text', {exact: true}).press('Control+Enter');
    assert.equal(await page.locator('g[data-id="text"] text').textContent(), 'Updated 日本語Second line');
    await page.getByRole('button', {name: 'Edit text', exact: true}).click();
    await page.getByLabel('Annotation text', {exact: true}).fill('Cancelled change');
    await page.getByLabel('Annotation text', {exact: true}).press('Escape');
    assert.equal(await page.locator('g[data-id="text"] text').textContent(), 'Updated 日本語Second line');
    await page.getByRole('button', {name: 'Edit text', exact: true}).click();
    await page.getByLabel('Annotation text', {exact: true}).fill('日'.repeat(334));
    await page.getByRole('button', {name: 'Update note', exact: true}).click();
    assert.equal(await page.locator('#inline-text-editor').isVisible(), true, 'Invalid UTF-8 byte length keeps editor open');
    await page.getByRole('button', {name: 'Cancel', exact: true}).click();
    assert.equal(await page.getByLabel('Drawing thickness', {exact: true}).isVisible(), false);
    await edit('Note font size', 19.5); await edit('Drawing angle', -15); await edit('Drawing opacity', 0);
    assert.equal(await page.locator('g[data-id="text"] text').getAttribute('opacity'), '0');
    assert.equal(await page.locator('g[data-id="text"] rect').getAttribute('opacity'), null);
    await page.getByRole('button', {name: 'Undo', exact: true}).click();
    assert.equal(await page.locator('g[data-id="text"] text').getAttribute('opacity'), '1');
    await select('pen'); await edit('Drawing width', 150); await edit('Drawing height', 60);
    await page.getByRole('button', {name: 'Text', exact: true}).click();
    await page.getByLabel('Drawing color', {exact: true}).fill('#008844');
    await page.getByLabel('Drawing color', {exact: true}).dispatchEvent('input');
    const svg = page.locator('.page svg').first();
    await svg.scrollIntoViewIfNeeded();
    const point = await svg.evaluate(el => { const p = el.createSVGPoint(); p.x = 420; p.y = 80; const screen = p.matrixTransform(el.getScreenCTM()); return {x: screen.x, y: screen.y}; });
    await page.mouse.click(point.x, point.y);
    await page.getByLabel('Annotation text', {exact: true}).fill('Inline draft');
    await page.getByLabel('Zoom', {exact: true}).selectOption('2');
    assert.equal(await page.locator('#inline-text-editor').isVisible(), true);
    assert.equal(await page.getByLabel('Annotation text', {exact: true}).inputValue(), 'Inline draft');
    await page.getByRole('button', {name: 'Rotate current page right', exact: true}).click();
    assert.equal(await page.locator('#inline-text-editor').isVisible(), true);
    await page.getByRole('button', {name: 'Save drawings', exact: true}).click();
    await page.waitForFunction(() => document.querySelector('#status').textContent === 'All changes saved');
    assert.equal(snapshot[0].color, '#2255aa'); assert.equal(snapshot[0].lineWidth, 1.25); assert.equal(snapshot[0].opacity, .4); assert.equal(snapshot[0].rotation, 30);
    assert.equal(snapshot[2].fontSize, 19.5); assert.equal(snapshot[2].rotation, -15);
    assert.equal(snapshot[2].text, 'Updated 日本語\nSecond line');
    assert.equal(snapshot.at(-1).text, 'Inline draft', 'Save applies an unfinished inline text draft');
    assert.equal(snapshot.at(-1).color, '#008844', 'Clicking the PDF preserves the selected color for new text');
    await page.reload(); await page.waitForFunction(() => document.querySelector('g[data-id="rect"]'));
    assert.match(await page.locator('g[data-id="rect"]').getAttribute('transform'), /rotate\(30/);
    assert.equal(await page.locator('g[data-id="rect"] rect').last().getAttribute('opacity'), '0.4');
    if (legacy) {
      assert.equal(await page.evaluate(() => typeof window.PointerEvent), 'undefined');
      assert.equal(await page.evaluate(() => typeof window.fetch), 'undefined');
      assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector('.workspace')).display), 'flex');
      await page.getByRole('button', {name: 'Edit', exact: true}).click();
      await page.getByRole('button', {name: 'Pen', exact: true}).click();
      const svg = page.locator('.page svg').first();
      await svg.scrollIntoViewIfNeeded();
      const locations = await svg.evaluate(el => [[400, 120], [440, 150]].map(coords => { const p = el.createSVGPoint(); p.x = coords[0]; p.y = coords[1]; const s = p.matrixTransform(el.getScreenCTM()); return {x: s.x, y: s.y}; }));
      await page.mouse.move(locations[0].x, locations[0].y); await page.mouse.down(); await page.mouse.move(locations[1].x, locations[1].y, {steps: 4}); await page.mouse.up();
      assert.equal(await svg.locator('g').count(), 6, 'Legacy mouse events create a pen stroke');
      await svg.evaluate(el => {
        const from = el.createSVGPoint(); from.x = 400; from.y = 220;
        const to = el.createSVGPoint(); to.x = 460; to.y = 260;
        const points = [from.matrixTransform(el.getScreenCTM()), to.matrixTransform(el.getScreenCTM())];
        ['touchstart', 'touchmove', 'touchend'].forEach((name, index) => {
          const event = document.createEvent('Event'); event.initEvent(name, true, true);
          const p = points[index ? 1 : 0];
          event.changedTouches = [{identifier: 3, target: el, clientX: p.x, clientY: p.y}];
          (index ? document.body : el).dispatchEvent(event);
        });
      });
      assert.equal(await svg.locator('g').count(), 7, 'Legacy touch events keep drawing captured outside the SVG');
      await page.waitForTimeout(850); // Synthetic mouse suppression after touch ends.
      const beforeWidth = await page.locator('#information').evaluate(el => el.getBoundingClientRect().width);
      const divider = await page.locator('#divider').boundingBox();
      await page.mouse.move(divider.x + 4, divider.y + 80); await page.mouse.down(); await page.mouse.move(divider.x + 44, divider.y + 80); await page.mouse.up();
      assert.ok(await page.locator('#information').evaluate(el => el.getBoundingClientRect().width) > beforeWidth, 'Legacy mouse events resize sidebar');
      await page.getByRole('button', {name: 'Thumbnails', exact: true}).click();
      await page.locator('.thumbnail-placeholder').first().waitFor({state: 'hidden'});
      await page.getByLabel('Page selector', {exact: true}).selectOption('2');
      await page.locator('.page').nth(1).waitFor({state: 'visible'});
      await page.waitForFunction(() => document.querySelectorAll('.page')[1].classList.contains('loaded'));
      await page.getByLabel('Page selector', {exact: true}).selectOption('1');
      assert.equal(await page.getByLabel('Page selector', {exact: true}).inputValue(), '1');
      await page.screenshot({path: 'tmp/legacy-fallback-editor.png'});
    }
    assert.deepEqual(errors, []);
    console.log((legacy ? 'Legacy fallback: ' : '') + 'Browser selection, type-specific controls, geometry edits, undo, save, and reload passed.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
