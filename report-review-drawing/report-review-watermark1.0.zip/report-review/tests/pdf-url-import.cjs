// Local HTTP fixtures only. No external download or annotation database writes.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {execFile} = require('node:child_process');
const assert = require('node:assert/strict');
const pdf = fs.readFileSync('pdfs/test_report.pdf');
const requests = new Map(), urls = [];
const server = http.createServer((req, res) => {
  requests.set(req.url, (requests.get(req.url) || 0) + 1);
  if (req.url === '/pdf') { res.setHeader('Content-Type', 'application/pdf'); return res.end(pdf); }
  if (req.url === '/redirect') { res.writeHead(302, {Location: '/pdf'}); return res.end('<html>' + 'Redirecting'.repeat(300) + '</html>'); }
  if (req.url === '/loop') { res.writeHead(302, {Location: '/loop'}); return res.end(); }
  if (req.url === '/html') return res.end('<html>Login required</html>');
  if (req.url === '/broken') return res.end('%PDF-1.4\nNot a valid PDF');
  if (req.url === '/partial') { res.writeHead(206); return res.end(pdf.subarray(0, 100)); }
  res.writeHead(404); res.end('Not found');
});
const php = `require 'src/bootstrap.php'; $config['pdf_url'] = $argv[1];
try { $file = PdfSource::path(); $info = ReportService::info();
echo json_encode(['ok' => true, 'path' => $file, 'hash' => $info['pdfHash'], 'pages' => $info['pageCount']]); }
catch (Throwable $e) { echo json_encode(['ok' => false, 'error' => $e->getMessage()]); }`;
const run = url => new Promise((resolve, reject) => execFile(process.env.TEST_PHP_BINARY || 'php', ['-r', php, url], {cwd: process.cwd(), timeout: 65000}, (error, stdout, stderr) => {
  if (error || stderr) return reject(error || new Error(stderr));
  try { resolve(JSON.parse(stdout)); } catch (e) { reject(e); }
}));
(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const sourceHash = crypto.createHash('sha256').update(pdf).digest('hex');
  try {
    const bundled = await run(''); assert.equal(bundled.ok, true);
    for (const route of ['/pdf', '/redirect']) {
      const url = origin + route; urls.push(url);
      const data = await run(url);
      assert.equal(data.ok, true); assert.equal(data.hash, sourceHash); assert.equal(data.pages, bundled.pages);
      assert.ok(data.path.includes('/cache/imported-pdfs/'));
      const before = requests.get(route);
      assert.deepEqual(await run(url), data);
      assert.equal(requests.get(route), before, 'Previously imported URLs are served from private cache');
    }
    for (const route of ['/html', '/broken', '/missing', '/loop', '/partial']) {
      const url = origin + route; urls.push(url);
      assert.equal((await run(url)).ok, false, `Reject invalid source ${route}`);
      const directory = path.resolve('cache/imported-pdfs', crypto.createHash('sha256').update(url).digest('hex'));
      assert.equal(fs.existsSync(path.join(directory, 'source.pdf')), false, 'Failed import is never published');
      assert.deepEqual(fs.readdirSync(directory), ['import.lock'], 'Failed imports leave no partial downloads');
    }
    for (const url of ['file:///etc/passwd', 'ftp://example.com/file.pdf', 'https://user:password@example.com/file.pdf', 'not a URL']) assert.equal((await run(url)).ok, false);
    const local = await run('');
    assert.equal(local.ok, true); assert.equal(local.hash, sourceHash); assert.ok(local.path.endsWith('/pdfs/test_report.pdf'));
    assert.equal(crypto.createHash('sha256').update(fs.readFileSync('pdfs/test_report.pdf')).digest('hex'), sourceHash);
    console.log('HTTP PDF import, redirects, private caching, source selection, invalid responses, cleanup, and local fallback passed.');
  } finally {
    await new Promise(resolve => server.close(resolve));
    const root = path.resolve('cache/imported-pdfs');
    for (const url of urls) {
      const directory = path.resolve(root, crypto.createHash('sha256').update(url).digest('hex'));
      if (path.dirname(directory) !== root) throw new Error('Unexpected cleanup target');
      if (!fs.existsSync(directory)) continue;
      for (const file of fs.readdirSync(directory)) fs.unlinkSync(path.join(directory, file));
      fs.rmdirSync(directory);
    }
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
