module.exports = async function legacyEnvironment(page) {
  await page.addInitScript(() => {
    const NativePointerEvent = window.PointerEvent;
    ['pointerdown', 'pointermove', 'pointerup', 'pointercancel', 'lostpointercapture'].forEach(name => {
      document.addEventListener(name, event => {
        if (NativePointerEvent && event instanceof NativePointerEvent) event.stopImmediatePropagation();
      }, true);
    });
    for (const name of ['PointerEvent', 'IntersectionObserver', 'DOMPoint', 'TextEncoder', 'fetch']) Object.defineProperty(window, name, {value: undefined, configurable: true});
    for (const name of ['append', 'replaceChildren', 'replaceWith', 'scrollTo']) Object.defineProperty(Element.prototype, name, {value: undefined, configurable: true, writable: true});
    NodeList.prototype.forEach = undefined;
    Object.entries = undefined;
    Array.prototype.includes = undefined;
    String.prototype.padStart = undefined;
    Object.defineProperty(KeyboardEvent.prototype, 'key', {get() { return undefined; }, configurable: true});
  });
};
