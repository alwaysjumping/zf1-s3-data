<?php
require dirname(__DIR__) . '/src/bootstrap.php';
$passed = 0;
function watermarkCheck(bool $ok, string $message): void {
    global $passed;
    if (!$ok) throw new RuntimeException('FAILED: ' . $message);
    $passed++; echo 'PASS: ' . $message . PHP_EOL;
}
$settings = require ROOT . '/config/watermark.php';
$settings['seed'] = str_repeat('a', 64);
$geometry = ['page' => 1, 'width' => 600, 'height' => 800];
$_SESSION = [];
WatermarkService::initialize();
$sessionSettings = WatermarkService::settings(); WatermarkService::initialize();
watermarkCheck(WatermarkService::settings() === $sessionSettings, 'Session identity and timestamp remain stable across image requests');
$positions = WatermarkService::layout($geometry, $settings);
watermarkCheck(count($positions) === 3, 'Default count is three');
watermarkCheck(count(array_unique(array_column($positions, 'angle'))) === 3, 'Each watermark has an independent random angle');
foreach ($positions as $mark) watermarkCheck($mark['angle'] >= -35 && $mark['angle'] <= 35, 'Random angle stays within configured range');
foreach ([0, 90, -90, 180, -180, 360] as $angle) {
    $fixed = $settings; $fixed['angleMin'] = $angle; $fixed['angleMax'] = $angle;
    foreach (WatermarkService::layout($geometry, $fixed) as $mark) {
        watermarkCheck($mark['angle'] === (float)$angle && $mark['x'] >= 0 && $mark['y'] >= 0 && $mark['x'] + $mark['width'] <= 600 && $mark['y'] + $mark['height'] <= 800, 'Rotated multiline block fits inside page');
    }
}
$reversed = $settings; $reversed['angleMin'] = 40; $reversed['angleMax'] = -40;
try { WatermarkService::layout($geometry, $reversed); throw new LogicException('Invalid rotation range accepted.'); }
catch (RuntimeException $e) { watermarkCheck(strpos($e->getMessage(), 'minimum angle') !== false, 'Invalid rotation range rejected'); }
watermarkCheck($positions === WatermarkService::layout($geometry, $settings), 'Same page retains positions across resolutions');
$otherPage = $geometry; $otherPage['page'] = 2;
watermarkCheck($positions !== WatermarkService::layout($otherPage, $settings), 'Each page has independent positions');
$otherUser = $settings; $otherUser['seed'] = str_repeat('b', 64);
watermarkCheck($positions !== WatermarkService::layout($geometry, $otherUser), 'Different sessions generate different positions');
foreach ([0, 1, 3, 7, 100] as $count) {
    $configured = $settings; $configured['count'] = $count;
    foreach ([$geometry, ['page' => 2, 'width' => 800, 'height' => 600]] as $page) {
        $marks = WatermarkService::layout($page, $configured);
        watermarkCheck(count($marks) === $count, 'Configured count applies to portrait and landscape pages');
        $unique = [];
        foreach ($marks as $mark) {
            if ($mark['x'] < 0 || $mark['y'] < 0 || $mark['x'] + $mark['width'] > $page['width'] || $mark['y'] + $mark['height'] > $page['height']) throw new RuntimeException('Mark exceeds page bounds.');
            $unique[] = $mark['x'] . ':' . $mark['y'];
        }
        watermarkCheck(count(array_unique($unique)) === $count, 'Marks have distinct positions and fit inside page');
    }
}
$temporary = tempnam(sys_get_temp_dir(), 'watermark-test-');
try {
    $source = imagecreatetruecolor(600, 800); imagefill($source, 0, 0, imagecolorallocate($source, 255, 255, 255));
    imagepng($source, $temporary); imagedestroy($source);
    $original = file_get_contents($temporary);
    $result = WatermarkService::image($temporary, $geometry, $settings);
    watermarkCheck($result !== $original, 'PHP embeds watermark pixels in PNG');
    watermarkCheck(file_get_contents($temporary) === $original, 'Shared clean image cache remains unchanged');
    watermarkCheck($result === WatermarkService::image($temporary, $geometry, $settings), 'Repeated requests produce the same personalized image');
    $opaque = $settings; $opaque['opacity'] = 1;
    $opaqueImage = imagecreatefromstring(WatermarkService::image($temporary, $geometry, $opaque));
    $faintImage = imagecreatefromstring($result);
    $transparent = $settings; $transparent['opacity'] = 0;
    $transparentImage = imagecreatefromstring(WatermarkService::image($temporary, $geometry, $transparent));
    $opaqueInk = 0; $faintInk = 0; $transparentInk = 0;
    for ($y = 0; $y < 800; $y++) for ($x = 0; $x < 600; $x++) {
        $opaqueInk += 255 - ((imagecolorat($opaqueImage, $x, $y) >> 16) & 255);
        $faintInk += 255 - ((imagecolorat($faintImage, $x, $y) >> 16) & 255);
        $transparentInk += 255 - ((imagecolorat($transparentImage, $x, $y) >> 16) & 255);
    }
    watermarkCheck($opaqueInk > $faintInk && $faintInk > 0 && $transparentInk === 0, 'Configured opacity controls embedded pixel darkness');
    imagedestroy($opaqueImage); imagedestroy($faintImage); imagedestroy($transparentImage);
    foreach ([-.1, 1.1, INF, '0.5'] as $invalid) {
        $bad = $settings; $bad['opacity'] = $invalid;
        try { WatermarkService::image($temporary, $geometry, $bad); throw new LogicException('Invalid opacity accepted.'); }
        catch (RuntimeException $e) { watermarkCheck(strpos($e->getMessage(), 'opacity') !== false, 'Invalid opacity rejected'); }
    }
    $personalized = $settings; $personalized['lines'][1] = 'Another viewer';
    watermarkCheck($result !== WatermarkService::image($temporary, $geometry, $personalized), 'Username changes image pixels');
    $disabled = $settings; $disabled['count'] = 0;
    watermarkCheck(WatermarkService::image($temporary, $geometry, $disabled) === $original, 'Server configuration can disable watermarking');
    $decoded = imagecreatefromstring($result);
    watermarkCheck(imagesx($decoded) === 600 && imagesy($decoded) === 800, 'Page dimensions remain unchanged');
    imagepng($decoded, ROOT . '/tmp/watermark-preview.png'); imagedestroy($decoded);
    $unavailable = $settings; $unavailable['font'] = ROOT . '/missing-font.ttf';
    try { WatermarkService::image($temporary, $geometry, $unavailable); throw new LogicException('Unwatermarked fallback unexpectedly allowed.'); }
    catch (RuntimeException $e) { watermarkCheck(strpos($e->getMessage(), 'TrueType') !== false, 'Missing font fails instead of serving an unwatermarked page'); }
} finally { unlink($temporary); }
$hash = ReportService::hash(); $clean = PageRenderer::image($hash, 1, 'standard'); $cleanHash = hash_file('sha256', $clean);
$code = 'session_name("report_review"); session_start(); $_SESSION["role"] = "view"; '
    . '$_SERVER["REQUEST_METHOD"] = "GET"; $_GET = ' . var_export(['reportId' => '1', 'page' => '1', 'level' => 'standard', 'pdfHash' => $hash, 'watermark_count' => '0', 'username' => 'Browser override'], true) . '; '
    . 'ob_start(); require ' . var_export(ROOT . '/public/api/page-image.php', true) . '; $bytes = ob_get_clean(); '
    . 'session_start(); $_SESSION = []; session_destroy(); echo $bytes;';
$process = proc_open([PHP_BINARY, '-r', $code], [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, ROOT);
fclose($pipes[0]); $bytes = stream_get_contents($pipes[1]); $errors = stream_get_contents($pipes[2]); fclose($pipes[1]); fclose($pipes[2]);
watermarkCheck(proc_close($process) === 0 && $errors === '', 'Real page-image endpoint completes without errors');
watermarkCheck(substr($bytes, 0, 8) === "\x89PNG\r\n\x1a\n", 'Endpoint returns PNG image pixels');
watermarkCheck(hash('sha256', $bytes) !== $cleanHash, 'Browser parameters cannot request an unwatermarked source image');
watermarkCheck(hash_file('sha256', $clean) === $cleanHash, 'Endpoint never replaces shared cached source image');
echo $passed . ' watermark checks passed.' . PHP_EOL;
