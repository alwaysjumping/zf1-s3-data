const assert = require('node:assert/strict');
const {chromium} = require('playwright');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch({headless: true, channel: process.env.TEST_BROWSER_CHANNEL || 'chrome'});
  const page = await browser.newPage();
  await require('./legacy-environment.cjs')(page);
  await page.goto('about:blank');
  await page.addScriptTag({content: fs.readFileSync('public/assets/compat.js', 'utf8')});
  const lengths = await page.evaluate(() => ['ASCII', '日本語', '😀', 'A😀日', '\ud800'].map(text => ReviewCompat.utf8Length(text)));
  assert.deepEqual(lengths, [5, 9, 4, 8, 3]);
  assert.deepEqual(await page.evaluate(() => [13, 27, 35, 36, 37, 39].map(keyCode => ReviewCompat.key({keyCode}))), ['Enter', 'Escape', 'End', 'Home', 'ArrowLeft', 'ArrowRight']);
  assert.deepEqual(await page.evaluate(() => { const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); const child = document.createElementNS(svg.namespaceURI, 'g'); svg.append(child); svg.replaceChildren(child); const other = document.createElementNS(svg.namespaceURI, 'path'); svg.append(other); other.replaceWith(child); return [svg.children.length, Object.entries({color: 'red'})[0], [1, 2].includes(2), '1'.padStart(2, '0')]; }), [1, ['color', 'red'], true, '01']);
  await browser.close();
  console.log('Legacy DOM, UTF-8, collection, and string fallbacks passed.');
})().catch(error => { console.error(error); process.exit(1); });
