// Run against an EMPTY, disposable test database. This test saves annotations.
// Requires Playwright, TEST_EDITOR_PASSWORD, and optionally TEST_VIEW_PASSWORD.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
  if (!process.env.TEST_EDITOR_PASSWORD) throw new Error('Set TEST_EDITOR_PASSWORD for an isolated test installation.');
  const browser = await chromium.launch({headless: true, channel: process.env.TEST_BROWSER_CHANNEL || 'chrome'});
  const context = await browser.newContext({viewport: {width: 1500, height: 1000}});
  const page = await context.newPage(); const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  const origin = process.env.TEST_BASE_URL || 'http://127.0.0.1:8088';
  const footer = page.locator('#drawing-toolbar');
  const status = text => page.waitForFunction(value => document.querySelector('#status').textContent.includes(value), text);
  const saved = async () => (await context.request.get(origin + '/api/drawing-load.php?reportId=1')).json();
  async function screenPoint(svg, x, y) {
    return svg.evaluate((el, p) => {
      const point = new DOMPoint(p.x * el.viewBox.baseVal.width, p.y * el.viewBox.baseVal.height).matrixTransform(el.getScreenCTM());
      return {x: point.x, y: point.y};
    }, {x, y});
  }
  async function drag(svg, a, b) {
    const from = await screenPoint(svg, ...a), to = await screenPoint(svg, ...b);
    await page.mouse.move(from.x, from.y); await page.mouse.down();
    await page.mouse.move(to.x, to.y, {steps: 8}); await page.mouse.up();
  }
  async function save() { await page.getByRole('button', {name: 'Save drawings'}).click(); await status('All changes saved'); }
  try {
    await page.goto(origin + '/edit.php');
    await page.getByLabel('Access password').fill(process.env.TEST_EDITOR_PASSWORD);
    await page.getByRole('button', {name: 'Open report'}).click(); await status('Ready to review');
    assert.equal((await saved()).drawings.length, 0, 'Use an empty test database');
    assert.equal(await footer.isVisible(), false);
    assert.equal(await page.getByRole('button', {name: 'Done', exact: true}).isDisabled(), true);
    await page.locator('.page.loaded').first().waitFor();
    const svg = page.locator('.page svg').first();
    await drag(svg, [.1, .1], [.3, .2]); assert.equal(await svg.locator('g').count(), 0);
    await page.getByRole('button', {name: 'Thumbnails', exact: true}).click();
    assert.equal(await page.locator('#thumbnails').isVisible(), true);
    await page.getByRole('button', {name: 'Go to page 3', exact: true}).click();
    await page.waitForFunction(() => document.querySelector('#page-selector').value === '3');
    await page.getByRole('button', {name: 'Previous page', exact: true}).click();
    assert.equal(await page.getByLabel('Page selector').inputValue(), '2');
    await page.getByLabel('Page selector').selectOption('1');
    await page.getByRole('button', {name: 'Thumbnails', exact: true}).click();
    await page.getByRole('button', {name: 'Zoom out', exact: true}).click();
    assert.equal(await page.getByLabel('Zoom', {exact: true}).inputValue(), '0.75');
    await page.getByRole('button', {name: 'Edit', exact: true}).click(); assert.equal(await footer.isVisible(), true);
    const footerBox = await footer.boundingBox(), pagesBox = await page.locator('#pages').boundingBox();
    assert.ok(footerBox.y >= pagesBox.y + pagesBox.height - 1, 'Toolbar is below the scrollable document');
    await page.getByRole('button', {name: 'Rectangle', exact: true}).click(); await drag(svg, [.1, .1], [.3, .2]);
    assert.equal(await svg.locator('g').count(), 1);
    await page.getByRole('button', {name: 'Done', exact: true}).click();
    assert.equal(await footer.isVisible(), false); assert.equal(await svg.locator('g').count(), 1);
    await drag(svg, [.4, .15], [.6, .3]); assert.equal(await svg.locator('g').count(), 1);
    assert.equal((await saved()).drawings.length, 0, 'Done does not silently save');
    await save();
    await page.getByRole('button', {name: 'Edit', exact: true}).click();
    await page.getByRole('button', {name: 'Select', exact: true}).click();
    await drag(svg, [.1, .15], [.2, .25]);
    await page.getByLabel('Drawing color').fill('#2255aa'); await page.getByLabel('Drawing color').dispatchEvent('change');
    await page.getByLabel('Drawing thickness').fill('4'); await page.getByLabel('Drawing thickness').press('Tab'); await save();
    let data = await saved(); assert.equal(data.drawings[0].color, '#2255aa'); assert.equal(data.drawings[0].lineWidth, 4);
    assert.ok(Math.abs(data.drawings[0].points[0][0] - .2) < .005);
    await page.getByRole('button', {name: 'Text', exact: true}).click();
    let pt = await screenPoint(svg, .4, .25); await page.mouse.click(pt.x, pt.y);
    await page.getByLabel('Annotation text').fill('Original note'); await page.getByRole('button', {name: 'Add note', exact: true}).click();
    await page.getByRole('button', {name: 'Select', exact: true}).click(); await svg.getByText('Original note').click();
    await page.getByRole('button', {name: 'Edit text', exact: true}).click();
    await page.getByLabel('Annotation text').fill('Updated 日本語 note'); await page.getByRole('button', {name: 'Update note', exact: true}).click();
    await page.getByLabel('Note font size').fill('20'); await page.getByLabel('Note font size').press('Tab');
    await page.getByRole('button', {name: 'Delete', exact: true}).click(); assert.equal(await svg.locator('text').count(), 0);
    await page.getByRole('button', {name: 'Undo', exact: true}).click(); assert.equal(await svg.locator('text').textContent(), 'Updated 日本語 note');
    await page.getByRole('button', {name: 'Done', exact: true}).click(); await save();
    const beforeRotate = await saved();
    await page.getByRole('button', {name: 'Rotate current page right', exact: true}).click();
    let dims = await page.locator('.page').first().boundingBox(); assert.ok(dims.width > dims.height);
    await page.getByRole('button', {name: 'Edit', exact: true}).click();
    await page.getByRole('button', {name: 'Arrow', exact: true}).click(); await drag(svg, [.4, .4], [.6, .5]);
    await page.getByRole('button', {name: 'Done', exact: true}).click(); await save();
    data = await saved(); const arrow = data.drawings.at(-1);
    assert.equal(arrow.type, 'arrow'); assert.ok(Math.abs(arrow.points[0][0] - .4) < .005); assert.ok(Math.abs(arrow.points[1][1] - .5) < .005);
    assert.deepEqual(data.drawings.slice(0, 2), beforeRotate.drawings, 'Rotation does not mutate existing annotations');
    // Verify the inverse coordinate mapping at every quarter-turn.
    for (const angle of [180, 270, 0]) {
      await page.getByRole('button', {name: 'Rotate current page right', exact: true}).click();
      await page.getByRole('button', {name: 'Edit', exact: true}).click();
      await page.getByRole('button', {name: 'Pen', exact: true}).click(); await drag(svg, [.45, .35], [.55, .4]);
      await page.getByRole('button', {name: 'Done', exact: true}).click(); await save();
      const stroke = (await saved()).drawings.at(-1);
      assert.equal(stroke.type, 'pen'); assert.ok(Math.abs(stroke.points[0][0] - .45) < .005, `Drawing at ${angle} degrees`);
    }
    await page.getByRole('button', {name: 'Zoom in', exact: true}).click(); assert.equal(await page.getByLabel('Zoom', {exact: true}).inputValue(), '1');
    await page.getByRole('button', {name: 'Next page', exact: true}).click();
    await page.getByRole('button', {name: 'Rotate current page left', exact: true}).click();
    assert.ok((await page.locator('.page').nth(1).boundingBox()).width > (await page.locator('.page').nth(1).boundingBox()).height);
    await page.getByLabel('Page selector').selectOption('1');
    await page.getByRole('button', {name: 'Edit', exact: true}).click();
    await page.screenshot({path: 'tmp/viewer-edit-mode.png'});
    await page.getByRole('button', {name: 'Done', exact: true}).click();
    await page.getByRole('button', {name: 'Thumbnails', exact: true}).click();
    await page.screenshot({path: 'tmp/viewer-done-mode.png'});
    await page.reload(); await status('Ready to review'); assert.equal(await footer.isVisible(), false);
    assert.equal(await page.locator('.page svg').first().locator('g').count(), 6);
    await page.goto(origin + '/view.php'); await status('Showing saved drawings');
    assert.equal(await page.getByRole('button', {name: 'Edit', exact: true}).count(), 0);
    assert.equal(await page.locator('#drawing-toolbar').count(), 0);
    assert.equal(await page.locator('.page svg').first().locator('g').count(), 6);
    assert.deepEqual(errors, []);
    console.log('PASS: view-first mode, footer visibility, Done lockout, explicit save, modify/move/text/delete/undo, thumbnails, page selector, zoom, all rotations, persistence, and read-only viewer.');
  } finally { await browser.close(); }
})().catch(error => {console.error(error); process.exit(1);});
