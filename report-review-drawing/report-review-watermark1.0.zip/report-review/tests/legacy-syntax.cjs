const fs = require('node:fs');
const acorn = require('acorn');
for (const name of ['compat', 'drawings', 'review']) {
  const file = `public/assets/${name}.js`;
  acorn.parse(fs.readFileSync(file, 'utf8'), {ecmaVersion: 5, sourceType: 'script'});
}
console.log('All deployed browser scripts parse as ES5.');
