// Native Firefox 52 integration test. Requires geckodriver 0.17 on port 44452.
// Uses isolated mock APIs; never reads or changes saved report annotations.
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const assert = require('node:assert/strict');
const driver = process.env.TEST_WEBDRIVER_URL || 'http://127.0.0.1:44452';
const binary = process.env.TEST_FIREFOX_BINARY || path.resolve('tmp/firefox52-tools/firefox52/core/firefox.exe');
let session;
let snapshot = [
  {id:'rect',page:1,type:'rectangle',color:'#112233',lineWidth:2,points:[[.1,.1],[.3,.2]]},
  {id:'text',page:1,type:'text',color:'#112233',fontSize:14,position:[.4,.5],text:'Test note'}
];
let html = '<!doctype html>' + fs.readFileSync('src/page.php','utf8').split('<!doctype html>')[1];
html = html.replace(/<\?(?:php|=)[\s\S]*?\?>/g,'').replace('data-mode=""','data-mode="edit"');
html = html.replace('<head>', '<head><script>window.testErrors=[];window.addEventListener("error",function(e){window.testErrors.push(e.message);});</script>');
const server = http.createServer((req,res) => {
  const url = new URL(req.url,'http://localhost');
  const json = value => {res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value));};
  if (url.pathname.endsWith('report-info.php')) return json({title:'Firefox 52 test',author:'Test',pdfHash:'0'.repeat(64),pageCount:2,pages:[1,2].map(page=>({page,width:600,height:800}))});
  if (url.pathname.endsWith('drawing-load.php')) return json({pdfHash:'0'.repeat(64),formatVersion:1,drawings:snapshot});
  if (url.pathname.endsWith('drawing-save.php')) {let body='';req.on('data',b=>body+=b);req.on('end',()=>{snapshot=JSON.parse(body).drawings;json({ok:true});});return;}
  if (url.pathname.endsWith('page-image.php')) {
    const png='tmp/watermark-preview.png';
    res.setHeader('Content-Type',fs.existsSync(png)?'image/png':'image/svg+xml');
    return res.end(fs.existsSync(png)?fs.readFileSync(png):'<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800"><rect width="600" height="800" fill="white"/></svg>');
  }
  if (/^\/assets\/[a-z-]+\.(js|css)$/.test(url.pathname)) {res.setHeader('Content-Type',url.pathname.endsWith('.js')?'text/javascript':'text/css');return res.end(fs.readFileSync('public'+url.pathname));}
  res.setHeader('Content-Type','text/html');res.end(url.pathname==='/view.php'?html.replace('data-mode="edit"','data-mode="view"'):html);
});
async function command(route,body,method=body===undefined?'GET':'POST') {
  const r=await fetch(driver+route,{method,headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(45000)});
  const data=await r.json();if(!r.ok||data.value?.error) throw Error(JSON.stringify(data));return data.value;
}
const exec = script=>command('/session/'+session+'/execute/sync',{script,args:[]});
const click = selector=>exec('document.querySelector('+JSON.stringify(selector)+').click();');
async function nativeClick(selector) {
  const element=await command('/session/'+session+'/element',{using:'css selector',value:selector});
  const id=element['element-6066-11e4-a52e-4f735466cecf']||element.ELEMENT;
  await command('/session/'+session+'/element/'+id+'/click',{});
}
const change = (selector,value,event='change')=>exec('var e=document.querySelector('+JSON.stringify(selector)+');e.value='+JSON.stringify(String(value))+';var ev=document.createEvent("Event");ev.initEvent('+JSON.stringify(event)+',true,true);e.dispatchEvent(ev);');
async function wait(script) {for(let i=0;i<100;i++){if(await exec('return '+script))return;await new Promise(r=>setTimeout(r,100));}throw Error('Timed out: '+script+'; '+await exec('return JSON.stringify(window.testErrors)'));}
const select = id=>exec('var g=document.querySelector("g[data-id='+id+']"),s=g.ownerSVGElement,p=s.createSVGPoint(),b=g.firstChild.getBBox();p.x=b.x+b.width/2;p.y=b.y+b.height/2;p=p.matrixTransform(g.getScreenCTM());["mousedown","mouseup"].forEach(function(t){var e=document.createEvent("MouseEvent");e.initMouseEvent(t,true,true,window,1,0,0,p.x,p.y,false,false,false,false,0,null);(t === "mouseup" ? document : g.firstChild).dispatchEvent(e);});');
(async()=>{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  try {
    const result=await command('/session',{desiredCapabilities:{browserName:'firefox','moz:firefoxOptions':{binary,prefs:{'app.update.enabled':false,'app.update.auto':false,'browser.shell.checkDefaultBrowser':false}}}});
    session=result.sessionId;
    assert.equal(result.capabilities.browserVersion,'52.0','Must test actual Firefox 52');
    console.log('Native browser:',result.capabilities.browserName,result.capabilities.browserVersion);
    const base='http://127.0.0.1:'+server.address().port;
    await command('/session/'+session+'/url',{url:base+'/edit.php'});
    await wait('document.querySelector(".page.loaded") && !document.getElementById("edit-mode").disabled');
    await nativeClick('#edit-mode');await select('rect');
    assert.equal(await exec('return document.querySelector("g[data-id=rect]").getAttribute("class")'),'selected');
    await change('#color','#2255aa','input');
    assert.equal(await exec('return document.querySelector("g[data-id=rect] rect[stroke-linecap]").getAttribute("stroke")'),'#2255aa');
    await change('#property-opacity',40);
    assert.equal(await exec('return document.querySelector("g[data-id=rect] rect[stroke-linecap]").getAttribute("opacity")'),'0.4');
    await change('#property-angle',30);await change('#property-width',180);
    assert.match(await exec('return document.querySelector("g[data-id=rect]").getAttribute("transform")'),/rotate\(30/);
    await select('text');await click('#edit-text');await change('#note-text','Updated 日本語\nSecond line','input');await click('#confirm-text');
    assert.equal(await exec('return document.querySelector("g[data-id=text] text").textContent'),'Updated 日本語Second line');
    await click('[data-tool=pen]');
    await exec('var s=document.querySelector(".page svg"),p=s.createSVGPoint();["mousedown","mousemove","mouseup"].forEach(function(t,i){p.x=80+i*25;p.y=300+i*15;var q=p.matrixTransform(s.getScreenCTM()),e=document.createEvent("MouseEvent");e.initMouseEvent(t,true,true,window,1,0,0,q.x,q.y,false,false,false,false,0,null);s.dispatchEvent(e);});');
    assert.equal(await exec('return document.querySelectorAll("g[data-id]").length'),3);
    await change('#zoom','1.25');await click('#rotate-right');
    await click('#toggle-thumbnails');assert.equal(await exec('return document.querySelectorAll("#thumbnails button").length'),2);
    await click('#save');await wait('document.getElementById("status").textContent.indexOf("saved") !== -1');
    assert.equal(snapshot.find(d=>d.id==='rect').color,'#2255aa');assert.equal(snapshot.find(d=>d.id==='rect').opacity,.4);
    assert.equal(snapshot.find(d=>d.id==='text').text,'Updated 日本語\nSecond line');
    assert.ok(snapshot.some(d=>d.type==='pen'&&d.points.length>=2));
    assert.deepEqual(await exec('return window.testErrors'),[]);
    fs.writeFileSync('tmp/firefox52-native.png',Buffer.from(await command('/session/'+session+'/screenshot'),'base64'));
    await click('#next-page');await wait('document.querySelectorAll(".page.loaded").length === 2');
    assert.equal(await exec('return document.getElementById("page-selector").value'),'2');
    await command('/session/'+session+'/url',{url:base+'/view.php'});await wait('document.querySelector(".page.loaded")');
    assert.equal(await exec('return document.getElementById("drawing-toolbar").hidden'),true);
    assert.deepEqual(await exec('return window.testErrors'),[]);
    console.log('Firefox 52: page images, selection, immediate color, properties, inline Unicode text, mouse drawing, zoom, rotation, thumbnails, navigation, save, and View mode passed.');
  } finally {if(session)await command('/session/'+session,undefined,'DELETE');await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;});

