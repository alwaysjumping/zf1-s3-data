const {spawnSync} = require('node:child_process');
for (const file of ['tests/legacy-syntax.cjs', 'tests/compat.cjs', 'tests/drawing-properties-browser.cjs']) {
  const result = spawnSync(process.execPath, [file], {stdio: 'inherit', env: {...process.env, TEST_LEGACY: '1'}});
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
