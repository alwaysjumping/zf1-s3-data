<?php
return [
    'dsn' => 'mysql:host=127.0.0.1;dbname=report_review_test;charset=utf8mb4',
    'user' => 'root',
    'password' => '',
    // Generate with: php scripts/password.php
    'edit_password_hash' => '',
    // Optional separate password for testing server-enforced view-only access.
    'view_password_hash' => '',
    'pdftoppm' => 'pdftoppm',
    'pdfinfo' => 'pdfinfo',
    // Server-side import; use a direct PDF link. Empty keeps the bundled PDF.
    'pdf_url' => '',
];
