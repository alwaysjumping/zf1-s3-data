<?php
// Copy local.example.php to local.php to override these defaults.
return array_replace([
    'dsn' => 'mysql:host=127.0.0.1;dbname=report_review;charset=utf8',
    'user' => 'root',
    'password' => '',
    'edit_password_hash' => '',
    'view_password_hash' => '',
    'pdftoppm' => 'pdftoppm',
    'pdfinfo' => 'pdfinfo',
    'pdf_url' => '', // Empty uses the bundled private PDF; otherwise PHP imports this HTTP/HTTPS URL.
], is_file(__DIR__ . '/local.php') ? require __DIR__ . '/local.php' : []);
