<?php
// Server-owned values; these are never accepted from browser requests.
$site_title = "Document View";
$username = "Danny Powel";
$datetime = date('Y-m-d H:i');
$watermark_count = 3;
$watermark_opacity = 0.28; // 0 = invisible, 1 = fully opaque.
$watermark_angle_min = -35; // Random rotation range in degrees.
$watermark_angle_max = 35;  // Set both to 0 to disable rotation.
$watermark_font = PHP_OS_FAMILY === 'Windows'
    ? 'C:/Windows/Fonts/arial.ttf'
    : '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';

return ['lines' => [$site_title, $username, $datetime], 'count' => $watermark_count, 'opacity' => $watermark_opacity,
    'angleMin' => $watermark_angle_min, 'angleMax' => $watermark_angle_max, 'font' => $watermark_font];
