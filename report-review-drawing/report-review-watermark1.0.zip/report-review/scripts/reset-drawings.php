<?php
if (PHP_SAPI !== 'cli') exit;
require dirname(__DIR__) . '/src/bootstrap.php';
if (($argv[1] ?? '') !== '--archive-and-reset') {
    fwrite(STDERR, "Usage: php scripts/reset-drawings.php --archive-and-reset\nBacks up the saved row privately, then deletes it. Close the editor first.\n"); exit(1);
}
$db = Database::connect(); $db->beginTransaction();
try {
    $row = $db->query('SELECT * FROM review_drawings WHERE report_id = 1 FOR UPDATE')->fetch();
    if ($row) {
        $dir = ROOT . '/cache/archives';
        if (!is_dir($dir) && !mkdir($dir, 0700, true)) throw new RuntimeException('Cannot create archive directory.');
        $file = $dir . '/drawings-' . gmdate('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.json';
        if (file_put_contents($file, json_encode($row, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), LOCK_EX) === false) throw new RuntimeException('Cannot write archive.');
        $db->exec('DELETE FROM review_drawings WHERE report_id = 1');
        echo 'Archived to ' . $file . PHP_EOL;
    }
    $db->commit(); echo "Drawings reset. Reload the editor.\n";
} catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); fwrite(STDERR, $e->getMessage() . PHP_EOL); exit(1); }
