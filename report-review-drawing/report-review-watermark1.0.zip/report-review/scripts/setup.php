<?php
if (PHP_SAPI !== 'cli') exit;
require dirname(__DIR__) . '/src/bootstrap.php';
try {
    $db = Database::connect();
    $db->exec('CREATE TABLE IF NOT EXISTS review_drawings (report_id INT UNSIGNED NOT NULL PRIMARY KEY, pdf_sha256 CHAR(64) NOT NULL, format_version SMALLINT UNSIGNED NOT NULL DEFAULT 1, drawings_json LONGTEXT NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB');
    echo "Drawing table is ready. Existing drawings were preserved.\n";
    $info = ReportService::info();
    foreach ($info['pages'] as $page) {
        PageRenderer::image($info['pdfHash'], $page['page'], 'standard');
        echo 'Rendered page ' . $page['page'] . '/' . $info['pageCount'] . PHP_EOL;
    }
    echo "Setup complete. Start PHP with public/ as the document root.\n";
} catch (Throwable $e) { fwrite(STDERR, $e->getMessage() . PHP_EOL); exit(1); }
