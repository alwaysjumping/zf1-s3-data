<?php
if (PHP_SAPI !== 'cli') exit;
fwrite(STDOUT, "Enter test password (input is visible in this terminal): ");
$password = rtrim(fgets(STDIN), "\r\n");
if ($password === '') { fwrite(STDERR, "Password must not be empty.\n"); exit(1); }
echo password_hash($password, PASSWORD_DEFAULT) . PHP_EOL;
