const fs = require('node:fs');
const babel = require('@babel/core');
const presetEnv = require('@babel/preset-env');
for (const name of ['compat', 'drawings', 'review']) {
  const source = `browser-src/${name}.js`;
  const result = babel.transformFileSync(source, {
    presets: [[presetEnv, {targets: {ie: '11'}, modules: false}]],
    comments: true, compact: false, sourceMaps: false
  });
  fs.writeFileSync(`public/assets/${name}.js`, '// Generated from ' + source + '; run npm run build after editing.\n' + result.code + '\n');
}
console.log('ES5 browser assets built.');
