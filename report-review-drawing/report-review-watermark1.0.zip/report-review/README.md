# Report Review — single-person test

Standalone PHP 7.4 / PDO / MariaDB or MySQL application. The supplied 17-page PDF stays private; the browser receives PNG pages and SVG annotations. One person uses one active edit tab. Saves replace the report's complete annotation set, without revision conflict handling.

## Install

The browser code targets Chrome 49 and Firefox 52. Shipped assets are already compiled to ES5; deployment requires no Node.js or npm. Native Firefox 52.0 checks passed for page images, annotation editing, immediate color changes, inline Unicode text, mouse drawing, zoom, rotation, thumbnails, navigation, saving, and View mode using isolated mock APIs. ES5 parsing and fallback checks also pass. Chrome 49 has not been tested natively.

1. Enable PHP PDO MySQL and sessions. PHP must be able to run `proc_open`. Install Poppler (`pdfinfo` and `pdftoppm`) and put both executables on the PHP process's PATH, or configure absolute executable paths. No Composer or npm installation is needed.
2. Import `sql/database.sql` into your local MariaDB/MySQL instance. This creates `report_review_test` and its table without dropping existing data.
3. Copy `config/local.example.php` to `config/local.php`. Configure database credentials and renderer paths there. On Windows, single-quoted paths such as `'C:/tools/poppler/bin/pdftoppm.exe'` work.
4. Run `php scripts/password.php`, enter your chosen test password, and paste the generated hash into `edit_password_hash` in `config/local.php`. Input is visible in the terminal. No default password is shipped. Optionally generate a different `view_password_hash` to test view-only permission; the editor password can open both pages.
5. Ensure PHP can write the private `cache/` directory. Run `php scripts/setup.php` to check the database and pre-render all pages at standard resolution. High-resolution pages are rendered on demand.
6. From the project directory run:

   ```text
   php -S 127.0.0.1:8080 -t public
   ```

7. Open http://127.0.0.1:8080/edit.php and sign in. Use http://127.0.0.1:8080/view.php for the saved view.

**Set the web document root to `public/`**, including under Apache or Nginx. Do not serve the project directory itself or create aliases to `pdfs/`, `config/`, `src/`, or `cache/`. The built-in server is for local testing. PHP 7.4 is the requested compatibility target.

## Import a PDF from a URL

Set a direct HTTP/HTTPS PDF URL in the private `config/local.php` configuration:

```php
'pdf_url' => 'https://example.com/report.pdf',
```

PHP downloads it with cURL, follows up to five HTTP/HTTPS redirects, validates it with Poppler, and caches it under `cache/imported-pdfs/`. The source PDF remains private; Edit, View, thumbnails, annotations, and PHP watermarks use the imported document through the existing page-image endpoint. Empty `pdf_url` keeps the bundled `pdfs/test_report.pdf`. The report title and author remain the application's sample metadata.

Limits: 50 MiB downloads, a 45-second download timeout, 1–500 pages, and the existing page-dimension limits. Password-protected PDFs and URLs requiring login are not supported. TLS verification stays enabled; use a direct accessible link. Only a trusted administrator should configure the URL, which is fetched from the server's network. No browser URL override or remote credentials are accepted.

Changing the document: close the editor and save any work, set the new URL, then run `php scripts/reset-drawings.php --archive-and-reset` to archive the old annotations before running `php scripts/setup.php`. Reload the viewer afterward. Drawing hash checks prevent attaching old annotations to a different imported PDF. A URL is downloaded once; if its content later changes, close the viewer, remove that URL's private `cache/imported-pdfs/<URL hash>/source.pdf`, and repeat the archive/reset/setup steps before reopening. Keep the old PDF separately if you need it with its archived drawings.

Run `node tests/pdf-url-import.cjs` to exercise the importer against local HTTP fixtures without external downloads or annotation database writes.

## Annotation and navigation controls

- The editor opens in viewing mode. Click **Edit** in the header to enable annotation and show the footer toolbar. **Done** finishes the active drawing/move, disables annotation, and hides the footer while keeping drawings visible. Done does not save; use **Save drawings** to persist changes.
- Header controls: show/hide thumbnails, select a page or use Previous/Next, zoom out/in or choose a percentage, and rotate the current page left/right by 90 degrees. The selected page follows scrolling. Rotation resets on reload; it does not alter the PDF or saved annotation coordinates.
- Pen, Rectangle, Arrow: select a tool, then drag on a loaded page. On touch devices, choose Done to scroll over the document; Edit mode uses touch gestures for annotation.
- Text: select Text and click on a page to type directly in an editor at that position. Select an existing note and choose **Edit text**, double-click it with Select, or click it with Text to edit in place. Click Add note/Update note or press Ctrl/⌘+Enter to apply; Escape or Cancel discards the draft. Unicode and line breaks are preserved. Clicking elsewhere on the page, changing drawing tools, Done, and Save drawings apply valid drafts automatically. Invalid notes keep the editor open for correction. Undo discards the current draft before undoing the last applied operation. The editor follows page zoom and rotation; no dialog opens.
- Select: click and drag a drawing to move it within its page. Change its color, line width, or text size in the footer, or choose Delete. Undo restores up to 100 local operations, including modifications and deletions. Undo after a save makes the change unsaved again.
- Selected drawings show type-specific properties: color, opacity, X/Y position, and angle for all types; width/height and thickness for pen strokes and rectangles; length, direction, and thickness for arrows; font size and Edit text for notes. Measurements use PDF points, independent of zoom. Arrow X/Y refers to its start; other positions refer to the unrotated top-left corner. Positive angles turn clockwise. Shapes rotate about their center and notes about their anchor. Edits that move stored coordinates outside the page are rejected. Changes support Undo and Save drawings.
- Save: writes the entire current drawing set. It is disabled during loading and an in-flight save. Changes made during saving remain unsaved. Empty saves clear all annotations.
- View: shows the latest saved snapshot when opened/refreshed. It never sends saves. A view-only password also blocks saves on the server; sign out to change permissions.
- Zoom: 100% means PDF points rendered at 96/72 CSS pixels per point. Page geometry uses the rotated crop box. At 150% and 200%, visible pages request high-resolution images.
- Divider: drag with mouse/touch, or focus it and use Left/Right (10 pixels), Home (minimum), End (maximum).

## Storage and limits

Watermarks also receive independent random rotations in PHP. Set `$watermark_angle_min` and `$watermark_angle_max` in `config/watermark.php` (defaults: −35° to 35°). Set both to `0` for horizontal watermarks, or the same angle for a fixed rotation. Angles remain stable for each page/session across standard and high-resolution images. The entire multiline block rotates together and is sized to stay within its page cell.

Set `$watermark_opacity` in `config/watermark.php` to control visibility: `0.28` (default) means 28% opacity, `0.5` means 50%, and `1` is fully opaque. The allowed range is 0–1; zero makes the watermark invisible. Reload the viewer after changing it. Opacity is applied by PHP to the image pixels and cannot be overridden by browser parameters.

PHP embeds personalized watermarks directly into every page image served in Edit and View, including thumbnails and high-resolution images. Configure `$site_title`, `$username`, `$datetime`, `$watermark_count`, and `$watermark_font` in `config/watermark.php`. The default is three marks with “Document View”, “Danny Powel”, and the current PHP date/time at page load. Set the count to zero to disable them (supported range: 0–100). PHP GD with FreeType and a readable TrueType font are required when enabled. The default font is Arial on Windows and DejaVu Sans on Linux; adjust its path for your server. A missing font fails the image request instead of serving an unwatermarked page.

Positions are independently generated per page from a private random session seed and stay fixed across image resolutions, zoom, rotation, and annotation edits. The watermark is part of the image pixels, so removing JavaScript or DOM overlays cannot remove it. The image endpoint accepts no browser overrides for watermark values or count. Personalized output is composed in memory, sent with private/no-store headers, and never written to the shared clean-page cache. Watermarks are not editable drawings. Date/time uses PHP's configured timezone. Run `php tests/watermarks.php` to verify layout, pixel composition, cache isolation, and the real image endpoint.

Normalized page coordinates range from 0 to 1. Width and text size are PDF points. Pen uses `points`; rectangle uses two opposite corner `points`; arrow uses two start/end `points`. Text uses a top-left `position`, `fontSize`, and `text`. Text lines advance by 1.2 × font size. IDs must be unique ASCII letters/digits/hyphens/underscores, up to 80 characters. Colors are six-digit hex. See the specification's JSON example.

Server limits: 2 MiB per request, 2,000 drawings, 10,000 points per pen stroke, 1,000 UTF-8 bytes per note, widths 0.5–20 points, and text sizes 6–72 points. This test renderer allows 1–500 PDF pages and a maximum page dimension of 20,000 points. Raster longest-edge bounds are 1,600 pixels (standard) and 3,200 pixels (high). Rendering times out after 40 seconds. API requests require the fixed report ID `1`.

Drawing loads validate persisted data as well as new input. Source hashes prevent attaching old drawings to a different PDF. Page-image requests also carry the expected hash. On source replacement, close the editor, then run:

```text
php scripts/reset-drawings.php --archive-and-reset
php scripts/setup.php
```

The reset script stores the old database row in private `cache/archives/` before deleting it. Back up this directory if its contents matter; `cache/` is ignored by Git. Reload both pages after resetting. Do not replace the PDF while using the editor.

## Verification

### Browser source and compatibility checks

Edit `browser-src/review.js`, `browser-src/drawings.js`, and `browser-src/compat.js`, then rebuild the deployed files in `public/assets/`. Generated files include a header identifying their source. With Node 22.18+ (22.x) or Node 24.11+ and npm:

```text
npm ci
npm run build
npm run check:legacy
npm run test:legacy
```

`check:legacy` parses every deployed browser script as ES5. `test:legacy` requires an installed Chrome browser (or `TEST_BROWSER_CHANNEL`) and Playwright; it disables modern APIs and native pointer dispatch to exercise actual fallback mouse/touch handling, multi-page loading, thumbnail loading, resizing, immediate color changes, Unicode inline text, zoom/rotation, Undo, Save, and reload. These tests use mocked APIs and do not change annotation data. They supplement testing in the actual target browsers.

For native Firefox 52 checks, start geckodriver 0.17 on port 44452, set `TEST_FIREFOX_BINARY` to the Firefox 52 executable, and run `node tests/firefox52-browser.cjs`. `TEST_WEBDRIVER_URL` optionally changes the driver address. The test requires exactly version 52.0, creates a temporary browser profile with updates disabled, and uses mock APIs without changing saved report data. Downloaded browser tools and screenshots belong in ignored `tmp/`, not deployment files.

`compat.js` loads before the drawing and review scripts. It supplies older-browser DOM/string/collection fallbacks, scroll-based visibility checks when IntersectionObserver is absent, and mouse/touch translation when Pointer Events are absent. Requests use XMLHttpRequest with native Promises. Coordinate conversion uses SVG points instead of DOMPoint, text validation uses a UTF-8 byte counter, and layout uses flex, `100vh`, and margins rather than requiring CSS Grid, dynamic viewport units, or flex gap. PHP PDF imports and watermarks remain server-side.

Run `node tests/drawing-properties.cjs` for geometry and rendering checks. With Playwright available, run `node tests/drawing-properties-browser.cjs` for selection, type-specific editing, Undo, Save, and reload checks using mocked APIs; this test does not modify the database. Optional saved fields are `opacity` (0–1, default 1) and `rotation` (−360–360 degrees, default 0, for pen/rectangle/text). Arrows encode direction in their endpoints. Existing format-version-1 drawings remain compatible.

Run `php tests/validation.php` for metadata, source-hash, and drawing validation checks. Run PHP syntax checks on all PHP files and `node --check public/assets/review.js` / `node --check public/assets/drawings.js` when Node is available (Node is only a development check, not a runtime requirement).

Manual acceptance checklist:

- Sign in; verify all 17 page placeholders, title, author, tools and zoom. Images load near the viewport.
- Draw each shape and Unicode text on two pages; resize, scroll, and zoom 75%–200%; confirm alignment.
- Save, reload, and compare the view page. Delete, undo, save, and reload. Save an empty list and confirm clean pages.
- Try loading with the database stopped: controls remain disabled. Stop it after loading: failed saves retain local drawings. Restore the database and retry.
- Create local edits during an in-flight save; confirm they remain unsaved afterward.
- Sign out; all API endpoints must reject requests. A view-only password must receive HTTP 403 on save. Invalid CSRF also returns 403.
- Check invalid payloads, report IDs, page numbers, image levels, and changed source hashes. Unsupported methods return 405.
- Request `/pdfs/test_report.pdf` and `/config/local.php`: both must be inaccessible. Network traffic must contain no PDF bytes.
- Test touch drawing/scrolling and keyboard divider resizing. Navigate away with unsaved edits to trigger the browser's warning.

The viewer protects the original PDF, not screenshots or saved page images. Database credentials and passwords are configured locally, not sent to the browser. A default installation intentionally refuses login until a password hash is configured.

## Files

`public/` contains the two pages, APIs, and assets. `src/` contains access control, rendering, and persistence. `config/` holds private settings. `scripts/` contains CLI setup and recovery tools. `sql/` contains the schema. `pdfs/Specification.md` is the agreed specification and `pdfs/test_report.pdf` is the existing sample.
