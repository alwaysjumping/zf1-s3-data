<?php
header('Location: edit.php', true, 302);
