// Generated from browser-src/drawings.js; run npm run build after editing.
'use strict';

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
window.ReviewDrawings = function () {
  var NS = 'http://www.w3.org/2000/svg';
  var element = function element(name) {
    var attrs = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var node = document.createElementNS(NS, name);
    Object.entries(attrs).forEach(function (_ref) {
      var _ref2 = _slicedToArray(_ref, 2),
        key = _ref2[0],
        value = _ref2[1];
      return node.setAttribute(key, value);
    });
    return node;
  };
  function bounds(d, geometry) {
    var points = d.type === 'text' ? [d.position] : d.points;
    var xs = points.map(function (p) {
        return p[0] * geometry.width;
      }),
      ys = points.map(function (p) {
        return p[1] * geometry.height;
      });
    var x = Math.min.apply(Math, _toConsumableArray(xs)),
      y = Math.min.apply(Math, _toConsumableArray(ys));
    return {
      x: x,
      y: y,
      width: Math.max.apply(Math, _toConsumableArray(xs)) - x,
      height: Math.max.apply(Math, _toConsumableArray(ys)) - y
    };
  }
  function properties(d, geometry) {
    var _d$rotation;
    var box = bounds(d, geometry);
    if (d.type === 'arrow') {
      var _d$points = _slicedToArray(d.points, 2),
        a = _d$points[0],
        b = _d$points[1];
      var dx = (b[0] - a[0]) * geometry.width,
        dy = (b[1] - a[1]) * geometry.height;
      return _objectSpread(_objectSpread({}, box), {}, {
        x: a[0] * geometry.width,
        y: a[1] * geometry.height,
        length: Math.hypot(dx, dy),
        angle: Math.atan2(dy, dx) * 180 / Math.PI
      });
    }
    return _objectSpread(_objectSpread({}, box), {}, {
      angle: (_d$rotation = d.rotation) !== null && _d$rotation !== void 0 ? _d$rotation : 0
    });
  }
  function update(d, geometry, property, value) {
    if (!Number.isFinite(value)) throw new Error('Enter a valid number.');
    var next = JSON.parse(JSON.stringify(d)),
      box = properties(d, geometry);
    if (property === 'lineWidth' || property === 'fontSize') {
      var text = property === 'fontSize',
        min = text ? 6 : .5,
        max = text ? 72 : 20;
      if (d.type === 'text' !== text) throw new Error('This property is unavailable for the selected drawing.');
      if (value < min || value > max) throw new Error("Use a value between ".concat(min, " and ").concat(max, " points."));
      next[property] = value;
    } else if (property === 'opacity') {
      if (value < 0 || value > 100) throw new Error('Opacity must be between 0 and 100%.');
      next.opacity = value / 100;
    } else if (property === 'angle' && d.type !== 'arrow') {
      if (value < -360 || value > 360) throw new Error('Angle must be between −360 and 360°.');
      next.rotation = value;
    } else {
      var points = d.type === 'text' ? [d.position] : d.points;
      if (d.type === 'arrow' && ['length', 'angle'].includes(property)) {
        var length = property === 'length' ? value : box.length;
        var angle = (property === 'angle' ? value : box.angle) * Math.PI / 180;
        if (length < 0) throw new Error('Length cannot be negative.');
        points = [points[0], [points[0][0] + length * Math.cos(angle) / geometry.width, points[0][1] + length * Math.sin(angle) / geometry.height]];
      } else if (['x', 'y'].includes(property)) {
        var axis = property === 'x' ? 0 : 1,
          dimension = axis ? geometry.height : geometry.width;
        points = points.map(function (p) {
          return p.map(function (v, i) {
            return i === axis ? v + (value - box[property]) / dimension : v;
          });
        });
      } else if (['width', 'height'].includes(property)) {
        if (value < 0) throw new Error('Size cannot be negative.');
        var _axis = property === 'width' ? 0 : 1,
          _dimension = _axis ? geometry.height : geometry.width;
        var origin = _axis ? box.y : box.x,
          old = box[property];
        if (old === 0 && value !== 0 && d.type === 'pen') throw new Error('This stroke has no extent in that direction.');
        points = points.map(function (p, index) {
          return p.map(function (v, i) {
            return i === _axis ? (origin + (old ? (v * _dimension - origin) * value / old : index * value)) / _dimension : v;
          });
        });
      } else throw new Error('This property is unavailable for the selected drawing.');
      if (points.some(function (p) {
        return p.some(function (v) {
          return v < -1e-9 || v > 1 + 1e-9;
        });
      })) throw new Error('Keep the drawing within the page. Try moving it or reducing its size first.');
      points = points.map(function (p) {
        return p.map(function (v) {
          return Math.max(0, Math.min(1, v));
        });
      });
      if (d.type === 'text') next.position = points[0];else next.points = points;
    }
    return next;
  }
  function render(svg, drawings, geometry, selected) {
    svg.replaceChildren();
    var point = function point(p) {
      return [p[0] * geometry.width, p[1] * geometry.height];
    };
    var _iterator = _createForOfIteratorHelper(drawings),
      _step;
    try {
      var _loop = function _loop() {
        var d = _step.value;
        if (d.page !== geometry.page) return 1; // continue
        var group = element('g', {
          'data-id': d.id
        });
        var box = bounds(d, geometry);
        if (d.rotation) group.setAttribute('transform', "rotate(".concat(d.rotation, " ").concat(box.x + box.width / 2, " ").concat(box.y + box.height / 2, ")"));
        if (selected === d.id) group.classList.add('selected');
        var style = {
          stroke: d.color,
          'stroke-width': d.lineWidth || 1,
          fill: 'none',
          'stroke-linecap': 'round',
          'stroke-linejoin': 'round'
        };
        if (d.type === 'text') {
          var _point = point(d.position),
            _point2 = _slicedToArray(_point, 2),
            x = _point2[0],
            y = _point2[1];
          var node = element('text', {
            x: x,
            y: y,
            fill: d.color,
            'font-size': d.fontSize,
            'font-family': 'Arial, sans-serif',
            'dominant-baseline': 'hanging',
            'xml:space': 'preserve'
          });
          d.text.split('\n').forEach(function (line, index) {
            var span = element('tspan', {
              x: x,
              dy: index ? d.fontSize * 1.2 : 0
            });
            span.textContent = line || ' ';
            node.append(span);
          });
          group.append(node);
        } else {
          var points = d.points.map(point);
          if (d.type === 'rectangle') {
            var _points = _slicedToArray(points, 2),
              a = _points[0],
              b = _points[1];
            var rect = {
              x: Math.min(a[0], b[0]),
              y: Math.min(a[1], b[1]),
              width: Math.abs(a[0] - b[0]),
              height: Math.abs(a[1] - b[1])
            };
            group.append(element('rect', _objectSpread(_objectSpread({}, rect), {}, {
              fill: 'transparent',
              stroke: 'transparent',
              'stroke-width': 10,
              'pointer-events': 'all'
            })));
            group.append(element('rect', _objectSpread(_objectSpread({}, style), rect)));
          } else {
            var path = 'M' + points.map(function (p) {
              return p.join(',');
            }).join(' L');
            // A transparent wider stroke makes narrow pen and arrow lines selectable.
            group.append(element('path', {
              d: path,
              stroke: 'transparent',
              'stroke-width': Math.max(10, d.lineWidth),
              fill: 'none',
              'pointer-events': 'stroke'
            }));
            group.append(element('path', _objectSpread(_objectSpread({}, style), {}, {
              d: path
            })));
            if (d.type === 'arrow') {
              var _points2 = _slicedToArray(points, 2),
                _a = _points2[0],
                _b = _points2[1],
                angle = Math.atan2(_b[1] - _a[1], _b[0] - _a[0]);
              var size = Math.max(9, d.lineWidth * 4);
              var left = [_b[0] - size * Math.cos(angle - .45), _b[1] - size * Math.sin(angle - .45)];
              var right = [_b[0] - size * Math.cos(angle + .45), _b[1] - size * Math.sin(angle + .45)];
              group.append(element('path', _objectSpread(_objectSpread({}, style), {}, {
                d: "M".concat(left, " L").concat(_b, " L").concat(right)
              })));
            }
          }
        }
        // Keep selection visible and clickable even when the drawing is fully transparent.
        for (var _i = 0, _Array$from = Array.from(group.children); _i < _Array$from.length; _i++) {
          var _d$opacity;
          var child = _Array$from[_i];
          child.setAttribute('opacity', (_d$opacity = d.opacity) !== null && _d$opacity !== void 0 ? _d$opacity : 1);
        }
        if (selected === d.id) {
          var text = d.type === 'text';
          group.append(element('rect', {
            x: box.x - 4,
            y: box.y - 4,
            width: Math.max(8, text ? d.fontSize * .6 * Math.max.apply(Math, _toConsumableArray(d.text.split('\n').map(function (s) {
              return s.length;
            }))) : box.width + 8),
            height: Math.max(8, text ? d.fontSize * 1.2 * d.text.split('\n').length : box.height + 8),
            fill: 'none',
            stroke: '#2473d5',
            'stroke-width': 1,
            'stroke-dasharray': '4 3',
            'pointer-events': 'none'
          }));
        }
        svg.append(group);
      };
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        if (_loop()) continue;
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
  return {
    element: element,
    render: render,
    bounds: bounds,
    properties: properties,
    update: update
  };
}();
