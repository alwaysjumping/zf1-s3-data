// Generated from browser-src/review.js; run npm run build after editing.
'use strict';

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i.return) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
(function () {
  var $ = function $(id) {
    return document.getElementById(id);
  };
  var editable = document.body.dataset.mode === 'edit';
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  var drawingColor = editable ? $('color').value : '#d62828',
    colorEdit = null;
  var info,
    drawings = [],
    saved = '[]',
    ready = false,
    saving = false,
    tool = 'select';
  var selected = null,
    active = null,
    noteAt = null,
    editing = false,
    currentPage = 1;
  var undo = [],
    pageViews = [];
  var copy = function copy(value) {
    return JSON.parse(JSON.stringify(value));
  };
  var dirty = function dirty() {
    return JSON.stringify(drawings) !== saved;
  };
  var status = function status(message) {
    var error = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    $('status').textContent = message;
    $('status').classList.toggle('error', error);
  };
  var controls = function controls() {
    var _drawings$find;
    $('previous-page').disabled = !ready || currentPage === 1;
    $('next-page').disabled = !ready || currentPage === pageViews.length;
    $('zoom-out').disabled = !ready || $('zoom').selectedIndex === 0;
    $('zoom-in').disabled = !ready || $('zoom').selectedIndex === $('zoom').options.length - 1;
    if (!editable) return;
    $('save').disabled = !ready || saving;
    $('edit-mode').disabled = !ready || editing;
    $('edit-mode').setAttribute('aria-pressed', String(editing));
    $('done-mode').disabled = !ready || !editing;
    $('tools').disabled = !ready || !editing;
    $('undo').disabled = !ready || !editing || !undo.length;
    $('delete').disabled = !ready || !editing || !selected;
    $('edit-text').disabled = !ready || !editing || ((_drawings$find = drawings.find(function (d) {
      return d.id === selected;
    })) === null || _drawings$find === void 0 ? void 0 : _drawings$find.type) !== 'text';
    syncProperties();
  };
  function syncProperties() {
    var _pageViews$find, _d$lineWidth, _d$fontSize, _d$opacity, _noteAt;
    var d = drawings.find(function (d) {
      return d.id === selected;
    });
    $('drawing-properties').hidden = !editing || !d;
    $('selection-help').textContent = d ? "Measurements in PDF points. X/Y: ".concat(d.type === 'arrow' ? 'arrow start' : 'unrotated top-left', ". Positive angles turn clockwise.") : 'Select a drawing to edit its properties. Measurements are in PDF points.';
    var type = (d === null || d === void 0 ? void 0 : d.type) || tool;
    $('line-width').closest('label').hidden = !!d || type === 'text';
    $('font-size').closest('label').hidden = !!d || type !== 'text' && type !== 'select';
    $('edit-text').hidden = type !== 'text';
    if (!d) return;
    $('selected-type').textContent = {
      pen: 'Pen stroke',
      rectangle: 'Rectangle',
      arrow: 'Arrow',
      text: 'Text note'
    }[d.type] + ' properties';
    var geometry = (_pageViews$find = pageViews.find(function (p) {
      return p.geometry.page === d.page;
    })) === null || _pageViews$find === void 0 ? void 0 : _pageViews$find.geometry;
    if (!geometry) return;
    var values = _objectSpread(_objectSpread({}, ReviewDrawings.properties(d, geometry)), {}, {
      lineWidth: (_d$lineWidth = d.lineWidth) !== null && _d$lineWidth !== void 0 ? _d$lineWidth : 2,
      fontSize: (_d$fontSize = d.fontSize) !== null && _d$fontSize !== void 0 ? _d$fontSize : 14,
      opacity: ((_d$opacity = d.opacity) !== null && _d$opacity !== void 0 ? _d$opacity : 1) * 100
    });
    document.querySelectorAll('[data-types]').forEach(function (label) {
      label.hidden = !label.dataset.types.split(' ').includes(d.type);
    });
    document.querySelectorAll('[data-property]').forEach(function (input) {
      input.value = String(Math.round(values[input.dataset.property] * 1000) / 1000);
      input.disabled = !editing || input.closest('label').hidden;
    });
    var _loop = function _loop() {
      var _arr$_i = _slicedToArray(_arr[_i], 2),
        inputId = _arr$_i[0],
        value = _arr$_i[1];
      if (value == null) return 1; // continue
      var input = $(inputId),
        size = String(value);
      if (!Array.from(input.options).some(function (option) {
        return option.value === size;
      })) input.add(new Option(size, size));
      input.value = size;
    };
    for (var _i = 0, _arr = [['line-width', d.lineWidth], ['font-size', d.fontSize]]; _i < _arr.length; _i++) {
      if (_loop()) continue;
    }
    if (((_noteAt = noteAt) === null || _noteAt === void 0 ? void 0 : _noteAt.id) === d.id) layoutTextEditor(pageViews.find(function (p) {
      return p.geometry.page === d.page;
    }));
  }
  function redraw() {
    var _active;
    var all = ((_active = active) === null || _active === void 0 ? void 0 : _active.kind) === 'draw' ? [].concat(_toConsumableArray(drawings), [active.drawing]) : drawings;
    pageViews.forEach(function (p) {
      return ReviewDrawings.render(p.svg, all, p.geometry, selected);
    });
    controls();
  }
  function changed() {
    redraw();
    status(saving ? 'Saving… Your newer changes remain local.' : dirty() ? 'Unsaved changes' : 'All changes saved');
  }
  function remember() {
    undo.push(copy(drawings));
    if (undo.length > 100) undo.shift();
  }
  function commit(drawing) {
    if (drawings.length >= 2000) {
      status('Maximum 2,000 drawings. Delete a drawing before adding more.', true);
      redraw();
      return;
    }
    remember();
    drawings.push(drawing);
    selected = null;
    changed();
  }
  function finishStroke() {
    if (!active) return;
    var _active2 = active,
      kind = _active2.kind,
      drawing = _active2.drawing,
      svg = _active2.svg,
      pointerId = _active2.pointerId,
      before = _active2.before;
    active = null;
    if (svg.hasPointerCapture(pointerId)) svg.releasePointerCapture(pointerId);
    if (kind === 'move') {
      if (JSON.stringify(before) !== JSON.stringify(drawings)) {
        undo.push(before);
        if (undo.length > 100) undo.shift();
        changed();
      }
      return;
    }
    if (drawing.points.length === 1) drawing.points.push(_toConsumableArray(drawing.points[0]));
    commit(drawing);
  }
  function request(path) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return ReviewCompat.request('api/' + path, options);
  }
  var id = function id() {
    return 'd-' + Array.from(crypto.getRandomValues(new Uint32Array(4)), function (n) {
      return n.toString(16);
    }).join('-');
  };
  function base(geometry, type) {
    return {
      id: id(),
      page: geometry.page,
      type: type,
      color: drawingColor
    };
  }
  function position(event, svg) {
    // Inverse SVG transform includes zoom and the page's display rotation.
    var point = ReviewCompat.point(svg, event.clientX, event.clientY);
    return [Math.max(0, Math.min(1, point.x / svg.viewBox.baseVal.width)), Math.max(0, Math.min(1, point.y / svg.viewBox.baseVal.height))];
  }
  function selectDrawing(value) {
    selected = value;
    colorEdit = null;
    var drawing = drawings.find(function (d) {
      return d.id === value;
    });
    if (drawing) {
      $('color').value = drawing.color;
      var input = $(drawing.type === 'text' ? 'font-size' : 'line-width');
      var size = String(drawing.type === 'text' ? drawing.fontSize : drawing.lineWidth);
      if (!Array.from(input.options).some(function (option) {
        return option.value === size;
      })) input.add(new Option(size, size));
      input.value = size;
    } else $('color').value = drawingColor;
    redraw();
  }
  function openText(note) {
    var _drawing$position;
    var text = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    if (!finishText()) return;
    var drawing = drawings.find(function (d) {
      return d.id === note.id;
    });
    var view = pageViews.find(function (p) {
      var _drawing$page, _note$geometry;
      return p.geometry.page === ((_drawing$page = drawing === null || drawing === void 0 ? void 0 : drawing.page) !== null && _drawing$page !== void 0 ? _drawing$page : (_note$geometry = note.geometry) === null || _note$geometry === void 0 ? void 0 : _note$geometry.page);
    });
    if (!view) return;
    noteAt = _objectSpread(_objectSpread({}, note), {}, {
      geometry: view.geometry,
      point: (_drawing$position = drawing === null || drawing === void 0 ? void 0 : drawing.position) !== null && _drawing$position !== void 0 ? _drawing$position : note.point
    });
    $('note-text').value = text;
    $('note-text').setCustomValidity('');
    $('confirm-text').textContent = note.id ? 'Update note' : 'Add note';
    var editor = $('inline-text-editor');
    view.content.append(editor);
    editor.hidden = false;
    layoutTextEditor(view);
    ReviewCompat.reveal(editor, $('pages'));
    ReviewCompat.focus($('note-text'), $('pages'));
  }
  function layoutTextEditor(view) {
    var _drawing$fontSize, _drawing$color;
    if (!noteAt || noteAt.geometry.page !== view.geometry.page) return;
    var editor = $('inline-text-editor'),
      scale = Number($('zoom').value) * 96 / 72;
    var drawing = drawings.find(function (d) {
      return d.id === noteAt.id;
    });
    if (drawing) noteAt.point = drawing.position;
    var width = view.geometry.width * scale,
      height = view.geometry.height * scale;
    editor.style.width = Math.min(280 * scale, width) + 'px';
    $('note-text').style.fontSize = ((_drawing$fontSize = drawing === null || drawing === void 0 ? void 0 : drawing.fontSize) !== null && _drawing$fontSize !== void 0 ? _drawing$fontSize : Number($('font-size').value)) * scale + 'px';
    $('note-text').style.color = (_drawing$color = drawing === null || drawing === void 0 ? void 0 : drawing.color) !== null && _drawing$color !== void 0 ? _drawing$color : drawingColor;
    editor.style.left = Math.min(noteAt.point[0] * width, Math.max(0, width - editor.offsetWidth)) + 'px';
    editor.style.top = Math.min(noteAt.point[1] * height, Math.max(0, height - editor.offsetHeight)) + 'px';
  }
  function cancelText() {
    noteAt = null;
    $('inline-text-editor').hidden = true;
  }
  function finishText() {
    if (!noteAt) return true;
    var input = $('note-text'),
      text = input.value;
    if (!text.trim()) {
      cancelText();
      return true;
    }
    input.setCustomValidity(ReviewCompat.utf8Length(text) > 1000 ? 'Use at most 1,000 UTF-8 bytes.' : '');
    if (!input.reportValidity()) return false;
    var note = noteAt;
    cancelText();
    if (note.id) {
      var d = drawings.find(function (d) {
        return d.id === note.id;
      });
      if (d && d.text !== text) {
        remember();
        d.text = text;
        changed();
      }
    } else commit(_objectSpread(_objectSpread({}, base(note.geometry, 'text')), {}, {
      fontSize: Number($('font-size').value),
      position: note.point,
      text: text
    }));
    return true;
  }
  function setEditing(enabled) {
    if (!editable || !ready) return;
    if (!enabled && !finishText()) return;
    finishStroke();
    editing = enabled;
    selected = null;
    $('drawing-toolbar').hidden = !editing;
    pageViews.forEach(function (p) {
      p.svg.style.pointerEvents = editing ? '' : 'none';
      p.svg.classList.toggle('editable', editing);
      p.svg.classList.toggle('selecting', editing && tool === 'select');
    });
    redraw();
    status(dirty() ? editing ? 'Unsaved changes' : 'Editing finished. Use Save drawings to keep your changes.' : editing ? 'Editing enabled' : 'Viewing report');
  }
  function wireDrawing(svg, geometry) {
    svg.addEventListener('pointerdown', function (event) {
      if (!ready || !editing || active || event.button !== 0 || !event.isPrimary || !svg.closest('.page').classList.contains('loaded')) return;
      if (!finishText()) return;
      if (tool === 'select') {
        var _event$target$closest;
        var value = ((_event$target$closest = event.target.closest('[data-id]')) === null || _event$target$closest === void 0 ? void 0 : _event$target$closest.dataset.id) || null;
        selectDrawing(value);
        if (value) {
          event.preventDefault();
          active = {
            kind: 'move',
            svg: svg,
            pointerId: event.pointerId,
            start: position(event, svg),
            original: copy(drawings.find(function (d) {
              return d.id === value;
            })),
            before: copy(drawings)
          };
          svg.setPointerCapture(event.pointerId);
        }
        return;
      }
      event.preventDefault();
      var point = position(event, svg);
      if (tool === 'text') {
        var d = drawings.find(function (d) {
          var _event$target$closest2;
          return d.id === ((_event$target$closest2 = event.target.closest('[data-id]')) === null || _event$target$closest2 === void 0 ? void 0 : _event$target$closest2.dataset.id);
        });
        if ((d === null || d === void 0 ? void 0 : d.type) === 'text') {
          selectDrawing(d.id);
          openText({
            id: d.id
          }, d.text);
          return;
        }
        openText({
          geometry: geometry,
          point: point
        });
        return;
      }
      var drawing = _objectSpread(_objectSpread({}, base(geometry, tool)), {}, {
        lineWidth: Number($('line-width').value),
        points: [point, _toConsumableArray(point)]
      });
      active = {
        kind: 'draw',
        drawing: drawing,
        svg: svg,
        pointerId: event.pointerId
      };
      selected = null;
      svg.setPointerCapture(event.pointerId);
      redraw();
    });
    svg.addEventListener('pointermove', function (event) {
      if (!editing || !active || active.svg !== svg || event.pointerId !== active.pointerId) return;
      var point = position(event, svg);
      if (active.kind === 'move') {
        var original = active.original,
          points = original.type === 'text' ? [original.position] : original.points;
        var xs = points.map(function (p) {
            return p[0];
          }),
          ys = points.map(function (p) {
            return p[1];
          });
        var dx = Math.max(-Math.min.apply(Math, _toConsumableArray(xs)), Math.min(1 - Math.max.apply(Math, _toConsumableArray(xs)), point[0] - active.start[0]));
        var dy = Math.max(-Math.min.apply(Math, _toConsumableArray(ys)), Math.min(1 - Math.max.apply(Math, _toConsumableArray(ys)), point[1] - active.start[1]));
        var moved = points.map(function (p) {
          return [Math.max(0, Math.min(1, p[0] + dx)), Math.max(0, Math.min(1, p[1] + dy))];
        });
        var target = drawings.find(function (d) {
          return d.id === original.id;
        });
        if (target.type === 'text') target.position = moved[0];else target.points = moved;
        redraw();
        return;
      }
      var d = active.drawing;
      if (d.type === 'pen') {
        if (d.points.length < 10000) d.points.push(point);
      } else d.points[1] = point;
      ReviewDrawings.render(svg, [].concat(_toConsumableArray(drawings), [d]), geometry, null);
    });
    svg.addEventListener('pointerup', function (event) {
      if (active && active.pointerId === event.pointerId) finishStroke();
    });
    svg.addEventListener('pointercancel', function () {
      var _active3;
      if (((_active3 = active) === null || _active3 === void 0 ? void 0 : _active3.kind) === 'move') drawings = active.before;
      active = null;
      redraw();
    });
    svg.addEventListener('lostpointercapture', function () {
      if (active && active.svg === svg) finishStroke();
    });
    svg.addEventListener('dblclick', function (event) {
      if (!editing || tool !== 'select') return;
      var d = drawings.find(function (d) {
        var _event$target$closest3;
        return d.id === ((_event$target$closest3 = event.target.closest('[data-id]')) === null || _event$target$closest3 === void 0 ? void 0 : _event$target$closest3.dataset.id);
      });
      if ((d === null || d === void 0 ? void 0 : d.type) === 'text') openText({
        id: d.id
      }, d.text);
    });
  }
  function imageError() {
    var failed = pageViews.filter(function (p) {
      return p.page.classList.contains('failed');
    }).length;
    $('image-status').textContent = failed ? "".concat(failed, " page image(s) failed. Use Retry beside the page, or reload if your session or PDF changed.") : '';
  }
  // Decode off-screen; never attach an empty or failed image to the viewer.
  function requestImage(url, isCurrent, success, failure, retrying) {
    var attempt = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;
    var img = new Image();
    img.draggable = false;
    img.onload = function () {
      if (isCurrent()) success(img);
    };
    img.onerror = function () {
      if (!isCurrent()) return;
      if (attempt < 2) {
        retrying();
        setTimeout(function () {
          if (isCurrent()) requestImage(url, isCurrent, success, failure, retrying, attempt + 1);
        }, 750 * (attempt + 1));
      } else failure();
    };
    img.src = url + (attempt ? "&retry=".concat(attempt, "-").concat(Date.now()) : '');
  }
  function loadImage(p) {
    var force = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var level = Number($('zoom').value) > 1.25 ? 'high' : 'standard';
    if (!force && (p.requested === level || p.loaded === 'high' || p.failedLevel === level)) return;
    p.requested = level;
    var token = {};
    p.imageRequest = token;
    p.failedLevel = null;
    p.page.setAttribute('aria-busy', 'true');
    p.placeholder.textContent = 'Loading page…';
    p.retry.hidden = true;
    p.page.classList.remove('failed');
    imageError();
    var url = "api/page-image.php?reportId=1&page=".concat(p.geometry.page, "&level=").concat(level, "&pdfHash=").concat(encodeURIComponent(info.pdfHash));
    requestImage(url, function () {
      return p.imageRequest === token;
    }, function (img) {
      img.alt = "Report page ".concat(p.geometry.page);
      p.img.replaceWith(img);
      p.img = img;
      p.loaded = level;
      p.placeholder.hidden = true;
      p.page.setAttribute('aria-busy', 'false');
      p.page.classList.add('loaded');
      p.page.classList.remove('failed');
      p.retry.hidden = true;
      imageError();
    }, function () {
      p.failedLevel = level;
      p.page.setAttribute('aria-busy', 'false');
      p.placeholder.textContent = 'Page image unavailable. Use Retry image above.';
      p.requested = null;
      p.page.classList.add('failed');
      p.retry.hidden = false;
      imageError();
    }, function () {
      p.placeholder.textContent = 'Preparing page… Retrying image.';
    });
  }
  function loadThumbnail(p) {
    var force = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    if (!force && p.thumbRequested) return;
    p.thumbRequested = true;
    p.thumbFailed = false;
    var token = {};
    p.thumbRequest = token;
    p.thumbPlaceholder.textContent = 'Loading…';
    var url = "api/page-image.php?reportId=1&page=".concat(p.geometry.page, "&level=standard&pdfHash=").concat(encodeURIComponent(info.pdfHash));
    requestImage(url, function () {
      return p.thumbRequest === token;
    }, function (img) {
      img.alt = '';
      img.style.transform = "rotate(".concat(p.rotation, "deg)");
      p.thumbImage.replaceWith(img);
      p.thumbImage = img;
      p.thumbPlaceholder.hidden = true;
    }, function () {
      p.thumbFailed = true;
      p.thumbPlaceholder.textContent = 'Preview unavailable. Click to retry.';
    }, function () {
      p.thumbPlaceholder.textContent = 'Retrying…';
    });
  }
  var thumbnailObserver = new ReviewCompat.Observer(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting && !$('thumbnails').hidden) {
        var p = pageViews.find(function (p) {
          return p.thumb === entry.target;
        });
        if (p) loadThumbnail(p);
      }
    });
  }, {
    root: $('thumbnails'),
    rootMargin: '150px'
  });
  var observer = new ReviewCompat.Observer(function (entries) {
    entries.forEach(function (entry) {
      var p = pageViews.find(function (p) {
        return p.page === entry.target;
      });
      p.visible = entry.isIntersecting;
      if (p.visible) loadImage(p);
    });
  }, {
    root: $('pages'),
    rootMargin: '600px'
  });
  function layoutPage(p) {
    var scale = Number($('zoom').value) * 96 / 72;
    var w = p.geometry.width * scale,
      h = p.geometry.height * scale;
    var sideways = p.rotation % 180 !== 0;
    p.page.style.width = (sideways ? h : w) + 'px';
    p.page.style.height = (sideways ? w : h) + 'px';
    p.wrap.style.width = p.page.style.width;
    p.content.style.width = w + 'px';
    p.content.style.height = h + 'px';
    var transforms = {
      0: '',
      90: "translate(".concat(h, "px, 0) rotate(90deg)"),
      180: "translate(".concat(w, "px, ").concat(h, "px) rotate(180deg)"),
      270: "translate(0, ".concat(w, "px) rotate(270deg)")
    };
    p.content.style.transform = transforms[p.rotation];
    p.thumbImage.style.transform = "rotate(".concat(p.rotation, "deg)");
    if (editable) layoutTextEditor(p);
  }
  function zoom() {
    finishStroke();
    pageViews.forEach(function (p) {
      layoutPage(p);
      if (p.visible) loadImage(p);
    });
    if (observer.refresh) observer.refresh();
    if (thumbnailObserver.refresh) thumbnailObserver.refresh();
    controls();
  }
  function setCurrentPage(number) {
    currentPage = number;
    $('page-selector').value = String(number);
    pageViews.forEach(function (p) {
      return p.thumb.setAttribute('aria-current', p.geometry.page === number ? 'page' : 'false');
    });
    controls();
  }
  function goToPage(number) {
    var p = pageViews[number - 1];
    if (!p) return;
    finishStroke();
    setCurrentPage(number);
    var top = p.wrap.getBoundingClientRect().top - $('pages').getBoundingClientRect().top + $('pages').scrollTop;
    $('pages').scrollTop = Math.max(0, top - 18);
    $('pages').scrollLeft = 0;
  }
  var scrollFrame;
  $('pages').addEventListener('scroll', function () {
    cancelAnimationFrame(scrollFrame);
    scrollFrame = requestAnimationFrame(function () {
      var viewport = $('pages').getBoundingClientRect();
      var best = null,
        area = -1;
      pageViews.forEach(function (p) {
        var rect = p.page.getBoundingClientRect();
        var visible = Math.max(0, Math.min(rect.bottom, viewport.bottom) - Math.max(rect.top, viewport.top));
        if (visible > area) {
          best = p;
          area = visible;
        }
      });
      if (best) setCurrentPage(best.geometry.page);
    });
  });
  function rotate(delta) {
    if (!ready) return;
    finishStroke();
    var p = pageViews[currentPage - 1];
    p.rotation = (p.rotation + delta + 360) % 360;
    layoutPage(p);
    goToPage(currentPage);
  }
  function buildPages() {
    var _$;
    var _iterator = _createForOfIteratorHelper(info.pages),
      _step;
    try {
      var _loop2 = function _loop2() {
        var geometry = _step.value;
        var wrap = document.createElement('div');
        wrap.className = 'page-wrap';
        var caption = document.createElement('div');
        caption.className = 'page-caption';
        caption.textContent = "PAGE ".concat(String(geometry.page).padStart(2, '0'), " / ").concat(info.pageCount);
        var retry = document.createElement('button');
        retry.textContent = 'Retry image';
        retry.className = 'page-retry';
        retry.hidden = true;
        caption.append(retry);
        var page = document.createElement('div');
        page.className = 'page';
        var content = document.createElement('div');
        content.className = 'page-content';
        var img = document.createElement('img');
        img.alt = '';
        img.hidden = true;
        var placeholder = document.createElement('div');
        placeholder.className = 'page-placeholder';
        placeholder.textContent = 'Loading page…';
        placeholder.setAttribute('role', 'status');
        var svg = ReviewDrawings.element('svg', {
          viewBox: "0 0 ".concat(geometry.width, " ").concat(geometry.height),
          'aria-label': "Annotations for page ".concat(geometry.page)
        });
        if (editable) wireDrawing(svg, geometry);
        svg.style.pointerEvents = 'none';
        content.append(img, svg);
        page.append(content, placeholder);
        wrap.append(caption, page);
        $('pages').append(wrap);
        var thumb = document.createElement('button');
        thumb.type = 'button';
        thumb.className = 'thumbnail';
        thumb.setAttribute('aria-label', "Go to page ".concat(geometry.page));
        var thumbFrame = document.createElement('span');
        thumbFrame.className = 'thumbnail-image';
        var thumbImage = document.createElement('img');
        thumbImage.alt = '';
        thumbImage.hidden = true;
        var thumbPlaceholder = document.createElement('span');
        thumbPlaceholder.className = 'thumbnail-placeholder';
        thumbPlaceholder.textContent = 'Loading…';
        var thumbLabel = document.createElement('span');
        thumbLabel.textContent = "Page ".concat(geometry.page);
        thumbFrame.append(thumbImage, thumbPlaceholder);
        thumb.append(thumbFrame, thumbLabel);
        $('thumbnails').append(thumb);
        var p = {
          page: page,
          content: content,
          wrap: wrap,
          img: img,
          svg: svg,
          geometry: geometry,
          retry: retry,
          placeholder: placeholder,
          rotation: 0,
          thumb: thumb,
          thumbImage: thumbImage,
          thumbPlaceholder: thumbPlaceholder
        };
        pageViews.push(p);
        thumb.addEventListener('click', function () {
          goToPage(geometry.page);
          if (p.thumbFailed) loadThumbnail(p, true);
        });
        thumbnailObserver.observe(thumb);
        retry.addEventListener('click', function () {
          return loadImage(p, true);
        });
        observer.observe(page);
      };
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        _loop2();
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    (_$ = $('page-selector')).replaceChildren.apply(_$, _toConsumableArray(info.pages.map(function (p) {
      return new Option(String(p.page), String(p.page));
    })));
    $('total-pages').textContent = "/ ".concat(info.pageCount);
    zoom();
    redraw();
    setCurrentPage(1);
  }
  $('zoom').addEventListener('change', function () {
    zoom();
    goToPage(currentPage);
  });
  $('zoom-out').addEventListener('click', function () {
    $('zoom').selectedIndex = Math.max(0, $('zoom').selectedIndex - 1);
    zoom();
    goToPage(currentPage);
  });
  $('zoom-in').addEventListener('click', function () {
    $('zoom').selectedIndex = Math.min($('zoom').options.length - 1, $('zoom').selectedIndex + 1);
    zoom();
    goToPage(currentPage);
  });
  $('previous-page').addEventListener('click', function () {
    return goToPage(currentPage - 1);
  });
  $('next-page').addEventListener('click', function () {
    return goToPage(currentPage + 1);
  });
  $('page-selector').addEventListener('change', function () {
    return goToPage(Number($('page-selector').value));
  });
  $('rotate-left').addEventListener('click', function () {
    return rotate(-90);
  });
  $('rotate-right').addEventListener('click', function () {
    return rotate(90);
  });
  $('toggle-thumbnails').addEventListener('click', function () {
    var panel = $('thumbnails');
    panel.hidden = !panel.hidden;
    $('toggle-thumbnails').setAttribute('aria-expanded', String(!panel.hidden));
    if (thumbnailObserver.refresh) thumbnailObserver.refresh();
  });
  $('pages').addEventListener('dragstart', function (event) {
    return event.preventDefault();
  });
  if (editable) {
    document.querySelectorAll('[data-property]').forEach(function (input) {
      return input.addEventListener('change', function () {
        var _pageViews$find2;
        if (!editing || !selected) return;
        finishStroke();
        var d = drawings.find(function (d) {
          return d.id === selected;
        });
        var geometry = (_pageViews$find2 = pageViews.find(function (p) {
          return p.geometry.page === (d === null || d === void 0 ? void 0 : d.page);
        })) === null || _pageViews$find2 === void 0 ? void 0 : _pageViews$find2.geometry;
        if (!d || !geometry) return;
        try {
          if (input.value.trim() === '' || !input.checkValidity()) throw new Error('Enter a value within the allowed range.');
          var next = ReviewDrawings.update(d, geometry, input.dataset.property, Number(input.value));
          if (JSON.stringify(next) !== JSON.stringify(d)) {
            remember();
            Object.assign(d, next);
            changed();
          }
        } catch (error) {
          syncProperties();
          status(error.message, true);
        }
      });
    });
    $('edit-mode').addEventListener('click', function () {
      setEditing(true);
      $('tools').querySelector('[aria-pressed="true"]').focus();
    });
    $('done-mode').addEventListener('click', function () {
      setEditing(false);
      $('edit-mode').focus();
    });
    document.querySelectorAll('[data-tool]').forEach(function (button) {
      return button.addEventListener('click', function () {
        if (!editing || !finishText()) return;
        finishStroke();
        tool = button.dataset.tool;
        selected = null;
        colorEdit = null;
        $('color').value = drawingColor;
        document.querySelectorAll('[data-tool]').forEach(function (b) {
          return b.setAttribute('aria-pressed', String(b === button));
        });
        pageViews.forEach(function (p) {
          return p.svg.classList.toggle('selecting', tool === 'select');
        });
        redraw();
      });
    });
    $('delete').addEventListener('click', function () {
      if (!editing || !selected) return;
      cancelText();
      remember();
      drawings = drawings.filter(function (d) {
        return d.id !== selected;
      });
      selected = null;
      changed();
    });
    $('undo').addEventListener('click', function () {
      if (!editing) return;
      cancelText();
      finishStroke();
      if (undo.length) {
        drawings = undo.pop();
        selected = null;
        changed();
      }
    });
    $('edit-text').addEventListener('click', function () {
      var d = drawings.find(function (d) {
        return d.id === selected;
      });
      if (editing && (d === null || d === void 0 ? void 0 : d.type) === 'text') openText({
        id: d.id
      }, d.text);
    });
    var applyColor = function applyColor() {
      if (!editing) return;
      drawingColor = $('color').value;
      var d = drawings.find(function (d) {
        return d.id === selected;
      });
      if (d && d.color !== drawingColor) {
        // A native picker may send many input events before its final change event.
        if (colorEdit !== d.id) {
          remember();
          colorEdit = d.id;
        }
        d.color = drawingColor;
        changed();
      }
      if (noteAt) layoutTextEditor(pageViews.find(function (p) {
        return p.geometry.page === noteAt.geometry.page;
      }));
    };
    $('color').addEventListener('input', applyColor);
    $('color').addEventListener('change', function () {
      applyColor();
      colorEdit = null;
    });
    $('color').addEventListener('blur', function () {
      colorEdit = null;
    });
    var _loop3 = function _loop3() {
      var _arr2$_i = _slicedToArray(_arr2[_i2], 2),
        inputId = _arr2$_i[0],
        property = _arr2$_i[1];
      $(inputId).addEventListener('change', function () {
        if (!editing) return;
        var d = drawings.find(function (d) {
          return d.id === selected;
        });
        if (!d || property === 'fontSize' && d.type !== 'text' || property === 'lineWidth' && d.type === 'text') return;
        var value = Number($(inputId).value);
        if (d[property] !== value) {
          remember();
          d[property] = value;
          changed();
        }
      });
    };
    for (var _i2 = 0, _arr2 = [['line-width', 'lineWidth'], ['font-size', 'fontSize']]; _i2 < _arr2.length; _i2++) {
      _loop3();
    }
    $('note-text').addEventListener('input', function () {
      $('note-text').setCustomValidity(ReviewCompat.utf8Length($('note-text').value) > 1000 ? 'Use at most 1,000 UTF-8 bytes.' : '');
    });
    $('confirm-text').addEventListener('click', finishText);
    $('cancel-text').addEventListener('click', cancelText);
    $('inline-text-editor').addEventListener('keydown', function (event) {
      var key = ReviewCompat.key(event);
      if (key === 'Escape') {
        event.preventDefault();
        cancelText();
      } else if (key === 'Enter' && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        finishText();
      }
    });
    $('save').addEventListener('click', /*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee() {
      var snapshot, _t;
      return _regenerator().w(function (_context) {
        while (1) switch (_context.p = _context.n) {
          case 0:
            if (!(!ready || saving)) {
              _context.n = 1;
              break;
            }
            return _context.a(2);
          case 1:
            if (finishText()) {
              _context.n = 2;
              break;
            }
            return _context.a(2);
          case 2:
            finishStroke();
            saving = true;
            controls();
            status('Saving…');
            snapshot = JSON.stringify(drawings);
            _context.p = 3;
            _context.n = 4;
            return request('drawing-save.php', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrf
              },
              body: JSON.stringify({
                reportId: 1,
                pdfHash: info.pdfHash,
                formatVersion: 1,
                drawings: JSON.parse(snapshot)
              })
            });
          case 4:
            saved = snapshot;
            status(dirty() ? 'Saved. Newer changes are still unsaved.' : 'All changes saved');
            _context.n = 6;
            break;
          case 5:
            _context.p = 5;
            _t = _context.v;
            status(_t.message + ' Your local drawings are retained.', true);
          case 6:
            _context.p = 6;
            saving = false;
            controls();
            return _context.f(6);
          case 7:
            return _context.a(2);
        }
      }, _callee, null, [[3, 5, 6, 7]]);
    })));
    window.addEventListener('beforeunload', function (event) {
      if (dirty() || active || noteAt && $('note-text').value.trim()) {
        event.preventDefault();
        event.returnValue = '';
      }
    });
  }
  var divider = $('divider');
  var maxWidth = function maxWidth() {
    return Math.max(200, Math.min(600, document.querySelector('.workspace').clientWidth - 328));
  };
  function resize(width) {
    var value = Math.round(Math.max(200, Math.min(maxWidth(), width)));
    $('information').style.flexBasis = value + 'px';
    divider.setAttribute('aria-valuenow', value);
    divider.setAttribute('aria-valuemax', maxWidth());
  }
  divider.addEventListener('pointerdown', function (e) {
    if (e.button !== 0) return;
    divider.setPointerCapture(e.pointerId);
    document.body.classList.add('resizing');
  });
  divider.addEventListener('pointermove', function (e) {
    if (divider.hasPointerCapture(e.pointerId)) resize(e.clientX + window.scrollX);
  });
  var stopResize = function stopResize() {
    return document.body.classList.remove('resizing');
  };
  divider.addEventListener('pointerup', stopResize);
  divider.addEventListener('pointercancel', stopResize);
  divider.addEventListener('lostpointercapture', stopResize);
  divider.addEventListener('keydown', function (e) {
    var key = ReviewCompat.key(e);
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(key)) {
      e.preventDefault();
      var current = Number(divider.getAttribute('aria-valuenow'));
      resize(key === 'Home' ? 200 : key === 'End' ? maxWidth() : current + (key === 'ArrowLeft' ? -10 : 10));
    }
  });
  window.addEventListener('resize', function () {
    return resize(Number(divider.getAttribute('aria-valuenow')));
  });
  resize(280);
  _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2() {
    var data, _i3, _arr3, name, _t2;
    return _regenerator().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          _context2.p = 0;
          _context2.n = 1;
          return request('report-info.php?reportId=1');
        case 1:
          info = _context2.v;
          $('title').textContent = info.title;
          $('author').textContent = info.author;
          $('page-count').textContent = info.pageCount;
          _context2.n = 2;
          return request('drawing-load.php?reportId=1');
        case 2:
          data = _context2.v;
          if (!(data.pdfHash !== info.pdfHash || data.formatVersion !== 1)) {
            _context2.n = 3;
            break;
          }
          throw new Error('The document changed. Reload the page.');
        case 3:
          drawings = data.drawings;
          saved = JSON.stringify(drawings);
          buildPages();
          ready = true;
          for (_i3 = 0, _arr3 = ['toggle-thumbnails', 'page-selector', 'zoom', 'rotate-left', 'rotate-right']; _i3 < _arr3.length; _i3++) {
            name = _arr3[_i3];
            $(name).disabled = false;
          }
          controls();
          status(editable ? 'Ready to review. Click Edit to annotate.' : 'Showing saved drawings');
          _context2.n = 5;
          break;
        case 4:
          _context2.p = 4;
          _t2 = _context2.v;
          status(_t2.message + ' Reload after correcting the problem.', true);
        case 5:
          return _context2.a(2);
      }
    }, _callee2, null, [[0, 4]]);
  }))();
})();
