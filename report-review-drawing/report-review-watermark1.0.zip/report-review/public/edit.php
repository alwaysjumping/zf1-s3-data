<?php
$mode = 'edit';
require dirname(__DIR__) . '/src/page.php';
