<?php
$mode = 'view';
require dirname(__DIR__) . '/src/page.php';
