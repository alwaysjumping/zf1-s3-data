<?php
require dirname(__DIR__, 2) . '/src/bootstrap.php';
api(function () {
    ReportService::checkId($_GET['reportId'] ?? null);
    $page = $_GET['page'] ?? '';
    if (!is_string($page) || !preg_match('/^[1-9][0-9]{0,3}$/D', $page)) throw new HttpError(400, 'Invalid page number.');
    $hash = $_GET['pdfHash'] ?? null;
    ReportService::checkHash($hash);
    $level = $_GET['level'] ?? 'standard';
    if (!is_string($level)) throw new HttpError(400, 'Invalid resolution.');
    $file = PageRenderer::image($hash, (int)$page, $level);
    $geometry = PageRenderer::metadata($hash)[(int)$page - 1];
    $image = WatermarkService::image($file, $geometry, WatermarkService::settings());
    ReportService::checkHash($hash);
    header('Content-Type: image/png');
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    header('Content-Length: ' . strlen($image));
    echo $image;
});
