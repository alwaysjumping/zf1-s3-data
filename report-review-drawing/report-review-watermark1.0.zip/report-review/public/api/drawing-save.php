<?php
require dirname(__DIR__, 2) . '/src/bootstrap.php';
api(function () {
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) throw new HttpError(400, 'Send a JSON drawing snapshot.');
    $limit = 2 * 1024 * 1024;
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit) throw new HttpError(413, 'Drawing payload exceeds 2 MB.');
    $stream = fopen('php://input', 'rb');
    $raw = stream_get_contents($stream, $limit + 1); fclose($stream);
    if (strlen($raw) > $limit) throw new HttpError(413, 'Drawing payload exceeds 2 MB.');
    try { $data = json_decode($raw, true, 64, JSON_THROW_ON_ERROR); }
    catch (JsonException $e) { throw new HttpError(400, 'Invalid JSON.'); }
    if (!is_array($data)) throw new HttpError(400, 'Invalid snapshot.');
    AnnotationService::save($data, ReportService::info());
    jsonResponse(['saved' => true]);
}, 'POST', true);
