<?php
require dirname(__DIR__, 2) . '/src/bootstrap.php';
api(function () {
    ReportService::checkId($_GET['reportId'] ?? null);
    jsonResponse(AnnotationService::load(ReportService::info()));
});
