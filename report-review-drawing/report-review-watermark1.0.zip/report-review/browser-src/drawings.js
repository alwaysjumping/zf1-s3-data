'use strict';
window.ReviewDrawings = (() => {
  const NS = 'http://www.w3.org/2000/svg';
  const element = (name, attrs = {}) => {
    const node = document.createElementNS(NS, name);
    Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
    return node;
  };
  function bounds(d, geometry) {
    const points = d.type === 'text' ? [d.position] : d.points;
    const xs = points.map(p => p[0] * geometry.width), ys = points.map(p => p[1] * geometry.height);
    const x = Math.min(...xs), y = Math.min(...ys);
    return {x, y, width: Math.max(...xs) - x, height: Math.max(...ys) - y};
  }
  function properties(d, geometry) {
    const box = bounds(d, geometry);
    if (d.type === 'arrow') {
      const [a, b] = d.points;
      const dx = (b[0] - a[0]) * geometry.width, dy = (b[1] - a[1]) * geometry.height;
      return {...box, x: a[0] * geometry.width, y: a[1] * geometry.height, length: Math.hypot(dx, dy), angle: Math.atan2(dy, dx) * 180 / Math.PI};
    }
    return {...box, angle: d.rotation ?? 0};
  }
  function update(d, geometry, property, value) {
    if (!Number.isFinite(value)) throw new Error('Enter a valid number.');
    const next = JSON.parse(JSON.stringify(d)), box = properties(d, geometry);
    if (property === 'lineWidth' || property === 'fontSize') {
      const text = property === 'fontSize', min = text ? 6 : .5, max = text ? 72 : 20;
      if ((d.type === 'text') !== text) throw new Error('This property is unavailable for the selected drawing.');
      if (value < min || value > max) throw new Error(`Use a value between ${min} and ${max} points.`);
      next[property] = value;
    } else if (property === 'opacity') {
      if (value < 0 || value > 100) throw new Error('Opacity must be between 0 and 100%.');
      next.opacity = value / 100;
    } else if (property === 'angle' && d.type !== 'arrow') {
      if (value < -360 || value > 360) throw new Error('Angle must be between −360 and 360°.');
      next.rotation = value;
    } else {
      let points = d.type === 'text' ? [d.position] : d.points;
      if (d.type === 'arrow' && ['length', 'angle'].includes(property)) {
        const length = property === 'length' ? value : box.length;
        const angle = (property === 'angle' ? value : box.angle) * Math.PI / 180;
        if (length < 0) throw new Error('Length cannot be negative.');
        points = [points[0], [points[0][0] + length * Math.cos(angle) / geometry.width, points[0][1] + length * Math.sin(angle) / geometry.height]];
      } else if (['x', 'y'].includes(property)) {
        const axis = property === 'x' ? 0 : 1, dimension = axis ? geometry.height : geometry.width;
        points = points.map(p => p.map((v, i) => i === axis ? v + (value - box[property]) / dimension : v));
      } else if (['width', 'height'].includes(property)) {
        if (value < 0) throw new Error('Size cannot be negative.');
        const axis = property === 'width' ? 0 : 1, dimension = axis ? geometry.height : geometry.width;
        const origin = axis ? box.y : box.x, old = box[property];
        if (old === 0 && value !== 0 && d.type === 'pen') throw new Error('This stroke has no extent in that direction.');
        points = points.map((p, index) => p.map((v, i) => i === axis ? (origin + (old ? (v * dimension - origin) * value / old : index * value)) / dimension : v));
      } else throw new Error('This property is unavailable for the selected drawing.');
      if (points.some(p => p.some(v => v < -1e-9 || v > 1 + 1e-9))) throw new Error('Keep the drawing within the page. Try moving it or reducing its size first.');
      points = points.map(p => p.map(v => Math.max(0, Math.min(1, v))));
      if (d.type === 'text') next.position = points[0]; else next.points = points;
    }
    return next;
  }
  function render(svg, drawings, geometry, selected) {
    svg.replaceChildren();
    const point = p => [p[0] * geometry.width, p[1] * geometry.height];
    for (const d of drawings) {
      if (d.page !== geometry.page) continue;
      const group = element('g', {'data-id': d.id});
      const box = bounds(d, geometry);
      if (d.rotation) group.setAttribute('transform', `rotate(${d.rotation} ${box.x + box.width / 2} ${box.y + box.height / 2})`);
      if (selected === d.id) group.classList.add('selected');
      const style = {stroke: d.color, 'stroke-width': d.lineWidth || 1, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round'};
      if (d.type === 'text') {
        const [x, y] = point(d.position);
        const node = element('text', {x, y, fill: d.color, 'font-size': d.fontSize, 'font-family': 'Arial, sans-serif', 'dominant-baseline': 'hanging', 'xml:space': 'preserve'});
        d.text.split('\n').forEach((line, index) => {
          const span = element('tspan', {x, dy: index ? d.fontSize * 1.2 : 0});
          span.textContent = line || ' ';
          node.append(span);
        });
        group.append(node);
      } else {
        const points = d.points.map(point);
        if (d.type === 'rectangle') {
          const [a, b] = points;
          const rect = {x: Math.min(a[0], b[0]), y: Math.min(a[1], b[1]), width: Math.abs(a[0] - b[0]), height: Math.abs(a[1] - b[1])};
          group.append(element('rect', {...rect, fill: 'transparent', stroke: 'transparent', 'stroke-width': 10, 'pointer-events': 'all'}));
          group.append(element('rect', {...style, ...rect}));
        } else {
          const path = 'M' + points.map(p => p.join(',')).join(' L');
          // A transparent wider stroke makes narrow pen and arrow lines selectable.
          group.append(element('path', {d: path, stroke: 'transparent', 'stroke-width': Math.max(10, d.lineWidth), fill: 'none', 'pointer-events': 'stroke'}));
          group.append(element('path', {...style, d: path}));
          if (d.type === 'arrow') {
            const [a, b] = points, angle = Math.atan2(b[1] - a[1], b[0] - a[0]);
            const size = Math.max(9, d.lineWidth * 4);
            const left = [b[0] - size * Math.cos(angle - .45), b[1] - size * Math.sin(angle - .45)];
            const right = [b[0] - size * Math.cos(angle + .45), b[1] - size * Math.sin(angle + .45)];
            group.append(element('path', {...style, d: `M${left} L${b} L${right}`}));
          }
        }
      }
      // Keep selection visible and clickable even when the drawing is fully transparent.
      for (const child of Array.from(group.children)) child.setAttribute('opacity', d.opacity ?? 1);
      if (selected === d.id) {
        const text = d.type === 'text';
        group.append(element('rect', {x: box.x - 4, y: box.y - 4, width: Math.max(8, text ? d.fontSize * .6 * Math.max(...d.text.split('\n').map(s => s.length)) : box.width + 8), height: Math.max(8, text ? d.fontSize * 1.2 * d.text.split('\n').length : box.height + 8), fill: 'none', stroke: '#2473d5', 'stroke-width': 1, 'stroke-dasharray': '4 3', 'pointer-events': 'none'}));
      }
      svg.append(group);
    }
  }
  return {element, render, bounds, properties, update};
})();
