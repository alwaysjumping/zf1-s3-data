'use strict';
// Small local fallbacks for Chrome 49 / Firefox 52. No CDN or runtime build required.
(function () {
  if (!Object.entries) Object.entries = function (object) { return Object.keys(object).map(function (key) { return [key, object[key]]; }); };
  if (!Array.prototype.includes) Array.prototype.includes = function (value) { return this.indexOf(value) !== -1; };
  if (!String.prototype.padStart) String.prototype.padStart = function (length, padding) {
    var result = String(this), pad = padding === undefined ? ' ' : String(padding);
    if (!pad) return result;
    while (result.length < length) result = pad.slice(0, length - result.length) + result;
    return result;
  };
  if (!NodeList.prototype.forEach) NodeList.prototype.forEach = Array.prototype.forEach;
  var append = function () {
    for (var i = 0; i < arguments.length; i++) this.appendChild(typeof arguments[i] === 'string' ? document.createTextNode(arguments[i]) : arguments[i]);
  };
  if (!Element.prototype.append) Element.prototype.append = append;
  if (!Element.prototype.replaceChildren) Element.prototype.replaceChildren = function () {
    while (this.firstChild) this.removeChild(this.firstChild);
    append.apply(this, arguments);
  };
  if (!Element.prototype.replaceWith) Element.prototype.replaceWith = function (node) { if (this.parentNode) this.parentNode.replaceChild(node, this); };

  function Observer(callback, options) {
    this.callback = callback; this.root = options.root; this.margin = parseFloat(options.rootMargin) || 0; this.targets = []; this.frame = null;
    var self = this;
    this.refresh = function () {
      if (self.frame !== null) return;
      self.frame = requestAnimationFrame(function () {
        self.frame = null;
        var root = self.root.getBoundingClientRect(), margin = self.margin;
        self.callback(self.targets.map(function (target) {
          var rect = target.getBoundingClientRect();
          return {target: target, isIntersecting: root.width > 0 && root.height > 0 && rect.bottom > root.top - margin && rect.top < root.bottom + margin && rect.right > root.left - margin && rect.left < root.right + margin};
        }));
      });
    };
    this.root.addEventListener('scroll', this.refresh);
    window.addEventListener('resize', this.refresh);
  }
  Observer.prototype.observe = function (target) { this.targets.push(target); this.refresh(); };
  Observer.prototype.disconnect = function () {
    this.root.removeEventListener('scroll', this.refresh); window.removeEventListener('resize', this.refresh);
    if (this.frame !== null) cancelAnimationFrame(this.frame);
    this.frame = null; this.targets = [];
  };

  // Translate mouse/touch into the pointer events already used by drawing and resizing.
  if (!window.PointerEvent) {
    var captures = {}, primaryTouch = null, lastTouch = 0;
    function send(type, target, original, point, pointerId, pointerType, primary) {
      var event = document.createEvent('Event'); event.initEvent(type, true, true);
      event.clientX = point.clientX; event.clientY = point.clientY;
      event.pointerId = pointerId; event.pointerType = pointerType; event.isPrimary = primary;
      event.button = pointerType === 'touch' ? 0 : original.button;
      target.dispatchEvent(event);
      if (event.defaultPrevented && original.preventDefault) original.preventDefault();
    }
    Element.prototype.setPointerCapture = function (id) { captures[id] = this; };
    Element.prototype.hasPointerCapture = function (id) { return captures[id] === this; };
    Element.prototype.releasePointerCapture = function (id) {
      if (captures[id] !== this) return;
      delete captures[id];
      var event = document.createEvent('Event'); event.initEvent('lostpointercapture', true, false); event.pointerId = id; this.dispatchEvent(event);
    };
    ['mousedown', 'mousemove', 'mouseup'].forEach(function (name) {
      document.addEventListener(name, function (event) {
        if (Date.now() - lastTouch < 800) return;
        var target = captures[1] || event.target;
        send({mousedown: 'pointerdown', mousemove: 'pointermove', mouseup: 'pointerup'}[name], target, event, event, 1, 'mouse', true);
        if (name === 'mouseup' && captures[1]) captures[1].releasePointerCapture(1);
      }, true);
    });
    ['touchstart', 'touchmove', 'touchend', 'touchcancel'].forEach(function (name) {
      document.addEventListener(name, function (event) {
        lastTouch = Date.now();
        if (name === 'touchstart' && primaryTouch === null) primaryTouch = event.changedTouches[0].identifier;
        for (var i = 0; i < event.changedTouches.length; i++) {
          var touch = event.changedTouches[i], id = touch.identifier + 2;
          send({touchstart: 'pointerdown', touchmove: 'pointermove', touchend: 'pointerup', touchcancel: 'pointercancel'}[name], captures[id] || touch.target, event, touch, id, 'touch', touch.identifier === primaryTouch);
          if (name === 'touchend' || name === 'touchcancel') {
            if (captures[id]) captures[id].releasePointerCapture(id);
            if (touch.identifier === primaryTouch) primaryTouch = null;
          }
        }
      }, {capture: true, passive: false});
    });
    window.addEventListener('blur', function () {
      Object.keys(captures).forEach(function (id) {
        var target = captures[id];
        send('pointercancel', target, {}, {clientX: 0, clientY: 0}, Number(id), 'mouse', true);
        if (captures[id]) target.releasePointerCapture(Number(id));
      });
      primaryTouch = null;
    });
  }

  window.ReviewCompat = {
    key: function (event) { return event.key || ({13: 'Enter', 27: 'Escape', 35: 'End', 36: 'Home', 37: 'ArrowLeft', 39: 'ArrowRight'})[event.keyCode] || ''; },
    Observer: window.IntersectionObserver || Observer,
    point: function (svg, x, y) { var p = svg.createSVGPoint(); p.x = x; p.y = y; return p.matrixTransform(svg.getScreenCTM().inverse()); },
    utf8Length: function (text) {
      var bytes = 0;
      for (var i = 0; i < text.length; i++) {
        var code = text.charCodeAt(i);
        if (code < 128) bytes++; else if (code < 2048) bytes += 2;
        else if (code >= 0xd800 && code <= 0xdbff && i + 1 < text.length && text.charCodeAt(i + 1) >= 0xdc00 && text.charCodeAt(i + 1) <= 0xdfff) { bytes += 4; i++; }
        else bytes += 3;
      }
      return bytes;
    },
    reveal: function (node, root) {
      var bounds = node.getBoundingClientRect(), viewport = root.getBoundingClientRect();
      if (bounds.top < viewport.top) root.scrollTop += bounds.top - viewport.top;
      else if (bounds.bottom > viewport.bottom) root.scrollTop += bounds.bottom - viewport.bottom;
      if (bounds.left < viewport.left) root.scrollLeft += bounds.left - viewport.left;
      else if (bounds.right > viewport.right) root.scrollLeft += bounds.right - viewport.right;
    },
    focus: function (node, root) { var top = root.scrollTop, left = root.scrollLeft; node.focus(); root.scrollTop = top; root.scrollLeft = left; },
    request: function (url, options) {
      return new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest(); options = options || {};
        xhr.open(options.method || 'GET', url, true); xhr.timeout = 120000;
        Object.keys(options.headers || {}).forEach(function (name) { xhr.setRequestHeader(name, options.headers[name]); });
        xhr.onload = function () {
          var data;
          try { data = JSON.parse(xhr.responseText); } catch (_) { reject(new Error('The server returned an unreadable response. Check PHP and database setup.')); return; }
          if (xhr.status < 200 || xhr.status >= 300) reject(new Error(data.error || 'Request failed (' + xhr.status + ').'));
          else resolve(data);
        };
        xhr.onerror = function () { reject(new Error('Cannot reach the server. Check your connection and try again.')); };
        xhr.ontimeout = function () { reject(new Error('The server request timed out. Try again.')); };
        xhr.send(options.body === undefined ? null : options.body);
      });
    }
  };
})();
