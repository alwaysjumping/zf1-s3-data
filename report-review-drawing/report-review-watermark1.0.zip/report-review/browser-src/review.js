'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const editable = document.body.dataset.mode === 'edit';
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  let drawingColor = editable ? $('color').value : '#d62828', colorEdit = null;
  let info, drawings = [], saved = '[]', ready = false, saving = false, tool = 'select';
  let selected = null, active = null, noteAt = null, editing = false, currentPage = 1;
  const undo = [], pageViews = [];
  const copy = value => JSON.parse(JSON.stringify(value));
  const dirty = () => JSON.stringify(drawings) !== saved;
  const status = (message, error = false) => { $('status').textContent = message; $('status').classList.toggle('error', error); };
  const controls = () => {
    $('previous-page').disabled = !ready || currentPage === 1;
    $('next-page').disabled = !ready || currentPage === pageViews.length;
    $('zoom-out').disabled = !ready || $('zoom').selectedIndex === 0;
    $('zoom-in').disabled = !ready || $('zoom').selectedIndex === $('zoom').options.length - 1;
    if (!editable) return;
    $('save').disabled = !ready || saving;
    $('edit-mode').disabled = !ready || editing;
    $('edit-mode').setAttribute('aria-pressed', String(editing));
    $('done-mode').disabled = !ready || !editing;
    $('tools').disabled = !ready || !editing;
    $('undo').disabled = !ready || !editing || !undo.length;
    $('delete').disabled = !ready || !editing || !selected;
    $('edit-text').disabled = !ready || !editing || drawings.find(d => d.id === selected)?.type !== 'text';
    syncProperties();
  };
  function syncProperties() {
    const d = drawings.find(d => d.id === selected);
    $('drawing-properties').hidden = !editing || !d;
    $('selection-help').textContent = d ? `Measurements in PDF points. X/Y: ${d.type === 'arrow' ? 'arrow start' : 'unrotated top-left'}. Positive angles turn clockwise.` : 'Select a drawing to edit its properties. Measurements are in PDF points.';
    const type = d?.type || tool;
    $('line-width').closest('label').hidden = !!d || type === 'text';
    $('font-size').closest('label').hidden = !!d || (type !== 'text' && type !== 'select');
    $('edit-text').hidden = type !== 'text';
    if (!d) return;
    $('selected-type').textContent = ({pen: 'Pen stroke', rectangle: 'Rectangle', arrow: 'Arrow', text: 'Text note'})[d.type] + ' properties';
    const geometry = pageViews.find(p => p.geometry.page === d.page)?.geometry;
    if (!geometry) return;
    const values = {...ReviewDrawings.properties(d, geometry), lineWidth: d.lineWidth ?? 2, fontSize: d.fontSize ?? 14, opacity: (d.opacity ?? 1) * 100};
    document.querySelectorAll('[data-types]').forEach(label => { label.hidden = !label.dataset.types.split(' ').includes(d.type); });
    document.querySelectorAll('[data-property]').forEach(input => {
      input.value = String(Math.round(values[input.dataset.property] * 1000) / 1000);
      input.disabled = !editing || input.closest('label').hidden;
    });
    for (const [inputId, value] of [['line-width', d.lineWidth], ['font-size', d.fontSize]]) {
      if (value == null) continue;
      const input = $(inputId), size = String(value);
      if (!Array.from(input.options).some(option => option.value === size)) input.add(new Option(size, size));
      input.value = size;
    }
    if (noteAt?.id === d.id) layoutTextEditor(pageViews.find(p => p.geometry.page === d.page));
  }
  function redraw() {
    const all = active?.kind === 'draw' ? [...drawings, active.drawing] : drawings;
    pageViews.forEach(p => ReviewDrawings.render(p.svg, all, p.geometry, selected));
    controls();
  }
  function changed() {
    redraw();
    status(saving ? 'Saving… Your newer changes remain local.' : dirty() ? 'Unsaved changes' : 'All changes saved');
  }
  function remember() { undo.push(copy(drawings)); if (undo.length > 100) undo.shift(); }
  function commit(drawing) {
    if (drawings.length >= 2000) { status('Maximum 2,000 drawings. Delete a drawing before adding more.', true); redraw(); return; }
    remember(); drawings.push(drawing); selected = null; changed();
  }
  function finishStroke() {
    if (!active) return;
    const {kind, drawing, svg, pointerId, before} = active;
    active = null;
    if (svg.hasPointerCapture(pointerId)) svg.releasePointerCapture(pointerId);
    if (kind === 'move') {
      if (JSON.stringify(before) !== JSON.stringify(drawings)) {
        undo.push(before); if (undo.length > 100) undo.shift(); changed();
      }
      return;
    }
    if (drawing.points.length === 1) drawing.points.push([...drawing.points[0]]);
    commit(drawing);
  }
  function request(path, options = {}) {
    return ReviewCompat.request('api/' + path, options);
  }
  const id = () => 'd-' + Array.from(crypto.getRandomValues(new Uint32Array(4)), n => n.toString(16)).join('-');
  function base(geometry, type) {
    return {id: id(), page: geometry.page, type, color: drawingColor};
  }
  function position(event, svg) {
    // Inverse SVG transform includes zoom and the page's display rotation.
    const point = ReviewCompat.point(svg, event.clientX, event.clientY);
    return [Math.max(0, Math.min(1, point.x / svg.viewBox.baseVal.width)), Math.max(0, Math.min(1, point.y / svg.viewBox.baseVal.height))];
  }
  function selectDrawing(value) {
    selected = value;
    colorEdit = null;
    const drawing = drawings.find(d => d.id === value);
    if (drawing) {
      $('color').value = drawing.color;
      const input = $(drawing.type === 'text' ? 'font-size' : 'line-width');
      const size = String(drawing.type === 'text' ? drawing.fontSize : drawing.lineWidth);
      if (!Array.from(input.options).some(option => option.value === size)) input.add(new Option(size, size));
      input.value = size;
    } else $('color').value = drawingColor;
    redraw();
  }
  function openText(note, text = '') {
    if (!finishText()) return;
    const drawing = drawings.find(d => d.id === note.id);
    const view = pageViews.find(p => p.geometry.page === (drawing?.page ?? note.geometry?.page));
    if (!view) return;
    noteAt = {...note, geometry: view.geometry, point: drawing?.position ?? note.point};
    $('note-text').value = text; $('note-text').setCustomValidity('');
    $('confirm-text').textContent = note.id ? 'Update note' : 'Add note';
    const editor = $('inline-text-editor');
    view.content.append(editor); editor.hidden = false;
    layoutTextEditor(view);
    ReviewCompat.reveal(editor, $('pages'));
    ReviewCompat.focus($('note-text'), $('pages'));
  }
  function layoutTextEditor(view) {
    if (!noteAt || noteAt.geometry.page !== view.geometry.page) return;
    const editor = $('inline-text-editor'), scale = Number($('zoom').value) * 96 / 72;
    const drawing = drawings.find(d => d.id === noteAt.id);
    if (drawing) noteAt.point = drawing.position;
    const width = view.geometry.width * scale, height = view.geometry.height * scale;
    editor.style.width = Math.min(280 * scale, width) + 'px';
    $('note-text').style.fontSize = (drawing?.fontSize ?? Number($('font-size').value)) * scale + 'px';
    $('note-text').style.color = drawing?.color ?? drawingColor;
    editor.style.left = Math.min(noteAt.point[0] * width, Math.max(0, width - editor.offsetWidth)) + 'px';
    editor.style.top = Math.min(noteAt.point[1] * height, Math.max(0, height - editor.offsetHeight)) + 'px';
  }
  function cancelText() {
    noteAt = null; $('inline-text-editor').hidden = true;
  }
  function finishText() {
    if (!noteAt) return true;
    const input = $('note-text'), text = input.value;
    if (!text.trim()) { cancelText(); return true; }
    input.setCustomValidity(ReviewCompat.utf8Length(text) > 1000 ? 'Use at most 1,000 UTF-8 bytes.' : '');
    if (!input.reportValidity()) return false;
    const note = noteAt; cancelText();
    if (note.id) {
      const d = drawings.find(d => d.id === note.id);
      if (d && d.text !== text) { remember(); d.text = text; changed(); }
    } else commit({...base(note.geometry, 'text'), fontSize: Number($('font-size').value), position: note.point, text});
    return true;
  }
  function setEditing(enabled) {
    if (!editable || !ready) return;
    if (!enabled && !finishText()) return;
    finishStroke(); editing = enabled; selected = null;
    $('drawing-toolbar').hidden = !editing;
    pageViews.forEach(p => {
      p.svg.style.pointerEvents = editing ? '' : 'none';
      p.svg.classList.toggle('editable', editing);
      p.svg.classList.toggle('selecting', editing && tool === 'select');
    });
    redraw();
    status(dirty() ? (editing ? 'Unsaved changes' : 'Editing finished. Use Save drawings to keep your changes.') : editing ? 'Editing enabled' : 'Viewing report');
  }
  function wireDrawing(svg, geometry) {
    svg.addEventListener('pointerdown', event => {
      if (!ready || !editing || active || event.button !== 0 || !event.isPrimary || !svg.closest('.page').classList.contains('loaded')) return;
      if (!finishText()) return;
      if (tool === 'select') {
        const value = event.target.closest('[data-id]')?.dataset.id || null;
        selectDrawing(value);
        if (value) {
          event.preventDefault();
          active = {kind: 'move', svg, pointerId: event.pointerId, start: position(event, svg), original: copy(drawings.find(d => d.id === value)), before: copy(drawings)};
          svg.setPointerCapture(event.pointerId);
        }
        return;
      }
      event.preventDefault();
      const point = position(event, svg);
      if (tool === 'text') {
        const d = drawings.find(d => d.id === event.target.closest('[data-id]')?.dataset.id);
        if (d?.type === 'text') { selectDrawing(d.id); openText({id: d.id}, d.text); return; }
        openText({geometry, point}); return;
      }
      const drawing = {...base(geometry, tool), lineWidth: Number($('line-width').value), points: [point, [...point]]};
      active = {kind: 'draw', drawing, svg, pointerId: event.pointerId};
      selected = null; svg.setPointerCapture(event.pointerId); redraw();
    });
    svg.addEventListener('pointermove', event => {
      if (!editing || !active || active.svg !== svg || event.pointerId !== active.pointerId) return;
      const point = position(event, svg);
      if (active.kind === 'move') {
        const original = active.original, points = original.type === 'text' ? [original.position] : original.points;
        const xs = points.map(p => p[0]), ys = points.map(p => p[1]);
        const dx = Math.max(-Math.min(...xs), Math.min(1 - Math.max(...xs), point[0] - active.start[0]));
        const dy = Math.max(-Math.min(...ys), Math.min(1 - Math.max(...ys), point[1] - active.start[1]));
        const moved = points.map(p => [Math.max(0, Math.min(1, p[0] + dx)), Math.max(0, Math.min(1, p[1] + dy))]);
        const target = drawings.find(d => d.id === original.id);
        if (target.type === 'text') target.position = moved[0]; else target.points = moved;
        redraw(); return;
      }
      const d = active.drawing;
      if (d.type === 'pen') {
        if (d.points.length < 10000) d.points.push(point);
      } else d.points[1] = point;
      ReviewDrawings.render(svg, [...drawings, d], geometry, null);
    });
    svg.addEventListener('pointerup', event => { if (active && active.pointerId === event.pointerId) finishStroke(); });
    svg.addEventListener('pointercancel', () => { if (active?.kind === 'move') drawings = active.before; active = null; redraw(); });
    svg.addEventListener('lostpointercapture', () => { if (active && active.svg === svg) finishStroke(); });
    svg.addEventListener('dblclick', event => {
      if (!editing || tool !== 'select') return;
      const d = drawings.find(d => d.id === event.target.closest('[data-id]')?.dataset.id);
      if (d?.type === 'text') openText({id: d.id}, d.text);
    });
  }
  function imageError() {
    const failed = pageViews.filter(p => p.page.classList.contains('failed')).length;
    $('image-status').textContent = failed ? `${failed} page image(s) failed. Use Retry beside the page, or reload if your session or PDF changed.` : '';
  }
  // Decode off-screen; never attach an empty or failed image to the viewer.
  function requestImage(url, isCurrent, success, failure, retrying, attempt = 0) {
    const img = new Image(); img.draggable = false;
    img.onload = () => { if (isCurrent()) success(img); };
    img.onerror = () => {
      if (!isCurrent()) return;
      if (attempt < 2) {
        retrying();
        setTimeout(() => {
          if (isCurrent()) requestImage(url, isCurrent, success, failure, retrying, attempt + 1);
        }, 750 * (attempt + 1));
      } else failure();
    };
    img.src = url + (attempt ? `&retry=${attempt}-${Date.now()}` : '');
  }
  function loadImage(p, force = false) {
    const level = Number($('zoom').value) > 1.25 ? 'high' : 'standard';
    if (!force && (p.requested === level || p.loaded === 'high' || p.failedLevel === level)) return;
    p.requested = level;
    const token = {}; p.imageRequest = token; p.failedLevel = null;
    p.page.setAttribute('aria-busy', 'true');
    p.placeholder.textContent = 'Loading page…';
    p.retry.hidden = true; p.page.classList.remove('failed'); imageError();
    const url = `api/page-image.php?reportId=1&page=${p.geometry.page}&level=${level}&pdfHash=${encodeURIComponent(info.pdfHash)}`;
    requestImage(url, () => p.imageRequest === token, img => {
      img.alt = `Report page ${p.geometry.page}`;
      p.img.replaceWith(img); p.img = img; p.loaded = level;
      p.placeholder.hidden = true; p.page.setAttribute('aria-busy', 'false');
      p.page.classList.add('loaded'); p.page.classList.remove('failed'); p.retry.hidden = true; imageError();
    }, () => {
      p.failedLevel = level; p.page.setAttribute('aria-busy', 'false');
      p.placeholder.textContent = 'Page image unavailable. Use Retry image above.';
      p.requested = null; p.page.classList.add('failed'); p.retry.hidden = false; imageError();
    }, () => { p.placeholder.textContent = 'Preparing page… Retrying image.'; });
  }
  function loadThumbnail(p, force = false) {
    if (!force && p.thumbRequested) return;
    p.thumbRequested = true; p.thumbFailed = false;
    const token = {}; p.thumbRequest = token;
    p.thumbPlaceholder.textContent = 'Loading…';
    const url = `api/page-image.php?reportId=1&page=${p.geometry.page}&level=standard&pdfHash=${encodeURIComponent(info.pdfHash)}`;
    requestImage(url, () => p.thumbRequest === token, img => {
      img.alt = ''; img.style.transform = `rotate(${p.rotation}deg)`;
      p.thumbImage.replaceWith(img); p.thumbImage = img; p.thumbPlaceholder.hidden = true;
    }, () => {
      p.thumbFailed = true;
      p.thumbPlaceholder.textContent = 'Preview unavailable. Click to retry.';
    }, () => { p.thumbPlaceholder.textContent = 'Retrying…'; });
  }
  const thumbnailObserver = new ReviewCompat.Observer(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !$('thumbnails').hidden) {
        const p = pageViews.find(p => p.thumb === entry.target);
        if (p) loadThumbnail(p);
      }
    });
  }, {root: $('thumbnails'), rootMargin: '150px'});
  const observer = new ReviewCompat.Observer(entries => {
    entries.forEach(entry => {
      const p = pageViews.find(p => p.page === entry.target);
      p.visible = entry.isIntersecting;
      if (p.visible) loadImage(p);
    });
  }, {root: $('pages'), rootMargin: '600px'});
  function layoutPage(p) {
    const scale = Number($('zoom').value) * 96 / 72;
    const w = p.geometry.width * scale, h = p.geometry.height * scale;
    const sideways = p.rotation % 180 !== 0;
    p.page.style.width = (sideways ? h : w) + 'px';
    p.page.style.height = (sideways ? w : h) + 'px';
    p.wrap.style.width = p.page.style.width;
    p.content.style.width = w + 'px'; p.content.style.height = h + 'px';
    const transforms = {0: '', 90: `translate(${h}px, 0) rotate(90deg)`, 180: `translate(${w}px, ${h}px) rotate(180deg)`, 270: `translate(0, ${w}px) rotate(270deg)`};
    p.content.style.transform = transforms[p.rotation];
    p.thumbImage.style.transform = `rotate(${p.rotation}deg)`;
    if (editable) layoutTextEditor(p);
  }
  function zoom() {
    finishStroke();
    pageViews.forEach(p => {
      layoutPage(p);
      if (p.visible) loadImage(p);
    });
    if (observer.refresh) observer.refresh();
    if (thumbnailObserver.refresh) thumbnailObserver.refresh();
    controls();
  }
  function setCurrentPage(number) {
    currentPage = number; $('page-selector').value = String(number);
    pageViews.forEach(p => p.thumb.setAttribute('aria-current', p.geometry.page === number ? 'page' : 'false'));
    controls();
  }
  function goToPage(number) {
    const p = pageViews[number - 1]; if (!p) return;
    finishStroke(); setCurrentPage(number);
    const top = p.wrap.getBoundingClientRect().top - $('pages').getBoundingClientRect().top + $('pages').scrollTop;
    $('pages').scrollTop = Math.max(0, top - 18); $('pages').scrollLeft = 0;
  }
  let scrollFrame;
  $('pages').addEventListener('scroll', () => {
    cancelAnimationFrame(scrollFrame);
    scrollFrame = requestAnimationFrame(() => {
      const viewport = $('pages').getBoundingClientRect();
      let best = null, area = -1;
      pageViews.forEach(p => {
        const rect = p.page.getBoundingClientRect();
        const visible = Math.max(0, Math.min(rect.bottom, viewport.bottom) - Math.max(rect.top, viewport.top));
        if (visible > area) { best = p; area = visible; }
      });
      if (best) setCurrentPage(best.geometry.page);
    });
  });
  function rotate(delta) {
    if (!ready) return;
    finishStroke(); const p = pageViews[currentPage - 1];
    p.rotation = (p.rotation + delta + 360) % 360;
    layoutPage(p); goToPage(currentPage);
  }
  function buildPages() {
    for (const geometry of info.pages) {
      const wrap = document.createElement('div'); wrap.className = 'page-wrap';
      const caption = document.createElement('div'); caption.className = 'page-caption'; caption.textContent = `PAGE ${String(geometry.page).padStart(2, '0')} / ${info.pageCount}`;
      const retry = document.createElement('button'); retry.textContent = 'Retry image'; retry.className = 'page-retry'; retry.hidden = true; caption.append(retry);
      const page = document.createElement('div'); page.className = 'page';
      const content = document.createElement('div'); content.className = 'page-content';
      const img = document.createElement('img'); img.alt = ''; img.hidden = true;
      const placeholder = document.createElement('div'); placeholder.className = 'page-placeholder'; placeholder.textContent = 'Loading page…'; placeholder.setAttribute('role', 'status');
      const svg = ReviewDrawings.element('svg', {viewBox: `0 0 ${geometry.width} ${geometry.height}`, 'aria-label': `Annotations for page ${geometry.page}`});
      if (editable) wireDrawing(svg, geometry);
      svg.style.pointerEvents = 'none';
      content.append(img, svg); page.append(content, placeholder); wrap.append(caption, page); $('pages').append(wrap);
      const thumb = document.createElement('button'); thumb.type = 'button'; thumb.className = 'thumbnail'; thumb.setAttribute('aria-label', `Go to page ${geometry.page}`);
      const thumbFrame = document.createElement('span'); thumbFrame.className = 'thumbnail-image';
      const thumbImage = document.createElement('img'); thumbImage.alt = ''; thumbImage.hidden = true;
      const thumbPlaceholder = document.createElement('span'); thumbPlaceholder.className = 'thumbnail-placeholder'; thumbPlaceholder.textContent = 'Loading…';
      const thumbLabel = document.createElement('span'); thumbLabel.textContent = `Page ${geometry.page}`;
      thumbFrame.append(thumbImage, thumbPlaceholder); thumb.append(thumbFrame, thumbLabel); $('thumbnails').append(thumb);
      const p = {page, content, wrap, img, svg, geometry, retry, placeholder, rotation: 0, thumb, thumbImage, thumbPlaceholder}; pageViews.push(p);
      thumb.addEventListener('click', () => { goToPage(geometry.page); if (p.thumbFailed) loadThumbnail(p, true); });
      thumbnailObserver.observe(thumb);
      retry.addEventListener('click', () => loadImage(p, true)); observer.observe(page);
    }
    $('page-selector').replaceChildren(...info.pages.map(p => new Option(String(p.page), String(p.page))));
    $('total-pages').textContent = `/ ${info.pageCount}`;
    zoom(); redraw(); setCurrentPage(1);
  }
  $('zoom').addEventListener('change', () => { zoom(); goToPage(currentPage); });
  $('zoom-out').addEventListener('click', () => { $('zoom').selectedIndex = Math.max(0, $('zoom').selectedIndex - 1); zoom(); goToPage(currentPage); });
  $('zoom-in').addEventListener('click', () => { $('zoom').selectedIndex = Math.min($('zoom').options.length - 1, $('zoom').selectedIndex + 1); zoom(); goToPage(currentPage); });
  $('previous-page').addEventListener('click', () => goToPage(currentPage - 1));
  $('next-page').addEventListener('click', () => goToPage(currentPage + 1));
  $('page-selector').addEventListener('change', () => goToPage(Number($('page-selector').value)));
  $('rotate-left').addEventListener('click', () => rotate(-90));
  $('rotate-right').addEventListener('click', () => rotate(90));
  $('toggle-thumbnails').addEventListener('click', () => {
    const panel = $('thumbnails'); panel.hidden = !panel.hidden;
    $('toggle-thumbnails').setAttribute('aria-expanded', String(!panel.hidden));
    if (thumbnailObserver.refresh) thumbnailObserver.refresh();
  });
  $('pages').addEventListener('dragstart', event => event.preventDefault());
  if (editable) {
    document.querySelectorAll('[data-property]').forEach(input => input.addEventListener('change', () => {
      if (!editing || !selected) return;
      finishStroke();
      const d = drawings.find(d => d.id === selected);
      const geometry = pageViews.find(p => p.geometry.page === d?.page)?.geometry;
      if (!d || !geometry) return;
      try {
        if (input.value.trim() === '' || !input.checkValidity()) throw new Error('Enter a value within the allowed range.');
        const next = ReviewDrawings.update(d, geometry, input.dataset.property, Number(input.value));
        if (JSON.stringify(next) !== JSON.stringify(d)) { remember(); Object.assign(d, next); changed(); }
      } catch (error) { syncProperties(); status(error.message, true); }
    }));
    $('edit-mode').addEventListener('click', () => { setEditing(true); $('tools').querySelector('[aria-pressed="true"]').focus(); });
    $('done-mode').addEventListener('click', () => { setEditing(false); $('edit-mode').focus(); });
    document.querySelectorAll('[data-tool]').forEach(button => button.addEventListener('click', () => {
      if (!editing || !finishText()) return;
      finishStroke(); tool = button.dataset.tool; selected = null;
      colorEdit = null; $('color').value = drawingColor;
      document.querySelectorAll('[data-tool]').forEach(b => b.setAttribute('aria-pressed', String(b === button)));
      pageViews.forEach(p => p.svg.classList.toggle('selecting', tool === 'select')); redraw();
    }));
    $('delete').addEventListener('click', () => { if (!editing || !selected) return; cancelText(); remember(); drawings = drawings.filter(d => d.id !== selected); selected = null; changed(); });
    $('undo').addEventListener('click', () => { if (!editing) return; cancelText(); finishStroke(); if (undo.length) { drawings = undo.pop(); selected = null; changed(); } });
    $('edit-text').addEventListener('click', () => {
      const d = drawings.find(d => d.id === selected);
      if (editing && d?.type === 'text') openText({id: d.id}, d.text);
    });
    const applyColor = () => {
      if (!editing) return;
      drawingColor = $('color').value;
      const d = drawings.find(d => d.id === selected);
      if (d && d.color !== drawingColor) {
        // A native picker may send many input events before its final change event.
        if (colorEdit !== d.id) { remember(); colorEdit = d.id; }
        d.color = drawingColor; changed();
      }
      if (noteAt) layoutTextEditor(pageViews.find(p => p.geometry.page === noteAt.geometry.page));
    };
    $('color').addEventListener('input', applyColor);
    $('color').addEventListener('change', () => { applyColor(); colorEdit = null; });
    $('color').addEventListener('blur', () => { colorEdit = null; });
    for (const [inputId, property] of [['line-width', 'lineWidth'], ['font-size', 'fontSize']]) {
      $(inputId).addEventListener('change', () => {
        if (!editing) return;
        const d = drawings.find(d => d.id === selected);
        if (!d || (property === 'fontSize' && d.type !== 'text') || (property === 'lineWidth' && d.type === 'text')) return;
        const value = Number($(inputId).value);
        if (d[property] !== value) { remember(); d[property] = value; changed(); }
      });
    }
    $('note-text').addEventListener('input', () => {
      $('note-text').setCustomValidity(ReviewCompat.utf8Length($('note-text').value) > 1000 ? 'Use at most 1,000 UTF-8 bytes.' : '');
    });
    $('confirm-text').addEventListener('click', finishText);
    $('cancel-text').addEventListener('click', cancelText);
    $('inline-text-editor').addEventListener('keydown', event => {
      const key = ReviewCompat.key(event);
      if (key === 'Escape') { event.preventDefault(); cancelText(); }
      else if (key === 'Enter' && (event.ctrlKey || event.metaKey)) { event.preventDefault(); finishText(); }
    });
    $('save').addEventListener('click', async () => {
      if (!ready || saving) return;
      if (!finishText()) return;
      finishStroke(); saving = true; controls(); status('Saving…');
      const snapshot = JSON.stringify(drawings);
      try {
        await request('drawing-save.php', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': csrf}, body: JSON.stringify({reportId: 1, pdfHash: info.pdfHash, formatVersion: 1, drawings: JSON.parse(snapshot)})});
        saved = snapshot; status(dirty() ? 'Saved. Newer changes are still unsaved.' : 'All changes saved');
      } catch (e) { status(e.message + ' Your local drawings are retained.', true); }
      finally { saving = false; controls(); }
    });
    window.addEventListener('beforeunload', event => { if (dirty() || active || (noteAt && $('note-text').value.trim())) { event.preventDefault(); event.returnValue = ''; } });
  }
  const divider = $('divider');
  const maxWidth = () => Math.max(200, Math.min(600, document.querySelector('.workspace').clientWidth - 328));
  function resize(width) {
    const value = Math.round(Math.max(200, Math.min(maxWidth(), width)));
    $('information').style.flexBasis = value + 'px';
    divider.setAttribute('aria-valuenow', value); divider.setAttribute('aria-valuemax', maxWidth());
  }
  divider.addEventListener('pointerdown', e => { if (e.button !== 0) return; divider.setPointerCapture(e.pointerId); document.body.classList.add('resizing'); });
  divider.addEventListener('pointermove', e => { if (divider.hasPointerCapture(e.pointerId)) resize(e.clientX + window.scrollX); });
  const stopResize = () => document.body.classList.remove('resizing');
  divider.addEventListener('pointerup', stopResize); divider.addEventListener('pointercancel', stopResize); divider.addEventListener('lostpointercapture', stopResize);
  divider.addEventListener('keydown', e => {
    const key = ReviewCompat.key(e);
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(key)) {
      e.preventDefault(); const current = Number(divider.getAttribute('aria-valuenow'));
      resize(key === 'Home' ? 200 : key === 'End' ? maxWidth() : current + (key === 'ArrowLeft' ? -10 : 10));
    }
  });
  window.addEventListener('resize', () => resize(Number(divider.getAttribute('aria-valuenow')))); resize(280);
  (async () => {
    try {
      info = await request('report-info.php?reportId=1');
      $('title').textContent = info.title; $('author').textContent = info.author; $('page-count').textContent = info.pageCount;
      const data = await request('drawing-load.php?reportId=1');
      if (data.pdfHash !== info.pdfHash || data.formatVersion !== 1) throw new Error('The document changed. Reload the page.');
      drawings = data.drawings; saved = JSON.stringify(drawings);
      buildPages(); ready = true;
      for (const name of ['toggle-thumbnails', 'page-selector', 'zoom', 'rotate-left', 'rotate-right']) $(name).disabled = false;
      controls(); status(editable ? 'Ready to review. Click Edit to annotate.' : 'Showing saved drawings');
    } catch (e) { status(e.message + ' Reload after correcting the problem.', true); }
  })();
})();
