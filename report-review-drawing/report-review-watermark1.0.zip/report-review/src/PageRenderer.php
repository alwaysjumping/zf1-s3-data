<?php
declare(strict_types=1);
final class PageRenderer {
    private static function publish(string $temporary, string $target): bool {
        // On Windows a scanner can briefly hold a newly rendered file open.
        // Keep publication atomic, but allow that transient file lock to clear.
        for ($attempt = 0; $attempt < 20; $attempt++) {
            if (@rename($temporary, $target)) return true;
            if (PHP_OS_FAMILY !== 'Windows') break;
            usleep(100000);
        }
        return false;
    }
    private static function run(array $args): string {
        $pipes = [];
        $process = proc_open($args, [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, ROOT, null, ['bypass_shell' => true]);
        if (!is_resource($process)) throw new RuntimeException('Cannot start PDF renderer.');
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $output = ''; $errors = ''; $start = microtime(true); $exit = -1;
        try {
            do {
                $output .= stream_get_contents($pipes[1]);
                $errors .= stream_get_contents($pipes[2]);
                $status = proc_get_status($process);
                if (!$status['running']) { $exit = $status['exitcode']; break; }
                if (microtime(true) - $start > 40) {
                    proc_terminate($process);
                    throw new RuntimeException('PDF rendering timed out.');
                }
                usleep(20000);
            } while (true);
            $output .= stream_get_contents($pipes[1]);
            $errors .= stream_get_contents($pipes[2]);
        } finally {
            fclose($pipes[1]); fclose($pipes[2]); proc_close($process);
        }
        if ($exit !== 0) throw new RuntimeException('Renderer failed: ' . $errors);
        return $output;
    }
    private static function directory(string $hash): string {
        $dir = ROOT . '/cache/rendered-pages/' . $hash;
        if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) throw new RuntimeException('Cannot create cache.');
        return $dir;
    }
    public static function metadata(string $hash): array {
        $file = self::directory($hash) . '/metadata.json';
        if (is_file($file)) return json_decode(file_get_contents($file), true, 512, JSON_THROW_ON_ERROR);
        $pages = self::inspect(PdfSource::path());
        ReportService::checkHash($hash);
        $temp = $file . '.' . bin2hex(random_bytes(6));
        file_put_contents($temp, json_encode($pages, JSON_THROW_ON_ERROR));
        if (!self::publish($temp, $file)) { @unlink($temp); if (!is_file($file)) throw new RuntimeException('Cannot publish metadata.'); }
        return $pages;
    }
    public static function inspect(string $source): array {
        global $config;
        $summary = self::run([$config['pdfinfo'], $source]);
        if (preg_match('/^Encrypted:\s+yes/m', $summary)) throw new RuntimeException('Password-protected PDF imports are not supported.');
        if (!preg_match('/^Pages:\s+(\d+)/m', $summary, $m)) throw new RuntimeException('Cannot read PDF pages.');
        $count = (int)$m[1];
        if ($count < 1 || $count > 500) throw new RuntimeException('PDF page count outside supported range.');
        $detail = self::run([$config['pdfinfo'], '-f', '1', '-l', (string)$count, '-box', $source]);
        $pages = [];
        for ($i = 1; $i <= $count; $i++) {
            if (!preg_match('/^Page\s+' . $i . '\s+CropBox:\s+([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)/m', $detail, $box)) throw new RuntimeException('Missing crop box.');
            $w = (float)$box[3] - (float)$box[1]; $h = (float)$box[4] - (float)$box[2];
            preg_match('/^Page\s+' . $i . '\s+rot:\s+(-?\d+)/m', $detail, $rotation);
            if (abs((int)($rotation[1] ?? 0)) % 180 === 90) { $swap = $w; $w = $h; $h = $swap; }
            if ($w <= 0 || $h <= 0 || $w > 20000 || $h > 20000) throw new RuntimeException('Unsupported page dimensions.');
            $pages[] = ['page' => $i, 'width' => $w, 'height' => $h];
        }
        return $pages;
    }
    public static function image(string $hash, int $page, string $level): string {
        global $config;
        if (!in_array($level, ['standard', 'high'], true)) throw new HttpError(400, 'Invalid image resolution.');
        $pages = self::metadata($hash);
        if ($page < 1 || $page > count($pages)) throw new HttpError(400, 'Invalid page number.');
        ReportService::checkHash($hash);
        $file = self::directory($hash) . '/' . $page . '-' . $level . '.png';
        if (is_file($file)) return $file;
        $lock = fopen($file . '.lock', 'c');
        if (!$lock) throw new RuntimeException('Cannot lock image cache.');
        $prefix = $file . '.' . bin2hex(random_bytes(6));
        try {
            $start = microtime(true);
            while (!flock($lock, LOCK_EX | LOCK_NB)) {
                if (microtime(true) - $start > 45) throw new RuntimeException('Image cache is busy.');
                usleep(50000);
            }
            if (!is_file($file)) {
                self::run([$config['pdftoppm'], '-f', (string)$page, '-l', (string)$page,
                    '-cropbox', '-singlefile', '-scale-to', $level === 'high' ? '3200' : '1600',
                    '-png', PdfSource::path(), $prefix]);
                ReportService::checkHash($hash);
                if (!is_file($prefix . '.png') || !self::publish($prefix . '.png', $file)) throw new RuntimeException('Cannot publish rendered page.');
            }
        } finally {
            @unlink($prefix . '.png'); flock($lock, LOCK_UN); fclose($lock);
        }
        return $file;
    }
}
