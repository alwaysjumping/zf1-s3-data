<?php
declare(strict_types=1);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
define('ROOT', dirname(__DIR__));
$config = require ROOT . '/config/database.php';
require_once __DIR__ . '/AccessGuard.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/PageRenderer.php';
require_once __DIR__ . '/PdfSource.php';
require_once __DIR__ . '/WatermarkService.php';
require_once __DIR__ . '/ReportService.php';
require_once __DIR__ . '/AnnotationService.php';

final class HttpError extends RuntimeException {
    public $status;
    public function __construct(int $status, string $message) {
        parent::__construct($message);
        $this->status = $status;
    }
}
function jsonResponse(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
}
function api(callable $action, string $method = 'GET', bool $edit = false): void {
    try {
        if ($_SERVER['REQUEST_METHOD'] !== $method) {
            header('Allow: ' . $method);
            throw new HttpError(405, 'Method not allowed.');
        }
        AccessGuard::requireAccess($edit);
        if ($method === 'POST') AccessGuard::checkCsrf($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        WatermarkService::initialize();
        session_write_close();
        $action();
    } catch (HttpError $e) {
        jsonResponse(['error' => $e->getMessage()], $e->status);
    } catch (Throwable $e) {
        error_log((string)$e);
        jsonResponse(['error' => 'Server operation failed. Check database and renderer setup.'], 500);
    }
}
