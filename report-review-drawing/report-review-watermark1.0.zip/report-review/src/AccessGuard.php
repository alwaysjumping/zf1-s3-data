<?php
declare(strict_types=1);
final class AccessGuard {
    public static function start(): void {
        if (session_status() === PHP_SESSION_ACTIVE) return;
        ini_set('session.use_strict_mode', '1');
        session_name('report_review');
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict',
            'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'path' => '/']);
        session_start();
        if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    public static function checkCsrf(string $token): void {
        self::start();
        if (!hash_equals($_SESSION['csrf'], $token)) throw new HttpError(403, 'Invalid access token. Reload the page.');
    }
    public static function requireAccess(bool $edit = false): void {
        self::start();
        if (empty($_SESSION['role'])) throw new HttpError(401, 'Please sign in again.');
        if ($edit && $_SESSION['role'] !== 'edit') throw new HttpError(403, 'This session has view-only access.');
    }
    public static function login(string $password): bool {
        global $config;
        foreach (['edit', 'view'] as $role) {
            $hash = $config[$role . '_password_hash'];
            if ($hash !== '' && password_verify($password, $hash)) {
                session_regenerate_id(true);
                $_SESSION['role'] = $role;
                $_SESSION['csrf'] = bin2hex(random_bytes(32));
                return true;
            }
        }
        return false;
    }
}
