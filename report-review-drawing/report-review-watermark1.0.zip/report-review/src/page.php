<?php
require __DIR__ . '/bootstrap.php';
AccessGuard::start();
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        AccessGuard::checkCsrf(is_string($_POST['csrf'] ?? null) ? $_POST['csrf'] : '');
        if (isset($_POST['logout'])) {
            $_SESSION = []; session_regenerate_id(true);
        } elseif (!AccessGuard::login(is_string($_POST['password'] ?? null) ? $_POST['password'] : '')) {
            $error = 'Access password is incorrect or has not been configured.';
        }
        if ($error === '') { header('Location: ' . $mode . '.php', true, 303); exit; }
    } catch (HttpError $e) { $error = $e->getMessage(); }
}
$signedIn = !empty($_SESSION['role']);
$canEdit = $signedIn && $_SESSION['role'] === 'edit' && $mode === 'edit';
$csrf = htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8');
if ($signedIn) WatermarkService::initialize(true);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="csrf-token" content="<?= $csrf ?>">
  <title><?= $mode === 'edit' ? 'Edit' : 'View' ?> review · Monthly Test Report</title>
  <link rel="stylesheet" href="assets/review.css">
  <?php if ($signedIn): ?><script src="assets/compat.js" defer></script><script src="assets/drawings.js" defer></script><script src="assets/review.js" defer></script><?php endif; ?>
</head>
<body data-mode="<?= $canEdit ? 'edit' : 'view' ?>">
<?php if (!$signedIn): ?>
<main class="access-card">
  <div class="eyebrow">REPORT REVIEW / TEST PROJECT</div>
  <h1>A closer look.</h1><p>Sign in to review the Monthly Test Report.</p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= $csrf ?>">
    <label for="password">Access password</label>
    <input id="password" name="password" type="password" autocomplete="current-password" required autofocus>
    <button class="primary" type="submit">Open report →</button>
  </form>
  <?php if ($error): ?><p class="error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
  <p class="muted">Configure your test password in the private configuration before signing in.</p>
</main>
<?php else: ?>
<header class="app-header"><a class="brand" href="<?= $mode ?>.php"><span class="brand-mark">R</span> Report Review</a><span class="badge"><?= $canEdit ? 'EDIT WORKSPACE' : 'READ ONLY' ?></span></header>
<main class="workspace">
  <aside id="information">
    <div class="eyebrow">DOCUMENT / 001</div><h1 id="title">Monthly Test Report</h1>
    <dl><dt>Author</dt><dd id="author">John Smith</dd><dt>Pages</dt><dd id="page-count">—</dd></dl>
    <div class="rule"></div><h2><?= $canEdit ? 'Review notes' : 'Saved review' ?></h2>
    <p class="muted"><?= $canEdit ? 'Click Edit to annotate. Done returns to viewing; use Save drawings to keep your changes.' : 'Explore the report and its saved annotations. Refresh to see the latest saved review.' ?></p>
    <?php if ($canEdit): ?><button id="save" class="primary" disabled>Save drawings</button><?php endif; ?>
    <p id="status" role="status" aria-live="polite">Loading report…</p>
    <p id="image-status" role="status" class="error"></p>
    <a class="page-link" href="<?= $mode === 'edit' ? 'view.php' : 'edit.php' ?>"><?= $mode === 'edit' ? 'Open saved view' : 'Back to editor' ?> →</a>
    <?php if ($mode === 'edit' && !$canEdit): ?><p class="muted">Your password grants view-only access.</p><?php endif; ?>
    <form method="post" class="logout"><input type="hidden" name="csrf" value="<?= $csrf ?>"><button name="logout" value="1" class="quiet">Sign out</button></form>
  </aside>
  <div id="divider" role="separator" tabindex="0" aria-label="Resize information panel" aria-orientation="vertical" aria-valuemin="200" aria-valuemax="500" aria-valuenow="280"></div>
  <section class="document-panel" aria-label="Report document">
    <header class="toolbar viewer-toolbar" aria-label="PDF viewer controls">
      <button id="toggle-thumbnails" type="button" aria-expanded="false" aria-controls="thumbnails" disabled>Thumbnails</button>
      <div class="control-group">
        <button id="previous-page" type="button" aria-label="Previous page" disabled>‹</button>
        <label>Page <select id="page-selector" aria-label="Page selector" disabled><option>1</option></select></label>
        <span id="total-pages" class="toolbar-label">/ —</span>
        <button id="next-page" type="button" aria-label="Next page" disabled>›</button>
      </div>
      <div class="control-group">
        <button id="zoom-out" type="button" aria-label="Zoom out" disabled>−</button>
        <label>Zoom <select id="zoom" aria-label="Zoom" disabled><option value="0.75">75%</option><option value="1" selected>100%</option><option value="1.25">125%</option><option value="1.5">150%</option><option value="2">200%</option></select></label>
        <button id="zoom-in" type="button" aria-label="Zoom in" disabled>+</button>
      </div>
      <div class="control-group">
        <button id="rotate-left" type="button" aria-label="Rotate current page left" title="Rotate current page left" disabled>↶</button>
        <button id="rotate-right" type="button" aria-label="Rotate current page right" title="Rotate current page right" disabled>↷</button>
      </div>
      <?php if ($canEdit): ?><div class="mode-controls"><button id="edit-mode" type="button" class="primary" aria-pressed="false" disabled>Edit</button><button id="done-mode" type="button" disabled>Done</button></div><?php endif; ?>
    </header>
    <div class="viewer-body">
      <nav id="thumbnails" aria-label="Page thumbnails" hidden></nav>
      <div id="pages" tabindex="0" aria-label="Scrollable report pages"></div>
    </div>
    <?php if ($canEdit): ?>
    <footer id="drawing-toolbar" class="toolbar drawing-toolbar" aria-label="Annotation controls" hidden>
      <fieldset id="tools" disabled aria-label="Drawing tools">
        <button type="button" data-tool="select" aria-pressed="true" title="Select and drag a drawing to move it">Select</button>
        <button type="button" data-tool="pen" aria-pressed="false">Pen</button>
        <button type="button" data-tool="rectangle" aria-pressed="false">Rectangle</button>
        <button type="button" data-tool="arrow" aria-pressed="false">Arrow</button>
        <button type="button" data-tool="text" aria-pressed="false">Text</button>
        <label>Color <input id="color" aria-label="Drawing color" type="color" value="#d62828"></label>
        <label>Width <select id="line-width" aria-label="Line width"><option>1</option><option selected>2</option><option>4</option><option>8</option></select></label>
        <label>Text <select id="font-size" aria-label="Text size"><option>10</option><option selected>14</option><option>20</option><option>28</option></select></label>
        <button id="edit-text" type="button" disabled>Edit text</button>
        <button id="delete" type="button" disabled>Delete</button><button id="undo" type="button" disabled>Undo</button>
      </fieldset>
      <span id="selection-help" class="toolbar-help">Select a drawing to edit its properties. Measurements are in PDF points.</span>
      <fieldset id="drawing-properties" aria-label="Selected drawing properties" hidden>
        <legend id="selected-type">Drawing properties</legend>
        <label data-types="pen rectangle arrow">Thickness <input id="property-lineWidth" data-property="lineWidth" type="number" min="0.5" max="20" step="any" aria-label="Drawing thickness"></label>
        <label data-types="text">Font size <input id="property-fontSize" data-property="fontSize" type="number" min="6" max="72" step="any" aria-label="Note font size"></label>
        <label>X <input id="property-x" data-property="x" type="number" min="0" step="any" aria-label="Position X"></label>
        <label>Y <input id="property-y" data-property="y" type="number" min="0" step="any" aria-label="Position Y"></label>
        <label data-types="pen rectangle">Width <input id="property-width" data-property="width" type="number" min="0" step="any" aria-label="Drawing width"></label>
        <label data-types="pen rectangle">Height <input id="property-height" data-property="height" type="number" min="0" step="any" aria-label="Drawing height"></label>
        <label data-types="arrow">Length <input id="property-length" data-property="length" type="number" min="0" step="any" aria-label="Line length"></label>
        <label>Angle ° <input id="property-angle" data-property="angle" type="number" min="-360" max="360" step="any" aria-label="Drawing angle"></label>
        <label>Opacity % <input id="property-opacity" data-property="opacity" type="number" min="0" max="100" step="any" aria-label="Drawing opacity"></label>
      </fieldset>
    </footer>
    <?php endif; ?>
  </section>
</main>
<?php if ($canEdit): ?>
<div id="inline-text-editor" class="inline-text-editor" aria-label="Text note editor" hidden><label for="note-text">Annotation text</label><textarea id="note-text" rows="3" required maxlength="1000" placeholder="Type your note…"></textarea><p class="inline-text-help">Ctrl/⌘ + Enter to apply · Esc to cancel</p><div class="inline-text-actions"><button id="cancel-text" type="button">Cancel</button><button id="confirm-text" type="button" class="primary">Add note</button></div></div>
<?php endif; ?>
<?php endif; ?>
</body></html>
