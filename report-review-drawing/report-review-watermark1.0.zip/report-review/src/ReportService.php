<?php
declare(strict_types=1);
final class ReportService {
    public static function checkId($id): void {
        if ($id !== 1 && $id !== '1') throw new HttpError(404, 'Report unavailable.');
    }
    public static function hash(): string {
        $path = PdfSource::path();
        if (!is_file($path)) throw new HttpError(404, 'Report unavailable.');
        return hash_file('sha256', $path);
    }
    public static function info(): array {
        $hash = self::hash();
        $pages = PageRenderer::metadata($hash);
        if (self::hash() !== $hash) throw new HttpError(409, 'The PDF changed. Reload the report.');
        return ['reportId' => 1, 'title' => 'Monthly Test Report', 'author' => 'John Smith',
            'pdfHash' => $hash, 'pageCount' => count($pages), 'pages' => $pages];
    }
    public static function checkHash($hash): void {
        if (!is_string($hash) || !hash_equals(self::hash(), $hash))
            throw new HttpError(409, 'The PDF changed. Reset or archive the old drawings before continuing.');
    }
}
