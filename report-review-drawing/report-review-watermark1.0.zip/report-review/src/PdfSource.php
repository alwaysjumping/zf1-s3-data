<?php
declare(strict_types=1);
final class PdfSource {
    private static function publish(string $temporary, string $file): void {
        for ($attempt = 0; $attempt < 20; $attempt++) {
            if (@rename($temporary, $file)) return;
            if (PHP_OS_FAMILY !== 'Windows') break;
            usleep(100000);
        }
        throw new RuntimeException('Cannot publish imported PDF.');
    }
    private static function removeTemporary(string $temporary): void {
        for ($attempt = 0; $attempt < 20; $attempt++) {
            if (!is_file($temporary) || @unlink($temporary)) return;
            if (PHP_OS_FAMILY !== 'Windows') break;
            usleep(100000);
        }
        throw new RuntimeException('Cannot remove temporary PDF import.');
    }
    public static function path(): string {
        global $config;
        $url = $config['pdf_url'] ?? '';
        if ($url === '') return ROOT . '/pdfs/test_report.pdf';
        if (!is_string($url)) throw new RuntimeException('PDF URL must be a string.');
        return self::import($url);
    }
    public static function import(string $url): string {
        $parts = parse_url($url);
        if (!filter_var($url, FILTER_VALIDATE_URL) || !$parts || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)
            || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']))
            throw new RuntimeException('Configure a valid HTTP or HTTPS PDF URL without embedded credentials.');
        $directory = ROOT . '/cache/imported-pdfs/' . hash('sha256', $url);
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) throw new RuntimeException('Cannot create PDF import cache.');
        $file = $directory . '/source.pdf';
        if (is_file($file)) return $file;
        if (!function_exists('curl_init')) throw new RuntimeException('PDF URL import requires PHP cURL.');
        $lock = fopen($directory . '/import.lock', 'c');
        if (!$lock) throw new RuntimeException('Cannot lock PDF import cache.');
        $temporary = $directory . '/download-' . bin2hex(random_bytes(8)) . '.pdf';
        $stream = null; $curl = null;
        try {
            $start = microtime(true);
            while (!flock($lock, LOCK_EX | LOCK_NB)) {
                if (microtime(true) - $start > 60) throw new RuntimeException('PDF import is busy. Try again shortly.');
                usleep(50000);
            }
            if (is_file($file)) return $file;
            $stream = fopen($temporary, 'xb');
            if (!$stream) throw new RuntimeException('Cannot create temporary PDF import.');
            $bytes = 0; $tooLarge = false; $responseStatus = 0;
            $curl = curl_init($url);
            curl_setopt_array($curl, [CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
                CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 45, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_FAILONERROR => true, CURLOPT_USERAGENT => 'ReportReview-PDF-Import/1.0',
                CURLOPT_HEADERFUNCTION => static function ($handle, string $header) use (&$responseStatus): int {
                    if (preg_match('/^HTTP\/\S+\s+(\d{3})/', $header, $match)) $responseStatus = (int)$match[1];
                    return strlen($header);
                },
                CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use ($stream, &$bytes, &$tooLarge, &$responseStatus): int {
                    if ($responseStatus >= 300 && $responseStatus < 400) return strlen($chunk);
                    $bytes += strlen($chunk);
                    if ($bytes > 50 * 1024 * 1024) { $tooLarge = true; return 0; }
                    $written = fwrite($stream, $chunk);
                    return $written === false ? 0 : $written;
                }]);
            $ok = curl_exec($curl);
            $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            if (!$ok || $status !== 200) {
                if ($tooLarge) throw new RuntimeException('Imported PDF exceeds the 50 MiB limit.');
                throw new RuntimeException('PDF download failed. Check the configured URL, server access, and TLS certificates.');
            }
            fclose($stream); $stream = null;
            $prefix = file_get_contents($temporary, false, null, 0, 1024);
            if ($prefix === false || strpos($prefix, '%PDF-') === false) throw new RuntimeException('The configured URL did not return a PDF.');
            PageRenderer::inspect($temporary);
            self::publish($temporary, $file);
            return $file;
        } finally {
            if ($curl !== null) curl_close($curl);
            if (is_resource($stream)) fclose($stream);
            flock($lock, LOCK_UN); fclose($lock);
            self::removeTemporary($temporary);
        }
    }
}
