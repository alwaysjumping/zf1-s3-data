<?php
declare(strict_types=1);
final class AnnotationService {
    private static function number($v, float $min, float $max): void {
        if ((!is_int($v) && !is_float($v)) || !is_finite((float)$v) || $v < $min || $v > $max) throw new HttpError(400, 'Invalid drawing size or coordinate.');
    }
    private static function point($point): void {
        if (!is_array($point) || array_keys($point) !== [0, 1]) throw new HttpError(400, 'Invalid drawing point.');
        self::number($point[0], 0, 1); self::number($point[1], 0, 1);
    }
    public static function validate(array $data, array $info): array {
        ReportService::checkId($data['reportId'] ?? null);
        ReportService::checkHash($data['pdfHash'] ?? null);
        if (($data['formatVersion'] ?? null) !== 1) throw new HttpError(400, 'Unsupported drawing format.');
        $drawings = $data['drawings'] ?? null;
        if (!is_array($drawings) || ($drawings !== [] && array_keys($drawings) !== range(0, count($drawings) - 1)) || count($drawings) > 2000) throw new HttpError(400, 'Invalid drawing list (maximum 2,000).');
        $ids = [];
        foreach ($drawings as $d) {
            if (!is_array($d)) throw new HttpError(400, 'Invalid drawing.');
            $id = $d['id'] ?? null;
            if (!is_string($id) || !preg_match('/^[a-zA-Z0-9_-]{1,80}$/D', $id) || isset($ids[$id])) throw new HttpError(400, 'Invalid or duplicate drawing ID.');
            $ids[$id] = true;
            if (!isset($d['page']) || !is_int($d['page']) || $d['page'] < 1 || $d['page'] > $info['pageCount']) throw new HttpError(400, 'Invalid drawing page.');
            if (!isset($d['color']) || !is_string($d['color']) || !preg_match('/^#[0-9a-fA-F]{6}$/D', $d['color'])) throw new HttpError(400, 'Invalid drawing color.');
            $type = $d['type'] ?? '';
            if (!in_array($type, ['pen', 'rectangle', 'arrow', 'text'], true)) throw new HttpError(400, 'Invalid drawing type.');
            if ($type === 'text') {
                self::number($d['fontSize'] ?? null, 6, 72);
                self::point($d['position'] ?? null);
                if (!isset($d['text']) || !is_string($d['text']) || $d['text'] === '' || strlen($d['text']) > 1000 || !preg_match('//u', $d['text'])) throw new HttpError(400, 'Text must contain 1–1,000 UTF-8 bytes.');
            } else {
                self::number($d['lineWidth'] ?? null, 0.5, 20);
                if (!isset($d['points']) || !is_array($d['points']) || count($d['points']) < 2 || count($d['points']) > ($type === 'pen' ? 10000 : 2) || array_keys($d['points']) !== range(0, count($d['points']) - 1)) throw new HttpError(400, 'Invalid drawing points.');
                foreach ($d['points'] as $point) self::point($point);
            }
            if (array_key_exists('opacity', $d)) self::number($d['opacity'], 0, 1);
            if (array_key_exists('rotation', $d)) {
                if ($type === 'arrow') throw new HttpError(400, 'Arrow direction is defined by its endpoints.');
                self::number($d['rotation'], -360, 360);
            }
            $allowed = ['id', 'page', 'type', 'color', 'opacity'];
            if ($type !== 'arrow') $allowed[] = 'rotation';
            $allowed = array_merge($allowed, $type === 'text' ? ['fontSize', 'position', 'text'] : ['lineWidth', 'points']);
            if (array_diff(array_keys($d), $allowed)) throw new HttpError(400, 'Unknown drawing property.');
        }
        return $drawings;
    }
    public static function load(array $info): array {
        $stmt = Database::connect()->prepare('SELECT pdf_sha256, format_version, drawings_json FROM review_drawings WHERE report_id = ?');
        $stmt->execute([1]); $row = $stmt->fetch();
        if ($row && $row['pdf_sha256'] !== $info['pdfHash']) throw new HttpError(409, 'The PDF changed. Archive or reset the old drawings.');
        $data = ['reportId' => 1, 'formatVersion' => $row ? (int)$row['format_version'] : 1,
            'pdfHash' => $info['pdfHash'], 'drawings' => $row ? json_decode($row['drawings_json'], true, 512, JSON_THROW_ON_ERROR) : []];
        self::validate($data, $info);
        return $data;
    }
    public static function save(array $data, array $info): void {
        $drawings = self::validate($data, $info);
        $db = Database::connect(); $db->beginTransaction();
        try {
            $stmt = $db->prepare('SELECT pdf_sha256 FROM review_drawings WHERE report_id = ? FOR UPDATE');
            $stmt->execute([1]); $row = $stmt->fetch();
            if ($row && $row['pdf_sha256'] !== $info['pdfHash']) throw new HttpError(409, 'The PDF changed. Archive or reset the old drawings.');
            ReportService::checkHash($info['pdfHash']);
            $stmt = $db->prepare('INSERT INTO review_drawings (report_id, pdf_sha256, format_version, drawings_json) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE pdf_sha256 = VALUES(pdf_sha256), format_version = VALUES(format_version), drawings_json = VALUES(drawings_json)');
            $stmt->execute([1, $info['pdfHash'], 1, json_encode($drawings, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
            $db->commit();
        } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); throw $e; }
    }
}
