<?php
declare(strict_types=1);
final class WatermarkService {
    public static function initialize(bool $refreshTime = false): void {
        $settings = require ROOT . '/config/watermark.php';
        if (!isset($_SESSION['watermark_seed'])) $_SESSION['watermark_seed'] = bin2hex(random_bytes(32));
        if ($refreshTime || !isset($_SESSION['watermark_datetime'])) $_SESSION['watermark_datetime'] = $settings['lines'][2];
    }
    public static function settings(): array {
        $settings = require ROOT . '/config/watermark.php';
        $settings['lines'][2] = $_SESSION['watermark_datetime'] ?? $settings['lines'][2];
        $settings['seed'] = $_SESSION['watermark_seed'];
        return $settings;
    }
    public static function layout(array $geometry, array $settings): array {
        $count = $settings['count'];
        if (!is_int($count) || $count < 0 || $count > 100) throw new RuntimeException('Watermark count must be between 0 and 100.');
        if (!$count) return [];
        $angleMin = $settings['angleMin'] ?? -35; $angleMax = $settings['angleMax'] ?? 35;
        foreach ([$angleMin, $angleMax] as $angle) {
            if ((!is_int($angle) && !is_float($angle)) || !is_finite((float)$angle) || $angle < -360 || $angle > 360)
                throw new RuntimeException('Watermark angles must be numbers between -360 and 360.');
        }
        if ($angleMin > $angleMax) throw new RuntimeException('Watermark minimum angle must not exceed maximum angle.');
        if (!function_exists('imagettfbbox') || !is_file($settings['font'])) throw new RuntimeException('Watermark requires PHP GD with FreeType and a readable TrueType font.');
        $random = static function (string $label) use ($geometry, $settings): float {
            $digest = hash_hmac('sha256', $geometry['page'] . ':' . $label, $settings['seed']);
            return hexdec(substr($digest, 0, 8)) / 4294967296;
        };
        $columns = max(1, (int)ceil(sqrt($count * $geometry['width'] / $geometry['height'])));
        $rows = (int)ceil($count / $columns);
        $cells = range(0, $columns * $rows - 1);
        for ($i = count($cells) - 1; $i > 0; $i--) {
            $j = (int)floor($random('shuffle-' . $i) * ($i + 1));
            $swap = $cells[$i]; $cells[$i] = $cells[$j]; $cells[$j] = $swap;
        }
        $boxes = [];
        foreach ($settings['lines'] as $index => $line) {
            $box = imagettfbbox(14, 0, $settings['font'], $line);
            if ($box === false) throw new RuntimeException('Cannot measure watermark text.');
            $boxes[] = $box;
        }
        $cellWidth = $geometry['width'] / $columns; $cellHeight = $geometry['height'] / $rows;
        $marks = [];
        foreach (array_slice($cells, 0, $count) as $cell) {
            $angle = $angleMin + ($angleMax - $angleMin) * $random('angle-' . $cell);
            $cos = cos(deg2rad($angle)); $sin = sin(deg2rad($angle));
            $rotate = static function (float $x, float $y) use ($cos, $sin): array {
                return [$x * $cos + $y * $sin, -$x * $sin + $y * $cos];
            };
            $corners = []; $origins = [];
            foreach ($boxes as $index => $box) {
                $left = min($box[0], $box[2], $box[4], $box[6]);
                $top = min($box[1], $box[3], $box[5], $box[7]);
                $baselineY = $index * 14 * 1.6 - $top;
                $origins[] = $rotate(-$left, $baselineY);
                for ($i = 0; $i < 8; $i += 2) $corners[] = $rotate($box[$i] - $left, $box[$i + 1] + $baselineY);
            }
            $xs = array_column($corners, 0); $ys = array_column($corners, 1);
            $minX = min($xs); $minY = min($ys);
            $naturalWidth = max(1, max($xs) - $minX); $naturalHeight = max(1, max($ys) - $minY);
            // Fit the whole rotated three-line block inside its cell, including its corners.
            $factor = min(1, $cellWidth * .85 / $naturalWidth, $cellHeight * .85 / $naturalHeight);
            $width = $naturalWidth * $factor; $height = $naturalHeight * $factor;
            $origins = array_map(static function (array $origin) use ($minX, $minY, $factor): array {
                return [($origin[0] - $minX) * $factor, ($origin[1] - $minY) * $factor];
            }, $origins);
            $marks[] = ['x' => ($cell % $columns) * $cellWidth + $cellWidth * .075 + $random('x-' . $cell) * max(0, $cellWidth * .85 - $width),
                'y' => (int)floor($cell / $columns) * $cellHeight + $cellHeight * .075 + $random('y-' . $cell) * max(0, $cellHeight * .85 - $height),
                'size' => 14 * $factor, 'width' => $width, 'height' => $height, 'angle' => $angle, 'origins' => $origins];
        }
        return $marks;
    }
    public static function image(string $file, array $geometry, array $settings): string {
        $opacity = $settings['opacity'] ?? 0.28;
        if ((!is_int($opacity) && !is_float($opacity)) || !is_finite((float)$opacity) || $opacity < 0 || $opacity > 1)
            throw new RuntimeException('Watermark opacity must be a number between 0 and 1.');
        // Compose only in memory: the shared clean-page cache never holds personalized images.
        $marks = self::layout($geometry, $settings);
        if (!$marks) {
            $bytes = file_get_contents($file);
            if ($bytes === false) throw new RuntimeException('Cannot read page image.');
            return $bytes;
        }
        $image = imagecreatefrompng($file);
        if ($image === false) throw new RuntimeException('Cannot read page image for watermarking.');
        $bufferLevel = ob_get_level();
        try {
            imagealphablending($image, true);
            $color = imagecolorallocatealpha($image, 83, 97, 107, (int)round((1 - $opacity) * 127));
            $scale = imagesx($image) / $geometry['width'];
            foreach ($marks as $mark) {
                foreach ($settings['lines'] as $index => $line) {
                    $size = $mark['size'] * $scale;
                    $origin = $mark['origins'][$index];
                    if (imagettftext($image, $size, $mark['angle'], (int)round(($mark['x'] + $origin[0]) * $scale),
                        (int)round(($mark['y'] + $origin[1]) * $scale), $color, $settings['font'], $line) === false)
                        throw new RuntimeException('Cannot draw watermark text.');
                }
            }
            ob_start();
            if (!imagepng($image)) throw new RuntimeException('Cannot encode watermarked page.');
            return ob_get_clean();
        } finally {
            while (ob_get_level() > $bufferLevel) ob_end_clean();
            imagedestroy($image);
        }
    }
}
