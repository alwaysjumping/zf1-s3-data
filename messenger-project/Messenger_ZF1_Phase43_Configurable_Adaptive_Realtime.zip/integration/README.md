# Messenger ZF1 skeleton integration

This is a **complete cumulative source skeleton**, not a turnkey production deployment.

## Included
- Original uploaded S3 project skeleton (applications, framework, configs, public, library, bizbasic)
- Messenger application, service controllers, domain services, frontend and gateway references
- MariaDB migrations 001-008, tests, phase documentation and example integration callback
- Configuration additions for the Messenger module and autoloader
- Scoped Messenger REST dispatch under `/ws/messenger/*`, preserving original non-Messenger route behavior

## Must configure
1. Restore approved `library/Zend/` and `vendor/` dependencies (excluded from original upload).
2. Set `S3_JWT_SECRET` as required by existing framework bootstrap.
3. Configure DB credentials, production PHP settings, session, and existing ACL.
4. Create writable **non-webroot** attachment storage.
5. Integrate `Messenger_Integration_Bootstrap::register()` into both site and service bootstrap after DB and auth initialization. Replace example callbacks with real employee/company lookups.
6. Verify the host REST router/dispatcher, ACL, module paths and session handling.
7. Apply `database/001_core.sql` through `008_gateway_tokens.sql` in staging.
8. Run `php -l`, `node --check`, `php tests/route_smoke.php`, `php tests/integration_adapter_smoke.php` and staging database tests.
9. Connect top-level shell quick-chat JS and test Chrome 49 / Firefox 52.
10. Harden gateway services before using Node.js or Workerman in production.

## Known limitations
- Original project skeleton deliberately omits Zend and vendor packages; therefore not immediately executable.
- Original non-Messenger REST fallback was a fixed draft route and is preserved, not repaired.
- Authentication/company schema is not supplied; adapters intentionally fail closed until wired.
- Phase 42 change-feed cursor is not lossless; snapshot reconciliation is required.
- No live ZF1/MariaDB/browser integration testing has been performed.
