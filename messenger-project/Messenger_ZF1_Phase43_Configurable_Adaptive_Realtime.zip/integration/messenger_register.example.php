<?php
// Example only. Call from both the authenticated page and service bootstraps,
// after Zend autoload, session, database and Zend_Registry are initialized.
// DO NOT enable until callbacks use your actual company/employee schema.
Messenger_Integration_Bootstrap::register(
    function ($userId) {
        throw new RuntimeException('CONFIGURE_COMPANY_LOOKUP');
    },
    function ($userId, $companyId) {
        throw new RuntimeException('CONFIGURE_EMPLOYEE_LOOKUP');
    },
    dirname(__DIR__) . '/private/messenger-attachments'
);
