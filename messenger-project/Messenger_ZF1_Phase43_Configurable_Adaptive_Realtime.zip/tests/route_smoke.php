<?php
// Standalone route smoke test with lightweight Zend stubs; not a ZF1 integration test.
class Zend_Controller_Router_Route_Module { protected $_moduleKey='module'; protected $_defaults; protected $_dispatcher; }
class Zend_Registry { public static function isRegistered($name){return $name==='config';} public static function get($name){return (object)array('uriPrefix'=>'ws');} }
class Zend_Controller_Front {
 public function getDispatcher(){return new stdClass();}
 public function getModuleDirectory($module){return '/mock/'.$module;}
 public function getModuleControllerDirectoryName(){return 'services';}
 public function addControllerDirectory($dir,$module){}
}
class FakeRequest {
 private $path; private $method;
 public function __construct($path,$method){$this->path=$path;$this->method=$method;}
 public function getRequestUri(){return $this->path;}
 public function getMethod(){return $this->method;}
}
require __DIR__.'/../library/User/Rest/Route.php';
$route=new User_Rest_Route(new Zend_Controller_Front());
$cases=array(
 array('/ws/messenger/gateway-token','POST','messenger','gateway-token','post'),
 array('/ws/messenger/gateway-token','DELETE','messenger','gateway-token','delete'),
 array('/ws/messenger/messages?conversation_id=2','GET','messenger','messages','get'),
 array('/ws/messenger/no-such-route','GET','messenger','unsupported','index'),
 array('/ws/messenger/sync','GET','messenger','sync','get'),
);
foreach($cases as $case){
 $got=$route->match(new FakeRequest($case[0],$case[1]));
 if($got['module']!==$case[2]||$got['controller']!==$case[3]||$got['action']!==$case[4]){
   fwrite(STDERR,'FAIL '.json_encode($case)."\n");exit(1);
 }
 echo 'PASS '.$case[1].' '.$case[0]."\n";
}
