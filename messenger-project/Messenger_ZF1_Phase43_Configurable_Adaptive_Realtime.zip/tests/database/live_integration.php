<?php
/** Destructive tests. Run ONLY against a disposable, isolated MariaDB database. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (getenv('MESSENGER_TEST_ALLOW_DESTRUCTIVE') !== 'YES_I_UNDERSTAND') {
    fwrite(STDERR, "SKIP: set MESSENGER_TEST_ALLOW_DESTRUCTIVE=YES_I_UNDERSTAND on disposable DB\n"); exit(77);
}
$bootstrap = getenv('MESSENGER_TEST_BOOTSTRAP');
if (!$bootstrap || !is_file($bootstrap)) { fwrite(STDERR,"SKIP: set MESSENGER_TEST_BOOTSTRAP to private PHP file returning Zend_Db_Adapter_Abstract\n"); exit(77); }
$db = require $bootstrap;
if (!($db instanceof Zend_Db_Adapter_Abstract)) { fwrite(STDERR,"Invalid bootstrap adapter\n"); exit(2); }
$name = $db->fetchOne('SELECT DATABASE()');
$expected = getenv('MESSENGER_TEST_DATABASE');
if (!$expected || $name !== $expected || !preg_match('/(?:test|staging|scratch|ci)/i', $name)) {
    fwrite(STDERR,"REFUSED: database name must exactly match MESSENGER_TEST_DATABASE and contain test/staging/scratch/ci\n"); exit(2);
}
$engine = $db->fetchOne("SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='msg_messages'");
if (strtoupper((string)$engine) !== 'INNODB') { fwrite(STDERR,"REFUSED: msg_messages must use InnoDB\n"); exit(2); }
$base = dirname(__DIR__,2);
foreach (array('EmployeeDirectory','ConversationService','MembershipService','MessageService') as $c) require_once $base.'/library/Messenger/'.$c.'.php';
class Messenger_Phase37Directory implements Messenger_EmployeeDirectory {
    private $allowed;
    public function __construct(array $allowed) { $this->allowed=$allowed; }
    public function isEligible($companyId,$userId) { return isset($this->allowed[$companyId][$userId]); }
}
function check37($condition,$description) { if (!$condition) throw new RuntimeException('FAIL: '.$description); echo "PASS: $description\n"; }
function rejected37($callback,$description) {
    try { $callback(); } catch (Exception $e) { echo "PASS: $description (".get_class($e).")\n"; return; }
    throw new RuntimeException('FAIL: '.$description);
}
// Use unique high-valued fixture identities; test DB must be empty of production data.
$company = 700000 + random_int(1, 9999);
$a = 800000 + random_int(1, 9999)*10;
$b = $a+1; $c=$a+2; $foreignCompany=$company+1;
$directory = new Messenger_Phase37Directory(array($company=>array($a=>true,$b=>true,$c=>true)));
$conversations = new Messenger_ConversationService($db,$directory);
$members = new Messenger_MembershipService($db,$directory);
$messages = new Messenger_MessageService($db);
$uuid = function() { $h=bin2hex(random_bytes(16)); return substr($h,0,8).'-'.substr($h,8,4).'-4'.substr($h,13,3).'-a'.substr($h,17,3).'-'.substr($h,20,12); };
try {
    $conv=$conversations->createGroup($company,$a,'Phase37 isolated fixture',array($b));
    check37($conv>0,'group creation');
    $m1=$messages->sendText($company,$conv,$a,$uuid(),'message before new member');
    check37((int)$m1['sequence_no']===1,'first message sequence');
    $idem=$uuid();
    $m2=$messages->sendText($company,$conv,$a,$idem,'idempotent');
    $repeat=$messages->sendText($company,$conv,$a,$idem,'idempotent');
    check37((int)$m2['id']===(int)$repeat['id'],'idempotent retry');
    check37((int)$db->fetchOne('SELECT last_sequence FROM msg_conversations WHERE id=?',array($conv))===2,'retry does not advance sequence');
    rejected37(function()use($messages,$company,$conv,$a,$idem){$messages->sendText($company,$conv,$a,$idem,'different body');},'idempotency collision rejected');
    rejected37(function()use($messages,$foreignCompany,$conv,$a,$uuid){$messages->sendText($foreignCompany,$conv,$a,$uuid(),'cross-company');},'cross-company write denied');
    rejected37(function()use($messages,$company,$conv,$c,$uuid){$messages->sendText($company,$conv,$c,$uuid(),'not member');},'non-member write denied');
    check37(count($messages->getHistory($foreignCompany,$conv,$a))===0,'cross-company history denied');
    $members->addMember($company,$conv,$a,$c);
    check37(count($messages->getHistory($company,$conv,$c))===0,'new member cannot read earlier messages');
    $m3=$messages->sendText($company,$conv,$a,$uuid(),'after join');
    check37(count($messages->getHistory($company,$conv,$c))===1,'new member can read post-join message');
    $members->removeMember($company,$conv,$a,$c);
    rejected37(function()use($messages,$company,$conv,$c,$uuid){$messages->sendText($company,$conv,$c,$uuid(),'after removal');},'departed member cannot send');
    $messages->sendText($company,$conv,$a,$uuid(),'while absent');
    $members->addMember($company,$conv,$a,$c);
    check37(count($messages->getHistory($company,$conv,$c))===0,'rejoined member cannot read prior membership or absence history');
    $messages->sendText($company,$conv,$a,$uuid(),'after rejoin');
    check37(count($messages->getHistory($company,$conv,$c))===1,'rejoined member can read post-rejoin message');
    check37((int)$db->fetchOne('SELECT COUNT(*) FROM msg_events_outbox WHERE conversation_id=?',array($conv))>=6,'transactional outbox events present');
    echo "PASS: live integration suite complete; fixture conversation=$conv; database=$name\n";
} catch (Exception $e) { fwrite(STDERR,$e->getMessage()."\n"); exit(1); }
