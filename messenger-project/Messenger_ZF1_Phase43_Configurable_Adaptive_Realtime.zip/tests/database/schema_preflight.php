<?php
/** Read-only checks against an explicitly selected MariaDB staging schema. */
$bootstrap=getenv('MESSENGER_TEST_BOOTSTRAP');
if (!$bootstrap || !is_file($bootstrap)) { fwrite(STDERR,"SKIP: missing MESSENGER_TEST_BOOTSTRAP\n"); exit(77); }
$db=require $bootstrap;
if (!($db instanceof Zend_Db_Adapter_Abstract)) { fwrite(STDERR,"Invalid Zend DB adapter\n"); exit(2); }
$actual=$db->fetchOne('SELECT DATABASE()');
$expected=getenv('MESSENGER_TEST_DATABASE');
if (!$expected || $actual!==$expected) { fwrite(STDERR,"REFUSED: database mismatch\n"); exit(2); }
$required=array('msg_conversations','msg_participants','msg_membership_periods','msg_messages','msg_events_outbox','msg_private_pairs','msg_attachments','msg_gateway_tokens');
$bad=0;
foreach ($required as $name) {
    $row=$db->fetchRow('SELECT ENGINE,TABLE_COLLATION FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?',array($name));
    if (!$row) { echo "FAIL: missing $name\n"; $bad++; continue; }
    if (strtoupper($row['ENGINE'])!=='INNODB') { echo "FAIL: $name not InnoDB\n"; $bad++; continue; }
    echo "PASS: $name uses InnoDB\n";
}
$index=$db->fetchOne("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='msg_messages' AND INDEX_NAME='uq_msg_seq'");
if (!$index) { echo "FAIL: missing sequence uniqueness index\n"; $bad++; }
else echo "PASS: sequence uniqueness index present\n";
$index=$db->fetchOne("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='msg_private_pairs' AND INDEX_NAME='uq_private_pair'");
if (!$index) { echo "FAIL: missing private-pair uniqueness index\n"; $bad++; }
else echo "PASS: private-pair uniqueness index present\n";
exit($bad?1:0);
