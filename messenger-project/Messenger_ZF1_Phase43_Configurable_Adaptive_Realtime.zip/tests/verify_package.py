#!/usr/bin/env python3
"""Offline source-contract checks; NOT a substitute for live integration tests."""
from pathlib import Path
import re, subprocess, sys
root=Path(__file__).resolve().parents[1]
fail=[]
def check(ok,msg):
    print(('PASS' if ok else 'FAIL')+' '+msg)
    if not ok: fail.append(msg)
php=list(root.rglob('*.php'))
js=list(root.rglob('*.js'))
for p in php:
    r=subprocess.run(['php','-l',str(p)],capture_output=True,text=True)
    check(r.returncode==0,'PHP syntax: '+str(p.relative_to(root)))
for p in js:
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    check(r.returncode==0,'JavaScript syntax: '+str(p.relative_to(root)))
route=(root/'patches/library/User/Rest/Route.php').read_text()
controllers={p.stem.lower().replace('controller','') for p in (root/'applications/messenger/services').glob('*Controller.php')}
expected=['conversations','messages','members','groups','attachments','message-state','interactions','sync','gateway-token']
for endpoint in expected:
    check(endpoint in route,'Router references '+endpoint)
    name=endpoint.replace('-','')
    check(name in controllers,'Controller exists for '+endpoint)
check('unsupported' in route,'Unknown Messenger endpoint fails closed')
check('draft' in route,'Legacy fallback still exists (requires manual security review)')
check('messengerTabScope' in (root/'applications/messenger/controllers/IndexController.php').read_text(),'Trusted tab scope assigned')
check((root/'library/Messenger/Integration/Bootstrap.php').is_file(),'Integration bootstrap exists')
check('messenger_company_resolver' in (root/'library/Messenger/ApiController.php').read_text(),'Company resolver guard exists')
check('messenger_csrf_validator' in (root/'library/Messenger/ApiController.php').read_text(),'CSRF guard exists')
check('scan_status' in (root/'database/005_attachment_scanner.sql').read_text(),'Scanner migration exists')
check('msg_gateway_tokens' in (root/'database/008_gateway_tokens.sql').read_text(),'Gateway token migration exists')
print('\nSUMMARY: %d PHP, %d JS, %d failed checks' % (len(php),len(js),len(fail)))
sys.exit(1 if fail else 0)
