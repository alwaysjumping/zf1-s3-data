<?php
// Offline deterministic failure injection; not a substitute for two real MariaDB connections.
if (!function_exists("mb_strlen")) { function mb_strlen($s,$encoding="UTF-8") { return strlen($s); } } // ASCII-only test shim
class Zend_Db_Adapter_Abstract {}
class Zend_Db_Statement_Exception extends Exception {}
require dirname(__DIR__).'/library/Messenger/MessageService.php';
class FakeDb extends Zend_Db_Adapter_Abstract {
    public $rows = array(); public $messages = 0; public $events = 0; public $seq = 0;
    public $failOnce = false; public $tx = false; public $rolledBack = 0;
    public function beginTransaction() { $this->tx = true; }
    public function commit() { $this->tx = false; }
    public function rollBack() { $this->tx = false; ++$this->rolledBack; }
    public function fetchRow($sql, $params) {
        if (strpos($sql, 'FROM msg_conversations') !== false) return array('id'=>1,'last_sequence'=>$this->seq);
        if (strpos($sql, 'FROM msg_participants') !== false) return array('id'=>1,'first_visible_sequence'=>1);
        if (strpos($sql, 'FROM msg_messages') !== false) {
            $key = $params[0].':'.$params[1]; return isset($this->rows[$key])?$this->rows[$key]:false;
        }
        return false;
    }
    public function fetchOne($sql, $params) { return 1; }
    public function insert($table, $data) {
        if ($table === 'msg_messages') {
            if ($this->failOnce) {
                $this->failOnce=false;
                throw new Zend_Db_Statement_Exception('SQLSTATE[40001]: Deadlock found 1213');
            }
            ++$this->messages; ++$this->seq;
            $this->rows[$data['sender_id'].':'.$data['client_message_id']] = array(
                'id'=>$this->messages,'conversation_id'=>$data['conversation_id'],
                'sequence_no'=>$this->seq,'body'=>$data['body'],'type'=>'text','created_at'=>$data['created_at']);
        }
        if ($table === 'msg_events_outbox') ++$this->events;
    }
    public function update($table, $data, $where) {}
    public function quoteInto($sql,$value) { return 'id = '.(int)$value; }
    public function lastInsertId() { return $this->messages; }
}
function check($yes,$message) { if (!$yes) throw new Exception($message); echo "PASS $message\n"; }
$db=new FakeDb(); $service=new Messenger_MessageService($db);
$uuid='12345678-1234-4123-8123-123456789abc';
$db->failOnce=true;
$first=$service->sendText(1,1,7,$uuid,'Hello');
check($db->rolledBack===1 && $db->messages===1 && $db->events===1,'deadlock retried once without duplicate event');
$second=$service->sendText(1,1,7,$uuid,'Hello');
check((int)$first['id']===(int)$second['id'] && $db->messages===1,'identical retry returns original');
try { $service->sendText(1,1,7,$uuid,'Changed'); throw new Exception('Expected conflict'); }
catch (RuntimeException $e) { check($e->getMessage()==='CLIENT_MESSAGE_ID_CONFLICT','changed payload rejected'); }
