from pathlib import Path
p=Path(__file__).resolve().parents[1]/'public/applications/messenger/js/messenger.js'
s=p.read_text()
for expected in ['maxVisibleMessages = 200','this.historyGeneration++','this.olderBusy=true','self.mergeMessages(rows,true)','request!==self.historyRequest','self.reactionRequest!==gen','rows.slice(rows.length-this.maxVisibleMessages)']:
 assert expected in s, expected
print('Frontend window/race static checks passed')
