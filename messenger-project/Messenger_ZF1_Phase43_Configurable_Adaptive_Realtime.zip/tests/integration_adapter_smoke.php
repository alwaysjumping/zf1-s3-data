<?php
interface Messenger_CompanyResolver { public function requireCompanyId($authenticatedUserId); }
interface Messenger_EmployeeDirectory { public function isEligible($companyId,$userId); }
class Zend_Registry { private static $data=array(); public static function set($k,$v){self::$data[$k]=$v;} public static function get($k){return self::$data[$k];} }
class Zend_Session_Namespace { private static $storage=array(); public function __construct($name){$this->name=$name;} public function __get($key){return isset(self::$storage[$this->name][$key])?self::$storage[$this->name][$key]:null;} public function __set($key,$val){self::$storage[$this->name][$key]=$val;} public function __isset($key){return isset(self::$storage[$this->name][$key]);} private $name; }
foreach(array('CompanyResolver','EmployeeDirectory','Csrf','Bootstrap') as $n) require __DIR__.'/../library/Messenger/Integration/'.$n.'.php';
function check($ok,$label){ if (!$ok){fwrite(STDERR,'FAIL '.$label."\n");exit(1);} echo 'PASS '.$label."\n"; }
$company=new Messenger_Integration_CompanyResolver(function($user){return $user===7?2:null;});
check($company->requireCompanyId(7)===2,'authoritative company callback');
try{$company->requireCompanyId(8);check(false,'reject unknown user');}catch(RuntimeException $e){check(true,'reject unknown user');}
$employees=new Messenger_Integration_EmployeeDirectory(function($company,$user){return $company===2&&$user===7;});
check($employees->isEligible(2,7),'eligible employee');
check(!$employees->isEligible(3,7),'cross-company employee denied');
$token=Messenger_Integration_Csrf::issue();
check(strlen($token)===64 && Messenger_Integration_Csrf::verify($token),'CSRF issue/verify');
check(!Messenger_Integration_Csrf::verify('bad'),'CSRF malformed denied');
Messenger_Integration_Csrf::rotate();
check(!Messenger_Integration_Csrf::verify($token),'CSRF old token rejected after rotation');
