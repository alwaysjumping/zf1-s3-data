# Phase 19 — ZF1 REST controllers (integration candidate)

This ZIP includes all Phase 18 files plus a base controller and four REST controllers. Copy only after reviewing your actual bootstrap and application registration.

## Routes

- POST `/ws/messenger/conversations`: `{"type":"private","recipient_id":123}` or `{"type":"group","title":"Team","user_ids":[123,456]}`
- POST `/ws/messenger/messages`: `{"conversation_id":1,"client_message_id":"<UUID>","body":"Hello"}`
- GET `/ws/messenger/messages?conversation_id=1&limit=50&before_sequence=100`
- POST `/ws/messenger/members`: `{"operation":"add|remove","conversation_id":1,"target_user_id":123}`
- POST `/ws/messenger/groups`: `{"operation":"rename","conversation_id":1,"title":"New title"}`; `transfer_owner` with `target_user_id`; `set_admin` with `target_user_id` and boolean `is_admin`.

All POST endpoints require a session-bound `X-CSRF-Token`. The CSRF validator must be registered server-side as `messenger_csrf_validator` (callable). The caller identity comes exclusively from `Zend_Auth`; do not accept user/company IDs from request bodies.

## Mandatory integration adapters (fail closed)

Register `messenger_company_resolver` as a `Messenger_CompanyResolver` and `messenger_employee_directory` as a `Messenger_EmployeeDirectory` in `Zend_Registry`. Both must consult authoritative application records. Missing adapters or CSRF validator return 503. Do not replace these with values from client parameters.

## Known blockers / follow-up

1. Router retains pre-existing hardcoded draft fallback for non-Messenger routes. Audit and replace before production.
2. Current router chooses GET/POST for Messenger but unsupported methods may reach indexAction; verify inherited 405 behavior.
3. Verify the app's REST bootstrap selects the correct service controller directory and module registration.
4. Confirm company membership mapping, session lifecycle, token generation/rotation and CSRF validator.
5. No live DB, concurrency, CSRF or HTTP integration tests have been run.
6. `MessageService` and `MembershipService` are earlier-phase candidates: test idempotency, membership periods, locking, and SQL behavior under MariaDB before deployment.
7. Existing REST services may use JWT; this version intentionally uses Zend_Auth sessions only. JWT requires a separate explicit auth strategy, not a silent fallback.
8. `jsonBody()` limits request bodies to 64 KiB; attachments will use a separate upload flow.
9. API error codes need final enumeration; unrecognized runtime exceptions are masked as `INTERNAL_ERROR`.
10. Before deployment, implement rate limiting, audit logging, consistent output escaping and security tests.
