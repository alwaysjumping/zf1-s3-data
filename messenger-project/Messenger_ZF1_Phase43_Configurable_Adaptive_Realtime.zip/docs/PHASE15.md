# Phase 15 — REST routing and message/outbox schema

## Contents
- `patches/library/User/Rest/Route.php`: candidate replacement of the existing placeholder route. **Review diff manually before copying**. It routes only `GET /ws/messenger/info`; unsupported methods get HTTP 405 through the inherited controller. All other requests retain the original hard-coded fallback, which is not production-safe.
- `applications/messenger/services/InfoController.php`: session-authenticated smoke endpoint, no user identifier in response.
- `database/002_messages_outbox.sql`: messages and transactional outbox; apply only after reviewing and installing `001_core.sql`.

## Installation prerequisites
1. Backup and version-control the original `library/User/Rest/Route.php`.
2. Register `messenger` in the application module suite; `resources.frontController.suite.applications = "docbook,messenger"` is an example, not an automatic patch.
3. Confirm `/ws/` dispatch and module controller directory conventions; the skeleton uses a custom router.
4. Ensure `Messenger_` library classes are autoloaded.
5. Do not expose the endpoint externally; this is an integration smoke test, not a production REST router.
6. Verify the actual user ID SQL type and company resolver before applying migrations.

## Manual tests
- Authenticated GET `/ws/messenger/info` -> 200 with `authenticated: true`.
- Unauthenticated GET -> 401.
- POST `/ws/messenger/info` -> 405.
- Existing non-Messenger endpoints behave exactly as before (including existing limitations).
- Inspect MariaDB table structure and index names after applying both SQL migrations to a test database.

## Not yet implemented
Company isolation, employee directory, authenticated message APIs, CSRF enforcement, atomic send/outbox service, durable sync, attachment security, frontend and comprehensive tests. **Not production ready.**
