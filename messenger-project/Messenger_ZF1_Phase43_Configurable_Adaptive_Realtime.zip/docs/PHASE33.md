# Phase 33 — Trusted WebSocket authentication verifier

Cumulative package built on Phase 32. Adds opaque, short-lived bearer tokens for WebSocket authentication and fresh database membership checks before delivery of each invalidation hint.

## New files
- `database/008_gateway_tokens.sql`: hashed, expiring gateway credentials.
- `library/Messenger/GatewayTokenService.php`: issue, verify, revoke, and purge.
- `applications/messenger/services/GatewayTokenController.php`: session-authenticated and CSRF-protected `POST /ws/messenger/gateway-token`.
- `gateways/verifier/router.php`: loopback-only trusted verifier for Node.js and Workerman gateways.
- Updated REST router patch for `/ws/messenger/gateway-token`.

## Integration
1. Apply migration 008 after previous migrations, once, to a backed-up staging database.
2. Confirm `Messenger_ApiController` has functioning CSRF verification, session authentication, company resolver and DB adapter. **Do not enable token issuance until all are implemented.**
3. Provision `MESSENGER_VERIFY_SECRET` as a random 32+-character value shared only between verifier and gateway. Use a different secret for internal signals.
4. Supply an administrator-owned PHP bootstrap file via `MESSENGER_VERIFIER_BOOTSTRAP` that initializes the Zend autoloader, DB adapter and returns `Zend_Db_Adapter_Abstract`. Do not place this file under the public webroot.
5. For isolated staging only, start `php -S 127.0.0.1:8092 gateways/verifier/router.php` from a trusted directory. Set `MESSENGER_VERIFY_URL=http://127.0.0.1:8092/internal/messenger/verify` on the gateway.
6. The browser calls `POST /ws/messenger/gateway-token` with its authenticated session and CSRF token, receives `{token, expires_in}`, and sends `{type:"auth",token:"..."}` as the first WebSocket message. Never put tokens in URLs, logs, or localStorage.
7. A gateway must re-authenticate or reconnect with a new token before expiration. The Phase 31/32 gateway currently authenticates once at connection establishment, and only calls the verifier again for each invalidation hint; after expiration, hints will be denied. **Implement proactive token refresh and connection recycling before production.**
8. Logout must call `revokeUser()` or implement a more granular per-session revocation model; otherwise already issued tokens remain usable for up to 120 seconds.
9. Configure trusted TLS reverse proxy, strict Origin, loopback binding, firewall restrictions, rate limits, health checks, and metrics.

## Security boundaries
- Token records contain only SHA-256 hashes, not plaintext tokens.
- The verifier compares the shared internal key using `hash_equals` and rejects non-loopback callers.
- `authorize` verifies the token, company ID, unarchived conversation, active participant, and active membership period in MariaDB.
- Company ID is always derived from the trusted server-side token record.
- No message bodies or attachments pass through the gateway.
- Membership checks do not prove current employee account status. Integrate a trusted active-user check and per-session revocation policy before production.
- The PHP built-in server is a **development reference**, not a production service. Use a hardened dedicated internal service for deployment.
- The verifier bootstrap is deliberately not supplied because the actual company resolver and deployment environment are not known.

## Test plan
- Anonymous token issuance and missing/invalid CSRF fail.
- Invalid company resolution fails closed.
- Valid token authenticates and returns a string user ID.
- Expired, revoked, malformed tokens fail.
- Member of correct company/conversation authorizes; another company or departed member fails.
- Removal between two signals prevents the second signal from being delivered.
- Verifier outage means no hint delivery; REST reconciliation still recovers.
- Confirm Node.js and Workerman response contracts match.
- Verify secrets never appear in HTTP access logs.
