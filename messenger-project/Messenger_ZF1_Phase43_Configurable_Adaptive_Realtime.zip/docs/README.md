# Messenger Phase 14 — Integration foundation

This is **not a complete Messenger module**. It is an additive, non-destructive starting package based on the supplied ZF1 skeleton.

## Verified project conventions

- Modules reside under `applications/<name>/`.
- REST controllers reside in `services/` and extend `User_Rest_Controller_Abstract`.
- Session identity uses `Zend_Auth` with `user_key`.
- `service.uriPrefix = "ws"` in `configs/application.ini`.
- The existing `User_Rest_Route::match()` currently returns a hard-coded `draft/info/put` route.

## Integration instructions

1. Do **not** replace `library/User/Rest/Route.php` with an untested generic router.
2. Register the new module in the appropriate `resources.frontController.suite` configuration after confirming its actual module discovery conventions.
3. Add a *specific* REST route for `GET /ws/messenger/info` mapping to `module=messenger`, `controller=info`, `action=get` **before** the existing catch-all route. ZF1 router ordering must be tested in the actual application. The route is **not included as an automatic patch**.
4. Copy `library/Messenger` classes into the application's library directory and verify its autoloader resolves `Messenger_IdentityProvider` and `Messenger_ApiResponse`.
5. Test authenticated and unauthenticated requests. The smoke test intentionally exposes the authenticated user ID, so disable/remove it in production.
6. Review company-to-user mapping and `frm_users.user_key` SQL type before applying the schema. This SQL is only the first four tables; do not deploy it as the full V1 schema.
7. The SQL is intended for an empty database namespace. Back up the database and review migration reversibility before execution.

## Security gaps intentionally not implemented yet

Company isolation, employee eligibility, CSRF, REST route patch, durable event stream/outbox, complete message transactions, attachments, group services, rate limiting, and frontend are pending. Do not expose this package as a working Messenger service.

Phase 37: see `docs/PHASE37.md` for MariaDB staging checks and live integration tests.
