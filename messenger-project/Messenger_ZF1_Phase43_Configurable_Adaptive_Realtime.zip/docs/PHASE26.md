# Phase 26 — Messenger browser frontend (ES5-compatible)

Cumulative package containing Phases 15–25 plus a simple full-page Messenger UI.

## Files
- `applications/messenger/controllers/IndexController.php`
- `applications/messenger/views/scripts/index/index.phtml`
- `public/applications/messenger/js/messenger.js`
- `public/applications/messenger/css/messenger.css`

## Integration
1. Register the `messenger` module in your ZF1 module discovery/configuration.
2. Serve the view at the host application's normal module route (typically `/messenger`).
3. Host a supported jQuery version **locally** and load it in the shared layout **before** this view's script. DHTMLX 3.5 can remain in the shell; this first UI uses plain jQuery rather than undocumented DHTMLX methods.
4. Register `messenger_csrf_token_provider` in Zend_Registry; it must issue a token accepted by your existing `messenger_csrf_validator`. Do not use the empty default token.
5. Register the company resolver and employee directory as described in earlier phases. Apply migrations and configure the `/ws/messenger` router.
6. Confirm `GET /ws/messenger/sync` and `GET/POST /ws/messenger/messages` are working with authenticated cookies.
7. Do not embed in an iframe until you have decided how the shared top-level shell will persist popups and coordinate tabs.

## Browser support
Uses ES5 syntax, jQuery, and `crypto.getRandomValues`; no Babel runtime or remote assets. Chrome 49 and Firefox 52 have the needed browser primitives in appropriate secure contexts. Verify in real target browsers. Do not serve the app over an insecure remote HTTP origin.

## Known limitations
- Conversation titles and participant names are not exposed by Phase 25 sync, so this UI displays numeric conversation IDs.
- No conversation creation, member management, attachment UI, edit/delete UI, reactions, read receipts, typing indicators, search, quick-chat popups, or WebSocket gateway in this phase.
- 10-second polling fetches history when the snapshot changes; Phase 25 `last_event_id` is only a hint, and a full reconciliation is performed on window focus and refresh. A committed edit can still be missed temporarily if the snapshot query races a commit. No durable event-feed guarantees.
- Browser does not queue or retry failed POSTs. If the server committed a send but the response was lost, a user retry creates a new UUID and may duplicate the message. Production implementation must retain the UUID for retries and provide pending-message state.
- History uses latest 50 and a manual older button; latest reload resets older pages. HTML escaping prevents rendering message body as markup.
- No automated browser/integration tests were run; only static syntax and packaging checks.
- A single user with >500 conversations receives a truncated snapshot; implement server-side pagination before deployment at scale.

## Staging checks
1. Verify CSRF token generation and validation match.
2. Log in; verify conversations appear and history is ordered oldest to newest.
3. Send a message; verify it appears and persists after reload.
4. Attempt an unauthenticated API call and cross-company conversation access; both must be denied.
5. Leave and rejoin a group; confirm earlier history is not shown.
6. Test Chrome 49 and Firefox 52, including old-browser cookie and TLS policies.
7. Stop real-time gateways: polling must still fetch new messages.
