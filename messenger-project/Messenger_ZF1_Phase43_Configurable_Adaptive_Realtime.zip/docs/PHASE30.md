# Phase 30 — Best-effort cross-tab poll coordination

This cumulative package adds `tab-coordinator.js` (ES5) and integrates it with the full Messenger frontend.

## Integration
Load `tab-coordinator.js` **before** `messenger.js` in the top-level shell or Messenger page. Supply `tabScope` as a non-secret, authenticated account-specific namespace; do not use an access token, session cookie or private data. For example, a server-derived opaque account namespace.

## Behavior
- Each tab uses a random 128-bit identity and a localStorage lease (15-second TTL, 4-second heartbeat).
- The elected tab polls the snapshot every 10 seconds and emits storage-event hints after successful polls.
- Other tabs refresh on hints and do a full reconciliation at least every 45 seconds, even if events are lost.
- If storage or Web Crypto is unavailable, each tab falls back to independent polling.
- Quick-chat popups continue to poll independently; this phase does not share a WebSocket connection.
- Storage-based election is advisory: concurrent contenders can both temporarily act as leader; correctness relies on REST and server-side authorization, not election.

## Remaining work
- Actual Node.js/Workerman WebSocket gateway adapters, authenticated handshake, reconnection and transport-specific routing are not implemented.
- Do not rely on localStorage for sensitive event content, durable delivery, locking or security.
- Client should stop polling and clear cached data on logout or account switch.
- Existing REST snapshot is not a durable change feed; implement event cursors and gap recovery before production.
- Test multiple tabs, background throttling, blocked storage, old browsers, account switching, and simultaneous lease contention.
