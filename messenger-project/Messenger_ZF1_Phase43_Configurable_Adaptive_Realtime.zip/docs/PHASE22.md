# Phase 22 — Trusted antivirus worker and attachment maintenance

Includes the Phase 21 package plus `Messenger_AttachmentScanWorker`, `Messenger_AttachmentMaintenance`, and migration `005_attachment_scanner.sql`.

## Installation
1. Apply migration 005 **once** after 004 in a backed-up staging database.
2. Install ClamAV `clamscan` and virus definitions on the isolated server using your approved offline package process. Confirm definitions are current under your internal update policy.
3. Use a **dedicated CLI entrypoint**, never an HTTP controller, to bootstrap ZF1, obtain its DB adapter, and instantiate:
   ```php
   $worker = new Messenger_AttachmentScanWorker($db, '/srv/messenger-attachments', '/usr/bin/clamscan');
   $worker->releaseExpiredLeases();
   while ($worker->runOne() !== false) { /* bounded batch in production */ }
   ```
   Run from cron/systemd timer under a restricted service account with access only to the attachment storage. Avoid concurrent maintenance during upload tests.
4. Use `Messenger_AttachmentMaintenance::reconcile()` to **report** missing, corrupt, and orphan files. It does not modify files.
5. `purgeRejected(30)` is a dry-run; `purgeRejected(30, true)` deletes rejected, unlinked uploads older than 30 days. Set retention to your policy.

## Safety behavior
- Only scanner exit code **0** and matching SHA-256 before/after scan marks a file clean.
- Exit code **1** rejects an infected file; scanner errors and timeouts requeue as quarantined.
- Claims are protected by random tokens and a lease; no transaction stays open during a scan.
- Expired lease release is intended for a scheduler with controlled concurrency; use a lease longer than the scan timeout.
- Downloads and message linking continue to require `scan_status='clean'`.
- Reconciliation is report-only and **does not delete orphan files** automatically.

## Remaining production work
- `proc_open` must be enabled for the trusted CLI runtime, and `clamscan` must be installed; neither is bundled.
- The worker uses a 300-second scan timeout; validate OS/process termination and error handling on CentOS.
- Database/filesystem operations are not atomic. Coordinate backup, retention, worker scheduling, and recovery.
- Verify the storage directory is truly outside **all** webroots, inaccessible via web server aliases, and writable only by intended identities.
- Race-hardening around file replacement, symlinks, concurrent scan lease expiry, and downloaded file handles requires security review.
- Implement quotas, file-type policy, audit logging, metrics, alerts, and automated integration tests before production.
- The older REST router still has placeholder behavior for non-Messenger routes. Do not deploy as a general routing replacement.

## Suggested staging tests
1. Upload a harmless test file -> quarantined -> worker -> clean.
2. Use the EICAR antivirus test string from your security team -> rejected (never downloadable).
3. Stop ClamAV / use outdated definitions -> never clean.
4. Tamper with stored bytes -> rejected.
5. Kill worker after claim -> lease expiry requeues.
6. Two workers compete -> one claim per row.
7. Reconciliation finds missing/orphan files; dry-run cleanup does not delete.
8. Confirm group membership period still gates attachment downloads.
