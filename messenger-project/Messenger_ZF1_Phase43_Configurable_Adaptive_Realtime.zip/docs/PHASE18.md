# Phase 18 — Group administration and fail-closed routing

## Included

- `library/Messenger/GroupAdminService.php`: transactional group rename, owner-only promotion/demotion, and ownership transfer. Locks the conversation row first, verifies active membership, writes outbox events in the same transaction, and rolls back on failure.
- `library/Messenger/CompanyResolver.php`: contract for mapping the authenticated `frm_users.user_key` to an authoritative company ID.
- `applications/messenger/services/UnsupportedController.php`: deny unsupported Messenger REST paths.
- `patches/library/User/Rest/Route.php`: route `/ws/messenger/info` and fail closed on other `/ws/messenger/*` paths. **This does not yet expose group-admin methods over REST.**

## Important limits

- This is an additive source package, not a deployable REST API. Do not advertise group-admin REST endpoints as active.
- Actual REST endpoints require an implemented company resolver, CSRF guard, service wiring and tested routing. These are intentionally **not** stubbed with an unsafe company ID.
- Do not replace the application router without reviewing other modules; non-Messenger paths still retain the skeleton's placeholder behavior.
- Group-owner invariant currently depends on all writers honoring the conversation lock; DB-level single-owner enforcement and administrative repair tooling remain to be added.
- Real DB tests, concurrency tests, and outbox delivery tests have not been run.

## Service usage (server-side trusted values)

```php
$service = new Messenger_GroupAdminService($db);
$service->transferOwnership($companyId, $groupId, $authenticatedUserId, $newOwnerId);
$service->setAdministrator($companyId, $groupId, $authenticatedUserId, $memberId, true);
$service->renameGroup($companyId, $groupId, $authenticatedUserId, 'Updated title');
```

## Suggested acceptance tests

1. Only owner can transfer ownership or promote/demote admins.
2. Owner cannot transfer to an inactive/nonmember user.
3. Exactly one owner after two concurrent ownership transfers.
4. Rename requires active owner/admin.
5. Failed outbox insert rolls back the role/title change.
6. Unknown `/ws/messenger/*` paths do not execute the draft module.
7. Unauthenticated requests are denied by the eventual REST adapters.
