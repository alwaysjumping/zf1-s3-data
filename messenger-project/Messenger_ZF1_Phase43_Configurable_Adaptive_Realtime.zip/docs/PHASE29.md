# Phase 29 — Approved attachment selection, downloads and cross-tab hints

Cumulative package based on Phase 28.

## API additions
`GET /ws/messenger/attachments?list=ready&conversation_id=ID` lists up to 100 clean, unlinked uploads belonging to the authenticated uploader in an active conversation.

`GET /ws/messenger/attachments?list=message-files&conversation_id=ID` lists up to 200 clean attachments linked to nondeleted messages visible to the current member.

`GET /ws/messenger/attachments?attachment_id=ID` remains the protected file download route. Existing server-side checks are mandatory.

## Frontend
- Refresh approved files after antivirus scanning; select up to 10 for a message.
- Send an attachment-only message with an empty text body, or text plus attachments.
- Display authorized download links for linked attachments.
- After a successful send, emit a same-origin `localStorage` storage-event hint so other tabs can refresh their REST snapshot.
- This is **not** leader election, does **not** stop each tab polling, and does not replace server authorization or durable synchronization.

## Limitations
- The storage-event hint does not fire in the originating tab; that tab already refreshes directly. It can be unavailable when storage is disabled; normal polling remains.
- Quick-chat windows remain independent polling clients. Multi-tab leader election and cross-tab socket sharing are NOT implemented.
- File lists have fixed limits and lack pagination, thumbnails, and scanning-progress feedback.
- Download links use same-origin session cookies; never pass auth tokens through query parameters.
- Legacy attachment stream sends headers before opening the file; fix this and add robust streaming error handling before production.
- Recheck scan status, membership period, and attachment linkage on each request; never rely on the UI.
- Attachment-only message creation depends on existing server-side service behavior. Verify integration and rollback cases in MariaDB.
- `GET` listing is read-only, and CSRF remains required for upload/send.
- Client-side UI and API have not been exercised against running ZF1, MariaDB, ClamAV, or legacy browsers.

## Suggested tests
1. Upload -> quarantined -> not listed; scanner clean -> listed; scanner reject -> never listed.
2. Select approved file and send; confirm it disappears from ready list and appears in download list.
3. Upload from user A; user B must not see it as a ready upload.
4. Leave/rejoin group; old attachment download must be denied.
5. Soft-delete message; attachment must disappear from the ordinary download list and be denied by download endpoint.
6. Open two tabs, send in first, confirm second refreshes on storage event; disable localStorage and verify polling still works.
7. Attempt 11 files and 20 MiB+ upload; server must enforce limits.
8. Confirm no file paths or sensitive data appear in real-time events or storage hints.
