# Phase 21 — Attachments API and message linking

## Endpoints
- `POST /ws/messenger/attachments` multipart/form-data: `conversation_id`, `file`, and `X-CSRF-Token` header. Returns quarantined attachment ID.
- `GET /ws/messenger/attachments?attachment_id=123` downloads only a clean attachment linked to a visible, undeleted message.
- `POST /ws/messenger/messages` JSON supports `attachment_ids: [123, ...]` (1–10), with `body` (empty string allowed when attachments supplied), `conversation_id`, `client_message_id` UUID.

## Required configuration
Register `messenger_attachment_storage` in `Zend_Registry` as an absolute writable directory outside all webroots. Existing company resolver, employee directory, CSRF validator and session authentication remain mandatory. The storage directory should not permit execution. Set upload limits appropriately.

## Antivirus and deployment
Uploads stay quarantined. A separate trusted scanner must scan the exact stored bytes, then invoke `recordScanResult`; **never expose that method through HTTP**. Until scanning is implemented, no attachment can be linked or downloaded. Protect downloads from compression, response buffering, accidental output, and reverse-proxy caching. Verify the web server does not serve the storage path directly.

## Known limitations and mandatory review
- This is a development package, not production-ready. ZF1 REST dispatch, session/CSRF adapters, MariaDB integration, and streaming behavior need end-to-end testing.
- PHP and database cannot atomically commit filesystem writes. Add orphan cleanup and reconciliation.
- The download checks authorization and hashes before opening; harden against TOCTOU (e.g. immutable file storage or safe open-and-verify handles) before production.
- No scanner worker, rate limiting, file type allowlist, quotas, retention policy, or audit logs yet.
- GET download response directly streams with `exit`; review compatibility with existing output buffers and ZF1 response lifecycle.
- REST router still retains the pre-existing placeholder for non-Messenger routes; do not deploy as a general routing fix.
- Run schema migrations from earlier phases in order, on a staging database, not blindly on production.

## Test cases
1. Upload clean-sized file -> quarantined; download and message-link denied.
2. Scanner approves file -> link succeeds; download succeeds only for active member with visibility.
3. Cross-company or cross-conversation ID -> denied.
4. Retry same UUID with same ordered-independent attachment set -> same message ID; altered content -> conflict.
5. Two concurrent attempts to attach the same file -> one succeeds.
6. Deleted message -> attachment download denied.
7. Rejoined group member -> prior-period attachment denied.
8. Oversize (>20 MiB), missing CSRF, invalid multipart, tampered file -> denied.
