# Phase 17: Conversations and group membership

This package extends Phase 16. It is **not production-ready** without the company/employee directory adapter, route/controller wiring, concurrency testing and the remaining feature tables.

## New files

- `library/Messenger/EmployeeDirectory.php` — authoritative employee/company eligibility contract.
- `library/Messenger/ConversationService.php` — create canonical private pairs and groups.
- `library/Messenger/MembershipService.php` — add/remove group members under the conversation lock.
- `database/003_private_pairs.sql` — unique private pair table.

## Migration order for fresh installation

1. `001_core.sql`
2. `002_messages_outbox.sql`
3. `003_private_pairs.sql`

**Never rerun a CREATE TABLE migration on a database already containing these tables.** Review schema drift and back up before applying incremental changes. `frm_users.user_key` type and the authoritative company mapping must be confirmed before production deployment.

## Transaction and visibility invariants

- Message sends and membership changes lock `msg_conversations` first.
- A new/rejoining member's first readable message is `last_sequence + 1` at join time.
- Removing a member closes the active membership period at the current `last_sequence`.
- The Phase 16 history query only reads the active membership period; former periods are not visible.
- Group size is at most 100 active members, counting the owner and admins.
- Group creator is the sole owner; ownership transfer is **not yet implemented**.
- Outbox writes are included in group create/add/remove transactions. Private creation currently does not publish a create event.

## Important limitations and follow-up work

1. Implement a concrete `Messenger_EmployeeDirectory` against your existing company/user schema. Do not trust company IDs supplied by clients.
2. Integrate controllers with the existing `/ws/` REST infrastructure and authenticated identity adapter.
3. Test private-pair duplicate races and group member cap using two independent MariaDB connections. Duplicate-key detection depends on actual Zend DB exception/driver messages and needs verification.
4. Implement owner transfer, group renaming, participant listing, audit logs and durable authorized sync.
5. Add a DB-level guard for one active membership period per participant, after verifying MariaDB version. Application logic alone does not protect against external SQL writers.
6. A membership removal event must be delivered to the removed user's sessions to clear cached data, without exposing new group messages. Delivery filtering requires explicit design.
7. Verify that an existing private pair's participants remain authorized and active before returning it; the current code checks employee eligibility but does not repair or reopen prior membership.
8. `MessageService` from Phase 16 uses second-precision timestamps, while new services use microseconds; normalize all services before production deployment.

## Manual acceptance tests (not yet executed)

- Creating the same private pair in reverse order returns the same conversation.
- Concurrent private creation produces exactly one pair.
- Group creation with 100 distinct eligible users succeeds; 101 fails.
- A member added at sequence 40 has `first_visible_sequence = 41`.
- A member removed at sequence 50 gets `last_visible_sequence = 50`.
- Rejoining at sequence 70 creates a new period starting at 71; old history stays inaccessible.
- Two simultaneous additions when group has 99 members do not exceed 100.
- A member cannot remove others; an admin cannot remove another admin; an owner cannot leave before transfer.
- Any outbox insertion failure rolls back the membership change.
