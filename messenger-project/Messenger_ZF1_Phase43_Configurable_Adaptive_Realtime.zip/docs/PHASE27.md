# Phase 27 — Frontend conversation and interaction controls

Cumulative package based on Phase 26. No external CDNs; ES5-style JavaScript and locally hosted CSS.

## Added UI
- Create private conversation by recipient user ID.
- Create group with title and comma-separated user IDs.
- Add/remove group member, rename group, transfer ownership, promote/demote admin.
- Edit/delete own message; emoji reaction and mark-read actions.
- CSRF header preserved for POST requests; UI uses the existing REST endpoints.

## Setup
Provide `$this->messengerCsrfToken` and `$this->messengerUserId` from your authenticated controller; never trust a client-supplied user ID for authorization. The latter is only used to decide whether to display edit/delete buttons; backend must enforce ownership.

## Known limitations
- This is a developer/admin prototype UI using numeric user IDs. Replace with an authorized employee picker before release.
- Group administration controls are visible for all selected conversations; the server must deny unauthorized operations. Role-based UI hiding needs a membership-details endpoint.
- Emoji reaction controls only add reactions. Removal/toggling and user-specific state need an enriched reactions endpoint.
- Reactions are fetched individually for up to 50 messages per render; this N+1 pattern is unsuitable for scale. Implement a batched reaction-summary endpoint.
- Mark-read is an explicit button, not proof that a human viewed the message.
- Existing Phase 26 refresh behavior replaces the latest message window and can discard older messages from the display. Improve incremental reconciliation and preserve scroll position.
- Group titles currently appear as numeric conversation labels. A conversation metadata endpoint is needed.
- The API response shape for reactions should be verified against your actual InteractionService.
- No typing-indicator UI, file attachment widget, popup chat, or WebSocket gateway integration yet.
- CSRF, company mapping, user directory, ZF1 routes, and MariaDB migrations must be wired and integration-tested.
- Legacy Chrome 49 and Firefox 52 compatibility is a design target; browser tests were not performed.

## Manual tests
1. Create private chat and group, confirm duplicates and group limit are handled server-side.
2. Add/remove member, leave/rejoin, verify old messages remain inaccessible.
3. Attempt editing another user's message, verify server rejection.
4. Edit within/outside 15-minute window; delete twice.
5. Add reaction; check reaction counts and authorization.
6. Mark-read; check monotonic sequence and membership floor.
7. Expire session and send POST; verify rejection.
8. Test XSS strings in message body and group title.
