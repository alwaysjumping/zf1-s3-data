# Phase 28 — Typing, attachment upload, persistent quick chat

## Install
- Install the cumulative Messenger module and its server adapters from earlier phases.
- Load `/applications/messenger/js/quickchat-host.js` and `/applications/messenger/css/messenger.css` **once on the top-level persistent shell**, outside navigated iframes.
- Set `window.messengerCsrfToken` securely in that shell using the authenticated server session. The token must never come from an iframe URL.
- The main Messenger view can then invoke `window.top.MessengerQuickChat.open(conversationId)`. Cross-origin frames cannot access this property; all pages must share the approved origin.

## Functionality
- Typing indicator sends REST heartbeat at most every 4 seconds and expires on server after 8 seconds; polling every 3 seconds.
- Attachment upload uses FormData with a 20 MiB client limit and CSRF header. Uploaded files remain quarantined until ClamAV approves them.
- Persistent quick-chat host supports up to three open panels and 10-second REST refresh.

## Important limitations
- **The attachment picker only uploads to quarantine.** There is no server endpoint to list approved unattached uploads yet. Do not allow manually entered attachment IDs; Phase 29 should add an authorized clean-upload listing and selection UI.
- The existing MessageService and attachment linking require the scanner to mark an upload clean before attaching.
- The quick-chat host currently uses `Object.keys`, `Uint8Array`, and `crypto.getRandomValues`; test these in your actual Chrome 49 and Firefox 52 deployments.
- Quick-chat host has no centralized multi-tab coordination yet. Its polling is per browser tab; Phase 29 should implement storage-event coordination for older browsers.
- Upload progress, cancellation, antivirus status polling, safe download links, role-aware controls, and accessible keyboard behavior need work.
- Never expose `window.messengerCsrfToken` to untrusted scripts; enforce Content Security Policy and same-origin restrictions.
- The main UI currently does not allow sending attachments because clean-attachment selection is not implemented.
- Test all ZF1 routes, auth, CSRF, company isolation, and actual browsers before production.
