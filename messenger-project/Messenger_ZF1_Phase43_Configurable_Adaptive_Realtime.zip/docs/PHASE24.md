# Phase 24 — Reactions and typing state

Cumulative package including Phases 14–23. Apply `database/007_reactions_typing.sql` **once** after migration 006 in staging. Ensure MariaDB client connection uses `utf8mb4`.

## REST API
- `POST /ws/messenger/interactions` with JSON `{ "type":"reaction", "conversation_id":12, "message_id":90, "emoji":"👍", "active":true }`.
- To remove, send `active:false`. The allowlist is 👍 ❤️ 😂 😮 😢 👏 🎉 👎. One row per message/user/emoji.
- `GET /ws/messenger/interactions?type=reactions&conversation_id=12&message_id=90` returns emoji counts.
- `POST /ws/messenger/interactions` with JSON `{ "type":"typing", "conversation_id":12, "active":true }`; false clears it.
- `GET /ws/messenger/interactions?type=typing&conversation_id=12` returns other currently typing user IDs.
- All POST requests require existing CSRF adapter. Company ID and user ID are resolved server-side.

## Typing semantics
Typing state expires after 8 seconds. Client should debounce typing updates (e.g. every 3–5 seconds while actively typing), and clear on send/blur. Expiry is enforced in the SELECT even if cleanup has not run. Schedule a trusted CLI cleanup call to `Messenger_InteractionService::purgeExpiredTyping()`; do not expose maintenance publicly.

## Important limitations
- Typing is implemented as **short-lived database state plus polling**, not push events. A future WebSocket/Workerman/Node.js adapter can publish typing changes without persistent outbox storage. Never treat a typing indicator as guaranteed delivery.
- Reaction events use the existing outbox; publisher implementation remains pending. Reaction retries are idempotent in storage but may create duplicate refresh events.
- Reaction history is not retained; removal deletes the row. Deleted messages cannot receive or expose reactions via this API; existing reaction rows remain for audit/retention decisions.
- This module is not integration-tested against the actual ZF1/MariaDB runtime. Test membership concurrency, company isolation, rejoin visibility, SQL schema, old browsers and offline assets.
- Error-to-HTTP mappings in the shared API controller need further hardening. `MESSENGER_ACCESS_DENIED` and `MESSAGE_NOT_FOUND` may currently surface as generic 500 codes; normalize to 403/404 before production.
- The legacy router still has placeholder fallback behavior outside Messenger. Do not deploy it as a general router replacement without review.

## Staging tests
1. Add reaction twice => one row; remove twice => no row.
2. React to other company's conversation or a message from before joining => denied.
3. React to soft-deleted message => denied.
4. Start typing => visible to another active member, not to self; expires after 8 seconds.
5. Leave group => typing and reaction endpoints reject access; old typing row expires.
6. Confirm emoji is preserved through UTF8MB4 and unsupported emoji is rejected.
7. Verify CSRF, unauthenticated requests and cross-company isolation.
