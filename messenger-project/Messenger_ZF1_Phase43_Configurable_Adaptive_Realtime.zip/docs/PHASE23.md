# Phase 23 — Message edits, soft deletion, read receipts

This is a cumulative source package built on Phase 22. Apply `database/006_message_revisions.sql` after earlier migrations, once, on a backed-up staging DB.

## REST endpoint
`POST /ws/messenger/message-state` with existing authenticated session and `X-CSRF-Token`.

```json
{"operation":"edit","conversation_id":12,"message_id":90,"body":"Updated message"}
```
```json
{"operation":"delete","conversation_id":12,"message_id":90}
```
```json
{"operation":"read","conversation_id":12,"sequence_no":27}
```

The controller obtains user/company IDs only from the trusted server-side adapters.

## Rules
- Edits: original sender only; active membership; message must be in the current membership period; text messages only; 15-minute edit window (configurable service constructor). Previous body saved in restricted revision table; ordinary APIs should never expose it.
- Delete: original sender only; soft-delete keeps record, sets `deleted_at` and `deleted_by`; repeat deletion returns an idempotent result.
- Read cursor: active member only, cannot exceed the conversation's current last sequence, cannot precede the current membership period; monotonic (never decreases).
- All writes lock `msg_conversations` first, then membership/message rows as needed; outbox insert is in the same transaction.
- No websocket delivery is performed here; your existing outbox publisher must be wired separately.

## Limitations / security review
- Actual DB tests and browser tests are NOT run; PHP syntax checks are not integration tests.
- A read receipt means the client reported having read up to the supplied sequence. The server cannot prove human viewing.
- Edit history is sensitive: restrict DB access, backups, retention, and administrator workflows. Ordinary API must not expose previous bodies.
- Deleted message attachments remain subject to the earlier attachment visibility rules; verify download implementation denies access to attachments of deleted messages according to your policy.
- Server timestamps use UTC `gmdate` to second precision, even though columns support microseconds.
- Message `created_at` is assumed UTC and is parsed as UTC for the edit-window check.
- Revisit the legacy router's fallback behavior and your company/employee/CSRF adapters before production.
- No admin/moderator delete override in this phase; only original author may delete.
- Client read-cursor submission can skip unread messages; decide whether to require explicit per-message acknowledgement.
- This phase does not yet implement UI, typing indicators, emoji, reactions, search, or complete real-time delivery.

## Manual staging test plan
1. Sender edits own recent text -> revision row + message update + outbox event.
2. Other participant edits/deletes sender's message -> denied.
3. Sender edits after window -> denied; edit a deleted/system/file message -> denied.
4. Sender deletes message -> ordinary history shows no body; repeat delete is idempotent.
5. Member reads sequence 10 then 8 -> cursor stays 10; 11 -> advances.
6. Cursor beyond conversation last sequence -> denied.
7. Leave/rejoin then edit old message or submit earlier read cursor -> denied.
8. Force outbox insert failure -> whole edit/delete/read transaction rolls back.
9. Two concurrent edits and membership changes -> no unauthorized visibility.
