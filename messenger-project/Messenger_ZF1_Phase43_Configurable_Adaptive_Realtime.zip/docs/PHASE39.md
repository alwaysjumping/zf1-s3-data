# Phase 39 — Performance and query optimization

## Implemented
- `GET /ws/messenger/interactions?type=reactions-batch&conversation_id=...&message_ids=1,2,3`
- Returns a map of message ID to emoji totals. Missing entries mean no reactions.
- Checks company, active conversation membership, and `first_visible_sequence` before fetching.
- Restricts to at most 100 unique IDs; no message body is returned.
- The frontend now requests one reaction batch per render instead of up to 50 separate requests.
- `database/diagnostics/phase39_explain.sql` provides read-only EXPLAIN queries.

## Important limitations
- This package has only syntax/static checks; no database benchmark or EXPLAIN has been executed.
- The existing `uq_msg_seq(conversation_id,sequence_no)` and `idx_reaction_message(message_id,emoji)` are already useful. Avoid adding redundant indexes without staging EXPLAIN evidence.
- Other frontend N+1 patterns, notably per-message attachments and repeated full history refreshes, still need optimization.
- The frontend uses one response per render; rapid successive refreshes can still race. Consider a request generation counter in a later phase.
- The package does not claim a measured performance improvement or production readiness.

## Staging checks
1. Apply all previous migrations in order to a disposable MariaDB staging database.
2. Confirm batch endpoint returns counts only for visible messages; test another company, departed member, and pre-join message.
3. Compare request counts for a 50-message page: previously up to 50 reaction GETs, now one.
4. Run `EXPLAIN` samples with realistic identifiers and compare `key`, `rows`, and `Extra`.
5. Run a concurrency and load test with representative employee counts before adjusting indexes or polling intervals.
