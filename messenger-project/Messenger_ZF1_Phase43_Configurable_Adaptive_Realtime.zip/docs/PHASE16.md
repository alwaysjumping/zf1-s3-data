# Phase 16: Transactional messaging foundation

## Contents

- `library/Messenger/MessageService.php`: transactional `sendText()` and membership-filtered `getHistory()`.
- `database/001_core.sql`: corrected to contain only conversations, participants, membership periods.
- `database/002_messages_outbox.sql`: message and transactional outbox tables.
- Previous Phase 15 routing smoke test and supporting files are retained.

## IMPORTANT migration correction

Phase 15's `001_core.sql` accidentally included `msg_messages` and Phase 15's `002_messages_outbox.sql` also created `msg_messages`. **Do not run both old Phase 15 migrations as-is.** Phase 16 corrects `001_core.sql` for fresh installs. If you have already run Phase 15 SQL, inspect `SHOW TABLES LIKE 'msg_%'` and `SHOW CREATE TABLE msg_messages` before applying anything. Do not drop existing tables or reapply migrations blindly.

## Integration

```php
$db = Zend_Db_Table::getDefaultAdapter();
$service = new Messenger_MessageService($db);
// Obtain all IDs from authenticated and validated server-side adapters.
$message = $service->sendText($companyId, $conversationId, $userId, $uuid, $body);
$history = $service->getHistory($companyId, $conversationId, $userId);
```

The module requires PHP `mbstring`, ZF1's database adapter, InnoDB, and tables in both SQL files. The code does not expose a send endpoint yet; Phase 15's REST router only supports the smoke-test route.

## Transaction rules

1. Lock the conversation row `FOR UPDATE` before membership checks or mutation.
2. Reject inactive members and cross-company access.
3. Reuse UUID for retries. A UUID reused with different content or conversation is rejected.
4. Insert message, update conversation summary, and insert outbox event within one transaction.
5. Roll back all changes if any operation fails.
6. Read history only from the currently active membership period, and hide deleted body text.

## Known remaining work

- Integrate trusted company resolver and authenticated REST endpoints.
- Implement driver-specific duplicate-key race recovery; current service safely rejects/rethrows a race rather than producing a duplicate message.
- Implement complete schema for groups, attachments, reactions, read receipts, durable sync, audit, and revisions.
- Build outbox publisher, authorization-filtered event delivery, and real-time adapters.
- Add MariaDB integration/concurrency tests and security tests; syntax checking is not a functional test.
- Validate timestamps, integer ranges, group ownership, rate limits, input size, and retention against your environment.
- Confirm employee/company key types before installation.

**This is a foundation package, not a production-ready Messenger module.**
