# Phase 37 — MariaDB staging validation

This is a **cumulative source package**. It includes a new read-only schema preflight and a **destructive** live integration test suite. These tests are **not executed against MariaDB in the build environment** because no live staging server and actual Zend dependencies were supplied. Syntax checks alone are not database validation.

## Prerequisites

- Create a disposable MariaDB schema with a name containing `test`, `staging`, `scratch`, or `ci`; **never use production or a clone containing sensitive production data**.
- Run `database/001_core.sql` through `008_gateway_tokens.sql` **in order** against that schema. Review every migration for MariaDB-version compatibility before execution.
- Use PHP 7.4 with Zend Framework 1, mbstring, PDO MySQL, and a Zend DB adapter. Set database session time zone to `+00:00`.
- Write a private bootstrap file (outside the webroot) that initializes the Zend autoloader and returns a configured `Zend_Db_Adapter_Abstract`. Use a dedicated database account restricted to this test schema.
- Provide the actual schema name in `MESSENGER_TEST_DATABASE` and the bootstrap path in `MESSENGER_TEST_BOOTSTRAP`. The script checks the selected database exactly.

## Commands

```bash
export MESSENGER_TEST_DATABASE=messenger_staging_test
export MESSENGER_TEST_BOOTSTRAP=/srv/private/messenger-test-bootstrap.php
php tests/database/schema_preflight.php
MESSENGER_TEST_ALLOW_DESTRUCTIVE=YES_I_UNDERSTAND php tests/database/live_integration.php
```

The live test creates conversations, messages, memberships and outbox records **and leaves them in the disposable database**. It tests group creation, monotonic message sequence, retry idempotency, duplicate UUID conflicts, company isolation, non-member denial, join/rejoin visibility boundaries, and outbox existence. It does not exercise production employee tables or an HTTP session; its employee directory is a deliberate test fixture.

## Concurrency verification (manual staging)

1. Create a group and two eligible test users; record the conversation ID and `last_sequence`.
2. Start 20 parallel requests with distinct `client_message_id` values, all to the same conversation, using two authenticated test accounts.
3. Verify 20 additional rows with unique, contiguous `sequence_no` values; `last_sequence` equals the maximum sequence; every committed message has an outbox event.
4. Repeat the same `client_message_id` concurrently from two workers with identical body. Verify only one committed row and consistent response. If one worker gets a duplicate-key exception, that is a **known current limitation** of `MessageService::sendText()` and must be resolved before release.
5. Race a member removal against a send. Verify lock ordering ensures the message is either committed before departure or rejected after departure, not inserted without valid membership.
6. Repeat private conversation creation simultaneously for the same pair. Verify one `msg_private_pairs` row.

## Known limitations and release gates

- `MessageService::sendText()` currently does not recover from concurrent duplicate-key idempotent retries; this is a **release blocker** for exactly-once client retry semantics.
- Company/employee resolvers are host-specific and remain unconfigured by this package.
- Migration rollback scripts are not provided; test on disposable schemas and restore backups if needed.
- Full cross-company isolation, concurrency, attachment scan worker, outbox transport, REST, WebSocket and old-browser tests remain pending.
- The database preflight checks only a subset of schema objects. Passing it does not certify the entire schema.
- No Redis is required.
