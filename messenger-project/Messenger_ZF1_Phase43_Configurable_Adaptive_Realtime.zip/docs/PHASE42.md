# Phase 42 — Authorized outbox change hints (preview)

Adds `GET /ws/messenger/changes?after_id=0&limit=100` and an authenticated, company-scoped `Messenger_Realtime_ChangeFeed`. Response contains `events`, `next_cursor`, `has_more`, `requires_periodic_snapshot`. Event metadata only; no payloads, message text or attachments.

## Security
- Active participant and latest active membership period required.
- Filters events before latest join and message/reaction events referring to pre-join messages.
- No cross-company access; company comes from server session.
- A member removed from a group cannot fetch its events.

## Known limitations (important)
- MariaDB auto-increment outbox IDs are **not commit-order**. A transaction that reserves a lower ID but commits later may be skipped when a client advances its cursor. Therefore this is a **best-effort invalidation feed**, not a lossless change log. Clients must retain periodic authoritative `/sync` snapshots and latest-message reconciliation. A durable change cursor requires an explicit commit-ordered per-conversation log or equivalent serialization.
- Membership events may not be visible after removal, because authorization intentionally fails closed. The regular conversation snapshot is authoritative.
- Read/reaction/attachment events require client-side refresh of their current authoritative REST representation. This phase does not yet wire a new browser change-feed polling loop; existing polling remains active.
- No live MariaDB concurrency or old-browser integration test has been run.

## Staging test cases
1. Compare events after edits, deletes, reactions, and new messages.
2. Remove a user and verify no further events are accessible.
3. Rejoin and verify events and message metadata before the new join are not visible.
4. Verify no cross-company conversation IDs appear.
5. Test a delayed transaction that commits after a later outbox ID; confirm `/sync` recovery.
6. Check `EXPLAIN` on the new query under representative volumes.
