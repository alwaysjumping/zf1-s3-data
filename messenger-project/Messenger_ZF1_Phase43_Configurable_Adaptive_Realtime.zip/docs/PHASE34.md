# Phase 34 — Credential rotation and gateway recovery

Cumulative package from Phase 33. Browser obtains a fresh opaque token for **each** WebSocket connection. The gateway forces connection recycling at 115 seconds, before the 120-second default token expiry. Reconnect triggers REST reconciliation.

## Wiring
1. Include locally hosted `gateway-session.js` **before** `ws-client.js` and `realtime-coordinator.js` in the top-level shell.
2. Create `var session = new MessengerGatewaySession(csrfToken);` where `csrfToken` comes from your server-authenticated page.
3. Pass `getToken: function(cb){session.getToken(cb);}` to `MessengerRealtimeCoordinator` along with `url`, `scope` and `onReconcile`. Do not pass persistent `token` values.
4. The coordinator's `onReconcile` must call your authorized REST sync API. A failed token request retries with exponential backoff.
5. Before completing normal ZF1 logout, call `session.logoutGateway(cb)`, stop coordinator, and then perform existing logout. **Always invalidate the ZF1 session even if gateway revocation fails.** The server must also call `revokeUser()` from the trusted logout handler; browser-only revocation is insufficient.
6. `DELETE /ws/messenger/gateway-token` revokes **all** current gateway tokens for the user, across sessions. Replace with per-session token families if other sessions must remain online. Verify `DELETE` is correctly dispatched and CSRF-checked in your actual ZF1 router.

## Security limitations
- The PHP verifier is a loopback-only development reference. Hardening remains necessary.
- A 115s timeout is a safety cap, not instant revocation. The existing gateway calls the verifier for every hint, so revoked tokens stop receiving hints, but a socket can remain open until timeout.
- The verifier currently does not validate active employment/account status on each check; integrate with authoritative employee directory.
- Server-side logout revocation integration is NOT automatically installed into your framework's existing logout endpoint.
- The frontend script is a wiring helper; top-level shell integration is still manual.
- Node.js and Workerman gateways are reference implementations and require runtime dependencies.
- REST polling must continue independently as fallback; reconnect does not guarantee delivery of past signals.
- `Messenger_ApiController` JSON envelope and CSRF behavior must be confirmed before use.
- The REST router patch must be reviewed for DELETE handling.

## Staging tests
1. Fresh token requested per initial connect/reconnect; no token in localStorage or URL.
2. Force token expiry and verify new connection with new token; REST sync runs on ready.
3. Revoke user tokens; verify hints are denied.
4. Disconnect gateway, recover network; REST polling reconciles missing messages.
5. Leader tab closes; another tab obtains a fresh token.
6. Logout from one tab; other sessions behave according to revoke-all policy.
7. Test Chrome 49, Firefox 52, and each gateway in a real staging environment.
