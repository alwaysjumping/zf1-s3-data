# Phase 20: Attachment storage foundation

## Installation
1. Apply `database/004_attachments.sql` **after** earlier migrations, on a staging copy first.
2. Create a dedicated non-web-accessible storage directory with restrictive permissions, owned by the PHP service account. Pass its absolute path to `Messenger_AttachmentService`.
3. Configure PHP `upload_max_filesize` and `post_max_size` to accommodate a 20 MiB file plus form overhead. Enforce server-side size checks regardless.
4. Use `upload($companyId, $conversationId, $userId, $_FILES['file'])` only after session authentication, company resolution and CSRF validation.
5. Scan quarantined files with a trusted server-side antivirus worker. Only that worker may call `recordScanResult()`; never expose it through a user endpoint.
6. `downloadMetadata()` only returns a server-side path after membership, message visibility, clean-scan and integrity checks. A download controller must stream bytes, set `Content-Disposition: attachment` and `X-Content-Type-Options: nosniff`, and must not expose the filesystem path in JSON.

## Not yet implemented
- A scanner adapter/worker, attachment linking into a newly sent message, download streaming controller, rate limiting, retention and orphan cleanup, file type policy, quotas, audit logging, and antivirus test coverage.
- Uploads are **quarantined** and cannot be downloaded or attached to a message until a trusted scanner marks them clean. This is intentional fail-closed behavior.
- Existing router must be extended for upload/download routes; do not assume these endpoints already exist.
- Never trust user-provided company IDs, file paths or scan results.

## Security considerations
- Store files on a filesystem outside all served roots and disable executable handling. Consider separate storage service/volume and mandatory access controls.
- This implementation checks current membership at upload and membership-period visibility at download. It does not authorize former members to download historical files.
- `recordScanResult` assumes a trusted worker actually scanned the same bytes. Production deployment should use a worker-only capability, a stable file handle, and a scan-result protocol bound to the digest.
- Database and filesystem writes are not atomic together: operational reconciliation and cleanup are required.
