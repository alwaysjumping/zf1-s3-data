# Phase 43 — Configurable Workerman / Adaptive REST polling (ZF1)

This is an update to the original ZF1 Messenger skeleton, **not** a replacement with the standalone PHP application.

## Configuration

Edit `configs/application.ini` under `[production]`:

```ini
messenger.realtime.mode = "polling"
messenger.realtime.wsUrl = "ws://127.0.0.1:8081/messenger/ws"
messenger.realtime.activePollMs = 5000
messenger.realtime.idlePollMs = 30000
messenger.realtime.hiddenPollMs = 60000
```

Set `mode = "workerman"` to enable the existing ZF1 Workerman gateway. The URL must be reachable from the browser; remote deployments should use `wss://`. The existing ZF1 gateway requires its **trusted verifier**, **signal publisher**, secrets, allowed origin, and Workerman Composer dependencies as documented in `docs/PHASE32.md`, `docs/PHASE33.md`, and `docs/PHASE34.md`. It is **not** the same protocol/configuration as the standalone PHP gateway.

## Behavior

- Polling mode: no WebSocket token requests or WebSocket connections; the leader tab discovers changes through REST.
- Workerman mode: one elected tab opens the WebSocket and refreshes on hints. A healthy socket suppresses frequent background REST polling; a safety REST sync occurs approximately every five minutes.
- If Workerman is disconnected, the leader uses adaptive REST polling and the socket client retries.
- In polling mode: active/visible leader ~5s; idle leader ~30s; hidden leader ~60s.
- Followers receive `localStorage` hints and use REST as needed. Visible followers reconcile at least every five minutes.
- Typing status is polled only for an open conversation in a visible tab, approximately every 10 seconds.
- Quickchat background refresh has been reduced from 10s to 60s, with an immediate refresh on opening/sending.
- A hint is sent to other tabs only when the conversation snapshot actually changes, not after every REST sync.
- Mode switching requires a reload of all Messenger tabs.

## Files changed

- `configs/application.ini`
- `applications/messenger/controllers/IndexController.php`
- `applications/messenger/views/scripts/index/index.phtml`
- `public/applications/messenger/js/messenger.js`
- `public/applications/messenger/js/quickchat-host.js`

Existing `tab-coordinator.js`, `ws-client.js`, `gateway-session.js`, Workerman gateway and ZF1 REST services are retained.

## Limitations and validation

- `localStorage` election is best-effort, not an atomic lock. ZF1 gateway does not yet have server-side per-session connection fencing comparable to the newer standalone gateway.
- Outbox delivery and gateway signaling must be configured; WebSocket hints alone are not a correctness boundary.
- Browser storage failure may cause duplicate polling or sockets.
- Browser sleep/throttling can delay timers; REST reconciliation remains essential.
- This release does not backport the standalone gateway's database ticket/session-fencing migrations.
- The standalone app's `realtime_mode` PHP config is **not** used by ZF1; ZF1 uses `application.ini`.
- Static syntax tests do not establish compatibility with the actual production ZF1 bootstrap, database, Workerman, Chrome 49, or Firefox 52. Test these integrations before deployment.

## Test checklist

1. Polling mode with Workerman stopped: confirm messages arrive eventually and no `gateway-token` requests occur.
2. Open three same-account tabs: confirm one leader performs routine discovery; close it and verify takeover.
3. Leave tabs idle, hide/reveal tabs, and inspect Network requests and response freshness.
4. Enable Workerman, configure verifier/signals, and reload: confirm one browser socket in ordinary operation.
5. Send from another account: verify WebSocket hint and authorized REST refresh.
6. Stop gateway: confirm adaptive REST fallback and recovery after gateway restart.
7. Test account/company isolation, logout, CSRF, and old browsers.
