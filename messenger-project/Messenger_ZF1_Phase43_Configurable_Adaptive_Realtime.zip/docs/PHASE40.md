# Phase 40 — Frontend history window and stale-response protection

## Implemented
- `loadLatest()` merges the latest 50 messages into previously fetched history rather than discarding older pages on every poll.
- History is deduplicated by message ID and sorted by `sequence_no`.
- The in-memory/DOM message window is bounded to the latest 200 loaded messages.
- `older()` avoids duplicate concurrent page requests and stops after a short page.
- Switching conversations increments a generation counter; stale history and reaction responses are ignored.
- A newer latest-page request supersedes an older one, preventing out-of-order refresh results from overwriting the UI.
- Reaction counts remain fetched as one batch per render (Phase 39).

## Limitations and staging tasks
- The 200-message window retains the newest loaded messages. When it is full, pressing Older will not navigate indefinitely back in time; a virtualized history viewer or paged server cursor is needed for archival browsing.
- Attachment listing still fetches the full authorized message-file list per latest-page refresh. Batch/cursor-based attachment API remains a future task.
- No server-side incremental synchronization or measured benchmark is claimed.
- Concurrent `older()` and `loadLatest()` calls may cause an older response to be ignored; retrying Older is safe.
- Test with Chrome 49 and Firefox 52 using locally hosted JS/CSS, and with real ZF1/MariaDB staging data.

## Test checklist
1. Load 50 messages, press Older, receive 50 more, then trigger sync: earlier messages must remain visible.
2. Rapidly switch between conversations: old conversation responses must not appear in the new conversation.
3. Trigger two latest-page requests and reverse response order: the earlier response must not overwrite the later one.
4. Remove membership during an in-flight request: history should be cleared and stale results ignored.
5. Load 200+ messages: DOM remains bounded; document the archive navigation limitation.
6. Confirm emoji reaction counts match the visible page and no stale reaction results are applied.
