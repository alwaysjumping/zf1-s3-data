# Phase 38 — Transaction retry and concurrency reliability

## Change
`Messenger_MessageService::sendText()` now retries known deadlock (1213) and lock-wait timeout (1205) errors up to three transaction attempts with bounded jitter. Unknown database failures still fail closed. After a duplicate-key failure, it rolls back and reads the winning message by the unique `(sender_id, client_message_id)` key; it checks conversation, message type, exact body and current membership before returning the existing message. A mismatched retry raises `CLIENT_MESSAGE_ID_CONFLICT`.

The existing `msg_messages.uq_msg_retry` unique index and per-conversation `SELECT ... FOR UPDATE` lock are required. Do not remove either. The message, sequence update and outbox insert remain one transaction.

## Checks
Run `php tests/concurrency_smoke.php` for deterministic deadlock injection, idempotency and conflict checks. Run the existing `tests/verify_package.py`, REST routing and adapter smoke checks. These are **not live concurrent database tests**.

## Real MariaDB staging concurrency test plan
1. Provision a disposable staging MariaDB database and apply migrations in order. Confirm InnoDB and unique keys.
2. Create two valid employees and a private conversation in the same company.
3. Start 10 PHP CLI workers behind a barrier, all sending the **same** UUID and body using separate database connections. Assert one `msg_messages` row, one matching outbox event and one increment to `last_sequence`; all successful calls return the same message ID.
4. Repeat with 10 **distinct** UUIDs. Assert 10 new messages, 10 outbox events and strictly contiguous sequence numbers.
5. Repeat using one UUID with different bodies. Exactly one body may win; all different-body retries must return `CLIENT_MESSAGE_ID_CONFLICT`.
6. Concurrently create the same private pair from 10 workers. Assert one `msg_private_pairs` row and one conversation; no orphaned participants.
7. Concurrently remove a group member while sending. Verify the conversation row lock serializes these operations and a removed member cannot send after removal commits.
8. Force deadlock 1213 and timeout 1205 and confirm bounded retry and rollback. Inject an outbox insert failure; confirm no message or sequence survives.
9. Test repeated membership join/leave and confirm the latest join's `first_visible_sequence` restricts history.

## Release gates
These checks must pass on your actual PHP 7.4 + Zend_Db + MariaDB version before production. The project ZIP does not include the full original Zend library or a runnable staging database. Do not interpret offline tests as proof of multi-process concurrency safety.
