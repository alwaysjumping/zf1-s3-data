# Phase 32 — Workerman gateway and coordinated browser WebSocket

Cumulative package built on Phase 31. Adds `gateways/workerman/server.php` and `public/applications/messenger/js/realtime-coordinator.js`.

## Gateway setup

1. Install a **PHP 7.4-compatible Workerman release** from your internally approved offline packages. Put its Composer autoload file under `gateways/workerman/vendor/autoload.php`, or adjust the bootstrap path. No vendor libraries are bundled.
2. Configure `MESSENGER_WS_PORT`, `MESSENGER_SIGNAL_PORT`, `MESSENGER_SIGNAL_SECRET`, `MESSENGER_VERIFY_SECRET`, `MESSENGER_VERIFY_URL`, and `MESSENGER_ALLOWED_ORIGIN` exactly as described in Phase 31. Secrets must not be committed to Git. Do not reuse the two secrets.
3. Start `php gateways/workerman/server.php start` under a restricted service identity and supervise it with your existing service manager. This is a **single-process reference gateway**; it intentionally does not support multi-process fanout.
4. Both Node and Workerman listen on the same default ports. **Run one gateway implementation per deployment**, not both.
5. Use a trusted TLS reverse proxy and the **same PHP signed signal transport** as Phase 31. Internal verifier is still a required, unimplemented dependency; it must validate ephemeral tokens and active membership on every authorize call.

## Browser wiring (top-level shell only)

Load in this order, from your own site:

```html
<script src="/applications/messenger/js/tab-coordinator.js"></script>
<script src="/applications/messenger/js/ws-client.js"></script>
<script src="/applications/messenger/js/realtime-coordinator.js"></script>
```

After the shell securely obtains a **short-lived, scoped** gateway token:

```javascript
var realtime = new MessengerRealtimeCoordinator({
  scope: companyScopedUserKey, // non-secret stable scope, derived by trusted shell
  url: 'wss://your-intranet-host/messenger/ws',
  token: ephemeralGatewayToken,
  onReconcile: function () { messengerInstance.sync(true); }
});
realtime.start();
// Call realtime.stop() on shell teardown/logout.
```

Only the elected tab opens the WebSocket; followers refresh on localStorage hints. Leader changes stop/start the socket. REST reconciliation occurs on readiness, hint, disconnection, and periodically. The existing Messenger frontend has its **own** coordinator; when integrating this bridge, avoid creating two independent coordinators for the same scope. Prefer exposing the bridge in the top-level shell and disabling the page-level coordinator. Quick-chat still needs its own integration with the shell's reconciliation event.

## Critical limitations

- This is a reference implementation, **not production-ready**. Workerman version-specific `onWebSocketConnect`/`Request` behavior needs testing with the chosen release.
- Workerman's `text://` signal listener parses newline-delimited frames and responds with the signed acknowledgement expected by Phase 31's PHP transport. Verify framing against your exact Workerman version.
- `file_get_contents()` verifier calls are **blocking** inside the Workerman event loop. For scale, use an async verifier with bounded concurrency and timeouts; a slow verifier can block every connection.
- Browser connection authorization occurs only on the first auth message. Add an authentication deadline, connection and memory limits, heartbeat, token expiry enforcement, and token refresh handling before production.
- Check the Workerman handshake origin and path in staging; reject unauthorized origins at both proxy and gateway.
- In-memory replay cache is lost on restart. Outbox and REST reconciliation provide eventual recovery, but do not guarantee exactly-once WebSocket delivery.
- The PHP signal transport and the gateway's signed packet format must be tested together. No production deployment should rely on syntax checks alone.
- A **trusted internal verifier is not provided**. Without it, neither Node nor Workerman gateway can authenticate users.
- The company resolver, employee directory, CSRF provider, DB migrations, and full app integration remain necessary.

## Staging tests

- Run the Workerman gateway and verify valid/invalid handshake origins and ephemeral tokens.
- Send signed hint through PHP transport; assert the gateway acknowledges it and only active members receive invalidation.
- Remove a member, then send a hint; confirm no delivery and no access via REST.
- Open three tabs: one gateway socket, followers reconcile on hint; close leader and confirm takeover.
- Restart gateway and force an outbox retry; verify REST catches missed messages.
- Simulate verifier outage, expired token, and signal outage; verify fail-closed behavior and REST fallback.
- Repeat on Chrome 49 and Firefox 52 with locally hosted assets.
