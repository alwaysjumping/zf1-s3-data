# Phase 41 — Incremental synchronization

## Changes
- GET `/ws/messenger/messages?conversation_id=ID&after_sequence=N&limit=50` fetches up to 50 newer messages in ascending sequence order. `after_sequence=0` is accepted.
- Existing history requests using `before_sequence` retain their descending ordering. Both cursor parameters together are rejected.
- Both modes use the same company and current-membership visibility checks.
- The main UI uses delta requests when a conversation sequence advances without a membership period change. On a full 50-row delta page it refreshes the newest page to avoid permanently missing recent messages.
- Quick-chat panels refresh on cross-tab storage hints, while retaining periodic polling.

## Caveats
- Edits, deletes and reactions do not increment message sequence; the snapshot path continues to call the latest-page endpoint for other event changes.
- This is not a complete change-feed protocol. A true event cursor, gap recovery, and versioned edits remain future work.
- `after_sequence` uses integer conversion on PHP 7.4; deploy on 64-bit PHP.
- Browser and database integration tests have not run.

## Staging acceptance checks
1. Verify before/after cursor boundary and same-company membership restrictions.
2. Verify a departed member and a rejoined member cannot read messages outside their current visibility period.
3. Simulate >50 messages arriving between syncs and confirm newest-page reconciliation.
4. Verify edit/delete/reaction changes still appear after snapshot refresh.
5. Verify quick-chat remains usable without localStorage events and in Chrome 49 / Firefox 52.
