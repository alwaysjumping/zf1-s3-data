# Phase 35 — Offline integration audit and staging deployment

This cumulative package contains Phase 34 source files plus a corrected Messenger REST route, a corrected view user ID, and offline source-contract tests. It is **not** production-ready.

## Corrections
1. Added `gateway-token` to the route allowlist. Without it, token requests fell through to the unsupported controller.
2. Routed HTTP `DELETE` to `deleteAction`, allowing gateway-token logout revocation.
3. Set `$this->view->messengerUserId` from the authenticated `Messenger_IdentityProvider` in the page controller; it is used only for UI affordances, never as authorization.

## Offline smoke checks
From the package root:

```bash
python3 tests/verify_package.py
php tests/route_smoke.php
```

Requires PHP 7.4+ CLI, Node.js for syntax checking, and Python 3. The route smoke test uses minimal Zend stubs; it is not an actual ZF1 bootstrap test.

## Staging deployment sequence
1. Make a backup of application files and MariaDB. Use a **new staging database** for the initial migration run.
2. Restore your actual `vendor/` and Zend framework libraries, which were intentionally absent from the skeleton. Do not deploy sample files over production without diff review.
3. Review the patch at `patches/library/User/Rest/Route.php` against your site's real router. The existing non-Messenger fallback still routes to the hardcoded `draft/info/put` placeholder. It must be replaced safely in a separate router migration before production.
4. Register `applications/messenger` as a module in your existing module loader and verify its `services/` directory is used by the REST dispatcher.
5. Run migrations `001` through `008` **once in order**, against an empty staging schema. Check actual MariaDB compatibility, constraints, indexes, and transaction behavior; these were not tested in this package.
6. Implement and register `messenger_company_resolver`, `messenger_employee_directory`, `messenger_csrf_validator`, `messenger_csrf_token_provider`, and `messenger_attachment_storage` in ZF1 bootstrap. Verify company identity is derived from trusted server-side configuration, not client input.
7. Configure `utf8mb4` on the MariaDB connection and test multi-byte emoji roundtrips.
8. Install ClamAV and approved definitions offline. Use a dedicated restricted worker identity and a storage directory outside every webroot.
9. Deploy the verifier on a restricted loopback listener and the chosen gateway (Node.js or Workerman) only after configuring internal shared secrets and TLS termination. Never use the PHP built-in verifier server in production.
10. Add gateway token revocation to the actual ZF1 logout path, then verify no stale session can issue new tokens.
11. Load locally hosted jQuery, DHTMLX 3.5 and Messenger assets from the top-level shell. Test Chrome 49 and Firefox 52 in the actual target environment.
12. Validate all API operations and error responses against real ZF1, MariaDB and the selected gateway.

## Required integration tests (not yet executed)
- Private chat uniqueness under concurrent requests; group membership limit at 100.
- Join/leave/rejoin visibility boundaries; simultaneous send and membership changes.
- Company isolation, missing session, CSRF failure, logout and revoked/expired gateway token.
- Message idempotency, edits, soft deletes, revisions, read receipts, emoji reactions and typing expiration.
- File upload 20 MiB boundary, antivirus fail-closed behavior, secure download and deleted-message attachment visibility.
- Outbox worker crashes, retry/recovery, duplicate hints, offline REST fallback.
- Multiple tabs, leader loss, iframe navigation, token rotation, and WebSocket reconnect.
- Database and filesystem backup/restore and retention policies.

## Known blockers
- Missing concrete company resolver and employee directory integration.
- The legacy router's hardcoded fallback is unsafe to treat as a general production REST router.
- The package's endpoint contract checks are static; no live application integration tests were possible.
- Quick-chat, WebSocket, and page-level tab coordinators require a single shell-level integration pass.
- Current frontend reaction summaries use many requests; add a batch endpoint for performance.
- A separate threat model, operational hardening and load test are required before launch.
