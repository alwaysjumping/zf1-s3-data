# Phase 36 — ZF1 staging integration adapters

This is a cumulative package. It provides **site adapter scaffolding**, not a fully deployed ZF1 module. It intentionally does not guess your employee/company database schema or alter your legacy REST routing outside Messenger.

## Added
- `library/Messenger/Integration/{CompanyResolver,EmployeeDirectory,Csrf,Bootstrap}.php`
- Scoped `messengerTabScope` using trusted company and user identifiers in `Messenger_IndexController`.
- `tests/integration_adapter_smoke.php` with isolated callback and CSRF tests.

## Bootstrap example (adapt to your actual ZF1 bootstrap)

```php
// Execute after Zend autoloading, Zend_Session, Zend_Auth and DB setup.
Messenger_Integration_Bootstrap::register(
    function ($userId) use ($db) {
        // TODO: Query authoritative company mapping. Return integer > 0 or throw.
        // Never use request company_id or return a constant for all users.
        throw new RuntimeException('COMPANY_LOOKUP_NOT_IMPLEMENTED');
    },
    function ($companyId, $userId) use ($db) {
        // TODO: Verify active employment and membership of this company.
        return false; // fail closed until implemented
    },
    '/srv/messenger-private/attachments'
);
```

The directory must exist, be writable by the dedicated service identity, and be outside the webroot. In production, explicitly configure an absolute webroot for each virtual host and review symlink/mount risks. The adapter's check is a safeguard, not a full filesystem policy.

## Module registration
1. Install `applications/messenger` using your actual application module discovery mechanism. Verify `services/` controllers are discoverable for `/ws/` routes.
2. Register `library/Messenger` and `library/Messenger/Integration` in your existing Zend autoloader. Verify `Messenger_Integration_*` class names map to paths.
3. Merge the Messenger branch from `patches/library/User/Rest/Route.php` into your existing router **without replacing non-Messenger routes**. The `draft/info/put` fallback in the supplied patch is a legacy placeholder and is **not** a general REST router. Do not deploy the patch wholesale.
4. Register the callbacks above in your real Bootstrap after auth and session setup. Check CSRF token rotation on login and logout and gateway token revocation on logout.
5. Configure attachments, scanner, worker, outbox, gateway, and shell-level quick-chat separately; the adapter does not start those services.
6. Run `php tests/route_smoke.php`, `php tests/integration_adapter_smoke.php`, and `python3 tests/verify_package.py` in staging.
7. Run migrations 001–008 on an isolated MariaDB staging schema and perform live authenticated endpoint tests.

## Security and limitations
- Browser tab scope is now partitioned by trusted company/user ID, but cross-tab leader election remains best-effort.
- The CSRF synchronizer is per authenticated PHP session namespace. The host must rotate it at authentication boundaries and set Secure/HttpOnly/SameSite session cookies as appropriate.
- Employee lookup and company lookup are mandatory host-specific implementations; neither is invented in this package.
- Runtime ZF1/MariaDB integration and old-browser tests have **not** been run.
- No Redis is required.
