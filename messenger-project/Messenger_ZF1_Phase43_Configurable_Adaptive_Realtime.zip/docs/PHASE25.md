# Phase 25 — Real-time publisher and REST synchronization

## New components

- `library/Messenger/Realtime/OutboxPublisher.php`: claims transactional outbox events, publishes opaque invalidation hints through a supplied callable transport, retries with exponential backoff, and records lease tokens.
- `library/Messenger/Realtime/ConversationSnapshot.php`: authenticated polling snapshot of the user's **current** conversations, last message sequence, read cursor, and current membership period.
- `applications/messenger/services/SyncController.php`: `GET /ws/messenger/sync`.
- Updated REST route for `/ws/messenger/sync`.

## Integration (PHP 7.4)

Register the `Messenger_` class prefix with your application's ZF1 autoloader. Provide a trusted transport callable, **not** arbitrary user-controlled destination URLs:

```php
$transport = function (array $hint) use ($trustedGateway) {
    // Implement with the existing internal signal socket or authenticated local IPC.
    // Return TRUE only when the gateway acknowledges receipt.
    // Gateway must authenticate the publisher and authorize each subscriber.
    return $trustedGateway->publishMessengerInvalidation($hint) === true;
};
$publisher = new Messenger_Realtime_OutboxPublisher($db, $transport);
for ($i=0; $i<100; $i++) {
    if ($publisher->runOne() === false) break;
}
```

Run this from a dedicated, supervised **CLI process**, never a public HTTP request. The `$trustedGateway` above is an integration placeholder and is **not included** in the package.

## Deployment modes

**Group A — Node.js WebSocket:** use your existing authenticated ZF1-to-Node internal signal channel as the transport. Node must authenticate subscribers and check current company/membership before delivery. A client receiving an invalidation calls authorized REST APIs.

**Group B — Workerman WebSocket:** same protocol via the existing ZF1-to-Workerman internal signal channel. Avoid full message content in signals.

**Group C — REST polling:** call `GET /ws/messenger/sync` on an interval, compare per-conversation snapshots, then fetch message history as needed. Refresh after reconnect, tab activation, and membership changes.

## Important correctness limitations

- **At least once:** a crash after gateway acknowledgement but before DB update can duplicate a hint. Clients deduplicate hints and re-fetch state; delivery is not exactly once.
- A gateway acknowledgement is **not** proof that an end user received an event. Clients must reconcile with REST.
- Outbox auto-increment IDs are **not** commit-order cursors. The snapshot `last_event_id` is only a change hint. The endpoint explicitly sets `resync_required=true`; clients must perform reconciliation rather than assuming a gap-free cursor.
- `GET /ws/messenger/sync` returns up to **500** active conversations and sets `truncated=true` when the cap is reached. Implement paginated snapshots before production for users with larger sets.
- This phase **does not** provide a real Node.js or Workerman gateway implementation, a durable event feed, browser multi-tab code, or a guarantee that every edit/reaction is detected by polling. The client must periodically re-fetch current conversation state, including edits and reactions, not just last sequence.
- Real-time gateways must **not** blindly broadcast hints to everyone in a company. Check current active membership, session revocation, and group membership changes at delivery time. Opaque hints still reveal conversation activity.
- No Redis is required. The outbox remains MariaDB-based.
- Failure to publish must never roll back already committed chat messages. The publisher retries separately.
- Ensure worker leases exceed transport timeouts; investigate long-running callbacks and concurrent lease expiry before production.
- Do not expose the outbox or its `payload_json` directly to browsers.

## Staging tests

1. Insert an outbox event in the same transaction as a message. Publisher sends an invalidation; client fetches the message via REST.
2. Stop the internal signal socket. Event remains failed/pending and retries later without losing the message.
3. Crash after transport acknowledgement. Duplicate event is harmless.
4. Two publishers race to claim the same row; verify locking and lease token behavior.
5. Remove a user from a group; gateway must stop delivering hints to that user.
6. Leave and rejoin; snapshot membership period changes, and old history remains inaccessible.
7. REST polling detects new message sequences; test edits/reactions with periodic full reconciliation.
8. Verify no message bodies, attachment keys, or private content are included in signal payloads.

**Status:** PHP syntax/ZIP validation only. No MariaDB, Node.js, Workerman, or browser integration tests have been run.
