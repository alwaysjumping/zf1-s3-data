# Phase 31 — Node gateway reference and authenticated signal protocol

This cumulative package adds a Node.js reference gateway, PHP signed-loopback signal transport, and ES5 WebSocket browser client. It does **not** implement the Workerman gateway; the same protocol can be ported to Workerman in the next phase.

## Required integration before it can run
1. Install `ws` from an internally approved offline npm cache; no dependencies are bundled. The gateway is Node.js 18+ reference code, **not** PHP 7.4 code.
2. Set `MESSENGER_SIGNAL_SECRET` (32+ chars, shared with PHP signal transport), `MESSENGER_VERIFY_SECRET` (32+ chars, different), `MESSENGER_VERIFY_URL` (e.g. `http://127.0.0.1:8082/internal/verify`), and `MESSENGER_ALLOWED_ORIGIN` (exact expected browser origin). Keep these out of source control.
3. Implement the trusted internal verifier endpoint on loopback. It must validate `X-Internal-Key`, check session/token validity and revocation, return `{ "allowed": true, "user_id": "123" }` only for valid users, and for `authorize` also check server-derived company and **current active membership** of the requested conversation. Default-deny every error. **This endpoint is not included.**
4. Run Node behind your internal TLS reverse proxy; do not expose the raw loopback listener. Ensure the proxy enforces the allowed origin and secure cookies/token handling. Browser token acquisition/refresh must be implemented by the host application.
5. Instantiate PHP `Messenger_Realtime_SignalTransport('127.0.0.1',8091,$secret)` and pass `[$transport,'publish']` to the existing outbox publisher. Start the outbox publisher as a supervised CLI process.
6. Instantiate `new MessengerWsClient({url:'wss://your-host/messenger/ws',token:ephemeralToken,onHint:function(){/* REST sync */},onReady:function(){/* REST reconcile */},onDisconnect:function(){/* polling fallback */}})` from the **top-level shell**. Only the elected tab should own the WebSocket; coordinate notifications to other tabs with the existing tab coordinator. This wiring is **not** done automatically.

## Security and reliability notes
- Do not put access tokens in WebSocket URL query parameters. Prefer short-lived scoped tokens; never expose a reusable session cookie or long-lived refresh token to the browser JS.
- The gateway authenticates at connection and reauthorizes each invalidation at delivery time; verifier failures fail closed.
- Publisher acknowledgements prove only that the gateway received the hint, not browser delivery.
- Reconnect always triggers REST reconciliation; REST polling remains available. No Redis is required.
- Signed TCP hints use HMAC-SHA256, timestamp tolerance and nonce replay checks; keep the signal socket bound to loopback and firewall protected.
- **Reference limitations:** per-client verifier HTTP requests are expensive for large fanout; implement bounded concurrency, backpressure, heartbeat/idle timeout, connection limits, session revocation checks, secure shutdown, monitoring, and robust malformed-message handling before production.
- The verifier's internal HTTP endpoint is loopback-only in this reference. For separate hosts, use mutually authenticated TLS or another authenticated private transport, not this loopback implementation.
- No actual running ZF1/Node integration or Chrome 49/Firefox 52 testing has been performed.

## Tests to run in staging
- Reject missing/expired tokens and wrong WebSocket Origin.
- Reject signal packets with bad HMAC, stale timestamp, duplicate nonce, oversized input.
- Verify a user removed from a group receives no further hints.
- Stop gateway and restart; outbox retries, browser reconnects and REST reconciles.
- Verify no message text, attachment storage keys, or private payloads appear on the socket.
