<?php
/** Adapter must use authoritative company membership, not user-supplied fields. */
interface Messenger_EmployeeDirectory
{
    public function isEligible($companyId, $userId);
}
