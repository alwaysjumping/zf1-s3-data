<?php
/** Implement against authoritative existing company/employee data. Never trust a client company_id. */
interface Messenger_CompanyResolver
{
    public function requireCompanyId($authenticatedUserId);
}
