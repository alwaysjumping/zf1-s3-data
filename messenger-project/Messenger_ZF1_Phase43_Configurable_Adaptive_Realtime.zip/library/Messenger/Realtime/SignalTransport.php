<?php
/** Signed internal TCP invalidation transport; never exposed to browsers. */
class Messenger_Realtime_SignalTransport
{
    private $host; private $port; private $secret;
    public function __construct($host,$port,$secret)
    {
        if (!in_array($host,array('127.0.0.1','::1'),true)) throw new InvalidArgumentException('LOOPBACK_ONLY');
        if ((int)$port<1 || (int)$port>65535 || strlen($secret)<32) throw new InvalidArgumentException('INVALID_SIGNAL_CONFIG');
        $this->host=$host;$this->port=(int)$port;$this->secret=$secret;
    }
    public function publish(array $hint)
    {
        if (!isset($hint['kind'],$hint['event_id'],$hint['company_id'],$hint['conversation_id']) || $hint['kind']!=='messenger.invalidate') throw new InvalidArgumentException('INVALID_HINT');
        $payload=array('kind'=>'messenger.invalidate','event_id'=>(string)$hint['event_id'],
            'company_id'=>(string)$hint['company_id'],'conversation_id'=>(string)$hint['conversation_id'],
            'ts'=>time(),'nonce'=>bin2hex(random_bytes(16)));
        foreach(array('event_id','company_id','conversation_id') as $k)if(!preg_match('/^[1-9][0-9]*$/D',$payload[$k]))throw new InvalidArgumentException('INVALID_HINT_ID');
        $body=json_encode($payload,JSON_UNESCAPED_SLASHES);
        $packet=json_encode(array('body'=>$body,'mac'=>hash_hmac('sha256',$body,$this->secret)))."\n";
        $endpoint=$this->host==='::1'?'tcp://[::1]:'.$this->port:'tcp://127.0.0.1:'.$this->port;
        $socket=@stream_socket_client($endpoint,$errno,$errstr,2,STREAM_CLIENT_CONNECT);
        if (!$socket) return false;
        stream_set_timeout($socket,2);
        $written=0;$size=strlen($packet);
        while($written<$size){$n=@fwrite($socket,substr($packet,$written));if($n===false||$n===0){fclose($socket);return false;}$written+=$n;}
        $ack=fgets($socket,256);fclose($socket);
        if(!is_string($ack))return false;
        $decoded=json_decode($ack,true);
        return is_array($decoded)&&isset($decoded['ack'])&&hash_equals(hash_hmac('sha256',$payload['nonce'],$this->secret),$decoded['ack']);
    }
}
