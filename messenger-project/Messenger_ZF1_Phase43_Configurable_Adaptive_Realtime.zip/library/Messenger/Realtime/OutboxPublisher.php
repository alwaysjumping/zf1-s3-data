<?php
/**
 * At-least-once outbox delivery. PHP 7.4 / Zend_Db.
 * Publish only opaque invalidation hints. Subscribers MUST fetch via authenticated REST.
 */
class Messenger_Realtime_OutboxPublisher
{
    private $db;
    private $transport;
    private $maxAttempts;
    public function __construct(Zend_Db_Adapter_Abstract $db, callable $transport, $maxAttempts = 12)
    {
        $this->db = $db;
        $this->transport = $transport;
        $this->maxAttempts = (int)$maxAttempts;
    }
    public function runOne()
    {
        $this->db->beginTransaction();
        try {
            $now = gmdate('Y-m-d H:i:s');
            $row = $this->db->fetchRow("SELECT id, company_id, conversation_id, event_type, attempts FROM msg_events_outbox WHERE ((status IN ('pending','failed') AND (next_attempt_at IS NULL OR next_attempt_at <= ?)) OR (status='processing' AND locked_until < ?)) AND attempts < ? ORDER BY id LIMIT 1 FOR UPDATE", array($now,$now,$this->maxAttempts));
            if (!$row) { $this->db->commit(); return false; }
            $token = bin2hex(random_bytes(16));
            $lease = gmdate('Y-m-d H:i:s', time()+120);
            $this->db->update('msg_events_outbox',array('status'=>'processing','worker_token'=>$token,'locked_until'=>$lease,'attempts'=>(int)$row['attempts']+1),$this->db->quoteInto('id=?',$row['id']));
            $this->db->commit();
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }

        // Never include message text, member identities, attachment keys or user-generated payload.
        $hint = array('kind'=>'messenger.invalidate','event_id'=>(string)$row['id'],
            'company_id'=>(string)$row['company_id'], 'conversation_id'=>(string)$row['conversation_id']);
        $error = null;
        try {
            $ack = call_user_func($this->transport,$hint);
            if ($ack !== true) throw new RuntimeException('TRANSPORT_NOT_ACKNOWLEDGED');
        } catch (Throwable $e) { $error = substr(preg_replace('/[^A-Za-z0-9_.:-]/','_', $e->getMessage()),0,150); }

        $this->db->beginTransaction();
        try {
            $where=array($this->db->quoteInto('id=?',$row['id']),
                $this->db->quoteInto('worker_token=?',$token),"status='processing'");
            if ($error === null) {
                $this->db->update('msg_events_outbox',array('status'=>'published','published_at'=>gmdate('Y-m-d H:i:s'),'worker_token'=>null,'locked_until'=>null,'last_error'=>null),$where);
            } else {
                $attempt=(int)$row['attempts']+1;
                $delay=min(3600, (int)pow(2,min($attempt,10)));
                $this->db->update('msg_events_outbox',array('status'=>'failed','next_attempt_at'=>gmdate('Y-m-d H:i:s',time()+$delay),'worker_token'=>null,'locked_until'=>null,'last_error'=>$error),$where);
            }
            $this->db->commit();
            return array('id'=>(int)$row['id'],'delivered'=>$error===null);
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
}
