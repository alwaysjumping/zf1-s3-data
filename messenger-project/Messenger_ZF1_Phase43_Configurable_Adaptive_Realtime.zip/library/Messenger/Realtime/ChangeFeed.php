<?php
/**
 * Bounded, authorized outbox invalidation feed.
 * IMPORTANT: Outbox auto-increment IDs are not commit-order cursors.
 * Clients MUST periodically reconcile via /sync even if this feed is empty.
 */
class Messenger_Realtime_ChangeFeed
{
    private $db;
    public function __construct(Zend_Db_Adapter_Abstract $db) { $this->db=$db; }
    public function get($companyId,$userId,$afterId,$limit=100)
    {
        foreach (array($companyId,$userId) as $v)
            if (!is_int($v)||$v<1) throw new InvalidArgumentException('INVALID_IDENTIFIER');
        if (!is_int($afterId)||$afterId<0) throw new InvalidArgumentException('INVALID_CURSOR');
        if (!is_int($limit)||$limit<1||$limit>100) throw new InvalidArgumentException('INVALID_LIMIT');
        // The active membership period controls both conversation access and visibility.
        // No event payload is exposed, since payload schemas differ between event types.
        $sql='SELECT o.id,o.conversation_id,o.event_type,o.entity_id,o.created_at, '.
             'mp.first_visible_sequence,m.sequence_no AS message_sequence '.
             'FROM msg_events_outbox o '.
             'JOIN msg_conversations c ON c.id=o.conversation_id AND c.company_id=? AND c.is_archived=0 '.
             'JOIN msg_participants p ON p.conversation_id=c.id AND p.user_id=? AND p.left_at IS NULL '.
             'JOIN msg_membership_periods mp ON mp.participant_id=p.id AND mp.left_at IS NULL '.
             'LEFT JOIN msg_messages m ON m.id=o.entity_id AND m.conversation_id=c.id '.
             'WHERE o.company_id=? AND o.id>? AND o.created_at>=mp.joined_at '.
             'AND (o.event_type NOT IN (?,?,?,?) OR (m.id IS NOT NULL AND m.sequence_no>=mp.first_visible_sequence)) '.
             
             'ORDER BY o.id ASC LIMIT '.(int)($limit+1);
        $params=array($companyId,$userId,$companyId,$afterId,
            'messenger.message.created','messenger.message.edited','messenger.message.deleted','messenger.reactions.changed');
        // Defense in depth: events created before the latest join must never disclose
        // old reaction/read activity. Message events are bounded by visible sequence.
        $rows=$this->db->fetchAll($sql,$params);
        $hasMore=count($rows)>$limit;
        if ($hasMore) array_pop($rows);
        $events=array();
        foreach ($rows as $row) {
            $events[]=array(
                'id'=>(string)$row['id'],
                'conversation_id'=>(string)$row['conversation_id'],
                'type'=>$row['event_type'],
                'entity_id'=>(string)$row['entity_id']
            );
        }
        return array('events'=>$events,'next_cursor'=>$events?end($events)['id']:(string)$afterId,
            'has_more'=>$hasMore,'requires_periodic_snapshot'=>true);
    }
}
