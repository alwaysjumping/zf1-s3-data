<?php
/** REST polling snapshot: no outbox cursor assumption, no event payload disclosure. */
class Messenger_Realtime_ConversationSnapshot
{
    private $db;
    public function __construct(Zend_Db_Adapter_Abstract $db) { $this->db=$db; }
    public function get($companyId,$userId)
    {
        if ((int)$companyId<=0 || (int)$userId<=0) throw new InvalidArgumentException('INVALID_IDENTITY');
        // Current membership only; leave/rejoin is represented by membership period id.
        // last_event_id is a *hint*, not a durable ordered sync cursor.
        $rows=$this->db->fetchAll("SELECT c.id AS conversation_id,c.last_sequence,p.last_read_sequence,mp.id AS membership_period_id,mp.first_visible_sequence, (SELECT MAX(o.id) FROM msg_events_outbox o WHERE o.conversation_id=c.id AND o.company_id=c.company_id) AS last_event_id FROM msg_conversations c JOIN msg_participants p ON p.conversation_id=c.id JOIN msg_membership_periods mp ON mp.participant_id=p.id WHERE c.company_id=? AND p.user_id=? AND p.left_at IS NULL AND mp.left_at IS NULL ORDER BY c.id LIMIT 500",array((int)$companyId,(int)$userId));
        return array('conversations'=>$rows,'truncated'=>count($rows)===500,'resync_required'=>true);
    }
}
