<?php
/**
 * Opaque gateway credentials. Never put session cookies, JWT access tokens,
 * or user-supplied company identifiers into WebSocket authentication.
 */
class Messenger_GatewayTokenService
{
    private $db;
    public function __construct(Zend_Db_Adapter_Abstract $db) { $this->db=$db; }
    public function issue($userId,$companyId,$ttlSeconds=120)
    {
        if (!is_int($userId)||$userId<1||!is_int($companyId)||$companyId<1)
            throw new InvalidArgumentException('INVALID_IDENTITY');
        $ttl=max(30,min(300,(int)$ttlSeconds));
        $token=bin2hex(random_bytes(32));
        $now=time();
        $this->db->insert('msg_gateway_tokens',array(
            'token_hash'=>hash('sha256',$token),
            'user_id'=>$userId,'company_id'=>$companyId,
            'created_at'=>gmdate('Y-m-d H:i:s',$now),
            'expires_at'=>gmdate('Y-m-d H:i:s',$now+$ttl)));
        return array('token'=>$token,'expires_in'=>$ttl);
    }
    public function verify($token,$action,$companyId=null,$conversationId=null)
    {
        if (!is_string($token)||!preg_match('/^[a-f0-9]{64}$/D',$token)) return array('allowed'=>false);
        if ($action!=='authenticate' && $action!=='authorize') return array('allowed'=>false);
        $row=$this->db->fetchRow(
            'SELECT user_id,company_id FROM msg_gateway_tokens WHERE token_hash=? AND revoked_at IS NULL AND expires_at > UTC_TIMESTAMP() LIMIT 1',
            array(hash('sha256',$token)));
        if (!$row) return array('allowed'=>false);
        if ($action==='authorize') {
            if (!is_string($companyId)||!preg_match('/^[1-9][0-9]*$/D',$companyId)||
                !is_string($conversationId)||!preg_match('/^[1-9][0-9]*$/D',$conversationId)||
                (string)$row['company_id']!==$companyId) return array('allowed'=>false);
            // Only active members in an unarchived conversation may receive hints.
            $exists=$this->db->fetchOne(
                'SELECT 1 FROM msg_conversations c JOIN msg_participants p ON p.conversation_id=c.id '.
                'JOIN msg_membership_periods mp ON mp.participant_id=p.id '.
                'WHERE c.id=? AND c.company_id=? AND c.is_archived=0 AND p.user_id=? '.
                'AND p.left_at IS NULL AND mp.left_at IS NULL LIMIT 1',
                array($conversationId,$companyId,$row['user_id']));
            if (!$exists) return array('allowed'=>false);
        }
        return array('allowed'=>true,'user_id'=>(string)$row['user_id']);
    }
    public function revokeUser($userId)
    {
        if (!is_int($userId)||$userId<1) throw new InvalidArgumentException('INVALID_USER');
        return $this->db->query('UPDATE msg_gateway_tokens SET revoked_at=UTC_TIMESTAMP() WHERE user_id=? AND revoked_at IS NULL',array($userId))->rowCount();
    }
    public function purgeExpired($days=1)
    {
        $days=max(1,min(30,(int)$days));
        return $this->db->query('DELETE FROM msg_gateway_tokens WHERE expires_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL '.$days.' DAY)')->rowCount();
    }
}
