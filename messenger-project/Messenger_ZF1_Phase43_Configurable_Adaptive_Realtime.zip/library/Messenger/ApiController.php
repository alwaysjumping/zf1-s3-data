<?php
/** Shared, fail-closed API controller for the existing ZF1 REST service bootstrap. */
abstract class Messenger_ApiController extends User_Rest_Controller_Abstract
{
    protected function context()
    {
        $userId = (new Messenger_IdentityProvider())->requireUserId();
        if (!Zend_Registry::isRegistered('messenger_company_resolver')) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        $resolver = Zend_Registry::get('messenger_company_resolver');
        if (!($resolver instanceof Messenger_CompanyResolver)) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        $companyId = $resolver->requireCompanyId($userId);
        if (!is_int($companyId) || $companyId < 1) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        return array($companyId, $userId);
    }
    protected function db()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        if (!($db instanceof Zend_Db_Adapter_Abstract)) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        return $db;
    }
    protected function employees()
    {
        if (!Zend_Registry::isRegistered('messenger_employee_directory')) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        $employees = Zend_Registry::get('messenger_employee_directory');
        if (!($employees instanceof Messenger_EmployeeDirectory)) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        return $employees;
    }
    protected function csrf()
    {
        // REST uses the existing Zend_Auth session: enforce a synchronizer token.
        if (!Zend_Registry::isRegistered('messenger_csrf_validator')) {
            throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        }
        $validator = Zend_Registry::get('messenger_csrf_validator');
        if (!is_callable($validator)) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        $token = $this->getRequest()->getHeader('X-CSRF-Token');
        if (!is_string($token) || !$validator($token)) throw new RuntimeException('CSRF_INVALID');
    }
    protected function jsonBody()
    {
        $req = $this->getRequest();
        $type = strtolower(trim(explode(';', (string)$req->getHeader('Content-Type'))[0]));
        if ($type !== 'application/json') throw new InvalidArgumentException('JSON_REQUIRED');
        $raw = $req->getRawBody();
        if (!is_string($raw) || strlen($raw) > 65536) throw new InvalidArgumentException('INVALID_BODY_SIZE');
        $data = json_decode($raw, true);
        if (!is_array($data) || array_values($data) === $data) throw new InvalidArgumentException('INVALID_JSON_OBJECT');
        return $data;
    }
    protected function id($value)
    {
        if (!(is_int($value) || (is_string($value) && ctype_digit($value))) ||
            !ctype_digit((string)$value) || (int)$value < 1 || (string)(int)$value !== (string)$value) {
            throw new InvalidArgumentException('INVALID_IDENTIFIER');
        }
        return (int)$value;
    }
    protected function runApi($callback, $write = false)
    {
        try {
            $context = $this->context();
            if ($write) $this->csrf();
            $data = $callback($context[0], $context[1]);
            Messenger_ApiResponse::write($this->getResponse(), 200, array('success'=>true,'data'=>$data));
        } catch (Exception $e) {
            $code = $e->getMessage();
            $statuses = array(
                'AUTHENTICATION_REQUIRED'=>401, 'CSRF_INVALID'=>403,
                'MESSENGER_NOT_CONFIGURED'=>503, 'GROUP_NOT_FOUND'=>404,
                'CONVERSATION_NOT_FOUND'=>404, 'GROUP_ADMIN_REQUIRED'=>403,
                'OWNER_REQUIRED'=>403, 'EMPLOYEE_NOT_ELIGIBLE'=>403,
                'ALREADY_A_MEMBER'=>409, 'GROUP_MEMBER_LIMIT_REACHED'=>409,
                'INVALID_NEW_OWNER'=>400, 'INVALID_ROLE_TARGET'=>400,
                'SELF_ROLE_CHANGE_DENIED'=>403, 'ATTACHMENT_NOT_READY'=>409,
                'ATTACHMENT_ALREADY_LINKED'=>409, 'CLIENT_MESSAGE_ID_CONFLICT'=>409,
                'ATTACHMENT_NOT_FOUND'=>404, 'UPLOAD_INVALID'=>400,
                'ATTACHMENT_SIZE_INVALID'=>413, 'ATTACHMENT_NAME_INVALID'=>400
            );
            $status = isset($statuses[$code]) ? $statuses[$code] :
                (($e instanceof InvalidArgumentException) ? 400 : 500);
            if ($status === 500) $code = 'INTERNAL_ERROR';
            Messenger_ApiResponse::write($this->getResponse(), $status, array(
                'success'=>false,'error'=>array('code'=>$code)
            ));
        }
    }
}
