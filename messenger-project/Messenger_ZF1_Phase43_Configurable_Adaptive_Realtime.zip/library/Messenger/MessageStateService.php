<?php
/**
 * Message editing, soft deletion, and read cursor updates.
 * PHP 7.4 / ZF1 / MariaDB; server-supplied company/user identity only.
 */
class Messenger_MessageStateService
{
    private $db;
    private $editWindowSeconds;
    public function __construct(Zend_Db_Adapter_Abstract $db, $editWindowSeconds = 900)
    {
        $this->db=$db;
        $this->editWindowSeconds=max(0,(int)$editWindowSeconds);
    }
    private function validId($v)
    {
        if (!is_int($v) || $v<=0) throw new InvalidArgumentException('INVALID_IDENTIFIER');
    }
    private function lockConversation($companyId,$conversationId)
    {
        $c=$this->db->fetchRow('SELECT id,last_sequence FROM msg_conversations WHERE id=? AND company_id=? AND is_archived=0 FOR UPDATE',array($conversationId,$companyId));
        if (!$c) throw new RuntimeException('CONVERSATION_NOT_FOUND');
        return $c;
    }
    private function activePeriod($conversationId,$userId)
    {
        $p=$this->db->fetchRow('SELECT p.id,p.last_read_sequence,mp.first_visible_sequence FROM msg_participants p JOIN msg_membership_periods mp ON mp.participant_id=p.id WHERE p.conversation_id=? AND p.user_id=? AND p.left_at IS NULL AND mp.left_at IS NULL',array($conversationId,$userId));
        if (!$p) throw new RuntimeException('MESSENGER_ACCESS_DENIED');
        return $p;
    }
    private function outbox($companyId,$conversationId,$type,$entityId,$data)
    {
        $json=json_encode($data);
        if ($json===false) throw new RuntimeException('EVENT_ENCODING_FAILED');
        $this->db->insert('msg_events_outbox',array('company_id'=>$companyId,'conversation_id'=>$conversationId,'event_type'=>$type,'entity_id'=>$entityId,'payload_json'=>$json,'status'=>'pending','created_at'=>gmdate('Y-m-d H:i:s')));
    }
    private function changeMessage($companyId,$conversationId,$userId,$messageId,$action,$body=null)
    {
        foreach(array($companyId,$conversationId,$userId,$messageId) as $v)$this->validId($v);
        if ($action==='edit' && (!is_string($body) || trim($body)==='' || mb_strlen($body,'UTF-8')>10000)) throw new InvalidArgumentException('INVALID_MESSAGE_BODY');
        $this->db->beginTransaction();
        try {
            $this->lockConversation($companyId,$conversationId);
            $period=$this->activePeriod($conversationId,$userId);
            $m=$this->db->fetchRow('SELECT id,sequence_no,sender_id,body,created_at,deleted_at,revision_no,type FROM msg_messages WHERE id=? AND conversation_id=? FOR UPDATE',array($messageId,$conversationId));
            if (!$m || (int)$m['sequence_no']<(int)$period['first_visible_sequence']) throw new RuntimeException('MESSAGE_NOT_FOUND');
            if ((int)$m['sender_id']!==$userId) throw new RuntimeException('MESSAGE_AUTHOR_REQUIRED');
            if ($m['type']==='system') throw new RuntimeException('MESSAGE_NOT_EDITABLE');
            if ($action==='delete' && $m['deleted_at']!==null) {
                $this->db->commit(); return array('id'=>$messageId,'deleted'=>true,'already_deleted'=>true);
            }
            if ($m['deleted_at']!==null) throw new RuntimeException('MESSAGE_DELETED');
            $now=gmdate('Y-m-d H:i:s');
            if ($action==='edit') {
                if ($m['type']!=='text') throw new RuntimeException('MESSAGE_NOT_EDITABLE');
                if (time()-strtotime($m['created_at'].' UTC')>$this->editWindowSeconds) throw new RuntimeException('EDIT_WINDOW_EXPIRED');
                if ($m['body']===$body) { $this->db->commit(); return array('id'=>$messageId,'revision_no'=>(int)$m['revision_no'],'unchanged'=>true); }
                $next=(int)$m['revision_no']+1;
                $this->db->insert('msg_message_revisions',array('message_id'=>$messageId,'revision_no'=>$next,'previous_body'=>$m['body'],'edited_by'=>$userId,'created_at'=>$now));
                $this->db->update('msg_messages',array('body'=>$body,'revision_no'=>$next,'edited_at'=>$now),$this->db->quoteInto('id=?',$messageId));
                $this->outbox($companyId,$conversationId,'messenger.message.edited',$messageId,array('message_id'=>$messageId,'sequence_no'=>(int)$m['sequence_no'],'revision_no'=>$next));
                $result=array('id'=>$messageId,'revision_no'=>$next,'edited_at'=>$now);
            } else {
                $this->db->update('msg_messages',array('deleted_at'=>$now,'deleted_by'=>$userId),$this->db->quoteInto('id=?',$messageId));
                $this->outbox($companyId,$conversationId,'messenger.message.deleted',$messageId,array('message_id'=>$messageId,'sequence_no'=>(int)$m['sequence_no']));
                $result=array('id'=>$messageId,'deleted'=>true,'deleted_at'=>$now);
            }
            $this->db->commit();
            return $result;
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
    public function edit($companyId,$conversationId,$userId,$messageId,$body)
    {
        return $this->changeMessage($companyId,$conversationId,$userId,$messageId,'edit',$body);
    }
    public function softDelete($companyId,$conversationId,$userId,$messageId)
    {
        return $this->changeMessage($companyId,$conversationId,$userId,$messageId,'delete');
    }
    public function markRead($companyId,$conversationId,$userId,$sequence)
    {
        foreach(array($companyId,$conversationId,$userId) as $v)$this->validId($v);
        if (!is_int($sequence) || $sequence<0) throw new InvalidArgumentException('INVALID_SEQUENCE');
        $this->db->beginTransaction();
        try {
            $c=$this->lockConversation($companyId,$conversationId);
            $p=$this->activePeriod($conversationId,$userId);
            if ($sequence>(int)$c['last_sequence']) throw new InvalidArgumentException('INVALID_SEQUENCE');
            $floor=(int)$p['first_visible_sequence']-1;
            if ($sequence<$floor) throw new InvalidArgumentException('INVALID_SEQUENCE');
            $prior=(int)$p['last_read_sequence'];
            if ($sequence<=$prior) {
                $this->db->commit();
                return array('conversation_id'=>$conversationId,'last_read_sequence'=>$prior,'unchanged'=>true);
            }
            $this->db->update('msg_participants',array('last_read_sequence'=>$sequence,'last_read_at'=>gmdate('Y-m-d H:i:s')),$this->db->quoteInto('id=?',(int)$p['id']));
            $this->outbox($companyId,$conversationId,'messenger.read.updated',$userId,array('user_id'=>$userId,'last_read_sequence'=>$sequence));
            $this->db->commit();
            return array('conversation_id'=>$conversationId,'last_read_sequence'=>$sequence);
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
}
