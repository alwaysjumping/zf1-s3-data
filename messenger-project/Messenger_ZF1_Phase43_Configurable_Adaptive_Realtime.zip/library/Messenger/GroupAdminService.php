<?php
/** Group role changes. Caller supplies authenticated, server-resolved company/user IDs. */
class Messenger_GroupAdminService
{
    private $db;
    public function __construct(Zend_Db_Adapter_Abstract $db) { $this->db = $db; }
    private function validateIds(array $ids) {
        foreach ($ids as $id) if (!is_int($id) || $id <= 0) throw new InvalidArgumentException('INVALID_IDENTIFIER');
    }
    private function now() { return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s.u'); }
    private function lockGroup($companyId, $conversationId) {
        $row = $this->db->fetchRow("SELECT id FROM msg_conversations WHERE id = ? AND company_id = ? AND type = 'group' AND is_archived = 0 FOR UPDATE", array($conversationId, $companyId));
        if (!$row) throw new RuntimeException('GROUP_NOT_FOUND');
    }
    private function member($conversationId, $userId) {
        return $this->db->fetchRow('SELECT id,role FROM msg_participants WHERE conversation_id = ? AND user_id = ? AND left_at IS NULL FOR UPDATE', array($conversationId,$userId));
    }
    private function emit($companyId,$conversationId,$type,array $payload) {
        $now = $this->now();
        $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($encoded === false) throw new RuntimeException('EVENT_ENCODING_FAILED');
        $this->db->insert('msg_events_outbox', array('company_id'=>$companyId,'conversation_id'=>$conversationId,'event_type'=>$type,'entity_id'=>$conversationId,'payload_json'=>$encoded,'status'=>'pending','created_at'=>$now));
    }
    public function transferOwnership($companyId,$conversationId,$actorId,$newOwnerId) {
        $this->validateIds(array($companyId,$conversationId,$actorId,$newOwnerId));
        if ($actorId === $newOwnerId) throw new InvalidArgumentException('INVALID_NEW_OWNER');
        $this->db->beginTransaction();
        try {
            $this->lockGroup($companyId,$conversationId);
            $actor = $this->member($conversationId,$actorId);
            $target = $this->member($conversationId,$newOwnerId);
            if (!$actor || $actor['role'] !== 'owner') throw new RuntimeException('OWNER_REQUIRED');
            if (!$target) throw new RuntimeException('INVALID_NEW_OWNER');
            $this->db->update('msg_participants',array('role'=>'admin'),$this->db->quoteInto('id = ?',$actor['id']));
            $this->db->update('msg_participants',array('role'=>'owner'),$this->db->quoteInto('id = ?',$target['id']));
            $this->emit($companyId,$conversationId,'messenger.member.role_changed',array('previous_owner_id'=>$actorId,'new_owner_id'=>$newOwnerId));
            $this->db->commit();
            return true;
        } catch (Exception $e) { $this->db->rollBack(); throw $e; }
    }
    public function setAdministrator($companyId,$conversationId,$actorId,$targetUserId,$isAdmin) {
        $this->validateIds(array($companyId,$conversationId,$actorId,$targetUserId));
        if (!is_bool($isAdmin)) throw new InvalidArgumentException('INVALID_ROLE_FLAG');
        if ($actorId === $targetUserId) throw new RuntimeException('SELF_ROLE_CHANGE_DENIED');
        $this->db->beginTransaction();
        try {
            $this->lockGroup($companyId,$conversationId);
            $actor = $this->member($conversationId,$actorId);
            $target = $this->member($conversationId,$targetUserId);
            if (!$actor || $actor['role'] !== 'owner') throw new RuntimeException('OWNER_REQUIRED');
            if (!$target || $target['role'] === 'owner') throw new RuntimeException('INVALID_ROLE_TARGET');
            $role = $isAdmin ? 'admin' : 'member';
            if ($target['role'] !== $role) {
                $this->db->update('msg_participants',array('role'=>$role),$this->db->quoteInto('id = ?',$target['id']));
                $this->emit($companyId,$conversationId,'messenger.member.role_changed',array('user_id'=>$targetUserId,'role'=>$role));
            }
            $this->db->commit(); return true;
        } catch (Exception $e) { $this->db->rollBack(); throw $e; }
    }
    public function renameGroup($companyId,$conversationId,$actorId,$title) {
        $this->validateIds(array($companyId,$conversationId,$actorId));
        if (!is_string($title) || trim($title)==='' || mb_strlen($title,'UTF-8')>255) throw new InvalidArgumentException('INVALID_GROUP_TITLE');
        $this->db->beginTransaction();
        try {
            $this->lockGroup($companyId,$conversationId);
            $actor = $this->member($conversationId,$actorId);
            if (!$actor || !in_array($actor['role'],array('owner','admin'),true)) throw new RuntimeException('GROUP_ADMIN_REQUIRED');
            $this->db->update('msg_conversations',array('title'=>trim($title),'updated_at'=>$this->now()),$this->db->quoteInto('id = ?',$conversationId));
            $this->emit($companyId,$conversationId,'messenger.conversation.updated',array('title_changed'=>true));
            $this->db->commit(); return true;
        } catch (Exception $e) { $this->db->rollBack(); throw $e; }
    }
}
