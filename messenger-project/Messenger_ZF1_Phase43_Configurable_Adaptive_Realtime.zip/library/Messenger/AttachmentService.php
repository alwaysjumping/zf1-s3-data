<?php
/** PHP 7.4, ZF1. Configure an absolute storage directory OUTSIDE the webroot. */
class Messenger_AttachmentService
{
    const MAX_BYTES = 20971520;
    private $db;
    private $root;
    public function __construct(Zend_Db_Adapter_Abstract $db, $storageRoot)
    {
        $root = realpath($storageRoot);
        if (!$root || !is_dir($root) || !is_writable($root) || strpos($root, DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR) !== false) {
            throw new RuntimeException('ATTACHMENT_STORAGE_NOT_CONFIGURED');
        }
        $this->db = $db;
        $this->root = $root;
    }
    private function path($key)
    {
        if (!preg_match('/^[a-f0-9]{64}$/D', $key)) throw new RuntimeException('INVALID_STORAGE_KEY');
        return $this->root . DIRECTORY_SEPARATOR . $key;
    }
    private function assertMember($companyId, $conversationId, $userId)
    {
        $row = $this->db->fetchOne('SELECT p.id FROM msg_conversations c INNER JOIN msg_participants p ON p.conversation_id=c.id INNER JOIN msg_membership_periods mp ON mp.participant_id=p.id WHERE c.id=? AND c.company_id=? AND p.user_id=? AND p.left_at IS NULL AND mp.left_at IS NULL LIMIT 1', array($conversationId,$companyId,$userId));
        if (!$row) throw new RuntimeException('MESSENGER_ACCESS_DENIED');
    }
    public function upload($companyId, $conversationId, $userId, array $file)
    {
        $this->assertMember($companyId,$conversationId,$userId);
        if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK || !isset($file['tmp_name'],$file['size'],$file['name']) || !is_uploaded_file($file['tmp_name'])) throw new InvalidArgumentException('UPLOAD_INVALID');
        $size = (int)$file['size'];
        if ($size < 1 || $size > self::MAX_BYTES || filesize($file['tmp_name']) !== $size) throw new InvalidArgumentException('ATTACHMENT_SIZE_INVALID');
        $name = basename(str_replace('\\','/',(string)$file['name']));
        $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name);
        if ($name === '' || strlen($name) > 255) throw new InvalidArgumentException('ATTACHMENT_NAME_INVALID');
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if (!is_string($mime) || strlen($mime) > 127) throw new InvalidArgumentException('ATTACHMENT_MIME_INVALID');
        $hash = hash_file('sha256',$file['tmp_name']);
        $key = bin2hex(random_bytes(32));
        $dest = $this->path($key);
        if (!move_uploaded_file($file['tmp_name'],$dest)) throw new RuntimeException('ATTACHMENT_STORAGE_FAILED');
        chmod($dest,0600);
        try {
            // Membership may change while bytes are uploaded. Re-check under conversation lock.
            $this->db->beginTransaction();
            $row = $this->db->fetchRow('SELECT id FROM msg_conversations WHERE id=? AND company_id=? FOR UPDATE',array($conversationId,$companyId));
            if (!$row) throw new RuntimeException('CONVERSATION_NOT_FOUND');
            $this->assertMember($companyId,$conversationId,$userId);
            $this->db->insert('msg_attachments',array('company_id'=>$companyId,'conversation_id'=>$conversationId,'uploader_id'=>$userId,'storage_key'=>$key,'original_name'=>$name,'mime_type'=>$mime,'byte_size'=>$size,'sha256'=>$hash,'scan_status'=>'quarantined','created_at'=>gmdate('Y-m-d H:i:s')));
            $id = (int)$this->db->lastInsertId();
            $this->db->commit();
            return array('id'=>$id,'scan_status'=>'quarantined','byte_size'=>$size,'original_name'=>$name);
        } catch (Exception $e) { $this->db->rollBack(); @unlink($dest); throw $e; }
    }
    /** Scanner worker ONLY: invoke after a trusted antivirus scan of the stored bytes. */
    public function recordScanResult($attachmentId, $clean)
    {
        $this->db->beginTransaction();
        try {
            $row = $this->db->fetchRow('SELECT id,storage_key,sha256,scan_status FROM msg_attachments WHERE id=? FOR UPDATE',array($attachmentId));
            if (!$row || $row['scan_status'] !== 'quarantined') throw new RuntimeException('SCAN_STATE_INVALID');
            // Verify bytes were not replaced between upload and scan result.
            $path = $this->path($row['storage_key']);
            $verified = is_file($path) && hash_equals($row['sha256'],hash_file('sha256',$path));
            $this->db->update('msg_attachments',array('scan_status'=>($clean && $verified) ? 'clean':'rejected','scanned_at'=>gmdate('Y-m-d H:i:s')),$this->db->quoteInto('id=?',$attachmentId));
            $this->db->commit();
        } catch (Exception $e) { $this->db->rollBack(); throw $e; }
    }
    public function downloadMetadata($companyId, $attachmentId, $userId)
    {
        $row = $this->db->fetchRow('SELECT a.*,m.sequence_no,m.deleted_at FROM msg_attachments a INNER JOIN msg_message_attachments ma ON ma.attachment_id=a.id INNER JOIN msg_messages m ON m.id=ma.message_id INNER JOIN msg_conversations c ON c.id=a.conversation_id INNER JOIN msg_participants p ON p.conversation_id=c.id INNER JOIN msg_membership_periods mp ON mp.participant_id=p.id WHERE a.id=? AND a.company_id=? AND c.company_id=? AND p.user_id=? AND p.left_at IS NULL AND mp.left_at IS NULL AND a.scan_status=\'clean\' AND m.deleted_at IS NULL AND m.conversation_id=a.conversation_id AND m.sequence_no >= mp.first_visible_sequence LIMIT 1',array($attachmentId,$companyId,$companyId,$userId));
        if (!$row) throw new RuntimeException('ATTACHMENT_NOT_FOUND');
        $path = $this->path($row['storage_key']);
        if (!is_file($path) || !hash_equals($row['sha256'],hash_file('sha256',$path))) throw new RuntimeException('ATTACHMENT_UNAVAILABLE');
        return array('path'=>$path,'mime_type'=>$row['mime_type'],'original_name'=>$row['original_name'],'byte_size'=>(int)$row['byte_size']);
    }
    /** Authorized uploader's clean, unlinked files for this active conversation. */
    public function listReady($companyId, $conversationId, $userId)
    {
        $this->assertMember($companyId,$conversationId,$userId);
        return $this->db->fetchAll(
            "SELECT a.id,a.original_name,a.byte_size,a.created_at FROM msg_attachments a " .
            "LEFT JOIN msg_message_attachments ma ON ma.attachment_id=a.id " .
            "WHERE a.company_id=? AND a.conversation_id=? AND a.uploader_id=? " .
            "AND a.scan_status='clean' AND ma.attachment_id IS NULL " .
            "ORDER BY a.id DESC LIMIT 100",
            array($companyId,$conversationId,$userId)
        );
    }
    /** Authorized links for currently visible, nondeleted messages. */
    public function listMessageFiles($companyId, $conversationId, $userId)
    {
        $this->assertMember($companyId,$conversationId,$userId);
        return $this->db->fetchAll(
            "SELECT a.id,a.original_name,a.byte_size,m.id AS message_id " .
            "FROM msg_attachments a JOIN msg_message_attachments ma ON ma.attachment_id=a.id " .
            "JOIN msg_messages m ON m.id=ma.message_id " .
            "JOIN msg_conversations c ON c.id=m.conversation_id " .
            "JOIN msg_participants p ON p.conversation_id=c.id " .
            "JOIN msg_membership_periods mp ON mp.participant_id=p.id " .
            "WHERE c.id=? AND c.company_id=? AND a.company_id=? AND a.conversation_id=c.id " .
            "AND p.user_id=? AND p.left_at IS NULL AND mp.left_at IS NULL " .
            "AND a.scan_status='clean' AND m.deleted_at IS NULL " .
            "AND m.sequence_no>=mp.first_visible_sequence " .
            "ORDER BY m.sequence_no DESC LIMIT 200",
            array($conversationId,$companyId,$companyId,$userId)
        );
    }
    /** Link only clean uploads owned by the sender, within the same locked conversation. */
    public function sendWithAttachments($companyId, $conversationId, $senderId, $clientMessageId, $body, array $attachmentIds)
    {
        if (!is_int($companyId) || !is_int($conversationId) || !is_int($senderId) || min($companyId,$conversationId,$senderId)<1) throw new InvalidArgumentException('INVALID_IDENTIFIER');
        if (!is_string($clientMessageId) || !preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$clientMessageId)) throw new InvalidArgumentException('INVALID_CLIENT_MESSAGE_ID');
        if (!is_string($body) || mb_strlen($body,'UTF-8')>10000) throw new InvalidArgumentException('INVALID_MESSAGE_BODY');
        if (count($attachmentIds)<1 || count($attachmentIds)>10) throw new InvalidArgumentException('INVALID_ATTACHMENTS');
        $ids=array(); foreach ($attachmentIds as $id) { if (!is_int($id) || $id<1 || isset($ids[$id])) throw new InvalidArgumentException('INVALID_ATTACHMENTS'); $ids[$id]=true; }
        $this->db->beginTransaction();
        try {
            $c=$this->db->fetchRow('SELECT id,last_sequence FROM msg_conversations WHERE id=? AND company_id=? AND is_archived=0 FOR UPDATE',array($conversationId,$companyId));
            if (!$c) throw new RuntimeException('CONVERSATION_NOT_FOUND');
            $this->assertMember($companyId,$conversationId,$senderId);
            $uuid=strtolower($clientMessageId);
            $prior=$this->db->fetchRow('SELECT id,conversation_id,body,type,sequence_no FROM msg_messages WHERE sender_id=? AND client_message_id=?',array($senderId,$uuid));
            if ($prior) {
                $priorIds=$this->db->fetchCol('SELECT attachment_id FROM msg_message_attachments WHERE message_id=? ORDER BY attachment_id',array($prior['id']));
                $requested=array_keys($ids); sort($requested,SORT_NUMERIC); $priorIds=array_map('intval',$priorIds);
                if ((int)$prior['conversation_id']!==$conversationId || $prior['body']!==$body || !in_array($prior['type'],array('file','mixed'),true) || $priorIds!==$requested) throw new RuntimeException('CLIENT_MESSAGE_ID_CONFLICT');
                $this->db->commit(); return array('id'=>(int)$prior['id'],'sequence_no'=>(int)$prior['sequence_no'],'duplicate'=>true);
            }
            foreach (array_keys($ids) as $id) {
                $a=$this->db->fetchRow('SELECT id,scan_status FROM msg_attachments WHERE id=? AND company_id=? AND conversation_id=? AND uploader_id=? FOR UPDATE',array($id,$companyId,$conversationId,$senderId));
                if (!$a || $a['scan_status']!=='clean') throw new RuntimeException('ATTACHMENT_NOT_READY');
                if ($this->db->fetchOne('SELECT attachment_id FROM msg_message_attachments WHERE attachment_id=?',array($id))) throw new RuntimeException('ATTACHMENT_ALREADY_LINKED');
            }
            $now=gmdate('Y-m-d H:i:s'); $seq=(int)$c['last_sequence']+1;
            $this->db->insert('msg_messages',array('conversation_id'=>$conversationId,'sequence_no'=>$seq,'sender_id'=>$senderId,'client_message_id'=>$uuid,'type'=>$body===''?'file':'mixed','body'=>$body,'created_at'=>$now));
            $mid=(int)$this->db->lastInsertId();
            foreach (array_keys($ids) as $id) $this->db->insert('msg_message_attachments',array('message_id'=>$mid,'attachment_id'=>$id));
            $this->db->update('msg_conversations',array('last_sequence'=>$seq,'last_message_id'=>$mid,'last_message_at'=>$now,'updated_at'=>$now),$this->db->quoteInto('id=?',$conversationId));
            $payload=json_encode(array('message_id'=>$mid,'sequence_no'=>$seq)); if ($payload===false) throw new RuntimeException('EVENT_ENCODING_FAILED');
            $this->db->insert('msg_events_outbox',array('company_id'=>$companyId,'conversation_id'=>$conversationId,'event_type'=>'messenger.message.created','entity_id'=>$mid,'payload_json'=>$payload,'status'=>'pending','created_at'=>$now));
            $this->db->commit(); return array('id'=>$mid,'sequence_no'=>$seq,'duplicate'=>false);
        } catch (Exception $e) { $this->db->rollBack(); throw $e; }
    }

}
