<?php
/** Phase 22 maintenance: dry-run by default. Only purge rejected, unlinked files. */
class Messenger_AttachmentMaintenance
{
    private $db; private $root;
    public function __construct(Zend_Db_Adapter_Abstract $db,$root)
    {
        $real=realpath($root);
        if (!$real || !is_dir($real)) throw new RuntimeException('INVALID_STORAGE_ROOT');
        $this->db=$db; $this->root=$real;
    }
    public function reconcile()
    {
        $known=array(); $missing=array(); $corrupt=array();
        $rows=$this->db->fetchAll('SELECT id,storage_key,byte_size,sha256 FROM msg_attachments');
        foreach ($rows as $r) {
            $key=$r['storage_key'];
            if (!preg_match('/^[a-f0-9]{64}$/D',$key)) { $corrupt[]=(int)$r['id']; continue; }
            $known[$key]=true; $p=$this->root.DIRECTORY_SEPARATOR.$key;
            if (!is_file($p) || is_link($p)) { $missing[]=(int)$r['id']; continue; }
            if (filesize($p)!==(int)$r['byte_size'] || !hash_equals($r['sha256'],hash_file('sha256',$p))) $corrupt[]=(int)$r['id'];
        }
        $orphans=array();
        foreach (new DirectoryIterator($this->root) as $f) {
            if (!$f->isFile() || $f->isLink()) continue;
            $key=$f->getFilename();
            if (preg_match('/^[a-f0-9]{64}$/D',$key) && !isset($known[$key])) $orphans[]=$key;
        }
        return array('missing_ids'=>$missing,'corrupt_ids'=>$corrupt,'orphan_storage_keys'=>$orphans);
    }
    public function rejectedCandidates($olderThanDays=30)
    {
        $days=max(1,(int)$olderThanDays);
        $cutoff=gmdate('Y-m-d H:i:s',time()-86400*$days);
        return $this->db->fetchAll("SELECT a.id,a.storage_key FROM msg_attachments a LEFT JOIN msg_message_attachments ma ON ma.attachment_id=a.id WHERE a.scan_status='rejected' AND a.created_at < ? AND ma.attachment_id IS NULL ORDER BY a.id",array($cutoff));
    }
    public function purgeRejected($olderThanDays=30,$execute=false)
    {
        $candidates=$this->rejectedCandidates($olderThanDays);
        if (!$execute) return array('dry_run'=>true,'candidate_ids'=>array_map(function($r){return (int)$r['id'];},$candidates));
        $deleted=array(); $failed=array();
        foreach ($candidates as $candidate) {
            $id=(int)$candidate['id']; $key=$candidate['storage_key'];
            if (!preg_match('/^[a-f0-9]{64}$/D',$key)) { $failed[]=$id; continue; }
            $this->db->beginTransaction();
            try {
                $row=$this->db->fetchRow("SELECT id,storage_key FROM msg_attachments WHERE id=? AND scan_status='rejected' FOR UPDATE",array($id));
                if (!$row || $row['storage_key']!==$key ||
                    $this->db->fetchOne('SELECT attachment_id FROM msg_message_attachments WHERE attachment_id=?',array($id))) {
                    $this->db->rollBack(); continue;
                }
                $p=$this->root.DIRECTORY_SEPARATOR.$key;
                // Delete bytes first; if DB deletion fails reconciliation will report missing bytes.
                if (is_link($p) || (file_exists($p) && (!is_file($p) || !unlink($p)))) throw new RuntimeException('UNLINK_FAILED');
                $this->db->delete('msg_attachments',$this->db->quoteInto('id=?',$id));
                $this->db->commit(); $deleted[]=$id;
            } catch (Throwable $e) {
                $this->db->rollBack(); $failed[]=$id;
                error_log('Attachment cleanup failed for ID '.$id.': '.$e->getMessage());
            }
        }
        return array('dry_run'=>false,'deleted_ids'=>$deleted,'failed_ids'=>$failed);
    }
}
