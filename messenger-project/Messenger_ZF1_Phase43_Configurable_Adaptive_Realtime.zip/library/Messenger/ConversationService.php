<?php
/** Conversation creation for PHP 7.4 / Zend_Db. */
class Messenger_ConversationService
{
    private $db;
    private $employees;

    public function __construct(Zend_Db_Adapter_Abstract $db, Messenger_EmployeeDirectory $employees)
    {
        $this->db = $db;
        $this->employees = $employees;
    }

    private function assertId($value)
    {
        if (!is_int($value) || $value < 1) {
            throw new InvalidArgumentException('INVALID_IDENTIFIER');
        }
    }

    private function assertEmployee($companyId, $userId)
    {
        if (!$this->employees->isEligible($companyId, $userId)) {
            throw new RuntimeException('EMPLOYEE_NOT_ELIGIBLE');
        }
    }

    private function utcNow()
    {
        return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s.u');
    }

    private function insertParticipant($conversationId, $userId, $role, $now)
    {
        $this->db->insert('msg_participants', array(
            'conversation_id' => $conversationId, 'user_id' => $userId,
            'role' => $role, 'joined_at' => $now, 'last_read_sequence' => 0
        ));
        $participantId = (int) $this->db->lastInsertId();
        $this->db->insert('msg_membership_periods', array(
            'participant_id' => $participantId, 'joined_at' => $now,
            'first_visible_sequence' => 1
        ));
    }

    public function createPrivate($companyId, $creatorId, $recipientId)
    {
        foreach (array($companyId, $creatorId, $recipientId) as $id) {
            $this->assertId($id);
        }
        if ($creatorId === $recipientId) {
            throw new InvalidArgumentException('SELF_CONVERSATION_NOT_ALLOWED');
        }
        $this->assertEmployee($companyId, $creatorId);
        $this->assertEmployee($companyId, $recipientId);
        $low = min($creatorId, $recipientId);
        $high = max($creatorId, $recipientId);

        $this->db->beginTransaction();
        try {
            $existing = $this->db->fetchOne(
                'SELECT conversation_id FROM msg_private_pairs WHERE company_id = ? AND user_low = ? AND user_high = ?',
                array($companyId, $low, $high)
            );
            if ($existing !== false && $existing !== null) {
                // Existing participants may have been deactivated by company policy.
                $this->db->commit();
                return (int) $existing;
            }
            $now = $this->utcNow();
            $this->db->insert('msg_conversations', array(
                'company_id' => $companyId, 'type' => 'private', 'created_by' => $creatorId,
                'last_sequence' => 0, 'created_at' => $now, 'updated_at' => $now
            ));
            $conversationId = (int) $this->db->lastInsertId();
            $this->db->insert('msg_private_pairs', array(
                'conversation_id' => $conversationId, 'company_id' => $companyId,
                'user_low' => $low, 'user_high' => $high
            ));
            $this->insertParticipant($conversationId, $creatorId, 'member', $now);
            $this->insertParticipant($conversationId, $recipientId, 'member', $now);
            $this->db->commit();
            return $conversationId;
        } catch (Exception $e) {
            $this->db->rollBack();
            // A concurrent create may win the unique pair constraint.
            // Only recover from a verified MariaDB duplicate-key exception (1062).
            if ($e instanceof Zend_Db_Statement_Exception &&
                preg_match('/(?:SQLSTATE\[23000\].*1062|Duplicate entry)/i', $e->getMessage())) {
                $existing = $this->db->fetchOne(
                    'SELECT conversation_id FROM msg_private_pairs WHERE company_id = ? AND user_low = ? AND user_high = ?',
                    array($companyId, $low, $high)
                );
                if ($existing !== false && $existing !== null) {
                    return (int) $existing;
                }
            }
            throw $e;
        }
    }

    public function createGroup($companyId, $creatorId, $title, array $userIds)
    {
        $this->assertId($companyId);
        $this->assertId($creatorId);
        if (!is_string($title) || trim($title) === '' || mb_strlen($title, 'UTF-8') > 255) {
            throw new InvalidArgumentException('INVALID_GROUP_TITLE');
        }
        $members = array($creatorId => $creatorId);
        foreach ($userIds as $userId) {
            $this->assertId($userId);
            $members[$userId] = $userId;
        }
        if (count($members) > 100) {
            throw new RuntimeException('GROUP_MEMBER_LIMIT_REACHED');
        }
        foreach ($members as $userId) {
            $this->assertEmployee($companyId, $userId);
        }
        $this->db->beginTransaction();
        try {
            $now = $this->utcNow();
            $this->db->insert('msg_conversations', array(
                'company_id' => $companyId, 'type' => 'group', 'title' => trim($title),
                'created_by' => $creatorId, 'last_sequence' => 0,
                'created_at' => $now, 'updated_at' => $now
            ));
            $conversationId = (int) $this->db->lastInsertId();
            foreach ($members as $userId) {
                $this->insertParticipant($conversationId, $userId,
                    $userId === $creatorId ? 'owner' : 'member', $now);
            }
            $this->db->insert('msg_events_outbox', array(
                'company_id' => $companyId, 'conversation_id' => $conversationId,
                'event_type' => 'messenger.conversation.created', 'entity_id' => $conversationId,
                'payload_json' => '{}', 'status' => 'pending', 'created_at' => $now
            ));
            $this->db->commit();
            return $conversationId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
