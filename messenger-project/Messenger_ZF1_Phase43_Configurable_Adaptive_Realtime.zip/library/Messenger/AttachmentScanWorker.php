<?php
/**
 * Phase 22 trusted CLI worker, PHP 7.4.
 * Bootstrap your application's Zend autoloader and DB before constructing this class.
 * Scanner command must be a locally installed, trusted ClamAV clamscan executable.
 */
class Messenger_AttachmentScanWorker
{
    private $db;
    private $root;
    private $scanner;
    private $leaseSeconds;
    public function __construct(Zend_Db_Adapter_Abstract $db, $root, $scanner = '/usr/bin/clamscan', $leaseSeconds = 900)
    {
        $real = realpath($root);
        if (!$real || !is_dir($real) || !is_writable($real)) throw new RuntimeException('INVALID_STORAGE_ROOT');
        if (!is_file($scanner) || !is_executable($scanner)) throw new RuntimeException('SCANNER_NOT_AVAILABLE');
        $this->db=$db; $this->root=$real; $this->scanner=$scanner;
        $this->leaseSeconds=max(60,(int)$leaseSeconds);
    }
    private function filePath($key)
    {
        if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D',$key)) throw new RuntimeException('INVALID_STORAGE_KEY');
        return $this->root.DIRECTORY_SEPARATOR.$key;
    }
    private function claim()
    {
        $this->db->beginTransaction();
        try {
            // Claim one row at a time; do not hold a DB transaction while scanning.
            $row=$this->db->fetchRow("SELECT id,storage_key,sha256,byte_size FROM msg_attachments WHERE scan_status='quarantined' ORDER BY id LIMIT 1 FOR UPDATE");
            if (!$row) { $this->db->commit(); return null; }
            $token=bin2hex(random_bytes(16));
            $this->db->update('msg_attachments',array('scan_status'=>'scanning','scan_token'=>$token,'scan_claimed_at'=>gmdate('Y-m-d H:i:s')),$this->db->quoteInto('id=?',$row['id']));
            $this->db->commit();
            $row['scan_token']=$token;
            return $row;
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
    private function scan($path)
    {
        // PHP 7.4 array command avoids shell interpretation of paths.
        $descriptors=array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w'));
        $pipes=array();
        $process=proc_open(array($this->scanner,'--no-summary','--',$path),$descriptors,$pipes,null,null,array('bypass_shell'=>true));
        if (!is_resource($process)) throw new RuntimeException('SCANNER_START_FAILED');
        fclose($pipes[0]);
        // Small scanner output expected; avoid unbounded memory.
        stream_set_blocking($pipes[1],false);
        stream_set_blocking($pipes[2],false);
        $start=time(); $timedOut=false;
        while (true) {
            $status=proc_get_status($process);
            if (!$status['running']) break;
            if (time()-$start>300) { $timedOut=true; proc_terminate($process); break; }
            usleep(100000);
        }
        $stdout=stream_get_contents($pipes[1],8192);
        $stderr=stream_get_contents($pipes[2],8192);
        fclose($pipes[1]); fclose($pipes[2]);
        $exit=proc_close($process);
        if ($timedOut) throw new RuntimeException('SCANNER_TIMEOUT');
        // Some PHP proc_open implementations return -1 after proc_get_status().
        if ($exit===-1 && isset($status['exitcode'])) $exit=$status['exitcode'];
        if ($exit===0) return 'clean';
        if ($exit===1) return 'rejected';
        throw new RuntimeException('SCANNER_ERROR: '.substr(trim((string)$stderr),0,100));
    }
    public function runOne()
    {
        $row=$this->claim();
        if (!$row) return false;
        $result='quarantined';
        try {
            $path=$this->filePath($row['storage_key']);
            if (!is_file($path) || is_link($path) || filesize($path)!==(int)$row['byte_size']) {
                $result='rejected';
            } else {
                $before=hash_file('sha256',$path);
                if (!hash_equals($row['sha256'],$before)) $result='rejected';
                else {
                    $result=$this->scan($path);
                    clearstatcache(true,$path);
                    if (!is_file($path) || is_link($path) || filesize($path)!==(int)$row['byte_size'] ||
                        !hash_equals($row['sha256'],hash_file('sha256',$path))) $result='rejected';
                }
            }
        } catch (Throwable $e) {
            // Scanner outage must not accidentally mark an unscanned file clean.
            error_log('Messenger attachment scan failed for ID '.$row['id'].': '.$e->getMessage());
            $result='quarantined';
        }
        $this->db->beginTransaction();
        try {
            $updated=$this->db->update('msg_attachments',array(
                'scan_status'=>$result,
                'scan_token'=>null,
                'scan_claimed_at'=>null,
                'scanned_at'=>$result==='quarantined'?null:gmdate('Y-m-d H:i:s')
            ),array($this->db->quoteInto('id=?',$row['id']),
                    $this->db->quoteInto('scan_status=?','scanning'),
                    $this->db->quoteInto('scan_token=?',$row['scan_token'])));
            $this->db->commit();
            return array('id'=>(int)$row['id'],'status'=>$result,'updated'=>$updated===1);
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
    public function releaseExpiredLeases()
    {
        // Expired scan leases are requeued. Worker must run on trusted host.
        $cutoff=gmdate('Y-m-d H:i:s',time()-$this->leaseSeconds);
        return $this->db->query("UPDATE msg_attachments SET scan_status='quarantined',scan_token=NULL,scan_claimed_at=NULL WHERE scan_status='scanning' AND scan_claimed_at < ?",array($cutoff))->rowCount();
    }
}
