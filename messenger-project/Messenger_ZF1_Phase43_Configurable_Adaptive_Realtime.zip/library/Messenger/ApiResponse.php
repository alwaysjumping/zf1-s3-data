<?php
class Messenger_ApiResponse
{
    public static function write(Zend_Controller_Response_Abstract $response, $status, array $body)
    {
        $response->setHttpResponseCode($status);
        $response->setHeader('Content-Type', 'application/json; charset=utf-8', true);
        $response->setHeader('Cache-Control', 'no-store', true);
        $response->setBody(json_encode($body, JSON_UNESCAPED_UNICODE));
    }
}
