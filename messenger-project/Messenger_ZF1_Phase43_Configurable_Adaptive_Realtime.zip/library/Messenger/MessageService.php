<?php
/**
 * Transactional text messaging for PHP 7.4 / ZF1.
 * The caller MUST provide authenticated company/user IDs from trusted server-side adapters.
 */
class Messenger_MessageService
{
    /** @var Zend_Db_Adapter_Abstract */
    private $db;

    public function __construct(Zend_Db_Adapter_Abstract $db)
    {
        $this->db = $db;
    }

    /** Retry only known transient MariaDB transaction failures. */
    private function isTransient($e)
    {
        $message = $e->getMessage();
        return preg_match('/(?:SQLSTATE\[(?:40001|HY000)\].*(?:1213|1205)|\b(?:Deadlock found|Lock wait timeout exceeded)\b)/i', $message) === 1;
    }

    /** Retry a concurrent duplicate only after rechecking the committed row. */
    private function isDuplicate($e)
    {
        return preg_match('/(?:SQLSTATE\[23000\].*1062|Duplicate entry)/i', $e->getMessage()) === 1;
    }

    public function sendText($companyId, $conversationId, $senderId, $clientMessageId, $body)
    {
        foreach (array($companyId, $conversationId, $senderId) as $id) {
            if (!is_int($id) || $id <= 0) {
                throw new InvalidArgumentException('INVALID_IDENTIFIER');
            }
        }
        if (!is_string($clientMessageId) || !preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i', $clientMessageId)) {
            throw new InvalidArgumentException('INVALID_CLIENT_MESSAGE_ID');
        }
        if (!is_string($body) || trim($body) === '' || mb_strlen($body, 'UTF-8') > 10000) {
            throw new InvalidArgumentException('INVALID_MESSAGE_BODY');
        }
        // Do not trim persisted body: retries must compare the same exact request.
        $clientMessageId = strtolower($clientMessageId);
        for ($attempt = 0; $attempt < 3; ++$attempt) {
        $this->db->beginTransaction();
        try {
            // All send/add/remove/role-change operations lock this row first.
            $conversation = $this->db->fetchRow(
                'SELECT id, last_sequence FROM msg_conversations WHERE id = ? AND company_id = ? AND is_archived = 0 FOR UPDATE',
                array($conversationId, $companyId)
            );
            if (!$conversation) {
                throw new RuntimeException('CONVERSATION_NOT_FOUND');
            }
            $membership = $this->db->fetchRow(
                'SELECT p.id, mp.first_visible_sequence FROM msg_participants p '
                . 'INNER JOIN msg_membership_periods mp ON mp.participant_id = p.id '
                . 'WHERE p.conversation_id = ? AND p.user_id = ? AND p.left_at IS NULL AND mp.left_at IS NULL',
                array($conversationId, $senderId)
            );
            if (!$membership) {
                throw new RuntimeException('MESSENGER_ACCESS_DENIED');
            }
            $prior = $this->db->fetchRow(
                'SELECT id, conversation_id, sequence_no, body, type, created_at FROM msg_messages '
                . 'WHERE sender_id = ? AND client_message_id = ?',
                array($senderId, strtolower($clientMessageId))
            );
            if ($prior) {
                if ((int) $prior['conversation_id'] !== $conversationId || $prior['type'] !== 'text' || $prior['body'] !== $body) {
                    throw new RuntimeException('CLIENT_MESSAGE_ID_CONFLICT');
                }
                $this->db->commit();
                return $prior;
            }
            $sequence = (int) $conversation['last_sequence'] + 1;
            $now = gmdate('Y-m-d H:i:s');
            $this->db->insert('msg_messages', array(
                'conversation_id' => $conversationId,
                'sequence_no' => $sequence,
                'sender_id' => $senderId,
                'client_message_id' => strtolower($clientMessageId),
                'type' => 'text',
                'body' => $body,
                'created_at' => $now
            ));
            $messageId = (int) $this->db->lastInsertId();
            $this->db->update('msg_conversations', array(
                'last_sequence' => $sequence,
                'last_message_id' => $messageId,
                'last_message_at' => $now,
                'updated_at' => $now
            ), $this->db->quoteInto('id = ?', $conversationId));
            $payload = json_encode(array('message_id' => $messageId, 'sequence_no' => $sequence));
            if ($payload === false) {
                throw new RuntimeException('EVENT_ENCODING_FAILED');
            }
            // Mandatory: outbox failure must roll back the message and sequence.
            $this->db->insert('msg_events_outbox', array(
                'company_id' => $companyId,
                'conversation_id' => $conversationId,
                'event_type' => 'messenger.message.created',
                'entity_id' => $messageId,
                'payload_json' => $payload,
                'status' => 'pending',
                'created_at' => $now
            ));
            $this->db->commit();
            return array('id' => $messageId, 'conversation_id' => $conversationId,
                'sequence_no' => $sequence, 'body' => $body, 'type' => 'text', 'created_at' => $now);
        } catch (Exception $e) {
            $this->db->rollBack();
            // After rollback, the winner's committed row may now be visible.
            // Never reinterpret a different payload or conversation as success.
            if ($this->isDuplicate($e)) {
                $prior = $this->db->fetchRow(
                    'SELECT id, conversation_id, sequence_no, body, type, created_at FROM msg_messages '
                    . 'WHERE sender_id = ? AND client_message_id = ?',
                    array($senderId, $clientMessageId)
                );
                if ($prior) {
                    if ((int)$prior['conversation_id'] !== $conversationId ||
                        $prior['type'] !== 'text' || $prior['body'] !== $body) {
                        throw new RuntimeException('CLIENT_MESSAGE_ID_CONFLICT');
                    }
                    // Revalidate membership and company before returning an existing message.
                    $allowed = $this->db->fetchOne(
                        'SELECT 1 FROM msg_conversations c JOIN msg_participants p ON p.conversation_id=c.id '
                        . 'JOIN msg_membership_periods mp ON mp.participant_id=p.id '
                        . 'WHERE c.id=? AND c.company_id=? AND c.is_archived=0 AND p.user_id=? '
                        . 'AND p.left_at IS NULL AND mp.left_at IS NULL LIMIT 1',
                        array($conversationId, $companyId, $senderId)
                    );
                    if (!$allowed) throw new RuntimeException('MESSENGER_ACCESS_DENIED');
                    return $prior;
                }
            }
            if (!$this->isTransient($e) || $attempt === 2) throw $e;
            // Bounded jitter reduces lock contention. No retry of unknown SQL errors.
            usleep(random_int(10000, 30000) * ($attempt + 1));
        }
        }
        throw new RuntimeException('SEND_RETRY_EXHAUSTED');
    }

    public function getHistory($companyId, $conversationId, $userId, $beforeSequence = null, $limit = 50, $afterSequence = null)
    {
        foreach (array($companyId, $conversationId, $userId) as $id) {
            if (!is_int($id) || $id <= 0) {
                throw new InvalidArgumentException('INVALID_IDENTIFIER');
            }
        }
        $limit = max(1, min(100, (int) $limit));
        if ($afterSequence !== null && (!is_int($afterSequence) || $afterSequence < 0)) {
            throw new InvalidArgumentException('INVALID_SEQUENCE');
        }
        if ($afterSequence !== null && $beforeSequence !== null) {
            throw new InvalidArgumentException('CONFLICTING_CURSORS');
        }
        if ($beforeSequence !== null && (!is_int($beforeSequence) || $beforeSequence <= 0)) {
            throw new InvalidArgumentException('INVALID_SEQUENCE');
        }
        $sql = 'SELECT m.id, m.conversation_id, m.sequence_no, m.sender_id, m.type, '
             . 'CASE WHEN m.deleted_at IS NULL THEN m.body ELSE NULL END AS body, '
             . 'm.created_at, m.edited_at, m.deleted_at '
             . 'FROM msg_conversations c '
             . 'INNER JOIN msg_participants p ON p.conversation_id = c.id '
             . 'INNER JOIN msg_membership_periods mp ON mp.participant_id = p.id '
             . 'INNER JOIN msg_messages m ON m.conversation_id = c.id '
             . 'WHERE c.id = ? AND c.company_id = ? AND p.user_id = ? '
             . 'AND p.left_at IS NULL AND mp.left_at IS NULL '
             . 'AND m.sequence_no >= mp.first_visible_sequence';
        $params = array($conversationId, $companyId, $userId);
        if ($beforeSequence !== null) {
            $sql .= ' AND m.sequence_no < ?';
            $params[] = $beforeSequence;
        }
        if ($afterSequence !== null) {
            $sql .= ' AND m.sequence_no > ?';
            $params[] = $afterSequence;
        }
        $sql .= ' ORDER BY m.sequence_no ' . ($afterSequence !== null ? 'ASC' : 'DESC') . ' LIMIT ' . $limit;
        return $this->db->fetchAll($sql, $params);
    }
}
