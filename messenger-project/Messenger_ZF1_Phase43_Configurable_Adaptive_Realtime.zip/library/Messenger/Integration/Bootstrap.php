<?php
/** Register only after the host application supplies authoritative lookup callbacks. */
class Messenger_Integration_Bootstrap
{
    public static function register($companyLookup,$employeeLookup,$attachmentDirectory)
    {
        if (!is_string($attachmentDirectory) || $attachmentDirectory==='' || !is_dir($attachmentDirectory)
            || !is_writable($attachmentDirectory) || !realpath($attachmentDirectory)) {
            throw new RuntimeException('MESSENGER_ATTACHMENT_DIRECTORY_INVALID');
        }
        $dir=realpath($attachmentDirectory);
        $root=isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
        if ($root && ($dir===$root || strpos($dir,$root.DIRECTORY_SEPARATOR)===0)) {
            throw new RuntimeException('MESSENGER_ATTACHMENT_DIRECTORY_IN_WEBROOT');
        }
        Zend_Registry::set('messenger_company_resolver',new Messenger_Integration_CompanyResolver($companyLookup));
        Zend_Registry::set('messenger_employee_directory',new Messenger_Integration_EmployeeDirectory($employeeLookup));
        Zend_Registry::set('messenger_csrf_token_provider',array('Messenger_Integration_Csrf','issue'));
        Zend_Registry::set('messenger_csrf_validator',array('Messenger_Integration_Csrf','verify'));
        Zend_Registry::set('messenger_attachment_storage',$dir);
    }
}
