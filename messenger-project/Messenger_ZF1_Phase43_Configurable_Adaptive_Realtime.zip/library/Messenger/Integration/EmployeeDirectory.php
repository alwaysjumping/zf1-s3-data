<?php
/** Site adapter: lookup must check active employee AND same-company authorization. */
class Messenger_Integration_EmployeeDirectory implements Messenger_EmployeeDirectory
{
    private $lookup;
    public function __construct($lookup) { if (!is_callable($lookup)) throw new InvalidArgumentException('EMPLOYEE_LOOKUP_REQUIRED'); $this->lookup=$lookup; }
    public function isEligible($companyId,$userId)
    {
        if (!is_int($companyId)||$companyId<1||!is_int($userId)||$userId<1) return false;
        return call_user_func($this->lookup,$companyId,$userId) === true;
    }
}
