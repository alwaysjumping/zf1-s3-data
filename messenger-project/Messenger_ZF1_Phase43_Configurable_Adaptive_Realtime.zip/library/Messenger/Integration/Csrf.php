<?php
/** Session-scoped synchronizer token. Requires Zend_Session_Namespace and HTTPS. */
class Messenger_Integration_Csrf
{
    const SESSION_NAME='messenger_csrf_v1';
    public static function issue()
    {
        $ns=new Zend_Session_Namespace(self::SESSION_NAME);
        if (!isset($ns->token) || !is_string($ns->token) || !preg_match('/^[a-f0-9]{64}$/D',$ns->token)) {
            $ns->token=bin2hex(random_bytes(32));
        }
        return $ns->token;
    }
    public static function verify($candidate)
    {
        if (!is_string($candidate) || !preg_match('/^[a-f0-9]{64}$/D',$candidate)) return false;
        $ns=new Zend_Session_Namespace(self::SESSION_NAME);
        return isset($ns->token) && is_string($ns->token) && hash_equals($ns->token,$candidate);
    }
    public static function rotate()
    {
        $ns=new Zend_Session_Namespace(self::SESSION_NAME);
        $ns->token=bin2hex(random_bytes(32));
    }
}
