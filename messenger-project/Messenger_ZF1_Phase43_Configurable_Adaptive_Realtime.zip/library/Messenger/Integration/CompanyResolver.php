<?php
/** Site adapter: callback must query trusted company membership, never request fields. */
class Messenger_Integration_CompanyResolver implements Messenger_CompanyResolver
{
    private $lookup;
    public function __construct($lookup) { if (!is_callable($lookup)) throw new InvalidArgumentException('COMPANY_LOOKUP_REQUIRED'); $this->lookup=$lookup; }
    public function requireCompanyId($authenticatedUserId)
    {
        $id=call_user_func($this->lookup,$authenticatedUserId);
        if (!(is_int($id) && $id>0)) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        return $id;
    }
}
