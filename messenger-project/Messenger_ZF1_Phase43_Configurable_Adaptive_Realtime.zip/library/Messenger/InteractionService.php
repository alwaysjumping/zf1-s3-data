<?php
/** Reaction and ephemeral typing state; no Redis required. PHP 7.4. */
class Messenger_InteractionService
{
    private $db;
    private $allowed = array('👍','❤️','😂','😮','😢','👏','🎉','👎');
    public function __construct(Zend_Db_Adapter_Abstract $db) { $this->db=$db; }
    private function ids($companyId,$conversationId,$userId)
    {
        foreach (array($companyId,$conversationId,$userId) as $v)
            if (!is_int($v) || $v<1) throw new InvalidArgumentException('INVALID_IDENTIFIER');
    }
    private function member($companyId,$conversationId,$userId,$lock=false)
    {
        $c=$this->db->fetchRow('SELECT id FROM msg_conversations WHERE id=? AND company_id=? AND is_archived=0'.($lock?' FOR UPDATE':''),array($conversationId,$companyId));
        if (!$c) throw new RuntimeException('CONVERSATION_NOT_FOUND');
        $p=$this->db->fetchRow('SELECT mp.first_visible_sequence FROM msg_participants p JOIN msg_membership_periods mp ON mp.participant_id=p.id WHERE p.conversation_id=? AND p.user_id=? AND p.left_at IS NULL AND mp.left_at IS NULL',array($conversationId,$userId));
        if (!$p) throw new RuntimeException('MESSENGER_ACCESS_DENIED');
        return (int)$p['first_visible_sequence'];
    }
    private function message($conversationId,$messageId,$floor)
    {
        $m=$this->db->fetchRow('SELECT id,sequence_no FROM msg_messages WHERE id=? AND conversation_id=? AND deleted_at IS NULL',array($messageId,$conversationId));
        if (!$m || (int)$m['sequence_no']<$floor) throw new RuntimeException('MESSAGE_NOT_FOUND');
    }
    public function setReaction($companyId,$conversationId,$userId,$messageId,$emoji,$active)
    {
        $this->ids($companyId,$conversationId,$userId);
        if (!is_int($messageId)||$messageId<1) throw new InvalidArgumentException('INVALID_IDENTIFIER');
        if (!is_string($emoji)||!in_array($emoji,$this->allowed,true)) throw new InvalidArgumentException('INVALID_EMOJI');
        if (!is_bool($active)) throw new InvalidArgumentException('INVALID_REACTION_STATE');
        $this->db->beginTransaction();
        try {
            $floor=$this->member($companyId,$conversationId,$userId,true);
            $this->message($conversationId,$messageId,$floor);
            if ($active) {
                // Duplicate submissions are idempotent under the unique key.
                $this->db->query('INSERT IGNORE INTO msg_reactions (message_id,user_id,emoji,created_at) VALUES (?,?,?,?)',array($messageId,$userId,$emoji,gmdate('Y-m-d H:i:s')));
            } else {
                $this->db->delete('msg_reactions',array($this->db->quoteInto('message_id=?',$messageId),$this->db->quoteInto('user_id=?',$userId),$this->db->quoteInto('emoji=?',$emoji)));
            }
            // Lightweight event; publisher and clients should fetch current state.
            $payload=json_encode(array('message_id'=>$messageId));
            $this->db->insert('msg_events_outbox',array('company_id'=>$companyId,'conversation_id'=>$conversationId,'event_type'=>'messenger.reactions.changed','entity_id'=>$messageId,'payload_json'=>$payload,'status'=>'pending','created_at'=>gmdate('Y-m-d H:i:s')));
            $this->db->commit();
            return array('message_id'=>$messageId,'emoji'=>$emoji,'active'=>$active);
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
    public function listReactions($companyId,$conversationId,$userId,$messageId)
    {
        $this->ids($companyId,$conversationId,$userId);
        if (!is_int($messageId)||$messageId<1) throw new InvalidArgumentException('INVALID_IDENTIFIER');
        $floor=$this->member($companyId,$conversationId,$userId);
        $this->message($conversationId,$messageId,$floor);
        return $this->db->fetchAll('SELECT emoji,COUNT(*) AS total FROM msg_reactions WHERE message_id=? GROUP BY emoji ORDER BY total DESC,emoji',array($messageId));
    }
    /**
     * Aggregate reactions for a bounded visible message page in one query.
     * No message bodies or identities are returned.
     */
    public function listReactionsBatch($companyId,$conversationId,$userId,$messageIds)
    {
        $this->ids($companyId,$conversationId,$userId);
        if (!is_array($messageIds) || count($messageIds)>100) throw new InvalidArgumentException('INVALID_BATCH');
        $floor=$this->member($companyId,$conversationId,$userId);
        $ids=array();
        foreach ($messageIds as $id) {
            if (!is_int($id) || $id<1) throw new InvalidArgumentException('INVALID_IDENTIFIER');
            $ids[$id]=$id;
        }
        if (!$ids) return array();
        $placeholders=implode(',',array_fill(0,count($ids),'?'));
        $params=array_merge(array($conversationId,$floor),array_values($ids));
        $sql='SELECT r.message_id,r.emoji,COUNT(*) AS total FROM msg_reactions r '.
             'INNER JOIN msg_messages m ON m.id=r.message_id '.
             'WHERE m.conversation_id=? AND m.sequence_no>=? AND m.deleted_at IS NULL '.
             'AND m.id IN ('.$placeholders.') GROUP BY r.message_id,r.emoji '.
             'ORDER BY r.message_id,r.emoji';
        $rows=$this->db->fetchAll($sql,$params);
        $result=array();
        foreach ($rows as $row) {
            $key=(string)$row['message_id'];
            if (!isset($result[$key])) $result[$key]=array();
            $result[$key][]=array('emoji'=>$row['emoji'],'total'=>(int)$row['total']);
        }
        return $result;
    }
    public function typing($companyId,$conversationId,$userId,$active)
    {
        $this->ids($companyId,$conversationId,$userId);
        if (!is_bool($active)) throw new InvalidArgumentException('INVALID_TYPING_STATE');
        $this->db->beginTransaction();
        try {
            $this->member($companyId,$conversationId,$userId,true);
            if ($active) {
                $expires=gmdate('Y-m-d H:i:s',time()+8);
                $this->db->query('INSERT INTO msg_typing_state(conversation_id,user_id,expires_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE expires_at=VALUES(expires_at)',array($conversationId,$userId,$expires));
            } else {
                $this->db->delete('msg_typing_state',array($this->db->quoteInto('conversation_id=?',$conversationId),$this->db->quoteInto('user_id=?',$userId)));
            }
            $this->db->commit();
            return array('conversation_id'=>$conversationId,'active'=>$active,'ttl_seconds'=>$active?8:0);
        } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
    }
    public function listTyping($companyId,$conversationId,$userId)
    {
        $this->ids($companyId,$conversationId,$userId);
        $this->member($companyId,$conversationId,$userId);
        return $this->db->fetchAll('SELECT user_id FROM msg_typing_state WHERE conversation_id=? AND user_id<>? AND expires_at>UTC_TIMESTAMP() ORDER BY user_id',array($conversationId,$userId));
    }
    public function purgeExpiredTyping()
    {
        return $this->db->query('DELETE FROM msg_typing_state WHERE expires_at<=UTC_TIMESTAMP()')->rowCount();
    }
}
