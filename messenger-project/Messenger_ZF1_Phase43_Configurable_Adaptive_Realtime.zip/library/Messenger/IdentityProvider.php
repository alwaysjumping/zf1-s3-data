<?php
/** Session identity guard; company resolution intentionally delegated. */
class Messenger_IdentityProvider
{
    public function requireUserId()
    {
        $auth = Zend_Auth::getInstance();
        if (!$auth->hasIdentity()) {
            throw new RuntimeException('AUTHENTICATION_REQUIRED');
        }
        $identity = $auth->getIdentity();
        if (!is_object($identity) || !isset($identity->user_key) ||
            !ctype_digit((string) $identity->user_key) ||
            (int) $identity->user_key <= 0) {
            throw new RuntimeException('AUTHENTICATION_REQUIRED');
        }
        return (int) $identity->user_key;
    }
}
