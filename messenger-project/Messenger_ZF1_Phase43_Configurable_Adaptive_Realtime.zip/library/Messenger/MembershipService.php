<?php
/** Group membership mutations. Lock order: conversation row, then participant rows. */
class Messenger_MembershipService
{
    private $db;
    private $employees;

    public function __construct(Zend_Db_Adapter_Abstract $db, Messenger_EmployeeDirectory $employees)
    {
        $this->db = $db;
        $this->employees = $employees;
    }

    private function validateIds(array $ids)
    {
        foreach ($ids as $id) {
            if (!is_int($id) || $id < 1) {
                throw new InvalidArgumentException('INVALID_IDENTIFIER');
            }
        }
    }

    private function now()
    {
        return (new DateTimeImmutable('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s.u');
    }

    private function lockGroup($companyId, $conversationId)
    {
        $row = $this->db->fetchRow(
            "SELECT id,last_sequence FROM msg_conversations WHERE id = ? AND company_id = ? AND type = 'group' AND is_archived = 0 FOR UPDATE",
            array($conversationId, $companyId)
        );
        if (!$row) {
            throw new RuntimeException('GROUP_NOT_FOUND');
        }
        return $row;
    }

    private function activeMember($conversationId, $userId)
    {
        return $this->db->fetchRow(
            'SELECT id,role FROM msg_participants WHERE conversation_id = ? AND user_id = ? AND left_at IS NULL',
            array($conversationId, $userId)
        );
    }

    private function assertManager($conversationId, $actorId)
    {
        $actor = $this->activeMember($conversationId, $actorId);
        if (!$actor || !in_array($actor['role'], array('owner', 'admin'), true)) {
            throw new RuntimeException('GROUP_ADMIN_REQUIRED');
        }
        return $actor;
    }

    private function outbox($companyId, $conversationId, $type, $targetUserId, $now)
    {
        $payload = json_encode(array('user_id' => $targetUserId));
        if ($payload === false) {
            throw new RuntimeException('EVENT_ENCODING_FAILED');
        }
        $this->db->insert('msg_events_outbox', array(
            'company_id' => $companyId, 'conversation_id' => $conversationId,
            'event_type' => $type, 'entity_id' => $targetUserId,
            'payload_json' => $payload, 'status' => 'pending', 'created_at' => $now
        ));
    }

    public function addMember($companyId, $conversationId, $actorId, $newUserId)
    {
        $this->validateIds(array($companyId, $conversationId, $actorId, $newUserId));
        $this->db->beginTransaction();
        try {
            $conversation = $this->lockGroup($companyId, $conversationId);
            $this->assertManager($conversationId, $actorId);
            if (!$this->employees->isEligible($companyId, $newUserId)) {
                throw new RuntimeException('EMPLOYEE_NOT_ELIGIBLE');
            }
            $participant = $this->db->fetchRow(
                'SELECT id,left_at FROM msg_participants WHERE conversation_id = ? AND user_id = ? FOR UPDATE',
                array($conversationId, $newUserId)
            );
            if ($participant && $participant['left_at'] === null) {
                throw new RuntimeException('ALREADY_A_MEMBER');
            }
            $count = (int) $this->db->fetchOne(
                'SELECT COUNT(*) FROM msg_participants WHERE conversation_id = ? AND left_at IS NULL',
                array($conversationId)
            );
            if ($count >= 100) {
                throw new RuntimeException('GROUP_MEMBER_LIMIT_REACHED');
            }
            $now = $this->now();
            $boundary = (int) $conversation['last_sequence'] + 1;
            if ($participant) {
                $participantId = (int) $participant['id'];
                $this->db->update('msg_participants', array(
                    'role' => 'member', 'joined_at' => $now, 'left_at' => null,
                    'last_read_sequence' => (int) $conversation['last_sequence'],
                    'last_read_at' => null
                ), $this->db->quoteInto('id = ?', $participantId));
            } else {
                $this->db->insert('msg_participants', array(
                    'conversation_id' => $conversationId, 'user_id' => $newUserId,
                    'role' => 'member', 'joined_at' => $now,
                    'last_read_sequence' => (int) $conversation['last_sequence']
                ));
                $participantId = (int) $this->db->lastInsertId();
            }
            $this->db->insert('msg_membership_periods', array(
                'participant_id' => $participantId, 'joined_at' => $now,
                'first_visible_sequence' => $boundary
            ));
            $this->outbox($companyId, $conversationId, 'messenger.member.added', $newUserId, $now);
            $this->db->commit();
            return $participantId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    public function removeMember($companyId, $conversationId, $actorId, $targetUserId)
    {
        $this->validateIds(array($companyId, $conversationId, $actorId, $targetUserId));
        $this->db->beginTransaction();
        try {
            $conversation = $this->lockGroup($companyId, $conversationId);
            $actor = $this->activeMember($conversationId, $actorId);
            if (!$actor) {
                throw new RuntimeException('MESSENGER_ACCESS_DENIED');
            }
            if ($actorId !== $targetUserId &&
                !in_array($actor['role'], array('owner', 'admin'), true)) {
                throw new RuntimeException('GROUP_ADMIN_REQUIRED');
            }
            $target = $this->db->fetchRow(
                'SELECT id,role FROM msg_participants WHERE conversation_id = ? AND user_id = ? AND left_at IS NULL FOR UPDATE',
                array($conversationId, $targetUserId)
            );
            if (!$target) {
                throw new RuntimeException('MEMBER_NOT_FOUND');
            }
            if ($target['role'] === 'owner') {
                throw new RuntimeException('TRANSFER_OWNERSHIP_FIRST');
            }
            if ($actorId !== $targetUserId && $target['role'] === 'admin' && $actor['role'] !== 'owner') {
                throw new RuntimeException('OWNER_PERMISSION_REQUIRED');
            }
            $now = $this->now();
            $closed = $this->db->update('msg_membership_periods', array(
                'left_at' => $now,
                'last_visible_sequence' => (int) $conversation['last_sequence']
            ), array(
                $this->db->quoteInto('participant_id = ?', $target['id']),
                'left_at IS NULL'
            ));
            if ((int) $closed !== 1) {
                throw new RuntimeException('INVALID_MEMBERSHIP_PERIOD_STATE');
            }
            $this->db->update('msg_participants', array('left_at' => $now),
                $this->db->quoteInto('id = ?', $target['id']));
            $this->outbox($companyId, $conversationId, 'messenger.member.removed', $targetUserId, $now);
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
