<?php
/**
 * Rest Route
 */
class User_Rest_Route extends Zend_Controller_Router_Route_Module
{
    /**
     * @var Zend_Controller_Front
     */
    protected $_front;

    /**
     * @var string
     */
    protected $_uriPrefix;

    /**
     * @var string
     */
    protected $_uriMatch;

    /**
     * Constructor
     *
     * @param Zend_Controller_Front $front Front Controller object
     */
    public function __construct(Zend_Controller_Front $front, $defaults = array())
    {
        $this->_defaults = $defaults;
        $this->_front = $front;
        $this->_dispatcher = $front->getDispatcher();

        if (Zend_Registry::isRegistered('config')) {
            $config = Zend_Registry::get('config');

            $this->_uriPrefix = $config->uriPrefix;
            $this->_uriMatch = sprintf('|^/%s/|', $this->_uriPrefix, '|');
        } else {
            throw new Zend_Exception("Can't read the application config from Zend_Registry");
        }
    }

    public function match($request, $partial = FALSE)
    {
        $path = parse_url($request->getRequestUri(), PHP_URL_PATH);
        $path = '/' . trim((string)$path, '/');
        $prefix = trim((string)$this->_uriPrefix, '/');
        $root = '/' . $prefix . '/messenger';
        $method = strtoupper($request->getMethod());
        if (preg_match('#^' . preg_quote($root, '#') . '/(conversations|messages|members|groups|attachments|message-state|interactions|sync|changes|gateway-token)$#', $path, $m)) {
            $controller = $m[1];
        } elseif ($path === $root . '/info') {
            $controller = 'info';
        } elseif ($path === $root || strpos($path, $root . '/') === 0) {
            $controller = 'unsupported';
        } else {
            $controller = null;
        }
        if ($controller !== null) {
            $action = $controller === 'unsupported' ? 'index' :
                ($method === 'POST' ? 'post' : ($method === 'GET' ? 'get' :
                ($method === 'DELETE' ? 'delete' : 'index')));
            $result = array('module'=>'messenger','controller'=>$controller,'action'=>$action);
            $controllerDir = $this->_front->getModuleDirectory('messenger')
                . DIRECTORY_SEPARATOR . $this->_front->getModuleControllerDirectoryName();
            $this->_front->addControllerDirectory($controllerDir,'messenger');
            return $result;
        }
        // Original host application's non-Messenger fallback is preserved.
        $result = array(
            'module'     => 'draft',
            'controller' => 'info',
            'action'     => 'put',
            'user_key'   => 6,
            'id'         => 'api'
        );

        $controllerDir = $this->_front->getModuleDirectory($result[$this->_moduleKey])
            . DIRECTORY_SEPARATOR
            . $this->_front->getModuleControllerDirectoryName();

        $this->_front->addControllerDirectory(
            $controllerDir,
            $result[$this->_moduleKey]
        );

        return $result;
    }
}