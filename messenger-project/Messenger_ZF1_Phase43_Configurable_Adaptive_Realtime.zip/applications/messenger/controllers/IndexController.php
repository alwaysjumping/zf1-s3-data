<?php
/** Basic full-page Messenger view; host application must register CSRF provider. */
class Messenger_IndexController extends User_Controller_Action
{
    public function indexAction()
    {
        if (!Zend_Auth::getInstance()->hasIdentity()) {
            $this->_redirect('/');
            return;
        }
        if (!Zend_Registry::isRegistered('messenger_csrf_token_provider')) {
            throw new RuntimeException('MESSENGER_CSRF_PROVIDER_NOT_CONFIGURED');
        }
        $provider=Zend_Registry::get('messenger_csrf_token_provider');
        if (!is_callable($provider)) throw new RuntimeException('MESSENGER_CSRF_PROVIDER_NOT_CONFIGURED');
        $this->view->messengerCsrfToken=(string)call_user_func($provider);
        $userId=(new Messenger_IdentityProvider())->requireUserId();
        $this->view->messengerUserId=$userId;
        if (!Zend_Registry::isRegistered('messenger_company_resolver')) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        $resolver=Zend_Registry::get('messenger_company_resolver');
        if (!($resolver instanceof Messenger_CompanyResolver)) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        $companyId=$resolver->requireCompanyId($userId);
        if (!is_int($companyId) || $companyId<1) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        $this->view->messengerTabScope='company:'.$companyId.':user:'.$userId;
        // Read ZF1 application.ini settings; default safely to polling.
        $bootstrap = Zend_Controller_Front::getInstance()->getParam('bootstrap');
        $options = $bootstrap ? $bootstrap->getOptions() : array();
        $rt = isset($options['messenger']['realtime']) && is_array($options['messenger']['realtime'])
            ? $options['messenger']['realtime'] : array();
        $mode = isset($rt['mode']) ? strtolower((string)$rt['mode']) : 'polling';
        $this->view->messengerRealtimeMode = $mode === 'workerman' ? 'workerman' : 'polling';
        $this->view->messengerWsUrl = isset($rt['wsUrl']) ? (string)$rt['wsUrl'] : '';
        $this->view->messengerActivePollMs = isset($rt['activePollMs']) ? max(2000,(int)$rt['activePollMs']) : 5000;
        $this->view->messengerIdlePollMs = isset($rt['idlePollMs']) ? max(5000,(int)$rt['idlePollMs']) : 30000;
        $this->view->messengerHiddenPollMs = isset($rt['hiddenPollMs']) ? max(10000,(int)$rt['hiddenPollMs']) : 60000;
    }
}
