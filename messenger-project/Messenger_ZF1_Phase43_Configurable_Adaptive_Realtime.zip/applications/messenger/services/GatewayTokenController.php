<?php
/**
 * POST /ws/messenger/gateway-token
 * Session authenticated + CSRF protected. The company resolver must be configured.
 */
class Messenger_GatewayTokenController extends Messenger_ApiController
{
    public function deleteAction()
    {
        $this->runApi(function($companyId,$userId) {
            return array('revoked_count'=>(new Messenger_GatewayTokenService($this->db()))->revokeUser($userId));
        },true);
    }
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            return (new Messenger_GatewayTokenService($this->db()))->issue($userId,$companyId);
        },true);
    }
}
