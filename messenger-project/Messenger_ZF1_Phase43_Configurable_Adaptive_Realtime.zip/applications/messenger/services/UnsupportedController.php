<?php
/** Deny unsupported Messenger routes instead of falling through to the draft module. */
class Messenger_UnsupportedController extends User_Rest_Controller_Abstract
{
    public function indexAction() { $this->deny(); }
    public function getAction() { $this->deny(); }
    public function postAction() { $this->deny(); }
    public function putAction() { $this->deny(); }
    public function deleteAction() { $this->deny(); }
    private function deny() {
        Messenger_ApiResponse::write($this->getResponse(),404,array('success'=>false,'error'=>array('code'=>'ENDPOINT_NOT_IMPLEMENTED','message'=>'Endpoint not available.')));
    }
}
