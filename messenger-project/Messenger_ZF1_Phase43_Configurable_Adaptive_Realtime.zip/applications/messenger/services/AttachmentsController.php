<?php
/** POST multipart /ws/messenger/attachments ; GET ?attachment_id=123 */
class Messenger_AttachmentsController extends Messenger_ApiController
{
    private function storage()
    {
        if (!Zend_Registry::isRegistered('messenger_attachment_storage')) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
        return new Messenger_AttachmentService($this->db(),Zend_Registry::get('messenger_attachment_storage'));
    }
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            $conversationId=$this->id($this->getRequest()->getPost('conversation_id'));
            if (!isset($_FILES['file']) || !is_array($_FILES['file'])) throw new InvalidArgumentException('UPLOAD_INVALID');
            return $this->storage()->upload($companyId,$conversationId,$userId,$_FILES['file']);
        },true);
    }
    public function getAction()
    {
        try {
            list($companyId,$userId)=$this->context();
            $listMode=$this->getRequest()->getQuery('list');
            if ($listMode==='ready' || $listMode==='message-files') {
                $conversationId=$this->id($this->getRequest()->getQuery('conversation_id'));
                $files=$listMode==='ready'
                    ? $this->storage()->listReady($companyId,$conversationId,$userId)
                    : $this->storage()->listMessageFiles($companyId,$conversationId,$userId);
                Messenger_ApiResponse::write($this->getResponse(),200,array('success'=>true,'data'=>$files));
                return;
            }
            $id=$this->id($this->getRequest()->getQuery('attachment_id'));
            $meta=$this->storage()->downloadMetadata($companyId,$id,$userId);
            // Avoid exposing any absolute server path in the response.
            $response=$this->getResponse();
            $response->clearBody(); $response->setHttpResponseCode(200);
            $response->setHeader('Content-Type','application/octet-stream',true);
            $response->setHeader('X-Content-Type-Options','nosniff',true);
            $response->setHeader('Cache-Control','private, no-store',true);
            $response->setHeader('Content-Security-Policy','sandbox',true);
            $response->setHeader('Content-Length',(string)$meta['byte_size'],true);
            $safeName=preg_replace('/[^A-Za-z0-9._-]/','_',basename($meta['original_name']));
            if ($safeName==='' || $safeName==='.' || $safeName==='..') $safeName='attachment';
            $response->setHeader('Content-Disposition','attachment; filename="'.$safeName.'"',true);
            // ZF1 response body buffering is avoided for large files. Ensure no output
            // buffers / compression and disable layouts in the service bootstrap.
            $response->sendHeaders();
            $fp=fopen($meta['path'],'rb');
            if ($fp===false) throw new RuntimeException('ATTACHMENT_UNAVAILABLE');
            while (!feof($fp)) { $chunk=fread($fp,65536); if ($chunk===false) break; echo $chunk; }
            fclose($fp); exit;
        } catch (Exception $e) {
            $code=$e->getMessage(); $status=$code==='AUTHENTICATION_REQUIRED'?401:($code==='MESSENGER_NOT_CONFIGURED'?503:404);
            Messenger_ApiResponse::write($this->getResponse(),$status,array('success'=>false,'error'=>array('code'=>$status===404?'ATTACHMENT_NOT_FOUND':$code)));
        }
    }
}
