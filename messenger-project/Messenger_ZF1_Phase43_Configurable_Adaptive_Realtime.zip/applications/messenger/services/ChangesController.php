<?php
/** GET /ws/messenger/changes?after_id=0&limit=100 */
class Messenger_ChangesController extends Messenger_ApiController
{
    public function getAction()
    {
        $this->runApi(function($companyId,$userId) {
            $q=$this->getRequest();
            $raw=$q->getQuery('after_id','0');
            $lim=$q->getQuery('limit','100');
            if (!is_string($raw) || !preg_match('/^(0|[1-9][0-9]*)$/D',$raw) ||
                strlen($raw)>18 || !is_string($lim) || !preg_match('/^[1-9][0-9]*$/D',$lim))
                throw new InvalidArgumentException('INVALID_CURSOR');
            return (new Messenger_Realtime_ChangeFeed($this->db()))->get(
                $companyId,$userId,(int)$raw,min(100,(int)$lim));
        });
    }
}
