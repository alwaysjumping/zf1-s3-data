<?php
/** POST /ws/messenger/groups {operation,conversation_id,...}. */
class Messenger_GroupsController extends Messenger_ApiController
{
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            $body=$this->jsonBody();
            $id=$this->id(isset($body['conversation_id'])?$body['conversation_id']:null);
            $service=new Messenger_GroupAdminService($this->db());
            $op=isset($body['operation'])?$body['operation']:null;
            if ($op==='rename') {
                if (!isset($body['title']) || !is_string($body['title'])) throw new InvalidArgumentException('INVALID_GROUP_TITLE');
                $result=$service->renameGroup($companyId,$id,$userId,$body['title']);
            } elseif ($op==='transfer_owner') {
                $result=$service->transferOwnership($companyId,$id,$userId,$this->id(isset($body['target_user_id'])?$body['target_user_id']:null));
            } elseif ($op==='set_admin') {
                if (!isset($body['is_admin']) || !is_bool($body['is_admin'])) throw new InvalidArgumentException('INVALID_ROLE_FLAG');
                $result=$service->setAdministrator($companyId,$id,$userId,$this->id(isset($body['target_user_id'])?$body['target_user_id']:null),$body['is_admin']);
            } else throw new InvalidArgumentException('INVALID_OPERATION');
            return array('result'=>$result);
        },true);
    }
}
