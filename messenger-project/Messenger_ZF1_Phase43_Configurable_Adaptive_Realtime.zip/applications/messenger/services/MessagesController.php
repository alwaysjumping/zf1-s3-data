<?php
/** POST /ws/messenger/messages; GET /ws/messenger/messages?conversation_id=... */
class Messenger_MessagesController extends Messenger_ApiController
{
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            $body=$this->jsonBody();
            foreach (array('conversation_id','client_message_id','body') as $key)
                if (!array_key_exists($key,$body)) throw new InvalidArgumentException('MISSING_FIELD');
            if (!is_string($body['client_message_id']) || !is_string($body['body']))
                throw new InvalidArgumentException('INVALID_MESSAGE');
            if (isset($body['attachment_ids']) && is_array($body['attachment_ids']) && count($body['attachment_ids'])>0) {
                $ids=array(); foreach ($body['attachment_ids'] as $v) $ids[]=$this->id($v);
                if (!Zend_Registry::isRegistered('messenger_attachment_storage')) throw new RuntimeException('MESSENGER_NOT_CONFIGURED');
                return (new Messenger_AttachmentService($this->db(),Zend_Registry::get('messenger_attachment_storage')))->sendWithAttachments($companyId,$this->id($body['conversation_id']),$userId,$body['client_message_id'],$body['body'],$ids);
            }
            return (new Messenger_MessageService($this->db()))->sendText(
                $companyId,$this->id($body['conversation_id']),$userId,$body['client_message_id'],$body['body']);
        },true);
    }
    public function getAction()
    {
        $this->runApi(function($companyId,$userId) {
            $req=$this->getRequest();
            $id=$this->id($req->getQuery('conversation_id'));
            $before=$req->getQuery('before_sequence');
            $before=($before === null || $before === '') ? null : $this->id($before);
            $after=$req->getQuery('after_sequence');
            if ($after !== null && $after !== '' && (!ctype_digit((string)$after) || strlen((string)$after)>18))
                throw new InvalidArgumentException('INVALID_SEQUENCE');
            $after=($after === null || $after === '') ? null : (int)$after;
            $limit=$req->getQuery('limit',50);
            if (!ctype_digit((string)$limit) || (int)$limit < 1 || (int)$limit > 50)
                throw new InvalidArgumentException('INVALID_LIMIT');
            return (new Messenger_MessageService($this->db()))->getHistory($companyId,$id,$userId,$before,(int)$limit,$after);
        });
    }
}
