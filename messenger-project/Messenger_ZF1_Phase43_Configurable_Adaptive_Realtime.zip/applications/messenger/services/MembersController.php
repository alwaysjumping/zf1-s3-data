<?php
/** POST /ws/messenger/members {operation,conversation_id,target_user_id}. */
class Messenger_MembersController extends Messenger_ApiController
{
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            $body=$this->jsonBody();
            $id=$this->id(isset($body['conversation_id'])?$body['conversation_id']:null);
            $target=$this->id(isset($body['target_user_id'])?$body['target_user_id']:null);
            $service=new Messenger_MembershipService($this->db(),$this->employees());
            if (isset($body['operation']) && $body['operation']==='add')
                $result=$service->addMember($companyId,$id,$userId,$target);
            elseif (isset($body['operation']) && $body['operation']==='remove')
                $result=$service->removeMember($companyId,$id,$userId,$target);
            else throw new InvalidArgumentException('INVALID_OPERATION');
            return array('result'=>$result);
        },true);
    }
}
