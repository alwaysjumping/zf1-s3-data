<?php
/** Integration smoke-test endpoint only; no business data exposed. */
class Messenger_InfoController extends User_Rest_Controller_Abstract
{
    public function getAction()
    {
        try {
            (new Messenger_IdentityProvider())->requireUserId();
            Messenger_ApiResponse::write($this->getResponse(), 200, array(
                'success' => true,
                'data' => array('authenticated' => true)
            ));
        } catch (RuntimeException $e) {
            Messenger_ApiResponse::write($this->getResponse(), 401, array(
                'success' => false,
                'error' => array('code' => 'AUTHENTICATION_REQUIRED', 'message' => 'Login required.')
            ));
        }
    }
}
