<?php
/** POST /ws/messenger/conversations (JSON {type,recipient_id} or {type,title,user_ids}). */
class Messenger_ConversationsController extends Messenger_ApiController
{
    public function postAction()
    {
        $this->runApi(function ($companyId,$userId) {
            $body = $this->jsonBody();
            $service = new Messenger_ConversationService($this->db(),$this->employees());
            if (isset($body['type']) && $body['type'] === 'private') {
                if (!isset($body['recipient_id'])) throw new InvalidArgumentException('RECIPIENT_REQUIRED');
                $id = $service->createPrivate($companyId,$userId,$this->id($body['recipient_id']));
            } elseif (isset($body['type']) && $body['type'] === 'group') {
                if (!isset($body['title']) || !is_string($body['title']) || !isset($body['user_ids']) || !is_array($body['user_ids']))
                    throw new InvalidArgumentException('INVALID_GROUP_REQUEST');
                $ids = array();
                foreach ($body['user_ids'] as $value) $ids[] = $this->id($value);
                $id = $service->createGroup($companyId,$userId,$body['title'],$ids);
            } else throw new InvalidArgumentException('INVALID_CONVERSATION_TYPE');
            return array('conversation_id'=>$id);
        }, true);
    }
}
