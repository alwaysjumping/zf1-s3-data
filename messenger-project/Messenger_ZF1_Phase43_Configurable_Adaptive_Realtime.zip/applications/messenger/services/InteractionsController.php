<?php
/** GET/POST /ws/messenger/interactions; authenticated session, CSRF on POST. */
class Messenger_InteractionsController extends Messenger_ApiController
{
    public function getAction()
    {
        $this->runApi(function($companyId,$userId) {
            $q=$this->getRequest();
            $conversationId=$this->id($q->getQuery('conversation_id'));
            $svc=new Messenger_InteractionService($this->db());
            if ($q->getQuery('type')==='reactions-batch') {
                $raw=$q->getQuery('message_ids');
                if (!is_string($raw) || strlen($raw)>2100 || !preg_match('/^[0-9]+(?:,[0-9]+)*$/D',$raw))
                    throw new InvalidArgumentException('INVALID_BATCH');
                $parts=explode(',',$raw);
                if (count($parts)>100) throw new InvalidArgumentException('INVALID_BATCH');
                $ids=array();
                foreach ($parts as $part) $ids[]=$this->id($part);
                return $svc->listReactionsBatch($companyId,$conversationId,$userId,$ids);
            }
            if ($q->getQuery('type')==='reactions') return $svc->listReactions($companyId,$conversationId,$userId,$this->id($q->getQuery('message_id')));
            if ($q->getQuery('type')==='typing') return $svc->listTyping($companyId,$conversationId,$userId);
            throw new InvalidArgumentException('INVALID_OPERATION');
        });
    }
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            $data=$this->jsonBody();
            $conversationId=$this->id(isset($data['conversation_id'])?$data['conversation_id']:null);
            $svc=new Messenger_InteractionService($this->db());
            $type=isset($data['type'])?$data['type']:null;
            if ($type==='reaction') {
                if (!array_key_exists('active',$data)||!is_bool($data['active'])) throw new InvalidArgumentException('INVALID_REACTION_STATE');
                return $svc->setReaction($companyId,$conversationId,$userId,$this->id(isset($data['message_id'])?$data['message_id']:null),isset($data['emoji'])?$data['emoji']:null,$data['active']);
            }
            if ($type==='typing') {
                if (!array_key_exists('active',$data)||!is_bool($data['active'])) throw new InvalidArgumentException('INVALID_TYPING_STATE');
                return $svc->typing($companyId,$conversationId,$userId,$data['active']);
            }
            throw new InvalidArgumentException('INVALID_OPERATION');
        },true);
    }
}
