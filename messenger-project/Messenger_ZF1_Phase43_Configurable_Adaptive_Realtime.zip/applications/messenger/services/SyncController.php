<?php
/** GET /ws/messenger/sync - authenticated current-membership snapshot. */
class Messenger_SyncController extends Messenger_ApiController
{
    public function getAction()
    {
        $this->runApi(function($companyId,$userId) {
            $service = new Messenger_Realtime_ConversationSnapshot($this->db());
            return $service->get($companyId,$userId);
        });
    }
}
