<?php
/** POST /ws/messenger/message-state, JSON {operation:edit|delete|read,...}. */
class Messenger_MessageStateController extends Messenger_ApiController
{
    public function postAction()
    {
        $this->runApi(function($companyId,$userId) {
            $data=$this->jsonBody();
            if (!isset($data['operation']) || !is_string($data['operation'])) throw new InvalidArgumentException('INVALID_OPERATION');
            $conversationId=$this->id(isset($data['conversation_id'])?$data['conversation_id']:null);
            $svc=new Messenger_MessageStateService($this->db());
            switch ($data['operation']) {
                case 'edit':
                    $messageId=$this->id(isset($data['message_id'])?$data['message_id']:null);
                    if (!isset($data['body']) || !is_string($data['body'])) throw new InvalidArgumentException('INVALID_MESSAGE_BODY');
                    return $svc->edit($companyId,$conversationId,$userId,$messageId,$data['body']);
                case 'delete':
                    return $svc->softDelete($companyId,$conversationId,$userId,$this->id(isset($data['message_id'])?$data['message_id']:null));
                case 'read':
                    $v=isset($data['sequence_no'])?$data['sequence_no']:null;
                    if ($v===0 || $v==='0') $seq=0;
                    else $seq=$this->id($v);
                    return $svc->markRead($companyId,$conversationId,$userId,$seq);
                default:
                    throw new InvalidArgumentException('INVALID_OPERATION');
            }
        },true);
    }
}
