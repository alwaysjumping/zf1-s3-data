<?php
/**
 * Workerman reference gateway, PHP 7.4. Run only as a trusted CLI service.
 * Composer autoloader for Workerman is required but not bundled.
 */
require __DIR__ . '/vendor/autoload.php';
use Workerman\Worker;
use Workerman\Connection\TcpConnection;
use Workerman\Protocols\Http\Request;
use Workerman\Timer;

$wsPort = (int)(getenv('MESSENGER_WS_PORT') ?: 8081);
$signalPort = (int)(getenv('MESSENGER_SIGNAL_PORT') ?: 8091);
$secret = (string)getenv('MESSENGER_SIGNAL_SECRET');
$verifySecret = (string)getenv('MESSENGER_VERIFY_SECRET');
$verifyUrl = (string)getenv('MESSENGER_VERIFY_URL');
$origin = (string)getenv('MESSENGER_ALLOWED_ORIGIN');
if (strlen($secret) < 32 || strlen($verifySecret) < 32 || !$origin ||
    !preg_match('~^http://127\.0\.0\.1:[0-9]+/[^\s]+$~D', $verifyUrl)) {
    throw new RuntimeException('Trusted verifier, origin and secrets required');
}
// Reference runs in ONE worker to keep in-memory client list coherent.
$connections = array();
$nonces = array();
function messengerVerify($url, $secret, $action, $token, $company = null, $conversation = null)
{
    $json = json_encode(array('action'=>$action,'token'=>$token,'company_id'=>$company,'conversation_id'=>$conversation));
    $context = stream_context_create(array('http'=>array('method'=>'POST','timeout'=>2,'ignore_errors'=>true,
        'header'=>"Content-Type: application/json\r\nX-Internal-Key: ".$secret."\r\nContent-Length: ".strlen($json)."\r\n",
        'content'=>$json)));
    $body = @file_get_contents($url, false, $context);
    if ($body === false || strlen($body) > 4096) return false;
    $status = isset($http_response_header[0]) ? $http_response_header[0] : '';
    if (!preg_match('~^HTTP/[0-9.]+ 200(?: |$)~', $status)) return false;
    $value = json_decode($body, true);
    return is_array($value) && isset($value['allowed']) && $value['allowed'] === true &&
        isset($value['user_id']) && is_string($value['user_id']) ? $value : false;
}
$ws = new Worker('websocket://127.0.0.1:'.$wsPort);
$ws->count = 1;
$ws->onWebSocketConnect = function(TcpConnection $connection, Request $request) use ($origin) {
    if ($request->path() !== '/messenger/ws' || $request->header('origin') !== $origin) {
        $connection->close(); return;
    }
    $connection->messengerAuthenticated = false;
};
$ws->onMessage = function(TcpConnection $connection, $raw) use (&$connections,$verifyUrl,$verifySecret) {
    if (!is_string($raw) || strlen($raw) > 4096 || !empty($connection->messengerAuthenticated)) {
        $connection->close(); return;
    }
    $message = json_decode($raw,true);
    if (!is_array($message) || !isset($message['type'],$message['token']) || $message['type'] !== 'auth' ||
        !is_string($message['token']) || strlen($message['token']) > 4096) {
        $connection->close(); return;
    }
    $identity = messengerVerify($verifyUrl,$verifySecret,'authenticate',$message['token']);
    if (!$identity) { $connection->close(); return; }
    $connection->messengerAuthenticated = true;
    $connection->messengerToken = $message['token'];
    $connections[$connection->id] = $connection;
    // Token expires after at most 120s. Reconnect with fresh credentials.
    $connection->messengerExpiryTimer = Timer::add(115, function() use ($connection) {
        $connection->close();
    }, array(), false);
    $connection->send(json_encode(array('type'=>'ready')));
};
$ws->onClose = function(TcpConnection $connection) use (&$connections) {
    if (isset($connection->messengerExpiryTimer)) Timer::del($connection->messengerExpiryTimer);
    unset($connections[$connection->id]);
};
$signal = new Worker('text://127.0.0.1:'.$signalPort);
$signal->count = 1;
$signal->onMessage = function(TcpConnection $connection, $raw) use (&$connections,&$nonces,$secret,$verifyUrl,$verifySecret) {
    // Workerman text protocol frames the newline-delimited TCP message.
    if (!is_string($raw) || strlen($raw)>2048) { $connection->close(); return; }
    $packet=json_decode(trim($raw),true);
    if (!is_array($packet) || !isset($packet['body'],$packet['mac']) || !is_string($packet['body']) ||
        !is_string($packet['mac']) || !preg_match('/^[0-9a-f]{64}$/D',$packet['mac']) ||
        !hash_equals(hash_hmac('sha256',$packet['body'],$secret),$packet['mac'])) { $connection->close(); return; }
    $data=json_decode($packet['body'],true);$now=time();
    if (!is_array($data) || !isset($data['kind'],$data['ts'],$data['nonce'],$data['event_id'],$data['company_id'],$data['conversation_id']) ||
        $data['kind']!=='messenger.invalidate' || !is_int($data['ts']) || abs($now-$data['ts'])>30 ||
        !is_string($data['nonce']) || !preg_match('/^[a-f0-9]{32}$/D',$data['nonce'])) { $connection->close(); return; }
    foreach(array('event_id','company_id','conversation_id') as $key) {
        if (!is_string($data[$key]) || !preg_match('/^[1-9][0-9]*$/D',$data[$key])) { $connection->close(); return; }
    }
    if (isset($nonces[$data['nonce']])) { $connection->close(); return; }
    $nonces[$data['nonce']]=$now;
    foreach($nonces as $key=>$when) if ($when<$now-60) unset($nonces[$key]);
    $connection->send(json_encode(array('ack'=>hash_hmac('sha256',$data['nonce'],$secret)))."\n");
    foreach($connections as $client) {
        if (empty($client->messengerAuthenticated)) continue;
        // Verifier must derive company from identity and re-check membership each time.
        $allowed=messengerVerify($verifyUrl,$verifySecret,'authorize',$client->messengerToken,$data['company_id'],$data['conversation_id']);
        if ($allowed) $client->send(json_encode(array('type'=>'invalidate','conversation_id'=>$data['conversation_id'],'event_id'=>$data['event_id'])));
    }
};
Worker::runAll();
