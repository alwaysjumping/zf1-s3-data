<?php
/**
 * Run ONLY via `php -S 127.0.0.1:8092 router.php` on a trusted gateway host.
 * Set MESSENGER_VERIFIER_BOOTSTRAP to an absolute, administrator-owned PHP
 * file that returns a Zend_Db_Adapter_Abstract (DB and Zend autoloader ready).
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function deny($status=403) {
    http_response_code($status);
    echo '{"allowed":false}';
    exit;
}
if (PHP_SAPI!=='cli-server') deny(403);
if (!isset($_SERVER['REMOTE_ADDR']) || $_SERVER['REMOTE_ADDR']!=='127.0.0.1') deny(403);
if ($_SERVER['REQUEST_METHOD']!=='POST' || parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)!=='/internal/messenger/verify') deny(404);
$secret=getenv('MESSENGER_VERIFY_SECRET');
$key=isset($_SERVER['HTTP_X_INTERNAL_KEY'])?(string)$_SERVER['HTTP_X_INTERNAL_KEY']:'';
if (!is_string($secret)||strlen($secret)<32||strlen($key)!==strlen($secret)||!hash_equals($secret,$key)) deny(403);
if (isset($_SERVER['CONTENT_LENGTH']) && (int)$_SERVER['CONTENT_LENGTH']>4096) deny(413);
$raw=file_get_contents('php://input',false,null,0,4097);
if ($raw===false||strlen($raw)>4096) deny(413);
$data=json_decode($raw,true);
if (!is_array($data)||!isset($data['action'],$data['token'])||
    !is_string($data['action'])||!is_string($data['token'])) deny(400);
$bootstrap=getenv('MESSENGER_VERIFIER_BOOTSTRAP');
if (!is_string($bootstrap)||$bootstrap===''||!is_file($bootstrap)) deny(503);
try {
    $db=require $bootstrap;
    if (!($db instanceof Zend_Db_Adapter_Abstract)) throw new RuntimeException('INVALID_BOOTSTRAP');
    $svc=new Messenger_GatewayTokenService($db);
    $company=isset($data['company_id'])?$data['company_id']:null;
    $conversation=isset($data['conversation_id'])?$data['conversation_id']:null;
    $result=$svc->verify($data['token'],$data['action'],$company,$conversation);
    if (empty($result['allowed'])) deny(403);
    echo json_encode($result);
} catch (Throwable $e) {
    error_log('Messenger verifier unavailable: '.$e->getMessage());
    deny(503);
}
