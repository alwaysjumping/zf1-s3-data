/* Reference gateway: authentication and authorization supplied by trusted internal verifier. */
'use strict';
const http=require('http'),net=require('net'),crypto=require('crypto'),WebSocket=require('ws');
const WS_PORT=Number(process.env.MESSENGER_WS_PORT||8081),SIGNAL_PORT=Number(process.env.MESSENGER_SIGNAL_PORT||8091);
const SECRET=process.env.MESSENGER_SIGNAL_SECRET||'',VERIFY_URL=process.env.MESSENGER_VERIFY_URL||'',VERIFY_SECRET=process.env.MESSENGER_VERIFY_SECRET||'';
if(SECRET.length<32||VERIFY_SECRET.length<32||!/^http:\/\/127\.0\.0\.1:\d+\/[^\s]+$/.test(VERIFY_URL))throw Error('Trusted verifier and 32+ character secrets required');
const clients=new Set();
function safeEqual(a,b){if(!/^[0-9a-f]{64}$/.test(b))return false;return crypto.timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex'));}
function verify(body,mac){return safeEqual(crypto.createHmac('sha256',SECRET).update(body).digest('hex'),mac);}
function callVerifier(action,token,company,conversation){
 return new Promise((resolve,reject)=>{
  const url=new URL(VERIFY_URL);const payload=JSON.stringify({action,token,company_id:company||null,conversation_id:conversation||null});
  const req=http.request({hostname:'127.0.0.1',port:Number(url.port),path:url.pathname+url.search,method:'POST',timeout:2000,headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload),'X-Internal-Key':VERIFY_SECRET}},res=>{
   let result='';res.on('data',b=>{result+=b;if(result.length>4096)req.destroy();});res.on('end',()=>{try{const data=JSON.parse(result);resolve(res.statusCode===200&&data.allowed===true&&typeof data.user_id==='string'?data:null);}catch(e){reject(e);}});
  });req.on('error',reject);req.on('timeout',()=>req.destroy(Error('verifier timeout')));req.end(payload);
 });
}
const server=http.createServer((req,res)=>{res.writeHead(404);res.end();});
const wss=new WebSocket.Server({noServer:true,maxPayload:4096,perMessageDeflate:false});
server.on('upgrade',(req,socket,head)=>{
 if(req.url!=='/messenger/ws'||req.headers.origin!==process.env.MESSENGER_ALLOWED_ORIGIN){socket.destroy();return;}
 wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
wss.on('connection',ws=>{
 const state={ws,token:null,user:null,lastAuth:0};clients.add(state);
 const deadline=setTimeout(()=>{if(!state.token)ws.close(1008,'auth required');},5000);
 const absoluteExpiry=setTimeout(()=>{ws.close(1008,'reauthenticate');},115000);
 ws.on('message',async raw=>{
  try{
   const msg=JSON.parse(String(raw));if(msg.type!=='auth'||typeof msg.token!=='string'||msg.token.length>4096)throw Error('bad auth');
   const identity=await callVerifier('authenticate',msg.token);
   if(!identity)throw Error('unauthorized');
   state.token=msg.token;state.user=identity.user_id;state.lastAuth=Date.now();clearTimeout(deadline);
   ws.send(JSON.stringify({type:'ready'}));
  }catch(e){ws.close(1008,'unauthorized');}
 });
 ws.on('close',()=>{clearTimeout(deadline);clearTimeout(absoluteExpiry);clients.delete(state);});ws.on('error',()=>{});
});
const seen=new Map();
const signal=net.createServer(socket=>{
 let input='';socket.setTimeout(3000,()=>socket.destroy());
 socket.on('data',async b=>{
  input+=b.toString('utf8');if(input.length>2048){socket.destroy();return;}
  if(input.indexOf('\n')<0)return;
  const line=input.slice(0,input.indexOf('\n'));input='';
  try{
   const packet=JSON.parse(line);if(typeof packet.body!=='string'||!verify(packet.body,packet.mac))throw Error('bad signature');
   const data=JSON.parse(packet.body),now=Math.floor(Date.now()/1000);
   if(data.kind!=='messenger.invalidate'||Math.abs(now-data.ts)>30||!/^[a-f0-9]{32}$/.test(data.nonce)||!['event_id','company_id','conversation_id'].every(k=>/^[1-9][0-9]*$/.test(data[k])))throw Error('invalid hint');
   if(seen.has(data.nonce))throw Error('replay');seen.set(data.nonce,now);
   for(const [nonce,when] of seen)if(now-when>60)seen.delete(nonce);
   // Ack receipt into gateway memory; delivery is best effort and clients always REST-reconcile.
   const ack=crypto.createHmac('sha256',SECRET).update(data.nonce).digest('hex');socket.end(JSON.stringify({ack})+'\n');
   for(const client of clients){
    if(!client.token||client.ws.readyState!==WebSocket.OPEN)continue;
    // Fresh authorization on every signal: membership revocation takes effect before delivery.
    callVerifier('authorize',client.token,data.company_id,data.conversation_id).then(result=>{
     if(result&&client.ws.readyState===WebSocket.OPEN)client.ws.send(JSON.stringify({type:'invalidate',conversation_id:data.conversation_id,event_id:data.event_id}));
    }).catch(()=>{});
   }
  }catch(e){socket.destroy();}
 });
});
server.listen(WS_PORT,'127.0.0.1');signal.listen(SIGNAL_PORT,'127.0.0.1');
console.log('Messenger gateway listening on loopback; terminate TLS at trusted reverse proxy.');
