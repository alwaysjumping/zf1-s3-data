-- Phase 22: run once after 004_attachments.sql. Backup and test in staging.
ALTER TABLE msg_attachments
 MODIFY scan_status ENUM('quarantined','scanning','clean','rejected') NOT NULL DEFAULT 'quarantined'
 COMMENT 'Scanner lifecycle; only clean may be linked or downloaded',
 ADD COLUMN scan_token CHAR(32) NULL COMMENT 'Random worker lease token',
 ADD COLUMN scan_claimed_at DATETIME(6) NULL COMMENT 'UTC worker lease start',
 ADD KEY idx_attachment_scan_queue(scan_status,id),
 ADD KEY idx_attachment_scan_lease(scan_status,scan_claimed_at);
