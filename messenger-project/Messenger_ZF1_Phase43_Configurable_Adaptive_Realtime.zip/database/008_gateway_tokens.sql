-- Phase 33: opaque short-lived websocket credentials, stored only as SHA-256 hashes.
CREATE TABLE msg_gateway_tokens (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Internal token record',
 token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL COMMENT 'SHA-256 of opaque browser token',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'Authenticated user_key',
 company_id BIGINT UNSIGNED NOT NULL COMMENT 'Server-resolved company',
 expires_at DATETIME NOT NULL COMMENT 'UTC expiration',
 revoked_at DATETIME NULL COMMENT 'UTC revocation',
 created_at DATETIME NOT NULL COMMENT 'UTC issue time',
 PRIMARY KEY(id),
 UNIQUE KEY uq_gateway_token_hash(token_hash),
 KEY idx_gateway_expiry(expires_at),
 KEY idx_gateway_user(user_id,revoked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Short-lived bearer tokens for realtime gateway only';
