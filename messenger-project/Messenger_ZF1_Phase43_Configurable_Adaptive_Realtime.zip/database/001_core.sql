-- Initial Messenger core schema. Confirm existing employee/company key types before deployment.
-- MariaDB InnoDB, UTF8MB4. This file is intended for a NEW Messenger installation.
CREATE TABLE msg_conversations (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Conversation ID',
 company_id BIGINT UNSIGNED NOT NULL COMMENT 'Owning company ID',
 type ENUM('private','group') NOT NULL COMMENT 'Conversation type',
 title VARCHAR(255) NULL COMMENT 'Group title',
 created_by BIGINT UNSIGNED NOT NULL COMMENT 'Creator user ID',
 last_sequence BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Last committed message sequence',
 last_message_id BIGINT UNSIGNED NULL COMMENT 'Most recent message ID',
 last_message_at DATETIME(6) NULL COMMENT 'Latest message UTC time',
 is_archived TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Archive flag',
 created_at DATETIME(6) NOT NULL COMMENT 'Creation UTC time',
 updated_at DATETIME(6) NOT NULL COMMENT 'Update UTC time',
 PRIMARY KEY (id), UNIQUE KEY uq_company (id,company_id),
 KEY idx_company_activity (company_id,last_message_at,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE msg_participants (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Participant ID',
 conversation_id BIGINT UNSIGNED NOT NULL COMMENT 'Conversation ID',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'User ID; maps to frm_users.user_key',
 role ENUM('owner','admin','member') NOT NULL DEFAULT 'member' COMMENT 'Group role',
 joined_at DATETIME(6) NOT NULL COMMENT 'Current membership start UTC',
 left_at DATETIME(6) NULL COMMENT 'Membership end UTC',
 last_read_sequence BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Read cursor',
 last_read_at DATETIME(6) NULL COMMENT 'Last read UTC time',
 is_muted TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Mute flag',
 is_pinned TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Pin flag',
 PRIMARY KEY (id), UNIQUE KEY uq_member (conversation_id,user_id),
 KEY idx_user_active (user_id,left_at),
 CONSTRAINT fk_part_conv FOREIGN KEY (conversation_id) REFERENCES msg_conversations(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE msg_membership_periods (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Period ID',
 participant_id BIGINT UNSIGNED NOT NULL COMMENT 'Participant ID',
 joined_at DATETIME(6) NOT NULL COMMENT 'Period start UTC',
 left_at DATETIME(6) NULL COMMENT 'Period end UTC',
 first_visible_sequence BIGINT UNSIGNED NOT NULL COMMENT 'First permitted sequence',
 last_visible_sequence BIGINT UNSIGNED NULL COMMENT 'Last sequence at departure',
 PRIMARY KEY (id), KEY idx_period (participant_id,joined_at),
 CONSTRAINT fk_period_part FOREIGN KEY (participant_id) REFERENCES msg_participants(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
