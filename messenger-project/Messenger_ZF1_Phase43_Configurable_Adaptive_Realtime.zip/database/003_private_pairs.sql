-- Apply after 001_core.sql. Fresh-install schema addition; no existing user/company FK assumptions.
CREATE TABLE msg_private_pairs (
 conversation_id BIGINT UNSIGNED NOT NULL COMMENT 'Conversation identifier',
 company_id BIGINT UNSIGNED NOT NULL COMMENT 'Owning company identifier',
 user_low BIGINT UNSIGNED NOT NULL COMMENT 'Smaller user identifier',
 user_high BIGINT UNSIGNED NOT NULL COMMENT 'Larger user identifier',
 PRIMARY KEY (conversation_id),
 UNIQUE KEY uq_private_pair (company_id,user_low,user_high),
 CONSTRAINT fk_private_pair_conversation FOREIGN KEY (conversation_id,company_id)
 REFERENCES msg_conversations(id,company_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Canonical private conversation pairs';
