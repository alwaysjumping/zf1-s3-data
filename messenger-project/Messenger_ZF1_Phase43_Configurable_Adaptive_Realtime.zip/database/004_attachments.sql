-- Run after 001_core.sql and 002_messages_outbox.sql. MariaDB/InnoDB.
CREATE TABLE msg_attachments (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Attachment ID',
 company_id BIGINT UNSIGNED NOT NULL COMMENT 'Tenant boundary',
 conversation_id BIGINT UNSIGNED NOT NULL COMMENT 'Owning conversation',
 uploader_id BIGINT UNSIGNED NOT NULL COMMENT 'Authenticated uploader',
 storage_key CHAR(64) NOT NULL COMMENT 'Random opaque storage identifier, never a client path',
 original_name VARCHAR(255) NOT NULL COMMENT 'Sanitized display name',
 mime_type VARCHAR(127) NOT NULL COMMENT 'Detected server-side MIME type',
 byte_size INT UNSIGNED NOT NULL COMMENT 'File size in bytes',
 sha256 CHAR(64) NOT NULL COMMENT 'SHA-256 digest',
 scan_status ENUM('quarantined','clean','rejected') NOT NULL DEFAULT 'quarantined' COMMENT 'Only clean can be downloaded or linked',
 created_at DATETIME(6) NOT NULL COMMENT 'UTC upload time',
 scanned_at DATETIME(6) NULL COMMENT 'UTC scan time',
 PRIMARY KEY(id), UNIQUE KEY uq_storage_key(storage_key),
 KEY idx_attachment_owner(company_id,conversation_id,uploader_id),
 CONSTRAINT fk_attachment_conversation FOREIGN KEY(conversation_id) REFERENCES msg_conversations(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quarantined and scanned Messenger uploads';
CREATE TABLE msg_message_attachments (
 message_id BIGINT UNSIGNED NOT NULL COMMENT 'Linked message',
 attachment_id BIGINT UNSIGNED NOT NULL COMMENT 'Linked clean attachment',
 PRIMARY KEY(message_id,attachment_id), UNIQUE KEY uq_attachment_one_message(attachment_id),
 CONSTRAINT fk_ma_message FOREIGN KEY(message_id) REFERENCES msg_messages(id),
 CONSTRAINT fk_ma_attachment FOREIGN KEY(attachment_id) REFERENCES msg_attachments(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Message attachment association';
