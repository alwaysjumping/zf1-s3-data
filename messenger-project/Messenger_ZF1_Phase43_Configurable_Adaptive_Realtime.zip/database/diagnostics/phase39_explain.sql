-- Run EXPLAIN in staging and inspect rows/key/Extra; do not blindly apply indexes.
EXPLAIN SELECT id,sequence_no,sender_id,body,created_at FROM msg_messages
WHERE conversation_id=1 AND sequence_no>=1 AND sequence_no<999999
ORDER BY sequence_no DESC LIMIT 50;
EXPLAIN SELECT r.message_id,r.emoji,COUNT(*) AS total FROM msg_reactions r
JOIN msg_messages m ON m.id=r.message_id
WHERE m.conversation_id=1 AND m.sequence_no>=1 AND m.deleted_at IS NULL
AND m.id IN (1,2,3) GROUP BY r.message_id,r.emoji;
EXPLAIN SELECT id FROM msg_events_outbox
WHERE status='pending' AND (next_attempt_at IS NULL OR next_attempt_at<=UTC_TIMESTAMP())
ORDER BY id LIMIT 100;
