-- Requires database/001_core.sql first. Review against MariaDB version.
CREATE TABLE msg_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Message primary key',
  conversation_id BIGINT UNSIGNED NOT NULL COMMENT 'Owning conversation',
  sequence_no BIGINT UNSIGNED NOT NULL COMMENT 'Monotonic sequence in conversation',
  sender_id BIGINT UNSIGNED NOT NULL COMMENT 'Authenticated sender',
  client_message_id CHAR(36) NOT NULL COMMENT 'Idempotency UUID',
  type ENUM('text','file','mixed','system') NOT NULL DEFAULT 'text' COMMENT 'Message kind',
  body MEDIUMTEXT NULL COMMENT 'Message text; redact from ordinary APIs after deletion',
  created_at DATETIME(6) NOT NULL COMMENT 'Creation UTC timestamp',
  edited_at DATETIME(6) NULL COMMENT 'Last edit UTC timestamp',
  deleted_at DATETIME(6) NULL COMMENT 'Soft delete UTC timestamp',
  deleted_by BIGINT UNSIGNED NULL COMMENT 'Deleting actor',
  revision_no INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Current revision',
  PRIMARY KEY (id),
  UNIQUE KEY uq_msg_seq (conversation_id,sequence_no),
  UNIQUE KEY uq_msg_retry (sender_id,client_message_id),
  KEY idx_msg_sender (sender_id,created_at),
  FULLTEXT KEY ft_msg_body (body),
  CONSTRAINT fk_msg_conv FOREIGN KEY (conversation_id)
    REFERENCES msg_conversations(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Conversation messages';

CREATE TABLE msg_events_outbox (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Outbox event ID',
  company_id BIGINT UNSIGNED NOT NULL COMMENT 'Company boundary',
  conversation_id BIGINT UNSIGNED NOT NULL COMMENT 'Owning conversation',
  event_type VARCHAR(100) NOT NULL COMMENT 'Event classification',
  entity_id BIGINT UNSIGNED NOT NULL COMMENT 'Related message or entity',
  payload_json LONGTEXT NULL COMMENT 'Minimal event metadata JSON',
  status ENUM('pending','processing','published','failed') NOT NULL DEFAULT 'pending' COMMENT 'Publication status',
  attempts INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Publication attempts',
  next_attempt_at DATETIME(6) NULL COMMENT 'Retry due time',
  locked_until DATETIME(6) NULL COMMENT 'Lease expiry',
  worker_token VARCHAR(64) NULL COMMENT 'Worker lease token',
  created_at DATETIME(6) NOT NULL COMMENT 'Event creation UTC',
  published_at DATETIME(6) NULL COMMENT 'Publication UTC',
  last_error VARCHAR(1024) NULL COMMENT 'Sanitized publication error',
  PRIMARY KEY(id),
  KEY idx_outbox_queue (status,next_attempt_at,id),
  KEY idx_outbox_conv (conversation_id,id),
  CONSTRAINT fk_outbox_conv FOREIGN KEY (conversation_id)
    REFERENCES msg_conversations(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Transactional delivery outbox';
