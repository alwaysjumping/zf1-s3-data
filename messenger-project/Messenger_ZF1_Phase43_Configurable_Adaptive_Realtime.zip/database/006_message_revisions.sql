-- Phase 23, after 002_messages_outbox.sql.
CREATE TABLE msg_message_revisions (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Revision history ID',
 message_id BIGINT UNSIGNED NOT NULL COMMENT 'Message being edited',
 revision_no INT UNSIGNED NOT NULL COMMENT 'Resulting message revision',
 previous_body MEDIUMTEXT NULL COMMENT 'Previous body; privileged retention only',
 edited_by BIGINT UNSIGNED NOT NULL COMMENT 'Author performing edit',
 created_at DATETIME(6) NOT NULL COMMENT 'UTC revision time',
 PRIMARY KEY(id),
 UNIQUE KEY uq_message_revision(message_id,revision_no),
 CONSTRAINT fk_revision_message FOREIGN KEY(message_id) REFERENCES msg_messages(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Restricted message edit history';
