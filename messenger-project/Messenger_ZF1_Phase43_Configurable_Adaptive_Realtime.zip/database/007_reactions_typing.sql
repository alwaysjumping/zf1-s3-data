-- Phase 24: run once after migration 006. UTF8MB4 connection required.
CREATE TABLE msg_reactions (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Reaction ID',
 message_id BIGINT UNSIGNED NOT NULL COMMENT 'Target message',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'Reacting user',
 emoji VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Allowlisted emoji identifier',
 created_at DATETIME(6) NOT NULL COMMENT 'UTC timestamp',
 PRIMARY KEY(id), UNIQUE KEY uq_reaction(message_id,user_id,emoji),
 KEY idx_reaction_message(message_id,emoji),
 CONSTRAINT fk_reaction_message FOREIGN KEY(message_id) REFERENCES msg_messages(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Current emoji reactions';
CREATE TABLE msg_typing_state (
 conversation_id BIGINT UNSIGNED NOT NULL COMMENT 'Conversation',
 user_id BIGINT UNSIGNED NOT NULL COMMENT 'User typing',
 expires_at DATETIME(6) NOT NULL COMMENT 'UTC expiry',
 PRIMARY KEY(conversation_id,user_id), KEY idx_typing_expiry(expires_at),
 CONSTRAINT fk_typing_conv FOREIGN KEY(conversation_id) REFERENCES msg_conversations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Ephemeral typing presence; periodically purge expired rows';
