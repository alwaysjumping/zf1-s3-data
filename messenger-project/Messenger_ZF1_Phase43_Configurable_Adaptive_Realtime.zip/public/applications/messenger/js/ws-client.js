/* ES5 WebSocket client: acquire a fresh, short-lived token per connection. */
(function(w){'use strict';
 function Client(options){this.opts=options||{};this.socket=null;this.attempt=0;this.stopped=true;this.timer=null;this.rotateTimer=null;this.generation=0;}
 Client.prototype.start=function(){if(!this.stopped)return;this.stopped=false;this.connect();};
 Client.prototype.clearTimers=function(){if(this.timer)w.clearTimeout(this.timer);if(this.rotateTimer)w.clearTimeout(this.rotateTimer);this.timer=null;this.rotateTimer=null;};
 Client.prototype.connect=function(){
  var self=this,o=this.opts,gen=++this.generation;
  if(this.stopped||!w.WebSocket||!o.url||typeof o.getToken!=='function')return;
  // getToken(callback) must fetch a new token using authenticated REST + CSRF.
  o.getToken(function(err,credentials){
   if(self.stopped||gen!==self.generation)return;
   if(err||!credentials||!(/^[a-f0-9]{64}$/).test(credentials.token||'')){self.retry();return;}
   var ttl=Number(credentials.expires_in);
   if(!isFinite(ttl)||ttl<30||ttl>300){self.retry();return;}
   var ws;try{ws=new w.WebSocket(o.url);}catch(e){self.retry();return;}
   self.socket=ws;
   // Proactively recycle with fresh credentials; no token is persisted.
   self.rotateTimer=w.setTimeout(function(){if(gen===self.generation&&ws===self.socket){ws.close(1000,'token rotation');}},Math.max(5000,(ttl-15)*1000));
   ws.onopen=function(){if(!self.stopped&&gen===self.generation)ws.send(JSON.stringify({type:'auth',token:credentials.token}));};
   ws.onmessage=function(event){if(self.stopped||gen!==self.generation)return;
    try{var data=JSON.parse(event.data);
     if(data.type==='ready'){self.attempt=0;if(o.onReady)o.onReady();}
     else if(data.type==='invalidate'&&/^[1-9][0-9]*$/.test(String(data.conversation_id))){if(o.onHint)o.onHint(data);}
    }catch(e){};
   };
   ws.onclose=function(){if(gen!==self.generation)return;self.socket=null;if(self.rotateTimer)w.clearTimeout(self.rotateTimer);self.rotateTimer=null;if(o.onDisconnect)o.onDisconnect();self.retry();};
   ws.onerror=function(){};
  });
 };
 Client.prototype.retry=function(){var self=this;if(this.stopped)return;if(this.timer)w.clearTimeout(this.timer);var wait=Math.min(30000,1000*Math.pow(2,Math.min(this.attempt++,5)));this.timer=w.setTimeout(function(){self.timer=null;self.connect();},wait);};
 Client.prototype.stop=function(){this.stopped=true;this.generation++;this.clearTimers();if(this.socket){var ws=this.socket;this.socket=null;ws.close();}};
 w.MessengerWsClient=Client;
}(window));
