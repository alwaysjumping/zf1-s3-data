/* ES5: one WebSocket per cooperative browser tab group; REST is source of truth. */
(function (w) {'use strict';
 function Realtime(options){this.o=options||{};this.coordinator=null;this.ws=null;this.started=false;this.lastLeader=false;this.lastReconcile=0;this.timer=null;}
 Realtime.prototype.reconcile=function(){this.lastReconcile=Date.now();if(typeof this.o.onReconcile==='function')this.o.onReconcile();};
 Realtime.prototype.setLeader=function(leader){
  if(!this.started)return;
  if(leader===this.lastLeader)return;
  this.lastLeader=leader;
  if(!leader){if(this.ws){this.ws.stop();this.ws=null;}return;}
  this.startSocket();
 };
 Realtime.prototype.startSocket=function(){
  var self=this;
  if(this.ws || !w.MessengerWsClient || !this.o.url || typeof this.o.getToken!=='function')return;
  this.ws=new w.MessengerWsClient({url:this.o.url,getToken:this.o.getToken,
   onReady:function(){self.reconcile();},
   onHint:function(){self.reconcile();if(self.coordinator)self.coordinator.hint();},
   onDisconnect:function(){self.reconcile();}});
  this.ws.start();
 };
 Realtime.prototype.start=function(){
  if(this.started)return;this.started=true;var self=this;
  if(w.MessengerTabCoordinator && this.o.scope){
   this.coordinator=new w.MessengerTabCoordinator({scope:this.o.scope,
    onLeader:function(leader){self.setLeader(leader);},
    onHint:function(){self.reconcile();}});
   this.coordinator.start();
  }else {this.setLeader(true);}
  this.reconcile();
  this.timer=w.setInterval(function(){
   // Periodic reconciliation covers lost hints, leader races and gateway outages.
   if(Date.now()-self.lastReconcile>=45000)self.reconcile();
  },10000);
 };
 Realtime.prototype.stop=function(){
  this.started=false;if(this.timer)w.clearInterval(this.timer);this.timer=null;
  if(this.ws)this.ws.stop();this.ws=null;
  if(this.coordinator)this.coordinator.stop();this.coordinator=null;this.lastLeader=false;
 };
 w.MessengerRealtimeCoordinator=Realtime;
}(window));
