/* Messenger Phase 26: ES5, jQuery 1.9+; no external CDN. */
(function (window, $) {
  'use strict';
  function escapeHtml(s) { return $('<div/>').text(s == null ? '' : String(s)).html(); }
  function uuid() {
    var s = '', i, x, bytes;
    if (!window.crypto || !window.crypto.getRandomValues) { throw new Error('Secure random generator unavailable'); }
    bytes = new Uint8Array(16); window.crypto.getRandomValues(bytes);
    bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
    for (i = 0; i < 16; i++) { x = bytes[i].toString(16); s += x.length === 1 ? '0' + x : x; }
    return s.substr(0,8)+'-'+s.substr(8,4)+'-'+s.substr(12,4)+'-'+s.substr(16,4)+'-'+s.substr(20);
  }
  function Messenger(root, opts) {
    this.$root = $(root); this.opts = opts || {}; this.csrf = this.opts.csrf || '';
    this.active = null; this.snapshot = {}; this.messages = []; this.timer = null; this.busy = false; this.coordinator = null; this.lastFullSync = 0; this.historyGeneration = 0; this.historyRequest = 0; this.olderBusy = false; this.hasOlder = true; this.maxVisibleMessages = 200; this.reactionRequest = 0; this.deltaBusy = false; this.deltaCounter = 0; this.latestRefreshAt = 0; this.ws=null; this.gatewaySession=null; this.wsHealthy=false; this.lastActivity=Date.now(); this.lastSafetySync=0; this.syncRequested=false; this.lastTypingCheck=0; this.lastPollAttempt=0; this.leaderState=null; this.pollingInFlight=false;
    this.$list = this.$root.find('.ms-conversations'); this.$history = this.$root.find('.ms-history');
    this.$title = this.$root.find('.ms-title'); this.$text = this.$root.find('.ms-compose');
    this.pendingAttachments=[]; this.typingTimer=null; this.typingPoll=null; this.lastTypingAt=0; this.currentTypingConversation=null; this.$status = this.$root.find('.ms-status'); this.currentUserId = this.opts.userId || null; this.bind();
  }
  Messenger.prototype.api = function (method, path, data) {
    return $.ajax({url:'/ws/messenger/'+path, type:method, data: method==='GET'?data:JSON.stringify(data),
      dataType:'json', contentType:method==='GET'?undefined:'application/json; charset=UTF-8',
      headers:method==='GET'?{}:{'X-CSRF-Token':this.csrf}, cache:false}).then(function(r){
        if (!r || r.success !== true) return $.Deferred().reject(r).promise(); return r.data;
      });
  };
  Messenger.prototype.error = function () { this.$status.text('Request failed. Please retry or sign in again.'); };
  Messenger.prototype.bind = function () {
    var self=this;
    this.$list.on('click','button[data-id]',function(){self.open($(this).attr('data-id'));});
    this.$root.find('.ms-send').on('click',function(){self.send();});
    this.$text.on('keydown',function(e){if(e.keyCode===13 && !e.shiftKey){e.preventDefault();self.send();}});
    this.$root.find('.ms-refresh').on('click',function(){self.sync(true);});
    this.$root.find('.ms-older').on('click',function(){self.older();});
    this.$root.find('.ms-create-private').on('click',function(){self.createPrivate();});
    this.$root.find('.ms-create-group').on('click',function(){self.createGroup();});
    this.$root.find('.ms-rename-group').on('click',function(){self.groupAction('rename');});
    this.$root.find('.ms-add-member').on('click',function(){self.memberAction('add');});
    this.$root.find('.ms-remove-member').on('click',function(){self.memberAction('remove');});
    this.$root.find('.ms-transfer-owner').on('click',function(){self.groupAction('transfer_owner');});
    this.$root.find('.ms-promote-admin').on('click',function(){self.groupAction('set_admin',true);});
    this.$root.find('.ms-demote-admin').on('click',function(){self.groupAction('set_admin',false);});
    this.$history.on('click','.ms-edit',function(){self.editMessage($(this).attr('data-id'));});
    this.$history.on('click','.ms-delete',function(){self.deleteMessage($(this).attr('data-id'));});
    this.$history.on('click','.ms-react',function(){self.react($(this).attr('data-id'));});
    this.$root.find('.ms-mark-read').on('click',function(){self.markRead();});
    this.$text.on('input',function(){self.signalTyping();});
    this.$root.find('.ms-upload').on('click',function(){self.uploadAttachment();});
    this.$root.find('.ms-clear-attachments').on('click',function(){self.pendingAttachments=[];self.$root.find('.ms-file-choice').prop('checked',false);self.renderPendingAttachments();});
    this.$root.find('.ms-popup-open').on('click',function(){self.openPopup();});
    this.$root.find('.ms-refresh-files').on('click',function(){self.refreshFiles();});
    this.$root.find('.ms-ready-files').on('change','.ms-file-choice',function(){self.updateFileChoices();});
    $(window).on('storage',function(event){
      var e=event.originalEvent || event;
      if(e.key==='messenger.sync.hint' && e.newValue){self.sync(true);}
    });
    $(window).on('focus',function(){self.sync(true);});
    $(document).on('visibilitychange',function(){if(!document.hidden)self.sync(true);});
  };
  Messenger.prototype.activity = function(){this.lastActivity=Date.now();};
  Messenger.prototype.intervalMs = function(){
    if(document.hidden)return this.opts.hiddenPollMs||60000;
    if(Date.now()-this.lastActivity>30000)return this.opts.idlePollMs||30000;
    return this.opts.activePollMs||5000;
  };
  Messenger.prototype.isLeader = function(){return !this.coordinator||this.coordinator.isLeader;};
  Messenger.prototype.socketStart = function(){
    var self=this;
    if(this.opts.realtimeMode!=='workerman'||!this.isLeader()||this.ws||!window.MessengerWsClient||!window.MessengerGatewaySession||!this.opts.wsUrl)return;
    this.gatewaySession=new window.MessengerGatewaySession(this.csrf);
    this.ws=new window.MessengerWsClient({
      url:this.opts.wsUrl,
      getToken:function(callback){self.gatewaySession.getToken(callback);},
      onReady:function(){self.wsHealthy=true;self.sync(true);},
      onHint:function(){self.sync(true);if(self.coordinator)self.coordinator.hint();},
      onDisconnect:function(){self.wsHealthy=false;self.lastPollAttempt=0;}
    });
    this.ws.start();
  };
  Messenger.prototype.socketStop = function(){
    this.wsHealthy=false;
    if(this.ws){this.ws.stop();this.ws=null;}
  };
  Messenger.prototype.leaderChanged = function(leader){
    if(this.leaderState===leader)return;
    this.leaderState=leader;
    if(leader){this.lastPollAttempt=0;this.socketStart();this.sync(true);}
    else this.socketStop();
  };
  Messenger.prototype.start = function () {
    var self=this;
    this.opts.realtimeMode=this.opts.realtimeMode==='workerman'?'workerman':'polling';
    if(window.MessengerTabCoordinator && this.opts.userId && this.opts.tabScope){
      this.coordinator=new window.MessengerTabCoordinator({
        scope:this.opts.tabScope,
        onHint:function(){self.sync(true);},
        onLeader:function(leader){self.leaderChanged(leader);}
      });
      this.coordinator.start();
    }
    if(!this.coordinator){this.socketStart();this.sync(true);}
    this.$root.on('keydown.messenger mousemove.messenger click.messenger',function(){self.activity();});
    this.visibilityHandler=function(){if(!document.hidden){self.activity();self.sync(true);}};
    document.addEventListener('visibilitychange',this.visibilityHandler,false);
    this.timer=window.setInterval(function(){
      var now=Date.now(),leader=self.isLeader();
      if(leader && self.opts.realtimeMode==='workerman' && self.wsHealthy){
        if(now-self.lastSafetySync>=300000){self.lastSafetySync=now;self.sync(false);}
      }else if(leader && now-self.lastPollAttempt>=self.intervalMs()){
        self.lastPollAttempt=now;self.sync(false);
      }else if(!leader && !document.hidden && now-self.lastFullSync>=300000){
        self.sync(false);
      }
      // Typing is only relevant while viewing a conversation, not in hidden tabs.
      if(self.active&&!document.hidden&&now-self.lastTypingCheck>=10000){
        self.lastTypingCheck=now;self.pollTyping();
      }
    },1000);
  };
  Messenger.prototype.stop = function () {
    if(this.timer)window.clearInterval(this.timer);
    if(this.typingPoll)window.clearInterval(this.typingPoll);
    if(this.typingTimer)window.clearTimeout(this.typingTimer);
    this.timer=null;this.typingPoll=null;this.typingTimer=null;
    this.socketStop();
    if(this.coordinator)this.coordinator.stop();
    this.coordinator=null;
    this.$root.off('.messenger');
    if(this.visibilityHandler)document.removeEventListener('visibilitychange',this.visibilityHandler,false);
  };
  Messenger.prototype.sync = function (force) {
    var self=this;
    if(this.busy){this.syncRequested=this.syncRequested||!!force;return;}
    this.busy=true;
    this.api('GET','sync',{}).done(function(data){
      self.lastFullSync=Date.now();
      var old=self.snapshot, next={}, list=data.conversations || [], changed=false, i, c, key, count=0;
      for(i=0;i<list.length;i++){
        c=list[i];key=String(c.conversation_id);next[key]=c;count++;
        if(!old[key] || String(old[key].last_sequence)!==String(c.last_sequence) ||
           String(old[key].membership_period_id)!==String(c.membership_period_id) ||
           String(old[key].last_event_id)!==String(c.last_event_id)) changed=true;
      }
      for(key in old)if(Object.prototype.hasOwnProperty.call(old,key)&&!next[key])changed=true;
      if(self.active && !next[self.active]) {
        self.historyGeneration++;self.historyRequest++;self.reactionRequest++;
        self.active=null;self.messages=[];self.$history.empty();self.$title.text('Select a conversation');
      }
      self.snapshot=next;
      if(changed||force)self.renderConversations(list);
      if(changed&&self.coordinator&&self.isLeader())self.coordinator.hint();
      if(self.active && (force || changed)) {
        var previous=old[self.active], current=next[self.active];
        if(!force && previous && current &&
           String(previous.membership_period_id)===String(current.membership_period_id) &&
           Number(current.last_sequence)>Number(previous.last_sequence) && self.messages.length)self.loadDelta();
        else self.loadLatest();
      }
      if(data.truncated)self.$status.text('Conversation list is incomplete; server pagination is required.');
      else if(!self.active)self.$status.text('Select a conversation.');
    }).fail(function(){self.error();}).always(function(){
      self.busy=false;
      if(self.syncRequested){self.syncRequested=false;self.sync(true);}
    });
  };
  Messenger.prototype.renderConversations = function (list) {
    var html='',i,c,id;
    for(i=0;i<list.length;i++) {c=list[i];id=String(c.conversation_id);
      html+='<button type="button" data-id="'+escapeHtml(id)+'"'+(id===this.active?' class="active"':'')+'>'+
      'Conversation #'+escapeHtml(id)+' <small>('+escapeHtml(c.last_sequence)+' messages)</small></button>';
    } this.$list.html(html || '<p>No conversations yet.</p>');
  };
  Messenger.prototype.open = function(id){
    this.clearTyping();this.pendingAttachments=[];this.renderPendingAttachments();
    this.historyGeneration++;this.historyRequest++;this.reactionRequest++;this.deltaCounter++;this.deltaBusy=false;
    this.active=String(id);this.messages=[];this.hasOlder=true;this.olderBusy=false;
    this.$title.text('Conversation #'+id);this.$history.empty();this.loadLatest();this.refreshFiles();
  };
  Messenger.prototype.mergeMessages = function (incoming, keepOlder) {
    var map={},rows=[],i,m,k;
    if(keepOlder){for(i=0;i<this.messages.length;i++){m=this.messages[i];map[String(m.id)]=m;}}
    for(i=0;i<incoming.length;i++){m=incoming[i];if(m && m.id!=null)map[String(m.id)]=m;}
    for(k in map)if(Object.prototype.hasOwnProperty.call(map,k))rows.push(map[k]);
    rows.sort(function(a,b){return Number(a.sequence_no)-Number(b.sequence_no);});
    if(rows.length>this.maxVisibleMessages)rows=rows.slice(rows.length-this.maxVisibleMessages);
    this.messages=rows;
  };
  Messenger.prototype.loadDelta=function(){
    var self=this,id=this.active,gen=this.historyGeneration,seq=0,i,request;
    if(!id || this.deltaBusy || !this.messages.length)return this.loadLatest();
    for(i=0;i<this.messages.length;i++)seq=Math.max(seq,Number(this.messages[i].sequence_no)||0);
    if(!seq)return this.loadLatest();
    this.deltaBusy=true;request=++this.deltaCounter;
    this.api('GET','messages',{conversation_id:id,after_sequence:seq,limit:50}).done(function(rows){
      if(self.active!==id || self.historyGeneration!==gen || request!==self.deltaCounter)return;
      if(!$.isArray(rows))return;
      self.mergeMessages(rows,true);self.renderMessages();self.refreshMessageFiles();
      // Full pages can hide further newer messages; fetch latest to reconcile safely.
      if(rows.length===50)self.loadLatest();
    }).fail(function(){if(self.active===id && self.historyGeneration===gen)self.loadLatest();})
      .always(function(){if(self.historyGeneration===gen)self.deltaBusy=false;});
  };
  Messenger.prototype.loadLatest=function(){
    var self=this,id=this.active,gen=this.historyGeneration,request=++this.historyRequest;
    if(!id)return;
    this.latestRefreshAt=(new Date()).getTime();
    this.api('GET','messages',{conversation_id:id,limit:50}).done(function(rows){
      if(self.active!==id || self.historyGeneration!==gen || request!==self.historyRequest || !$.isArray(rows))return;
      // Preserve already loaded older messages while refreshing the newest page.
      // The 200-message DOM window is bounded; scrolling older is not a full archive viewer.
      self.mergeMessages(rows,true);self.renderMessages();self.refreshMessageFiles();
    }).fail(function(){if(self.active===id && self.historyGeneration===gen)self.error();});
  };
  Messenger.prototype.older=function(){
    var self=this,id=this.active,gen=this.historyGeneration,oldest=null,i,request;
    if(!id||!this.messages.length||this.olderBusy||!this.hasOlder)return;
    for(i=0;i<this.messages.length;i++)if(oldest===null || Number(this.messages[i].sequence_no)<oldest)oldest=Number(this.messages[i].sequence_no);
    this.olderBusy=true;request=this.historyRequest;
    this.api('GET','messages',{conversation_id:id,before_sequence:oldest,limit:50}).done(function(rows){
      if(self.active!==id||self.historyGeneration!==gen||request!==self.historyRequest||!$.isArray(rows))return;
      if(rows.length<50)self.hasOlder=false;
      self.mergeMessages(rows,true);self.renderMessages();
    }).fail(function(){if(self.active===id&&self.historyGeneration===gen)self.error();})
      .always(function(){if(self.historyGeneration===gen)self.olderBusy=false;});
  };
  Messenger.prototype.renderMessages=function(){
    var rows=this.messages.slice(0),html='',i,m;
    rows.sort(function(a,b){return Number(a.sequence_no)-Number(b.sequence_no);});
    for(i=0;i<rows.length;i++) {m=rows[i];html+='<div class="ms-message"><small>#'+escapeHtml(m.sequence_no)+
      ' · User '+escapeHtml(m.sender_id)+' · '+escapeHtml(m.created_at)+'</small><div>'+
      (m.deleted_at?'[Message deleted]':escapeHtml(m.body))+'</div><div class="ms-message-actions">'+
      (this.currentUserId !== null && String(m.sender_id) === String(this.currentUserId) && !m.deleted_at ?
      '<button type="button" class="ms-edit" data-id="'+escapeHtml(m.id)+'">Edit</button>'+
      '<button type="button" class="ms-delete" data-id="'+escapeHtml(m.id)+'">Delete</button>' : '')+
      (!m.deleted_at?'<button type="button" class="ms-react" data-id="'+escapeHtml(m.id)+'">React</button>':'')+
      '<span class="ms-reactions" data-message-id="'+escapeHtml(m.id)+'"></span></div></div>'; }
    this.$history.html(html || '<p>No messages in this conversation.</p>');
    this.loadReactions(rows);
  };
  Messenger.prototype.send=function(){
    var self=this,body=this.$text.val(),id=this.active,requestId;
    if(!id || (!$.trim(body || '') && !this.pendingAttachments.length))return;
    if(body.length>10000){this.$status.text('Message is too long.');return;}
    try {requestId=uuid();}catch(e){this.$status.text('Secure random generator is required.');return;}
    this.$root.find('.ms-send').prop('disabled',true);
    this.api('POST','messages',{conversation_id:Number(id),client_message_id:requestId,body:body,attachment_ids:this.pendingAttachments.slice(0)}).done(function(){
      if(self.active===id){self.$text.val('');self.pendingAttachments=[];self.renderPendingAttachments();self.refreshFiles();self.clearTyping();self.loadLatest();}self.$status.text('Message sent.');self.broadcastSyncHint();
    }).fail(function(){self.error();}).always(function(){self.$root.find('.ms-send').prop('disabled',false);});
  };

  Messenger.prototype.broadcastSyncHint = function () {
    try {window.localStorage.setItem('messenger.sync.hint',String((new Date()).getTime()));} catch(e) {}
  };
  Messenger.prototype.value = function (selector) { return $.trim(this.$root.find(selector).val() || ''); };
  Messenger.prototype.positiveId = function (value) {
    var n=Number(value);
    return (/^[1-9][0-9]*$/).test(String(value)) && isFinite(n) && n<=9007199254740991 ? n : null;
  };
  Messenger.prototype.notify = function (text) { this.$status.text(text); };
  Messenger.prototype.createPrivate = function () {
    var self=this,id=this.positiveId(this.value('.ms-private-user'));
    if(!id){this.notify('Enter a valid recipient ID.');return;}
    this.api('POST','conversations',{type:'private',recipient_id:id}).done(function(r){
      self.notify('Private conversation ready.');self.sync(true);
      if(r && r.conversation_id)self.open(String(r.conversation_id));
    }).fail(function(){self.error();});
  };
  Messenger.prototype.createGroup = function () {
    var self=this,title=this.value('.ms-group-title'),raw=this.value('.ms-group-users'),parts=raw?raw.split(','):[],ids=[],i,n;
    if(!title || title.length>150){this.notify('Enter a group title (1–150 characters).');return;}
    for(i=0;i<parts.length;i++){n=this.positiveId($.trim(parts[i]));if(!n){this.notify('Use comma-separated numeric user IDs.');return;}if($.inArray(n,ids)<0)ids.push(n);}
    if(ids.length>99){this.notify('Groups support up to 100 people including the creator.');return;}
    this.api('POST','conversations',{type:'group',title:title,user_ids:ids}).done(function(r){
      self.notify('Group created.');self.sync(true);if(r && r.conversation_id)self.open(String(r.conversation_id));
    }).fail(function(){self.error();});
  };
  Messenger.prototype.memberAction = function (operation) {
    var self=this,id=this.positiveId(this.value('.ms-target-user'));
    if(!this.active || !id){this.notify('Select a conversation and enter a target user ID.');return;}
    if(operation==='remove' && !window.confirm('Remove this member?'))return;
    this.api('POST','members',{operation:operation,conversation_id:Number(this.active),target_user_id:id}).done(function(){
      self.notify('Membership updated.');self.sync(true);
    }).fail(function(){self.error();});
  };
  Messenger.prototype.groupAction = function (operation,isAdmin) {
    var self=this,data={operation:operation,conversation_id:Number(this.active)},id;
    if(!this.active){this.notify('Select a group first.');return;}
    if(operation==='rename'){data.title=this.value('.ms-group-title');if(!data.title){this.notify('Enter a group title.');return;}}
    else {
      id=this.positiveId(this.value('.ms-target-user'));
      if(!id){this.notify('Enter a valid target user ID.');return;}
      data.target_user_id=id;
      if(operation==='set_admin')data.is_admin=isAdmin;
      if(operation==='transfer_owner' && !window.confirm('Transfer group ownership?'))return;
    }
    this.api('POST','groups',data).done(function(){self.notify('Group updated.');self.sync(true);}).fail(function(){self.error();});
  };
  Messenger.prototype.findMessage = function (id) {
    var i;for(i=0;i<this.messages.length;i++)if(String(this.messages[i].id)===String(id))return this.messages[i];
    return null;
  };
  Messenger.prototype.editMessage = function (id) {
    var self=this,m=this.findMessage(id),body;
    if(!m || !this.active)return;
    body=window.prompt('Edit message:',m.body || '');
    if(body===null)return;
    if(!$.trim(body) || body.length>10000){this.notify('Enter message text of at most 10,000 characters.');return;}
    this.api('POST','message-state',{operation:'edit',conversation_id:Number(this.active),message_id:Number(id),body:body}).done(function(){
      self.notify('Message edited.');self.loadLatest();
    }).fail(function(){self.error();});
  };
  Messenger.prototype.deleteMessage = function (id) {
    var self=this;
    if(!this.active || !window.confirm('Delete this message?'))return;
    this.api('POST','message-state',{operation:'delete',conversation_id:Number(this.active),message_id:Number(id)}).done(function(){
      self.notify('Message deleted.');self.loadLatest();
    }).fail(function(){self.error();});
  };
  Messenger.prototype.react = function (id) {
    var self=this,emoji=window.prompt('Reaction: 👍 ❤️ 😂 😮 😢 😡 🎉 👏','👍');
    if(emoji===null || !this.active)return;
    if($.inArray(emoji,['👍','❤️','😂','😮','😢','😡','🎉','👏'])<0){this.notify('Choose one of the supported reactions.');return;}
    this.api('POST','interactions',{type:'reaction',conversation_id:Number(this.active),message_id:Number(id),emoji:emoji,active:true}).done(function(){
      self.notify('Reaction added.');self.loadLatest();
    }).fail(function(){self.error();});
  };
  Messenger.prototype.loadReactions = function (rows) {
    var self=this,conversation=this.active,gen=++this.reactionRequest,ids=[],i,m;
    for(i=0;i<rows.length && ids.length<100;i++){
      m=rows[i];if(!m.deleted_at && /^[1-9][0-9]*$/.test(String(m.id)))ids.push(String(m.id));
    }
    if(!ids.length)return;
    // One bounded request replaces one HTTP request per visible message.
    this.api('GET','interactions',{type:'reactions-batch',conversation_id:conversation,message_ids:ids.join(',')}).done(function(groups){
      if(self.active!==conversation || self.reactionRequest!==gen || !groups)return;
      var id,counts,text,j,item;
      for(i=0;i<ids.length;i++){
        id=ids[i];counts=groups[id]||[];text='';
        for(j=0;j<counts.length;j++){
          item=counts[j];text+=String(item.emoji||'')+' '+String(item.total||0)+' ';
        }
        self.$history.find('.ms-reactions').filter(function(){return $(this).attr('data-message-id')===id;}).text(text);
      }
    });
  };
  Messenger.prototype.markRead = function () {
    var self=this,max=0,i;
    if(!this.active)return;
    for(i=0;i<this.messages.length;i++)max=Math.max(max,Number(this.messages[i].sequence_no)||0);
    if(!max){this.notify('No messages to mark as read.');return;}
    this.api('POST','message-state',{operation:'read',conversation_id:Number(this.active),sequence_no:max}).done(function(){
      self.notify('Read position updated.');
    }).fail(function(){self.error();});
  };


  Messenger.prototype.signalTyping = function () {
    var self=this, now=(new Date()).getTime(), id=this.active;
    if(!id)return;
    if(now-this.lastTypingAt>4000){
      this.lastTypingAt=now;
      this.api('POST','interactions',{type:'typing',conversation_id:Number(id),active:true}).fail(function(){/* ephemeral best effort */});
    }
    if(this.typingTimer)window.clearTimeout(this.typingTimer);
    this.typingTimer=window.setTimeout(function(){self.clearTyping();},4500);
  };
  Messenger.prototype.clearTyping = function () {
    if(this.typingTimer)window.clearTimeout(this.typingTimer);
    this.typingTimer=null;
    if(this.active && this.lastTypingAt){
      this.api('POST','interactions',{type:'typing',conversation_id:Number(this.active),active:false});
    }
    this.lastTypingAt=0;
    this.$root.find('.ms-typing').text('');
  };
  Messenger.prototype.pollTyping = function () {
    var self=this,id=this.active;
    if(!id || (document.hidden===true))return;
    this.api('GET','interactions',{type:'typing',conversation_id:id}).done(function(rows){
      if(self.active!==id)return;
      var names=[],i;
      if(!$.isArray(rows))return;
      for(i=0;i<rows.length;i++)names.push('User '+String(rows[i].user_id));
      self.$root.find('.ms-typing').text(names.length?names.join(', ')+' typing…':'');
    });
  };
  Messenger.prototype.renderPendingAttachments = function () {
    var ids=this.pendingAttachments;
    this.$root.find('.ms-pending-attachments').text(ids.length?ids.length+' approved attachment(s) selected':'No attachments selected');
  };
  Messenger.prototype.uploadAttachment = function () {
    var self=this,id=this.active,fileInput=this.$root.find('.ms-file')[0],file,form;
    if(!id || !fileInput || !fileInput.files || !fileInput.files.length){this.notify('Select a conversation and file.');return;}
    file=fileInput.files[0];
    if(file.size>20971520){this.notify('Maximum file size is 20 MiB.');return;}
    if(!window.FormData){this.notify('This browser cannot upload files with this interface.');return;}
    form=new FormData();form.append('conversation_id',id);form.append('file',file);
    this.$root.find('.ms-upload').prop('disabled',true);
    $.ajax({url:'/ws/messenger/attachments',type:'POST',data:form,processData:false,contentType:false,dataType:'json',headers:{'X-CSRF-Token':this.csrf}})
    .done(function(result){
      if(!result || !result.success || !result.data){self.error();return;}
      // Uploaded files are quarantined. They cannot be linked until scanned clean.
      self.$root.find('.ms-upload-result').text('File uploaded (#'+String(result.data.id)+'). Await antivirus approval.');
      fileInput.value='';
    }).fail(function(){self.error();}).always(function(){self.$root.find('.ms-upload').prop('disabled',false);});
  };
  Messenger.prototype.refreshFiles = function () {
    var self=this,id=this.active;
    if(!id)return;
    this.api('GET','attachments',{list:'ready',conversation_id:id}).done(function(rows){
      if(self.active!==id || !$.isArray(rows))return;
      var html='',i,f,selected;
      for(i=0;i<rows.length;i++){
        f=rows[i];selected=$.inArray(Number(f.id),self.pendingAttachments)>=0;
        html+='<label class="ms-ready-item"><input type="checkbox" class="ms-file-choice" value="'+escapeHtml(f.id)+'"'+(selected?' checked':'')+'>'+escapeHtml(f.original_name)+' ('+escapeHtml(f.byte_size)+' bytes)</label>';
      }
      self.$root.find('.ms-ready-files').html(html || '<small>No approved unlinked uploads. Refresh after antivirus scanning.</small>');
      self.updateFileChoices();
    }).fail(function(){self.notify('Could not load approved files.');});
  };
  Messenger.prototype.updateFileChoices = function () {
    var ids=[],self=this;
    this.$root.find('.ms-file-choice:checked').each(function(){
      var id=self.positiveId($(this).val());if(id!==null && $.inArray(id,ids)<0)ids.push(id);
    });
    if(ids.length>10){this.notify('Maximum 10 attachments per message.');ids=ids.slice(0,10);}
    this.pendingAttachments=ids;this.renderPendingAttachments();
  };
  Messenger.prototype.refreshMessageFiles = function () {
    var self=this,id=this.active;
    if(!id)return;
    this.api('GET','attachments',{list:'message-files',conversation_id:id}).done(function(rows){
      if(self.active!==id || !$.isArray(rows))return;
      var html='',i,f;
      for(i=0;i<rows.length;i++){
        f=rows[i];
        html+='<div class="ms-download-item">Message #'+escapeHtml(f.message_id)+': <a href="/ws/messenger/attachments?attachment_id='+encodeURIComponent(String(f.id))+'">'+escapeHtml(f.original_name)+'</a></div>';
      }
      self.$root.find('.ms-message-files').html(html);
    });
  };
  Messenger.prototype.openPopup = function () {
    if(!this.active){this.notify('Select a conversation first.');return;}
    if(window.top && window.top.MessengerQuickChat){window.top.MessengerQuickChat.open(this.active);}
    else this.notify('Quick-chat host is not installed in the top-level shell.');
  };

  window.MessengerPhase26=Messenger;
}(window,window.jQuery));
