/* ES5 helper for same-origin gateway credential requests. Requires local jQuery. */
(function(w,$){'use strict';
 function GatewaySession(csrf){this.csrf=csrf;}
 GatewaySession.prototype.getToken=function(callback){
  $.ajax({url:'/ws/messenger/gateway-token',type:'POST',data:'{}',contentType:'application/json',dataType:'json',cache:false,
   headers:{'X-CSRF-Token':this.csrf}}).done(function(result){
    // Normalize to service payload. Confirm your ApiController JSON envelope.
    var data=result && result.data ? result.data : result;
    callback(null,data);
   }).fail(function(){callback(new Error('Gateway token unavailable'));});
 };
 GatewaySession.prototype.logoutGateway=function(callback){
  $.ajax({url:'/ws/messenger/gateway-token',type:'DELETE',dataType:'json',headers:{'X-CSRF-Token':this.csrf}})
   .always(function(){if(callback)callback();});
 };
 w.MessengerGatewaySession=GatewaySession;
}(window,window.jQuery));
