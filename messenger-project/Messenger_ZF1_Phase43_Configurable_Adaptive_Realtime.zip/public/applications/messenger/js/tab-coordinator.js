/* Best-effort ES5 tab coordination. Never a security or correctness boundary. */
(function(w){'use strict';
 function rand(){if(!w.crypto||!w.crypto.getRandomValues)return null;var a=new Uint32Array(4);w.crypto.getRandomValues(a);return Array.prototype.join.call(a,'-');}
 function Coordinator(options){
  options=options||{};this.scope=String(options.scope||'');this.id=rand();this.enabled=!!(this.id&&this.scope);this.key='messenger.coordinator.'+this.scope;
  this.onHint=options.onHint||function(){};this.onLeader=options.onLeader||function(){};
  this.isLeader=false;this.timer=null;this.lastFallback=0;this.leaseMs=15000;this.tickMs=4000;this.bound=null;
  if(this.enabled){try{var probe=this.key+'.probe';w.localStorage.setItem(probe,this.id);w.localStorage.removeItem(probe);}catch(e){this.enabled=false;}}
 }
 Coordinator.prototype.read=function(){try{var v=w.localStorage.getItem(this.key);return v?JSON.parse(v):null;}catch(e){return null;}};
 Coordinator.prototype.write=function(v){try{w.localStorage.setItem(this.key,JSON.stringify(v));return true;}catch(e){this.enabled=false;return false;}};
 Coordinator.prototype.tick=function(){
  if(!this.enabled){this.isLeader=true;this.onLeader(true);return;}
  var now=Date.now(),old=this.read(),mine=old&&old.id===this.id;
  if(!old||!old.id||!old.until||old.until<=now||mine){
   this.write({id:this.id,until:now+this.leaseMs});
   var check=this.read();this.isLeader=!!(check&&check.id===this.id);
  }else this.isLeader=false;
  this.onLeader(this.isLeader);
 };
 Coordinator.prototype.start=function(){
  var self=this;if(this.timer)return;this.tick();
  this.bound=function(e){e=e||w.event;if(e.key===self.key){self.tick();return;}if(e.key===self.key+'.hint'&&e.newValue){self.onHint();}};
  if(w.addEventListener)w.addEventListener('storage',this.bound,false);
  this.timer=w.setInterval(function(){self.tick();},this.tickMs);
 };
 Coordinator.prototype.hint=function(){if(!this.enabled)return;try{w.localStorage.setItem(this.key+'.hint',JSON.stringify({id:this.id,at:Date.now()}));}catch(e){}};
 Coordinator.prototype.stop=function(){
  if(this.timer)w.clearInterval(this.timer);this.timer=null;
  if(this.bound&&w.removeEventListener)w.removeEventListener('storage',this.bound,false);
  if(this.enabled&&this.isLeader){var old=this.read();if(old&&old.id===this.id)try{w.localStorage.removeItem(this.key);}catch(e){}}
  this.isLeader=false;
 };
 w.MessengerTabCoordinator=Coordinator;
}(window));
