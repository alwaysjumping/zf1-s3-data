/* Install only in the persistent top-level shell. ES5 + local jQuery. */
(function(window,$){'use strict';
 if(window!==window.top)return;
 var $host=$('<div class="ms-quickchat-host" aria-label="Quick chats"></div>').appendTo('body'),panels={};
 function escape(s){return $('<span/>').text(s==null?'':String(s)).html();}
 function api(method,path,data,csrf){return $.ajax({url:'/ws/messenger/'+path,type:method,data:method==='GET'?data:JSON.stringify(data),dataType:'json',contentType:method==='GET'?undefined:'application/json; charset=UTF-8',headers:method==='GET'?{}:{'X-CSRF-Token':csrf},cache:false});}
 function csrf(){return typeof window.messengerCsrfToken==='string'?window.messengerCsrfToken:'';}
 function refresh(id){var panel=panels[id];if(!panel)return;
  api('GET','messages',{conversation_id:id,limit:30},csrf()).done(function(r){
   if(!panels[id] || !r || r.success!==true || !$.isArray(r.data))return;
   var html='',rows=r.data.slice(0),i,m;rows.sort(function(a,b){return Number(a.sequence_no)-Number(b.sequence_no);});
   for(i=0;i<rows.length;i++){m=rows[i];html+='<p><small>User '+escape(m.sender_id)+':</small> '+(m.deleted_at?'[Deleted]':escape(m.body))+'</p>';}
   panel.find('.ms-quickchat-log').html(html);
  });
 }
 function open(id){id=String(id);if(!/^[1-9][0-9]*$/.test(id))return;
  if(panels[id]){refresh(id);return;}
  if(Object.keys(panels).length>=3)return;
  var $p=$('<section class="ms-quickchat-panel"><header>Conversation #'+escape(id)+' <button type="button" class="ms-quickchat-close">×</button></header><div class="ms-quickchat-log"></div><textarea aria-label="Quick message"></textarea><button type="button" class="ms-quickchat-send">Send</button></section>').appendTo($host);
  panels[id]=$p;
  var timer=window.setInterval(function(){if(!document.hidden)refresh(id);},60000);
  $p.find('.ms-quickchat-close').on('click',function(){window.clearInterval(timer);delete panels[id];$p.remove();});
  $p.find('.ms-quickchat-send').on('click',function(){
    var body=$p.find('textarea').val();if(!$.trim(body))return;
    if(!window.crypto || !window.crypto.getRandomValues){$p.find('.ms-quickchat-log').text('Secure random generator unavailable.');return;}
    var a=new Uint8Array(16),i,h='',x;window.crypto.getRandomValues(a);a[6]=(a[6]&15)|64;a[8]=(a[8]&63)|128;
    for(i=0;i<16;i++){x=a[i].toString(16);h+=(x.length===1?'0':'')+x;}
    var uuid=h.substr(0,8)+'-'+h.substr(8,4)+'-'+h.substr(12,4)+'-'+h.substr(16,4)+'-'+h.substr(20);
    api('POST','messages',{conversation_id:Number(id),client_message_id:uuid,body:body},csrf()).done(function(r){if(r && r.success===true){$p.find('textarea').val('');refresh(id);}});
  });refresh(id);
 }
 // Cross-tab hints are advisory; regular polling remains the recovery mechanism.
 $(window).on('storage',function(event){
   var e=event.originalEvent||event,id;
   if(e.key!=='messenger.sync.hint' || !e.newValue)return;
   for(id in panels)if(Object.prototype.hasOwnProperty.call(panels,id))refresh(id);
 });
 window.MessengerQuickChat={open:open};
}(window,jQuery));
