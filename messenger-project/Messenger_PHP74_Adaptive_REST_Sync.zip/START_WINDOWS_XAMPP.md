> **Realtime selection:** Set `realtime_mode` to `polling` (no Workerman) or `workerman` in `app/config.php`. See [REALTIME_MODES.md](REALTIME_MODES.md).

# Windows 11 / XAMPP setup

1. Unzip the project to `C:\xampp\htdocs\messenger-purephp`.
2. Start Apache and MariaDB in the XAMPP control panel.
3. In phpMyAdmin, import `database/schema.sql`. This script creates database `messenger_demo`.
4. Copy `app/config.example.php` to `app/config.php`; edit MariaDB username/password. Temporarily set `allow_demo_seed` to `true`.
5. Open a command prompt in the project directory and run `C:\xampp\php\php.exe scripts\seed.php`.
6. For a simple local test, run `C:\xampp\php\php.exe -S 127.0.0.1:8080 -t public public\router.php` and open `http://127.0.0.1:8080/`.
7. Sign in as `alice` / `demo1234` and use another private browser for `bob` / `demo1234`.
8. Set `allow_demo_seed` back to `false` after setup.

**Important:** Do not use `http://localhost/messenger-purephp/` with the entire extracted folder as Apache's public webroot. Use the `public` folder as DocumentRoot, or use the PHP built-in server above. The app, scripts, and stored files must not be served publicly.

The demo uses PHP 7.4-compatible syntax. Use the PHP executable belonging to the intended XAMPP installation. ClamAV is optional for text chat, but attachments cannot be sent until scanned and approved.
