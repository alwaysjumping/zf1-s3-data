(function($){
'use strict';
var realtimeMode=window.APP_REALTIME_MODE==='workerman'?'workerman':'polling';
var pollInterval=Math.max(1000,Math.min(60000,parseInt(window.APP_POLL_INTERVAL,10)||5000));
var csrf=window.APP_CSRF,active=0,me=null,conv=[],lastSeq=0,pending=[],lastTyping=0,win={},pollTick=0,lastReadSeq={},syncTimer=null,syncBusy=false,lastBackgroundSync=0,lastSignalAt=0,wsReady=false,typingLast=0,lastConversationSignature=null;
function api(action,data,method,form){
 var options={url:'api/index.php?action='+encodeURIComponent(action),type:method||'GET',dataType:'json',headers:{'X-CSRF-Token':csrf}};
 if(form){options.data=data;options.processData=false;options.contentType=false;}
 else if(options.type==='POST'){options.data=JSON.stringify(data||{});options.contentType='application/json';}
 else options.data=data||{};
 return $.ajax(options).then(function(x){if(!x.ok)throw Error(x.error);return x.data;});
}
function err(x){alert((x.responseJSON&&x.responseJSON.error)||x.message||'Request failed');}
function esc(v){return $('<div>').text(String(v==null?'':v)).html();}
function uuid(){var s='',a='abcdefghijklmnopqrstuvwxyz0123456789';for(var i=0;i<30;i++)s+=a.charAt(Math.floor(Math.random()*a.length));return s;}
function conversation(id){for(var i=0;i<conv.length;i++)if(+conv[i].id===+id)return conv[i];return null;}
function title(c){return c.title||(c.kind==='private'?'Private chat #'+c.id:'Group #'+c.id);}
function list(){api('conversations').done(function(data){conv=data;renderConversations(data);}).fail(err);}
function messages(after){if(!active)return;var cid=active;api('messages',{conversation_id:cid,after:after||0}).done(function(rows){
 if(active!==cid)return;
 if(!after){$('#messages').empty();lastSeq=0;}
 $.each(rows,function(_,m){
  var existing=$('#messages [data-mid="'+m.id+'"]');if(existing.length){existing.find('.body').html(m.deleted_at?'<i>Message deleted</i>':esc(m.body));return;}
  var mine=me&&+m.sender_id===+me.id;
  var h='<div class="msg '+(mine?'mine':'')+'" data-mid="'+esc(m.id)+'"><div class="body">'+(m.deleted_at?'<i>Message deleted</i>':esc(m.body))+'</div><div class="meta">User #'+esc(m.sender_id)+' · '+esc(m.created_at)+(m.edited_at?' (edited)':'')+'</div>';
  if(!m.deleted_at)h+='<div class="msgActions">'+(mine?'<button class="edit">Edit</button>':'')+'<button class="react">React</button>'+(mine?'<button class="delete">Delete</button>':'')+'</div>';
  h+='<div class="reactions"></div></div>';
  $('#messages').append(h);lastSeq=Math.max(lastSeq,+m.seq);
 });
 if(rows.length){$('#messages').scrollTop($('#messages')[0].scrollHeight);if((lastReadSeq[cid]||0)<lastSeq){lastReadSeq[cid]=lastSeq;api('read',{conversation_id:cid,seq:lastSeq},'POST');}}
 }).fail(err);}
function members(){if(!active)return;var cid=active;api('members',{conversation_id:cid}).done(function(rows){
 if(active!==cid)return;var h='';$.each(rows,function(_,r){h+='<div class="member">'+esc(r.display_name)+' <small>'+esc(r.role)+'</small></div>';});$('#members').html(h);
 }).fail(err);}
function open(id){active=+id;lastSeq=0;$('#messages').empty();var c=conversation(active);$('#chatHeader').text(c?title(c):'Conversation #'+active);list();members();messages();}
function send(){if(!active)return;var body=$('#body').val();if(!$.trim(body)&&!pending.length)return;api('send',{conversation_id:active,body:body,uuid:uuid(),attachments:pending},'POST').done(function(){pending=[];$('#body').val('');$('#attachmentStatus').text('');messages();list();}).fail(err);}
function choose(kind){api('users').done(function(users){
 var names=[];$.each(users,function(_,u){names.push(u.id+': '+u.display_name);});
 var raw=prompt('Enter member IDs separated by commas:\n'+names.join('\n'));if(!raw)return;
 var ids=raw.split(','),title=kind==='group'?prompt('Group title','New group'):'';
 api('create',{kind:kind,members:ids,title:title},'POST').done(function(c){list();open(c.id);}).fail(err);
 }).fail(err);}
function popup(){if(!active)return;if(win[active])return;if(Object.keys(win).length>=3){alert('Maximum 3 quick chats');return;}
 var id=active,name=$('#chatHeader').text(),el=$('<div class="popup" data-cid="'+id+'"><h4><button class="close">×</button>'+esc(name)+'</h4><div class="log"></div><div class="sendbar"><input placeholder="Message"><button class="send">Send</button></div></div>');
 $('#popups').append(el);win[id]=el;refreshPopup(id);
}
function refreshPopup(id){if(!win[id])return;api('messages',{conversation_id:id}).done(function(rows){
 if(!win[id])return;var h='';$.each(rows,function(_,m){h+='<div class="entry '+(+m.sender_id===+me.id?'mine':'')+'">'+esc(m.deleted_at?'[deleted]':m.body)+'</div>';});
 win[id].find('.log').html(h).scrollTop(999999);
 });}
// Cross-tab leader election: ES5, Chrome 49 and Firefox 52 compatible.
// localStorage is NOT atomic; the server fences overlapping WS connections.
var ws=null,wsRetry=0,wsTimer=null,wsStopped=false;
var tabId=String(new Date().getTime())+'-'+Math.random().toString(36).slice(2);
var leaseKey=null,signalKey=null,leader=false,leaderTerm='',leaseMs=7000;
var electionTimer=null,lastSnapshot=0,storageOK=true;
function readLease(){try{return JSON.parse(localStorage.getItem(leaseKey)||'null');}catch(e){storageOK=false;return null;}}
function publishSignal(type,cid){if(!signalKey||!storageOK)return;try{localStorage.setItem(signalKey,JSON.stringify({type:type,cid:cid||0,source:tabId,nonce:Math.random(),at:new Date().getTime()}));}catch(e){storageOK=false;}}
function reconcile(cid){list();if(active&&(!cid||active===+cid)){messages(0);members();}if(cid&&win[+cid])refreshPopup(+cid);else $.each(win,function(id){refreshPopup(+id);});}
function closeWS(){if(wsTimer){clearTimeout(wsTimer);wsTimer=null;}if(ws){var old=ws;ws=null;old.onclose=null;try{old.close();}catch(e){}}}
function resign(){leader=false;leaderTerm='';wsReady=false;closeWS();}
function becomeLeader(term){if(leader&&leaderTerm===term)return;resign();leader=true;leaderTerm=term;wsRetry=0;wsConnect();reconcile(0);lastBackgroundSync=0;publishSignal('sync',0);}
function electionTick(){
 if(wsStopped||!leaseKey)return;
 if(!storageOK){if(!leader)becomeLeader('no-storage-'+tabId);return;}
 var now=new Date().getTime(),cur=readLease();
 if(leader){
  if(!cur||cur.id!==tabId||cur.term!==leaderTerm){resign();return;}
  try{localStorage.setItem(leaseKey,JSON.stringify({id:tabId,term:leaderTerm,expires:now+leaseMs}));}catch(e){storageOK=false;resign();}
  return;
 }
 if(cur&&cur.expires>now)return;
 // Stagger takeover attempts to avoid a synchronized herd.
 var delay=Math.floor(Math.random()*550);
 setTimeout(function(){
  if(wsStopped||leader||!storageOK)return;
  var check=readLease(),t=new Date().getTime();if(check&&check.expires>t)return;
  var term=tabId+'-'+t+'-'+Math.random().toString(36).slice(2);
  try{localStorage.setItem(leaseKey,JSON.stringify({id:tabId,term:term,expires:t+leaseMs}));}catch(e){storageOK=false;return;}
  var verify=readLease();if(verify&&verify.id===tabId&&verify.term===term)becomeLeader(term);
 },delay);
}
function wsConnect(){
 if(realtimeMode!=='workerman')return;
 if(wsStopped||!leader||!window.WebSocket||!me)return;
 var term=leaderTerm;
 api('ws-ticket',{},'POST').done(function(info){
  if(wsStopped||!leader||leaderTerm!==term)return;
  try{
   var socket=new WebSocket(info.url);ws=socket;
   socket.onopen=function(){if(!leader||leaderTerm!==term){socket.close();return;}socket.send(JSON.stringify({type:'auth',ticket:info.ticket}));};
   socket.onmessage=function(e){
    if(!leader||leaderTerm!==term)return;
    var msg;try{msg=JSON.parse(e.data);}catch(ignore){return;}
    if(msg.type==='ready'){wsReady=true;wsRetry=0;reconcile(0);publishSignal('sync',0);return;}
    if(msg.type==='hint'){reconcile(msg.conversation_id);publishSignal('hint',msg.conversation_id);}
    if(msg.type==='error'&&msg.reason==='SUPERSEDED'){resign();}
   };
   socket.onclose=function(){if(ws===socket){ws=null;wsReady=false;}if(!wsStopped&&leader&&leaderTerm===term)wsSchedule();};
   socket.onerror=function(){};
  }catch(e){wsSchedule();}
 }).fail(function(){wsSchedule();});
}
function wsSchedule(){if(wsStopped||!leader)return;if(wsTimer)clearTimeout(wsTimer);wsRetry=Math.min(wsRetry+1,6);wsTimer=setTimeout(wsConnect,Math.min(30000,1000*Math.pow(2,wsRetry)));}
function startElection(){
 leaseKey='messenger.leader.v1.'+me.company_id+'.'+me.id;
 signalKey='messenger.signal.v1.'+me.company_id+'.'+me.id;
 if(!window.localStorage){storageOK=false;becomeLeader('fallback-'+tabId);return;}
 electionTick();electionTimer=setInterval(electionTick,2000);
 if(window.addEventListener)window.addEventListener('storage',function(e){
  if(e.key===leaseKey&&leader){var l=readLease();if(!l||l.id!==tabId||l.term!==leaderTerm)resign();}
  if(e.key===signalKey&&e.newValue){try{var m=JSON.parse(e.newValue);if(m.source!==tabId){lastSignalAt=new Date().getTime();if(m.type==='hint'||m.type==='sync')reconcile(m.cid);}}catch(ignore){}}
 });
 if(window.addEventListener)window.addEventListener('beforeunload',function(){
  if(leader&&storageOK){var l=readLease();if(l&&l.id===tabId&&l.term===leaderTerm){try{localStorage.removeItem(leaseKey);}catch(ignore){}}}
  resign();
 });
}
// Adaptive synchronization. Only the elected tab performs routine background polling.
// Workerman healthy: no frequent REST polling; five-minute safety reconciliation.
// Workerman unavailable: leader falls back to adaptive polling automatically.
function pageVisible(){return !document.hidden;}
function localActivity(){return pageVisible()&&new Date().getTime()-lastActivity<30000;}
var lastActivity=new Date().getTime();
function backgroundInterval(){
 if(realtimeMode==='workerman'&&wsReady)return 300000;
 if(!pageVisible())return 60000;
 return localActivity()?pollInterval:Math.max(15000,Math.min(30000,pollInterval*4));
}
function syncBackground(){
 if(syncBusy)return;
 syncBusy=true;
 // A single leader checks conversations. Visible followers receive a lightweight signal.
 api('conversations').done(function(data){
  var signature=JSON.stringify($.map(data,function(c){return [String(c.id)+':'+String(c.seq)+':'+String(c.updated_at)+':'+String(c.member_count)];}));
  var changed=lastConversationSignature!==signature;
  lastConversationSignature=signature;conv=data;
  if(changed){renderConversations(data);if(active)messages(0);$.each(win,function(id){refreshPopup(+id);});publishSignal('sync',0);}
 }).always(function(){syncBusy=false;});
}
function renderConversations(data){var h='';$.each(data,function(_,c){h+='<div class="conv '+(+c.id===active?'active':'')+'" data-id="'+esc(c.id)+'"><b>'+esc(title(c))+'</b><small>'+esc(c.kind)+' · '+esc(c.member_count)+' members</small></div>';});$('#conversations').html(h);}
function scheduleBackground(){
 if(syncTimer)clearTimeout(syncTimer);
 syncTimer=setTimeout(function(){
  var now=new Date().getTime(),delay=backgroundInterval();
  if(leader&&now-lastBackgroundSync>=delay){lastBackgroundSync=now;syncBackground();}
  // If localStorage is disabled, tabs cannot coordinate: each falls back independently.
  if(!storageOK&&now-lastBackgroundSync>=delay){lastBackgroundSync=now;syncBackground();}
  scheduleBackground();
 },1000);
}
function onResume(){if(!me)return;reconcile(0);lastBackgroundSync=new Date().getTime();if(leader)publishSignal('sync',0);}
function init(){
 api('me').done(function(u){me=u;$('#who').text(u.display_name);list();startElection();scheduleBackground();
  if(document.addEventListener)document.addEventListener('visibilitychange',function(){if(pageVisible())onResume();});
  if(window.addEventListener)window.addEventListener('focus',function(){onResume();});
  $(document).on('mousemove keydown mousedown touchstart',function(){lastActivity=new Date().getTime();});
 }).fail(err);
}
$('#login').on('submit',function(e){e.preventDefault();var d={username:this.username.value,password:this.password.value};api('login',d,'POST').done(function(){location.reload();}).fail(function(){$('#loginError').text('Invalid login');});});
$('#logout').on('click',function(){wsStopped=true;resign();api('logout',{},'POST').done(function(){location.reload();}).fail(err);});
$('#conversations').on('click','.conv',function(){open($(this).data('id'));});
$('#newPrivate').on('click',function(){choose('private');});$('#newGroup').on('click',function(){choose('group');});
$('#send').on('click',send);$('#body').on('keydown',function(e){if(e.which===13&&!e.shiftKey){e.preventDefault();send();}});
$('#body').on('input',function(){if(active&&Date.now()-lastTyping>2500){lastTyping=Date.now();api('typing',{conversation_id:active},'POST');}});
$('#messages').on('click','.edit',function(){var box=$(this).closest('.msg'),mid=box.data('mid'),body=prompt('Edit message',box.find('.body').text());if(body!==null)api('edit',{message_id:mid,body:body},'POST').done(function(){messages();}).fail(err);});
$('#messages').on('click','.delete',function(){var mid=$(this).closest('.msg').data('mid');if(confirm('Delete this message?'))api('delete',{message_id:mid},'POST').done(function(){messages();}).fail(err);});
$('#messages').on('click','.react',function(){var mid=$(this).closest('.msg').data('mid'),emoji=prompt('Reaction: 👍 ❤️ 😂 🎉 👀','👍');if(emoji)api('reactions',{message_id:mid,emoji:emoji},'POST').done(function(){api('reactions',{message_id:mid}).done(function(r){var h='';$.each(r,function(_,v){h+=v.emoji+' '+v.total+' ';});$('#messages [data-mid="'+mid+'"] .reactions').text(h);});}).fail(err);});
$('#addMember').on('click',function(){if(!active)return;var id=prompt('User ID to add');if(id)api('group',{conversation_id:active,op:'add',user_id:id},'POST').done(function(){members();}).fail(err);});
$('#renameGroup').on('click',function(){if(!active)return;var t=prompt('New group name');if(t)api('group',{conversation_id:active,op:'rename',title:t},'POST').done(function(){list();}).fail(err);});
$('#search').on('keydown',function(e){if(e.which!==13)return;var q=$(this).val();api('search',{q:q}).done(function(rows){alert(rows.map(function(r){return '#'+r.conversation_id+' '+r.body;}).join('\n')||'No results');}).fail(err);});
$('#fileBtn').on('click',function(){$('#file').click();});
$('#file').on('change',function(){if(!this.files.length)return;var f=new FormData();f.append('file',this.files[0]);api('upload',f,'POST',true).done(function(x){$('#attachmentStatus').text('File #'+x.id+' quarantined; scanner approval required. Use Approved uploads after scanning.');}).fail(err);});
$('#approvedUploads').on('click',function(){api('my_uploads').done(function(rows){var choices=[],ids=[];$.each(rows,function(_,r){if(r.status==='approved'){choices.push(r.id+': '+r.original_name);ids.push(String(r.id));}});if(!choices.length){alert('No approved uploads yet. Run the ClamAV scanner.');return;}var selected=prompt('Enter approved file IDs separated by commas:\n'+choices.join('\n'));if(!selected)return;var arr=selected.split(','),chosen=[];$.each(arr,function(_,v){v=$.trim(v);if($.inArray(v,ids)!==-1)chosen.push(+v);});pending=chosen;$('#attachmentStatus').text(chosen.length+' approved attachment(s) selected for next message.');}).fail(err);});
$('#filesBtn').on('click',function(){if(!active)return;api('files',{conversation_id:active}).done(function(rows){var h='';$.each(rows,function(_,r){h+='<div><a href="api/index.php?action=download&id='+encodeURIComponent(r.id)+'">'+esc(r.original_name)+'</a></div>';});$('#files').html(h);}).fail(err);});
$('#popup').on('click',popup);
$('#popups').on('click','.close',function(){var el=$(this).closest('.popup'),id=el.data('cid');delete win[id];el.remove();});
$('#popups').on('click','.send',function(){var el=$(this).closest('.popup'),id=el.data('cid'),input=el.find('input');api('send',{conversation_id:id,body:input.val(),uuid:uuid()},'POST').done(function(){input.val('');refreshPopup(id);}).fail(err);});
if($('#conversations').length)init();
})(jQuery);
