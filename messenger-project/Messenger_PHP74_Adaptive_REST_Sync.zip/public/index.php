<?php
require dirname(__DIR__).'/app/bootstrap.php';
if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));
$logged=isset($_SESSION['uid']);
?><!doctype html>
<html><head><meta charset="utf-8"><title>Messenger Demo</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="assets/app.css"></head>
<body>
<?php if(!$logged): ?>
<div class="login"><h2>Messenger Demo</h2><p>Sign in with a seeded demo account.</p>
<form id="login"><input name="username" placeholder="Username" required><input name="password" type="password" placeholder="Password" required><button>Sign in</button></form><p id="loginError"></p></div>
<?php else: ?>
<header><strong>Messenger</strong><span id="who"></span><button id="logout">Sign out</button></header>
<div class="layout">
<aside><div class="asideHead"><button id="newPrivate">+ Private</button><button id="newGroup">+ Group</button></div>
<input id="search" placeholder="Search messages"><div id="conversations"></div></aside>
<main><div id="chatHeader">Select a conversation</div><div id="messages"></div><div id="typing"></div>
<div id="composer"><button id="fileBtn">Upload</button><button id="approvedUploads">Approved uploads</button><input type="file" id="file" hidden><textarea id="body" placeholder="Write a message"></textarea><button id="send">Send</button></div>
<div id="attachmentStatus"></div></main>
<section class="details"><h3>Conversation</h3><div id="members"></div><button id="addMember">Add member</button><button id="renameGroup">Rename group</button><button id="filesBtn">Files</button><button id="popup">Quick chat</button><div id="files"></div></section>
</div><div id="popups"></div>
<?php endif; ?>
<script>window.APP_CSRF=<?php echo json_encode($_SESSION['csrf']); ?>;window.APP_REALTIME_MODE=<?php echo json_encode(realtime_mode()); ?>;window.APP_POLL_INTERVAL=<?php echo (int)max(1000,min(60000,(int)($config['poll_interval_ms']??5000))); ?>;</script>
<script src="assets/jquery.min.js"></script><script src="assets/app.js"></script>
</body></html>
