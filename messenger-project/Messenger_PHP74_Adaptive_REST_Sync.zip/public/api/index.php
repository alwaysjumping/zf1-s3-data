<?php
require dirname(__DIR__,2).'/app/bootstrap.php';
set_exception_handler(function(Throwable $e){error_log((string)$e);fail('Server error',500);});
$action=(string)($_GET['action']??'');
$method=$_SERVER['REQUEST_METHOD']??'GET';
$d=$method==='POST'?input():$_GET;
if($action==='login' && $method==='POST'){
    csrf();
    $name=trim((string)($d['username']??''));$password=(string)($d['password']??'');
    $account=query('SELECT * FROM users WHERE username=? AND is_active=1',[$name])->fetch();
    if(!$account||!password_verify($password,$account['password_hash']))fail('Invalid credentials',401);
    session_regenerate_id(true);$_SESSION['uid']=(int)$account['id'];$_SESSION['csrf']=bin2hex(random_bytes(24));
    respond(['csrf'=>$_SESSION['csrf'],'user'=>['id'=>$account['id'],'name'=>$account['display_name'],'company_id'=>$account['company_id']]]);
}
if($action==='csrf'){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));respond(['csrf'=>$_SESSION['csrf']]);}
if($action==='logout' && $method==='POST'){csrf();$_SESSION=[];session_regenerate_id(true);respond(true);}
$u=user();
if($method==='POST')csrf();
if($action==='ws-ticket' && $method==='POST'){
    if(realtime_mode()!=='workerman')fail('WebSocket mode is disabled',403);
    // The ticket is an opaque one-time capability, never a session cookie.
    // Store only a SHA-256 hash; expires in 30 seconds.
    $ticket=bin2hex(random_bytes(32));
    query('INSERT INTO gateway_tickets(token_hash,user_id,company_id,session_hash,expires_at) VALUES(?,?,?,?,DATE_ADD(UTC_TIMESTAMP(), INTERVAL 30 SECOND))',
      [hash('sha256',$ticket),$u['id'],$u['company_id'],hash('sha256',session_id())]);
    respond(['ticket'=>$ticket,'url'=>(string)($config['workerman_ws_url']??'ws://127.0.0.1:2346')]);
}
if($action==='me')respond($u);
if($action==='users'){
    respond(query('SELECT id,display_name FROM users WHERE company_id=? AND is_active=1 AND id<>? ORDER BY display_name',[$u['company_id'],$u['id']])->fetchAll());
}
if($action==='conversations' && $method==='GET'){
    respond(query('SELECT c.id,c.kind,c.title,c.seq,c.updated_at,m.role,m.last_read_seq,
      (SELECT COUNT(*) FROM members a WHERE a.conversation_id=c.id AND a.left_at IS NULL) AS member_count
      FROM conversations c JOIN members m ON m.conversation_id=c.id AND m.user_id=? AND m.left_at IS NULL
      WHERE c.company_id=? ORDER BY c.updated_at DESC LIMIT 200',[$u['id'],$u['company_id']])->fetchAll());
}
if($action==='create' && $method==='POST'){
    $kind=(string)($d['kind']??'private');$targets=$d['members']??[];
    if(!in_array($kind,['private','group'],true)||!is_array($targets))fail('Invalid conversation');
    $ids=[(int)$u['id']];
    foreach($targets as $v)$ids[]=id($v);
    $ids=array_values(array_unique($ids));sort($ids);
    if($kind==='private' && count($ids)!==2)fail('Private chat needs two users');
    if($kind==='group' && (count($ids)<2||count($ids)>100))fail('Group size must be 2-100');
    $place=implode(',',array_fill(0,count($ids),'?'));
    $found=query('SELECT id FROM users WHERE company_id=? AND is_active=1 AND id IN ('.$place.')',array_merge([$u['company_id']],$ids))->fetchAll(PDO::FETCH_COLUMN);
    if(count($found)!==count($ids))fail('Member outside company or inactive',403);
    $title=trim((string)($d['title']??''));if(strlen($title)>150)fail('Title too long');
    $pdo=db();$pdo->beginTransaction();
    try{
        if($kind==='private'){
            $key=hash('sha256',$u['company_id'].':'.implode(':',$ids));
            query('INSERT INTO private_pairs(company_id,pair_key,conversation_id) VALUES(?,?,NULL) ON DUPLICATE KEY UPDATE pair_key=pair_key',[$u['company_id'],$key]);
            $pair=query('SELECT conversation_id FROM private_pairs WHERE company_id=? AND pair_key=? FOR UPDATE',[$u['company_id'],$key])->fetch();
            if(!empty($pair['conversation_id'])){$cid=(int)$pair['conversation_id'];member($u,$cid);$pdo->commit();respond(['id'=>$cid]);}
        }
        query('INSERT INTO conversations(company_id,kind,title,created_by) VALUES(?,?,?,?)',[$u['company_id'],$kind,$kind==='group'?$title:null,$u['id']]);
        $cid=(int)$pdo->lastInsertId();
        foreach($ids as $target)query('INSERT INTO members(conversation_id,user_id,role,first_seq) VALUES(?,?,?,1)',[$cid,$target,$target===$u['id']?'owner':'member']);
        if($kind==='private')query('UPDATE private_pairs SET conversation_id=? WHERE company_id=? AND pair_key=?',[$cid,$u['company_id'],$key]);
        event((int)$u['company_id'],$cid,'conversation.created',$cid);
        $pdo->commit();respond(['id'=>$cid]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
if($action==='members'){
    $cid=id($d['conversation_id']??0);$m=member($u,$cid);
    respond(query('SELECT x.user_id,x.role,x.joined_at,x.first_seq,v.display_name FROM members x JOIN users v ON v.id=x.user_id WHERE x.conversation_id=? AND x.left_at IS NULL ORDER BY x.role,x.joined_at',[$cid])->fetchAll());
}
if($action==='group' && $method==='POST'){
    $cid=id($d['conversation_id']??0);$m=member($u,$cid);mod($m);
    if($m['kind']!=='group')fail('Not a group');
    $op=(string)($d['op']??'');
    if($op==='rename'){
        $title=trim((string)($d['title']??''));if(!$title||strlen($title)>150)fail('Invalid title');
        query('UPDATE conversations SET title=?,updated_at=UTC_TIMESTAMP(6) WHERE id=?',[$title,$cid]);
    }elseif($op==='add'){
        $target=id($d['user_id']??0);
        if(!query('SELECT id FROM users WHERE id=? AND company_id=? AND is_active=1',[$target,$u['company_id']])->fetch())fail('Invalid user',403);
        $pdo=db();$pdo->beginTransaction();
        try{
            $conv=query('SELECT seq FROM conversations WHERE id=? FOR UPDATE',[$cid])->fetch();
            $count=(int)query('SELECT COUNT(*) FROM members WHERE conversation_id=? AND left_at IS NULL',[$cid])->fetchColumn();
            if($count>=100)fail('Group full');
            $existing=query('SELECT id FROM members WHERE conversation_id=? AND user_id=? FOR UPDATE',[$cid,$target])->fetch();
            if($existing)query('UPDATE members SET left_at=NULL,joined_at=UTC_TIMESTAMP(6),first_seq=?,last_read_seq=? WHERE id=?',[(int)$conv['seq']+1,(int)$conv['seq'],$existing['id']]);
            else query('INSERT INTO members(conversation_id,user_id,first_seq,last_read_seq) VALUES(?,?,?,?)',[$cid,$target,(int)$conv['seq']+1,(int)$conv['seq']]);
            event((int)$u['company_id'],$cid,'membership.changed',$target);$pdo->commit();
        }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
    }elseif($op==='remove'){
        $target=id($d['user_id']??0);
        if($target===(int)$m['user_id'])fail('Owner/admin self-removal not supported');
        $targetRow=query('SELECT role FROM members WHERE conversation_id=? AND user_id=? AND left_at IS NULL',[$cid,$target])->fetch();
        if(!$targetRow||$targetRow['role']==='owner'||($m['role']!=='owner'&&$targetRow['role']==='admin'))fail('Cannot remove privileged member');
        query('UPDATE members SET left_at=UTC_TIMESTAMP(6) WHERE conversation_id=? AND user_id=?',[$cid,$target]);
        event((int)$u['company_id'],$cid,'membership.changed',$target);
    }else fail('Invalid operation');
    respond(true);
}
if($action==='messages'){
    $cid=id($d['conversation_id']??0);$m=member($u,$cid);
    $after=isset($d['after'])?max(0,(int)$d['after']):0;$before=isset($d['before'])?max(0,(int)$d['before']):0;
    $params=[$cid,$m['first_seq']];$where='conversation_id=? AND seq>=?';
    if($after){$where.=' AND seq>?';$params[]=$after;$order='ASC';}
    else{$order='DESC';if($before){$where.=' AND seq<?';$params[]=$before;}}
    $rows=query('SELECT id,conversation_id,seq,sender_id,body,created_at,edited_at,deleted_at FROM messages WHERE '.$where.' ORDER BY seq '.$order.' LIMIT 50',$params)->fetchAll();
    if($order==='DESC')$rows=array_reverse($rows);
    respond($rows);
}
if($action==='send' && $method==='POST'){
    $cid=id($d['conversation_id']??0);$body=trim((string)($d['body']??''));
    $uuid=(string)($d['uuid']??'');$attachmentIds=$d['attachments']??[];
    if(!preg_match('/^[a-zA-Z0-9_-]{12,64}$/D',$uuid))fail('Invalid request identifier');
    if(strlen($body)>10000||($body==='' && !$attachmentIds)||!is_array($attachmentIds)||count($attachmentIds)>10)fail('Invalid message');
    $pdo=db();$pdo->beginTransaction();
    try{
        $m=member($u,$cid);
        $existing=query('SELECT id,conversation_id,body FROM messages WHERE sender_id=? AND client_uuid=?',[$u['id'],$uuid])->fetch();
        if($existing){
            if((int)$existing['conversation_id']!==$cid||$existing['body']!==$body)fail('UUID conflict',409);
            $pdo->commit();respond(['id'=>$existing['id'],'duplicate'=>true]);
        }
        $seq=(int)query('SELECT seq FROM conversations WHERE id=? FOR UPDATE',[$cid])->fetchColumn()+1;
        query('UPDATE conversations SET seq=?,updated_at=UTC_TIMESTAMP(6) WHERE id=?',[$seq,$cid]);
        query('INSERT INTO messages(conversation_id,seq,sender_id,client_uuid,body) VALUES(?,?,?,?,?)',[$cid,$seq,$u['id'],$uuid,$body]);
        $mid=(int)$pdo->lastInsertId();
        foreach($attachmentIds as $raw){
            $aid=id($raw);
            $r=query("UPDATE attachments SET message_id=? WHERE id=? AND uploader_id=? AND company_id=? AND status='approved' AND message_id IS NULL",[$mid,$aid,$u['id'],$u['company_id']]);
            if($r->rowCount()!==1)fail('Attachment not approved',403);
        }
        event((int)$u['company_id'],$cid,'message.created',$mid);
        $pdo->commit();respond(['id'=>$mid,'seq'=>$seq]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
if($action==='edit' && $method==='POST'){
    $mid=id($d['message_id']??0);$m=messageAccess($u,$mid);
    if((int)$m['sender_id']!==(int)$u['id']||$m['deleted_at'])fail('Cannot edit',403);
    $body=trim((string)($d['body']??''));if(!$body||strlen($body)>10000)fail('Invalid body');
    db()->beginTransaction();try{query('INSERT INTO message_revisions(message_id,editor_id,old_body) VALUES(?,?,?)',[$mid,$u['id'],$m['body']]);
    query('UPDATE messages SET body=?,edited_at=UTC_TIMESTAMP(6) WHERE id=?',[$body,$mid]);
    event((int)$u['company_id'],(int)$m['conversation_id'],'message.edited',$mid);db()->commit();}catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}respond(true);
}
if($action==='delete' && $method==='POST'){
    $mid=id($d['message_id']??0);$m=messageAccess($u,$mid);
    if((int)$m['sender_id']!==(int)$u['id']&&!in_array($m['role'],['owner','admin'],true))fail('Cannot delete',403);
    query('UPDATE messages SET body="",deleted_at=UTC_TIMESTAMP(6) WHERE id=? AND deleted_at IS NULL',[$mid]);
    event((int)$u['company_id'],(int)$m['conversation_id'],'message.deleted',$mid);respond(true);
}
if($action==='reactions'){
    $mid=id($d['message_id']??0);$m=messageAccess($u,$mid);
    if($method==='GET'){
        respond(query('SELECT emoji,COUNT(*) AS total FROM reactions WHERE message_id=? GROUP BY emoji ORDER BY emoji',[$mid])->fetchAll());
    }
    $emoji=(string)($d['emoji']??'');if(!in_array($emoji,['👍','❤️','😂','🎉','👀'],true))fail('Invalid reaction');
    $op=(string)($d['op']??'add');
    if($op==='remove')query('DELETE FROM reactions WHERE message_id=? AND user_id=? AND emoji=?',[$mid,$u['id'],$emoji]);
    else query('INSERT IGNORE INTO reactions(message_id,user_id,emoji) VALUES(?,?,?)',[$mid,$u['id'],$emoji]);
    event((int)$u['company_id'],(int)$m['conversation_id'],'reaction.changed',$mid);respond(true);
}
if($action==='read' && $method==='POST'){
    $cid=id($d['conversation_id']??0);$m=member($u,$cid);
    $seq=min((int)$m['seq'],max(0,(int)($d['seq']??0)));
    query('UPDATE members SET last_read_seq=GREATEST(last_read_seq,?) WHERE conversation_id=? AND user_id=?',[$seq,$cid,$u['id']]);
    respond(true);
}
if($action==='typing'){
    $cid=id($d['conversation_id']??0);member($u,$cid);
    if($method==='POST'){
        query('INSERT INTO typing(conversation_id,user_id,expires_at) VALUES(?,?,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 5 SECOND)) ON DUPLICATE KEY UPDATE expires_at=VALUES(expires_at)',[$cid,$u['id']]);respond(true);
    }
    respond(query('SELECT t.user_id,v.display_name FROM typing t JOIN users v ON v.id=t.user_id WHERE t.conversation_id=? AND t.user_id<>? AND t.expires_at>UTC_TIMESTAMP()',[$cid,$u['id']])->fetchAll());
}
if($action==='search'){
    $term=trim((string)($d['q']??''));if(strlen($term)<2||strlen($term)>100)fail('Search needs 2-100 characters');
    respond(query('SELECT x.id,x.conversation_id,x.seq,x.body,x.created_at FROM messages x
       JOIN conversations c ON c.id=x.conversation_id
       JOIN members m ON m.conversation_id=c.id AND m.user_id=? AND m.left_at IS NULL
       WHERE c.company_id=? AND x.seq>=m.first_seq AND x.deleted_at IS NULL AND x.body LIKE ?
       ORDER BY x.created_at DESC LIMIT 50',[$u['id'],$u['company_id'],'%'.$term.'%'])->fetchAll());
}
if($action==='sync'){
    respond(query('SELECT c.id,c.seq,m.last_read_seq FROM conversations c JOIN members m ON m.conversation_id=c.id
       WHERE m.user_id=? AND m.left_at IS NULL AND c.company_id=? ORDER BY c.id LIMIT 200',[$u['id'],$u['company_id']])->fetchAll());
}
if($action==='upload' && $method==='POST'){
    if(!isset($_FILES['file'])||!is_uploaded_file($_FILES['file']['tmp_name']))fail('No file');
    $f=$_FILES['file'];global $config;
    if($f['error']!==UPLOAD_ERR_OK||$f['size']<1||$f['size']>$config['max_upload_bytes'])fail('Invalid file size');
    $filename=basename(str_replace('\\','/',$f['name']));$stored=bin2hex(random_bytes(24));
    $dir=dirname(__DIR__,2).'/storage/quarantine';if(!is_dir($dir))mkdir($dir,0700,true);
    $path=$dir.'/'.$stored;if(!move_uploaded_file($f['tmp_name'],$path))fail('Upload failed',500);
    chmod($path,0600);
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($path);
    query('INSERT INTO attachments(company_id,uploader_id,original_name,storage_name,mime,size_bytes,sha256) VALUES(?,?,?,?,?,?,?)',
       [$u['company_id'],$u['id'],$filename,$stored,$mime,$f['size'],hash_file('sha256',$path)]);
    respond(['id'=>db()->lastInsertId(),'status'=>'quarantine']);
}
if($action==='my_uploads'){
    respond(query("SELECT id,original_name,status,size_bytes FROM attachments WHERE company_id=? AND uploader_id=? AND message_id IS NULL ORDER BY id DESC LIMIT 30",[$u['company_id'],$u['id']])->fetchAll());
}
if($action==='files'){
    $cid=id($d['conversation_id']??0);$m=member($u,$cid);
    respond(query("SELECT a.id,a.message_id,a.original_name,a.size_bytes,a.mime FROM attachments a
      JOIN messages x ON x.id=a.message_id
      WHERE x.conversation_id=? AND x.seq>=? AND a.status='approved' ORDER BY a.id DESC LIMIT 100",
      [$cid,$m['first_seq']])->fetchAll());
}
if($action==='download'){
    $aid=id($d['id']??0);
    $a=query("SELECT a.*,x.conversation_id FROM attachments a JOIN messages x ON x.id=a.message_id
        WHERE a.id=? AND a.company_id=? AND a.status='approved'",[$aid,$u['company_id']])->fetch();
    if(!$a)fail('File not found',404);messageAccess($u,(int)$a['message_id']);
    $path=dirname(__DIR__,2).'/storage/approved/'.$a['storage_name'];
    if(!is_file($path))fail('File missing',404);
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="attachment-'.(int)$aid.'"');
    header('Content-Length: '.filesize($path));readfile($path);exit;
}
fail('Unknown action',404);
