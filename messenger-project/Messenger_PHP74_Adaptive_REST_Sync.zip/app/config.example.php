<?php
return [
 'dsn'=>'mysql:host=127.0.0.1;port=3306;dbname=messenger_demo;charset=utf8mb4',
 'user'=>'root','password'=>'',
 'allow_demo_seed'=>false,
 'max_upload_bytes'=>20971520,
 'require_scan'=>true,
 'clamav_binary'=>'clamscan',
 'realtime_mode'=>'polling', // 'polling' (no Workerman) or 'workerman'
 'poll_interval_ms'=>5000, // Active leader polling interval; idle/hidden intervals adapt automatically
 'workerman_ws_url'=>'ws://127.0.0.1:2346', // for remote browsers use wss://your-host/ws
 'workerman_bind'=>'websocket://127.0.0.1:2346',
 'workerman_poll_seconds'=>1
];
