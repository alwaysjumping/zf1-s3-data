<?php
declare(strict_types=1);
ini_set('display_errors','0');
error_reporting(E_ALL);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');
session_name('MESSENGER_DEMO');
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);
session_start();
$configFile=__DIR__.'/config.php';
if (!is_file($configFile)) {http_response_code(503);exit('Copy app/config.example.php to app/config.php and configure MariaDB.');}
$config=require $configFile;
function db(): PDO {static $db=null;global $config;if(!$db){$db=new PDO($config['dsn'],$config['user'],$config['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);$db->exec("SET time_zone = '+00:00'");}return $db;}
function query(string $sql,array $args=[]):PDOStatement{$q=db()->prepare($sql);$q->execute($args);return $q;}
function user():array {if(empty($_SESSION['uid']))fail('Login required',401);$u=query('SELECT id,company_id,username,display_name FROM users WHERE id=? AND is_active=1',[(int)$_SESSION['uid']])->fetch();if(!$u)fail('Login required',401);return $u;}
function fail(string $message,int $code=400):void{http_response_code($code);header('Content-Type: application/json');echo json_encode(['ok'=>false,'error'=>$message]);exit;}
function respond($data):void{header('Content-Type: application/json');echo json_encode(['ok'=>true,'data'=>$data],JSON_INVALID_UTF8_SUBSTITUTE);exit;}
function input():array{$raw=file_get_contents('php://input');if(strlen($raw)>1048576)fail('Request too large',413);$d=json_decode($raw,true);return is_array($d)?$d:$_POST;}
function csrf():void{$expected=(string)($_SESSION['csrf']??'');$given=(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'');if($expected===''||$given===''||!hash_equals($expected,$given))fail('Invalid CSRF token',403);}
function id($v):int {if(!is_scalar($v)||!preg_match('/^[1-9][0-9]{0,17}$/D',(string)$v))fail('Invalid identifier');return (int)$v;}
function member(array $u,int $cid,bool $lock=false):array{
 $sql='SELECT m.*,c.company_id,c.kind,c.title,c.seq FROM members m JOIN conversations c ON c.id=m.conversation_id WHERE m.conversation_id=? AND m.user_id=? AND m.left_at IS NULL AND c.company_id=?';
 $m=query($sql.($lock?' FOR UPDATE':''),[$cid,$u['id'],$u['company_id']])->fetch();if(!$m)fail('Conversation access denied',403);return $m;
}
function mod(array $m):void{if(!in_array($m['role'],['owner','admin'],true))fail('Administrator required',403);}
function event(int $company,int $cid,string $type,int $entity):void{query('INSERT INTO outbox(company_id,conversation_id,event_type,entity_id) VALUES(?,?,?,?)',[$company,$cid,$type,$entity]);}
function messageAccess(array $u,int $mid):array{$m=query('SELECT x.*,c.company_id,mem.first_seq,mem.role FROM messages x JOIN conversations c ON c.id=x.conversation_id JOIN members mem ON mem.conversation_id=c.id AND mem.user_id=? AND mem.left_at IS NULL WHERE x.id=? AND c.company_id=? AND x.seq>=mem.first_seq',[$u['id'],$mid,$u['company_id']])->fetch();if(!$m)fail('Message access denied',403);return $m;}

function realtime_mode(): string {global $config; $mode=(string)($config['realtime_mode']??'polling');return in_array($mode,['polling','workerman'],true)?$mode:'polling';}
