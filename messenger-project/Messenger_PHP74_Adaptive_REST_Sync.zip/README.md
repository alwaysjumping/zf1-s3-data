> **Realtime selection:** Set `realtime_mode` to `polling` (no Workerman) or `workerman` in `app/config.php`. See [REALTIME_MODES.md](REALTIME_MODES.md).

# Pure PHP Messenger — Standalone Research/Test Project

This is an independent, inspectable **PHP 7.4 + MariaDB + HTML/CSS + ES5 + local jQuery + Workerman 4.1** implementation. It does not require ZF1, Node.js, or Redis. Composer is used only to install the Workerman dependency.

## Fast start (Windows XAMPP or local PHP)

1. Create a MariaDB database and import `database/schema.sql` using phpMyAdmin or `mysql -u root -p < database/schema.sql`.
2. Copy `app/config.example.php` to `app/config.php` and edit PDO credentials.
3. For demo setup only, change `allow_demo_seed` to `true`.
4. Run `php scripts/seed.php`. Test users: `alice`, `bob`, `carol`, `dave` (all password `demo1234`). Dave belongs to a different company.
5. For the PHP built-in server: `php -S 127.0.0.1:8080 -t public public/router.php`. Open `http://127.0.0.1:8080/`. Alternatively configure Apache DocumentRoot to the `public` directory.
6. Sign in as Alice, open a second private/incognito browser as Bob, and create a private or group chat. New messages are polled every 5 seconds.
7. For attachment scanning, set `clamav_binary` to the absolute `clamscan` executable path and run `php scripts/scan.php`. Files remain quarantined until approved. The uploader can then attach approved files by ID through the API; see API notes below.

**Workerman setup:** See `workerman/README.md`; start `php workerman/server.php start` on Linux/WSL2. The PHP website still works via REST polling if Workerman is not running.

## Features
- Session authentication, CSRF and active-account validation
- Company-scoped employee directory; cross-company member rejection
- Private conversations with pair deduplication, groups (2-100 members), add/remove/rename
- Membership-period visibility on rejoin
- Transactional sequence and durable outbox, client message UUID deduplication
- Messages, edit/soft-delete, reactions, read cursor, typing, history, search
- Attachment quarantine, SHA-256, ClamAV approval, authorized download
- Quick-chat popups (up to 3), polling sync
- Local jQuery and ES5-compatible frontend

## REST examples
All API calls use `public/api/index.php?action=...`. Responses use `{ok:true,data:...}`.
- GET `conversations`, `users`, `messages?conversation_id=1`, `messages?conversation_id=1&after=5`
- POST JSON `create`, `send`, `edit`, `delete`, `group`, `reactions`, `read`, `typing`
- GET `members?conversation_id=1`, `search?q=report`, `sync`, `files?conversation_id=1`, `download?id=1`
- POST multipart `upload` with `file` and `X-CSRF-Token` header.
- POST JSON `send` accepts `attachments:[approved_attachment_id]`. Approved unlinked files are linked transactionally to the message.
- POST `logout` ends the current session.

## Important differences from the ZF1 project
This is a **test/research implementation**, not full production feature parity.
- Realtime: Workerman 4.1 WebSocket hint gateway is included, with one-time DB tickets and REST polling fallback. Node.js gateway, multi-tab leader election and advanced change feed are **not included**.
- UI is a simplified independent frontend, not DHTMLX 3.5.
- Search uses SQL LIKE rather than a full-text index.
- File upload UI stages files, but linking an approved file currently requires an API request after scanning.
- Reactions render after clicking React; not batched on page load.
- Membership leave/remove UI is limited; backend group remove exists.
- Browser testing on Chrome 49 and Firefox 52 and live MariaDB integration testing are still needed.

## Security warning
Only run on localhost or a restricted staging network. Demo credentials are deliberately weak. Set `allow_demo_seed=false` after seeding. Use HTTPS, hardened session settings, request throttling, antivirus monitoring, authorization testing, and an external security review before real deployment. Keep `app/`, `database/`, `scripts/`, and `storage/` outside the webroot.

## Additional references

- `FEATURE_MATRIX.md` — precise ZF1 feature comparison and gaps
- `TEST_GUIDE.md` — manual test scenarios
- `START_WINDOWS_XAMPP.md` — Windows/XAMPP setup

## Multi-tab leader election
See `MULTITAB_LEADER_ELECTION.md`; apply `database/upgrade_multitab.sql`.


See `ADAPTIVE_SYNC.md` for the event-driven and adaptive background synchronization design.
