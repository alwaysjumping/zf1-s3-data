> **Realtime selection:** Set `realtime_mode` to `polling` (no Workerman) or `workerman` in `app/config.php`. See [REALTIME_MODES.md](REALTIME_MODES.md).

# Functional comparison with the ZF1 Messenger project

| Function | Pure PHP standalone | Difference / caveat |
|---|---|---|
| Private conversations | Implemented | Pair key prevents duplicate chats within company |
| Groups and 100-member cap | Implemented | Group UI uses prompts rather than DHTMLX controls |
| Company isolation | Implemented | Requires secure real employee/company mapping before deployment |
| Rejoin visibility | Implemented for message APIs | Simplified one-row member model; membership history not retained |
| Send and history | Implemented | Sequence allocated under conversation lock; history 50 per request |
| Idempotent send | Implemented | UUID conflict validation does not compare attachment list |
| Edit, soft delete, revisions | Implemented | Basic permissions and revision table |
| Reactions | Implemented | UI shows reactions on interaction; no batch refresh |
| Read cursors | Implemented | No full read-receipt UI per member |
| Typing indicators | Implemented | Five-second expiry, REST polling |
| Search | Implemented | LIKE query, 50-result cap |
| Upload/quarantine/scan | Implemented | Requires ClamAV CLI and manual scan invocation |
| Attachment download | Implemented | Approved-only, authorized, generic safe filename |
| Quick-chat | Implemented | Up to three panels; refresh by REST polling |
| Multi-tab leader election | Not implemented | Each tab polls independently |
| Workerman WebSocket | Implemented as reference | Workerman 4.1, ticket auth, MariaDB outbox hints, REST reconciliation; live test pending |
| Outbox publisher | Implemented as reference | Workerman polls MariaDB outbox; best-effort delivery |
| Phase 42 change feed | Not implemented | Snapshot and polling only |
| Gateway tokens | Implemented | One-time SHA-256 hashed 30-second tickets |
| Full DHTMLX integration | Not implemented | Intentionally replaced with plain HTML/CSS/jQuery |
| Chrome 49 / Firefox 52 | ES5-targeted | Requires manual real-browser testing |
| Production readiness | No | Demonstration and code research only |

The original ZF1 project and this standalone demo do **not** have complete functional parity. This table is the authoritative scope statement for the standalone release.
