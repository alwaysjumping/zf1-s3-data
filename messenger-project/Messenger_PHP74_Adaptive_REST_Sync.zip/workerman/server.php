<?php
/**
 * PHP 7.4 compatible Workerman 4.x server.
 * Install workerman/workerman ^4.1 into vendor/ (offline installation supported).
 * CLI: php workerman/server.php start
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$root=dirname(__DIR__);
$configFile=$root.'/app/config.php';
if(!is_file($configFile)){fwrite(STDERR,"Copy app/config.example.php to app/config.php\n");exit(1);}
$config=require $configFile;
$autoload=$root.'/vendor/autoload.php';
if(!is_file($autoload)){fwrite(STDERR,"Workerman missing: install workerman/workerman ^4.1 into vendor/\n");exit(1);}
require $autoload;
use Workerman\Worker;
use Workerman\Lib\Timer;

function gatewayDb(array $config) {
    return new PDO($config['dsn'],$config['user'],$config['password'],array(
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
        PDO::ATTR_TIMEOUT=>3
    ));
}
function gatewaySend($connection,array $data){
    $connection->send(json_encode($data,JSON_INVALID_UTF8_SUBSTITUTE));
}
function gatewayClose($connection,$reason){
    gatewaySend($connection,array('type'=>'error','reason'=>$reason));
    $connection->close();
}
function gatewayActive($db,$userId,$companyId){
    $q=$db->prepare('SELECT id FROM users WHERE id=? AND company_id=? AND is_active=1');
    $q->execute(array($userId,$companyId));return (bool)$q->fetchColumn();
}
function gatewayAuthorized($db,$companyId,$userId,$conversationId){
    $q=$db->prepare('SELECT 1 FROM members m JOIN conversations c ON c.id=m.conversation_id WHERE c.id=? AND c.company_id=? AND m.user_id=? AND m.left_at IS NULL');
    $q->execute(array($conversationId,$companyId,$userId));return (bool)$q->fetchColumn();
}
$server=new Worker((string)($config['workerman_bind']??'websocket://127.0.0.1:2346'));
$server->name='MessengerWorkerman';
// Single worker simplifies in-process connection fan-out; scale with an external pub/sub broker if needed.
$server->count=1;
$clients=array();
$cursor=0;
$server->onConnect=function($connection) use (&$clients){
    $connection->authenticated=false;
    $connection->authStarted=time();
    $connection->userId=0;$connection->companyId=0;$connection->sessionHash='';
    $clients[$connection->id]=$connection;
};
$server->onClose=function($connection) use (&$clients){unset($clients[$connection->id]);};
$server->onMessage=function($connection,$raw) use ($config,&$clients){
    if(strlen($raw)>4096){gatewayClose($connection,'FRAME_TOO_LARGE');return;}
    $msg=json_decode($raw,true);
    if(!is_array($msg)){gatewayClose($connection,'BAD_FRAME');return;}
    if(!$connection->authenticated){
        if(($msg['type']??'')!=='auth'||!is_string($msg['ticket']??null)||!preg_match('/^[a-f0-9]{64}$/D',$msg['ticket'])){
            gatewayClose($connection,'AUTH_REQUIRED');return;
        }
        try{
            $db=gatewayDb($config);
            $db->beginTransaction();
            $q=$db->prepare('SELECT * FROM gateway_tickets WHERE token_hash=? AND consumed_at IS NULL AND expires_at>UTC_TIMESTAMP() FOR UPDATE');
            $q->execute(array(hash('sha256',$msg['ticket'])));
            $row=$q->fetch();
            if(!$row||!gatewayActive($db,$row['user_id'],$row['company_id'])){
                $db->rollBack();gatewayClose($connection,'INVALID_TICKET');return;
            }
            $q=$db->prepare('UPDATE gateway_tickets SET consumed_at=UTC_TIMESTAMP() WHERE id=? AND consumed_at IS NULL');
            $q->execute(array($row['id']));
            $db->commit();
            $connection->userId=(int)$row['user_id'];$connection->companyId=(int)$row['company_id'];
            $connection->authenticated=true;
            $connection->sessionHash=(string)$row['session_hash'];
            // Server-side fencing: only one live socket per authenticated PHP session.
            // Different browser sessions are intentionally independent.
            foreach($clients as $other){
                if($other===$connection||!$other->authenticated)continue;
                if($other->sessionHash===$connection->sessionHash &&
                   $other->userId===$connection->userId && $other->companyId===$connection->companyId){
                    gatewayClose($other,'SUPERSEDED');
                }
            }
            gatewaySend($connection,array('type'=>'ready'));
        }catch(Throwable $e){if(isset($db)&&$db->inTransaction())$db->rollBack();error_log($e->getMessage());gatewayClose($connection,'AUTH_FAILED');}
        return;
    }
    if(($msg['type']??'')==='ping'){gatewaySend($connection,array('type'=>'pong'));return;}
    gatewaySend($connection,array('type'=>'error','reason'=>'UNKNOWN_ACTION'));
};
$server->onWorkerStart=function($worker) use (&$clients,&$cursor,$config){
    // Start from current high-water ID. REST snapshot covers pre-connect history.
    try{$db=gatewayDb($config);$cursor=(int)$db->query('SELECT COALESCE(MAX(id),0) FROM outbox')->fetchColumn();}
    catch(Throwable $e){error_log($e->getMessage());$cursor=0;}
    Timer::add(max(1,(int)($config['workerman_poll_seconds']??1)),function() use (&$clients,&$cursor,$config){
        try{
            $db=gatewayDb($config);
            $q=$db->prepare('SELECT id,company_id,conversation_id,event_type FROM outbox WHERE id>? ORDER BY id ASC LIMIT 200');
            $q->execute(array($cursor));
            $events=$q->fetchAll();
            foreach($events as $event){
                // Outbox IDs are not commit-order. REST snapshot reconciliation remains mandatory.
                $cursor=max($cursor,(int)$event['id']);
                foreach($clients as $connection){
                    if(!$connection->authenticated||(int)$event['company_id']!==$connection->companyId)continue;
                    if(!gatewayActive($db,$connection->userId,$connection->companyId)){
                        gatewayClose($connection,'ACCOUNT_DISABLED');continue;
                    }
                    if(!gatewayAuthorized($db,$connection->companyId,$connection->userId,$event['conversation_id']))continue;
                    // No message text, sender details or attachment metadata in realtime signals.
                    gatewaySend($connection,array('type'=>'hint','conversation_id'=>(string)$event['conversation_id']));
                }
            }
            foreach($clients as $connection){
                if(!$connection->authenticated&&time()-$connection->authStarted>10)gatewayClose($connection,'AUTH_TIMEOUT');
            }
        }catch(Throwable $e){error_log('Workerman polling: '.$e->getMessage());}
    });
};
Worker::runAll();
