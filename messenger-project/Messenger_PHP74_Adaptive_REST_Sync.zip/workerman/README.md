# Workerman Messenger gateway (PHP 7.4)

This standalone app now uses **Workerman 4.1.x** (PHP 7.4 compatible), not Workerman 5 (PHP 8.1+). The package does not bundle third-party Workerman code: install its approved Composer distribution in `vendor/` (offline installation is possible). No Node.js or Redis is required.

## Install / start

1. Keep PHP 7.4 CLI, PDO MySQL, JSON and PCNTL (for Linux daemon) installed. Workerman is intended for Linux for production; **Windows XAMPP can serve the PHP website but the Workerman server should run on Linux/WSL2 or a separate Linux VM**.
2. On a connected staging/build machine with PHP 7.4: `composer require workerman/workerman:^4.1` then transfer the `vendor/` directory and lockfile offline. On the offline target, run `composer install --no-dev --prefer-dist --no-interaction` only if all dependencies are already cached; otherwise transfer the complete vendor directory.
3. Import `database/schema.sql` for new installs; for existing installs apply `database/upgrade_workerman.sql` only.
4. Copy `app/config.example.php` to `app/config.php` and configure MariaDB, `workerman_bind`, and `workerman_ws_url`.
5. Run `php workerman/server.php start` from project root on Linux. To stop: `php workerman/server.php stop`.
6. Serve `public/` with Apache or PHP built-in server, log in and inspect browser WebSocket network messages. The first WebSocket message is an opaque one-time ticket, not a URL parameter.
7. For browser access from another machine, `ws://127.0.0.1:2346` is **not** suitable. Use a TLS reverse proxy to expose `wss://your-host/ws`, proxying to Workerman bound on 127.0.0.1. Update `workerman_ws_url` accordingly.

## Design
- PHP REST issues a one-time 30-second ticket after session + CSRF validation.
- Workerman validates ticket hash in MariaDB and atomically marks it used.
- A single Workerman worker polls committed MariaDB outbox events every second and sends small conversation invalidation hints to active, authorized company members.
- Browser refreshes data through existing REST APIs. 5-second REST fallback remains enabled to handle missed hints, gateway downtime and outbox transaction commit ordering.
- No message content is pushed through WebSocket. Never expose the Workerman listener directly to untrusted networks.

## Limitations
- **Not full parity** with the ZF1 implementation: no multi-tab leader election, no dedicated change feed, no distributed multi-worker fanout, no durable subscriber acknowledgment, and no full read-receipt UI.
- Outbox IDs are not commit-order cursors. Workerman hints are best effort; REST reconciliation is essential.
- Authentication and membership checks are database-backed, but existing sessions are not revoked instantly at the socket layer on logout; close the socket on logout and use short gateway sessions/periodic validation for production.
- Live MariaDB + Workerman + browser integration testing is required. The available environment runs PHP 8.4, so PHP 7.4 runtime execution has not been verified here; code is authored for PHP 7.4.
