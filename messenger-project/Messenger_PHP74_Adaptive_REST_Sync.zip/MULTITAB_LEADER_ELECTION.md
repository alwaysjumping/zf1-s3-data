# Multi-tab leader election (ES5)

The browser uses a per-user/company `localStorage` lease and a `storage` event channel. Lease heartbeat: 2 seconds; expiry: 7 seconds; randomized takeover delay: 0-550 ms. Only the elected leader initiates a Workerman socket. Followers use REST and respond to cross-tab hint signals. All tabs reconcile periodically every 5 seconds, so dropped hints do not cause permanent stale state.

## Server fencing
`gateway_tickets.session_hash` contains SHA-256 of the authenticated PHP session ID. On authentication, Workerman closes other sockets for the same user/company/session (`SUPERSEDED`). This protects against transient simultaneous leaders. **Separate PHP sessions (incognito windows or different browsers) are not forced to share a single connection.** The server uses a single Workerman worker; multi-worker deployment needs shared fencing state.

## Known limits
`localStorage` lease acquisition is not atomic; two tabs can briefly act as leader. Server fencing prevents persistent duplicate sockets but does not guarantee an exactly-once event delivery. REST remains authoritative. When storage is disabled, each tab may connect independently. Closing or freezing tabs may delay failover. A logout in one tab should be propagated through shared-session invalidation; the current UI does not immediately broadcast logout. Test in Chrome 49 and Firefox 52, including sleep, crash, reconnect, and multiple accounts.

## Upgrade
1. Import `database/upgrade_multitab.sql` after `upgrade_workerman.sql`.
2. Deploy updated `public/assets/app.js`, `public/api/index.php`, and `workerman/server.php` together.
3. Restart Workerman. Open 3 tabs in the same browser session, inspect WebSocket connections, then close the leader tab.
4. Confirm another tab takes over within ~7-9 seconds and all tabs receive messages.
