-- Apply to an EXISTING messenger_demo database; only once.
USE messenger_demo;
CREATE TABLE IF NOT EXISTS gateway_tickets (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 token_hash CHAR(64) NOT NULL,
 user_id INT UNSIGNED NOT NULL,
 company_id INT UNSIGNED NOT NULL,
 expires_at DATETIME NOT NULL,
 consumed_at DATETIME DEFAULT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_token_hash(token_hash),
 KEY idx_expiry(expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
