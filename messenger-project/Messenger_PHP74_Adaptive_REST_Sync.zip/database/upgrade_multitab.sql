-- Run once after upgrade_workerman.sql
ALTER TABLE gateway_tickets ADD COLUMN session_hash CHAR(64) NOT NULL DEFAULT '' AFTER company_id;
CREATE INDEX idx_gateway_session ON gateway_tickets(session_hash);
