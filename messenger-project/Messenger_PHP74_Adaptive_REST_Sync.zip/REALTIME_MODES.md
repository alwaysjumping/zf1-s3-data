# Select Messenger realtime mode in `app/config.php`

The same PHP 7.4/MariaDB database, users, conversations, REST APIs, message history, attachments and UI work in either mode.

## Without Workerman (default)

```php
'realtime_mode' => 'polling',
'poll_interval_ms' => 5000,
```

- Run only PHP 7.4 + MariaDB; **do not install or start Workerman**.
- Every browser tab independently fetches new messages and conversation changes over REST.
- The browser does not request `ws-ticket`, start leader election, or open WebSocket connections.
- The REST API refuses WebSocket ticket requests in polling mode.
- `database/schema.sql` is sufficient for a fresh installation; the Workerman upgrade scripts are not needed in this mode.

## With Workerman

```php
'realtime_mode' => 'workerman',
'poll_interval_ms' => 5000,
'workerman_ws_url' => 'ws://127.0.0.1:2346',
'workerman_bind' => 'websocket://127.0.0.1:2346',
```

- Apply `database/upgrade_workerman.sql` and `database/upgrade_multitab.sql` once, if not already applied.
- Install and start Workerman according to `workerman/README.md`.
- Browser tabs elect one WebSocket leader using localStorage; other tabs receive storage-event hints.
- REST synchronization continues as a fallback if Workerman disconnects.

## Changing modes

1. Edit `app/config.php` and change `realtime_mode`.
2. Reload **all open Messenger tabs**. The selected mode is injected into each page when it loads; an already-open tab will not automatically change modes.
3. When switching to Workerman, start the server and apply the two gateway migrations first.
4. When switching to polling, Workerman may be stopped; existing message data is preserved.

**Testing:** Open Alice and Bob in separate browsers, send messages, and confirm receipt within the configured polling interval in polling mode. In Workerman mode, test leader takeover by closing the leader tab. Browser and database integration tests must be performed in your environment.

**Security:** In production use WSS behind HTTPS and keep application files outside the public webroot. The frontend mode setting is not a security boundary; the API checks the server-side mode independently.
