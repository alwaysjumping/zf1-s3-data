# Adaptive REST Synchronization (PHP 7.4, ES5)

## Modes
- `realtime_mode=workerman`: when the elected leader WebSocket is healthy, only a five-minute safety REST reconciliation runs. WebSocket hints trigger REST fetches. If WS is down, the leader automatically polls.
- `realtime_mode=polling`: only the elected tab performs scheduled background REST requests, with other tabs notified via `localStorage` storage events.

## Intervals
- Active/visible: `poll_interval_ms` (default 5000 ms)
- Visible idle (no input for 30 s): 15-30 s
- Hidden: 60 s
- Connected Workerman: 300 s safety interval
- Tab focus / visibility resume: immediate reconciliation

## Known limitations
- `localStorage` coordination is best-effort, not atomic. Browser restrictions or private modes can cause each tab to poll.
- Follower tabs still call REST to retrieve authorized content after leader signals. This design shares event discovery, not message content.
- REST polling remains necessary without Workerman, including while idle, to discover incoming messages.
- Workerman outbox IDs are not commit ordered; periodic safety reconciliation remains important.
- A polling leader can fetch selected messages and popup content only for its own tab; followers fetch their own selected conversations when signaled.
- The browser must be reloaded after editing config.php.

## Manual tests
1. Polling mode: open three tabs, observe only one tab issuing routine conversation requests.
2. Leave all tabs idle for 40 seconds; verify reduced request frequency.
3. Hide tabs and verify 60-second intervals.
4. Close the leader; verify another tab takes over after lease expiration.
5. Workerman mode: check there are no 5-second REST polls when WebSocket is ready.
6. Stop Workerman; verify REST fallback. Restart it and verify WS reconnect.
7. Send/edit/delete a message from another account and check all tabs converge.
