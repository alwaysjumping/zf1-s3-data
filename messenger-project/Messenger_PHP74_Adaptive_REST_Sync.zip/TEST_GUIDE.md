> **Realtime selection:** Set `realtime_mode` to `polling` (no Workerman) or `workerman` in `app/config.php`. See [REALTIME_MODES.md](REALTIME_MODES.md).

# Hands-on test scenarios

1. Log in as `alice` in one browser and `bob` in a private browser. Create a private chat. Send and receive text; messages should appear within approximately five seconds.
2. Repeat private chat creation with the same two users. The existing conversation ID should be reused.
3. Create a group with Alice, Bob, and Carol; verify member count, rename, add and remove members.
4. Log in as `dave` from the other company. Attempt to join an Acme chat using its ID; the server must reject it.
5. Send a message, edit it, soft-delete it, and add a reaction. Verify edit and deletion changes after refresh.
6. Send duplicate `send` requests with the same `uuid`. Confirm the second returns `duplicate:true` and does not create a second message.
7. Remove a group member and re-add them; verify earlier messages are not returned after rejoin.
8. Upload a harmless test file under 20 MiB. It should remain quarantined. Configure ClamAV, run `php scripts/scan.php`, select the approved upload, send it and download from the Files panel.
9. Open three quick-chat panels. A fourth should be rejected. Check behavior after navigation and across tabs.
10. Disconnect the browser temporarily; reconnect and verify the five-second polling cycle recovers messages.

## Security tests

- Verify all mutating APIs reject missing or invalid `X-CSRF-Token`.
- Verify a user cannot download another company's attachment or access messages before their group join.
- Verify quarantined and rejected attachments cannot be linked or downloaded.
- Verify disabled users cannot use protected APIs after deactivation.

These are manual test cases, not a claim that the tests were executed on a live MariaDB server.


See `ADAPTIVE_SYNC.md` for the event-driven and adaptive background synchronization design.
