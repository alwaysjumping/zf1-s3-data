<?php
// CLI-only demo accounts. Do not expose this script through the webroot.
if(PHP_SAPI!=='cli')exit("CLI only\n");
require dirname(__DIR__).'/app/bootstrap.php';
if(empty($config['allow_demo_seed']))exit("Set allow_demo_seed=true in app/config.php before seeding.\n");
$accounts=[
 ['Acme','alice','Alice Johnson','demo1234'],
 ['Acme','bob','Bob Smith','demo1234'],
 ['Acme','carol','Carol Lee','demo1234'],
 ['Other Co','dave','Dave Miller','demo1234']
];
foreach($accounts as $a){
 query('INSERT INTO companies(name) VALUES(?) ON DUPLICATE KEY UPDATE name=name',[$a[0]]);
 $co=query('SELECT id FROM companies WHERE name=?',[$a[0]])->fetchColumn();
 query('INSERT INTO users(company_id,username,password_hash,display_name) VALUES(?,?,?,?)
  ON DUPLICATE KEY UPDATE display_name=VALUES(display_name)',[$co,$a[1],password_hash($a[3],PASSWORD_DEFAULT),$a[2]]);
 echo $a[1]." / ".$a[3]."\n";
}
