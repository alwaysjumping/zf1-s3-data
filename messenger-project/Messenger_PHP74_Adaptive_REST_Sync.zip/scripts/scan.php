<?php
// Run periodically via CLI; requires ClamAV. Quarantined files never auto-approve.
if(PHP_SAPI!=='cli')exit("CLI only\n");
require dirname(__DIR__).'/app/bootstrap.php';
$bin=(string)($config['clamav_binary']??'');
if(!$bin||!is_file($bin)||!is_executable($bin))exit("Set absolute executable clamav_binary path. Files remain quarantined.\n");
$root=dirname(__DIR__).'/storage';
if(!is_dir($root.'/approved'))mkdir($root.'/approved',0700,true);
$files=query("SELECT id,storage_name FROM attachments WHERE status='quarantine' ORDER BY id LIMIT 100")->fetchAll();
foreach($files as $f){
 $src=$root.'/quarantine/'.$f['storage_name'];
 if(!is_file($src))continue;
 $cmd=escapeshellarg($bin).' --no-summary -- '.escapeshellarg($src).' 2>&1';
 $output=[];$status=2;exec($cmd,$output,$status);
 if($status===0){
  if(rename($src,$root.'/approved/'.$f['storage_name'])){
   query("UPDATE attachments SET status='approved' WHERE id=? AND status='quarantine'",[$f['id']]);
   echo "Approved #".$f['id']."\n";
  }
 }elseif($status===1){
  query("UPDATE attachments SET status='rejected' WHERE id=? AND status='quarantine'",[$f['id']]);
  unlink($src);echo "Rejected #".$f['id']."\n";
 }else fwrite(STDERR,"Scanner error on #".$f['id']."; file remains quarantined\n");
}
