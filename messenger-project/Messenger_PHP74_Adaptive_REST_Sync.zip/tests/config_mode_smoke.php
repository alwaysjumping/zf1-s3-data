<?php
$root=dirname(__DIR__);
$config=require $root.'/app/config.example.php';
if(($config['realtime_mode']??'')!=='polling')exit("FAIL default mode\n");
$api=file_get_contents($root.'/public/api/index.php');
$js=file_get_contents($root.'/public/assets/app.js');
$page=file_get_contents($root.'/public/index.php');
$bootstrap=file_get_contents($root.'/app/bootstrap.php');
foreach(["realtime_mode()!=='workerman'",'ws-ticket'] as $token)if(strpos($api,$token)===false)exit("FAIL API mode guard\n");
foreach(["realtimeMode!=='workerman'",'pollInterval','function startElection()'] as $token)if(strpos($js,$token)===false)exit("FAIL JS mode guard\n");
if(strpos($page,'APP_REALTIME_MODE')===false||strpos($bootstrap,'function realtime_mode()')===false)exit("FAIL config propagation\n");
echo "PASS config modes and REST/WebSocket separation static checks\n";
