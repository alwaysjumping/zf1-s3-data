<?php
$root=dirname(__DIR__);
foreach(['app/bootstrap.php','app/config.example.php','database/schema.sql','public/index.php','public/api/index.php','public/assets/app.js','public/assets/jquery.min.js','public/assets/app.css','scripts/seed.php','scripts/scan.php'] as $f){if(!is_file($root.'/'.$f)){fwrite(STDERR,"Missing $f\n");exit(1);}}
$api=file_get_contents($root.'/public/api/index.php');
foreach(['login','conversations','create','group','messages','send','edit','delete','reactions','read','typing','search','sync','upload','files','download','my_uploads'] as $action){if(strpos($api,"\$action==='".$action."'")===false){fwrite(STDERR,"Missing endpoint $action\n");exit(1);}}
$js=file_get_contents($root.'/public/assets/app.js');
if(strpos($js,'=>')!==false||strpos($js,'const ')!==false||strpos($js,'let ')!==false){fwrite(STDERR,"ES6 syntax suspected\n");exit(1);}
echo "PASS standalone files, 17 endpoint checks and basic ES5 syntax screening\n";
