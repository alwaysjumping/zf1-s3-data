export const keyCollectionDefinition = 'dataResolver';
