# Canvas Studio — GrapesJS + PHP 7.4 + MariaDB

A standalone HTML visual designer with a dark, three-column workspace inspired by the reference screenshot. Uses open-source GrapesJS with vanilla JavaScript and pure PHP 7.4. No login or multiple-user system, Composer, npm, or build step.

## Quick start with XAMPP

1. Start **Apache** and **MySQL** (MariaDB) in XAMPP.
2. Check `config.php`. Defaults: `127.0.0.1:3306`, database `visual_designer`, user `root`, empty password.
3. In PowerShell, run once:

```powershell
cd E:\xampp7.4\htdocs\visual-designer-php74
E:\xampp7.4\php\php.exe setup.php
```

4. Open **http://localhost/visual-designer-php74/**.

The setup script creates the database and `projects` table if they do not exist. Running it again preserves existing projects. Alternatively, create the database in phpMyAdmin and import `database/schema.sql` into it.

For PHP's development server, run:

```powershell
E:\xampp7.4\php\php.exe -S localhost:8080 -t public
```

Then open **http://localhost:8080/**. `pdo_mysql` must be enabled (included with XAMPP).

## Using the designer

### Editor theme

Set `theme` in `config.php` to `'light'` or `'dark'`, then refresh the editor:

```php
'theme' => 'light', // Change to 'dark' for the original appearance.
```

The default is light. Missing or invalid theme values fall back to dark. This setting controls the editor interface, including panels and dialogs; your website content keeps its own styles.

- Drag a block from the left panel into the center canvas.
- Double-click text to edit it. Select elements to edit **Styles** or **Properties** on the right.
- Switch to **Layers** to navigate the element tree.
- Add pages with **+**; use **⋯** to rename and **×** to delete. At least one page is kept.
- Click **Sample pages** to browse twelve reference layouts: SaaS Landing, Creative Portfolio, Digital Agency, Restaurant & Café, Product Store, Conference & Event, Travel & Tours, Fitness Studio, Real Estate, Online Course, Community Nonprofit, and Photography Portfolio. Scroll the gallery to see the additional designs. Preview any sample or add it as a new editable page. Existing pages are preserved; click **Save design** to store the result in MariaDB. These are reference designs with placeholder content, prices, schedules, listings, and links; booking, checkout, enrollment, and donation processing are not implemented.
- Switch between Desktop, Tablet, and Mobile preview sizes.
- Use undo/redo, **Preview**, and **Import HTML** (replaces the current page's contents and CSS).
- Name the design and click **Save design**. The complete GrapesJS project, including all pages, is stored in MariaDB. Reopen it using the top dropdown.
- **Download HTML** exports the selected page as a standalone HTML file with embedded CSS. It does not export every page as a ZIP or rewrite cross-page links. Component JavaScript is not exported.

Save is manual; unsaved-change prompts help prevent losing work. Projects are shared by everyone who accesses this app. Concurrent saves use the last save. This is intended for local testing with trusted HTML. Image assets use URLs; no upload endpoint is included.

## Files

- `index.php` — XAMPP project-root entry point
- `public/index.php` — editor interface
- `public/api.php` — list, load, and save JSON API with prepared SQL statements
- `public/assets/app.js` — GrapesJS configuration and editor actions
- `public/assets/samples.js` — sample HTML and scoped responsive CSS; edit this file to customize or add sample layouts
- `public/assets/samples-more.js` — six additional layouts using the shared base stylesheet from `samples.js`
- `public/assets/samples.css` — sample gallery and preview styling for light and dark themes
- `public/assets/app.css` — dark workspace styling
- `app/database.php` — PDO MariaDB connection
- `config.php` — database configuration (also supports `DESIGNER_DB_*` environment variables)
- `setup.php` — command-line database setup
- `database/schema.sql` — table schema

GrapesJS **0.22.13** loads from unpkg, so internet access is needed. For offline use, place that version's `dist/grapes.min.js` and `dist/css/grapes.min.css` in `public/assets/vendor/` and replace the CDN URLs in `public/index.php` with `<?= $assetBase ?>/assets/vendor/grapes.min.js` and `<?= $assetBase ?>/assets/vendor/grapes.min.css`.

The API limits saved designs to 5 MB and validates project IDs, names, and session CSRF tokens. MariaDB's `max_allowed_packet` may impose a smaller limit (XAMPP often defaults to 1 MB). If needed, set `max_allowed_packet=8M` under `[mysqld]` in XAMPP's MySQL `my.ini` and restart MySQL. The editor reports this limit before attempting an oversized save. The session only supports request protection; it is not a login. For nonlocal hosting, set `public/` as the document root and restrict access to the shared editor.

## Verification

`tests/browser.cjs` is an optional Playwright smoke test covering drag/drop, panels, pages, database save/load, import, export, preview, and API validation. It creates a design named `Browser smoke test` and a screenshot at `tests/editor.png`. Requires Node.js, Playwright, and Chrome; these are only test dependencies, not application dependencies. Set `PLAYWRIGHT_PATH` if Playwright is outside normal module paths and `DESIGNER_URL` to test another address.

`tests/samples.cjs` verifies all twelve sample previews, adding pages, mobile layouts, duplicate names, preserved original styling, MariaDB save/load, and HTML export. It creates a design named `Sample gallery smoke test` and screenshots in `tests/`.

GrapesJS documentation: https://grapesjs.com/docs/getting-started.html
