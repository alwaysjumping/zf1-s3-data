<?php
// Copy this file to config.php and enter your hosting database credentials.
return [
    'theme' => 'light', // 'light' or 'dark'
    'host' => getenv('DESIGNER_DB_HOST') ?: '127.0.0.1',
    'port' => getenv('DESIGNER_DB_PORT') ?: '3306',
    'database' => getenv('DESIGNER_DB_NAME') ?: 'visual_designer',
    'username' => getenv('DESIGNER_DB_USER') ?: 'designer_user',
    'password' => getenv('DESIGNER_DB_PASSWORD') !== false ? getenv('DESIGNER_DB_PASSWORD') : 'CHANGE_ME',
];
