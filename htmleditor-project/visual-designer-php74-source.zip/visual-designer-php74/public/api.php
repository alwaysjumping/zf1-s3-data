<?php
declare(strict_types=1);
session_start();
require dirname(__DIR__) . '/app/database.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(array $data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

try {
$pdo = database();
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
    $id = $_GET['id'] ?? '';
    if (!is_string($id)) respond(['error' => 'Invalid project ID.'], 400);
    if ($id !== '') {
        if (!preg_match('/^[a-f0-9]{32}$/D', $id)) respond(['error' => 'Invalid project ID.'], 400);
        $query = $pdo->prepare('SELECT id, name, project_data, updated_at AS updatedAt FROM projects WHERE id = ?');
        $query->execute([$id]);
        $data = $query->fetch();
        if (!$data) respond(['error' => 'Design not found.'], 404);
        $data['project'] = json_decode($data['project_data'], true);
        unset($data['project_data']);
        respond($data);
    }
    $projects = $pdo->query('SELECT id, name, updated_at AS updatedAt FROM projects ORDER BY updated_at DESC, id')->fetchAll();
    respond(['projects' => $projects]);
}
if ($method !== 'POST') {
    header('Allow: GET, POST');
    respond(['error' => 'Method not allowed.'], 405);
}
if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) {
    respond(['error' => 'Session expired. Refresh the page before saving.'], 403);
}
// Release the session lock before writing the project.
session_write_close();
$raw = file_get_contents('php://input', false, null, 0, 5 * 1024 * 1024 + 1);
if ($raw === false || strlen($raw) > 5 * 1024 * 1024) respond(['error' => 'Design exceeds the 5 MB limit.'], 413);
$input = json_decode($raw, true);
if (!is_array($input) || !isset($input['project']) || !is_array($input['project'])) respond(['error' => 'Invalid project data.'], 400);
$id = $input['id'] ?? '';
if (!is_string($id) || ($id !== '' && !preg_match('/^[a-f0-9]{32}$/D', $id))) respond(['error' => 'Invalid project ID.'], 400);
$isNew = $id === '';
if ($isNew) $id = bin2hex(random_bytes(16));
$name = $input['name'] ?? '';
if (!is_string($name) || trim($name) === '' || preg_match_all('/./us', trim($name)) > 100) respond(['error' => 'Enter a project name of up to 100 characters.'], 400);
$data = ['id' => $id, 'name' => trim($name), 'updatedAt' => gmdate('c'), 'project' => $input['project']];
$encoded = json_encode($input['project'], JSON_UNESCAPED_SLASHES);
if ($encoded === false) respond(['error' => 'Project could not be encoded.'], 400);
$packetLimit = (int) $pdo->query('SELECT @@max_allowed_packet')->fetchColumn();
if (strlen($encoded) + strlen($data['name']) + 65536 >= $packetLimit) {
    respond(['error' => 'Design exceeds the MariaDB packet limit. Increase max_allowed_packet to at least 8M in MySQL configuration and restart MySQL.'], 413);
}
if ($isNew) {
    $query = $pdo->prepare('INSERT INTO projects (id, name, project_data) VALUES (?, ?, ?)');
    $query->execute([$id, $data['name'], $encoded]);
} else {
    $query = $pdo->prepare('SELECT id FROM projects WHERE id = ?');
    $query->execute([$id]);
    if (!$query->fetchColumn()) respond(['error' => 'Design not found.'], 404);
    $query = $pdo->prepare('UPDATE projects SET name = ?, project_data = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
    $query->execute([$data['name'], $encoded, $id]);
}
respond(['id' => $id, 'name' => $data['name'], 'updatedAt' => $data['updatedAt']]);
} catch (Throwable $error) {
    error_log($error->getMessage());
    respond(['error' => 'Database unavailable. Start MariaDB and run setup.php; check config.php.'], 500);
}
