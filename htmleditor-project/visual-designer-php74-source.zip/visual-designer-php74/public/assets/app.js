/* global grapesjs */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const status = message => { $('status').textContent = message; };
  if (!window.grapesjs) { status('Cannot load GrapesJS. Check your internet connection and reload.'); return; }
  const apiUrl = window.DESIGNER.api;
  let projectId = '', dirty = false, loading = false, saving = false, revision = 0;
  const initialHtml = `<header class="site-header"><a class="wordmark" href="#">STUDIO.</a><nav><a href="#features">Features</a><a href="#contact">Get in touch ↗</a></nav></header><section class="hero"><div class="eyebrow">YOUR NEXT GREAT IDEA STARTS HERE</div><h1>Make something<br><span>remarkable.</span></h1><p>A beautiful starting point for your next website. Edit this text, make it yours, and bring your ideas to life.</p><a class="cta" href="#features">Explore the possibilities →</a><div class="hero-art"><div class="orb"></div><span>Designed by you.<br>Built for the web.</span></div></section><section id="features" class="features"><div><span class="number">01 /</span><h2>Start with an idea</h2><p>Drag blocks onto your page and shape the layout you imagined.</p></div><div><span class="number">02 /</span><h2>Make it your own</h2><p>Choose your colors, refine your typography, and add your content.</p></div><div><span class="number">03 /</span><h2>Share your work</h2><p>Save your design and export a complete HTML page when you are ready.</p></div></section><footer id="contact">STUDIO. <span>Something great is on the way.</span></footer>`;
  const initialCss = `*{box-sizing:border-box}body{margin:0;color:#24233b;font-family:Arial,sans-serif;background:#faf9f6}a{color:inherit;text-decoration:none}.site-header{padding:28px 7%;display:flex;justify-content:space-between;align-items:center}.wordmark{font-size:24px;font-weight:900;letter-spacing:-1px}nav{display:flex;gap:28px;font-size:14px}.hero{padding:70px 7% 90px;position:relative;overflow:hidden;min-height:560px}.eyebrow{font-size:11px;letter-spacing:2px;font-weight:bold;color:#79728c}h1{font-size:72px;line-height:1.05;letter-spacing:-4px;margin:25px 0}h1 span{color:#7761d5}.hero p{max-width:410px;line-height:1.8;color:#777185;font-size:16px}.cta{display:inline-block;padding:17px 24px;background:#28233c;color:white;border-radius:8px;margin-top:20px;font-size:14px}.hero-art{position:absolute;right:7%;top:100px;width:30%;height:340px;border-radius:160px 160px 25px 25px;background:#e5def6;display:flex;align-items:center;justify-content:center}.orb{width:180px;height:180px;border-radius:50%;background:radial-gradient(circle at 30% 25%,#d0bbff,#8d6ccc 50%,#453168);box-shadow:20px 25px 40px #6c509b44}.hero-art span{position:absolute;bottom:30px;font-size:12px;text-align:center;line-height:1.5;color:#675384}.features{display:flex;gap:40px;padding:50px 7%;border-top:1px solid #e4dfeb}.features>div{flex:1}.number{font-size:12px;color:#8b75bc}.features h2{font-size:20px}.features p{font-size:14px;line-height:1.8;color:#777185}footer{padding:30px 7%;background:#28233c;color:white;font-weight:bold;display:flex;justify-content:space-between}footer span{font-size:12px;font-weight:normal;color:#b9adc9}@media(max-width:768px){h1{font-size:50px}.hero-art{position:relative;right:auto;top:auto;width:100%;margin-top:40px;height:260px}.hero{padding-top:35px}.features{flex-direction:column}nav{gap:15px}}@media(max-width:480px){h1{font-size:40px;letter-spacing:-2px}.site-header{padding:20px 5%}nav{font-size:12px}.hero{padding:30px 5%}.features{padding:30px 5%}footer{gap:15px}}`;
  const editor = grapesjs.init({
    container: '#gjs', height: '100%', width: 'auto', fromElement: false,
    nativeDnD: false,
    storageManager: false, panels: { defaults: [] },
    pageManager: { pages: [{ id: 'home', name: 'Home', component: initialHtml, styles: initialCss + `body{background:#130c20;color:#f5efff}.site-header{border-bottom:1px solid #ffffff12}.wordmark{color:#c983f5}.hero{background:radial-gradient(ellipse at 75% 45%,#51226555,transparent 65%)}h1 span{color:#c663ed}.hero p,.features p{color:#b0a2bd}.eyebrow{color:#c190de}.cta{background:#b345d0}.hero-art{background:linear-gradient(135deg,#72257d,#241237);border:1px solid #ac67c544}.orb{background:radial-gradient(circle at 30% 25%,#f1bdff,#bc54ce 50%,#511062);box-shadow:20px 25px 40px #12041e66}.hero-art span{color:#d7b5e7}.features{border-color:#ffffff18}.features h2{color:#f5efff}.number{color:#c983f5}footer{background:#0d0815}` }] },
    blockManager: { appendTo: '#blocks' },
    layerManager: { appendTo: '#layers' },
    selectorManager: { appendTo: '#selectors' },
    traitManager: { appendTo: '#traits' },
    styleManager: { appendTo: '#styles', sectors: [
      { name: 'Layout', open: true, buildProps: ['display', 'position', 'top', 'right', 'bottom', 'left', 'flex-direction', 'justify-content', 'align-items', 'gap'] },
      { name: 'Size', open: false, buildProps: ['width', 'height', 'max-width', 'min-height'] },
      { name: 'Spacing', open: false, buildProps: ['margin', 'padding'] },
      { name: 'Typography', open: false, buildProps: ['font-family', 'font-size', 'font-weight', 'letter-spacing', 'color', 'line-height', 'text-align', 'text-decoration'] },
      { name: 'Appearance', open: false, buildProps: ['background-color', 'border', 'border-radius', 'box-shadow', 'opacity'] }
    ] },
    assetManager: { upload: false },
    deviceManager: { devices: [{ name: 'Desktop', width: '' }, { name: 'Tablet', width: '768px', widthMedia: '992px' }, { name: 'Mobile', width: '375px', widthMedia: '480px' }] }
  });
  const blocks = [
    ['section', 'Section', '<section style="padding:50px 30px"><h2>A new section</h2><p>Add your content here.</p></section>'],
    ['columns', 'Two columns', '<div style="display:flex;gap:24px;padding:30px;flex-wrap:wrap"><div style="flex:1;min-width:200px;padding:20px"><h2>First column</h2><p>Your content here.</p></div><div style="flex:1;min-width:200px;padding:20px"><h2>Second column</h2><p>Your content here.</p></div></div>'],
    ['heading', 'Heading', '<h2 style="font-size:32px;padding:10px">Your heading</h2>'],
    ['text', 'Text', '<p style="padding:10px;line-height:1.7">Double-click to edit this text.</p>'],
    ['image', 'Image', { type: 'image' }],
    ['button', 'Button', '<a href="#" style="display:inline-block;background:#7965ed;color:white;padding:14px 24px;border-radius:8px">Click here</a>'],
    ['card', 'Card', '<div style="padding:30px;margin:20px;border:1px solid #ddd;border-radius:12px;background:white"><h3>Card title</h3><p>A little detail goes a long way.</p><a href="#">Learn more →</a></div>'],
    ['divider', 'Divider', '<hr style="border:0;border-top:1px solid #ddd;margin:30px 0">'],
    ['video', 'Video', { type: 'video' }],
    ['link', 'Link', '<a href="https://example.com" style="color:#7965ed">Visit website</a>']
  ];
  blocks.forEach(([id, label, content]) => editor.BlockManager.add(id, { label, category: 'Build your page', content }));
  editor.on('load', () => { renderPages(); status('Ready'); });
  const starterProject = editor.getProjectData();
  function renderPages() {
    const selected = editor.Pages.getSelected();
    $('page-list').replaceChildren();
    editor.Pages.getAll().forEach(page => {
      const row = document.createElement('div'); row.className = 'page-row' + (selected === page ? ' selected' : '');
      const select = document.createElement('button'); select.className = 'page-select'; select.textContent = page.getName() || page.getId();
      select.onclick = () => editor.Pages.select(page);
      const rename = document.createElement('button'); rename.textContent = '⋯'; rename.title = 'Rename page'; rename.setAttribute('aria-label', 'Rename ' + select.textContent);
      rename.onclick = () => { const name = prompt('Page name', page.getName()); if (name && name.trim()) { page.set('name', name.trim().slice(0, 100)); renderPages(); dirty = true; revision++; status('Unsaved changes'); } };
      const remove = document.createElement('button'); remove.textContent = '×'; remove.title = 'Delete page'; remove.setAttribute('aria-label', 'Delete ' + select.textContent); remove.disabled = editor.Pages.getAll().length === 1;
      remove.onclick = () => { if (confirm('Delete this page?')) { editor.Pages.remove(page); renderPages(); dirty = true; revision++; status('Unsaved changes'); } };
      row.append(select, rename, remove); $('page-list').append(row);
    });
    $('current-page').textContent = selected ? selected.getName() || selected.getId() : 'Canvas';
  }
  editor.on('page', renderPages);
  $('add-page').onclick = () => {
    const name = prompt('New page name', 'New page');
    if (!name || !name.trim()) return;
    const page = editor.Pages.add({ name: name.trim().slice(0, 100), component: '<main style="padding:60px;font-family:Arial,sans-serif"><h1>Your new page</h1><p>Drag blocks here to start building.</p></main>' });
    editor.Pages.select(page); dirty = true; revision++; status('Unsaved changes');
  };
  let previewSample = null;
  const samples = window.DESIGNER_SAMPLES || [];
  let galleryGeneration = 0;
  $('sample-gallery-description').textContent = 'Browse ' + samples.length + ' editable layouts. Add a sample as a new page, then make it your own.';
  function sampleDocument(sample) {
    return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;padding:0}' + sample.css + '</style></head><body>' + sample.html + '</body></html>';
  }
  function addSample(sample) {
    let name = sample.name;
    let number = 2;
    const names = editor.Pages.getAll().map(page => page.getName());
    while (names.includes(name)) name = sample.name + ' (' + number++ + ')';
    const page = editor.Pages.add({ name, component: sample.html, styles: sample.css });
    editor.Pages.select(page);
    renderPages(); dirty = true; revision++;
    $('sample-preview-dialog').close(); $('samples-dialog').close();
    status('Sample added · Save design to keep it');
  }
  samples.forEach(sample => {
    const card = document.createElement('article'); card.className = 'sample-card';
    const thumb = document.createElement('div'); thumb.className = 'sample-thumb'; thumb.dataset.sampleIndex = samples.indexOf(sample);
    const frame = document.createElement('iframe'); frame.srcdoc = sampleDocument(sample); frame.setAttribute('sandbox', ''); frame.setAttribute('aria-hidden', 'true'); frame.tabIndex = -1; frame.loading = 'lazy'; frame.title = sample.name + ' thumbnail'; thumb.append(frame);
    const details = document.createElement('div'); details.className = 'sample-details';
    const category = document.createElement('span'); category.className = 'sample-category'; category.textContent = sample.category;
    const heading = document.createElement('h3'); heading.textContent = sample.name;
    const description = document.createElement('p'); description.textContent = sample.description;
    const actions = document.createElement('div'); actions.className = 'sample-actions';
    const preview = document.createElement('button'); preview.textContent = 'Preview'; preview.onclick = () => {
      previewSample = sample; $('sample-preview-title').textContent = sample.name;
      $('sample-preview-dialog').showModal();
      // A fresh frame avoids stale rendering when a closed dialog is reopened.
      const frame = document.createElement('iframe'); frame.id = 'sample-preview-frame';
      frame.title = sample.name + ' preview'; frame.setAttribute('sandbox', '');
      frame.srcdoc = sampleDocument(sample); $('sample-preview-frame').replaceWith(frame);
    };
    const add = document.createElement('button'); add.textContent = 'Add page'; add.className = 'primary'; add.onclick = () => addSample(sample);
    actions.append(preview, add); details.append(category, heading, description, actions); card.append(thumb, details); $('sample-grid').append(card);
  });
  function refreshThumbnail(thumb) {
    if (thumb.dataset.generation === String(galleryGeneration)) return;
    thumb.dataset.generation = String(galleryGeneration);
    const previous = thumb.querySelector('iframe');
    const frame = previous.cloneNode(false); frame.loading = 'eager';
    frame.srcdoc = sampleDocument(samples[Number(thumb.dataset.sampleIndex)]); previous.replaceWith(frame);
  }
  const thumbnailObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => { if (entry.isIntersecting && $('samples-dialog').open) refreshThumbnail(entry.target); });
  }, { root: $('samples-dialog') });
  document.querySelectorAll('.sample-thumb').forEach(thumb => thumbnailObserver.observe(thumb));
  $('samples').onclick = () => {
    galleryGeneration++;
    $('samples-dialog').showModal();
    // Mount fresh previews as their cards enter the scrollable gallery.
    const bounds = $('samples-dialog').getBoundingClientRect();
    document.querySelectorAll('.sample-thumb').forEach(thumb => {
      const rect = thumb.getBoundingClientRect();
      if (rect.bottom > bounds.top && rect.top < bounds.bottom) refreshThumbnail(thumb);
    });
  };
  $('close-samples').onclick = () => $('samples-dialog').close();
  $('close-sample-preview').onclick = $('sample-preview-back').onclick = () => $('sample-preview-dialog').close();
  $('sample-preview-add').onclick = () => { if (previewSample) addSample(previewSample); };
  document.querySelectorAll('[data-left]').forEach(button => { button.onclick = () => {
    ['blocks', 'layers'].forEach(id => { $(id).hidden = id !== button.dataset.left; });
    document.querySelectorAll('[data-left]').forEach(tab => tab.classList.toggle('active', tab === button));
  }; });
  document.querySelectorAll('[data-right]').forEach(button => { button.onclick = () => {
    ['style-panel', 'traits-panel'].forEach(id => { $(id).hidden = id !== button.dataset.right; });
    document.querySelectorAll('[data-right]').forEach(tab => tab.classList.toggle('active', tab === button));
  }; });
  editor.on('update', () => { if (!loading) { dirty = true; revision++; status('Unsaved changes'); } });
  $('project-name').addEventListener('input', () => { dirty = true; revision++; status('Unsaved changes'); });
  window.addEventListener('beforeunload', event => { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
  async function request(url, options) {
    const response = await fetch(url, options);
    let data;
    try { data = await response.json(); } catch (_) { throw new Error('The server returned an invalid response. Check that PHP is running.'); }
    if (!response.ok) throw new Error(data.error || 'Request failed.');
    return data;
  }
  async function listProjects() {
    const data = await request(apiUrl);
    $('projects').replaceChildren(new Option('Open saved design…', ''));
    data.projects.forEach(project => $('projects').add(new Option(project.name, project.id)));
    $('projects').value = projectId;
  }
  function resetCanvas(project) {
    loading = true;
    try { editor.loadProjectData(project); editor.UndoManager.clear(); renderPages(); } finally { loading = false; }
    dirty = false; revision++;
  }
  $('save').onclick = async () => {
    if (saving) return;
    const name = $('project-name').value.trim();
    if (!name) { status('Enter a project name before saving.'); $('project-name').focus(); return; }
    saving = true; $('save').disabled = true; $('new').disabled = true; $('projects').disabled = true;
    const savedRevision = revision;
    status('Saving…');
    try {
      const data = await request(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': window.DESIGNER.csrf }, body: JSON.stringify({ id: projectId, name, project: editor.getProjectData() }) });
      projectId = data.id; dirty = revision !== savedRevision;
      status(dirty ? 'Saved · You have newer unsaved changes' : 'Design saved');
      try { await listProjects(); } catch (_) { status('Design saved · Could not refresh the project list'); }
    } catch (error) { status(error.message); }
    finally { saving = false; $('save').disabled = false; $('new').disabled = false; $('projects').disabled = false; }
  };
  $('projects').onchange = async () => {
    const id = $('projects').value;
    if (!id) return;
    if (dirty && !confirm('Discard unsaved changes and open this design?')) { $('projects').value = projectId; return; }
    $('projects').disabled = true; $('save').disabled = true; $('new').disabled = true;
    status('Opening design…');
    try { const data = await request(apiUrl + '?id=' + encodeURIComponent(id)); resetCanvas(data.project); projectId = data.id; $('project-name').value = data.name; status('Design opened'); }
    catch (error) { $('projects').value = projectId; status(error.message); }
    finally { $('projects').disabled = false; $('save').disabled = false; $('new').disabled = false; }
  };
  $('new').onclick = () => {
    if (dirty && !confirm('Discard unsaved changes and start a new design?')) return;
    resetCanvas(JSON.parse(JSON.stringify(starterProject)));
    projectId = ''; $('project-name').value = 'Untitled design'; $('projects').value = ''; dirty = true; status('New design · Save to keep it');
  };
  $('device').onchange = () => editor.setDevice($('device').value);
  $('undo').onclick = () => editor.UndoManager.undo();
  $('redo').onclick = () => editor.UndoManager.redo();
  $('preview').onclick = () => { const active = editor.Commands.isActive('preview'); editor[active ? 'stopCommand' : 'runCommand']('preview'); document.body.classList.toggle('previewing', !active); $('preview').textContent = active ? 'Preview' : 'Exit preview'; };
  $('export').onclick = () => {
    const title = $('project-name').value.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
    const html = '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + title + '</title><style>' + editor.getCss() + '</style></head>' + editor.getHtml() + '</html>';
    const url = URL.createObjectURL(new Blob([html], { type: 'text/html;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = ($('project-name').value.replace(/[^a-z0-9_-]+/gi, '-').replace(/^-|-$/g, '') || 'design') + '.html'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    status('HTML downloaded');
  };
  $('import').onclick = () => $('import-dialog').showModal();
  $('cancel-import').onclick = () => $('import-dialog').close();
  $('apply-import').onclick = () => { editor.setComponents($('html-input').value); editor.setStyle($('css-input').value); $('import-dialog').close(); dirty = true; revision++; status('HTML imported · Unsaved changes'); };
  listProjects().catch(error => status(error.message));
})();
