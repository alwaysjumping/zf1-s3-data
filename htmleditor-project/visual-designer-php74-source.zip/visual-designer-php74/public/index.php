<?php
declare(strict_types=1);
$config = require dirname(__DIR__) . '/config.php';
$theme = in_array($config['theme'] ?? 'dark', ['light', 'dark'], true) ? $config['theme'] : 'dark';
session_start();
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
?><!doctype html>
<?php
$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$base = rtrim(str_replace('\\', '/', dirname($scriptPath)), '/.');
if (realpath($_SERVER['SCRIPT_FILENAME']) === realpath(dirname(__DIR__) . '/index.php')) $base .= '/public';
$assetBase = htmlspecialchars($base, ENT_QUOTES, 'UTF-8');
?>
<html lang="en" data-theme="<?= $theme ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Canvas — HTML Visual Designer</title>
  <link rel="stylesheet" href="https://unpkg.com/grapesjs@0.22.13/dist/css/grapes.min.css">
  <link rel="stylesheet" href="<?= $assetBase ?>/assets/app.css">
  <link rel="stylesheet" href="<?= $assetBase ?>/assets/samples.css">
  <?php if ($theme === 'light'): ?>
  <link rel="stylesheet" href="<?= $assetBase ?>/assets/theme-light.css">
  <?php endif; ?>
</head>
<body>
  <header class="toolbar">
    <div class="brand"><span class="logo">✦</span><div>Canvas Studio<small>WEBSITE BUILDER</small></div></div>
    <input id="project-name" aria-label="Project name" value="My first website" maxlength="100">
    <select id="projects" aria-label="Saved projects"><option value="">Open saved design…</option></select>
    <button id="new">New</button>
    <button id="samples">Sample pages</button>
    <span class="divider"></span>
    <select id="device" aria-label="Preview device"><option>Desktop</option><option>Tablet</option><option>Mobile</option></select>
    <button id="undo" title="Undo">↶</button><button id="redo" title="Redo">↷</button>
    <button id="import">Import HTML</button>
    <button id="preview">Preview</button>
    <button id="export">Download HTML</button>
    <button id="save" class="primary">Save design</button>
  </header>
  <div class="statusbar"><span>Drag a block onto the page · Double-click text to edit · Select an element to style it</span><span id="status" role="status" aria-live="polite">Starting editor…</span></div>
  <main class="workspace">
    <aside class="left-panel">
      <div class="panel-heading"><span>Pages</span><button id="add-page" title="Add page" aria-label="Add page">＋</button></div>
      <div id="page-list"></div>
      <div class="tabs"><button class="active" data-left="blocks">Blocks</button><button data-left="layers">Layers</button></div>
      <div id="blocks"></div><div id="layers" hidden></div>
      <div class="panel-note">Drag blocks to build your page</div>
    </aside>
    <section class="canvas-area"><div class="canvas-heading"><span id="current-page">Home</span><span>VISUAL CANVAS</span></div><div id="gjs"></div></section>
    <aside class="right-panel">
      <div class="tabs"><button class="active" data-right="style-panel">Styles</button><button data-right="traits-panel">Properties</button></div>
      <div id="style-panel"><div id="selectors"></div><div id="styles"></div></div><div id="traits-panel" hidden><div id="traits"></div></div>
    </aside>
  </main>
  <dialog id="import-dialog">
    <h2>Import HTML &amp; CSS</h2><p>This replaces the current canvas. Save your design first if you want to keep it.</p>
    <label for="html-input">HTML</label><textarea id="html-input" spellcheck="false" placeholder="<section><h1>Hello world</h1></section>"></textarea>
    <label for="css-input">CSS</label><textarea id="css-input" spellcheck="false" placeholder="h1 { color: #635bff; }"></textarea>
    <div class="dialog-actions"><button id="cancel-import">Cancel</button><button id="apply-import" class="primary">Replace canvas</button></div>
  </dialog>
  <script>window.DESIGNER = {csrf: <?= json_encode($_SESSION['csrf']) ?>, api: <?= json_encode($base . '/api.php') ?>};</script>
  <dialog id="samples-dialog" class="samples-dialog">
    <div class="gallery-heading"><div><h2>A starting point for your next idea.</h2><p id="sample-gallery-description">Browse editable layouts. Add a sample as a new page, then make it your own.</p></div><button id="close-samples" aria-label="Close sample gallery">×</button></div>
    <div id="sample-grid" class="sample-grid"></div>
  </dialog>
  <dialog id="sample-preview-dialog" class="sample-preview-dialog">
    <div class="gallery-heading"><h2 id="sample-preview-title">Sample preview</h2><button id="close-sample-preview" aria-label="Close sample preview">×</button></div>
    <iframe id="sample-preview-frame" sandbox="" title="Sample page preview"></iframe>
    <div class="dialog-actions"><button id="sample-preview-back">Back to samples</button><button id="sample-preview-add" class="primary">Add this page</button></div>
  </dialog>
  <script src="https://unpkg.com/grapesjs@0.22.13/dist/grapes.min.js"></script>
  <script src="<?= $assetBase ?>/assets/samples.js"></script>
  <script src="<?= $assetBase ?>/assets/samples-more.js"></script>
  <script src="<?= $assetBase ?>/assets/app.js"></script>
</body>
</html>
