# Deploy Canvas Studio

The source package includes the PHP application, both editor themes, all twelve sample layouts, and the database schema. It contains no saved projects or local database credentials. The supplied `config.php` uses example credentials and must be edited before use.

## Requirements

- A PHP server compatible with PHP 7.4 and the `pdo_mysql` extension
- MariaDB or MySQL, with permission to create/import a table in your database
- PHP sessions enabled and a writable server session directory
- Internet access in the browser to load the pinned GrapesJS 0.22.13 library from unpkg

No Composer, npm, Node.js, or build process is needed to run the application.

## Deployment steps

1. Extract `visual-designer-php74-source.zip` and upload its `visual-designer-php74/` folder to your server.
2. Create a database and a database user using your hosting control panel. Grant the user SELECT, INSERT, and UPDATE access to the application's database. Use an account with table-creation permission when importing the schema.
3. Import `database/schema.sql` into that database using phpMyAdmin or your database tool. The schema creates the shared `projects` table and preserves an existing table.
4. Edit `config.php` with your database host, port, name, username, and password. Set `theme` to `light` or `dark`.
5. Set the website's document root to the uploaded **`visual-designer-php74/public/`** directory. Keep `config.php`, `app/`, and `database/` at their supplied locations, one level above `public/`.
6. Open the site's URL. Add a sample page, name the design, click **Save design**, refresh, and reopen it from the saved-design dropdown to check the deployment.

The database stores complete GrapesJS project JSON, including all pages and styles. The twelve sample layouts ship as JavaScript source and are available immediately; they do not require database seeding.

### Shared hosting with a fixed document root

If your hosting provider cannot point the document root at `public/`, upload the complete project into a subfolder such as `public_html/designer/` and open `/designer/`. The root `index.php` forwards to the editor. The included Apache `.htaccess` rules protect configuration, application, and database files; your server must honor those rules. For servers that do not support `.htaccess`, use the recommended `public/` document-root layout.

### Optional command-line setup

If your database account can create databases and tables, run from the uploaded folder:

```sh
php setup.php
```

For a database account limited to an existing database, use the manual schema import instead. The setup script is command-line-only. Its success message refers to the local XAMPP URL; open your actual deployment URL on the server.

## Configuration

```php
return [
    'theme' => 'light',
    'host' => '127.0.0.1',
    'port' => '3306',
    'database' => 'your_database_name',
    'username' => 'your_database_user',
    'password' => 'your_database_password',
];
```

Database settings can also be supplied through `DESIGNER_DB_HOST`, `DESIGNER_DB_PORT`, `DESIGNER_DB_NAME`, `DESIGNER_DB_USER`, and `DESIGNER_DB_PASSWORD` environment variables. The theme is selected in `config.php`.

For larger designs, set MariaDB's `max_allowed_packet` to at least `8M`. The API accepts up to 5 MB per save, subject to your PHP, proxy, web-server, and database limits. Set PHP `post_max_size` and any web-server request-body limits above 5 MB if you need to use the full save allowance.

## Access and existing data

There is no login or multiple-user system. Every visitor who can access the editor can view and modify its shared designs. If you want restricted access, deploy it on a private server or restrict access through your hosting/web-server settings.

Existing local designs are not included in the source archive. To migrate them, export your local `visual_designer.projects` table and import it into the deployment database. Back up any destination designs before importing data.

## Contents

- `public/` — editor, save/load API, styles, gallery, and all twelve sample layouts
- `app/database.php` — PDO database connection
- `database/schema.sql` — MariaDB table definition
- `config.php` and `config.example.php` — deployment configuration templates
- `index.php` — optional project-root entry point
- `setup.php` — optional command-line setup
- `README.md` — usage instructions and local XAMPP setup
- `DEPLOYMENT.md` — these deployment instructions

Browser test tools, screenshots, temporary files, and local project data are excluded from the source archive.
