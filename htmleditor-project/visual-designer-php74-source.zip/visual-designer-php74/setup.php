<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
try {
    $config = require __DIR__ . '/config.php';
    if (!preg_match('/^[a-zA-Z0-9_]+$/D', $config['database'])) throw new RuntimeException('Invalid database name.');
    $pdo = new PDO('mysql:host=' . $config['host'] . ';port=' . $config['port'] . ';charset=utf8mb4', $config['username'], $config['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $config['database'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . $config['database'] . '`');
    $pdo->exec((string) file_get_contents(__DIR__ . '/database/schema.sql'));
    echo "Database ready. Open http://localhost/visual-designer-php74/\n";
} catch (Throwable $error) {
    fwrite(STDERR, "Setup failed: " . $error->getMessage() . "\nStart MySQL/MariaDB in XAMPP and check config.php.\n");
    exit(1);
}
