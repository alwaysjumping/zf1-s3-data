# Industrial Dashboard Development with Apache ECharts and Grafana

**Project context:** ZF1, PHP 7.4, MariaDB, DHTMLX 3.5, jQuery, isolated intranet; legacy Chrome 49 and Firefox 52 support is an important constraint.

## 1. Overview

**Apache ECharts** is a JavaScript visualization library for building charts inside your own pages. It does not provide a complete dashboard editor, database integration, user management, or alerting system.

**Grafana** is a standalone dashboard and monitoring platform with a visual dashboard editor, data-source connections, time-range controls, permissions, and alerting.

The two technologies can coexist: ECharts for tightly integrated ZF1 business dashboards; Grafana for configurable technical monitoring and historical trends.

## 2. Recommended dashboard categories

| Dashboard | Core information | Users |
|---|---|---|
| Executive | Overall output, OEE, critical incidents | Management |
| Production | Targets vs actual, shifts, line output | Production teams |
| Machine status | Running, idle, stopped, warning, alarm, maintenance, offline | Operators |
| Factory overview | Floor plan, equipment icons, line status | Operations |
| Quality | Defects, rejection rates, inspection trends | Quality teams |
| Maintenance | Failures, work orders, MTBF, MTTR | Engineers |
| Energy | Power, consumption, peaks | Facilities |
| Inventory | Materials, WIP, finished goods | Logistics |
| Safety | Incidents and warnings | Safety teams |

Common features: filtering by factory/line/machine, drill-down, full-screen display, automatic refresh, historical comparisons, user permissions, export, and **last-updated timestamps**.

### 2.1 Important manufacturing metrics

- **Achievement rate:** actual production / target production × 100%.
- **OEE:** availability × performance × quality. Example: 90% × 95% × 98% = **83.79%**.
- **Availability:** runtime / planned production time.
- **Performance:** ideal cycle time × total units / runtime.
- **Quality:** good units / total units.
- **MTBF:** operating time / number of failures, using an agreed definition.
- **MTTR:** total repair time / number of repairs.

Document shift boundaries, planned stops, and definitions to keep metrics consistent.

## 2A. Industrial dashboards — detailed functional specification

### 2A.1 Purpose, scope, and terminology

An **industrial dashboard** is an operational view of production, equipment, quality, maintenance, safety, inventory, and energy information. It should answer four questions quickly: **What is happening? Is it normal? What changed? What should the responsible person investigate?**

A dashboard is not the PLC, safety controller, or SCADA control system. Its principal role is visibility, analysis, and workflow navigation. Any future machine-control actions require separate authorization, safety analysis, and industrial-system design.

Distinguish **live state** (latest trustworthy reading), **historical trend** (time-series samples), **business transaction** (work orders, batches, inspections), and **derived KPI** (OEE, scrap rate, attainment). Each has different data freshness and calculation rules.

### 2A.2 Intended users and operational questions

| User role | Primary questions | Recommended default view |
|---|---|---|
| Executive | Are factories meeting targets? Which sites need attention? | Cross-factory KPIs and trends |
| Plant manager | Which lines are behind plan? Why? | Plant and shift overview |
| Shift supervisor | What is running now? What stopped this shift? | Line status, hourly output, incidents |
| Operator | What is my machine doing? What is the current job? | Machine detail and active alarms |
| Maintenance engineer | Which assets are failing repeatedly? | Alarms, downtime, work orders, MTBF/MTTR |
| Quality engineer | Where are defects increasing? | Scrap, first-pass yield, defect Pareto |
| Energy/facility manager | Where is energy being consumed? | Power, kWh, intensity and peaks |
| Warehouse/planner | Are materials sufficient for the production plan? | Material availability and shortages |

Every view should be scoped to the user's authorized factories, departments, lines, and machines; filtering in the browser is not an authorization boundary.

### 2A.3 Suggested navigation hierarchy

```text
Company overview
  └─ Factory overview
      └─ Production area / workshop
          └─ Production line
              └─ Machine / asset
                  ├─ Live status and last reading
                  ├─ Process values and trends
                  ├─ Production orders / batches
                  ├─ Alarms and downtime
                  └─ Maintenance and quality history
```

Provide breadcrumbs, cross-filtering, and drill-down links. A manager should be able to move from a red KPI to the exact line, machine, time window, and underlying records that explain it.

### 2A.4 Dashboard catalog and detailed widget ideas

#### A. Executive and factory-wide overview

| Widget | Definition / behavior |
|---|---|
| Production attainment | Actual good units / planned good units for the selected period |
| Plant OEE | Aggregated OEE with explicit aggregation method and exclusions |
| On-time completion | Orders completed by committed deadline / eligible orders |
| Active incidents | Unresolved high-severity operational events |
| Factory comparison | Comparable output, attainment, downtime, and quality across sites |
| Trend vs previous period | Current shift/day/week compared with an equivalent prior period |
| Top losses | Pareto of downtime, speed loss, and quality loss |

Use consistent units and time zones. Avoid comparing factories with fundamentally different products using raw unit counts alone; normalized or product-specific metrics may be more meaningful.

#### B. Production dashboard

Display plan vs actual by shift, hour, day, line, product, order, and batch. Include good count, reject count, remaining target, estimated completion time, cycle time, bottleneck, and delayed orders. Show planned and unplanned downtime separately.

Useful charts: hourly output line/bar, target vs actual bullet/bar, shift comparison, production order progress, and downtime Pareto. Clicking an hour should open the related events and orders.

#### C. Machine and equipment status dashboard

Show each asset as a card or table row with machine identifier, line, current state, job/product, speed, latest sensor values, alarm severity, last-seen time, and state duration. Allow filters for asset type, state, location, and criticality.

**Recommended mutually exclusive primary states:** `RUNNING`, `IDLE`, `STOPPED`, `MAINTENANCE`, `OFFLINE`, and `UNKNOWN`. Represent `WARNING` and `ALARM` as **separate severity indicators**, because a running machine can also have a warning or alarm. If your business needs `ALARM` as a primary state, document its precedence rules clearly.

| Primary state | Meaning | Suggested indicator |
|---|---|---|
| RUNNING | Confirmed active production | Green |
| IDLE | Powered/available but not producing | Blue |
| STOPPED | Confirmed non-operating | Gray |
| MAINTENANCE | Maintenance mode or work order active | Orange |
| OFFLINE | Communications stale or disconnected | Dark gray |
| UNKNOWN | Insufficient or inconsistent evidence | Hatched / question mark |

Never silently classify an expired reading as `STOPPED`. Show **last seen**, **data age**, and **connection health** independently. Use labels/icons as well as color, with sufficient contrast.

#### D. Production-line and factory-floor overview

Represent production stages using a line diagram or floor-plan SVG. Each asset node can show primary state, alarm badge, output, and a link to machine details. Show material flow direction and bottlenecks; support zoom/pan and a simplified mode for old browsers. SVG positions and equipment IDs should be configured rather than hard-coded in JavaScript.

#### E. Quality dashboard

Track inspection counts, accepted/rejected units, first-pass yield, scrap rate, rework rate, defect categories, and quality trends by product/line/shift/batch. Include defect Pareto and drill-down to inspection records. Clearly distinguish **scrap** from **rework** and avoid double-counting re-inspected items.

#### F. Maintenance and reliability dashboard

Track planned preventive maintenance, overdue tasks, open work orders, downtime reasons, repeat failures, mean time between failures (MTBF), mean time to repair (MTTR), and maintenance backlog. Show maintenance due dates and asset history; separate scheduled maintenance from unplanned failure downtime.

#### G. Energy and utilities dashboard

Show instantaneous power (kW), cumulative energy (kWh), peak demand, compressed air/water/steam consumption, and energy per good unit. Compare shifts and lines, and annotate production changes so energy spikes are interpreted in context.

#### H. Inventory and material availability dashboard

Show stock by location, materials reserved for production, shortages, expected replenishment, work-in-progress (WIP), and finished goods. Link shortages to affected orders or production lines.

#### I. Safety and incident overview

Show reported incidents, near misses, open corrective actions, and training or inspection compliance where appropriate. Do **not** imply the dashboard replaces certified alarms, interlocks, emergency-stop systems, or other safety-critical controls.

### 2A.5 Manufacturing KPI definitions and formulas

All KPI definitions should be versioned and agreed upon with production/quality teams before implementation.

| KPI | Formula | Important interpretation |
|---|---|---|
| Production attainment | `actual good quantity / planned good quantity × 100%` | Define how revised plans and partial shifts are handled |
| Scrap rate | `scrapped units / total produced units × 100%` | Clarify whether rework is excluded |
| First-pass yield | `units passing first inspection / units inspected first time × 100%` | Track first attempt, not final disposition |
| Availability | `run time / planned production time` | Planned downtime exclusions must be consistent |
| Performance | `(ideal cycle time × total count) / run time` | Product mix and ideal cycle time matter |
| Quality | `good count / total count` | Use the same production window as the other factors |
| OEE | `availability × performance × quality` | Fractions, not percentages, are multiplied |
| MTBF | `eligible operating time / number of failures` | State asset population and observation window |
| MTTR | `total repair time / number of repairs` | Define whether waiting for parts is included |
| Energy intensity | `energy consumed (kWh) / good units` | Meaningful only with compatible product mix |

**OEE worked example:** planned production time = 480 min; unplanned stops = 48 min; run time = 432 min; ideal cycle time = 0.4 min/unit; total output = 1,000 units; good output = 980 units.

```text
Availability = 432 / 480 = 90.00%
Performance  = (0.4 × 1000) / 432 = 92.59%
Quality      = 980 / 1000 = 98.00%
OEE          = 0.90 × (400/432) × 0.98 = 81.67%
```

If the calculated performance exceeds 100%, investigate cycle-time definitions, counter accuracy, or data-window alignment before simply capping it. Aggregate OEE from underlying time/count measures where possible, rather than averaging machine percentages without weighting.

### 2A.6 Functional requirements for every dashboard

1. **Time selection:** live, current shift, previous shift, today, custom range; show the effective factory time zone and shift boundaries.
2. **Filters:** company, factory, area, line, machine, product, order, and status; enforce scope on the server.
3. **Drill-down:** every critical KPI or alarm links to underlying records and relevant time range.
4. **Refresh:** configurable per widget, with a visible timestamp and stale-data indication.
5. **Alert presentation:** severity, first/last occurrence, acknowledgment, owner, and resolution status.
6. **Usability:** responsive layouts, keyboard-accessible controls, readable wallboard mode, and color-independent status indicators.
7. **Customization:** optionally save per-role or per-user layout, widgets, filters, and refresh settings.
8. **Export:** CSV/Excel/PDF reports with applied filters, generation time, and access control.
9. **Auditability:** record who changed dashboards, thresholds, and acknowledgments.
10. **Failure behavior:** show partial failure explicitly; never silently present old readings as current.

### 2A.7 Example screen layout

```text
┌───────────────────────────────────────────────────────────────────────┐
│ FACTORY A / LINE 02        Shift: Day     Updated: 10:42:05          │
│ Filters: [Factory ▼] [Line ▼] [Shift ▼] [Time range ▼]              │
├────────────────┬────────────────┬────────────────┬───────────────────┤
│ Plan: 10,000   │ Good: 8,200    │ Attainment: 82%│ Active alarms: 2  │
├─────────────────────────────┬─────────────────────────────────────────┤
│ Output by hour              │ Machine status                          │
│ [Target vs actual chart]    │ M01 RUN  M02 IDLE  M03 OFFLINE         │
├─────────────────────────────┼─────────────────────────────────────────┤
│ Downtime reasons            │ Alarm / incident feed                   │
│ [Pareto chart]              │ [Severity, asset, time, status]         │
└─────────────────────────────┴─────────────────────────────────────────┘
```

### 2A.8 Data sources, ownership, and freshness

| Data class | Typical source | Typical dashboard expectation |
|---|---|---|
| Production orders and targets | ERP/MES/business MariaDB | Updated on transaction or scheduled sync |
| Machine state and sensors | PLC/SCADA/gateway | Seconds-level updates if infrastructure permits |
| Quality inspection | Quality module / lab system | Event-driven or periodic |
| Maintenance work orders | CMMS/business module | Event-driven or periodic |
| Energy meters | Meter gateway / historian | Seconds to minutes |
| Historical aggregates | Reporting/analytics tables | Minutes to hours depending on purpose |

These are illustrative expectations, **not guaranteed latency requirements**. Define per-metric sampling frequency, expected arrival delay, stale threshold, retention, and source of truth. Store both **measurement time** and **server receipt time** when possible; account for clock drift and delayed/offline uploads.

A practical event shape:

```json
{
  "machine_id": "M-003",
  "measured_at": "2026-10-12T10:42:00+09:00",
  "received_at": "2026-10-12T10:42:02+09:00",
  "state": "RUNNING",
  "alarm_severity": "WARNING",
  "temperature_c": 68.2,
  "rpm": 1180,
  "quality": "GOOD"
}
```

The `quality` field here refers to **reading validity**, not manufactured-product quality. Use an explicit schema name such as `reading_quality` in production to avoid ambiguity.

### 2A.9 Example logical data model (not a complete schema)

```text
factories(id, name, timezone)
production_lines(id, factory_id, name)
machines(id, line_id, code, asset_type, criticality)
production_orders(id, line_id, product_id, planned_qty, start_at, end_at)
production_counts(id, machine_id, order_id, good_qty, reject_qty, recorded_at)
machine_readings(id, machine_id, measured_at, received_at, temperature, rpm, ...)
machine_state_events(id, machine_id, state, started_at, ended_at, reason_code)
alarms(id, machine_id, severity, raised_at, acknowledged_at, cleared_at, ...)
maintenance_orders(id, machine_id, opened_at, closed_at, category, ...)
dashboard_definitions(id, owner_id, name, scope, layout_json, ...)
```

For time-series tables, plan indexes such as `(machine_id, measured_at)` and `(line_id, recorded_at)` based on real queries. Use appropriate partitions/retention/aggregation only after validating data volume and MariaDB capabilities. Separate transactional production tables from high-frequency telemetry ingestion if necessary.

### 2A.10 Update strategy and operational resilience

- **Small deployments:** ZF1 REST endpoints and controlled polling may be sufficient.
- **Workerman deployments:** push lightweight change notifications through WebSocket; fetch full data through REST when necessary.
- **Larger deployments:** use a dedicated ingestion/aggregation path and avoid running expensive raw telemetry queries for every viewer.

With multiple browser tabs, reuse your application's tab-coordination approach to avoid redundant network work where supported. After disconnect/reconnect, re-fetch an authoritative snapshot rather than assuming no updates were missed. When Workerman is unavailable, fall back to a documented polling policy if the deployment supports it. Keep data collection independent of dashboard availability.

### 2A.11 Dashboard designer — optional advanced feature

A reusable designer can let authorized administrators choose widgets, resize them, configure a **whitelisted** data source, select time ranges, and save layouts. Example widget types: KPI, line/bar chart, gauge, state grid, alarm list, table, floor-plan SVG, and markdown instructions.

Avoid allowing arbitrary SQL or JavaScript in user-defined widget configuration. Store versioned JSON definitions, validate them on the server, and expose only approved API endpoints or read-only reporting views. Include layout revisions, ownership, publication workflow, and role-based sharing.

### 2A.12 Nonfunctional requirements and acceptance criteria

| Area | Example acceptance criterion (to finalize with stakeholders) |
|---|---|
| Freshness | Machine card shows last-seen age; stale readings visibly change state |
| Accuracy | KPI values reconcile to authoritative production/quality records |
| Consistency | Same machine/time window produces the same KPI across views |
| Authorization | User cannot request data outside authorized factory scope |
| Reliability | A failed data source is visibly marked without corrupting other panels |
| Performance | Agreed panel load time met under realistic simultaneous viewers |
| Accessibility | State is identifiable without color alone |
| Audit | Changes to alarm thresholds and dashboard layouts are attributable |
| Legacy browsers | Tested functionality on required Chrome 49 / Firefox 52 versions |
| Offline operation | All required JS/CSS/fonts/plugins served locally |

**Suggested first release:** factory summary, line production, machine-state grid, alarm list, machine-detail trend, and a last-update/staleness indicator. Use realistic simulated data first, then integrate one line of actual data and validate all KPI formulas with operations staff.

---

## 3. Apache ECharts in detail

Official website: https://echarts.apache.org/  
Handbook: https://echarts.apache.org/handbook/en/  
Examples: https://echarts.apache.org/examples/en/index.html  
Repository: https://github.com/apache/echarts

ECharts supports line, bar, pie, gauge, scatter, heatmap, treemap, Sankey, and custom graphics. It runs in the browser and can use locally hosted assets.

**Advantages:** Complete UI flexibility, easy integration with ZF1/jQuery, reuse of application authentication and permissions, no separate ECharts server.

**You must build:** Dashboard layout and persistence, widget configuration, data-source bindings, alert logic, access control, and dashboard administration.

### 3.1 Architecture

```text
Browser (ZF1 page + ECharts + DHTMLX)
                   |
           jQuery AJAX / WebSocket
                   |
              ZF1 REST API
                   |
                 MariaDB
```

### 3.2 Example production chart

```html
<script src="/vendor/echarts/echarts.min.js"></script>
<div id="productionChart" style="width:100%;height:360px"></div>
<script>
var chart = echarts.init(document.getElementById('productionChart'));
chart.setOption({
  title: {text:'Production: Target vs Actual'},
  tooltip: {trigger:'axis'},
  legend: {data:['Target','Actual']},
  xAxis: {type:'category',data:['Mon','Tue','Wed','Thu','Fri']},
  yAxis: {type:'value'},
  series:[
    {name:'Target',type:'bar',data:[1000,1200,1100,1300,1500]},
    {name:'Actual',type:'bar',data:[950,1150,1050,1250,1400]}
  ]
});
</script>
```

### 3.3 Suggested ZF1 API

`GET /api/dashboard/production?line_id=3`

```json
{
  "success": true,
  "data": {
    "line_id": 3,
    "target": 10000,
    "actual": 8450,
    "good": 8200,
    "rejected": 250,
    "as_of": "2026-10-12T14:32:10+09:00"
  }
}
```

Validate request filters and enforce permissions server-side. Display measurement units and data freshness.

### 3.4 Updating data

ECharts itself does not provide WebSocket or polling transport. Use your application to retrieve data and call `chart.setOption(...)`. With REST polling, prevent overlapping requests, pause hidden dashboards, and handle failures. With Workerman, WebSocket events can trigger chart updates. Your existing MariaDB-based event/outbox architecture can remain in place; Redis is not assumed.

## 4. Grafana in detail

Official website: https://grafana.com/  
Documentation: https://grafana.com/docs/grafana/latest/  
MySQL data source: https://grafana.com/docs/grafana/latest/datasources/mysql/  
Alerting: https://grafana.com/docs/grafana/latest/alerting/  
Dashboard gallery: https://grafana.com/grafana/dashboards/

Grafana provides a standalone web UI with dashboard panels, time-range selectors, variables, data sources, users, folders, and alerts. Capabilities vary across OSS, Enterprise, and Cloud editions.

### 4.1 Architecture

```text
Browser --> Grafana server --> MariaDB read-only views
                           --> Optional telemetry/time-series store
```

Grafana has its own configuration database (often SQLite for smaller deployments; MySQL and PostgreSQL are alternatives), separate from the production data it queries.

### 4.2 Example MariaDB table

```sql
CREATE TABLE machine_metrics (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  machine_id BIGINT UNSIGNED NOT NULL,
  temperature DECIMAL(8,2) NULL,
  pressure DECIMAL(8,2) NULL,
  rpm INT UNSIGNED NULL,
  recorded_at DATETIME NOT NULL,
  INDEX idx_machine_recorded (machine_id, recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

Example Grafana panel query using its MySQL-compatible data source:

```sql
SELECT recorded_at AS time, temperature AS value
FROM machine_metrics
WHERE machine_id = 1
  AND $__timeFilter(recorded_at)
ORDER BY recorded_at;
```

`$__timeFilter()` is a **Grafana macro**, not standard MariaDB SQL. Configure a dedicated **read-only** account with access only to approved views or tables.

### 4.3 Dashboard designer

Typical workflow: create dashboard → add visualization → select data source → configure query → choose chart/stat/gauge/table/state timeline → set thresholds and units → save. Users can select time ranges and filter dashboards using variables.

### 4.4 Alerting

Grafana can evaluate thresholds, route notifications, and send webhooks to internal services. Define no-data behavior, severity, evaluation windows, and maintenance periods. **Grafana alerts must never replace safety-rated PLC protections, interlocks, or emergency-stop systems.**

### 4.5 Integration with ZF1

Options include links to Grafana, approved embedding, or integration with a common identity provider. Authentication, cookies, frame restrictions, and permissions need explicit design. Current Grafana versions generally require modern browsers; do not assume Chrome 49/Firefox 52 support.

## 5. Detailed comparison

| Feature | Apache ECharts | Grafana |
|---|---|---|
| Product | Charting library | Complete dashboard platform |
| Independent server | No | Yes |
| Dashboard designer | Not included | Included |
| PHP/ZF1 integration | Direct | Separate app / API / embedding |
| MariaDB integration | Through ZF1 API | MySQL-compatible data source |
| Authentication | Existing ZF1 | Grafana or integrated identity |
| Alerts | Custom | Built-in |
| Factory floor diagram | Custom SVG / graphics | Plugin or custom panel |
| Historical analysis | Build APIs/UI | Built-in time controls |
| UI customization | Very flexible | Within Grafana's model |
| Offline deployment | Local JS assets | Local service and dependencies |
| Legacy browsers | Pin/test compatible version | Modern browsers expected |
| License | Apache 2.0 | Grafana OSS: AGPLv3; verify edition |

## 6. Three architecture choices

**Option A: ECharts only**

```text
ZF1 Dashboard + ECharts --> ZF1 APIs --> MariaDB
```

Best when business integration, UI customization, and legacy-browser requirements dominate. More development work for dashboard management.

**Option B: Grafana only for dashboards**

```text
Grafana --> MariaDB / telemetry data source
ZF1 remains a separate business application
```

Best for quickly authoring monitoring dashboards and historical trends. Adds a separate server and authentication concerns.

**Option C: Hybrid**

```text
              Company intranet
               /           \
      ZF1 + ECharts       Grafana
           |                |
        ZF1 APIs      Read-only data source
           \                /
              Production data
```

Use ECharts for executive, production, and factory-specific screens; Grafana for technical telemetry, energy, and historical troubleshooting. Maintain distinct permissions and account for added operations overhead.

## 7. Machine monitoring requirements

Suggested machine states: `RUNNING`, `IDLE`, `STOPPED`, `WARNING`, `ALARM`, `MAINTENANCE`, `OFFLINE`.

A machine can be running while its data connection is offline: model **operating state** and **communication freshness** separately. Show text/icons as well as colors.

Machine detail views should include readings, trends, production totals, downtime causes, alarm history, maintenance, and last-seen timestamps. Factory overview can use an SVG floor plan with clickable equipment indicators.

## 8. Data volume and architecture

Possible data sources: existing MariaDB business records, PLC/SCADA telemetry via an approved collector, both, or simulated data during prototyping.

Illustrative scale: 5 factories × 20 lines × 30 machines = **3,000 machines**. At five measurements every five seconds: **180,000 values per minute** and **259.2 million values per day**. Values are not necessarily individual database rows; batching, rollups, and retention matter.

At higher volume, consider separating current machine state, transactional production records, and high-frequency historical telemetry. Benchmark before introducing a dedicated time-series database.

## 9. Offline and old-browser compatibility

- Host ECharts, fonts, icons, and other assets locally; avoid CDNs.
- Install Grafana and required plugins from locally transferred packages in the intranet.
- Verify exact ECharts versions on Chrome 49 and Firefox 52.
- Plan modern browsers for current Grafana unless testing proves otherwise.
- TypeScript can compile ES5 syntax, but cannot automatically polyfill missing browser APIs.
- Babel is optional for ordinary TypeScript-to-ES5 builds; Terser can minify compiled JS.
- Test production build artifacts, not just development source.

## 10. Optional visual dashboard builder for ZF1

If administrators must build their own dashboards, create a separate builder around ECharts:

- Widget palette: KPI, bar, line, gauge, status, alarm list, grid, floor plan.
- Drag/resize grid layout and preview mode.
- Approved data-source catalog, units, thresholds, and refresh intervals.
- MariaDB storage of layouts, revisions, templates, and publication status.
- View/edit/publish permissions and audit history.
- No arbitrary user-provided SQL or JavaScript in saved widgets.

## 11. Security and operations

1. Enforce permissions in ZF1 APIs and Grafana data-source access.
2. Use read-only Grafana database credentials.
3. Display data timestamps and stale-data warnings.
4. Limit query costs, panel counts, and refresh rates.
5. Separate dashboards from industrial control and safety systems.
6. Plan TLS, backups, audit logs, and controlled offline updates.
7. Treat PHP 7.4 and legacy browsers as end-of-life security risks.

## 12. Recommended proof of concept

**Phase 1:** Prepare sample data for one factory, three production lines, and 10–20 machines.

**Phase 2:** Build a ZF1/ECharts dashboard with production KPIs, target-vs-actual chart, machine tiles, and temperature history.

**Phase 3:** Install test Grafana, connect read-only MariaDB, and build equivalent panels.

**Phase 4:** Compare development effort, performance, browser compatibility, permissions, offline deployment, and maintenance.

**Phase 5:** Decide whether to adopt ECharts, Grafana, or both.

### Acceptance checklist

- [ ] Correct KPIs and measurement units
- [ ] Factory/line/machine filters
- [ ] Drill-down to details
- [ ] Last-updated and stale-data indicators
- [ ] Server-side authorization
- [ ] Acceptable query performance under load
- [ ] Offline functionality
- [ ] Verified browser compatibility
- [ ] Documented alert and missing-data behavior
- [ ] Clear separation from safety controls

## 13. Open decisions

1. Will data come from MariaDB, PLC/SCADA, or both?
2. Is refresh required every few seconds or every minute?
3. Must Grafana also support Chrome 49 and Firefox 52?
4. Will administrators design dashboards, or developers build fixed pages?
5. How many factories, machines, data points, and concurrent viewers are expected?
6. Should alerting live in Grafana, ZF1 notifications, or both?
7. Is a hybrid architecture acceptable?

## 14. References

- https://echarts.apache.org/
- https://echarts.apache.org/handbook/en/
- https://echarts.apache.org/examples/en/index.html
- https://github.com/apache/echarts
- https://grafana.com/
- https://grafana.com/docs/grafana/latest/
- https://grafana.com/docs/grafana/latest/datasources/mysql/
- https://grafana.com/docs/grafana/latest/alerting/
- https://grafana.com/grafana/dashboards/

---

**Conclusion:** ECharts gives precise control over dashboards integrated into ZF1; Grafana provides ready-made monitoring dashboards and alerting. Prototype both on representative data before choosing a long-term approach.
