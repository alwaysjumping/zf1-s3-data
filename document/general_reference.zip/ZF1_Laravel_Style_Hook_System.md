# Laravel-Style Extension System for Zend Framework 1

**Target:** Zend Framework 1, PHP 7.4, MariaDB, modular applications  
**Design:** Class-based event dispatcher + listeners for actions; ordered pipeline for filters  
**Public API:** `S3_Event::dispatch()` / `S3_Event::listen()` and `S3_Pipeline::through()` — no global hook functions.

## 1. Executive summary

Laravel typically uses **events and listeners** to react to completed operations, and a **pipeline** to transform data through ordered stages. These are related but distinct patterns. In ZF1, implement both with small PHP 7.4-compatible classes. This avoids adding a Laravel dependency and allows a gradual migration from `S3_Hook`.

| Existing WordPress-style concept | Proposed ZF1 equivalent | Purpose |
|---|---|---|
| `S3_Hook::add_action()` | `S3_Event::listen()` | Register a listener |
| `S3_Hook::do_action()` | `S3_Event::dispatch()` | Announce a domain event |
| `S3_Hook::add_filter()` | Pipeline stage registration | Register transformation |
| `S3_Hook::apply_filters()` | `S3_Pipeline::through()` | Transform a value |

**Recommendation:** Keep events as immutable-in-intent notifications, not as an implicit value-changing filter mechanism. For validation/authorization, use explicit services and fail closed; do not rely on optional notification listeners.

## 2. Architecture

```text
Module config.json ----> installer/validator ----> compiled registry PHP
                                                  |
ZF1 Bootstrap ------------------------------------+--> S3_Event::loadRegistry()
                                                  |
Document_Service --> S3_Event::dispatch(DocumentSaved) --> listener A
                                                     \--> listener B

Document_Service --> S3_Pipeline::through(data, stages) --> validated/transformed data
```

A module's configuration is the source of truth. The installer validates declarations and compiles enabled modules into a registry. Normal requests load the compiled registry rather than querying all modules or constructing all handlers.

## 3. Directory layout

```text
application/
  Bootstrap.php
  services/Document.php
  events/DocumentSaved.php
  modules/notification/listeners/DocumentSaved.php
  modules/document/pipeline/NormalizeTitle.php
library/S3/
  Event.php
  Event/Dispatcher.php
  Event/ListenerResolver.php
  Pipeline.php
  Pipeline/StageInterface.php
data/cache/events.php
modules/notification/config.json
tests/unit/EventDispatcherTest.php
tests/unit/PipelineTest.php
```

The examples below use ZF1-style underscore class names and can be autoloaded through `Zend_Loader_Autoloader` if class-to-file mappings match the directory layout. For application/module-specific classes, configure appropriate autoloading or explicit includes.

## 4. Domain event class

`application/events/DocumentSaved.php`:

```php
<?php
class Application_Event_DocumentSaved
{
    private $documentId;
    private $data;

    public function __construct($documentId, array $data)
    {
        $this->documentId = (int) $documentId;
        $this->data = $data;
    }

    public function getDocumentId() { return $this->documentId; }
    public function getData() { return $this->data; }
}
```

Event classes make parameter contracts discoverable and avoid mistakes with string hook names and argument order. Treat event payloads as read-only; listeners should not mutate business data by reference.

## 5. Minimal event dispatcher

`library/S3/Event/Dispatcher.php`:

```php
<?php
class S3_Event_Dispatcher
{
    private $listeners = array();
    private $sequence = 0;

    public function listen($eventClass, $callback, $priority = 10)
    {
        if (!is_string($eventClass) || $eventClass === '') {
            throw new InvalidArgumentException('Invalid event class');
        }
        if (!is_callable($callback)) {
            throw new InvalidArgumentException('Listener must be callable');
        }
        $this->listeners[$eventClass][] = array(
            'callback' => $callback,
            'priority' => (int) $priority,
            'sequence' => $this->sequence++
        );
        usort($this->listeners[$eventClass], function ($a, $b) {
            if ($a['priority'] === $b['priority']) {
                return $a['sequence'] <=> $b['sequence'];
            }
            return $a['priority'] <=> $b['priority'];
        });
    }

    public function dispatch($event)
    {
        if (!is_object($event)) {
            throw new InvalidArgumentException('Event must be an object');
        }
        $name = get_class($event);
        foreach (isset($this->listeners[$name]) ? $this->listeners[$name] : array() as $entry) {
            call_user_func($entry['callback'], $event);
        }
    }
}
```

This is the intentionally small core. It executes synchronously, in ascending priority order, with stable ordering for equal priorities. It does not silently catch exceptions. Add logging, queues, or transaction-aware delivery as separate policies rather than hiding them inside the dispatcher.

## 6. Static facade matching your preferred API

`library/S3/Event.php`:

```php
<?php
class S3_Event
{
    private static $dispatcher;

    public static function setDispatcher(S3_Event_Dispatcher $dispatcher)
    {
        self::$dispatcher = $dispatcher;
    }

    public static function dispatcher()
    {
        if (!self::$dispatcher) {
            self::$dispatcher = new S3_Event_Dispatcher();
        }
        return self::$dispatcher;
    }

    public static function listen($eventClass, $callback, $priority = 10)
    {
        self::dispatcher()->listen($eventClass, $callback, $priority);
    }

    public static function dispatch($event)
    {
        self::dispatcher()->dispatch($event);
    }

    public static function reset()
    {
        self::$dispatcher = new S3_Event_Dispatcher();
    }
}
```

Developers call **class methods**, never global `event()` or `add_action()` functions:

```php
S3_Event::listen('Application_Event_DocumentSaved', array($listener, 'handle'), 10);
S3_Event::dispatch(new Application_Event_DocumentSaved(123, $data));
```

## 7. Listener class

`application/modules/notification/listeners/DocumentSaved.php`:

```php
<?php
class Notification_Listener_DocumentSaved
{
    public function handle(Application_Event_DocumentSaved $event)
    {
        $id = $event->getDocumentId();
        // Call the notification service, log, or enqueue a durable job.
    }
}
```

Register with an object callback:

```php
$listener = new Notification_Listener_DocumentSaved();
S3_Event::listen('Application_Event_DocumentSaved', array($listener, 'handle'));
```

**Important:** `array('ClassName', 'method')` is only suitable for a static method in PHP 7.4. For instance methods, create the instance or use a lazy resolver as shown below.

## 8. Lazy listener resolution

The compiled registry should store metadata rather than constructing all module listeners during bootstrap:

```php
<?php
return array(
    'Application_Event_DocumentSaved' => array(
        array('class' => 'Notification_Listener_DocumentSaved', 'method' => 'handle', 'priority' => 10),
        array('class' => 'Audit_Listener_DocumentSaved', 'method' => 'handle', 'priority' => 20)
    )
);
```

A simple lazy callback factory can be registered at bootstrap:

```php
function s3_create_lazy_listener($class, $method)
{
    return function ($event) use ($class, $method) {
        if (!class_exists($class)) {
            throw new RuntimeException('Missing listener class: ' . $class);
        }
        $instance = new $class();
        if (!is_callable(array($instance, $method))) {
            throw new RuntimeException('Invalid listener method');
        }
        return call_user_func(array($instance, $method), $event);
    };
}
```

This factory is an **internal implementation helper**, not a public hook API. If a strict class-only codebase is required, move it to `S3_Event_ListenerResolver::callback($class, $method)`. For production, prefer a resolver that caches instances per request and injects dependencies; do not repeatedly instantiate expensive listeners.

Example registry loader:

```php
$registry = require APPLICATION_PATH . '/../data/cache/events.php';
foreach ($registry as $eventClass => $listeners) {
    foreach ($listeners as $item) {
        S3_Event::listen(
            $eventClass,
            s3_create_lazy_listener($item['class'], $item['method']),
            $item['priority']
        );
    }
}
```

## 9. Laravel-style pipelines for transformations

Laravel's pipeline concept is better suited to data transformations than events. Each stage receives a value and the next callable, and can modify the value before forwarding it.

`library/S3/Pipeline.php`:

```php
<?php
class S3_Pipeline
{
    public static function through($value, array $stages)
    {
        $next = function ($passable) { return $passable; };
        foreach (array_reverse($stages) as $stage) {
            if (!is_callable($stage)) {
                throw new InvalidArgumentException('Pipeline stage is not callable');
            }
            $previous = $next;
            $next = function ($passable) use ($stage, $previous) {
                return call_user_func($stage, $passable, $previous);
            };
        }
        return $next($value);
    }
}
```

Example stage:

```php
class Document_Pipeline_NormalizeTitle
{
    public function handle($data, $next)
    {
        $data['title'] = trim($data['title']);
        return $next($data);
    }
}
```

Usage:

```php
$normalizer = new Document_Pipeline_NormalizeTitle();
$data = S3_Pipeline::through($data, array(
    array($normalizer, 'handle')
));
```

Pipeline stages can short-circuit by not calling `$next`. For document saving, define whether short-circuiting is allowed and what output type the service expects. Validation failures should throw a documented exception, not return an ambiguous `null`.

## 10. Integration with `Document_Service`

```php
class Document_Service
{
    public function save(array $data)
    {
        $normalizer = new Document_Pipeline_NormalizeTitle();
        $data = S3_Pipeline::through($data, array(
            array($normalizer, 'handle')
        ));

        $db = Zend_Db_Table::getDefaultAdapter();
        $db->beginTransaction();
        try {
            $db->insert('documents', $data);
            $documentId = (int) $db->lastInsertId();
            $db->commit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }

        S3_Event::dispatch(
            new Application_Event_DocumentSaved($documentId, $data)
        );
        return $documentId;
    }
}
```

**Transaction warning:** A synchronous listener failure after commit cannot roll back the document save. Decide whether notifications are best-effort, whether errors are logged, and whether durable delivery is required. For critical guaranteed notifications, write an **outbox record in the same DB transaction** and process it separately; dispatching after commit alone is not reliable delivery.

## 11. Module config and compilation

Example `modules/notification/config.json`:

```json
{
  "module": {"name": "notification", "version": "1.0.0"},
  "events": [
    {
      "event": "Application_Event_DocumentSaved",
      "listener": "Notification_Listener_DocumentSaved",
      "method": "handle",
      "priority": 10
    }
  ]
}
```

Installer sequence:

1. Validate module name, class/method declarations, event names, priorities, and file presence.
2. Install/update module files and persist module enabled status.
3. Compile **enabled** module declarations into a PHP array; sort listeners deterministically.
4. Write to a temporary file and atomically publish a versioned registry or use a safe rename strategy.
5. Invalidate opcode cache when required by the deployment; avoid deleting a live registry before replacement.
6. On disable/uninstall, recompile without that module; ensure no stale callbacks remain.

Do not trust arbitrary module-supplied class names unless modules are administrator-approved code. Treat module installation as privileged code deployment, not merely data configuration.

## 12. ZF1 bootstrap

```php
class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initEvents()
    {
        S3_Event::reset();
        $registry = require APPLICATION_PATH . '/../data/cache/events.php';
        foreach ($registry as $eventClass => $listeners) {
            foreach ($listeners as $item) {
                S3_Event::listen(
                    $eventClass,
                    S3_Event_ListenerResolver::callback(
                        $item['class'], $item['method']
                    ),
                    $item['priority']
                );
            }
        }
    }
}
```

Implement `S3_Event_ListenerResolver::callback()` using the lazy resolver logic above. Ensure the resolver and event classes are available through the ZF1 autoloader. A missing registry should be handled according to deployment policy: fail startup with a clear error, or load an explicitly approved empty registry—not silently skip expected security behavior.

## 13. Unit tests (PHPUnit)

```php
class EventDispatcherTest extends PHPUnit\Framework\TestCase
{
    protected function setUp(): void
    {
        S3_Event::reset();
    }

    public function testDispatchCallsListener()
    {
        $received = array();
        S3_Event::listen(
            'Application_Event_DocumentSaved',
            function ($event) use (&$received) {
                $received[] = $event->getDocumentId();
            }
        );
        S3_Event::dispatch(
            new Application_Event_DocumentSaved(42, array('title' => 'A'))
        );
        $this->assertSame(array(42), $received);
    }

    public function testPriorityOrdering()
    {
        $calls = array();
        S3_Event::listen('stdClass', function ($e) use (&$calls) {
            $calls[] = 'later';
        }, 20);
        S3_Event::listen('stdClass', function ($e) use (&$calls) {
            $calls[] = 'first';
        }, 5);
        S3_Event::dispatch(new stdClass());
        $this->assertSame(array('first', 'later'), $calls);
    }

    public function testPipelineTransformsValue()
    {
        $result = S3_Pipeline::through('a', array(
            function ($v, $next) { return $next($v . 'b'); },
            function ($v, $next) { return $next($v . 'c'); }
        ));
        $this->assertSame('abc', $result);
    }
}
```

This example targets PHPUnit versions with namespaced `TestCase` and `setUp(): void`. Choose a PHPUnit release compatible with your PHP 7.4 environment. For older PHPUnit, adjust the base class and method signature to its supported API.

Additional tests should cover missing listeners, multiple listeners, equal-priority ordering, invalid callbacks, listener exceptions, pipeline short-circuiting, module enable/disable compilation, invalid module metadata, and after-commit/outbox behavior.

## 14. Hook/event documentation as an API contract

Maintain `docs/events/README.md` as a master index and one page per domain. Each published event should specify:

| Field | Example |
|---|---|
| Event class | `Application_Event_DocumentSaved` |
| Meaning | Document was committed successfully |
| Dispatch location | `Document_Service::save()` |
| Payload | Document ID (int), data (array) |
| Timing | After database commit |
| Delivery | Synchronous, best effort unless outbox is used |
| Failure policy | Exception may propagate to caller |
| Introduced | `1.0.0` |
| Compatibility | Do not change public getters or semantics without migration |

Document pipeline stages separately, including input/output types, order, short-circuit rules, and failure policy. Use deprecation windows for renamed events; modules may depend on event classes even if the compiler registry loads successfully.

## 15. Migration from `S3_Hook`

| Phase | Work |
|---|---|
| 1 | Inventory all existing `S3_Hook::do_action()` and `apply_filters()` calls. |
| 2 | Create event classes for action hooks; write event contract documentation. |
| 3 | Implement and unit-test `S3_Event` and `S3_Pipeline`. |
| 4 | Convert one non-critical module, such as notifications, as a pilot. |
| 5 | Add compiled event declarations to the module installer. |
| 6 | Migrate value filters into explicit pipeline stages. |
| 7 | Remove old hooks only after dependent modules have migrated. |

During migration, avoid automatically firing both old and new APIs unless duplicate side effects are explicitly prevented. Audit, email, and notification listeners can otherwise execute twice.

## 16. Tradeoffs and production checklist

**Benefits:** typed event payloads; IDE navigation; clean class-only API; modular listener registration; straightforward unit tests; explicit data transformation; incremental migration.

**Costs:** more classes than WordPress-style hooks; additional registry compiler; synchronous listeners can slow requests; durable delivery requires an outbox/worker; pipeline ordering needs documentation.

Before production release verify: registry integrity, module disable/uninstall behavior, callback validation, deterministic priority, autoloading, exception policy, transaction boundaries, outbox retry/idempotency where applicable, monitoring, logging, PHPUnit coverage, and event documentation.

## 17. Recommendation

For your ZF1 system, implement **`S3_Event` + `S3_Pipeline`** as small independent components. Keep the module `config.json` → compiled registry approach already planned for your hook system. Begin with synchronous events for low-risk notifications; use a MariaDB outbox when delivery must survive process failure. Do not introduce a command bus, dependency-injection framework, or queue server until a concrete requirement justifies them.

## References

- Laravel documentation: Events — https://laravel.com/docs/events
- Laravel API: Pipeline — https://laravel.com/api/12.x/Illuminate/Pipeline/Pipeline.html
- PHP manual: `call_user_func`, `is_callable`, anonymous functions, exceptions — https://www.php.net/manual/en/
- PHPUnit documentation — https://docs.phpunit.de/
