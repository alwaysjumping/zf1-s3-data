# Enterprise Module Marketplace and Offline License Management System

**Comprehensive architecture, implementation, security, operations, and test guide**  
**Edition:** 1.0 · **Date:** 2026-10-14 · **Status:** Consolidated design and implementation reference  
**Target environment:** PHP 7.4, Zend Framework 1 (ZF1), MariaDB 10.11, Windows 11 / PowerShell 5.0 packaging, isolated subsidiary deployments

> **Important:** This document consolidates the decisions and examples from our discussion (Parts 1–19). It is a detailed design reference, **not a certification that the prototype ZIPs are production-ready**. Some example classes are illustrative; complete integration, live MariaDB tests, hardening, and operational approval remain necessary. PHP 7.4 and ZF1 are legacy platforms and require compensating controls and an upgrade plan.

---

## Contents

1. Executive summary and objectives
2. Organization, terminology, and trust boundaries
3. Functional requirements and use cases
4. Nonfunctional requirements and offline constraints
5. Overall architecture
6. Commercial marketplace and developer publishing
7. Product, release, dependency, and module lifecycle
8. Licensing business model and entitlement rules
9. Cryptographic architecture and trust management
10. License certificate specification
11. Installation identity and offline activation protocol
12. Authority-side data model and concurrency
13. Subsidiary-side data model and license import
14. Signed offline status, revocation, and freshness
15. Runtime validation and feature licensing
16. ZF1 integration and automatic enforcement
17. Module packaging, verification, and installation
18. Administration versus business-user sites
19. Financial settlement, refunds, and auditability
20. Detailed example: Company A sells CRM to Company B
21. Offline deployment, operations, and disaster recovery
22. Security threat model and limitations
23. Test strategy and acceptance criteria
24. Implementation roadmap and deliverables
25. Reference PHP, SQL, JSON, and command examples
26. Troubleshooting and operational checklist
27. Open decisions and future enhancements
28. Glossary

---

# 1. Executive summary and objectives

The parent company operates a central **Module Marketplace** through which subsidiary companies can publish, discover, purchase, and download business modules. A subsidiary that develops a better version of a parent-company module should be able to earn revenue when another subsidiary adopts it. The parent company remains responsible for governance, release approval, trust anchors, licensing policy, and settlement.

The critical technical constraint is that some subsidiary application servers cannot maintain an online connection to the parent company. Consequently, a license must be **verifiable locally**, using signed certificates and periodically imported signed status packages. Every business-module execution path must use a centrally maintained license policy. A browser-side check is not a security control.

## 1.1 Principal objectives

- Support subsidiary-owned and parent-owned modules.
- Support module publication, approval, pricing, orders, entitlements, license issuance, downloads, installation, and renewal.
- Compensate the module developer according to an agreed revenue-sharing rule.
- Bind authorization to an approved company and installation, with explicit installation-count limits.
- Permit offline activation and runtime verification through authorized file transfer.
- Separate **commercial licensing**, **software-release trust**, and **user authorization**.
- Enforce licensing in ZF1 controllers, REST APIs, CLI tasks, cron, background workers, and hook callbacks.
- Provide reproducible audit trails, immutable financial events, and controlled administrative operations.
- Avoid requiring Redis or a persistent connection to the parent License Authority.

## 1.2 Out of scope for the initial foundation

- Full payment gateway integration, tax calculations, and bank settlement.
- A hardware-enforced anti-cloning guarantee.
- Instant revocation on disconnected servers.
- Safe execution of hostile third-party PHP code inside the same ZF1 process.
- Automated migration of all legacy ZF1 module entry points without an inventory.

# 2. Organization, terminology, and trust boundaries

| Actor | Responsibility |
|---|---|
| Parent company | Owns Marketplace, License Authority, Module Trust Authority, approval policy, financial settlement |
| Company A | Develops/publishes `company_a.crm_advanced`; receives agreed sales revenue |
| Company B | Purchases, downloads, installs, and activates the module |
| Company C | Unlicensed or separately licensed subsidiary; cannot use B's certificate |
| License Authority (LA) | Issues signed usage certificates and status packages |
| Module Trust Authority (MTA) | Signs or approves immutable release manifests and package hashes |
| Local Module License Manager (MLM) | Validates signed licenses and status on subsidiary servers |
| Marketplace | Catalog, commerce, developer profiles, plans, orders, entitlement provisioning |
| Module Registry | Trusted local record of installed module ID, version, status, routes, jobs, hooks |

**Trust boundaries:** The parent signing keys remain on parent-controlled infrastructure. Subsidiary servers receive only public verification keys and their own installation private keys. Transfer media is an untrusted transport: signatures and integrity checks must still be verified. Browser inputs, ZIP contents, developer-supplied metadata, and module-declared ownership must not be accepted as trusted facts without validation.

## 2.1 The three independent authorizations

1. **Commercial authorization:** Is this installation licensed for the module/version/feature?
2. **Module privilege authorization:** What application resources or services may this module use?
3. **User/service authorization:** May the current user or service identity perform the operation?

A valid commercial license does not grant an employee permission to edit customer records. A valid user permission does not grant a company a commercial license. Nor does a signed license prove that a module ZIP is safe.

# 3. Functional requirements and use cases

## 3.1 Marketplace requirements

- Developer/company registration and verification.
- Module listing with immutable module ID, display name, description, category, owner, maintainer, support contact, screenshots, and documentation.
- Upload a release archive and manifest; validate integrity, compatibility, dependencies, malware/security review, and publishing authorization.
- Version history, release channels, release notes, support lifecycle, deprecation notices, and upgrade paths.
- Pricing plans: trial, standard, professional, enterprise, subscription, perpetual, site-based, feature-based, and negotiated enterprise arrangements.
- Purchase approval, order status, invoice/reference, entitlement provisioning, activation quota, renewals, refunds, and transfers.
- Download only approved immutable releases for authorized recipients; offline export bundle where needed.
- Developer sales dashboards and parent-company settlement statements.
- Audit of publishing, approval, entitlement, license, activation, revocation, and financial actions.

## 3.2 Licensing requirements

- Registration of a subsidiary installation with an Ed25519 public key and approved company association.
- One-time challenge-response proof of possession of the corresponding installation private key.
- Issue signed, installation-bound certificate with explicit version range and feature list.
- Enforce activation quotas transactionally even under concurrent requests.
- Make repeated submission of the *same request* idempotent; reject reuse of its challenge for a different request.
- Verify certificates locally without parent connectivity.
- Reject invalid signatures, mismatched company/installations, wrong versions, expired terms, and stale/revoked status.
- Import signed status updates with monotonic sequence and expiry.
- Audit license import and verification failures without logging secrets.

## 3.3 Illustrative acceptance scenarios

| Scenario | Expected result |
|---|---|
| B has valid certificate for CRM 2.1.0 | Permit, subject to module/user checks |
| C imports B's certificate | Reject: company/installation mismatch |
| B copies certificate to another registered installation | Reject: installation mismatch |
| B exceeds one-installation entitlement | Reject new activation |
| B retries identical completed activation request | Return previously issued certificate |
| B reuses challenge in a different request | Reject replay |
| Signed status revokes B's license | Deny after import |
| Status expires under fail-closed policy | Deny until fresh status arrives |
| Premium feature absent from certificate | Deny premium feature |
| Module disabled by administrator | Deny even with valid license |

# 4. Nonfunctional requirements and offline constraints

**Offline first:** Subsidiary servers may have no route to the Marketplace or LA. Activation, certificate import, revocation import, and package updates must work through authorized files. The absence of connectivity is normal operation, not an exceptional outage.

**Integrity:** Every certificate/status package is signed. Every module release is independently authenticated by a signed manifest and content hash. Do not rely on file names, ZIP CRC, TLS alone, or an unsigned JSON field.

**Availability versus security:** The organization must explicitly choose whether a stale status package blocks a module. A fail-closed policy protects revocation enforcement but can interrupt operations when transfer media is delayed.

**Compatibility:** Use PHP 7.4-compatible code and `ext-sodium`; MariaDB with InnoDB transactions; ZF1-compatible underscore classes for integration. Avoid relying on PHP 8-only syntax. Use `password_hash`/`password_verify` for passwords, not reversible encryption.

**Performance:** Avoid a database query on every minor method call. Cache verified decisions with strict expiry bounds and invalidation on certificate/status changes. Revalidate at trusted job and request boundaries.

**Operations:** Protect keys and database backups, monitor status freshness, keep clocks synchronized using approved internal time services, and document recovery when a key, installation, or database is lost.

# 5. Overall architecture

```text
                    PARENT COMPANY / CONTROLLED ZONE
 +----------------------------------------------------------------+
 | Module Marketplace                                             |
 |  Developer registry -> Catalog -> Orders -> Entitlements        |
 |          |                                 |                    |
 |          v                                 v                    |
 |  Module Trust Authority              License Authority         |
 |  - approve immutable ZIP             - register installation   |
 |  - sign release manifest             - challenge-response      |
 |  - sign package hash                 - issue license           |
 |                                     - sign status/revocations  |
 +---------------------+---------------------------+--------------+
                       | Authorized offline packages
                       v
                TRANSFER / APPROVAL BOUNDARY
                       |
                       v
 +----------------------------------------------------------------+
 | COMPANY B / ISOLATED SITE                                      |
 | Admin Site: import ZIP, release signature, license, status     |
 |          |                                                     |
 |          v                                                     |
 | Trusted Module Registry ---- Local Module License Manager      |
 |          |                          |                          |
 |          v                          v                          |
 | Business Site / REST / CLI / Hooks -> Module Access Policy     |
 |                                     -> User authorization      |
 |                                     -> Business execution      |
 +----------------------------------------------------------------+
```

**Key rule:** The Marketplace may create an entitlement after an order is approved, but only the License Authority signs executable authorization. The MTA separately signs approved software. A license certificate is not a software-release signature.

# 6. Commercial marketplace and developer publishing

## 6.1 Company and publisher records

Maintain distinct concepts: **developer** (author of code), **publisher** (entity authorized to distribute), **legal owner** (IP rights), **maintainer** (support and updates), and **revenue beneficiary** (recipient of proceeds). They may differ after ownership transfers, acquisitions, or outsourcing.

Suggested entities: `companies`, `developer_profiles`, `publisher_memberships`, `modules`, `module_ownership_history`, `module_releases`, `release_reviews`, `license_plans`, `orders`, `order_lines`, `commercial_entitlements`, `settlement_accounts`, `ledger_entries`, `audit_events`.

## 6.2 Publication workflow

```text
Developer submits ZIP + manifest + documentation
  -> identity/ownership check
  -> manifest schema validation
  -> file safety and package hash
  -> compatibility and dependency checks
  -> security/quality review
  -> approval by authorized parent reviewer
  -> immutable release ID
  -> MTA signature
  -> catalog publication
```

A reviewer should not approve their own high-risk release without a documented exception. After approval, any changed byte creates a new release and requires a new signature. Never overwrite a published archive in place.

## 6.3 Orders and entitlements

An **order** is a commercial event. An **entitlement** represents purchased rights. An **activation** consumes a permitted installation slot. A **certificate** is the signed proof of rights for one activation. These must not be collapsed into a single table or identifier.

A payment/refund workflow should be idempotent and event-driven. Do not issue new entitlements based solely on a client-side “payment successful” message. In a fully offline enterprise environment, use a parent-approved order or accounting authorization event rather than an online payment gateway.

# 7. Product, release, dependency, and module lifecycle

## 7.1 Stable identity and immutable releases

Use a globally unique module ID such as `company_a.crm_advanced`; the display name may change. Each release has a version, release ID, SHA-256 digest, signed manifest, minimum framework/PHP/MariaDB compatibility, dependencies, conflicts, and release channel.

Example manifest (illustrative):

```json
{
  "manifest_format": "s3-module-release",
  "manifest_version": 1,
  "module_id": "company_a.crm_advanced",
  "version": "2.1.0",
  "publisher_id": "COMPANY_A",
  "archive_sha256": "<64 lowercase hex characters>",
  "requires": {"php": ">=7.4 <8.0", "zf1": "compatible"},
  "dependencies": [{"module_id": "s3.customer_core", "version": ">=1.4.0 <2.0.0"}],
  "conflicts": ["s3.crm_legacy"],
  "entry_points": ["api", "admin", "hooks", "jobs"]
}
```

Do not treat arbitrary version strings or constraints as safe without a validated parser. Define an explicit comparison policy (for example SemVer for module versions), including prerelease semantics.

## 7.2 Replacement and upgrade relationships

Company A's CRM may **replace** the parent's original CRM. That relationship is not automatically a transfer of the old CRM's commercial rights. Possible policies:

- `NONE` (default): purchase a new entitlement.
- `UPGRADE_CREDIT`: discount based on a qualifying existing entitlement.
- `FULL_MIGRATION`: parent-approved migration to replacement license.
- `DUAL_ENTITLEMENT`: temporary overlap for transition.

Data migration is a separate concern: plan schema changes, backups, rollback/recovery, import/export compatibility, and preservation of audit trails. MariaDB DDL may implicitly commit; do not assume that a single transaction can roll back an entire module installation.

## 7.3 Lifecycle

`DRAFT -> SUBMITTED -> REVIEW -> APPROVED -> PUBLISHED -> DEPRECATED -> RETIRED` for catalog/release governance. Installed-module state is separate: `NOT_INSTALLED`, `INSTALLED`, `ENABLED`, `DISABLED`, `ERROR`. License state is separate again: `ACTIVE`, `EXPIRED`, `REVOKED`, `STATUS_STALE`, etc.

# 8. Licensing business model and entitlement rules

A license plan defines what is purchased: module ID, authorized versions, features, license type, maximum active installations, usage term, update term, and support policy.

| Term | Meaning |
|---|---|
| Usage expiration | Date after which module execution is denied |
| Update entitlement expiration | Date after which newly released versions cannot be acquired under this plan |
| Version range | Executable module versions covered by this certificate |
| Installation limit | Maximum active registered installations |
| Feature list | Exact named premium capabilities permitted |
| Renewal | New commercial term and certificate revision |
| Transfer | Controlled release/reassignment of activation slot |

A **perpetual** license can permit ongoing use of an authorized version while update rights expire earlier. A subscription typically has a finite usage expiration. The certificate must reflect the purchased plan rather than hard-coded defaults.

**Activation counting:** Lock the entitlement row before counting active activations. A unique `(entitlement_id, installation_id)` constraint prevents duplicate pairs. Define whether an inactive activation row can be reactivated, how transfers are approved, and whether revoked activations free a slot.

# 9. Cryptographic architecture and trust management

## 9.1 Algorithms

- **Ed25519**: digital signatures for license certificates, activation proof of possession, status packages, and (under a separate authority/key) module release manifests.
- **SHA-256**: archive integrity and fingerprints; hashes alone do not authenticate a publisher.
- **Cryptographically secure random bytes**: challenge nonces, request IDs where applicable, and installation key generation.
- **Base64url**: compact binary transport encoding; require strict canonical decoding.

PHP 7.4 can use `sodium_crypto_sign_keypair()`, `sodium_crypto_sign_detached()`, and `sodium_crypto_sign_verify_detached()` when `ext-sodium` is installed.

## 9.2 Key separation

| Key | Holder | Purpose |
|---|---|---|
| LA signing private key | Parent License Authority only | Signs licenses and status (prefer separate subkeys) |
| LA signing public key | All approved subsidiaries | Verifies LA signatures |
| MTA signing private key | Parent release approval infrastructure | Signs approved release manifests |
| MTA public key | All approved subsidiaries | Verifies module release authenticity |
| Installation private key | Specific subsidiary installation | Signs activation responses |
| Installation public key | Registered at parent; known locally | Verifies proof of possession / identity binding |

**Never distribute an LA or MTA private signing key to subsidiaries.** Prefer separate signing keys for licenses, status, and software releases, even when the algorithm is the same. Implement key IDs, revocation, staged rollover, and overlapping trusted-key periods.

## 9.3 Signature domain separation

Do not sign an arbitrary JSON object and later reserialize it for verification. Sign exact bytes using a protocol-specific prefix. The discussed license envelope uses:

```text
S3-LICENSE-V1\n<key_id>\n<base64url_payload>
```

Verify the signature over the original encoded payload bytes **before** parsing its claims. Require a fixed algorithm, known key ID, correct signature length, strict base64url, valid JSON schema, and bounded file sizes. Reject ambiguous/duplicate JSON keys; do not silently accept unknown critical fields.

## 9.4 Offline trust-anchor distribution

Initial trusted public keys must arrive via a parent-approved channel with independently verified fingerprints. Do not let a license file install a new trust key merely because it says to. Key rotation requires a signed transition package under an existing trusted key or a separately approved physical provisioning procedure. Record which key signed each certificate and status snapshot.

# 10. License certificate specification

## 10.1 Signed envelope

```json
{
  "format": "s3-module-license",
  "format_version": 1,
  "algorithm": "Ed25519",
  "key_id": "license-2026-01",
  "payload": "BASE64URL_ENCODED_UTF8_JSON",
  "signature": "BASE64URL_ED25519_SIGNATURE"
}
```

## 10.2 Decoded payload example

```json
{
  "license_id": "LIC-000015",
  "certificate_id": "CERT-000152",
  "certificate_revision": 1,
  "entitlement_id": "ENT-000152",
  "activation_id": "ACT-000852",
  "company_id": "COMPANY_B",
  "installation_id": "INST-00852",
  "installation_key_sha256": "<SHA-256 fingerprint of registered 32-byte public key>",
  "module_id": "company_a.crm_advanced",
  "version_min": "2.0.0",
  "version_max_exclusive": "3.0.0",
  "license_type": "perpetual",
  "issued_at": "2026-10-14T00:00:00Z",
  "not_before": "2026-10-14T00:00:00Z",
  "usage_expires_at": null,
  "updates_expires_at": "2027-10-14T00:00:00Z",
  "features": ["customer_management", "sales_pipeline", "advanced_reporting"]
}
```

These dates are examples, not actual issued rights. Every field must come from approved entitlement and installation records. Distinct IDs are required for entitlement, license, activation, certificate, and request. Version upper bounds are exclusive. Use UTC timestamps and a single documented parser. A local identity file supplied on the command line is not automatically a trusted identity; in production, compare against securely provisioned local state.

# 11. Installation identity and offline activation protocol

## 11.1 Installation registration

On Company B's server, generate an Ed25519 key pair. Protect the private key with restrictive OS permissions or, where possible, a hardware-backed key provider. Create a registration package containing `company_id`, `installation_id`, and encoded public key. Parent staff verify the requesting company through an approved channel before binding the key to the company. Registration must not be authorized solely by self-declared JSON.

## 11.2 Challenge-response

1. Parent verifies entitlement and registered installation.
2. Parent generates a cryptographically random challenge nonce and durable challenge ID.
3. Parent binds challenge to entitlement, installation, purpose, and expiry.
4. Company B signs a canonical activation message with its installation private key.
5. Parent verifies signature against the *registered* installation public key.
6. Parent atomically consumes challenge and creates/reuses activation.
7. Parent signs and persists certificate, then exports it to Company B.

Activation V2 signing bytes:

```text
S3-ACTIVATION-V2
REQ-000152
CHAL-000152
INST-00852
ENT-000152
BASE64URL_RANDOM_NONCE
```

All line separators and encodings must be specified byte-for-byte. The request code is a durable idempotency key, not a random nonce substitute. A challenge may be consumed by exactly one distinct request.

## 11.3 Idempotency and crash recovery

- **Same request code + identical request digest + completed:** return stored certificate.
- **Same request code + different digest:** reject conflict.
- **New request code + already consumed challenge:** reject replay.
- **Database error before commit:** no activation or certificate becomes visible.
- **Response lost after commit:** retry returns stored certificate, not a second activation.

Persist the certificate **inside** the transaction; export/deliver only after commit. Record an audit event and correlate it with the request code.

## 11.4 Offline transport

Transfer request/response as versioned files on approved media. Use descriptive package names but never trust names for identity. Authenticate contents cryptographically; quarantine unknown files; log sender, recipient, time, hash, operator, and import outcome. A signed certificate may be copied freely, but should validate only on the intended installation.

# 12. Authority-side data model and concurrency

## 12.1 Recommended entities

| Table | Essential fields / constraints |
|---|---|
| `companies` | ID, code UNIQUE, status |
| `installations` | ID, installation_code UNIQUE, company_id FK, public_key VARBINARY(32), status |
| `modules` | module_code UNIQUE, publisher, owner, status |
| `commercial_entitlements` | entitlement_code UNIQUE, company_id, module_code, plan terms, max_installations, status |
| `licenses` | license_code UNIQUE, entitlement_id, lifecycle state |
| `license_activations` | activation_code UNIQUE, entitlement_id, installation_id, status, UNIQUE(entitlement_id, installation_id) |
| `activation_challenges` | challenge_code UNIQUE, installation_id, entitlement_id, nonce, expiry, status |
| `activation_requests` | request_code UNIQUE, challenge_id UNIQUE, request_sha256, status, certificate_id |
| `license_certificates` | certificate_code UNIQUE, activation_id, revision, signed JSON, hash, UNIQUE(activation_id, revision) |
| `license_status_publications` | scope, sequence, issued_at, valid_until, signed JSON, UNIQUE(scope, sequence) |
| `audit_events` | actor, action, object, result, correlation ID, timestamp |

Use InnoDB, foreign keys, appropriate covering indexes, and restrictive database roles. Keep signing-key material outside MariaDB when feasible.

## 12.2 Transaction and locking order

```text
Validate bounded request structure (outside transaction)
BEGIN
  Lock entitlement (serialization point)
  Claim or inspect idempotency request
  Lock challenge
  Verify challenge binding, status, expiry, nonce
  Verify registered installation status and company
  Verify Ed25519 proof of possession
  Find existing activation
  If none active, count active slots and enforce quota
  Create/reuse activation and logical license
  Allocate next certificate revision and sign exact payload
  Persist certificate and mark request COMPLETED
  Consume challenge; write audit record
COMMIT
Return persisted certificate
```

The implementation must handle unique-key races, deadlocks, lock timeouts, and retry boundaries explicitly. Use a consistent locking order for all writers. Count and allocate within the same serialized transaction; a plain count outside the lock is unsafe.

## 12.3 Example DDL fragments

```sql
CREATE TABLE license_activations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    activation_code VARCHAR(64) NOT NULL,
    entitlement_id BIGINT UNSIGNED NOT NULL,
    installation_id BIGINT UNSIGNED NOT NULL,
    status VARCHAR(16) NOT NULL,
    activated_at DATETIME(6) NOT NULL,
    released_at DATETIME(6) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_activation_code (activation_code),
    UNIQUE KEY uq_entitlement_installation (entitlement_id, installation_id),
    KEY ix_entitlement_status (entitlement_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE activation_requests (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    request_code VARCHAR(64) NOT NULL,
    challenge_id BIGINT UNSIGNED NOT NULL,
    request_sha256 BINARY(32) NOT NULL,
    status VARCHAR(16) NOT NULL,
    certificate_id BIGINT UNSIGNED NULL,
    created_at DATETIME(6) NOT NULL,
    completed_at DATETIME(6) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_request_code (request_code),
    UNIQUE KEY uq_request_challenge (challenge_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

These fragments are **not** the complete production schema; add FKs, company/module tables, indexes, audit, lifecycle constraints, and migration management in the implementation.

# 13. Subsidiary-side data model and license import

## 13.1 Suggested local tables

- `local_installation_identity`: immutable approved company/install ID and public key fingerprint; private key held separately.
- `local_license_certificates`: original signed JSON, certificate hash, revision, module ID, status, import timestamp.
- `local_status_snapshots`: signed status envelope, sequence, validity period, scope, import timestamp.
- `local_license_audit`: imports, rejections, administrative actions, policy decisions (sampled), correlation IDs.
- `local_module_registry`: trusted installed module IDs, versions, enabled states, entry-point mappings.

## 13.2 Atomic import

```text
Read bounded input
 -> strict envelope/schema checks
 -> select trusted authority key
 -> verify signature on exact signed bytes
 -> validate company/install/key fingerprint/module/version claims
 -> check issued/not-before/expiry and revision
 -> check local status sequence and revocation policy
 -> BEGIN
 -> reject conflicting duplicate IDs/revisions
 -> insert original signed certificate
 -> supersede older revision only when valid
 -> append audit event
 -> COMMIT
 -> invalidate affected cache
```

Do not delete a previously valid certificate when a new import fails. Same certificate import can return `ALREADY_IMPORTED`; same ID/revision with different bytes must fail. A newer revision is not automatically more permissive: all signed claims still require validation.

## 13.3 Local key storage

A software key stored in a local file is cloneable by a sufficiently privileged administrator. File permissions, disk encryption, and restricted service accounts reduce casual copying but cannot guarantee physical uniqueness. If strict device binding is essential, evaluate a USB token, TPM, or HSM with non-exportable keys and a supported signing interface.

# 14. Signed offline status, revocation, and freshness

## 14.1 Status envelope

```json
{
  "format": "s3-license-status",
  "format_version": 1,
  "algorithm": "Ed25519",
  "key_id": "status-2026-01",
  "payload": "BASE64URL_ENCODED_UTF8_JSON",
  "signature": "BASE64URL_SIGNATURE"
}
```

Decoded payload example:

```json
{
  "scope": "COMPANY_B",
  "sequence": 12,
  "issued_at": "2026-10-14T00:00:00Z",
  "valid_until": "2026-10-21T00:00:00Z",
  "revoked_license_ids": ["LIC-000015", "LIC-000027"]
}
```

**Specify whether the package is a complete snapshot or a delta.** For the first version, prefer a **complete, scoped snapshot** of all currently revoked licenses for that scope. A missing ID in a later full snapshot must have a defined meaning; reinstatement should not happen accidentally. A separate signed reinstatement event with administrative approval is safer for early releases.

## 14.2 Sequence and rollback

Accept only the next valid sequence policy for the scope, or an allowed higher sequence with documented missed-update handling. Reject older sequences. Persist the highest accepted sequence. **Database-only monotonic counters do not prevent rollback of the entire database backup.** Higher assurance requires protected external monotonic state or controlled re-provisioning.

## 14.3 Freshness policy

| Policy | Illustrative validity | Trade-off |
|---|---|---|
| Strict | 24 hours | Fast denial of stale state; high operational burden |
| Standard | 7 days | Balanced for routinely transferred packages |
| Extended | 30 days | More availability; slower revocation awareness |
| Unlimited | No freshness enforcement | Poor fit for revocable licenses |

Seven days is a **starting proposal**, not a security guarantee. It is suitable only if the organization can reliably deliver signed updates within the chosen interval. Critical modules may require stricter rules.

## 14.4 Clock manipulation and outages

Use trusted internal time synchronization, detect implausible backward jumps, persist observed time/sequence where possible, and log anomalies. Software-only time checks can be bypassed by a fully privileged local operator. Decide explicitly whether a stale status produces `LICENSE_STATUS_STALE` and denies service. Provide a documented emergency exception process with dual approval, narrow scope, expiry, and audit.

# 15. Runtime validation and feature licensing

A runtime decision should check, in order:

1. Installed module exists in trusted registry.
2. Module is administratively enabled.
3. Certificate envelope is valid and signed by trusted LA key.
4. Company, installation ID, and registered public-key fingerprint match.
5. Module ID and installed version fall within signed authorization.
6. Current time satisfies `not_before` and usage expiry.
7. Trusted revocation status is sufficiently fresh and does not revoke license.
8. Requested feature is present in signed feature list, if feature-gated.
9. User or service identity is authorized for the business action.

Return structured decisions such as `ALLOW`, `LICENSE_REQUIRED`, `LICENSE_EXPIRED`, `LICENSE_REVOKED`, `LICENSE_STATUS_STALE`, `LICENSE_VERSION_DENIED`, `LICENSE_FEATURE_DENIED`, and `USER_PERMISSION_DENIED`.

**Cache rules:** A cached allow must expire no later than the earliest applicable certificate expiry, status `valid_until`, policy TTL, and administrative invalidation deadline. Importing a license/status update invalidates affected cache entries. A cache must not become an alternative source of unverified rights.

# 16. ZF1 integration and automatic enforcement

## 16.1 Proposed components

```text
library/S3/
  License/Manager.php
  Module/Registry.php
  Module/Resolver.php
  Module/AccessPolicy.php
  Module/PermissionManager.php
  Module/JobDispatcher.php
  Controller/Plugin/ModuleLicense.php
```

`S3_License_Manager` offers:

```php
$manager->canActivate($moduleId, $version);
$manager->canExecute($moduleId, $version);
$manager->canUseFeature($moduleId, $version, $feature);
$manager->getStatus($moduleId, $version);
```

The module version must be obtained from the trusted installed-module registry, not supplied uncritically by the browser. User authorization remains separate.

## 16.2 Access policy example (illustrative)

```php
<?php
class S3_Module_AccessPolicy
{
    private $registry;
    private $licenses;
    private $permissions;

    public function __construct($registry, $licenses, $permissions)
    {
        $this->registry = $registry;
        $this->licenses = $licenses;
        $this->permissions = $permissions;
    }

    public function assertCanExecute(string $moduleId, $principalId): void
    {
        $module = $this->registry->getModule($moduleId);
        if (!$module || $module['status'] !== 'ENABLED') {
            throw new RuntimeException('MODULE_DISABLED');
        }
        if (!$this->licenses->canExecute($moduleId, $module['version'])) {
            throw new RuntimeException('LICENSE_REQUIRED');
        }
        if (!$this->permissions->canAccess($principalId, $moduleId)) {
            throw new RuntimeException('USER_PERMISSION_DENIED');
        }
    }
}
```

Production code should use typed domain exceptions and preserve precise internal denial reasons; a generic `LICENSE_REQUIRED` should not mask every expiration/revocation failure in logs.

## 16.3 Controller plugin

A `Zend_Controller_Plugin_Abstract` plugin can enforce policy in `preDispatch()`, after routing resolves a trusted module ID. Maintain a trusted route-to-module mapping rather than deriving ownership by splitting the URL. Example routes:

| Route | Owner |
|---|---|
| `/api/crm/customer/getlist` | `company_a.crm_advanced` |
| `/api/crm/report/export` | `company_a.crm_advanced` |
| `/api/email/getlist` | `email` |
| `/api/auth/login` | Core authentication service |

Core services must have a **narrow, explicit allowlist**. Do not bypass all administrator routes or all authentication-prefixed routes indiscriminately. Prevent loops where license denial routes themselves require the denied module.

## 16.4 Entry-point coverage

| Entry point | Required enforcement |
|---|---|
| ZF1 controller action | Central controller plugin and module policy |
| REST API | Trusted route ownership + policy |
| CLI command | Central CLI dispatcher and service principal |
| Cron job | Job dispatcher before each run |
| Long-running worker | Recheck at job boundaries and on invalidation |
| Hook callback | Trusted module ownership and policy before callback |
| Direct internal service call | Protected service boundary or explicit policy call |

**Critical limitation:** A ZF1 controller plugin does not intercept arbitrary PHP functions or independently executed scripts. The system must inventory and migrate all entry points to trusted dispatchers. PHP modules in the same process are not sandboxed from one another.

## 16.5 Hook integration

Register hook ownership through trusted module metadata; avoid allowing an untrusted callback to claim another module's ID. Before dispatching a callback, check the owner's module license and the applicable service/user permissions. Apply the same rule to actions and filters. Do not silently skip business-critical callbacks without a defined failure policy.

## 16.6 Administrator and user sites

The administrator site may install/uninstall/import licenses; the business site may execute authorized modules. Both sites must enforce their own authorization. Shared business modules are possible, but minimize cross-site shared secrets and privileges. An administrator can manage an unlicensed module without gaining permission to execute its premium business functions.

# 17. Module packaging, verification, and installation

## 17.1 Preserve the existing PowerShell packaging contract

The organization's current module packaging process uses PowerShell on Windows and `product_*.json` configuration. Preserve these established rules:

1. User edits `version` manually; packaging **never auto-increments version**.
2. Build ZIP, then verify the ZIP successfully.
3. **Only after successful ZIP creation and verification**, update the original selected configuration: `install_date`, increment `build_no`, and resolve `build_info` placeholders.
4. Rename configuration files only **inside the archive**; do not rename source files.
5. Special case: `module_framework.zip` intentionally has **no version number in its filename**.

Adding release signatures must not cause source metadata to be updated prematurely. Prefer: prepare archive -> verify contents -> compute digest -> request MTA approval/signature -> publish immutable release -> finalize successful build bookkeeping under the agreed process. Define recovery when approval fails after ZIP creation; do not mark unpublished content as approved.

## 17.2 ZIP safety checks

- Reject `../` traversal, absolute paths, dangerous symlinks, device files, unexpected executable scripts, and oversized decompressed content.
- Enforce file count, total expanded size, path length, and extension rules.
- Extract into a quarantine/staging directory with no executable web access.
- Verify SHA-256 of **exact ZIP bytes** against the signed manifest.
- Verify MTA signature using a separately trusted MTA public key.
- Check module ID/version consistency across manifest, archive, registry, and entitlement.
- Require review for dependency changes, migrations, privilege additions, and hook/route registrations.

## 17.3 Install/activate separation

A module can be `INSTALLED` but not `ENABLED`. License failure should block activation/execution, not necessarily deletion of installed files. This allows renewal without reinstalling and avoids destructive reactions to temporary status staleness. Database migrations require backups and forward-recovery plans; do not assume DDL rollback is transactional.

# 18. Administration versus business-user sites

The organization decided to separate admin and user sites while reusing approved business modules. Maintain separate web roots, application entry points, route registration, roles, and administrative credentials. Only the admin site exposes module installation/uninstallation and license import. Both sites can read approved local licensing state under least-privilege DB accounts; the business site should not have privileges to modify certificates or revocation records.

The parent Marketplace is a third system, not the subsidiary admin site. The parent signs and approves; the subsidiary imports and executes. A subsidiary administrator must not be able to mint parent-authorized licenses merely by changing local database rows.

# 19. Financial settlement, refunds, and auditability

## 19.1 Revenue split example

Company B purchases Company A's CRM Advanced module for **$500**. The parent Marketplace commission is **10%**:

| Item | Amount |
|---|---:|
| Gross sale | $500 |
| Parent commission | $50 |
| Company A revenue share | $450 |

This example excludes tax, payment processing, withholding, and refund rules. Financial settlement should use a **double-entry ledger** with immutable postings. Refunds and chargebacks generate reversal entries; do not edit historical posted amounts.

## 19.2 Audit requirements

Record who approved a publisher, release, plan, price, entitlement, activation transfer, revocation, and settlement. Capture before/after state where appropriate, correlation IDs, timestamps, signed artifact hashes, and approval references. Prevent unauthorized deletion or alteration of audit logs; export signed periodic audit summaries where the threat model requires it.

## 19.3 Ownership and beneficiary changes

A module's current maintainer, legal owner, and revenue beneficiary can change. Store effective-dated relationships and ensure historical sales remain attributable to the beneficiary agreed at the time of sale. Do not recompute old settlement entries based on today's owner.

# 20. Detailed example: Company A sells CRM to Company B

**Initial state:** Parent originally developed CRM. Company A publishes improved `company_a.crm_advanced` version `2.1.0`. Company B wants to use it on `INST-00852`. Company C is not entitled.

### Phase 1 — Publish

1. Company A registers as publisher.
2. Company A uploads immutable CRM 2.1.0 ZIP, manifest, and release notes.
3. Parent checks ownership, dependencies, compatibility, package security, and approval.
4. MTA signs approved release manifest and archive SHA-256.
5. Marketplace publishes release and plan.

### Phase 2 — Purchase

6. Company B places order for one installation.
7. Parent-approved commercial process records purchase and creates `ENT-000152`.
8. Entitlement specifies Company B, CRM Advanced, version range `[2.0.0, 3.0.0)`, features, and installation limit `1`.

### Phase 3 — Register and activate offline

9. Company B generates installation key pair and registration package.
10. Parent verifies Company B and registers public key under `INST-00852`.
11. Parent issues challenge bound to installation and entitlement.
12. Company B signs canonical activation request; transfers response to parent.
13. Parent validates challenge, signature, company ownership, and quota transactionally.
14. Parent creates `ACT-000852`, `LIC-000015`, and signed `CERT-000152`.
15. Company B imports certificate after verifying trusted LA signature and local identity.

### Phase 4 — Install and execute

16. Company B imports approved CRM ZIP and MTA release signature.
17. Installer verifies ZIP safety, digest, signature, compatibility, and dependencies.
18. Admin installs then activates module.
19. Runtime policy checks license, status freshness, module state, feature, and user permission.
20. Company B's authorized employee can use CRM; Company C cannot import or execute B's certificate.

### Phase 5 — Revocation or renewal

21. Parent issues scoped signed status sequence `12` with validity deadline.
22. Company B imports status. If license is revoked, runtime denies further execution.
23. On renewal, parent updates entitlement and issues a new signed certificate revision; local import is atomic.

### Phase 6 — Settlement

24. Parent posts gross sale, commission, and Company A payable to immutable ledger.
25. Parent reconciles approved accounting records and issues settlement statement.

# 21. Offline deployment, operations, and disaster recovery

## 21.1 Recommended environments

| Environment | Purpose | Security posture |
|---|---|---|
| Parent LA | Keys, activation, certificate/status signing | Highly restricted, separate administrative roles |
| Parent MTA | Release approval/signing | Separate key and approval path |
| Parent Marketplace | Catalog, orders, entitlement workflow | No direct access to private signing keys without controlled interface |
| Subsidiary admin | Import, module installation, local license management | Restricted administrators, audited changes |
| Subsidiary business | Module execution | Read-only license data, limited runtime privileges |

## 21.2 Initial provisioning runbook

1. Inventory company code, site ID, OS, PHP 7.4 extensions, MariaDB version, module inventory, and transfer-media process.
2. Provision trusted LA/MTA public keys using independently verified fingerprints.
3. Generate installation key; protect its private portion; approve registration at parent.
4. Create separate least-privilege DB accounts for admin import and runtime read access.
5. Establish trusted time and status update cadence.
6. Test certificate verification and reject a deliberately tampered certificate.
7. Import approved module ZIP and verify MTA signature.
8. Run end-to-end activation and denial tests before enabling business users.
9. Record recovery contacts, backup procedure, and key-loss procedure.

## 21.3 Routine operations

**Daily/each transfer window:** Inspect pending activation requests, status publication age, import failures, activation limit alarms, module release notices, and clock anomalies.  
**Weekly:** Confirm latest signed status package was received within policy, review revocations, failed signatures, and entitlement changes.  
**Monthly:** Reconcile settlements, verify backup restore drills, audit publisher approvals, and review deprecated modules.

## 21.4 Backup and restore

Back up encrypted local DB, approved identity metadata, signed certificate/status files, and audit logs. Keep installation private key backup under separately approved key-custody rules; a lost private key may require installation re-registration and license reissuance. After restore, do **not** blindly accept an old status sequence; reconcile with protected latest state or require a parent-approved recovery package. Test restores in a nonproduction environment.

## 21.5 Key compromise

If an LA signing key is compromised, revoke its trust through an authenticated emergency process, stop issuance, rotate keys, publish replacement trust anchors, and reissue affected certificates/status. If an installation key is compromised, suspend its registration and issue a replacement identity and activation under parent approval. If an MTA key is compromised, quarantine release verification until trust anchors and approved manifests are reconciled.

# 22. Security threat model and limitations

| Threat | Mitigation | Remaining limitation |
|---|---|---|
| Forged license | Ed25519 signature and trusted LA key | LA private-key compromise defeats trust |
| Modified license claims | Verify exact signed bytes | Parser ambiguity must be rejected |
| Certificate copied to Company C | Company/install/key fingerprint binding | Full local identity+private key clone remains possible |
| Replayed activation challenge | One-use challenge, expiry, bound signed message | Compromised authority DB can alter state |
| Concurrent quota bypass | Entitlement row lock + unique constraints | Incorrect alternate code path can bypass lock |
| Fake module ZIP | MTA signature + SHA-256 + review | Approved code can still be malicious or vulnerable |
| Offline revocation delay | Short-lived signed status snapshots | Cannot revoke instantly without communication |
| Local clock rollback | Internal time controls, anomaly detection | Privileged host operator can subvert software-only checks |
| Local DB rollback | Protected monotonic state and recovery policy | DB-only sequence cannot prevent whole-DB rollback |
| Developer omits license check | Central dispatchers and tests | Direct PHP execution outside dispatchers remains a gap |
| Malicious module inside PHP runtime | Approval, least privilege, separate process/service for risky modules | Shared runtime is not a security sandbox |
| Status import denial-of-service | Size limits, strict parsing, atomic import | Fail-closed policies can affect availability |
| Signing key stolen | Restricted custody, rotation, dual approval | Historical signatures may require re-evaluation |

Never claim absolute prevention of module piracy in a software-only offline environment. Set an achievable security goal: make unauthorized ordinary use difficult, detect and audit misuse, and enforce policy for trusted deployments.

# 23. Test strategy and acceptance criteria

## 23.1 Unit tests

- Base64url strict/canonical round-trip and invalid-input rejection.
- Ed25519 valid signature and tampered payload rejection.
- Unknown key ID, wrong algorithm, malformed envelope, oversized JSON, duplicate JSON keys.
- Version lower-inclusive/upper-exclusive semantics and prerelease handling.
- Not-before, usage expiry, update expiry, feature list.
- Wrong company, wrong installation, wrong public-key fingerprint.
- Expired/stale status, revoked license, monotonic sequence.

## 23.2 Authority integration tests

- Register installation only after authenticated parent approval.
- Challenge is single-use, bound, random, and time-limited.
- Invalid activation signature rejected.
- Entitlement belongs to correct company and module.
- One active slot: two concurrent requests result in at most one new activation.
- Exact retry returns identical stored certificate.
- Same request ID with different digest rejected.
- Different request with used challenge rejected.
- Rollback leaves no half-issued certificate.
- Deadlock retry preserves correctness.

## 23.3 Client integration tests

- Import valid certificate; import same file twice idempotently.
- Reject conflicting certificate with same ID/revision.
- Reject stale revision and retain previous valid certificate.
- Import status sequence; reject older status.
- Fail-closed on expired status according to configured policy.
- Cache invalidation after revocation or renewal.
- Simulate DB unavailable and confirm documented denial/fallback behavior.

## 23.4 ZF1 integration tests

- Enabled + licensed + authorized principal: allow.
- Disabled module: deny.
- Unlicensed REST route: deny.
- CLI and cron job: deny when license invalid.
- Hook callback: deny when owning module invalid.
- Admin user does not bypass business licensing.
- Core login/refresh endpoints remain available under explicit core-service policy.
- Untrusted module cannot register another module's ownership in registry.

## 23.5 Acceptance criteria for first production pilot

1. Complete offline activation works from fresh installation to signed certificate import.
2. Unauthorized company and installation tests consistently fail.
3. Concurrent activation tests prove quota enforcement.
4. Parent status revocation blocks runtime after import.
5. All known module entry points are inventoried and centrally checked.
6. Approved ZIP signature and hash verification are mandatory.
7. Backup/restore and key-loss runbooks are tested.
8. Auditors can correlate order -> entitlement -> activation -> certificate -> module execution decision -> settlement.
9. Security review explicitly accepts remaining offline and legacy-platform risks.

# 24. Implementation roadmap and deliverables

| Phase | Scope | Exit criterion |
|---|---|---|
| 0 | Inventory modules, routes, jobs, hooks, trust boundaries | Complete entry-point map |
| 1 | Shared cryptographic protocol, schemas, identity | Unit tests pass |
| 2 | Offline challenge-response, activation, idempotency | Live MariaDB integration tests pass |
| 3 | Certificate import and local License Manager | Offline verification and revision tests pass |
| 4 | Signed status, revocation, freshness | Revocation and stale-status tests pass |
| 5 | ZF1 registry, controller plugin, CLI/job/hook enforcement | No known bypass through supported entry points |
| 6 | MTA signing, ZIP validation, installer integration | Approved immutable release installed safely |
| 7 | Developer portal, publication, catalog, plans | Approved module can be published and discovered |
| 8 | Orders, entitlements, ledger, settlement | Company A sale to B reconciles |
| 9 | Pilot, audit, key rotation, recovery | Parent and subsidiary sign off |

**Prototype progression discussed:** v0.1 basic authority/activation; v0.2 local client DB and import; v0.3 signed status/revocation; v0.4 ZF1-oriented runtime adapter and smoke tests; proposed v0.5 automatic ZF1 access-policy enforcement. These ZIPs were described as **development prototypes**, not as live-DB-tested or fully production-hardened releases. Part 19 supplied architectural examples, not a completed v0.5 ZIP.

# 25. Reference PHP, SQL, JSON, and command examples

## 25.1 Environment checks (offline)

```bash
php -v
php -m
php -r "echo extension_loaded('sodium') ? 'sodium OK' : 'sodium MISSING';"
php -r "echo extension_loaded('pdo_mysql') ? 'pdo_mysql OK' : 'pdo_mysql MISSING';"
```

If extensions are missing, provision them from trusted internal installation media. Do not fetch packages from the public Internet on isolated servers.

## 25.2 Ed25519 example (standalone PHP 7.4)

```php
<?php
if (!extension_loaded('sodium')) {
    throw new RuntimeException('ext-sodium required');
}
$keypair = sodium_crypto_sign_keypair();
$secretKey = sodium_crypto_sign_secretkey($keypair);
$publicKey = sodium_crypto_sign_publickey($keypair);
$message = "S3-LICENSE-V1\nlicense-2026-01\nEXAMPLE_PAYLOAD";
$signature = sodium_crypto_sign_detached($message, $secretKey);
if (!sodium_crypto_sign_verify_detached($signature, $message, $publicKey)) {
    throw new RuntimeException('Signature verification failed');
}
echo "Signature OK\n";
sodium_memzero($secretKey);
```

This is a **cryptographic API demonstration only**; it does not implement secure key storage, certificate schema, or issuance policy. Do not embed secret keys in source files or logs.

## 25.3 Offline workflow command examples from prototypes

```bash
# Parent authority (illustrative prototype CLI)
php bin/app.php keys
php bin/app.php company COMPANY_B "Company B"
php bin/app.php identity COMPANY_B
php bin/app.php entitlement COMPANY_B company_a.crm_advanced 1 2.0.0 3.0.0

# Subsidiary client (illustrative prototype CLI)
php bin/client.php import license.json company-b-identity.json company_a.crm_advanced 2.1.0
php bin/client.php check company-b-identity.json company_a.crm_advanced 2.1.0
php bin/client.php list

# Parent status publication (illustrative prototype CLI)
php bin/issue-status.php 12 2026-10-21T00:00:00Z revoked.json status.json

# Subsidiary status import
php bin/client.php import-status status.json

# Prototype smoke tests
php tests/smoke.php
```

These commands reflect the earlier prototype interface; inspect each ZIP's actual README and file layout before execution. They are not a substitute for end-to-end testing, and example file names are placeholders. The `keys` operation must be run in a protected environment and never expose private keys to ordinary users.

## 25.4 Runtime status and API response

```json
{
  "success": false,
  "error": {
    "code": "LICENSE_EXPIRED",
    "message": "The CRM module license has expired."
  }
}
```

Use appropriate HTTP status codes (often 403 for a well-formed unauthorized business operation), consistent JSON response contracts, and internal logs with more detail than is shown to ordinary users. Do not expose signing-key paths, raw certificates, or internal installation secrets in public API responses.

## 25.5 Recommended source tree for a consolidated implementation

```text
module-licensing-foundation/
  authority/
    src/{ActivationProcessor,ChallengeManager,CertificateIssuer}.php
    src/{EntitlementRepository,InstallationRepository,AuditRepository}.php
    bin/{register-installation,generate-challenge,activate-license}.php
  client/
    src/{InstallationIdentity,LicenseImportService,LicenseValidator}.php
    src/{LicenseManager,LicenseRepository,SignatureVerifier}.php
    bin/{generate-installation,sign-challenge,import-license,verify-license}.php
  shared/{Base64Url,Json,Protocol,Exceptions}.php
  database/{authority-schema,client-schema,demo-data}.sql
  zf1/library/S3/{License,Module,Controller}/...
  tests/{Unit,Integration,Security}/...
  config/{authority.example,client.example}.php
  docs/{OPERATIONS,SECURITY,ZF1-INTEGRATION,PROTOCOL}.md
  README.md
```

# 26. Troubleshooting and operational checklist

| Symptom | Likely causes | Safe action |
|---|---|---|
| `INVALID_SIGNATURE` | Wrong public key, modified payload, encoding mismatch | Verify key ID/fingerprint and exact signed bytes; do not bypass verification |
| `INSTALLATION_MISMATCH` | Certificate for another server or cloned/misconfigured identity | Compare approved installation ID and key fingerprint; request authorized reissue |
| `LICENSE_VERSION_DENIED` | Installed version outside signed range | Install an approved compatible release or renew entitlement |
| `LICENSE_STATUS_STALE` | Status package expired or not imported | Obtain newer signed status; follow approved exception procedure only |
| `LICENSE_REVOKED` | Revocation included in trusted status | Confirm parent decision; do not edit local DB to reactivate |
| `ACTIVATION_LIMIT_REACHED` | Active slot count equals plan limit | Release/transfer slot through approved parent workflow |
| `CHALLENGE_USED` | Replay or completed activation | Retry same request ID for existing certificate; otherwise request new challenge |
| `UNKNOWN_KEY_ID` | Trust anchor not provisioned/rotated | Verify and import parent-approved trust-anchor update |
| `ZIP_HASH_MISMATCH` | Corrupted or altered module ZIP | Quarantine and retransfer exact approved release |
| `DB_LOCK_TIMEOUT` | Concurrent activation or long transaction | Investigate contention and use bounded safe retry |
| `MODULE_DISABLED` | Administrative state disabled | Verify business/admin decision; do not alter license claims |

**Offline checklist:** Verify trusted key fingerprints, confirm DB backup, check clocks, inspect file hashes, ensure latest status sequence, confirm entitlement, run denial tests, verify all entry points, log import operator, and keep signed originals.

# 27. Open decisions and future enhancements

1. **Hardware binding:** Is software installation identity sufficient, or must selected modules require USB token/TPM/HSM-backed non-exportable keys?
2. **Status cadence:** Which module categories require 24-hour, 7-day, or 30-day freshness? What is the approved outage policy?
3. **Activation transfers:** What approval, cooldown, slot release, and lost-server procedures apply?
4. **Reinstatement:** How should a revoked license be reinstated without ambiguous snapshot semantics?
5. **Clock trust:** What internal time service and rollback detection are available?
6. **Signing-key custody:** Who can authorize key generation, rotation, emergency compromise response, and offline signing?
7. **Marketplace accounting:** What taxes, currencies, refunds, withholding, payment terms, and settlement periods apply?
8. **Module isolation:** Which modules require process/service isolation rather than shared PHP execution?
9. **Version policy:** How will SemVer, prerelease versions, and update entitlement be applied consistently?
10. **Legacy modernization:** What is the approved timetable to migrate PHP 7.4/ZF1 to supported software?
11. **Enterprise scope:** Are entitlements company-wide, per installation, per environment, per site, or per named business unit?
12. **Offline transfer:** Which authorized media, custody logs, encryption-at-rest requirements, and import approval steps are mandatory?

Future work may include delegated resellers, marketplace search/rating, trial conversion, volume discounts, offline renewal bundles, entitlement pooling, license usage analytics, cryptographically signed audit exports, and a parent-controlled module dependency catalog.

# 28. Glossary

| Term | Definition |
|---|---|
| Activation | Association between an entitlement and an approved installation |
| Certificate | Signed statement of executable rights for a specific activation |
| Entitlement | Commercial right acquired through purchase or parent allocation |
| Installation identity | Registered installation ID and cryptographic key pair |
| LA | License Authority; signs licenses and status packages |
| MLM | Module License Manager; verifies licenses locally |
| MTA | Module Trust Authority; approves/signs software releases |
| Module registry | Trusted local record of installed modules and entry-point ownership |
| Revocation snapshot | Signed, sequenced status package describing revoked rights in a defined scope |
| Release manifest | Metadata identifying immutable software archive, hash, compatibility, and dependencies |
| Domain separation | Different signed-message prefixes/keys for distinct protocol purposes |
| Idempotency | Repeating the same logical request has no duplicate side effects |
| Fail-closed | Deny authorization when required trust/status checks cannot be satisfied |
| Trust anchor | Independently provisioned trusted public key |
| Offline transfer | Controlled file movement without direct network communication |

---

## Final architectural recommendation

Build the system in layers: **(1) trusted release signing, (2) commercial entitlements, (3) offline activation and signed certificates, (4) local status/revocation, (5) central ZF1 runtime enforcement, and (6) marketplace accounting**. Keep these responsibilities separate, test them independently, and join them through stable identifiers and auditable workflows. Prioritize a complete, live-database-tested offline Company A → Company B demonstration before deploying to additional subsidiaries.

**End of consolidated reference.**
