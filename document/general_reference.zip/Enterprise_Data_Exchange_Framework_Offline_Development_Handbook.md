# Enterprise Multi-Hop Data Exchange Framework

## Expanded Offline Development Handbook — Requirements, Protocol, Security, Database, APIs, Algorithms, Operations, and Testing

**Document version:** 2.1 (expanded enterprise PKI and cryptography implementation reference)  
**Prepared:** 2026-10-14  
**Status:** Architecture and implementation specification; not yet a production-certified protocol  
**Target stack:** PHP 7.4, Zend Framework 1 (ZF1), MariaDB 10.11, CentOS, DHTMLX 3.5, jQuery, ES5 JavaScript  
**Scope:** Parent company, subsidiaries, isolated Inner/Outer sites, multi-hop exchange, reusable business modules  

> **Scope clarification:** The authorized dongle remains the **only approved transfer mechanism between an Inner and Outer site**. Its internal hardware, software, authentication and transfer algorithm are managed by another department and **are not designed here**. This document specifies only the file handoff, receipt and recovery contracts at that boundary.

---

## Contents

**How to use offline:** Read Chapters 1–17 for the agreed architecture; continue with Appendices A–N for expanded implementation contracts, code, SQL, algorithms, test cases, and operational runbooks. All snippets are reference designs and must be integrated and tested before production.


1. Executive summary and design decisions
2. Business context, sites and trust boundaries
3. Requirements and non-goals
4. Enterprise routing and delivery examples
5. Business events, multi-destination grouping and synchronization
6. Delivery semantics, acknowledgements and state machines
7. Package format and protocol contract
8. Cryptography, PKI, trust and key lifecycle
8A. **Enterprise PKI, Digital Signatures, Encryption, and Trust Management — detailed implementation reference**
9. Transactional outbox, inbox and database design
10. PHP/ZF1 component architecture and developer API
11. File handoff and HTTPS transport adapters
12. Background workers, retry, idempotency and recovery
13. Security threat model and hardening
14. Administration, monitoring and audit
15. Testing, deployment and phased roadmap
16. Open decisions, acceptance criteria and implementation checklist
17. Glossary and references

---

# 1. Executive Summary and Design Decisions

The Data Exchange (DX) Framework provides **reliable, bidirectional, asynchronous, encrypted, signed, package-based business-data exchange** among companies whose Inner and Outer environments cannot communicate directly over a network. It serves Email, CRM, Product, Blog, Notification, and future modules through one stable application API.

**Canonical path for Company A → Company B:**

```text
COMPANY_A.INNER
   |  signed, encrypted package
   v
[approved dongle file handoff]
   |
COMPANY_A.OUTER
   |  HTTPS + mutual TLS
   v
PARENT.OUTER  (store-and-forward routing hub; no business decryption)
   |  HTTPS + mutual TLS
   v
COMPANY_B.OUTER
   |
[approved dongle file handoff]
   v
COMPANY_B.INNER
   |  validate, decrypt, commit business event
   v
signed End-to-End ACK → reverse authorized route → COMPANY_A.INNER
```

The reverse direction uses the same architectural rules. No direct network link is introduced between any Inner and Outer site. Parent Outer is not a trusted plaintext processor.

| Decision | Baseline |
|---|---|
| Delivery model | At-least-once, store-and-forward, idempotent business processing |
| Routing | Parent Outer central hub for cross-company traffic |
| Inter-site payload | One immutable, destination-specific end-to-end protected package |
| Encryption | AES-256-GCM with fresh per-package content-encryption key (CEK) |
| Key transport | Recipient Inner public-key wrapping / approved KEM; exact provider and parameters to be fixed |
| Origin authentication | End-to-end digital signature (baseline ECDSA P-256 / SHA-256) |
| Transport authentication | mTLS between Outer sites; authenticated receipts for every hop |
| Custody confirmation | Hop ACK (H-ACK) after durable acceptance |
| Final processing confirmation | Signed End-to-End ACK (E-ACK) after committed business processing |
| Database | MariaDB 10.11 transactional outbox/inbox, no Redis |
| Backend | PHP 7.4 + ZF1 for initial integration |
| UI | DHTMLX 3.5 + jQuery + ES5; locally hosted resources |
| Runtime | PHP CLI workers with cron/systemd supervision |
| Security management | Offline root CA, separated subordinate Inner/Outer CAs, signed monotonic trust-directory updates |
| Dongle | External approved subsystem; only file handoff contract is in scope |

**Security caveat:** PHP 7.4 and original ZF1 are legacy software. Production deployment requires a documented exception, supported patching/containment strategy, independent security review and migration plan. The exact wire protocol and crypto provider require interoperation tests and security approval before production use.

# 2. Business Context, Sites and Trust Boundaries

## 2.1 Actors and environments

- **Parent company:** Coordinates enterprise routing and trust governance.
- **Subsidiaries:** Each runs a separate Inner Site and Outer Site.
- **Internal users (Group A):** Use Inner Site within a restricted internal environment.
- **External users (Group B):** Use Outer Site through a controlled private VPN.
- **Enterprise Security Authority:** Issues and governs site identities, certificates, revocation and signed directory updates.
- **Authorized transfer subsystem:** Transfers approved files across the isolated boundary; outside DX implementation scope.

Example site IDs:

```text
PARENT.OUTER
COMPANY_A.INNER     COMPANY_A.OUTER
COMPANY_B.INNER     COMPANY_B.OUTER
COMPANY_C.INNER     COMPANY_C.OUTER
```

IDs must be stable, unique and cryptographically bound to site certificates. Do not infer site identity from a caller-supplied string.

## 2.2 Non-negotiable isolation

- Inner and Outer have **no direct TCP/IP, HTTP, REST, WebSocket, database or shared network filesystem communication**.
- The only approved cross-boundary mechanism is the authorized dongle's file transfer.
- Inner Sites do not directly connect to Parent Outer or other subsidiaries.
- Outer Sites use authenticated network connections to Parent Outer, not to Inner Sites.
- Parent Outer does not store destination decryption private keys or execute business handlers.

## 2.3 Trust boundaries

| Boundary | Required controls |
|---|---|
| Business module → local DX API | Module authorization, payload schema, transaction discipline |
| Inner → handoff directory | Safe publication, file permissions, immutable package, local custody record |
| Handoff → Outer receive directory | Untrusted-input validation, durable receipt, authenticated H-ACK |
| Outer → Outer over network | mTLS, signed package verification, route policy, durable custody |
| Outer → destination Inner | Same strict file validation and custody semantics |
| Destination DX → business handler | Verified origin, authorization, schema, replay protection, DB transaction |
| Admin UI → DX management API | Authentication, RBAC, CSRF defense, audit, approval for critical changes |

# 3. Requirements and Non-Goals

## 3.1 Functional requirements

1. Publish one business event to one or multiple authorized destination Inner Sites.
2. Generate independent destination packages and delivery histories.
3. Encrypt business payloads and attachments so intermediates cannot read them.
4. Sign immutable package content and verify sender/site identity at each receiving hop.
5. Route cross-company traffic via Parent Outer.
6. Maintain durable custody and authenticated hop acknowledgements.
7. Process business events idempotently at destination Inner Sites.
8. Return signed final processing results through the reverse authorized path.
9. Recover from crashes, duplicate files, missing ACKs, stale leases and delayed handoffs.
10. Support versioned event schemas, dependency waiting, full-state sync, ordered changes and append-only events.
11. Provide local monitoring and authenticated delayed status reporting to Parent Outer.
12. Maintain audit evidence and administrator-controlled safe recovery actions.

## 3.2 Non-functional requirements

- **Security:** Confidentiality, integrity, authenticity, authorization, replay defense, key separation.
- **Reliability:** No silent loss of committed business events; no duplicate business side effects for replayed events.
- **Operability:** Clear statuses, retries, recovery tools, alerting and runbooks.
- **Maintainability:** Stable public API and separable service implementations.
- **Offline compatibility:** Local assets, offline trust bundles and no dependence on Internet services.
- **Scalability:** Database claims, batch processing, configurable size/concurrency limits.
- **Traceability:** Correlation among event, package, transfer, ACK and audit identifiers.

## 3.3 Explicit non-goals

- Implementing or redesigning the dongle or its driver/software.
- Providing live Inner Site status to Parent Outer.
- Guaranteeing delivery when an intermediate site intentionally drops all traffic.
- Guaranteeing exactly-once network delivery; **at-least-once with idempotent effects** is the objective.
- Letting Outer/Parent decrypt confidential business payloads.
- Treating transport custody as proof of business processing or user reading.

# 4. Enterprise Routing and Delivery Examples

## 4.1 Standard forward route

```text
A.INNER --handoff--> A.OUTER --mTLS--> PARENT.OUTER --mTLS--> B.OUTER --handoff--> B.INNER
```

Each hop verifies package identity and applicable security/routing policy. The original package remains unchanged. Each hop's transfer state and custody receipt are stored separately.

## 4.2 Reverse acknowledgements

```text
B.INNER --handoff--> B.OUTER --mTLS--> PARENT.OUTER --mTLS--> A.OUTER --handoff--> A.INNER
```

An E-ACK is a **separate signed control object** referencing the original immutable package. H-ACKs are hop-specific receipts. Neither ACK type triggers ACK-of-ACK recursion.

## 4.3 Email grouping and privacy

Alice at A sends one email to Bob and Charlie at B, David at C. The Email module creates **one business email ID** and **one delivery payload per destination**:

```text
EMAIL-50001
  ├── destination B: Bob + Charlie → encrypted package PKG-B
  └── destination C: David         → encrypted package PKG-C
```

Local recipients are handled locally. To/Cc/Bcc visibility must be computed by the Email module before publication; Bcc recipients must not leak into unrelated destination packages. Packages and E-ACKs are independent per destination.

# 5. Business Events and Synchronization

## 5.1 Event identity and naming

Use stable event names such as `crm.customer.updated`, `email.deliver`, `product.catalog.updated`, `notification.created`, `blog.article.published`.

A business event contains a stable `event_id`, `event_type`, `event_version`, verified source/destination context, and validated payload. Entity synchronization may add `entity_type`, `entity_id`, `entity_version`, and owner identity.

**Two levels of idempotency:**

- Package: `(package_id, package_hash)` — same ID + same hash is replay; same ID + different hash is a security conflict.
- Business event: `(source_site, event_id)` — suppress duplicate committed effects even if a replay arrives in another package.

An event published to multiple destinations uses the same logical event ID with **destination-specific outbox uniqueness** `(source_site, event_id, destination_site)`.

## 5.2 Synchronization modes

| Mode | Rule | Example |
|---|---|---|
| `FULL_STATE` | Apply latest authoritative snapshot; may skip intermediate versions if contract permits | Customer profile |
| `ORDERED_CHANGE` | Apply changes in strict sequence; queue missing predecessor | Inventory delta |
| `APPEND_ONLY` | Preserve unique entries and required ordering/dependencies | Financial journal |

A single authoritative owner per entity is the default. Conflicting writers require explicit reconciliation policy. A destination must not infer that Parent Outer's last reported version is a live version.

## 5.3 Version compatibility

- Package protocol version and **business event schema version are independent**.
- Unknown mandatory protocol features cause rejection or a defined `UNSUPPORTED_VERSION` result.
- Unsupported event versions wait for a compatible handler or a **registered trusted transformation**; never silently guess.
- Schema files belong to business modules, not to the router.

# 6. Delivery Semantics, ACKs and State Machines

## 6.1 Publication is not delivery

`publish()` succeeds when the event has been recorded in the caller's local outbox transaction; it does not wait for package creation or remote processing. If the caller's transaction later rolls back, the publication did not occur.

## 6.2 Hop ACK (H-ACK)

A receiving hop issues an authenticated H-ACK only after:

1. The package has passed required admission and cryptographic checks.
2. Its identity and route are acceptable.
3. It has been durably stored and recorded for custody/recovery.
4. The receipt is bound to the package hash and specific hop transfer.

The sending hop may release its transfer copy only after verifying the receipt and meeting retention policy. File disappearance or HTTP 200 alone is not an H-ACK.

## 6.3 End-to-End ACK (E-ACK)

Only destination Inner issues the signed E-ACK. A successful result requires the business update, processed-event record, and E-ACK outbox record to commit atomically. An E-ACK proves **business processing**, not that a user opened/read an item.

Example logical E-ACK fields:

```json
{
  "ack_type": "END_TO_END_ACK",
  "ack_id": "ACK-50001",
  "original_package_id": "PKG-50001",
  "original_package_hash": "<sha256-hex>",
  "original_event_id": "EVT-50001",
  "source_site": "COMPANY_B.INNER",
  "destination_site": "COMPANY_A.INNER",
  "result": "SUCCESS",
  "processed_at": "2026-10-13T10:00:00Z"
}
```

This is a **logical payload example**, not complete signed wire framing. It must be signed, versioned, replay-protected and validated against the original package.

## 6.4 State separation

**Outbox/build:** `PENDING → CLAIMED → BUILDING → READY` or waiting/failure states.  
**Hop transfer:** `READY → IN_TRANSIT → WAITING_H_ACK → H_ACKNOWLEDGED` (or retry/reject).  
**Destination inbox:** `RECEIVED → VALIDATING → ACCEPTED → PROCESSING → SUCCESS / WAITING_DEPENDENCY / RETRYABLE_FAILURE / PERMANENT_FAILURE`.  
**Origin delivery:** `WAITING_E_ACK → ACKNOWLEDGED / CONFIRMED_FAILURE`, with unknown/timeouts separately represented.

A package may have multiple hop transfer records; do not force all transfer and business states into one ambiguous column. Missing E-ACK means **unconfirmed**, not necessarily failed.

# 7. Package Format and Protocol Contract

## 7.1 Protocol baseline

Use a versioned **DXP/1** package contract (working name). The final binary framing, canonicalization library, signature preimage and test vectors **must be frozen and reviewed before interoperable production use**.

Suggested logical components:

```text
<opaque-package-id>.dxp
  routing header        (minimal immutable metadata needed by intermediates)
  cryptographic header  (algorithms, key IDs, nonce, wrapped CEK, etc.)
  encrypted body        (event type, payload, private recipient data, attachments)
  detached signature    (authenticates protected immutable header + ciphertext digest)
```

A ZIP container is possible but must not be signed by naively hashing the entire archive containing its own signature (circular dependency). A simpler fixed framing may be safer; choose one definitive encoding before coding.

## 7.2 Public routing metadata

Minimum fields:

| Field | Meaning |
|---|---|
| `protocol_version` | Explicit format version |
| `package_id` | Immutable globally unique package identity |
| `source_site` | Origin Inner identity |
| `destination_site` | Final destination Inner identity |
| `created_at` | Claimed origin time; not trusted proof of signing time |
| `signing_key_id` | Key used for end-to-end signature |
| `encryption_key_id` | Recipient public encryption key reference |
| `crypto_suite` | Explicit supported algorithm suite |
| `nonce` | AEAD nonce, bound to package |
| `wrapped_cek` | Encrypted content key for destination |
| `ciphertext_sha256` | Ciphertext digest authenticated by signature |
| `critical_extensions` | Required features, if any |

**Avoid publishing business event type, subject, recipients, attachments or PII in routing headers unless strictly required by policy.** If routing policy needs classification, define an approved signed coarse classification.

## 7.3 Encrypted body

Example **plaintext before encryption**:

```json
{
  "event_id": "EVT-50001",
  "event_type": "crm.customer.updated",
  "event_version": 1,
  "entity": {
    "type": "crm.customer",
    "id": "CUST-10001",
    "version": 3
  },
  "payload": {
    "customer_id": "CUST-10001",
    "name": "ABC Corporation",
    "version": 3
  },
  "attachments": []
}
```

Attachments may be embedded in one encrypted body or protected as independently authenticated blobs with unique nonce/key derivation rules. **Do not mix both without a written protocol.**

## 7.4 Canonical serialization and authenticated binding

A safe design must specify exact bytes for:

1. The immutable header signed by the origin.
2. The AEAD associated data (AAD).
3. The encrypted body and its digest.
4. The detached signature input, including domain separation.
5. The whole-package hash used for custody/deduplication.

Recommended design constraint: AAD is computed from a deterministic subset of immutable metadata **before** ciphertext digest/signature exist; the signature authenticates the final immutable header including ciphertext digest. This avoids circular dependencies. Use an audited canonical JSON implementation (e.g. a correctly implemented RFC 8785 profile with strict restrictions) **or a fixed binary encoding**. PHP JSON serialization alone is not an adequate cross-language canonicalization contract.

The whole-package SHA-256 is computed over final immutable bytes. An optional external `.sha256` sidecar supports accidental corruption detection, **not authenticity**; authenticity comes from signatures/AEAD and validated identities.

## 7.5 File/archive validation

Reject or safely handle:

- Absolute paths, `../`, symlinks, duplicate/case-colliding entry names.
- Unexpected files, nested archives and unsupported compression methods.
- Excessive compressed or expanded sizes, entry counts and decompression ratios.
- Invalid UTF-8, ambiguous JSON keys, oversized manifests, unknown critical extensions.
- Nonce/key reuse, unsupported algorithms, malformed signatures and tags.

Validate cheap structural bounds before expensive crypto; **never execute** contents or call arbitrary classes from package metadata.

## 7.6 Package validation order

```text
Receive file
 → safe claim and size/format bounds
 → parse strict routing/crypto header
 → verify ciphertext digest and origin signature
 → validate certificate chain, site identity and revocation policy
 → validate route, destination and source permissions
 → check package ID/hash replay state
 → durably accept custody; issue H-ACK
 → if final Inner: unwrap key, authenticate/decrypt, validate event schema
 → deduplicate business event and invoke registered handler
 → commit business changes + processed-event + E-ACK outbox
```

For security-sensitive stages, policy may require certain authorization checks before custody acceptance; define the exact H-ACK acceptance contract uniformly at all sites.

# 8. Cryptography, PKI, Trust and Key Lifecycle

## 8.1 Cryptographic separation

- **AES-256-GCM:** Encrypt/authenticate private body; fresh 256-bit CEK per package and 96-bit nonce unique for that CEK.
- **Public-key wrapping:** Protect CEK for destination Inner. RSA-OAEP-SHA256 or approved ECDH/KEM suite; implementation must actually support the specified OAEP hash.
- **ECDSA P-256 / SHA-256:** Authenticate immutable origin package and destination E-ACK.
- **SHA-256:** Package/ciphertext hashes; hashes alone are not authentication.
- **mTLS:** Authenticate Outer-to-Outer transport; it does not replace end-to-end signatures.

Use separate signing, decryption and transport credentials. Never embed private keys in packages, application source or logs. Generate randomness with a cryptographically secure generator (PHP `random_bytes()` or vetted provider).

## 8.2 Enterprise PKI

```text
Offline Enterprise Root CA
  ├── Inner Site Issuing CA
  └── Outer Site Issuing CA
```

Site identity is bound to X.509 SAN and suitable certificate policy/usage. The Enterprise Security Authority signs a versioned directory of site identities, certificates, allowed roles and revocations. Parent Outer distributes that directory but cannot issue or rewrite it.

**Trust bootstrap** must be performed through an independently authenticated installation process. Do not trust the first certificate simply because it arrived via the routing hub.

## 8.3 Offline directory updates

Each site tracks highest accepted directory version and revocation freshness. Reject rollback. Missing recipient certificate → `WAITING_CERTIFICATE`, not plaintext fallback. Stale revocation information → hold/reject according to risk policy; do not silently ignore.

A certificate's `notBefore/notAfter` and a package's self-declared timestamp do not independently establish historical signing validity. Compromised-key handling requires documented signing-time and revocation policy.

## 8.4 Rotation and incident response

1. Issue replacement keys/certificates under approved authority.
2. Publish signed directory update and revocation information.
3. Retain necessary old decryption keys securely for authorized in-flight packages during an approved overlap period.
4. Stop new signing with compromised/retired keys.
5. Quarantine uncertain packages and preserve evidence.
6. Verify all sites have accepted required trust updates before resuming sensitive flows.

**Unresolved implementation gate:** Select reviewed PHP 7.4-compatible crypto provider or compiled extension. Do not claim PHP's default `openssl_public_encrypt(..., OPENSSL_PKCS1_OAEP_PADDING)` provides RSA-OAEP-SHA256 without verifying the provider's hash controls.


# 8A. Enterprise PKI, Digital Signatures, Encryption, and Trust Management — Detailed Implementation Reference

> **Status and normative language:** This is a development design for offline review. “MUST” denotes a required security invariant; “SHOULD” denotes a strong recommendation. The exact DXPP 1.0 binary serialization and cryptographic suite remain a release gate. Examples are not a production-certified cryptographic library. Never use test keys in production.

## 8A.1 Purpose, boundaries, and protection goals

The Enterprise Public Key Infrastructure (PKI) identifies sites, distributes verified public keys, and controls which sites may sign, receive, route, or transport DX packages. The original Inner Site signs a package and encrypts its business content for the destination Inner Site. Outer Sites, including Parent Outer, transport opaque encrypted packages. The destination Inner Site verifies origin and authorization, decrypts, applies an idempotent business transaction, and signs the end-to-end acknowledgement.

**Key separation is mandatory.** Site signing keys authenticate origin, destination encryption keys protect CEKs, transport keys authenticate Outer-to-Outer TLS sessions, and CA keys issue credentials or trust metadata. One key must not silently serve multiple purposes.

```text
                      Enterprise Security Authority
                           offline trust anchors
                                   |
                         Offline Enterprise Root
                            /               \
                   Inner Issuing CA     Outer Issuing CA
                     /         \           /         \
               A.Inner      B.Inner    A.Outer    Parent.Outer
                 |             |          |            |
             sign + decrypt  sign + decrypt   mTLS + custody signing
                 |             ^          |            |
                 +---- encrypted package --> opaque forwarding
```

The diagram is conceptual: actual CA topology and key usages must be approved. A compromised Parent Outer can withhold or reorder traffic, but must not decrypt the protected payload or forge an original Inner signature or destination Inner E-ACK.

## 8A.2 Cryptographic vocabulary and key inventory

| Item | Purpose | Private material location | Typical public distribution |
|---|---|---|---|
| Offline root CA key | Signs subordinate CAs | Offline security authority | Pinned root trust anchor |
| Inner issuing CA key | Issues Inner certificates | Protected issuing authority | CA chain |
| Outer issuing CA key | Issues Outer transport/identity certificates | Protected issuing authority | CA chain |
| Inner signing key | Signs original package / destination E-ACK | Respective Inner Site | Signed trust directory |
| Inner decryption key | Unwraps package CEK | Destination Inner only | Signed trust directory |
| Outer TLS key | Authenticates HTTPS peer | Respective Outer Site | TLS certificate chain |
| Gateway custody-signing key | Authenticates H-ACK/control messages | Respective custody-taking site | Signed trust directory |
| CEK | Encrypts one package payload | Volatile package-builder and authorized destination memory | Wrapped, never plaintext |
| Trust-directory signing key | Signs site/policy/revocation bundle | Enterprise security authority | Pinned metadata verification key |

A **certificate** binds a public key to an identity through an issuer's signature; it does not contain the private key. A **CSR** is a request for a certificate, not proof that a site is authorized. A **trust anchor** is installed independently through an approved bootstrap channel. A **CRL** conveys revoked certificate serial numbers; OCSP-style online checking cannot be assumed inside isolated Inner networks.

### Identity and naming rules

Use globally unique, stable site IDs such as `COMPANY_A.INNER`, `COMPANY_A.OUTER`, `PARENT.OUTER`. Bind site ID to a SAN value defined by enterprise policy, e.g. a `uniformResourceIdentifier` SAN using an enterprise-controlled scheme. Avoid relying only on the certificate Common Name. A verifier must compare the authenticated certificate identity to the **signed manifest source**, the expected role, and policy permissions. The certificate must be authorized for its purpose (keyUsage, extendedKeyUsage or enterprise certificate policy OID as appropriate); the presence of a valid CA signature is not enough.

## 8A.3 Certificate profiles and lifecycle

Recommended profiles are **separate** for:
- CA certificates: `basicConstraints=critical,CA:TRUE`; keyCertSign and cRLSign as needed; explicit path length; carefully protected private key.
- Package-signing leaf: `CA:FALSE`, `digitalSignature`, enterprise package-signing policy/EKU where supported.
- Decryption leaf: `CA:FALSE`, key agreement or key encipherment usage appropriate to the *selected* key-encapsulation algorithm.
- Outer mTLS leaf: `CA:FALSE`, `digitalSignature`, TLS serverAuth and/or clientAuth as the endpoint requires.
- H-ACK/control signer: dedicated signing purpose and explicit authorized site identity.

**Do not blindly apply a single profile to every key.** The selected encryption suite determines required key type and usage. If ECDSA P-256 is chosen for signing, the signing certificate must contain a compatible EC public key. RSA-OAEP-SHA256 key wrapping requires an RSA recipient encryption key, not an ECDSA-only key.

Lifecycle states:
`REQUESTED → APPROVED → ISSUED → DISTRIBUTED → ACTIVE → RENEWING → RETIRED`, with exceptional transitions to `REVOKED`, `COMPROMISED`, `EXPIRED`. A certificate can be cryptographically valid but not yet authorized for DX use. Track certificate fingerprint, serial, issuer, subject/SAN, algorithm, key purpose, site ID, validity interval, activation status, and trust-directory version.

For renewal, overlap old and new *public* certificates in the signed directory, activate the new signing key on a coordinated date, and retain an old decryption private key **only for an approved window** to decrypt legitimate in-flight packages. A revoked signing key must never be used to sign new packages. Compromise may require immediate suspension rather than an ordinary overlap.

## 8A.4 Trust-chain and authorization verification

A complete verifier MUST perform, at minimum:

1. Parse the certificate and constrain certificate size, algorithms, and extensions.
2. Build a chain to an independently installed approved root or intermediate trust anchor.
3. Verify each chain signature and CA constraints.
4. Check certificate validity and permitted signature/key algorithms.
5. Check leaf key usage, purpose and identity SAN.
6. Check revocation against the currently accepted enterprise revocation data.
7. Check trust-directory version and freshness policy.
8. Check the certificate fingerprint/key ID is authorized for the claimed site and role.
9. Verify the package signature over the **precisely defined signed bytes**.
10. Check source→destination→event-category authorization and policy version.
11. Enforce replay and state-transition protections before dispatch.

Never interpret `openssl_x509_parse()` success as complete chain validation. Never infer authorization from a trusted CA alone. Never allow a caller-supplied certificate to replace the pinned trust anchor.

### Example validation decision record

```json
{
  "validation_id": "VAL-20261014-0001",
  "package_id": "PKG-0001",
  "source_site": "COMPANY_A.INNER",
  "signer_key_id": "KEY-A-SIGN-2026-02",
  "trust_directory_version": 125,
  "signature_verified": true,
  "chain_verified": true,
  "identity_verified": true,
  "revocation_checked": true,
  "route_authorized": true,
  "event_authorized": true,
  "decision": "ACCEPT"
}
```

This is an **audit record after verification**, not input trusted from the sender.

## 8A.5 Encryption: hybrid envelope and authenticated binding

A large business payload is not encrypted directly with RSA. The builder generates a fresh random **32-byte CEK**, encrypts the payload using **AES-256-GCM**, then encapsulates/wraps the CEK using the destination's authorized public encryption key.

For the baseline AEAD profile, use a **12-byte nonce** with AES-GCM, a **16-byte authentication tag**, and a unique nonce for every encryption under the same CEK. A fresh CEK per package substantially simplifies nonce management. If attachments are encrypted separately under the same CEK, use a rigorously specified nonce allocation scheme or, preferably, independent derived subkeys/nonces with domain separation. Do not casually reuse the payload nonce for attachments.

```text
Business JSON/attachments
         |
    validate + serialize
         |
     random CEK (32 B) ------ recipient public-key wrap ------ wrapped CEK
         |
  AES-256-GCM + nonce + AAD
         |
    ciphertext + tag
         |
  immutable manifest hashes + cryptographic metadata
         |
  canonical signed bytes
         |
    origin signature
```

**AAD must be defined byte-for-byte.** One example contract is the UTF-8 bytes of a versioned canonical structure containing `protocol`, `package_id`, `source_site`, `destination_site`, `object_id`, `object_kind`, and `encryption_suite`. Both encryption and decryption must produce the *same bytes*. AAD must not be recomputed from unauthenticated mutable routing fields. Explicitly specify Unicode handling, numeric encoding, nulls, ordering, and base64 representation.

A tag mismatch means **integrity failure**; never release partial plaintext to the business handler. A successful GCM tag proves integrity relative to the CEK, but sender authentication still requires the original digital signature and authorization.

### Illustrative PHP 7.4 AES-GCM operation

```php
<?php
function dxEncryptAesGcm($plaintext, $aad)
{
    $cek = random_bytes(32);
    $nonce = random_bytes(12);
    $tag = '';

    $ciphertext = openssl_encrypt(
        $plaintext,
        'aes-256-gcm',
        $cek,
        OPENSSL_RAW_DATA,
        $nonce,
        $tag,
        $aad,
        16
    );
    if ($ciphertext === false || strlen($tag) !== 16) {
        throw new RuntimeException('Encryption failed');
    }

    // CEK is returned ONLY to a protected internal wrapping stage.
    // Never serialize the raw CEK into the package or write it to logs.
    return array(
        'ciphertext' => $ciphertext,
        'nonce' => $nonce,
        'tag' => $tag,
        'cek_for_immediate_wrapping' => $cek
    );
}
```

```php
<?php
function dxDecryptAesGcm($ciphertext, $cek, $nonce, $tag, $aad)
{
    if (strlen($cek) !== 32 || strlen($nonce) !== 12 || strlen($tag) !== 16) {
        throw new RuntimeException('Invalid cryptographic parameters');
    }
    $plaintext = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        $cek,
        OPENSSL_RAW_DATA,
        $nonce,
        $tag,
        $aad
    );
    if ($plaintext === false) {
        throw new RuntimeException('Authentication/decryption failed');
    }
    return $plaintext;
}
```

These functions illustrate the AEAD primitive, **not the full DX package format**. Key wrapping, metadata canonicalization, signatures, authorization, and secure key lifetime remain necessary. PHP strings cannot guarantee prompt zeroization of every in-memory copy; avoid long-lived key retention and use protected providers where required.

## 8A.6 Key wrapping: algorithm selection and PHP 7.4 limitation

**Choose one exact, versioned suite before production.** An RSA option is `RSA-OAEP` with SHA-256 for both OAEP digest and MGF1, with a precisely specified empty or fixed label and explicit RSA key-size policy. An EC-based option requires a specified KEM/EC-DH construction, KDF, key confirmation/AEAD wrapping, and test vectors. Do not interchange them merely because both use “public-key encryption.”

**Critical PHP 7.4 warning:** `openssl_public_encrypt($cek, $wrapped, $publicKey, OPENSSL_PKCS1_OAEP_PADDING)` does not expose an OAEP digest parameter and should not be described as implementing OAEP-SHA256. The default is not the agreed SHA-256 profile. Use an audited provider, compatible extension, or another approved implementation that explicitly configures OAEP SHA-256 and MGF1 SHA-256. The same limitation applies to corresponding unwrap APIs. Validate interoperability against published and locally generated test vectors.

The wrapped key must be bound to the recipient's encryption certificate/key ID. Never “try every private key and accept whatever decrypts” without also checking the signed destination and authorized key identity.

## 8A.7 Digital signatures and canonical bytes

ECDSA P-256 with SHA-256 signs an exact byte string, not an abstract JSON object. The protocol must define whether it signs:
- A canonicalized manifest;
- A versioned binary framing of the manifest and encrypted object hashes; or
- A canonicalized protected header plus payload digests.

Choose exactly one format and document it. Ordinary `json_encode()` output is **not** automatically RFC 8785 JCS canonical JSON. If JCS is selected, use a tested implementation and constrain inputs (especially numeric values, duplicate keys, Unicode, and object ordering). Alternatively define a length-prefixed binary signing envelope.

Suggested domain separation:
`"DXPP-PACKAGE-SIGNATURE-v1\0" || uint32_be(length(manifest_bytes)) || manifest_bytes`.

For E-ACK:
`"DXPP-EACK-SIGNATURE-v1\0" || uint32_be(length(ack_bytes)) || ack_bytes`.

Different message types must not share ambiguous signing contexts. Define ECDSA signature encoding (DER versus fixed-width `r||s`) and verify it strictly. The signature must cover immutable origin identity, final destination, package ID, event binding or protected digest, cryptographic algorithm IDs, wrapped-key metadata, ciphertext hashes, and protocol version.

### Illustrative PHP signature primitive

```php
<?php
function dxSignBytes($signedBytes, $privateKeyPem)
{
    $key = openssl_pkey_get_private($privateKeyPem);
    if ($key === false) {
        throw new RuntimeException('Signing key unavailable');
    }
    $signature = '';
    $ok = openssl_sign($signedBytes, $signature, $key, OPENSSL_ALGO_SHA256);
    if (!$ok) {
        throw new RuntimeException('Signing failed');
    }
    // OpenSSL ECDSA signatures are typically ASN.1 DER encoded.
    // Validate key type/curve and define signature encoding in the protocol.
    return $signature;
}
function dxVerifyBytes($signedBytes, $signature, $publicKeyPem)
{
    $key = openssl_pkey_get_public($publicKeyPem);
    if ($key === false) {
        throw new RuntimeException('Verification key unavailable');
    }
    $result = openssl_verify(
        $signedBytes,
        $signature,
        $key,
        OPENSSL_ALGO_SHA256
    );
    if ($result === -1) {
        throw new RuntimeException('Signature verification error');
    }
    return $result === 1;
}
```

The calling layer MUST first or additionally establish that the public key belongs to an authorized site and approved signing certificate. A successful `openssl_verify` with an attacker-supplied public key proves nothing about enterprise identity.

## 8A.8 Illustrative OpenSSL certificate laboratory (NOT production CA procedure)

The following commands are suitable only for a segregated **development lab**. Production CA creation needs offline ceremony, role separation, HSM consideration, protected backups, approval records, serial/CRL management, and a reviewed CA implementation.

```bash
# Lab-only: generate a P-256 key and a CSR.
umask 077
openssl ecparam -name prime256v1 -genkey -noout -out company_a_sign.key
openssl req -new -sha256 \
  -key company_a_sign.key \
  -subj "/O=DX Test/OU=Inner/CN=COMPANY_A.INNER" \
  -out company_a_sign.csr

# Inspect the CSR; it is NOT an issued/authorized certificate.
openssl req -in company_a_sign.csr -noout -text

# Inspect a previously issued certificate and its extensions.
openssl x509 -in company_a_sign.crt -noout -text
openssl x509 -in company_a_sign.crt -noout -fingerprint -sha256
```

**Do not use a self-signed site certificate as the production enterprise trust model.** Certificate issuance must include an approved SAN, keyUsage, policy identifiers, unique serial, validity interval, issuer signature, and documented approval. Never put actual production keys into source control or portable documentation.

## 8A.9 Signed trust-directory bundle

An offline enterprise trust-directory update is a signed, versioned **authorization snapshot**. It should include:
- `directory_version` (monotonic integer);
- `schema_version`, issuer, creation and expiration;
- Intended enterprise/environment and optional site scope;
- Site IDs, roles, allowed identities, active key IDs, certificate fingerprints;
- Certificate chains or immutable certificate references with hashes;
- Revocation information and effective times;
- Authorized event categories and routes or references to signed policies;
- Supersession and key-rotation status;
- Signature algorithm/key ID and signature over canonical bytes.

Example **illustrative JSON**, not a final signing format:

```json
{
  "schema_version": 1,
  "directory_version": 125,
  "environment": "production",
  "issuer": "ENTERPRISE_SECURITY_AUTHORITY",
  "created_at": "2026-10-14T00:00:00Z",
  "expires_at": "2026-11-14T00:00:00Z",
  "sites": [
    {
      "site_id": "COMPANY_A.INNER",
      "role": "INNER",
      "signing_key_id": "KEY-A-SIGN-2026-02",
      "encryption_key_id": "KEY-A-ENC-2026-01",
      "signing_cert_sha256": "EXAMPLE_FINGERPRINT_NOT_A_REAL_HASH"
    }
  ],
  "revoked_certificate_serials": [],
  "policy_version": 38
}
```

The actual signed bundle needs the complete referenced material or cryptographically verified retrieval mechanism. A directory version must never be accepted based only on an unverified header. A compromised hub may delay or suppress updates; local expiry/freshness policy must account for that.

### Trust update acceptance algorithm

```text
RECEIVE BUNDLE
  -> enforce file/JSON limits
  -> identify pinned metadata-verification trust anchor
  -> verify exact signed bytes and issuer authorization
  -> verify enterprise/environment/site scope
  -> reject unsupported algorithms and schema versions
  -> compare version with highest previously accepted
  -> reject rollback and unexpected same-version hash conflict
  -> validate certificate and policy relationships
  -> validate freshness and revocation policy
  -> atomically persist bundle + accepted version + audit record
  -> activate new snapshot only after durable commit
```

Persist both `highest_accepted_version` and `accepted_bundle_sha256`. Equal version with identical bytes is an idempotent replay; equal version with different bytes is a security incident. To resist full database rollback, periodically anchor accepted versions and audit checkpoints outside the ordinary application database.

## 8A.10 Offline freshness and revocation

Inner Sites cannot assume live Internet access or direct online CA checks. Distribute signed CRLs or equivalent approved revocation evidence with trust updates. Define:
- Maximum permitted age of revocation information;
- Per-event risk classification;
- Fail-closed behavior for high-risk routes;
- Grace windows, if any, approved by security authority;
- Procedure for recovering from extended network isolation;
- Handling of unknown revocation state;
- Emergency site suspension.

A package's `created_at` is sender-controlled and does **not** prove when a signature occurred. Retrospective acceptance of a signature after key compromise requires a separately defined trusted-time/evidence policy. In the absence of trustworthy signing-time evidence, quarantine ambiguous historical packages for review.

## 8A.11 Full package creation sequence

1. Commit business mutation and outbox row in one MariaDB transaction.
2. Claim outbox item with lease/fencing token.
3. Validate event schema, source authorization and destination permission.
4. Resolve the **currently authorized** destination encryption certificate from the accepted directory.
5. Generate stable package ID and immutable event binding.
6. Serialize payload using the approved canonical/encoding rules.
7. Generate random CEK and per-object nonce/key schedule.
8. Construct exact AAD for each encrypted object.
9. Encrypt business payload and attachments with AEAD.
10. Wrap CEK for the intended destination with the approved suite.
11. Compute hashes of encrypted objects; construct manifest with algorithm and key IDs.
12. Produce exact canonical signed bytes and sign using source Inner signing key.
13. Write bounded package to a staging file outside the web root.
14. Flush/close; verify archive structure, hashes and signature against the completed artifact.
15. Atomically rename on the same filesystem into `ready/`.
16. Persist package state and durable audit evidence.
17. Publish only the verified immutable artifact.

A crash between filesystem and database commits is recovered through durable state reconciliation; never assume both commit atomically.

## 8A.12 Full final-destination validation and processing sequence

1. Safely claim incoming file; apply resource limits before decompression.
2. Validate strict ZIP allowlist, paths, duplicates, sizes, compression and manifest schema.
3. Verify signed origin manifest, certificate chain, identity, revocation, trust freshness and authorization.
4. Verify immutable ciphertext hashes and final destination binding.
5. Apply package ID + hash dedup; same ID/different hash → quarantine.
6. Persist accepted package custody and the appropriate receipt.
7. Resolve authorized destination decryption key by signed key ID and certificate.
8. Unwrap CEK with the exact approved suite; never log it.
9. Reconstruct exact AAD; authenticate/decrypt all required objects.
10. Validate decrypted event schema and business authorization.
11. Check `(source_site,event_id)` dedup and immutable event digest binding.
12. Apply business mutation, record processed event and enqueue E-ACK in **one database transaction**.
13. Sign and transport E-ACK asynchronously via durable ACK outbox.
14. Retain or purge artifacts according to approved retention and incident policies.

**Failure semantics:** Signature failure, GCM tag mismatch, key-ID mismatch, destination mismatch, or package-hash conflict are security failures. Missing approved decryption certificate/key is a controlled waiting or incident state, not a reason to accept plaintext or skip checks. Missing E-ACK means **unknown remote outcome**, not confirmed failure.

## 8A.13 Hop ACK and End-to-End ACK authentication

**H-ACK** is created only after durable next-hop custody. It authenticates the custody-taking site, package ID/hash, receiving hop, custody timestamp/sequence, and result. Its signer must be authorized for that hop. An HTTP 200 response alone is not sufficient proof of durable custody.

**E-ACK** is signed by the final destination Inner Site **after business commit**. It binds package ID/hash, event ID, original source, final destination, outcome, ACK ID and protocol version. The source validates the final Inner signer and original package identity; Parent Outer and subsidiary Outer Sites must not fabricate success E-ACKs. Do not generate an ACK-of-ACK loop.

Replay checks must cover ACK ID and binding, and reject conflicting outcomes. Time-only replay windows are insufficient when offline transport can delay packages for days.

## 8A.14 Key storage and operational separation

Recommended permissions and boundaries:
- Inner package-signing private key readable only by the dedicated signing service identity or protected provider.
- Inner decryption private key available only to the destination decryption service.
- Outer mTLS key available only to authorized Outer transport service.
- CA and trust-directory signing private keys never installed on Parent Outer or ordinary business application servers.
- Web UI accounts cannot read raw private keys or trigger arbitrary signing.
- Backup copies of private keys are encrypted, access-controlled, inventoried, and restoration-tested.
- Sensitive signing operations are logged by key ID and operation ID, not key material.
- Key generation, approval, installation, rotation and destruction require documented separation of duties.

Example directory concept:

```text
/etc/s3-dataexchange/
  trust/
    pinned-root.pem
    accepted-directory.bundle
    accepted-directory.sig
  public/
    site-chain.pem
  private/                # restricted to privileged service accounts
    signing-key-reference.conf
    decryption-key-reference.conf
/var/lib/s3-dataexchange/
  send/ready/
  receive/incoming/
  quarantine/
  audit-checkpoints/
```

Prefer protected provider key references rather than PEM private keys where possible. Do not place private keys or package storage beneath the public document root.

## 8A.15 Rotation procedures

**Routine signing-key rotation**
1. Generate replacement key in approved location.
2. Verify CSR identity and approve issuance.
3. Issue new signing certificate with correct SAN/usage.
4. Publish signed directory containing both old and new public keys with activation windows.
5. Verify each participating site accepted the required directory version.
6. Activate new signing key for new packages.
7. Continue verifying historical signatures under approved historical policy.
8. Retire old signing key, revoke if necessary, and archive evidence.

**Routine encryption-key rotation**
1. Publish new destination encryption public key.
2. Confirm senders received the update.
3. Switch new package wrapping to the new key ID.
4. Retain old private key only for approved in-flight packages.
5. Track remaining package dependencies on the old key.
6. Destroy/retire old key only after authorized retention window and verification.

**Compromised key**
- Suspend affected key/site privileges; preserve forensic evidence.
- Revoke and distribute signed updates.
- Quarantine uncertain messages; investigate packages and E-ACKs.
- Replace credentials via independently authenticated procedures.
- Reprocess or reissue only under documented business approval; never silently rewrite immutable signed packages.
- Reconcile site trust versions before resuming sensitive exchange.

## 8A.16 Example MariaDB metadata tables

These tables are **supplementary reference definitions**; reconcile with the handbook's existing schema before creating migrations.

```sql
CREATE TABLE security_site_keys (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    site_id VARCHAR(100) NOT NULL,
    key_id VARCHAR(100) NOT NULL,
    purpose ENUM('PACKAGE_SIGN','PACKAGE_DECRYPT','MTLS','CUSTODY_SIGN') NOT NULL,
    cert_sha256 CHAR(64) NOT NULL,
    issuer_id VARCHAR(120) NOT NULL,
    serial_hex VARCHAR(100) NOT NULL,
    not_before DATETIME NOT NULL,
    not_after DATETIME NOT NULL,
    status ENUM('PENDING','ACTIVE','RETIRED','REVOKED') NOT NULL,
    directory_version BIGINT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL,
    UNIQUE KEY uk_security_key_id (key_id),
    KEY idx_site_purpose_status (site_id,purpose,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE security_trust_acceptance (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    site_id VARCHAR(100) NOT NULL,
    directory_version BIGINT UNSIGNED NOT NULL,
    bundle_sha256 CHAR(64) NOT NULL,
    issuer_key_id VARCHAR(100) NOT NULL,
    accepted_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    UNIQUE KEY uk_site_version (site_id,directory_version),
    KEY idx_site_accepted (site_id,accepted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE security_validation_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    package_id VARCHAR(100) NOT NULL,
    source_site VARCHAR(100) NULL,
    signer_key_id VARCHAR(100) NULL,
    directory_version BIGINT UNSIGNED NULL,
    decision VARCHAR(32) NOT NULL,
    error_code VARCHAR(80) NULL,
    verified_at DATETIME NOT NULL,
    KEY idx_package (package_id),
    KEY idx_verified (verified_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

Use UTC consistently and make acceptance/activation a serialized transaction. A trust-acceptance history table does not by itself prevent rollback; keep an authoritative highest-version record with concurrency controls and independent checkpointing.

## 8A.17 Test matrix and negative tests

| ID | Test | Expected result |
|---|---|---|
| PKI-01 | Valid chain, matching SAN, correct purpose | Accept when authorized |
| PKI-02 | Valid chain, wrong site SAN | Reject |
| PKI-03 | Valid chain, wrong EKU/purpose | Reject |
| PKI-04 | Untrusted CA or substituted root | Reject |
| PKI-05 | Expired or not-yet-valid leaf | Reject/hold under explicit historical policy |
| PKI-06 | Revoked signing certificate | Reject/hold under policy |
| PKI-07 | Stale revocation information | Fail closed for protected routes |
| PKI-08 | Older signed directory version | Reject rollback |
| PKI-09 | Same directory version, different hash | Security incident |
| PKI-10 | Unknown recipient encryption key | Wait/quarantine, never plaintext |
| CRY-01 | Correct CEK, nonce, AAD and tag | Decrypt successfully |
| CRY-02 | Modified ciphertext | Authentication failure |
| CRY-03 | Modified tag | Authentication failure |
| CRY-04 | Modified AAD destination | Authentication failure |
| CRY-05 | Incorrect unwrap private key | Reject |
| CRY-06 | OAEP digest mismatch | Reject; never downgrade |
| SIG-01 | Exact canonical signed bytes | Verify |
| SIG-02 | Reordered noncanonical JSON | Verify only if canonicalization contract produces same bytes |
| SIG-03 | Altered immutable manifest field | Reject |
| SIG-04 | Attacker public key supplied in package | Reject identity/chain |
| ACK-01 | Forged Parent Outer E-ACK | Reject |
| ACK-02 | Replayed identical E-ACK | Idempotent |
| ACK-03 | Same ACK ID, conflicting outcome | Quarantine/incident |
| OPS-01 | Crash during trust update | Previous or new complete snapshot, never partial |
| OPS-02 | Rotation with in-flight old-key package | Decrypt only during authorized overlap |
| OPS-03 | Compromised key revocation during offline delay | Apply documented hold/review policy |

Tests must include **cross-platform vectors**: PHP↔OpenSSL/provider, Windows↔CentOS, non-ASCII payloads, empty strings, long attachments, malformed DER, malformed JSON, duplicate JSON keys, and noncanonical numeric representations. Test certificate fixtures must be unmistakably labeled and never trusted in production.

## 8A.18 Incident response playbooks

### Invalid origin signature
1. Quarantine package and record immutable hash.
2. Record verified source identity claim, signer key ID and reason code.
3. Do not decrypt or dispatch.
4. Alert local security operations.
5. Correlate with other occurrences and preserve evidence.
6. Resume only after verified remediation, never by disabling checks.

### Certificate expired or trust directory stale
1. Place affected packages in `WAITING_TRUST` or `QUARANTINED` per policy.
2. Report locally; central reporting may be delayed.
3. Obtain a signed trust update through approved distribution.
4. Verify issuer, signature, version and freshness.
5. Revalidate queued packages under the approved historical policy.
6. Audit every manual intervention.

### Suspected Inner private-key compromise
1. Isolate affected signing/decryption service and preserve evidence.
2. Suspend affected key identity and authorized routes.
3. Revoke credentials and issue signed trust update.
4. Assess packages and ACKs created during the suspected compromise interval.
5. Replace keys and distribute new certificates.
6. Reconcile unresolved business events without duplicate side effects.
7. Obtain security approval before resuming.

## 8A.19 Production release gates

**Do not mark DXPP production-ready until all are complete:**

- [ ] One approved algorithm suite and algorithm registry.
- [ ] Exact key-wrap mechanism, OAEP/MGF1 digest or EC-KEM parameters.
- [ ] Exact AEAD nonce/key derivation, AAD and tag encoding.
- [ ] Exact canonical manifest/ACK serialization and signature input.
- [ ] Signature representation and strict parser rules.
- [ ] Site SAN, CA, leaf purpose and certificate-policy profiles.
- [ ] Independently authenticated root/trust bootstrap.
- [ ] Signed trust-directory schema, version/freshness and rollback rules.
- [ ] Offline revocation and historical-signature acceptance policy.
- [ ] Key rotation, in-flight decryption and compromise procedures.
- [ ] Hardware/protected key-storage decision and service-account permissions.
- [ ] Cross-platform cryptographic interoperability test vectors.
- [ ] Automated positive, negative, replay, fault-injection and recovery tests.
- [ ] Independent security review and penetration assessment.

**References for offline engineering library:** RFC 5280 (X.509 path validation); RFC 8017 (RSAES-OAEP); RFC 8785 (JSON Canonicalization Scheme); NIST SP 800-38D (GCM); NIST FIPS 186-5 (digital signatures); NIST SP 800-57 (key management). Store approved local copies in the organization's offline documentation repository and verify versions during implementation.

---

# 9. Transactional Outbox, Inbox and Database Design

## 9.1 Logical data model

| Table | Responsibility |
|---|---|
| `exchange_outbox` | Transactionally committed pending publications per destination |
| `exchange_packages` | Immutable package identity, hash, location and lifecycle |
| `exchange_transfers` | One hop's custody/transport attempts |
| `exchange_received` | Durable inbound package receipt and deduplication |
| `exchange_processed_events` | Successfully processed business-event identities |
| `exchange_pending_events` | Dependency/version waiting queue |
| `exchange_entity_versions` | Per-entity version/owner state |
| `exchange_sites` | Site identity and role metadata |
| `exchange_routes` | Approved next-hop route policy |
| `exchange_route_permissions` | Source/destination/event-category authorization |
| `exchange_audit_log` | Administrative and security event evidence |
| `security_site_certificates` | Certificate metadata and status |
| `security_directory_versions` | Accepted signed trust-directory versions |
| `security_site_directory_status` | Reported trust version/freshness per site |
| `exchange_worker_status` | Worker heartbeats, leases and progress |
| `exchange_alerts` | Operational/security alerts and lifecycle |

**The following SQL is illustrative core schema, not a substitute for the complete migration-reviewed schema.** Use InnoDB, UTC timestamps, consistent character sets, foreign keys where practical and audited retention policies.

## 9.2 Outbox example

```sql
CREATE TABLE exchange_outbox (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_id VARCHAR(100) NOT NULL,
    event_type VARCHAR(150) NOT NULL,
    event_version INT UNSIGNED NOT NULL,
    source_site VARCHAR(100) NOT NULL,
    destination_site VARCHAR(100) NOT NULL,
    payload_json LONGTEXT NOT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    next_attempt_at DATETIME NULL,
    claimed_by VARCHAR(100) NULL,
    lease_token VARCHAR(100) NULL,
    lease_expires_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_source_event_destination
        (source_site, event_id, destination_site),
    KEY idx_queue (status, next_attempt_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

If payloads contain secrets, restrict DB access and consider protected at-rest storage. An outbox stores plaintext business data locally before package encryption; its threat model must acknowledge this.

## 9.3 Package and transfer identity

```sql
CREATE TABLE exchange_packages (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    package_id VARCHAR(100) NOT NULL,
    event_id VARCHAR(100) NOT NULL,
    source_site VARCHAR(100) NOT NULL,
    destination_site VARCHAR(100) NOT NULL,
    package_hash CHAR(64) NOT NULL,
    direction VARCHAR(12) NOT NULL,
    status VARCHAR(40) NOT NULL,
    storage_path VARCHAR(1024) NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_package_id (package_id),
    KEY idx_destination_status (destination_site, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE exchange_transfers (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    transfer_id VARCHAR(100) NOT NULL,
    package_id VARCHAR(100) NOT NULL,
    from_site VARCHAR(100) NOT NULL,
    to_site VARCHAR(100) NOT NULL,
    transport_type VARCHAR(20) NOT NULL,
    status VARCHAR(40) NOT NULL,
    attempts INT UNSIGNED NOT NULL DEFAULT 0,
    last_attempt_at DATETIME NULL,
    acknowledged_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_transfer_id (transfer_id),
    KEY idx_package (package_id),
    KEY idx_transfer_queue (status, last_attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## 9.4 Transactional invariants

**Origin transaction:** business update + outbox insert must use **same MariaDB adapter and transaction**, with business service owning commit/rollback.

**Destination transaction:** business changes + processed-event dedup record + E-ACK outbox insert must commit atomically. Duplicate-event conflicts must be handled without executing the handler twice.

**Filesystem vs database:** There is no atomic transaction across MariaDB and filesystem rename. Persist immutable artifact identity, use same-filesystem atomic rename and implement reconciliation after crashes.

# 10. PHP/ZF1 Component Architecture and Developer API

## 10.1 Project layout

```text
project/
  application/
    Bootstrap.php
    configs/{application.ini,dataexchange.ini}
    modules/{email,crm,product,blog,notification}/
  library/S3/DataExchange/
    Api.php  Publisher.php  Receiver.php  Router.php
    Contract/{PublisherInterface,TransportInterface,CryptoInterface}.php
    Package/{Builder,Parser,Validator,Manifest,Storage}.php
    Security/{Encryption,Signature,Certificate,TrustStore,Authorization}.php
    Event/{Registry,Dispatcher,HandlerInterface}.php
    Queue/{Outbox,Inbox,Retry}.php
    Transport/{Directory,Https}.php
    Ack/{HopAck,EndToEndAck,Manager}.php
    Sync/{Version,Dependency,Conflict}.php
    Worker/{BuildWorker,ReceiveWorker,RetryWorker,RecoveryWorker}.php
    Exception/{PackageException,SecurityException,ProcessingException}.php
  scripts/dataexchange/{build,receive,retry,recover}.php
  tests/DataExchange/{Unit,Integration,Security,Recovery}/
```

ZF1 naming example: `S3_DataExchange_Package_Builder` → `library/S3/DataExchange/Package/Builder.php`.

## 10.2 Public facade

```php
interface S3_DataExchange_ApiInterface
{
    public function publish($eventType, $destinationSite,
        array $payload, array $options = array());
    public function publishMany($eventType, array $destinationSites,
        array $payload, array $options = array());
    public function publishBatch($eventType, array $deliveries,
        array $options = array());
    public function registerEventType($eventType, array $definition);
    public function registerHandler($eventType,
        S3_DataExchange_Event_HandlerInterface $handler);
    public function getEventStatus($eventId);
    public function getDeliveryResults($eventId);
}
```

`publish()` writes to the outbox and returns `PENDING` (provisional until enclosing transaction commits). It does **not** synchronously encrypt, route or deliver.

## 10.3 Example: CRM business transaction

```php
$db = Zend_Db_Table::getDefaultAdapter();
$dx = new S3_DataExchange_Api($db);

$db->beginTransaction();
try {
    $db->update('crm_customers',
        array('name' => 'ABC Corporation', 'version' => 3),
        $db->quoteInto('customer_id = ?', 'CUST-10001'));

    $dx->publish('crm.customer.updated', 'COMPANY_B.INNER',
        array('customer_id' => 'CUST-10001',
              'name' => 'ABC Corporation', 'version' => 3),
        array('event_id' => 'EVT-50001', 'event_version' => 1,
              'entity_type' => 'crm.customer',
              'entity_id' => 'CUST-10001', 'entity_version' => 3));

    $db->commit();
} catch (Throwable $e) {
    $db->rollBack();
    throw $e;
}
```

**Implementation rule:** `publish()` must not commit/rollback the caller's transaction. Duplicate publication attempts with same event/destination must be idempotent or return a clearly defined conflict.

## 10.4 Event handler registry

```php
interface S3_DataExchange_Event_HandlerInterface
{
    public function handle(array $event);
}

class Crm_DataExchange_CustomerHandler
    implements S3_DataExchange_Event_HandlerInterface
{
    public function handle(array $event)
    {
        // Validate business semantics and authoritative owner.
        // Apply changes using the framework-owned transaction.
        return array('status' => 'SUCCESS');
    }
}
```

Only trusted application code registers handlers. Incoming `event_type` is a lookup key in a trusted registry, **never** a PHP class name to instantiate dynamically.

## 10.5 Module integration contract

Each module should supply:

- Event definitions, schema versions and allowed destinations.
- Receiving handlers and optional trusted version transformers.
- Business idempotency/ownership rules.
- Destination-specific payload generation where privacy requires it.
- Optional durable status listeners for verified E-ACK results.
- PHPUnit tests independent of physical handoff.

Example module tree:

```text
application/modules/crm/dataexchange/
  Config.php
  EventRegistry.php
  handlers/CustomerUpdated.php
  listeners/DeliveryStatus.php
  schemas/customer-updated-v1.json
  tests/CustomerUpdatedTest.php
```

# 11. File Handoff and HTTPS Transport Adapters

## 11.1 Directory lifecycle

```text
/var/lib/s3-dataexchange/
  send/{building,ready,exported,failed}/
  receive/{incoming,processing,processed,rejected,failed}/
  quarantine/
  temporary/
  logs/
```

These paths are outside the public web root, with restrictive permissions. A file is written to a private staging name, flushed/closed, validated, then atomically renamed into a ready directory on the same filesystem. The handoff boundary is an external contract: **which files are ready, how they are claimed, and how receipts return**. Do not assume or specify dongle internals.

## 11.2 Transport interfaces

```php
interface S3_DataExchange_Contract_TransportInterface
{
    public function send($packagePath, array $transfer);
    public function receive(array $options = array());
}
```

- **Directory adapter:** publishes immutable files, claims received files safely, records custody, handles receipt packages and recovery.
- **HTTPS adapter:** uses mTLS, streaming upload/download, authenticated receipts, timeouts, retries and rate limits.

Both adapters use the **same immutable package** and separate authenticated per-hop transfer metadata. A normal HTTP response is not a custody acknowledgement without a verified H-ACK protocol message.

# 12. Background Workers, Retry and Recovery

## 12.1 Workers

| Worker | Responsibilities |
|---|---|
| `BuildWorker` | Claim outbox, resolve cert, build/verify/publish immutable package |
| `ReceiveWorker` | Claim inbound file, validate, store custody, route or dispatch |
| `RetryWorker` | Retry eligible transfer/build/business work with backoff |
| `RecoveryWorker` | Reconcile expired leases, DB/file mismatch, lost ACKs |

CLI examples:

```bash
php scripts/dataexchange/build.php
php scripts/dataexchange/receive.php
php scripts/dataexchange/retry.php
php scripts/dataexchange/recover.php
```

Use cron/systemd and MariaDB job leases; no Redis requirement. A lease expiry does not prove a worker stopped: use fencing tokens, conditional state updates and idempotent actions.

## 12.2 Retry policy

For retryable network errors, exponential backoff with jitter:

\[
D_n = \min(D_{max}, D_0 \cdot 2^n) + J_n
\]

- Retry: transient HTTPS failure, temporary DB/storage issue.
- Wait for external condition: certificate unavailable, dependency/version missing.
- Quarantine or require investigation: invalid signature, hash conflict, unauthorized route, revoked identity.
- A missing E-ACK triggers investigation/retry of approved delivery path, **not** a conclusion that the business operation failed.

## 12.3 Crash recovery cases

| Crash point | Required recovery |
|---|---|
| Outbox claimed, builder died | Expired lease, reclaim safely |
| Package file ready, DB still BUILDING | Verify existing artifact and reconcile DB |
| DB READY, file missing | Investigate; rebuild only under deterministic identity rules |
| Received package duplicated | Match ID/hash, avoid duplicate custody/business effects |
| Business committed, E-ACK transfer lost | Resume E-ACK from durable outbox |
| H-ACK lost | Retry receipt/transfer idempotently; retain sender copy |
| Worker stale after lease expiration | Reject stale writes using lease/fencing token |

**No ACK-of-ACK loops.** Retention/garbage collection occurs only after verified custody/completion and policy checks.

# 13. Security Threat Model and Hardening

## 13.1 STRIDE overview

| Threat | Controls |
|---|---|
| Spoofing | X.509 SAN identity binding, signature and mTLS validation |
| Tampering | AEAD, signed immutable metadata, package digest |
| Repudiation | Signed origin/E-ACK, protected audit evidence; limits acknowledged |
| Information disclosure | Destination-only decryption, minimal public routing metadata |
| Denial of service | Size/rate/CPU/disk limits, quotas, worker isolation |
| Elevation of privilege | RBAC, least-privilege DB/filesystem credentials, trusted handlers |

## 13.2 Key scenarios

**Compromised Parent Outer:** May read routing metadata, delay/drop/replay packages and falsify its own observations; cannot decrypt or forge endpoint signatures without keys. End-to-end encryption does not guarantee availability.

**Replay:** Duplicate package ID+same hash → idempotent; same ID+different hash → quarantine. Separate processed-event dedup suppresses repeated business effects.

**Forged E-ACK:** Verify destination Inner signer, original package ID/hash, event ID, result, expected route and permitted state transition.

**Archive attack:** Reject traversal, symlinks, bombs, duplicate paths, unsupported entries and unbounded extraction.

**Compromised business module:** Event/destination permissions enforced at a trusted boundary. If all modules run in one fully privileged PHP process, application checks cannot fully contain arbitrary code execution; stronger isolation needs process/credential boundaries.

**Trust rollback:** Signed directory must also pass monotonic version and freshness rules.

**Certificate compromise:** Revoke, distribute signed updates, quarantine affected packages and review historical acceptance.

**Audit tampering:** Hash-chain local records and periodically export independently signed checkpoints. A database-only chain can be rewritten by a fully privileged attacker.

## 13.3 Host/application controls

- Keep package directories outside document root; restrict ownership and modes.
- Never run package workers as root.
- Separate router, receiver, builder and monitoring privileges where feasible.
- Restrict MariaDB accounts by service and function.
- Use prepared SQL and strict JSON/schema validation; never `unserialize()` untrusted packages.
- Escape untrusted UI fields; enforce CSRF, session security, RBAC and audit on admin endpoints.
- Never log plaintext confidential payloads, private keys, CEKs or credentials.
- Apply signed offline patch/dependency processes and maintain an SBOM.
- Treat legacy PHP 7.4/ZF1 as an explicit production security risk requiring remediation.

# 14. Administration, Monitoring and Audit

## 14.1 Three levels of visibility

1. **Inner dashboard:** Actual local business processing, outbox, inbox, dependencies and E-ACKs.
2. **Outer dashboard:** Gateway custody, routes, transfers and H-ACKs; no plaintext business content.
3. **Parent Outer dashboard:** Enterprise routing and last authenticated reports; **not live Inner state**.

Statuses should distinguish `LOCAL_CONFIRMED`, `REMOTE_REPORTED` and `INFERRED`. Display both report generation and reception times; sequence numbers establish order, not timestamps alone.

## 14.2 Dashboard sections

```text
DX Administration
  Dashboard
  Packages (outbound/inbound/transit/details)
  Transfers and timeline
  H-ACK / E-ACK monitoring
  Business events and synchronization
  Routing and site permissions
  Certificates and trust-directory status
  Workers, retries and recovery
  Alerts, audit and configuration
```

Recommended KPIs: created/received/processed packages, H-ACK/E-ACK backlog, completion latency, per-route failure, worker queue depth, sync backlog, trust staleness and security rejects. Avoid claiming confirmed processing when only a hop has accepted custody.

## 14.3 Status reports

A signed `dx.status.report` control event contains `report_id`, `site_id`, `generated_at`, monotonic `sequence`, schema version and approved aggregate metrics. Parent Outer stores the latest **authenticated** snapshot. A stale report does not prove a site is down, and reachable Outer does not prove Inner is online.

## 14.4 REST API outline

```text
GET  /api/dataexchange/dashboard
GET  /api/dataexchange/packages
GET  /api/dataexchange/package
GET  /api/dataexchange/transfers
GET  /api/dataexchange/acks
GET  /api/dataexchange/events
GET  /api/dataexchange/sync
GET  /api/dataexchange/routes
GET  /api/dataexchange/certificates
GET  /api/dataexchange/workers
GET  /api/dataexchange/alerts
GET  /api/dataexchange/audit
POST /api/dataexchange/transfer/retry
POST /api/dataexchange/package/retry
POST /api/dataexchange/event/resume
POST /api/dataexchange/alert/acknowledge
```

Use DHTMLX 3.5 grids with server-side pagination/filtering and locally hosted assets. Validate sortable columns against allowlists. Optional ECharts must be tested against supported browsers.

## 14.5 Administrator roles

| Role | Typical permissions |
|---|---|
| DX Viewer | View permitted monitoring data |
| DX Operator | Request safe retry/resume operations |
| DX Administrator | Manage local DX settings and approved operations |
| DX Security Administrator | Manage security workflows and trust updates |
| DX Auditor | Read audit evidence |
| Enterprise DX Administrator | Approved enterprise routing governance |

Never permit direct DB status edits to turn a failed package into a successful package. Critical route/trust changes require approval and audit.

## 14.6 Alerts and runbooks

Alert examples: `PACKAGE_STUCK`, `HOP_ACK_TIMEOUT`, `END_TO_END_ACK_TIMEOUT`, `WORKER_UNRESPONSIVE`, `CERTIFICATE_EXPIRING`, `TRUST_DIRECTORY_STALE`, `HASH_CONFLICT`, `INVALID_SIGNATURE`, `DISK_SPACE_LOW`, `SYNCHRONIZATION_BACKLOG`.

Runbooks must document symptoms, evidence, safe actions, approval gates, escalation and post-recovery verification. Timeout thresholds vary by route and expected handoff frequency.

# 15. Testing, Deployment and Phased Roadmap

## 15.1 Testing layers

**Unit:** Registry, schema, routing, retry calculations, version comparisons.  
**Integration:** Outbox transaction, builder, validator, inbox, handler and E-ACK round trip.  
**Security:** Modified ciphertext, wrong destination, forged signature/ACK, revoked cert, archive traversal/bomb, trust rollback, replay/hash conflict.  
**Recovery:** Crashes before/after file rename, after business commit, stale leases, lost H-ACK/E-ACK.  
**Interoperability:** Exact protocol test vectors across independent implementations and cryptographic providers.  
**Operations:** Disk full, DB unavailable, route disabled, trust stale, worker stopped, site offline.

Test keys and certificates must be dedicated to nonproduction environments.

## 15.2 Development milestones

| Phase | Deliverable | Exit condition |
|---|---|---|
| 0 | Freeze wire protocol, trust/crypto suite, schemas | Reviewed spec and test vectors |
| 1 | Direct A.INNER → B.INNER simulated file transfer | Email event encrypted, signed, processed once; signed E-ACK returned |
| 2 | A.OUTER/B.OUTER gateways | Directory custody + HTTPS/mTLS + H-ACK |
| 3 | PARENT.OUTER multi-hop routing | Cross-company route, immutable package, reverse E-ACK |
| 4 | Multi-destination publication | Independent B/C payloads and results, Bcc privacy |
| 5 | CRM/Product synchronization | Version, dependency and snapshot recovery tests |
| 6 | Administration UI | Monitoring, retry, audit, worker health |
| 7 | Trust lifecycle and enterprise rollout | Rotation, revocation, signed directory, operational readiness |

Security validation and idempotency must be present from Phase 1, not deferred until Phase 7.

## 15.3 Version 1 prototype

Simulate two isolated PHP/MariaDB instances on a test computer, with a **manual test file copy** only for development. Production always uses the approved external transfer subsystem.

```text
COMPANY_A.INNER (publish → outbox → build/sign/encrypt)
    → test file copy →
COMPANY_B.INNER (verify → decrypt → Email handler → commit)
    → signed E-ACK test file copy →
COMPANY_A.INNER (verify E-ACK → update delivery result)
```

Acceptance criteria:

- Business update and outbox insert commit/rollback together.
- Destination accepts only authenticated authorized packages.
- Destination decrypts correct payload and stores one Email record.
- Same package replay does not duplicate business action.
- Same ID/different hash is quarantined.
- Lost ACK can be regenerated/resumed from durable state.
- Crash after business commit does not repeat side effects.
- Source reports completion only after verified E-ACK.

## 15.4 Deployment baseline

- Separate configuration per role: Inner, Outer, Parent Outer.
- Secure site certificates and keys; no Inner decryption keys on Outer.
- MariaDB backups and restore drills; filesystem artifact backup/retention.
- CLI workers under dedicated service accounts, supervised by cron/systemd.
- Restricted package directories and web-root separation.
- Offline dependency updates and vulnerability review.
- Network allowlists/mTLS for Outer links.
- Alert thresholds tuned to handoff cadence and business priority.
- Formal incident, recovery and certificate revocation procedures.

# 16. Open Decisions and Implementation Checklist

## 16.1 Decisions to resolve before production coding

1. **Exact DXP/1 byte format:** ZIP vs fixed framing; path rules; manifest/ciphertext/signature layout.
2. **Canonicalization:** Precise signed bytes, AAD subset, signature domain separation and test vectors.
3. **Crypto provider:** Audited PHP 7.4-compatible implementation with explicit RSA-OAEP-SHA256 or approved KEM parameters.
4. **Certificate profiles:** SAN format, key usages, issuer policy, revocation freshness and historical signature validation.
5. **ACK framing:** Exact signed H-ACK/E-ACK objects, replay handling and control-message retention.
6. **Directory handoff contract:** Ownership, atomic file publication, receipt naming and duplicate delivery behavior with the external team.
7. **Retention:** How long origin, transit and destination artifacts and audit evidence remain.
8. **Limits:** Package/attachment sizes, quotas, retries, batch/concurrency thresholds.
9. **Synchronization semantics:** Authority and conflict policies per business entity.
10. **Operations:** Trust bundle distribution cadence, reporting cadence and alert thresholds.
11. **Legacy runtime:** Security exception, hardening and supported-runtime migration timetable.

## 16.2 Engineering checklist

- [ ] Document and test all site identities and trust boundaries.
- [ ] Freeze package protocol and publish test vectors.
- [ ] Define reviewed crypto provider and key separation.
- [ ] Implement DB schema with unique idempotency constraints.
- [ ] Implement outbox under caller-owned transactions.
- [ ] Implement builder with stable package identity and atomic file publish.
- [ ] Implement strict validator and safe archive handling.
- [ ] Implement destination-only decryption and trusted handler registry.
- [ ] Implement transactional processed-event + E-ACK outbox.
- [ ] Implement authenticated hop custody and E-ACK verification.
- [ ] Implement MariaDB leases, fencing, retries and recovery.
- [ ] Implement approved directory and HTTPS adapters.
- [ ] Implement signed trust directory, rollback defense and revocation policy.
- [ ] Implement per-site RBAC, admin audit and safe retries.
- [ ] Implement local/central status reporting with freshness labels.
- [ ] Pass security, recovery and interoperability acceptance tests.
- [ ] Complete deployment hardening and incident-response runbooks.

# 17. Glossary and References

## 17.1 Glossary

| Term | Definition |
|---|---|
| DX | Data Exchange Framework |
| Inner Site | Network-isolated environment hosting authoritative business processing |
| Outer Site | Gateway environment for controlled external access and package routing |
| Parent Outer | Central enterprise routing hub; no business plaintext access |
| Package | Immutable signed and encrypted end-to-end exchange object |
| Outbox | Business-transactional publication queue |
| Inbox | Durable receipt and processing state at a receiving site |
| H-ACK | Authenticated acknowledgement of durable next-hop custody |
| E-ACK | Destination Inner's signed business-processing result |
| CEK | Per-package content-encryption key |
| AAD | AEAD associated data binding ciphertext to immutable context |
| mTLS | Mutual TLS authentication between authorized Outer sites |
| Idempotency | Repeated delivery does not repeat committed business effects |
| Trust directory | Signed enterprise identity/certificate/authorization distribution |
| Store-and-forward | Durable intermediate custody followed by asynchronous forwarding |

## 17.2 Technical references for final review

- RFC 5116 — Authenticated Encryption with Associated Data (AEAD) interface.
- NIST SP 800-38D — Galois/Counter Mode (GCM).
- RFC 8017 — PKCS #1, including RSAES-OAEP.
- FIPS 186-5 — Digital Signature Standard.
- RFC 5280 — X.509 certificate and CRL profile.
- RFC 8785 — JSON Canonicalization Scheme (if canonical JSON is selected).
- OWASP ASVS — Application security verification guidance.
- MariaDB 10.11 documentation — InnoDB transactions, locking, indexes and worker claim patterns.
- PHP documentation — `random_bytes`, OpenSSL interfaces and PHP 7.4 support status.

---

## Final Architecture Principle

**Business modules publish events. Inner Sites encrypt, sign, decrypt and process them. Outer Sites and Parent Outer transport immutable packages without decrypting business contents. Each hop proves durable custody with an authenticated H-ACK; only the destination Inner confirms committed business processing with a signed E-ACK. MariaDB-backed idempotency and recovery make the system reliable despite disconnected, delayed and repeated transfers.**

**Document limitation:** This consolidated design is detailed enough to guide a phased implementation, but it is not yet a final interoperable cryptographic wire specification or a completed executable source-code release. The open decisions above must be closed and tested before production deployment.

---

# Appendix A. Full Decision Register and Site-by-Site Responsibilities

This appendix expands the condensed chapters into developer-level rules. The decisions below are **normative for the proposed implementation** unless marked *open*. Where the earlier discussions used illustrative names or code, the final implementation must choose one wire contract and publish test vectors.

## A.1 Enterprise site identities

| Site ID | Role | Business handlers | Decryption keys | HTTPS gateway | File handoff |
|---|---|---|---|---|---|
| `PARENT.INNER` | Parent business site | Yes | Own recipient key | No | To/from `PARENT.OUTER` |
| `PARENT.OUTER` | Enterprise gateway | No | **Never** | Yes | To/from `PARENT.INNER` |
| `COMPANY_A.INNER` | Subsidiary business site | Yes | Own recipient key | No | To/from `COMPANY_A.OUTER` |
| `COMPANY_A.OUTER` | Subsidiary gateway | No | **Never** | Yes | To/from `COMPANY_A.INNER` |
| `COMPANY_B.INNER` | Subsidiary business site | Yes | Own recipient key | No | To/from `COMPANY_B.OUTER` |
| `COMPANY_B.OUTER` | Subsidiary gateway | No | **Never** | Yes | To/from `COMPANY_B.INNER` |

Each site owns its own MariaDB database. A parent dashboard never performs a live SQL query against an Inner database. An Outer gateway stores only opaque business ciphertext and minimal routing/control metadata.

## A.2 Explicit network and software boundaries

```text
A.INNER --[file handoff; external approved dongle]--> A.OUTER
A.OUTER --[HTTPS + mutual TLS]--> PARENT.OUTER
PARENT.OUTER --[HTTPS + mutual TLS]--> B.OUTER
B.OUTER --[file handoff; external approved dongle]--> B.INNER

E-ACK: B.INNER -> B.OUTER -> PARENT.OUTER -> A.OUTER -> A.INNER
```

**Prohibited:** direct Inner↔Outer TCP/IP; a Parent service opening an Inner database; an Outer gateway decrypting business payloads; replacing the authorized dongle with a custom socket bridge; relying on Redis; dynamically loading event-handler classes from untrusted messages.

## A.3 Business responsibilities versus framework responsibilities

| Operation | Business module | DX framework |
|---|---|---|
| Decide an Email recipient's site | Owns decision using trusted directory | Validate destination permission |
| Store outgoing email | Owns transaction | Insert outbox in same transaction |
| Encrypt and sign package | No | Yes |
| Package naming, atomic file publication | No | Yes |
| Transfer through approved handoff | No | Expose/consume folders; dongle internals external |
| Route via Parent Outer | No | Yes |
| Validate package, cert, route | No | Yes |
| Deliver to local mailbox | Yes | Invoke registered handler transactionally |
| Business event dedup | Cooperates | Enforce durable `(source_site,event_id)` uniqueness |
| Signed processing acknowledgement | No | Yes, after committed handler result |
| Report business-specific failure | Yes | Translate into authenticated result and durable retry state |

## A.4 Failure guarantees and limitations

- At-least-once transport means repeated delivery is expected. Exactly-once *effects* require idempotent handlers, database constraints, and correct transaction boundaries.
- H-ACK proves **durable next-hop custody**, not business success. E-ACK proves a specific final processing outcome and must be verified at the original Inner sender.
- No transport can guarantee delivery if a malicious intermediary persistently discards all copies. Missing confirmations, custody history, and retention make this detectable/recoverable where alternate trusted copies remain.
- An Inner site's status at Parent Outer is a **last reported snapshot**. Never label it real-time merely because the corresponding Outer gateway is reachable.
- The approved dongle subsystem's internal authentication, scheduling, and hardware protocol are **out of scope**. Specify only the file publication, file intake, and authenticated receipt interfaces.

---

# Appendix B. Detailed End-to-End Scenarios and Sequence Diagrams

## B.1 Single destination: Email delivery

```text
Alice / Email service  A.INNER   A.OUTER   PARENT.OUTER   B.OUTER   B.INNER / Bob
        |                 |         |           |            |          |
1 Save email + outbox ---->|         |           |            |          |
2 Commit business txn      |         |           |            |          |
3 Build, encrypt, sign     |         |           |            |          |
4 Publish ready .pkg       |         |           |            |          |
5 Approved file handoff    |-------->|           |            |          |
6 Validate/store custody   |<--HACK--|           |            |          |
7 Forward via mTLS         |         |---------->|            |          |
8 Store custody            |         |<---HACK---|            |          |
9 Forward via mTLS         |         |           |----------->|          |
10 Store custody           |         |           |<---HACK----|          |
11 Approved file handoff   |         |           |            |--------->|
12 Store custody           |         |           |            |<--HACK---|
13 Decrypt, validate, apply|         |           |            |          |--> Bob mailbox
14 Commit processed+ACK outbox       |           |            |          |
15 Sign E-ACK              |         |           |            |<---------|
16 Reverse routing         |<--------|<----------|<-----------|          |
17 Verify E-ACK; mark destination business-success                     |
```

Each arrow in this sketch is conceptual. Actual H-ACK delivery across the directory boundary uses the approved reverse handoff path, not a network call. Do not delete the only surviving copy when an acknowledgement is merely queued but not yet verified.

## B.2 Multiple recipients with Bcc isolation

One logical email ID can generate multiple destination-specific package IDs. Build recipient subsets **before encryption**. The payload for B must not expose C's Bcc recipients. Per-site result statuses are independent; a failure at C does not revoke a success at B. Source mailbox status is a business aggregation over per-destination delivery outcomes.

## B.3 Out-of-order CRM synchronization

```text
Source customer V1 -> V2 -> V3 -> V4 -> V5
Receiver sees V3, then V5, then V4
FULL_STATE: apply V3; apply V5; ignore older V4 (after validation)
ORDERED_CHANGE: wait for V2 if last applied V1; buffer V3/V5/V4
APPEND_ONLY: deduplicate events and honor domain-specific ordering/dependencies
```

The source authority is registered per entity domain. The destination must not let a non-owner overwrite authoritative state. Deletions require explicit tombstone/version rules so an old update cannot resurrect a deleted entity.

## B.4 Failure and recovery example: ACK lost after commit

1. B.INNER commits Email insertion, processed-event identity, and E-ACK outbox in one transaction.
2. Worker signs E-ACK and places it in ready output.
3. A transfer fails and A.INNER never sees E-ACK.
4. A.INNER retains unconfirmed state and may retransmit the **same package bytes**.
5. B.INNER recognizes the duplicate and does **not** insert the email again.
6. B.INNER retrieves or regenerates a semantically equivalent signed processing result through its durable ACK workflow.
7. A.INNER verifies ACK package ID, hash, source, destination, event ID, result, and signature; only then marks the destination successful.

---

# Appendix C. DXPP 1.0 Protocol — Expanded Wire Contract

> **Specification status:** Proposed DXPP 1.0. The example structures are design contracts, not interoperability-certified fixtures. Freeze exact encodings, canonicalization, signature inputs, AAD bytes, and key-wrapping suite before deployment. Do not treat illustrative JSON as already canonical.

## C.1 Immutable package archive

```text
PKG-<opaque-unique-id>.pkg  [restricted ZIP]
├── manifest.json              # immutable, canonical JSON bytes
├── signature.sig              # detached origin signature; format fixed by suite
├── payload/
│   └── business.enc           # ciphertext plus explicit authenticated tag framing
└── attachments/
    ├── ATT-00001.enc
    └── ATT-00002.enc
```

For compatibility with earlier examples, the protocol may use `manifest.sig` rather than `signature.sig`, but **choose exactly one** for a released protocol. The initial recommendation is `signature.sig`. Never accept both ambiguously.

## C.2 Proposed public manifest (illustrative)

```json
{
  "protocol": "DXPP",
  "protocol_version": "1.0",
  "package_id": "PKG-8b4b23a4",
  "event_id": "EVT-fc172b1a",
  "source_site": "COMPANY_A.INNER",
  "destination_site": "COMPANY_B.INNER",
  "created_at": "2026-10-14T08:00:00Z",
  "crypto_suite": "DXPP-A256GCM-P256-v1",
  "signing_key_id": "COMPANY_A.INNER-SIGN-2026-02",
  "recipient_key_id": "COMPANY_B.INNER-ENC-2026-01",
  "wrapped_cek": "BASE64URL_PLACEHOLDER",
  "payload": {
    "path": "payload/business.enc",
    "ciphertext_sha256": "LOWERCASE_HEX_SHA256_PLACEHOLDER",
    "nonce": "BASE64URL_PLACEHOLDER",
    "tag": "BASE64URL_PLACEHOLDER"
  },
  "attachments": [],
  "critical_extensions": []
}
```

The manifest should reveal no event type or subject unless necessary for a documented routing policy. Store business message ID, event type, schema version, and recipient lists in the encrypted payload. If route policy needs a category, define a narrow authenticated public `routing_class` with a stable registry.

## C.3 Encrypted business event body

```json
{
  "event_type": "email.deliver",
  "event_version": 1,
  "business_message_id": "EMAIL-10001",
  "entity_type": null,
  "entity_id": null,
  "entity_version": null,
  "payload": {
    "sender": "alice",
    "recipients": ["bob"],
    "subject": "Test Message",
    "body": "Hello from Company A."
  }
}
```

Validate the decrypted JSON against a **registered schema** before dispatch. The event's verified source/destination identities come from authenticated package metadata, not from untrusted payload fields.

## C.4 Cryptographic processing order

1. Generate unique package ID and a fresh random 32-byte CEK.
2. Generate unique GCM nonce(s) for that CEK. A safer simple profile uses a distinct CEK per encrypted object or a formally specified nonce allocator for multiple objects.
3. Canonicalize immutable authenticated metadata according to the chosen protocol encoding.
4. Encrypt business payload and attachments with AES-256-GCM; bind required package identity/source/destination/object identity in AAD.
5. Wrap CEK using destination Inner's authorized encryption public key. RSA-OAEP-SHA256 requires a provider that **actually supports SHA-256 OAEP parameters**; PHP 7.4 `openssl_public_encrypt(..., OPENSSL_PKCS1_OAEP_PADDING)` alone does not guarantee this.
6. Compute ciphertext hashes and populate manifest.
7. Canonicalize manifest with an actual RFC 8785 JCS implementation or an independently specified deterministic encoding. PHP `json_encode()` alone is **not** JCS.
8. Sign the exact canonical manifest bytes with the authorized origin signing key.
9. Construct restricted archive, validate its contents, and publish atomically.
10. Destination validates origin signature and trust, authorization, recipient binding, ciphertext hashes, and AEAD tag before passing decrypted content to business handlers.

**Implementation detail to freeze:** whether the signature is DER-encoded ECDSA `(r,s)` or a fixed-width raw encoding, and whether ciphertext/tag are separate entries or explicitly framed bytes. Do not allow multiple interpretations of the same package.

## C.5 Transport envelope (separate from immutable package)

```json
{
  "transport_protocol": "DX-HOP/1",
  "transfer_id": "TRF-000123",
  "package_id": "PKG-8b4b23a4",
  "package_sha256": "LOWERCASE_HEX_SHA256_PLACEHOLDER",
  "from_site": "COMPANY_A.OUTER",
  "to_site": "PARENT.OUTER",
  "route_policy_version": 125,
  "hop_index": 2,
  "max_hops": 8,
  "attempt_id": "ATTEMPT-000987",
  "created_at": "2026-10-14T08:05:00Z"
}
```

Authenticate the per-hop envelope independently (mTLS channel identity plus a defined authenticated record, or signed envelope). A gateway must not rewrite the origin package. Hop index and route limits mitigate accidental loops, but cannot prevent a fully malicious gateway from dropping traffic.

## C.6 Archive validation checklist

- Accept only explicitly supported archive compression methods.
- Reject absolute paths, `..`, backslashes when ambiguous, duplicate normalized names, symlinks, special files, and unexpected entries.
- Bound compressed bytes, uncompressed bytes, entry count, manifest size, attachment count, and decompression work.
- Compare declared object hashes to exact stored bytes; do not trust ZIP CRC as cryptographic integrity.
- Reject invalid UTF-8, duplicate JSON object keys, unsupported critical extensions, invalid integer ranges, and noncanonical representations where required.
- Never unpack arbitrary archive paths directly into business directories; stream recognized entries into controlled private storage.

---

# Appendix D. Acknowledgement Contracts and Durable State Machines

## D.1 H-ACK record (illustrative)

```json
{
  "type": "DX.HOP_ACK",
  "version": 1,
  "ack_id": "HACK-00001",
  "transfer_id": "TRF-000123",
  "package_id": "PKG-8b4b23a4",
  "package_sha256": "LOWERCASE_HEX_SHA256_PLACEHOLDER",
  "from_site": "PARENT.OUTER",
  "to_site": "COMPANY_A.OUTER",
  "result": "CUSTODY_ACCEPTED",
  "received_at": "2026-10-14T08:06:00Z"
}
```

H-ACK must be authenticated by the *receiving hop*. It is issued only after durable storage and corresponding database state are committed. It is not a promise of final business delivery.

## D.2 E-ACK record (illustrative)

```json
{
  "type": "DX.END_TO_END_ACK",
  "version": 1,
  "ack_id": "EACK-00001",
  "package_id": "PKG-8b4b23a4",
  "package_sha256": "LOWERCASE_HEX_SHA256_PLACEHOLDER",
  "event_id": "EVT-fc172b1a",
  "original_source_site": "COMPANY_A.INNER",
  "final_destination_site": "COMPANY_B.INNER",
  "result": "SUCCESS",
  "processed_at": "2026-10-14T08:20:00Z"
}
```

The E-ACK must be signed by the destination Inner identity and travel through approved reverse hops. The sender verifies the ACK against the **expected destination**, package ID/hash, event ID, and valid result transition. ACK-of-ACK loops are forbidden.

## D.3 Recommended state dimensions

Do not overload one `status` column with every independent fact. Maintain separate dimensions for:

| Dimension | Representative states |
|---|---|
| Outbox | `PENDING`, `CLAIMED`, `BUILT`, `FAILED_RETRYABLE`, `FAILED_FINAL` |
| Package | `BUILDING`, `READY`, `QUARANTINED`, `RETAINED`, `CLEANED` |
| Transfer | `QUEUED`, `SENDING`, `WAITING_HACK`, `HACK_VERIFIED`, `RETRY_WAIT`, `FAILED` |
| Receiver | `RECEIVED`, `VALIDATING`, `CUSTODY_ACCEPTED`, `PROCESSING`, `PROCESSED`, `REJECTED` |
| Business event | `PENDING`, `WAITING_DEPENDENCY`, `WAITING_VERSION`, `SUCCESS`, `PERMANENT_FAILURE` |
| E-ACK | `NOT_RECEIVED`, `VERIFIED_SUCCESS`, `VERIFIED_FAILURE`, `CONFLICT` |

## D.4 State transition invariants

- `READY` requires an existing verified immutable artifact.
- `HACK_VERIFIED` requires matching authenticated transfer/package/hash/receiver identity.
- `VERIFIED_SUCCESS` requires a valid destination-signed E-ACK; a timeout cannot set this state.
- `PROCESSED` requires committed business effects and durable processed-event record.
- A terminal security rejection cannot be converted into success by manual status editing.
- Duplicate ACK IDs and duplicate package deliveries are safe no-ops when exact identities and content match; conflicting duplicates are security incidents.

---

# Appendix E. MariaDB 10.11 — Expanded Reference Schema

> This schema is a **reference starting point**, not a drop-in replacement for the earlier illustrative Part 10 schema. It uses local site databases, utf8mb4, UTC timestamps, and unique constraints. Integrators must align column types, foreign keys, partition/retention policies, and transaction semantics with their existing ZF1 schema. Sensitive payload data in the outbox exists only on an authorized Inner site; Outer sites must not hold plaintext business events.

```sql
CREATE TABLE IF NOT EXISTS exchange_sites (
  site_id VARCHAR(100) NOT NULL PRIMARY KEY,
  site_role ENUM('INNER','OUTER') NOT NULL,
  company_code VARCHAR(60) NOT NULL,
  is_enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_routes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  current_site VARCHAR(100) NOT NULL,
  destination_site VARCHAR(100) NOT NULL,
  next_hop_site VARCHAR(100) NOT NULL,
  transport_type ENUM('DIRECTORY','HTTPS') NOT NULL,
  policy_version BIGINT UNSIGNED NOT NULL,
  is_enabled TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_route (current_site,destination_site,policy_version),
  KEY ix_route_next (next_hop_site,is_enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_route_permissions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  source_site VARCHAR(100) NOT NULL,
  destination_site VARCHAR(100) NOT NULL,
  routing_class VARCHAR(100) NOT NULL,
  is_allowed TINYINT(1) NOT NULL,
  policy_version BIGINT UNSIGNED NOT NULL,
  UNIQUE KEY uq_permission (source_site,destination_site,routing_class,policy_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_outbox (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  source_site VARCHAR(100) NOT NULL,
  event_id VARCHAR(100) NOT NULL,
  event_type VARCHAR(150) NOT NULL,
  event_version SMALLINT UNSIGNED NOT NULL,
  destination_site VARCHAR(100) NOT NULL,
  payload_json LONGTEXT NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
  lease_token VARCHAR(100) DEFAULT NULL,
  lease_expires_at DATETIME(6) DEFAULT NULL,
  next_attempt_at DATETIME(6) DEFAULT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_event_destination (source_site,event_id,destination_site),
  KEY ix_claim (status,next_attempt_at,id),
  KEY ix_lease (lease_expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_packages (
  package_id VARCHAR(100) NOT NULL PRIMARY KEY,
  outbox_id BIGINT UNSIGNED DEFAULT NULL,
  source_site VARCHAR(100) NOT NULL,
  destination_site VARCHAR(100) NOT NULL,
  package_sha256 CHAR(64) NOT NULL,
  package_size BIGINT UNSIGNED NOT NULL,
  storage_path VARCHAR(1024) NOT NULL,
  status VARCHAR(32) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  KEY ix_package_outbox (outbox_id),
  KEY ix_package_dest_status (destination_site,status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_package_files (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  package_id VARCHAR(100) NOT NULL,
  object_name VARCHAR(255) NOT NULL,
  ciphertext_sha256 CHAR(64) NOT NULL,
  ciphertext_size BIGINT UNSIGNED NOT NULL,
  UNIQUE KEY uq_object (package_id,object_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_transfers (
  transfer_id VARCHAR(100) NOT NULL PRIMARY KEY,
  package_id VARCHAR(100) NOT NULL,
  from_site VARCHAR(100) NOT NULL,
  to_site VARCHAR(100) NOT NULL,
  transport_type ENUM('DIRECTORY','HTTPS') NOT NULL,
  status VARCHAR(40) NOT NULL,
  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
  next_attempt_at DATETIME(6) DEFAULT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  KEY ix_transfer_queue (status,next_attempt_at),
  KEY ix_transfer_package (package_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_transfer_attempts (
  attempt_id VARCHAR(100) NOT NULL PRIMARY KEY,
  transfer_id VARCHAR(100) NOT NULL,
  started_at DATETIME(6) NOT NULL,
  completed_at DATETIME(6) DEFAULT NULL,
  result_code VARCHAR(80) DEFAULT NULL,
  error_detail VARCHAR(1000) DEFAULT NULL,
  KEY ix_attempt_transfer (transfer_id,started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_received (
  package_id VARCHAR(100) NOT NULL PRIMARY KEY,
  package_sha256 CHAR(64) NOT NULL,
  source_site VARCHAR(100) NOT NULL,
  destination_site VARCHAR(100) NOT NULL,
  custody_status VARCHAR(40) NOT NULL,
  received_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  KEY ix_received_status (custody_status,received_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_processed_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  source_site VARCHAR(100) NOT NULL,
  event_id VARCHAR(100) NOT NULL,
  event_type VARCHAR(150) NOT NULL,
  package_id VARCHAR(100) NOT NULL,
  result_code VARCHAR(60) NOT NULL,
  processed_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_processed_event (source_site,event_id),
  KEY ix_processed_package (package_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_pending_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  source_site VARCHAR(100) NOT NULL,
  event_id VARCHAR(100) NOT NULL,
  package_id VARCHAR(100) NOT NULL,
  pending_reason VARCHAR(60) NOT NULL,
  dependency_type VARCHAR(100) DEFAULT NULL,
  dependency_id VARCHAR(150) DEFAULT NULL,
  next_check_at DATETIME(6) DEFAULT NULL,
  created_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_pending_event (source_site,event_id),
  KEY ix_pending_check (pending_reason,next_check_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_acknowledgements (
  ack_id VARCHAR(100) NOT NULL PRIMARY KEY,
  ack_type ENUM('HOP','END_TO_END') NOT NULL,
  package_id VARCHAR(100) NOT NULL,
  transfer_id VARCHAR(100) DEFAULT NULL,
  signed_by_site VARCHAR(100) NOT NULL,
  result_code VARCHAR(60) NOT NULL,
  verified_at DATETIME(6) DEFAULT NULL,
  created_at DATETIME(6) NOT NULL,
  KEY ix_ack_package (package_id,ack_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_ack_outbox (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ack_id VARCHAR(100) NOT NULL,
  ack_type ENUM('HOP','END_TO_END') NOT NULL,
  package_id VARCHAR(100) NOT NULL,
  destination_site VARCHAR(100) NOT NULL,
  ack_body_json LONGTEXT NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_ack_outbox (ack_id),
  KEY ix_ack_queue (status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_entity_versions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  authority_site VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id VARCHAR(150) NOT NULL,
  last_applied_version BIGINT UNSIGNED NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_entity (authority_site,entity_type,entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_certificates (
  certificate_id VARCHAR(100) NOT NULL PRIMARY KEY,
  site_id VARCHAR(100) NOT NULL,
  usage_type ENUM('SIGNING','ENCRYPTION','TRANSPORT') NOT NULL,
  sha256_fingerprint CHAR(64) NOT NULL,
  not_before DATETIME NOT NULL,
  not_after DATETIME NOT NULL,
  status VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_fingerprint (sha256_fingerprint),
  KEY ix_cert_site_usage (site_id,usage_type,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_trust_versions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  directory_version BIGINT UNSIGNED NOT NULL,
  signed_digest CHAR(64) NOT NULL,
  accepted_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_trust_version (directory_version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  occurred_at DATETIME(6) NOT NULL,
  site_id VARCHAR(100) NOT NULL,
  actor_id VARCHAR(150) NOT NULL,
  action VARCHAR(120) NOT NULL,
  target_id VARCHAR(150) DEFAULT NULL,
  result_code VARCHAR(80) NOT NULL,
  correlation_id VARCHAR(100) DEFAULT NULL,
  previous_hash CHAR(64) DEFAULT NULL,
  record_hash CHAR(64) DEFAULT NULL,
  KEY ix_audit_time (occurred_at),
  KEY ix_audit_target (target_id,occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_worker_status (
  worker_instance_id VARCHAR(100) NOT NULL PRIMARY KEY,
  worker_type VARCHAR(60) NOT NULL,
  site_id VARCHAR(100) NOT NULL,
  status VARCHAR(30) NOT NULL,
  last_heartbeat_at DATETIME(6) DEFAULT NULL,
  last_success_at DATETIME(6) DEFAULT NULL,
  processed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  failed_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  updated_at DATETIME(6) NOT NULL,
  KEY ix_worker_type (site_id,worker_type,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exchange_alerts (
  alert_id VARCHAR(100) NOT NULL PRIMARY KEY,
  site_id VARCHAR(100) NOT NULL,
  alert_type VARCHAR(100) NOT NULL,
  severity ENUM('INFO','WARNING','ERROR','CRITICAL') NOT NULL,
  status ENUM('OPEN','ACKNOWLEDGED','RESOLVED') NOT NULL,
  package_id VARCHAR(100) DEFAULT NULL,
  message VARCHAR(1000) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  resolved_at DATETIME(6) DEFAULT NULL,
  KEY ix_alert_queue (status,severity,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## E.1 Important schema notes

1. The original core list had **16** named core tables, despite one earlier description saying 15. This expanded reference includes those 16 plus `exchange_ack_outbox`, `exchange_worker_status`, and `exchange_alerts`.
2. **No foreign keys are shown** in this portable reference because not all rows are present on every site and retention policies differ. Add appropriate same-site FKs after confirming lifecycle and deletion semantics.
3. `exchange_outbox.payload_json` must be restricted to an authorized Inner database. Encrypt sensitive fields at rest if required by the site's data policy. Never replicate it to an Outer gateway.
4. MariaDB `DATETIME(6)` should be stored in UTC by application convention. Establish clock synchronization and record local receive time independently of claimed remote times.
5. Ensure durable ACK publication after business commit: `exchange_ack_outbox` is inserted in the same transaction as business effects and `exchange_processed_events`.
6. Add row-level fencing checks when claiming work: the `lease_token` must match on every final state update. A lease alone does not prevent a paused worker from resuming.
7. Do not store private keys in `exchange_certificates`; store certificate **metadata** and protected key references only.
8. `exchange_packages.storage_path` is an internal controlled path, not an untrusted manifest-supplied path.
9. A production schema needs explicit migration/version tables, detailed state constraints, and approved cleanup/retention logic.

## E.2 Typical operational queries

```sql
-- Pending work eligible for claiming
SELECT id, event_id, destination_site
FROM exchange_outbox
WHERE status = 'PENDING'
  AND (next_attempt_at IS NULL OR next_attempt_at <= UTC_TIMESTAMP(6))
ORDER BY id
LIMIT 50;

-- Awaiting hop custody confirmation
SELECT transfer_id, package_id, to_site, updated_at
FROM exchange_transfers
WHERE status = 'WAITING_HACK'
ORDER BY updated_at ASC
LIMIT 100;

-- Business processing backlog
SELECT pending_reason, COUNT(*) AS total
FROM exchange_pending_events
GROUP BY pending_reason;

-- Active security alerts
SELECT alert_id, alert_type, severity, created_at
FROM exchange_alerts
WHERE status = 'OPEN'
ORDER BY FIELD(severity,'CRITICAL','ERROR','WARNING','INFO'), created_at;
```

---

# Appendix F. PHP 7.4 / ZF1 Developer API — Detailed Reference

## F.1 Public API contracts

```php
<?php
interface S3_DataExchange_ApiInterface
{
    public function publish($eventType, $destinationSite, array $payload, array $options = array());
    public function publishMany($eventType, array $destinationSites, array $payload, array $options = array());
    public function publishBatch($eventType, array $deliveries, array $options = array());
    public function registerEventType($eventType, array $definition);
    public function registerHandler($eventType, S3_DataExchange_Event_HandlerInterface $handler);
    public function getEventStatus($eventId);
    public function getDeliveryResults($eventId);
}

interface S3_DataExchange_Event_HandlerInterface
{
    public function handle(array $event);
}

interface S3_DataExchange_StatusListenerInterface
{
    public function onDeliveryResult(array $result);
}
```

The methods above are the **intended interface**, not a claim that these classes have already been implemented. Delayed status callbacks are delivered through a durable local event queue; an in-memory callback cannot survive a process restart.

## F.2 Publication with a shared transaction

```php
<?php
class Crm_Service_Customer
{
    private $db;
    private $dx;

    public function __construct(Zend_Db_Adapter_Abstract $db, S3_DataExchange_ApiInterface $dx)
    {
        $this->db = $db;
        $this->dx = $dx;
    }

    public function renameCustomer($customerId, $newName, $eventId)
    {
        $this->db->beginTransaction();
        try {
            // Real code must enforce business authorization and version checks.
            $affected = $this->db->update('crm_customers', array(
                'name' => $newName
            ), $this->db->quoteInto('customer_id = ?', $customerId));

            if ($affected !== 1) {
                throw new RuntimeException('Customer not found or update not applied');
            }

            $result = $this->dx->publish(
                'crm.customer.updated',
                'COMPANY_B.INNER',
                array('customer_id' => $customerId, 'name' => $newName),
                array('event_id' => $eventId, 'event_version' => 1)
            );
            // Publisher MUST use this same DB adapter and MUST NOT commit.
            $this->db->commit();
            return $result;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
```

**Contract:** The caller owns the transaction. `publish()` validates the event and destination, inserts one outbox row, and returns a provisional local queue result. A failure publishing any required destination in `publishMany()` or `publishBatch()` rolls back the entire business transaction unless a separate documented partial-publication policy is explicitly chosen.

## F.3 Event registry and allowlisted handlers

```php
<?php
$registry->register('crm.customer.updated', array(
    'event_version' => 1,
    'module' => 'crm',
    'handler_class' => 'Crm_DataExchange_CustomerUpdated',
    'schema_path' => APPLICATION_PATH . '/modules/crm/dataexchange/schemas/customer-updated-v1.json',
    'sync_mode' => 'FULL_STATE',
    'allowed_sources' => array('COMPANY_A.INNER'),
    'allowed_destinations' => array('COMPANY_B.INNER'),
    'max_payload_bytes' => 1048576
));
```

Only locally trusted configuration may specify `handler_class`. The received event's `event_type` is a **lookup key** into the preloaded registry, never an executable class name or path. Registering a new version requires a schema, handler/adapter, compatibility tests, and a rollout plan for disconnected sites.

## F.4 Handler transaction boundary

```php
<?php
class Crm_DataExchange_CustomerUpdated
    implements S3_DataExchange_Event_HandlerInterface
{
    private $db;

    public function __construct(Zend_Db_Adapter_Abstract $db)
    {
        $this->db = $db;
    }

    public function handle(array $event)
    {
        $payload = $event['payload'];
        // Framework has already authenticated source/destination and schema.
        // Handler still validates domain-specific ownership and version semantics.
        $this->db->update('crm_customers', array(
            'name' => $payload['name']
        ), $this->db->quoteInto('customer_id = ?', $payload['customer_id']));

        // Do NOT commit here; dispatcher commits business changes,
        // processed-event identity, and ACK-outbox atomically.
        return array('status' => 'SUCCESS');
    }
}
```

A real handler must implement the full-state or ordered-change policy and verify authoritative ownership; the code above illustrates only the transaction boundary. Side effects such as SMTP sends, HTTP calls, or OS file writes cannot be rolled back by MariaDB; use a business outbox/idempotency token for those.

## F.5 Per-destination Email grouping

```php
<?php
$dx->publishBatch('email.deliver', array(
    array(
        'destination_site' => 'COMPANY_B.INNER',
        'payload' => array(
            'message_id' => 'EMAIL-50001',
            'recipients' => array('bob', 'charlie'),
            'subject' => 'Monthly report'
        )
    ),
    array(
        'destination_site' => 'COMPANY_C.INNER',
        'payload' => array(
            'message_id' => 'EMAIL-50001',
            'recipients' => array('david'),
            'subject' => 'Monthly report'
        )
    )
), array('event_id' => 'EVT-EMAIL-50001', 'event_version' => 1));
```

One logical email ID and event ID may have multiple per-destination outbox records. Each destination gets a separate package ID, encryption context, ACK history, and result. Preserve Bcc privacy and do not put recipient lists in the public manifest.

## F.6 API result meanings

| API | Success means | It does NOT mean |
|---|---|---|
| `publish()` | Local outbox row inserted in caller transaction | Remote delivered |
| `publishMany()` | Required destination rows inserted in caller transaction | Every destination processed |
| `getEventStatus()` | Known local and verified reported states returned | Live remote state |
| `registerHandler()` | Trusted local handler mapped | Remote site supports version |
| `onDeliveryResult()` | Verified result was delivered to listener | Callback will never be retried |

## F.7 Exception taxonomy

```text
S3_DataExchange_Exception_ValidationException
S3_DataExchange_Exception_AuthorizationException
S3_DataExchange_Exception_ConfigurationException
S3_DataExchange_Exception_DuplicateEventException
S3_DataExchange_Exception_StorageException
S3_DataExchange_Exception_SecurityException
S3_DataExchange_Exception_ProcessingException
```

Treat errors as either immediate local API errors or asynchronous processing/transport/remote errors. Do not conflate them. All remote result handling must be idempotent.

## F.8 ZF1 bootstrap registration

```php
<?php
class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initDataExchange()
    {
        $db = Zend_Db_Table::getDefaultAdapter();
        $dx = new S3_DataExchange_Api($db);
        Zend_Registry::set('dataExchange', $dx);
        return $dx;
    }
}
```

For new code, constructor injection is preferable to repeated `Zend_Registry` access. Avoid global function wrappers. PHP 7.4 supports `Throwable`, but not PHP 8 `match`, union types, or constructor property promotion.

## F.9 Recommended module structure

```text
application/modules/crm/
  controllers/
  models/
  services/
  dataexchange/
    Config.php
    EventRegistry.php
    handlers/CustomerCreated.php
    handlers/CustomerUpdated.php
    handlers/CustomerDeleted.php
    listeners/DeliveryStatus.php
    schemas/customer-created-v1.json
    schemas/customer-updated-v1.json
    schemas/customer-updated-v2.json
    tests/CustomerUpdatedTest.php
```

---

# Appendix G. Processing Algorithms A–T — Engineering Pseudocode

These are the expanded algorithms discussed in Part 11. Each algorithm should have unit tests, integration tests, crash injection, and audit correlation IDs.

## G.A Publish business event

```text
INPUT: authenticated local business action, event type, destination(s), payload
1. Authorize user/action in business module.
2. Resolve destination site(s) using trusted directory.
3. Generate stable logical event ID.
4. BEGIN business database transaction.
5. Apply business change.
6. For each destination: validate event schema and permissions; INSERT outbox.
7. COMMIT. If any required insert fails, ROLLBACK all changes.
8. Return local queued result; never claim remote delivery.
```

## G.B Claim outbox work

```text
1. BEGIN short transaction.
2. SELECT eligible PENDING rows FOR UPDATE SKIP LOCKED.
3. Assign unique lease token, expiry, attempt number.
4. COMMIT; perform expensive package work outside transaction.
5. On final update, require matching lease token/fencing condition.
6. If lease lost, stop publishing and let recovery reconcile.
```

## G.C Build package

```text
1. Validate event, destination, schema version, current policy.
2. Reserve durable package ID associated with outbox row.
3. Resolve recipient encryption key and origin signing key.
4. Create fresh CEK and authenticated encryption metadata.
5. Encrypt payload and attachment objects.
6. Compute ciphertext hashes; canonicalize and sign manifest.
7. Build restricted archive in send/building.
8. Validate archive, hashes, signature, recipient binding.
9. fsync as supported, atomic rename within filesystem to send/ready.
10. Commit package READY state with lease fencing.
11. Recovery reconciles any crash between steps 9 and 10.
```

## G.D Detect incoming file

```text
1. Scan receive/incoming for approved complete filenames.
2. Do not consume partially written files; require producer atomic publication contract.
3. Safely claim file to receive/processing without following symlinks.
4. Record file identity and immutable bytes/hash.
5. Begin bounded structural validation.
```

## G.E Validate at gateway versus final Inner

```text
COMMON: archive bounds, canonical manifest, signature, certificate, revocation,
        site identities, routing authorization, package hash, replay state.
GATEWAY: store opaque package; never unwrap CEK or call business handler.
FINAL INNER: validate recipient binding; unwrap CEK; AEAD verify; validate
             decrypted schema; dispatch registered business handler.
```

## G.F Detect duplicates

```text
IF package_id absent: insert immutable ID/hash and process.
IF same package_id + same hash: return prior custody/business result safely.
IF same package_id + different hash: quarantine and raise security incident.
IF different package_id + same source_site/event_id already processed:
    suppress duplicate business effect and return prior committed outcome.
```

## G.G Route package

```text
1. Read immutable signed final destination.
2. Read authenticated current site identity.
3. Find active approved route under signed policy version.
4. Reject loops, excessive hop count, unauthorized next hop.
5. Create separate hop transfer record and authenticated envelope.
6. Enqueue for DIRECTORY or HTTPS transport.
```

## G.H Generate Hop ACK

```text
1. Validate and durably store package bytes.
2. Commit receiver custody record with package hash.
3. Persist H-ACK intent (durable queue).
4. Authenticate H-ACK using receiving hop identity.
5. Publish through reverse approved hop.
```

## G.I Process Hop ACK

```text
1. Verify hop identity and ACK authentication.
2. Match transfer_id, package_id, package_hash, expected receiving hop.
3. Reject conflicts and unauthorized state transitions.
4. Commit HACK_VERIFIED and custody history.
5. Retain/delete transfer copy only according to retention policy.
```

## G.J Dispatch final business event

```text
1. Verify recipient site identity and decrypt/authenticate payload.
2. Validate registered schema and source/event permissions.
3. BEGIN business DB transaction.
4. Check durable (source_site,event_id) dedup.
5. Invoke allowlisted handler with verified context and same DB adapter.
6. Insert processed-event record and E-ACK outbox intent.
7. COMMIT; asynchronous worker signs and sends E-ACK.
8. On error ROLLBACK; record retryable/permanent outcome separately.
```

## G.K Business event deduplication

```text
Use UNIQUE(source_site,event_id) with transactional insert/lock.
If event already committed: do not repeat handler; return committed outcome.
If another worker is in progress: wait/retry without side effects.
Never rely only on an in-memory cache.
```

## G.L Generate E-ACK

```text
1. Read committed ACK outbox intent.
2. Build canonical ACK with package ID/hash, event ID, source/destination.
3. Sign using destination Inner signing key.
4. Persist immutable ACK artifact.
5. Route through reverse approved path.
```

## G.M Process E-ACK

```text
1. Verify signature, destination Inner certificate and revocation policy.
2. Match original source/destination, package ID/hash and event ID.
3. Validate outcome and ACK identity against previous outcomes.
4. Atomically update per-destination delivery state.
5. Queue durable local business delivery-result notification.
6. No ACK-of-ACK message.
```

## G.N Retry/backoff

```text
Classify errors as TRANSIENT, WAITING_DEPENDENCY, WAITING_CERTIFICATE,
PERMANENT_BUSINESS, or SECURITY_REJECTION.
Retry only eligible states; use capped exponential backoff plus jitter.
Track attempt ID, previous error, next attempt time, and retry budget.
Never modify immutable package bytes during a transport retry.
```

## G.O Crash recovery

```text
Inspect expired leases and mismatches between database and filesystem.
If ready artifact exists: validate exact bytes/hash before reconciling.
If artifact missing: rebuild only when no published conflicting package exists.
If business commit succeeded but ACK unsent: resume ACK outbox.
If H-ACK lost: safely reissue custody confirmation.
Log every reconciliation and retain evidence of ambiguous cases.
```

## G.P Apply synchronization

```text
Read event sync_mode and authoritative owner.
FULL_STATE: apply only if version > last_applied and valid owner.
ORDERED_CHANGE: require expected predecessor; otherwise WAITING_VERSION.
APPEND_ONLY: deduplicate and enforce domain dependencies.
Commit business changes and version state together.
```

## G.Q Resolve dependencies

```text
On WAITING_DEPENDENCY, store dependency type/ID and event identity.
On dependency arrival, select eligible pending events.
Retry in bounded batches; avoid infinite cycles.
For missing history, request approved snapshot/replay through DX event.
```

## G.R Install signed trust update

```text
1. Receive through approved path.
2. Verify security-authority signature against pinned bootstrap trust.
3. Validate target scope, version monotonicity, validity and revocations.
4. Stage new trust bundle; atomically activate.
5. Persist highest accepted version in protected state.
6. Audit activation and trigger waiting-certificate rechecks.
```

## G.S Cleanup and retention

```text
1. Identify eligible artifacts by explicit retention policy.
2. Ensure required H-ACK/E-ACK and legal/audit holds are satisfied.
3. Record cleanup decision and correlation ID.
4. Delete only known controlled storage paths; never trust input path.
5. Reconcile database status after deletion; report exceptions.
```

## G.T Worker scheduling and concurrency

```text
Run build, receive, retry and recover workers via cron/systemd.
Use short MariaDB claim transactions, lease tokens, idempotent handlers.
Apply bounded concurrency, disk quotas, worker heartbeats, alerts.
Keep operational workers off HTTP request paths.
```

---

# Appendix H. Transport, Directory Contracts, and Failure Handling

## H.1 Directory lifecycle

```text
/var/lib/s3-dataexchange/
  send/building/
  send/ready/
  send/exported/
  send/failed/
  receive/incoming/
  receive/processing/
  receive/processed/
  receive/rejected/
  receive/failed/
  quarantine/
  logs/
```

`send/ready` is the only directory the approved handoff subsystem should consume. The handoff producer must publish complete immutable files atomically; the consumer must never process half-written files. Directory existence or disappearance is not delivery confirmation. A separate authenticated H-ACK is the proof of custody.

## H.2 Directory handoff interface contract

| Contract | Required behavior |
|---|---|
| File naming | Opaque package ID plus fixed extension; reject ambiguous names |
| Completion | Temporary write followed by atomic rename on same filesystem |
| Immutability | Never modify a ready package in place |
| Intake | Safe claim to processing directory; hash exact bytes |
| Duplicate | Same ID/hash is replay-safe; ID/hash mismatch quarantined |
| Custody | H-ACK only after durable storage and database commit |
| Error | Quarantine security failures; retry transient IO errors |
| External boundary | No assumptions about dongle internal software or scheduling |

## H.3 HTTPS/mTLS gateway protocol

```text
1. Sender authenticates remote gateway certificate and expected site identity.
2. Receiver authenticates client gateway certificate and route permission.
3. Sender streams bounded package with authenticated transfer envelope.
4. Receiver validates admission constraints, immutable package and custody policy.
5. Receiver durably stores package and commits custody record.
6. Receiver returns authenticated H-ACK (not merely HTTP 200).
7. Sender verifies ACK, updates transfer record, and schedules next work.
```

Use timeouts, maximum body size, request IDs, rate limits, and TLS cipher/protocol policy appropriate to the approved platform. Never allow a remote endpoint to dictate an arbitrary filesystem path or next-hop site.

## H.4 Common failure matrix

| Failure | Observation | Safe response |
|---|---|---|
| Dongle handoff delayed | No authenticated next-hop custody | Retain package, show waiting |
| HTTPS timeout | No verified H-ACK | Retry identical package/transfer idempotently |
| H-ACK lost | Receiver may already have custody | Replay; receiver reissues equivalent H-ACK |
| E-ACK lost | Business may already be committed | Retransmit safely; no duplicate business effect |
| Invalid signature | Authenticated origin cannot be established | Quarantine and alert |
| Missing cert | Cannot complete trust validation | Wait under policy; no plaintext fallback |
| Route unavailable | No authorized next hop | Hold and alert; never invent route |
| Disk full | Cannot durably accept custody | Do not issue H-ACK; preserve sender copy |
| DB unavailable | Cannot commit custody/business transaction | Do not claim successful processing |
| Worker crash | Lease expires; partial artifact may exist | Recovery reconcile using hash/lease fencing |

---

# Appendix I. Security Hardening and Threat Model — Full Developer Checklist

## I.1 STRIDE across boundaries

| Boundary | Threat | Defense | Evidence/test |
|---|---|---|---|
| Business module → DX API | Unauthorized event publication | Module/service identity, event/destination allowlist | Unauthorized publish rejected |
| Inner → directory | Tampered ready file | Signed immutable package, controlled folder | Byte flip rejected |
| Outer → Parent | Spoofed gateway | mTLS certificate/site binding | Wrong certificate rejected |
| Parent → Outer | Route manipulation | Signed route policy, immutable destination | Unauthorized next hop rejected |
| Outer → Inner | Replay | Package ID/hash dedup | Same package not reprocessed |
| Receiver → handler | Injection | JSON schema, allowlisted handler, SQL binding | Malformed payload rejected |
| Destination → sender ACK | Forgery | Signed E-ACK bound to package/event | Forged ACK rejected |
| Admin → DX services | Privilege escalation | RBAC, CSRF, approval, audit | Viewer cannot retry/activate route |

## I.2 Compromised Parent Outer

An attacker with control of Parent Outer may inspect **public routing metadata**, suppress/replay/delay packages, forge local monitoring claims, or deny service. The attacker must not be able to decrypt business payloads or forge origin signatures and destination E-ACKs if Inner private keys and trust authorities remain secure. H-ACK from a compromised hop cannot be treated as business completion. Retain source copies until verified E-ACK according to retention policy.

## I.3 Compromised signing key

A stolen Inner signing key defeats origin authentication for messages signed with that key. Required response: suspend affected signing, revoke certificate, issue replacement, distribute authenticated trust updates, identify affected packages, quarantine uncertain history, audit all actions. A package's self-declared creation time is not trusted signing-time evidence.

## I.4 Trust rollback and stale revocation

Each site persists highest accepted signed trust-directory version; reject lower versions. Define a maximum revocation-information age and fail-closed/hold behavior for sensitive operations. A compromised local database can rewrite a version counter; stronger systems anchor the highest accepted version in protected independent state.

## I.5 Archive/parser defense

- Limit compressed and expanded sizes, entry count, manifest bytes, attachment count and decompression time.
- Reject traversal, absolute paths, symlinks, duplicate normalized names, unknown critical extensions and invalid UTF-8.
- Reject ambiguous JSON (duplicate keys, noncanonical encodings, unsupported numbers) according to frozen protocol.
- Never execute package content or use `unserialize()` on untrusted bytes.
- Compare exact ciphertext hashes and verify AEAD tags before business use.

## I.6 Privilege separation

| Process | Recommended access |
|---|---|
| Web business service | Business tables + insert authorized outbox rows |
| Build worker | Read claimed outbox, signing/encryption service, private build/ready directories |
| Gateway worker | Opaque package custody, transport cert, routing policy; **no Inner decryption key** |
| Receive worker | Package validation and local processing queues |
| Business dispatcher | Required business tables, processed-events, ACK outbox |
| Dashboard API | Read-only operational views, except controlled admin operations |
| Cleanup worker | Only managed artifact paths with retention authorization |

Run workers under restricted service identities rather than root. Keep DX files outside the public web root. Protect backups, logs, private keys and certificate issuance processes.

## I.7 Audit integrity

A tamper-evident chain can compute `H_i = SHA256(H_(i-1) || canonical_record_i)`. This detects isolated modifications but **not** wholesale rewriting by a database administrator who controls all hashes. Periodically sign checkpoints and export them outside the database trust boundary. Log denied admin actions, route changes, certificate installs, quarantines and recovery decisions without exposing keys or plaintext.

## I.8 Security baseline caveat

PHP 7.4 and original ZF1 are legacy and lack normal current upstream security support. The production security review should evaluate a supported PHP runtime, supported OS, maintained framework/compatibility layer, dependency inventory, offline patch distribution, and compensating controls. Do not describe a PHP 7.4 proof of concept as production security certification.

---

# Appendix J. Administration, REST APIs, DHTMLX 3.5 and Monitoring

## J.1 Three distinct dashboards

- **Inner dashboard:** Business events, outbox, decryption/processing, sync, E-ACK and local worker health.
- **Outer dashboard:** Opaque package custody, mTLS transfers, routing, H-ACK and gateway health.
- **Parent Outer dashboard:** Enterprise routes and *reported* status; no live Inner database or plaintext access.

Every remote status row should include `observation_source`, `generated_at`, `received_at`, `sequence`, and `freshness`. An Inner status report that is stale must be labeled stale even when the corresponding Outer gateway is online.

## J.2 Suggested navigation

```text
Data Exchange
  Dashboard
  Packages / Outgoing / Incoming / Transit / Details
  Transfers / Attempts / Failures
  Acknowledgements / H-ACK / E-ACK / Missing
  Business Events / Published / Processed / Pending
  Synchronization / Versions / Dependencies / Conflicts
  Routing / Sites / Policies / Permissions
  Security / Certificates / Trust / Quarantine
  Workers / Backlog / Recovery
  Alerts / Audit / Configuration
```

## J.3 Operational KPIs

| KPI | Definition | Caveat |
|---|---|---|
| Outbox backlog | Pending eligible outbox rows | Local only |
| Build throughput | Completed verified packages/time | Exclude unfinished claims |
| Transfer duration | Attempt start to verified H-ACK | Transport-specific |
| End-to-end completion | Publish commit to verified E-ACK | Delays include offline handoffs |
| Missing H-ACK | Transfer without authenticated custody confirmation | Not proof receiver failed |
| Missing E-ACK | Source lacks authenticated business result | Not proof business failed |
| Duplicate packages | Same ID and hash seen again | Expected under retries |
| Hash conflicts | Same ID, different bytes | Security incident |
| Sync backlog | Pending version/dependency events | Must be source-attributed |
| Trust freshness | Accepted version and revocation age | Remote data may be stale |

## J.4 Suggested ZF1 REST endpoints

```text
GET  /api/dataexchange/dashboard
GET  /api/dataexchange/packages
GET  /api/dataexchange/package?id=PKG-...
GET  /api/dataexchange/transfers
GET  /api/dataexchange/acks
GET  /api/dataexchange/events
GET  /api/dataexchange/sync
GET  /api/dataexchange/routes
GET  /api/dataexchange/certificates
GET  /api/dataexchange/workers
GET  /api/dataexchange/alerts
GET  /api/dataexchange/audit
POST /api/dataexchange/transfer/retry
POST /api/dataexchange/package/retry
POST /api/dataexchange/event/resume
POST /api/dataexchange/alert/acknowledge
```

Server-side pagination, allowlisted sort columns, bounded filters, authentication, RBAC, CSRF protection for browser mutations, and audit logs are mandatory. A retry endpoint queues an authorized action and returns an operation ID; it does not synchronously perform cryptography in the web request.

## J.5 Example API response

```json
{
  "success": true,
  "total": 2,
  "page": 1,
  "limit": 50,
  "rows": [
    {"package_id": "PKG-50001", "destination_site": "COMPANY_B.INNER", "status": "WAITING_END_TO_END_ACK", "last_confirmed_hop": "COMPANY_B.OUTER"},
    {"package_id": "PKG-50002", "destination_site": "COMPANY_C.INNER", "status": "FAILED", "last_confirmed_hop": "PARENT.OUTER"}
  ]
}
```

## J.6 DHTMLX 3.5 grid example

```javascript
var dxGrid = new dhtmlXGridObject('dxPackageGrid');
dxGrid.setImagePath('/dhtmlx/imgs/');
dxGrid.setHeader('Package ID,Destination,Status,Last Confirmed Hop,Created');
dxGrid.setInitWidths('190,180,170,180,*');
dxGrid.setColAlign('left,left,center,left,left');
dxGrid.setColTypes('ro,ro,ro,ro,ro');
dxGrid.setColSorting('str,str,str,str,str');
dxGrid.init();
// Convert the API's JSON response into the grid's configured data format.
// For large datasets use server-side paging/sorting, not client-side full load.
```

DHTMLX 3.5 requires checking the exact JSON/XML data adapter used by the installed version. Use locally hosted JavaScript and CSS. Apache ECharts may be used for charts after verifying the selected release's browser compatibility and offline asset packaging.

## J.7 Role permissions

```text
dx.dashboard.view
dx.package.view
dx.transfer.view
dx.transfer.retry
dx.event.resume
dx.route.view
dx.route.manage
dx.certificate.view
dx.trust.manage
dx.alert.acknowledge
dx.audit.view
```

Recommended roles: DX Viewer, DX Operator, DX Administrator, DX Security Administrator, DX Auditor, Enterprise DX Administrator. Approval and separation of duties should apply to route/trust changes. Never allow a manual DB status edit to fabricate E-ACK success.

## J.8 Signed site status reports

```json
{
  "report_id": "REPORT-50001",
  "site_id": "COMPANY_B.INNER",
  "sequence": 125,
  "generated_at": "2026-10-14T08:00:00Z",
  "metrics": {
    "pending_outbox": 15,
    "pending_business_events": 4,
    "failed_packages": 2,
    "pending_ack": 8
  }
}
```

Reports travel through approved exchange routes and must be authenticated, versioned and replay-protected. Parent Outer stores the latest *accepted* sequence per site. Display both generated and received timestamps. Do not accept an older report as the current state because it arrived later.

## J.9 Alert catalogue and suggested actions

| Alert | Meaning | Action |
|---|---|---|
| `PACKAGE_STUCK` | Package not advancing within policy | Inspect build/transfer state |
| `HOP_ACK_TIMEOUT` | No authenticated next-hop custody | Check route/transport; retain copy |
| `END_TO_END_ACK_TIMEOUT` | No verified final processing outcome | Investigate; do not mark failed solely by timeout |
| `WORKER_UNRESPONSIVE` | Heartbeat/expected run missing | Inspect service, lease and backlog |
| `CERTIFICATE_EXPIRING` | Credential approaching expiration | Plan approved rotation |
| `TRUST_DIRECTORY_STALE` | Accepted trust state older than policy | Hold sensitive flows if required |
| `PACKAGE_HASH_CONFLICT` | Same package ID, different bytes | Quarantine and escalate security |
| `INVALID_SIGNATURE_DETECTED` | Signature or identity validation failed | Quarantine; preserve evidence |
| `SYNCHRONIZATION_BACKLOG` | Pending versions/dependencies growing | Investigate authoritative stream |
| `DISK_SPACE_LOW` | Durable custody at risk | Stop accepting custody if unsafe |

---

# Appendix K. Operational Runbooks for Offline Sites

## K.1 Package stuck in BUILDING

**Symptoms:** Outbox claimed, no READY package, lease expired.

1. Identify outbox ID, package ID, lease token, worker instance and claim time.
2. Check private `send/building` and `send/ready` for exact package artifact.
3. If READY exists, verify archive, origin signature, hash, and DB linkage; reconcile instead of rebuilding.
4. If only incomplete staging exists, quarantine/delete according to retention policy, then safely reclaim with a new fencing token.
5. Retry build; verify one READY artifact and one package ID.
6. Record audit correlation ID and root cause.

## K.2 Missing Hop ACK

1. Verify the transfer ID, expected receiving hop, transport type and last attempt.
2. Check local package retention and hash; do not delete the only copy.
3. For HTTPS, inspect mTLS identity, timeout and receiver response; for directory, inspect only the approved handoff boundary and local receipt files.
4. Retransmit identical package bytes if retry policy permits.
5. Accept only authenticated H-ACK matching transfer/package/hash/receiver.
6. Escalate prolonged missing custody; do not infer final business failure.

## K.3 Missing E-ACK

1. Confirm source package ID/hash/event ID and expected destination Inner.
2. Inspect verified custody history; do not claim the destination processed it without a signed E-ACK.
3. If safe, retransmit the same immutable package using idempotent transport.
4. At destination, check processed-event identity and durable ACK outbox.
5. Resume ACK dispatch if business commit already occurred.
6. Verify returned signed E-ACK and update per-destination result.

## K.4 Invalid signature / hash conflict

1. Quarantine exact bytes without extraction into public paths.
2. Preserve package ID, hash, verified envelope metadata, time and source evidence.
3. Disable automatic retry for the security-rejected artifact.
4. Notify DX Security Administrator.
5. Check certificate/trust version and known compromise notices.
6. Release only through documented authorized security resolution; never bypass verification.

## K.5 Certificate expiration or revocation

1. Identify certificate ID, usage and affected site.
2. Obtain approved replacement via enterprise security authority.
3. Verify signed trust update independently and install monotonic version.
4. Recheck waiting packages; do not downgrade crypto or accept stale revoked keys silently.
5. Preserve old decryption keys only for approved in-flight recovery windows.
6. Audit update and confirm sites' reported trust versions.

## K.6 Disk full or database outage

1. Stop accepting new custody if durable persistence cannot be guaranteed.
2. Preserve existing immutable package files and sender retention.
3. Restore capacity/database service using approved recovery procedure.
4. Reconcile files with DB rows before restarting workers.
5. Reprocess duplicate-safe claims and ACK queues.
6. Confirm no false H-ACK/E-ACK was issued during outage.

## K.7 Synchronization gap

1. Read entity owner, sync mode, last applied version and pending event IDs.
2. For `ORDERED_CHANGE`, request missing predecessor/replay; do not skip sequence.
3. For `FULL_STATE`, accept later authoritative complete state if contract permits.
4. For dependency failures, wait or request required entity snapshot.
5. Apply and advance version in one transaction.
6. Record business reconciliation result and clear pending event.

---

# Appendix L. Testing Matrix, Failure Injection, and Acceptance Gates

## L.1 PHPUnit structure

```text
tests/DataExchange/
  Unit/PublisherTest.php
  Unit/RouterTest.php
  Unit/ManifestTest.php
  Unit/ValidatorTest.php
  Unit/RetryTest.php
  Unit/RegistryTest.php
  Integration/OutboxTransactionTest.php
  Integration/PackageBuildTest.php
  Integration/PackageReceiveTest.php
  Integration/BusinessProcessingTest.php
  Integration/AckRoundTripTest.php
  Security/SignatureTest.php
  Security/ReplayTest.php
  Security/AuthorizationTest.php
  Security/ArchiveValidationTest.php
  Recovery/BuildCrashTest.php
  Recovery/ReceiveCrashTest.php
  Recovery/AckRecoveryTest.php
```

Choose a PHPUnit release compatible with PHP 7.4; do not assume the latest PHPUnit runs on that runtime. Use disposable MariaDB databases and test-only keys/certificates.

## L.2 Test matrix

| ID | Scenario | Required assertion |
|---|---|---|
| T01 | Publish event | Business row and outbox row commit together |
| T02 | Publish fails | Business update rolled back |
| T03 | Build package | Exact immutable archive validates |
| T04 | Modify ciphertext | Hash/signature/AEAD check rejects |
| T05 | Wrong destination key | Decryption fails; no business effect |
| T06 | Forged signer | Certificate identity/permission rejects |
| T07 | Replay identical package | No duplicate mailbox row |
| T08 | Same package ID, changed bytes | Quarantine and alert |
| T09 | Same event ID in second package | No duplicate business effect |
| T10 | Lost H-ACK | Safe retransmit and custody re-ACK |
| T11 | Lost E-ACK | Original business effect once; ACK recovery |
| T12 | Crash after atomic rename | Recovery reconciles DB/file |
| T13 | Crash after business commit | E-ACK outbox survives |
| T14 | Expired worker lease | Stale worker cannot overwrite newer state |
| T15 | Unsupported schema version | Explicit hold/reject; no guessing |
| T16 | Missing dependency | Durable pending queue; eventual retry |
| T17 | Route loop | Reject max-hop/loop policy |
| T18 | Trust rollback | Lower version rejected |
| T19 | Revoked certificate | Reject/hold under policy |
| T20 | ZIP traversal | No filesystem escape |
| T21 | ZIP bomb | Reject within configured bounds |
| T22 | Unauthorized admin retry | HTTP forbidden and audit recorded |
| T23 | Parent cannot decrypt | No destination Inner private key available |
| T24 | Stale Inner report | Dashboard labels stale, not live |
| T25 | Bcc multi-destination | Each package reveals only permitted recipient subset |

## L.3 Crash injection points

Inject process termination at each of these boundaries:

```text
After outbox insert / before business COMMIT
After claim COMMIT / before build
After ciphertext write / before manifest signing
After archive staging / before atomic rename
After atomic rename / before DB READY update
After receiving bytes / before custody COMMIT
After custody COMMIT / before H-ACK publication
After business update / before processed-event insert
After business COMMIT / before E-ACK signing
After E-ACK signing / before transfer
After receiving verified E-ACK / before local status update
```

Every test should prove either safe rollback or deterministic idempotent recovery. Document the expected durable artifacts and DB rows at each point.

## L.4 Version 1 acceptance gate

Version 1 is acceptable for the **controlled test environment** only when: package crypto uses vetted provider/test vectors; package validator rejects tampering; two simulated Inner instances use separate DBs; Email handler applies once; signed E-ACK round trip works; replay and crash recovery pass; no Outer decryption key exists; logs contain no plaintext or secrets. This is not a production security approval.

---

# Appendix M. Offline Development, Installation, and Deployment Guide

## M.1 Offline environment goals

The Inner environment may have no Internet access. All required dependencies, documentation, certificates, build artifacts and checksums must be prepared through an approved acquisition process, verified, and imported according to enterprise policy. Do not instruct Inner services to call public package repositories at runtime.

## M.2 Proposed source tree

```text
project/
  application/Bootstrap.php
  application/configs/application.ini
  application/configs/dataexchange.ini
  application/modules/email/dataexchange/
  application/modules/crm/dataexchange/
  library/Zend/
  library/S3/DataExchange/Api.php
  library/S3/DataExchange/Publisher.php
  library/S3/DataExchange/Receiver.php
  library/S3/DataExchange/Router.php
  library/S3/DataExchange/Contract/
  library/S3/DataExchange/Package/
  library/S3/DataExchange/Security/
  library/S3/DataExchange/Event/
  library/S3/DataExchange/Queue/
  library/S3/DataExchange/Transport/
  library/S3/DataExchange/Ack/
  library/S3/DataExchange/Sync/
  library/S3/DataExchange/Worker/
  library/S3/DataExchange/Exception/
  scripts/dataexchange/build.php
  scripts/dataexchange/receive.php
  scripts/dataexchange/retry.php
  scripts/dataexchange/recover.php
  tests/DataExchange/
  docs/
```

## M.3 Offline dependency preparation

1. On an approved connected staging system, select **specific supported versions** of every required dependency, including a PHP 7.4-compatible PHPUnit version and a vetted crypto provider.
2. Obtain source/release archives from trusted distributors, verify publisher signatures or authoritative checksums, and record the exact version and license.
3. Run dependency/security review, including transitive dependencies; keep a software bill of materials (SBOM).
4. Prepare a reproducible vendor directory or internal package repository snapshot. Never disable integrity/security checks merely to force an installation.
5. Transfer via the enterprise-approved software import process; this is separate from DX business package routing.
6. Verify file hashes again on the offline host.
7. Run smoke tests and the full unit/integration suite without Internet connectivity.
8. Archive the exact dependency bundle, checksums, configuration template and release notes for repeatable deployments.

## M.4 Example application configuration

```ini
[dataexchange]
enabled = 1
site.id = "COMPANY_A.INNER"
site.role = "INNER"
storage.root = "/var/lib/s3-dataexchange"
database.adapter = "default"
security.require_signature = 1
security.require_encryption = 1
security.check_revocation = 1
transport.directory.enabled = 1
transport.https.enabled = 0
worker.build.batch_size = 20
worker.receive.batch_size = 20
retry.initial_delay = 30
retry.maximum_delay = 3600
```

**Outer role example:** set `site.role = "OUTER"`, enable directory and HTTPS adapters as appropriate, and do not provision business decryption keys or business handlers. Reject contradictory configuration on startup. Keep key locations and secrets out of shared source repositories.

## M.5 MariaDB prerequisites

- Create separate MariaDB schemas for `COMPANY_A.INNER` and `COMPANY_B.INNER` in the test environment.
- Use InnoDB transactions, utf8mb4, unique constraints and appropriate per-worker DB accounts.
- Apply schema with an explicit migration/version log and backup plan.
- Verify time-zone handling (UTC), transaction isolation, and `FOR UPDATE SKIP LOCKED` semantics for MariaDB 10.11.
- Use prepared SQL or `Zend_Db` parameter binding. Run `EXPLAIN` on queue claim, package lookup and dashboard queries under realistic volumes.

## M.6 CLI workers and service supervision

```bash
php scripts/dataexchange/build.php
php scripts/dataexchange/receive.php
php scripts/dataexchange/retry.php
php scripts/dataexchange/recover.php
```

Schedule through cron or systemd, ensuring workers use restricted OS identities and bounded concurrency. A cron worker should report last successful execution; a long-running worker should emit heartbeats. Restart must not imply that an expired lease is proof the previous worker stopped—use fencing.

## M.7 Test environment topology

```text
Test host (simulation only; not production trust isolation)
  A-INNER app + database + private DX storage
     -> controlled copy of immutable .pkg ->
  B-INNER app + separate database + private DX storage
     -> controlled reverse copy of signed E-ACK ->
  A-INNER verification and delivery status
```

Test separate process credentials and directories. Do not mistake two folders on one computer for a security-equivalent production air gap. After direct simulation passes, introduce A.OUTER/B.OUTER gateways, then Parent Outer, then multi-destination routing and sync.

## M.8 Operational backup and restore

- Back up MariaDB consistently with package artifacts and retention metadata.
- Encrypt backups and protect signing/decryption keys under separate approved key-recovery policy.
- Test restoration into a disposable environment; reconcile DB rows with immutable package hashes.
- Ensure restoring old trust-directory state cannot silently roll back revocations.
- After restore, run recovery workers before resuming transfers, and confirm no false acknowledgements are generated.

---

# Appendix N. Implementation Milestones, Open Decisions, and Release Checklist

## N.1 Milestones

| Version / phase | Deliverable | Exit condition |
|---|---|---|
| V1 foundation | DB, registry, publisher, encrypted/signed package, receiver, Email handler, E-ACK, recovery | All direct simulated Inner-to-Inner tests pass |
| V2 local gateways | Directory handoff, Outer custody, HTTPS/mTLS, H-ACK | No Outer decryption; custody/retry tests pass |
| V3 enterprise hub | Parent Outer routing, signed route policy, multi-hop tracking | Full A→Parent→B path and reverse ACK pass |
| V4 fan-out | Multi-destination packages and Email recipient grouping | Independent ACK/retry/Bcc tests pass |
| V5 sync | CRM full-state, ordered events, dependencies, snapshot | Version-gap/conflict tests pass |
| V6 operations | ZF1 REST, DHTMLX monitoring, alerts, audit | Roles and stale-report tests pass |
| V7 security management | Trust rotation, revocation, signed directory, incident playbooks | Key compromise and rollback drills pass |

## N.2 Decisions that still require formal approval

1. Exact DXPP 1.0 canonical manifest encoding and signature input bytes.
2. Exact AES-GCM AAD construction, nonce policy, and attachment encryption framing.
3. Approved key-wrapping suite and provider with verified SHA-256 OAEP/KEM support.
4. ECDSA signature encoding and cryptographic test vectors.
5. X.509 SAN/site identity rules, certificate usage/policies, revocation freshness, and historical-signature acceptance.
6. Trust bootstrap and rollback-resistant highest-version storage.
7. Exact H-ACK durable-custody threshold, file fsync policy and retention duration.
8. Full database migration/foreign-key plan and status state machine definitions.
9. Maximum package, attachment, archive and worker resource limits.
10. Schema compatibility and offline rollout policy across subsidiaries.
11. Site reporting intervals and transport-specific timeout thresholds.
12. Legacy PHP 7.4/ZF1 security exception, support plan and migration target.

## N.3 Engineering definition of done

```text
[ ] All site identities and permissions registered
[ ] Protocol version and canonical encodings frozen
[ ] Crypto provider approved and known-answer tests passed
[ ] Package signature, AEAD, certificate and routing validation enforced
[ ] Transactional outbox shares business DB transaction
[ ] Duplicate package and event tests passed
[ ] Business effects + processed event + ACK outbox committed atomically
[ ] H-ACK issued only after durable custody
[ ] E-ACK signed by destination Inner and verified by original source
[ ] Recovery reconciles files, DB rows and worker leases
[ ] Directory boundary never assumes dongle internals
[ ] Parent and other Outer sites cannot decrypt business payloads
[ ] Admin APIs enforce RBAC, CSRF and audit
[ ] Remote status displays source and freshness
[ ] Offline dependency bundle and SBOM prepared
[ ] PHPUnit, integration, security and crash-injection suites pass
[ ] Backup/restore and incident response rehearsed
[ ] Production security review and release approval recorded
```

## N.4 Terminology index

| Term | Meaning |
|---|---|
| Inner Site | Isolated business application and final encryption/decryption endpoint |
| Outer Site | Network-connected gateway for opaque package transport |
| Parent Outer | Enterprise routing hub; not a business decryption endpoint |
| DXPP | Proposed Data Exchange Package Protocol |
| Outbox | Transactional record of an event to publish |
| Inbox | Durable record of an accepted incoming package |
| H-ACK | Authenticated next-hop durable custody acknowledgement |
| E-ACK | Destination Inner's signed final business-processing outcome |
| CEK | Content encryption key used for AEAD |
| AAD | Additional authenticated data bound to ciphertext |
| Trust directory | Signed versioned registry of site certificates and policies |
| Lease fencing | Prevents stale workers from overwriting newer job state |
| Full-state sync | Event carries authoritative complete entity state |
| Ordered-change sync | Event requires predecessor version(s) |
| Append-only sync | Domain event appended without mutating earlier event identity |

---

# Offline Reading Order and Final Notes

**For architecture review:** Chapters 1–8, then Appendices A–D and I.  
**For database/backend implementation:** Chapters 9–12, then Appendices E–H.  
**For frontend and operations:** Chapters 13–14, then Appendices J–K.  
**For testing and offline rollout:** Chapters 15–17, then Appendices L–N.

This handbook intentionally repeats important invariants in multiple places so an offline developer can read a subsystem chapter without missing its security and transaction requirements. Examples are **reference implementations and design sketches**, not an assertion that a complete runnable DX application is included. The authorized dongle's internal design is intentionally excluded. No Redis or direct Inner↔Outer networking is introduced.
