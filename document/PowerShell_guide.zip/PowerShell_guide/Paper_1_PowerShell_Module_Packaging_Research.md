# Design and Implementation of a Configuration-Driven Module Packaging System Using Windows PowerShell

**Technical research paper — Draft 1.0**  
**Publication series:** Enterprise Software Build and Distribution, Paper 1  
**Scope:** Module and suite packaging; product assembly is addressed in a separate paper  
**Basis:** *PowerShell Module Packaging Script — Requirements Version 4.12* and the supplied `Package-Module(1).ps1` source  
**Status:** Design analysis and proposed evaluation protocol; no empirical performance or successful Windows execution is claimed.

## Abstract

Enterprise applications frequently comprise independently deployable business modules and larger suites of related modules. Manual packaging of these components introduces risks of missing source files, inconsistent configuration, omitted database dependencies, version-history errors, and premature publication of incomplete archives. This paper presents a configuration-driven module packaging design targeting Windows PowerShell 5.1, WinRAR ZIP archives, and a modular PHP application environment. The design supports independent and suite builds, development and production profiles, JSON or Zend Framework 1–compatible INI configuration output, declared source-file ownership, SQL dependencies, developer-maintained release histories, and optional distribution through SMB and Git. A key design property is separation of build preparation from mutation of authoritative configuration: the selected build target's metadata is committed only after archive integrity and content checks pass. We describe the requirements, data model, algorithms, validation boundaries, and a reproducible acceptance-testing methodology. The contribution is a practical, auditable packaging architecture rather than a claim of measured speed or reliability improvement; those claims require execution-based evaluation.

**Keywords:** PowerShell 5.1; modular software; software packaging; configuration-driven build; ZIP verification; software supply chain; JSON; INI; version history; deployment automation.

## 1. Introduction

### 1.1 Problem context

A large application may contain many separately maintained business modules, including future modules that do not yet exist when the packaging tool is written. Some modules are also assembled into suites, with a suite configuration and several child configurations. A developer may need either an individual module archive or one complete suite archive. Repeating these operations manually can result in incomplete releases: source directories may be missed, generated configuration may contain development-only assets, SQL definitions may be absent, or package metadata may be changed before an archive is proven valid.

The proposed system makes the module's configuration the primary declaration of packaging inputs. It aims to avoid module-name-specific branches in the script and to preserve the semantics of source configuration while producing a clean, verifiable distribution artifact.

### 1.2 Research objectives

This paper examines five engineering questions:

1. How can one packaging program support newly introduced modules and suites without hardcoded module names?
2. How can source ownership and development/production filtering be enforced without accidental cross-module effects?
3. How can JSON configuration be transformed into deployable JSON or INI while preserving future configuration sections?
4. How can release metadata, SQL dependencies, and version history be validated without changing source files prematurely?
5. What evidence is required to conclude that an archive is complete and safe to publish?

### 1.3 Contributions and boundaries

The principal contributions are (a) an owner-oriented manifest model; (b) deterministic handling of single-module and suite archives; (c) a staged validation-and-commit workflow; (d) generic history-file discovery; and (e) a concrete evaluation plan. The document analyzes the Version 4.12 specification and available script source. It does **not** claim that every Version 4.12 feature is implemented or has been executed successfully on Windows.

## 2. Background and design constraints

### 2.1 Deployment context

The specified implementation targets **Windows PowerShell 5.1**, with **WinRAR** used to create and test ZIP-format archives. **Git** is a prerequisite even if the optional Git publishing operation is declined. The workspace root is the current packaging workspace, and finished module archives are placed in its `output` directory. Optional SMB and Git publishing are distribution mechanisms, not prerequisites for the archive's correctness.

The packaging system is independent of the later product-assembly script: module packaging produces versioned ZIP files, while product packaging consumes those ZIP files as opaque artifacts.

### 2.2 Why a configuration-driven approach?

Hardcoding filenames such as `draft.json` or `email.json` would require modifying the script whenever the organization introduces another module. Instead, the build discovers `config*.json`, determines whether the selected file represents a module or a suite, and resolves the relevant child configurations through validated metadata. The `source` declaration, not a broad filesystem search, determines which ordinary source files belong to a module.

### 2.3 Design invariants

The design imposes the following invariants:

- **No invented source ownership:** source files come from an owner's explicit `source` declarations.
- **No cross-owner sharing:** two owners may not declare the same source file, including through overlapping directory expansion.
- **No cross-owner exclusion:** a module's production exclusions affect only its own files.
- **No automatic version bump:** `version` is maintained manually.
- **No early metadata commit:** only the selected target's original configuration may be changed, and only after verification.
- **No silent omission:** missing required SQL or history files are fatal.
- **No module-name assumptions:** new module keys must not require editing script conditionals.

## 3. Requirements and domain model

### 3.1 Configuration owners

An **owner** is the module or suite whose configuration governs a set of packaging inputs. A standalone module has one owner. A complete suite build has the suite owner and all referenced child owners. An independent child build has only the selected child as its build target.

| Build mode | Configuration owners represented in archive | Original metadata updated after verification |
|---|---|---|
| Standalone module | Selected module | Selected module only |
| Child built independently | Selected child | Selected child only |
| Complete suite | Suite plus each child | Suite only |

The child configurations in a complete suite retain their existing metadata; they are not silently rebuilt as independent releases.

### 3.2 Input configuration

A configuration is JSON with a top-level `module` or `suite` object. Other top-level sections may include `source`, `tables`, `menus`, `staff`, and future objects or arrays. The specification prohibits arbitrary top-level scalar sections for the generic INI conversion path. `source_exclude_extension` controls filtering during production builds but is removed from packaged configuration output.

**Illustrative module configuration** (simplified, not a complete production schema):

```json
{
  "module": {"key": "customer", "version": "1.2.0", "build_no": 8},
  "source": ["applications/modules/customer/", "public/modules/customer/"],
  "source_exclude_extension": ["ts", "scss"],
  "tables": ["customer", "customer_contact"],
  "settings": {"enabled": true}
}
```

The configuration schema shown above illustrates processing behavior; authoritative field names and any optional fields should be checked against the deployed configuration files.

### 3.3 Build options

The interactive build selects (1) a configuration, (2) a complete suite or a child if a suite was selected, (3) Development or Production, and (4) JSON or INI configuration output. JSON is the authoritative input format. INI is generated from the prepared JSON representation, not copied from an existing INI file.

## 4. Architecture

### 4.1 Logical components

```text
              Workspace configuration files
                          |
                          v
              Discovery and validation
                          |
               Owner/build-mode selection
                          |
                +---------+---------+
                |                   |
                v                   v
       Source ownership       Required artifacts
       and profile filter     SQL + history + config
                |                   |
                +---------+---------+
                          |
                 Staging manifest
                          |
                JSON / INI generation
                          |
                 ZIP creation (WinRAR)
                          |
                Integrity + content checks
                          |
                 Target metadata commit
                          |
                  Optional SMB / Git
```

### 4.2 Separation of concerns

The **discovery layer** identifies valid owners and dependencies. The **manifest layer** constructs an explicit set of archive-relative paths and source paths. The **transformation layer** creates packaged configuration copies. The **archive layer** writes the ZIP. The **verification layer** tests integrity and expected content. Finally, the **commit layer** persists the target's metadata and makes the verified package available for optional publication.

Separating these layers reduces the likelihood that one function's incidental behavior changes an unrelated configuration or module.

### 4.3 Example package layouts

An independent module built in INI mode may produce:

```text
module_customer(1.2.0).zip
  config.ini
  history.json
  applications/modules/customer/...
  public/modules/customer/...
  tables/mysql/customer.sql
  tables/mysql/customer_contact.sql
```

A suite built in JSON mode may produce:

```text
module_docbook(2.1.1).zip
  config.json
  history.json
  docbookcore.json
  history_docbookcore.json
  draft.json
  history_draft.json
  docdist.json
  history_docdist.json
  applications/...
  public/...
  tables/mysql/...
```

These trees are illustrative. Actual archive contents depend on the selected owners' declared files and dependencies.

## 5. Configuration discovery and dynamic suite composition

The tool scans the workspace for `config*.json`. It fails when none exist, auto-selects when exactly one exists, and prompts when several are available. A configuration with `suite` is a suite; one with `module` is a module; configurations with both or neither are invalid.

Suite membership is obtained from the suite's child identifiers, not a fixed list. The child list must be validated for count, ordering, uniqueness, and resolvability. An unresolved design point in Version 4.12 is the **exact key-to-child-filename lookup rule** when a suite refers to a child; a production implementation should document this mapping and reject ambiguous matches rather than guess.

A key distinction is between a **filename identifier** and a **module key**. For example, `config_dockbook.json` may contain a suite key of `docbook`. History-file discovery must respect the actual configuration filename, including this spelling difference.

## 6. Source manifests, exclusions, and ownership

### 6.1 Authoritative source declarations

Each owner has a `source` list containing files or directories. Directory entries expand to actual files, with archive-relative paths preserved. The prepared packaged `source` list should enumerate files actually included. An owner with no source files may use an empty array; a suite without a `source` property must not acquire one during packaging.

### 6.2 Development versus production

A Development build includes declared source files, including developer-facing assets such as `.ts` and `.scss`. A Production build applies that owner's `source_exclude_extension` to its declared source files. Filtering does not delete original files, and the exclusion setting itself is not included in packaged configurations. Required SQL and history artifacts are separately managed and are not silently removed by ordinary source-extension filtering.

### 6.3 Ownership collision algorithm

Ownership validation should occur **before** production filtering, so exclusions cannot conceal duplicate declarations.

```text
for each owner:
    expand every declared source path into concrete relative files
    for each concrete file:
        if file is already claimed by another owner:
            fail with both owner identifiers and the conflicting path
        otherwise record its owner

for each owner:
    apply only that owner's production exclusions
    add remaining files to the staging manifest
```

An overlap such as `applications/modules/` in one owner and `applications/modules/customer/` in another is rejected if the expanded declarations claim the same concrete file. Within-owner duplicate declarations may be deduplicated; this is distinct from forbidden cross-owner sharing.

### 6.4 Security implications

Source paths should be normalized and checked against the workspace boundary. Reject absolute or traversal paths where the schema expects relative paths, and do not permit symlinks or filesystem redirection to escape the intended root. Reserved archive destinations—such as generated `config.json`, `config.ini`, and `history.json`—must not be overwritten by ordinary source entries. These checks help prevent both accidental inclusion and path-based packaging attacks.

## 7. Required database dependencies

The `tables` section identifies required SQL definitions. A table name maps to `tables/mysql/<table>.sql` in the workspace and to the same relative path inside the archive. Missing required files are fatal, rather than producing a ZIP that would fail later during installation.

For a complete suite, the required SQL set is the union of dependencies declared by the suite and its children. Identical SQL dependencies may be referenced by multiple owners; the archive includes each required SQL file once. This is an intentional exception to source-file ownership rules: sharing a database dependency is not equivalent to two owners declaring the same source file.

SQL bytes should be copied without modification and checked against the original during archive verification.

## 8. Configuration serialization

### 8.1 Packaged copy versus authoritative original

The system prepares a **copy** of each owner's configuration for the archive. It removes `source_exclude_extension`, adjusts packaged `source` entries to match included files, and applies the specified build-target metadata to the target copy. It must preserve unknown sections unless an explicit transformation applies. The original JSON retains its complete source declarations and exclusion list.

### 8.2 Generic JSON-to-INI mapping

In INI mode, each top-level object or array is transformed into a section. Nested object properties are flattened with dot-separated keys, and arrays use zero-based indices under the generic conversion rules. Values require escaping appropriate for the consuming INI parser. Future ordinary sections should be handled generically; top-level scalar sections are rejected under the current format contract.

### 8.3 Hierarchical menus

`menus` is a special case. The script traverses menu trees depth-first and creates one numbered INI group for **each leaf node**, independent of its `menutype` value. In a group, level `0` is the leaf, level `1` its parent, and so on. The `children` property is not emitted.

```json
{"menus":[{"name":"Documents","menutype":"class","children":[
  {"name":"Open","menutype":"url","children":[]},
  {"name":"Search","menutype":"custom","children":[]}
]}]}
```

```ini
[menus]
1.0.name = "Open"
1.0.menutype = "url"
1.1.name = "Documents"
1.1.menutype = "class"
2.0.name = "Search"
2.0.menutype = "custom"
2.1.name = "Documents"
2.1.menutype = "class"
```

This structural criterion accommodates future menu types without a script update. An implementation must also validate unusual trees, empty children, and scalar escaping.

## 9. Dynamic release-history management

### 9.1 Motivation and data format

Every build owner has a developer-maintained history JSON file. The history documents release changes independently of `build_no`, which is a build counter rather than a semantic release number.

```json
{
  "module_key": "customer",
  "history": [
    {
      "version": "1.2.0",
      "date": "2026-10-13",
      "changes": ["Illustrative release-note text; replace with actual changes."]
    }
  ]
}
```

The example text is deliberately illustrative. The packaging tool cannot verify the factual accuracy of a human-authored release note.

### 9.2 Discovery without hardcoded module names

| Configuration role and filename | Source history filename | Archive filename |
|---|---|---|
| Root `config.json` | `history.json` | `history.json` |
| Standalone `config_customer.json` | `history_customer.json` | `history.json` |
| Suite `config_dockbook.json` | `history_dockbook.json` | `history.json` |
| Child `draft.json`, key `draft` | `history_draft.json` | `history_draft.json` in suite; `history.json` independently |
| Child `production.json`, key `production` | `history_production.json` | `history_production.json` in suite; `history.json` independently |

For complete suite builds, the suite's history becomes `history.json`, while child histories retain their derived filenames. No original history file is renamed or edited. History is included regardless of whether JSON or INI is selected for configuration output.

### 9.3 Validation

Each history file must be valid UTF-8 JSON with a matching `module_key` and a nonempty, newest-first `history` array. Every entry needs a nonempty version, a valid calendar date in `YYYY-MM-DD` format, and a nonempty list of nonempty change descriptions. The first history version must equal the owner's configured version; versions must be unique and ordered according to the supported numeric dotted scheme. Missing files, invalid JSON, mismatched keys or versions, and archive-name collisions are fatal.

Verification must ensure the expected history file appears **exactly once** in the ZIP and is byte-identical to its source. Historical release descriptions are not generated or rewritten by the script.

## 10. Build metadata and transactional boundaries

### 10.1 Metadata policy

The target's `install_date` is updated, `build_no` is incremented, and configured `build_info` placeholders are resolved. The semantic `version` remains unchanged. In a suite build, only the suite's original configuration is committed; child originals retain their metadata. The design also discusses retaining a `build_info_template` to preserve placeholder templates across builds, which should be distinguished from fields required by the baseline specification.

### 10.2 Staged commit

A safe sequence is:

```text
validate configuration and owner relationships
  -> collect source / SQL / history inputs
  -> validate ownership and histories
  -> prepare target metadata and packaged config copies
  -> stage files and create ZIP
  -> verify archive integrity and expected entries
  -> verify hashes / config semantics / history content
  -> persist selected target's original JSON metadata
  -> finalize archive and optionally publish
```

A failure before the metadata commit must leave authoritative configuration files unchanged. This is a **limited transaction boundary**, not an assertion of full filesystem atomicity: optional SMB and Git publishing and filesystem operations can still fail independently and require their own recovery policy.

## 11. ZIP construction and verification

### 11.1 Deterministic manifest

The manifest should map each expected archive-relative path to one staged source and role (ordinary source, generated config, required SQL, or history). Duplicate archive destinations are errors unless an explicit deduplication rule applies, such as identical required SQL dependencies.

### 11.2 Verification layers

1. **Input validation:** required paths, configurations, SQL, and histories exist and are valid.
2. **Staging validation:** staged bytes match their intended originals or generated representations.
3. **Archive integrity:** WinRAR reports a successful ZIP integrity test.
4. **Manifest completeness:** every expected path exists exactly once, and unexpected entries are rejected under the chosen policy.
5. **Semantic validation:** packaged configuration matches the intended build type and format; histories and SQL dependencies are correct.
6. **Publication gate:** no metadata commit or publication is allowed after a failed mandatory verification step.

A successful integrity test alone is insufficient: a ZIP may be structurally valid while missing an essential SQL file or containing the wrong configuration.

### 11.3 Hashing

SHA-256 digests provide practical byte-level comparison between source and staged or extracted files. They establish equality for the compared bytes but do not prove the origin or trustworthiness of those bytes. Cryptographic signing and provenance attestations are potential future enhancements, not features established by the supplied requirements.

## 12. Distribution through SMB and Git

The optional SMB workflow copies the verified archive to a configured network share and requires secure runtime credential handling; passwords must not be stored in plaintext. The optional Git workflow publishes the archive to a configured repository path, stages only the intended archive, commits it, and pushes the result. Both require path validation, error reporting, and safeguards against publishing incomplete output.

Publishing is deliberately downstream of verification. The module build is conceptually successful only according to a clearly defined success policy; a verified local archive and a failed remote publication should be reported as distinct outcomes rather than conflated.

## 13. Implementation observations and limitations

The supplied `Package-Module(1).ps1` includes functions associated with discovery, source collection, SQL dependency inclusion, INI generation, WinRAR invocation, ZIP-manifest testing, and SMB/Git publishing. That source is useful implementation evidence for the pre-history packaging architecture. **It predates the Version 4.12 history requirements in this paper; therefore history-file support must not be described as demonstrated by that script without an updated source review and execution test.**

The requirements also leave some details open, including suite child-configuration resolution and whether saving JSON must preserve original key order and whitespace. These issues should be resolved before a reproducible implementation is declared complete.

## Detailed Working Algorithm — Module Packaging (Expanded Methodology)

This section specifies an **algorithm derived from Requirements v4.12**, rather than claiming every step is already implemented and runtime-tested. It is applicable to any module or suite; identifiers below are variables, not hardcoded names.

### Algorithm M1 — Inputs, outputs, and invariants

**Inputs:** workspace root `W`; a selected `config*.json`; build scope (single module or complete suite); build mode (Development/Production); output configuration format (JSON/INI); optional SMB and Git publishing choices. **Outputs:** a verified `module_<key>(<version>).zip`, a metadata update to *only* the selected original build-target JSON, and a build report.

**Invariants:** no original source or history file is modified; module `version` never increments automatically; child configuration metadata remains unchanged during a suite build; `source` remains authoritative; no module shares source-file ownership with another; SQL dependencies may be deduplicated; missing dependencies are fatal; the packaged configuration never gains an absent `source` section.

### Algorithm M2 — Discovery and build-plan formation

1. Establish `W` and validate WinRAR, Git, paths, and output permissions. Search for `config*.json`; fail if none, auto-select if exactly one, otherwise prompt.
2. Parse the selected configuration and distinguish `module` from `suite`. For a suite, prompt for a complete suite or a selected child. Resolve child configurations from the suite declaration; never use a fixed module list.
3. Create an **owner set**: the selected module for a single build, or the suite plus all children for a complete suite. Create a separate **metadata-update target**, which is only the selected module or suite original JSON.
4. Validate each owner's key, version, paths, optional `source` and `tables`, and top-level section types. Ask for Development/Production and JSON/INI (JSON default).
5. Build a manifest in memory before changing original files. Reserve archive paths for configuration outputs and history files; reject collisions.

### Algorithm M3 — Source ownership, filtering, and SQL

For each owner, expand its declared `source` entries to concrete, workspace-relative files. Reject path traversal, missing files, and references to reserved package artifacts. Maintain a map `relativePath → owner`. If two distinct owners claim the same file, **fail before applying exclusions**, even if one would exclude it in Production. Duplicate references within one owner can be deduplicated. In Production, apply **only that owner's** `source_exclude_extension`; Development retains all declared source files. Rewrite that owner's *packaged* `source` list to enumerate included files, but only if the original contained `source`. Remove `source_exclude_extension` from packaged copies, not originals.

Independently enumerate `tables` for every applicable owner. For each table identifier, resolve `W/tables/mysql/<table>.sql`; reject unsafe names or missing files. Deduplicate identical SQL archive paths **without treating them as source-ownership conflicts**. SQL inclusion overrides ordinary extension filtering.

### Algorithm M4 — History resolution and validation

Resolve history filenames from the actual configuration filenames: `config.json → history.json`; `config_<id>.json → history_<id>.json`; a suite child `<filename>.json → history_<module.key>.json`. For example, `config_dockbook.json` maps to `history_dockbook.json` even if its suite key is `docbook`. For each owner, validate readable UTF-8 JSON, matching `module_key`, a newest-first `history` array, required `version/date/changes` fields, and the newest version equal to its configured version. Fail on missing, mismatched, or colliding history. A single build writes only the selected history as archive-root `history.json`; a complete suite writes suite history as `history.json` and each child history under its derived name. Do not edit history contents.

### Algorithm M5 — Configuration synthesis and staging

1. Deep-copy each configuration; never construct the packaged copy by whitelisting only known sections. Preserve future sections by default.
2. Prepare `install_date`, incremented `build_no`, and resolved `build_info` **only for the build target**, initially in memory. Preserve `version`; do not update child metadata for a suite build.
3. Remove packaged-only exclusions and adjust packaged source lists as in M3. Validate top-level objects/arrays.
4. For JSON, serialize the prepared objects with correct archive filenames. For INI, recursively flatten ordinary sections; transform `menus` by depth-first traversal, creating one group for **each leaf node regardless of `menutype`**, with the leaf at level 0 and ancestors at levels 1, 2, etc. Preserve arbitrary menu properties except `children` and escape values safely.
5. Stage all source files, SQL files, configurations, and history files in a fresh temporary tree. Verify that each staged file corresponds to exactly one expected archive entry.

### Algorithm M6 — Verification, commit, and optional publication

Create a ZIP with WinRAR in temporary output, test archive integrity, list entries, and compare the list against the manifest. Verify file bytes or digests and parse packaged configurations and histories. Check that the original build-target JSON has not changed since reading it. **Only after verification**, atomically replace the target original JSON with the prepared metadata update, then safely publish the ZIP to its final output path. Optionally upload to SMB and/or stage, commit, and push **only the generated ZIP** in Git; report each publication result independently. If a pre-commit validation fails, original configuration files must remain unchanged. A failure after the metadata commit is a distinct partial-publication state and must be logged rather than described as a fully rolled-back build.

### Algorithm M7 — End-to-end pseudocode

```text
W ← validate_workspace_and_prerequisites()
selected ← select_config(discover("config*.json"))
plan ← resolve_scope_and_owners(selected)       # module OR suite + children
mode, format ← prompt_build_options()
validate_configurations(plan)
manifest ← reserve_config_and_history_paths(plan, format)
claims ← expand_declared_sources_for_each_owner(plan)
reject_cross_owner_duplicates(claims)          # before exclusions
manifest += filter_each_owner_independently(claims, mode)
manifest += collect_and_deduplicate_required_sql(plan)
manifest += discover_and_validate_histories(plan)
staged_configs, metadata_patch ← prepare_configs_and_target_metadata(plan)
manifest += serialize_configs(staged_configs, format)
stage_and_hash(manifest)
temporary_zip ← create_zip_with_winrar(manifest)
verify_zip_and_contents(temporary_zip, manifest)
verify_target_original_unchanged()
atomically_save_target_metadata(metadata_patch)
publish_verified_zip(temporary_zip)
optional_smb_or_git_publication()
report_success_or_precise_partial_failure()
```

### Algorithm M8 — Illustrative failure cases and evaluation hooks

| Condition | Required action | Evidence to record |
|---|---|---|
| Child module history absent or wrong version | Abort before ZIP | Owner, expected history path/version |
| Two owners claim one source file | Abort before exclusions | Conflicting relative path and both owners |
| Required table SQL missing | Abort | Table identifier and expected SQL path |
| Unknown future JSON section | Preserve/convert if valid | Before/after semantic comparison |
| Arbitrary leaf `menutype` | Generate menu group | INI group and ancestor ordering |
| ZIP test or manifest verification fails | Do not update original metadata | WinRAR exit code and manifest diff |
| Git push fails after local publication | Report partial publication | Commit/push results, local artifact path |

A reproducible evaluation should execute these cases on Windows PowerShell 5.1 and record actual pass/fail results, timing, and file hashes. No such results are asserted here.

---

## 14. Evaluation methodology

### 14.1 Test environment to record

A future evaluation should record Windows version, PowerShell version, WinRAR version, Git version, storage type, workspace size, module count, suite composition, archive format, and whether SMB/Git publishing is enabled. Each test should begin from a controlled workspace snapshot and record console output, logs, final archive entries, hashes, and changes to authoritative JSON files.

### 14.2 Functional acceptance matrix

| Test ID | Scenario | Required outcome |
|---|---|---|
| T01 | Exactly one configuration | Automatic selection |
| T02 | Multiple configurations | Validated interactive selection |
| T03 | Development profile with `.ts` / `.scss` | Declared files included |
| T04 | Production profile with exclusions | Only owner-specific excluded files omitted |
| T05 | Two owners declare same file | Build fails before archive creation |
| T06 | Two owners declare overlapping populated directories | Cross-owner conflict detected |
| T07 | Two owners require same SQL | One SQL archive entry |
| T08 | Required SQL missing | Build fails; metadata unchanged |
| T09 | Suite without `source` | No synthetic suite `source` added |
| T10 | New ordinary configuration section | Preserved in JSON and generically converted in INI |
| T11 | Menu leaf with arbitrary `menutype` | One correctly ordered INI group |
| T12 | Independent child history | Packaged once as `history.json` |
| T13 | Complete suite histories | Suite canonical history plus individually named child histories |
| T14 | History version mismatch | Build fails before metadata update |
| T15 | Corrupted ZIP | Archive rejected; no metadata commit |
| T16 | Successful verified suite build | Only suite original metadata updated |
| T17 | Successful verified child build | Only child original metadata updated |
| T18 | Optional Git/SMB failure | Local versus remote status accurately reported |

### 14.3 Quantitative measures

A research evaluation should measure: (i) build duration by phase; (ii) ZIP size; (iii) manifest completeness rate; (iv) number of detected invalid inputs; (v) failure-injection success rate (whether each induced fault is caught); and (vi) metadata preservation under failure. Each measurement should include a sample size, hardware/software context, and repeated-run variation. A comparison with a manual workflow would require a documented baseline and equivalent package requirements.

### 14.4 Results reporting template — not measured data

| Metric | Manual baseline | Automated build | Evidence |
|---|---:|---:|---|
| Median build time (s) | Not measured | Not measured | Timed runs |
| Missing-file incidents / 100 builds | Not measured | Not measured | Manifest audit |
| Correct rejection of injected failures (%) | Not measured | Not measured | Fault-injection log |
| Metadata changes after failed build | Not measured | Not measured | Before/after hashes |

**No numerical outcome should be filled in until the tests have been executed.**

## 15. Discussion

The architecture trades convenience for explicitness: strict source ownership and fatal dependency checks may initially require more accurate configuration maintenance, but they make packaging decisions reviewable. Dynamic module discovery lowers future maintenance cost by reducing the need for module-specific code. The separate treatment of SQL and history artifacts prevents ordinary source filters from accidentally dropping release-critical files. Staging and verification protect authoritative metadata from many failure modes, although they do not make the entire publication workflow fully transactional.

The approach is particularly suited to organizations with a legacy application runtime, offline or restricted-network development, and a need to retain predictable ZIP-based distribution. It is less appropriate where the application requires a richer dependency solver, signed provenance chain, or transactional deployment orchestrator unless those capabilities are added separately.

## 16. Limitations and future work

1. **Implementation gap:** verify that the actual script implements every Version 4.12 history rule; the supplied earlier script is not sufficient evidence.
2. **Child lookup contract:** formalize suite child configuration path and identifier resolution.
3. **Configuration persistence:** decide whether metadata writes must preserve JSON formatting, key order, and original scalar types.
4. **Reproducibility:** investigate stable ZIP entry order, timestamps, and normalization if byte-for-byte reproducible archives are required.
5. **Security:** consider archive signing, provenance records, permission checks, and protected publishing credentials.
6. **Recovery:** define explicit behavior for a verified local build followed by SMB or Git failure.
7. **Automated tests:** implement PowerShell test fixtures and run failure-injection suites on Windows PowerShell 5.1.
8. **Scale:** measure performance as module counts, SQL dependencies, and archive sizes increase.

## 17. Conclusion

A configuration-driven PowerShell packaging system can offer a disciplined route from modular application sources to verified ZIP artifacts. The central engineering ideas are explicit owner manifests, independent build-profile filtering, generic configuration conversion with a narrowly defined menu exception, required SQL and history validation, and delayed commitment of authoritative build metadata. The supplied Version 4.12 specification provides a detailed design contract. Demonstrating its operational benefits requires an updated implementation and measured acceptance tests; the paper therefore presents a design and evaluation framework rather than unsupported claims of production performance.

## References and source basis

### Project primary sources

[P1] *PowerShell Module Packaging Script — Requirements Version 4.12*. Project requirements document, supplied in the working materials, 2026.

[P2] *Package-Module(1).ps1*. Project PowerShell source code, supplied in the working materials, 2026. Source inspection supports discussion of earlier packaging functions but does not establish Version 4.12 runtime compliance.

### Technical references for publication verification

[R1] Microsoft, *about_PowerShell_5.1* and PowerShell language documentation. Official Microsoft Learn documentation; verify exact title and publication metadata before final publication.

[R2] Microsoft, *Get-FileHash* documentation. Official Microsoft Learn documentation; verify version-specific applicability before publication.

[R3] Git Project, *Git Documentation*. Official reference for repository, staging, commits, and push semantics.

[R4] RARLAB, *WinRAR documentation*. Official documentation for archive creation and integrity testing.

[R5] IETF, *RFC 8259: The JavaScript Object Notation (JSON) Data Interchange Format* (2017).

**Editorial note:** The references above are a working bibliography, not a claim that each external document has been independently reviewed in this draft. Confirm bibliographic details and add publication-ready citations before submission.

---

## Mathematical Formalization of the Module Packaging Algorithm

This section formalizes the specified Version 4.12 behavior. Equations describe design constraints and proposed evaluation measures; they do not represent experimental findings.

### M-F1. Module source ownership uniqueness

Let $M$ be the set of module owners in a build and $S_m$ the **expanded, normalized declared source-file set** for owner $m$. For every source file $f$:

$$\tag{M1}\sum_{m\in M}\mathbf{1}[f\in S_m]\leq 1.$$

Here $\mathbf{1}[P]$ is 1 when proposition $P$ is true, and 0 otherwise. This check occurs **before** Production exclusions; excluding a duplicated file does not make an ownership conflict acceptable. SQL dependencies are exempt from this source ownership rule.

### M-F2. Ownership conflict count

$$\tag{M2}C_{\mathrm{ownership}}=\sum_{f\in\cup_{m\in M}S_m}\mathbf{1}\!\left[\sum_{m\in M}\mathbf{1}[f\in S_m]>1\right].$$

A valid build requires $C_{\mathrm{ownership}}=0$. Example: if `application/a.php` is declared by two owners and all other files have one owner, the conflict count is 1, not 2.

### M-F3. Development versus Production source sets

For module $m$, let $E_m$ be the extensions listed in its own `source_exclude_extension` configuration and let $\operatorname{ext}(f)$ return a normalized file extension. Then:

$$\tag{M3}I_m(b)=\begin{cases}S_m,&b=\mathrm{Development},\\\{f\in S_m:\operatorname{ext}(f)\notin E_m\},&b=\mathrm{Production}.\end{cases}$$

Filtering is local to the declaring owner; a suite must not apply one child's exclusion settings to another child's files.

### M-F4. SQL dependency closure and deduplication

Let $T_m$ be the declared SQL table identifiers for module $m$, and $\operatorname{sql}(t)$ map a table identifier to `tables/mysql/<name>.sql`. The required SQL archive set is:

$$\tag{M4}Q=\bigcup_{m\in M}\{\operatorname{sql}(t):t\in T_m\}.$$

Every $q\in Q$ must exist before building. Set union permits a shared SQL dependency to appear once in a suite ZIP even when several owners declare it.

### M-F5. History and configured-version consistency

For each owner $m$, let $v_m$ be its configured version, $k_m$ its module key, $h_m$ its history document, and $h_m[0]$ its newest entry:

$$\tag{M5}\operatorname{ValidHistory}(m)\iff (h_m.\mathrm{module\_key}=k_m)\land(|h_m.\mathrm{history}|\geq1)\land(h_m[0].\mathrm{version}=v_m).$$

JSON syntax, date, changes-array, and remaining-entry validation are additional conditions. For discovery, `config.json` uses `history.json`; other configuration filenames use `history_<module_key>.json`, **derived from the configuration's key rather than its filename**. Thus `config_dockbook.json` can correctly map to `history_docbook.json`.

### M-F6. Manifest-to-archive content consistency

Let $R$ be the complete required set of staged files (filtered sources, required SQL, generated configuration, and histories), and $A$ the actual archive entry set after normalizing paths:

$$\tag{M6}R\subseteq A\quad\land\quad A\cap F=\varnothing,$$

where $F$ denotes explicitly forbidden entries, including excluded Production files and temporary build artifacts. Stronger builds may enforce $A=R$ when no extra packaged files are permitted. ZIP structural verification is required separately; set membership alone does not prove byte integrity.

### M-F7. Verified-build commit condition

Let $V_{\mathrm{config}}$, $V_{\mathrm{sources}}$, $V_{\mathrm{history}}$, $V_{\mathrm{zip}}$, and $V_{\mathrm{contents}}$ be Boolean validation results. Define:

$$\tag{M7}V_{\mathrm{build}}=V_{\mathrm{config}}\land V_{\mathrm{sources}}\land V_{\mathrm{history}}\land V_{\mathrm{zip}}\land V_{\mathrm{contents}}.$$

Only if $V_{\mathrm{build}}=\mathrm{true}$ may the selected target's source configuration metadata be committed. For a successful commit:

$$\tag{M8}\mathrm{build\_no}_{\mathrm{after}}=\mathrm{build\_no}_{\mathrm{before}}+1,\qquad \mathrm{version}_{\mathrm{after}}=\mathrm{version}_{\mathrm{before}}.$$

`install_date` and resolved `build_info` are updated as specified; child configurations in a suite remain unchanged.

### M-F8. Packaging time and reliability evaluation

For $n$ matched test builds, manual duration $t_i^{(m)}$ and automated duration $t_i^{(a)}$ yield:

$$\tag{M9}\overline{\Delta t}=\frac{1}{n}\sum_{i=1}^{n}\left(t_i^{(m)}-t_i^{(a)}\right).$$

A relative reduction in **mean** duration is:

$$\tag{M10}R_t=100\left(1-\frac{\overline{t}^{(a)}}{\overline{t}^{(m)}}\right)\%,\quad \overline{t}^{(m)}>0.$$

For $N$ attempted builds and $N_v$ verified builds, the observed verified-build rate is:

$$\tag{M11}\widehat{p}_{\mathrm{verified}}=\frac{N_v}{N}.$$

These metrics must be populated using actual logs; no performance improvement is asserted here.

### M-F9. Algorithmic cost (design-level bound)

Let $F$ be the number of expanded source declarations, $D$ the number of SQL dependencies, $H$ the number of history entries inspected, and $B$ the total bytes written/read for archive construction and verification. With hash-based ownership and dependency sets, a useful **expected** planning bound is:

$$\tag{M12}T_{\mathrm{build}}=O(F+D+H+B),$$

assuming constant expected-time set operations and sequential byte processing. Filesystem traversal, compression characteristics, and Git/SMB latency can change observed time; this is not a measured benchmark.


---

## Appendix A. Reviewer checklist

- Are all implementation claims tied to inspected code or test evidence?
- Does the manuscript distinguish configured `version` from incremented `build_no`?
- Are suite metadata updates limited to the suite owner?
- Are history files validated independently for every owner?
- Is the `config_dockbook.json` filename preserved as written?
- Does the paper avoid treating example module names as hardcoded requirements?
- Are performance results left unreported until measured?
- Are all screenshots, log excerpts, and release notes authentic and approved for publication?

## Appendix B. Suggested publication figures

1. Owner/manifest and ZIP staging architecture.
2. Complete suite versus independent child packaging flow.
3. Menu-tree to INI-group conversion example.
4. Build validation and metadata-commit state machine.
5. Failure-injection test results chart (to be created only after testing).
