# Design and Implementation of a Configuration-Driven Product Generation System Using Windows PowerShell

**Subtitle:** Dependency Resolution, Installation Configuration Synthesis, and Verified Assembly of Modular Enterprise Software  
**Publication series:** PowerShell-Based Modular Enterprise Software Packaging — Paper 2  
**Manuscript status:** Technical research draft; architecture and evaluation protocol, not a claim of measured implementation results  
**Technical basis:** ZF1 Product Packaging Script Requirements v1.3; example `product_uppererp.json`, `install.json`, and `install.ini` from the supplied project archive  
**Target environment:** Windows PowerShell 5.1, WinRAR ZIP output, modular PHP/ZF1 applications

## Abstract

Modular enterprise applications require a repeatable method for assembling independently distributed software modules into deployable products. Manual assembly creates risks of selecting outdated dependencies, generating inconsistent installation configurations, overwriting critical files, and distributing incomplete archives. This paper presents the specification and design of a configuration-driven product generation workflow orchestrated by Windows PowerShell 5.1. The proposed system reads product manifests, selects the highest available version of each required module ZIP by numeric comparison, copies and verifies selected packages, synthesizes installation INI files, copies declared product sources, and builds a verified product ZIP. Safety measures include exact module-key matching, checksum comparison, deferred cleanup of obsolete packages, destination containment checks, and protection of generated configuration files from later source-copy operations. The paper separates requirements established by the project specification from implementation recommendations and from empirical outcomes that have not yet been measured. An acceptance-testing protocol and reproducible evaluation framework are provided to support later validation in a controlled Windows environment.

**Keywords:** Windows PowerShell, software packaging, modular applications, product assembly, dependency resolution, ZIP verification, JSON-to-INI transformation, build automation, software supply chain.

## 1. Introduction

### 1.1 Problem context

A modular business application may consist of a common framework, application files, and multiple independently packaged business modules. Different products may require different module sets and versions. Even when individual module archives are correct, manually constructing a final product can introduce several classes of error: selecting the wrong version, copying packages to the wrong directory, leaving obsolete packages in place, referencing a missing archive in an installer configuration, or accidentally including earlier product builds inside a new archive.

The studied workflow addresses the **product assembly** stage. It is distinct from the companion **module packaging** stage discussed in Paper 1. Module packaging creates independent module ZIPs; product generation consumes those ZIPs as inputs and assembles a deployable product.

### 1.2 Research objectives

The paper examines how a script-driven system can:

1. Express product assembly using declarative JSON configuration rather than fixed module names.
2. Resolve versioned module ZIPs reliably and preserve exact package identities.
3. Generate installation INI files that reference the packages actually selected.
4. Protect verified packages and generated configuration from destructive operations.
5. Construct a complete, verifiable final product archive.
6. Define acceptance tests that distinguish specified behavior from demonstrated performance.

### 1.3 Scope and evidence

The primary source is **Product Packaging Requirements v1.3**. Its examples establish intended data structures and processing rules, but do not establish that `Package-Product.ps1` has been implemented or tested. Accordingly, algorithm sketches and diagrams below are design descriptions, not evidence of a running implementation. Any performance figures in the evaluation section are fields to be measured, not invented results.

## 2. Technical background and constraints

### 2.1 Packaging hierarchy

The workflow has two artifact levels:

```text
Module source/configuration
         |
         v
  Module packaging system
         |
         v
Versioned module ZIP repository
         |
         v
Product packaging system <--- product_*.json
         |               <--- installation JSON files
         v
 Verified product ZIP
```

The product script must treat module archives as opaque package artifacts. In particular, a module ZIP's embedded history information should remain unchanged when the ZIP is copied into the product; the product stage does not rewrite module history or internal module configuration.

### 2.2 Platform constraints

The specified implementation targets **Windows PowerShell 5.1** and requires WinRAR to create and test ZIP archives. Git must be discoverable according to the existing prerequisite policy, although product Git publishing is **not** defined. The specification also prohibits storing SMB passwords in plaintext but does not define a product SMB upload workflow. These distinctions matter: a prerequisite does not imply an additional publication feature.

### 2.3 Configuration as a contract

The product manifest contains a `product` object and `source` and `module_config` arrays. Installation JSON files contain a `modules` **object**, whose keys are dynamic module identifiers. The script must therefore iterate over the current configuration rather than hardcode names such as `email` or `chat`.

## 3. Requirements and data model

### 3.1 Product metadata

The product configuration supplies at least `product_key`, `product_version`, `php_version`, and `zipfile_path`. The output filename is constructed as:

```text
<product_key>(<product_version>)_<php_version>.zip
```

For example, the supplied illustrative values yield `Uppererp(2.0)_php7.4.zip`. Filename components must be validated against invalid Windows characters and path traversal.

### 3.2 Installation configurations

Each entry in `module_config` maps a source installation JSON file to a destination INI file:

```json
{
  "module_config": [
    {
      "src": "C:/source/media/modules/apps/install.json",
      "des": "C:/des/media/modules/apps/install.ini"
    }
  ]
}
```

*Illustrative paths above demonstrate the structure; real paths must pass containment validation.* Multiple entries are processed independently; the script cannot assume there is only one root-level installation configuration.

### 3.3 Module entry schema

An installation JSON `modules` object may resemble:

```json
{
  "modules": {
    "email": {
      "name": "Email",
      "module_key": "module_email",
      "module_src_dir": "C:/repo/modules",
      "module_des_dir": "C:/des/media/modules/apps",
      "icon": "email.png",
      "enabled": true
    }
  }
}
```

The keys `email`, `chat`, or any future identifiers are data, not script constants. `module_key` identifies the ZIP filename prefix. `module_src_dir` and `module_des_dir` are packaging-time paths and must not leak into the generated runtime INI.

### 3.4 Product source mappings

Each `source` entry defines `src` and `des`. A file mapping copies a file; a directory mapping copies the **contents** of its source directory into the destination directory while preserving the internal relative tree. Existing destination files are overwritten automatically, subject to the protection rules described later.

## 4. Proposed system architecture

### 4.1 Functional components

```text
+-------------------------+
| Product config discovery|
+------------+------------+
             |
             v
+-------------------------+
| Validation / path guard |
+------------+------------+
             |
             v
+-------------------------+
| Installation JSON reader|
+------------+------------+
             |
             v
+-------------------------+
| Module version resolver  |
+------------+------------+
             |
             v
+-------------------------+
| Copy / hash / ZIP test  |
+------------+------------+
             |
             v
+-------------------------+
| INI generation/validation|
+------------+------------+
             |
             v
+-------------------------+
| Source conflict preflight|
+------------+------------+
             |
             v
+-------------------------+
| Product source copy      |
+------------+------------+
             |
             v
+-------------------------+
| ZIP assembly/verification|
+------------+------------+
             |
             v
+-------------------------+
| Final archive publication|
+-------------------------+
```

The order is intentional. The generated INI must refer to packages already resolved and verified. Source copying occurs **after** INI generation, but must be preflighted so it cannot overwrite generated INI files or restore installation JSON files removed by the generation step.

### 4.2 Separation of responsibility

The resolver selects module artifacts; the copier transports and checks them; the INI writer synthesizes runtime metadata; the source copier merges product-owned files; and the archive builder publishes a verified snapshot. Keeping these responsibilities separate makes errors easier to localize and tests easier to construct.

## 5. Configuration discovery and validation

The script searches the workspace for `product_*.json`. No matches are fatal; multiple matches require a user selection. The v1.3 specification does not require automatic selection when exactly one file exists. After selection, the script parses JSON and validates required fields without changing the original manifest.

Validation should be completed before destructive operations whenever possible. In particular, every generated INI destination and module package destination intended for inclusion must be within the canonical `product.zipfile_path` root. A string-prefix test is insufficient: `C:\des2` is not inside `C:\des`. Path checks should normalize paths and require a directory-boundary-aware comparison. Symbolic links or junctions, if present, require additional containment safeguards.

## 6. Module dependency resolution

### 6.1 Exact identity matching

For module key `module_email`, eligible filenames have the form:

```text
module_email(<version>).zip
```

The resolver must not confuse `module_email` with `module_emailplus`. Matching should anchor the entire filename and escape metacharacters in the module key before constructing a regular expression.

### 6.2 Numeric version comparison

Lexicographic comparison produces incorrect ordering for versions such as `2.4.7` and `2.4.10`. The specified policy accepts dotted numeric components and compares them numerically. An unsupported version format is an error unless a future policy defines it.

**Design pseudocode:**

```text
candidates = files in module_src_dir matching exact module_key(version).zip
if candidates is empty: fail
for each candidate:
    parse version as numeric dotted components
    if malformed: fail under the agreed policy
selected = candidate with greatest numeric version
```

A production implementation should also define how to handle equivalent versions with different textual spellings (for example `1.2` versus `1.2.0`) and ties, since the specification does not yet settle these cases.

### 6.3 Latest available is not always compatible

Selecting the highest version is the current requirement, **not a compatibility solver**. The system does not currently define dependency ranges, module-to-module constraints, or compatibility checks between product and module releases. These are legitimate future research directions, not existing guarantees.

## 7. Safe module copy and cleanup

The selected module ZIP is copied to `module_des_dir`, potentially replacing a file of the same name. The script then verifies the destination against the source, preferably with SHA-256, and tests ZIP integrity with WinRAR. Only **after both checks succeed** may it delete older ZIP files matching the same exact module key. Files belonging to other modules must remain untouched.

This sequence enforces a limited safety property: a failed copy or failed verification must not cause deletion of the pre-existing module packages. It is **not** a full transaction: if an earlier module was replaced successfully and a later operation fails, the current requirements do not guarantee rollback of all earlier changes.

A useful implementation improvement would be copying into a temporary sibling filename, verifying it, and atomically renaming where supported. Such staging reduces exposure to partially written destination files, but the v1.3 requirement only mandates verification before obsolete-package cleanup.

## 8. Installation INI synthesis

### 8.1 Why a specialized transformation is required

The example installation JSON contains a `modules` object; the output INI does not contain a literal `[modules]` section. Instead, each child property becomes an INI section. This is a semantic transformation, not generic JSON flattening.

For the sample `email` entry, the output is:

```ini
[email]
name = "Email"
module = "module_email(2.4.10).zip"
icon = "email.png"
enabled = true
```

The filename is illustrative: a real build must use the **actual** highest-version archive selected at runtime. The output omits `module_key`, `module_src_dir`, and `module_des_dir`. If the input contains a stale `module` value, it is replaced by the selected filename.

### 8.2 Future module properties

New scalar module properties (strings, numbers, booleans) must be preserved with their original keys. Unsupported nested objects or arrays within a module entry must produce a clear error, not silent data loss. Additional unknown top-level installation sections have **no agreed conversion rule**; the script should reject them until their mapping is specified. This limitation should be reported explicitly rather than claiming unrestricted future-schema compatibility.

### 8.3 Framework mapping and serialization

The example `framework` object becomes `[framework]` with scalar key-value pairs. The serializer must safely quote and escape values containing quotes, backslashes, and line breaks in accordance with the parser used by the target ZF1 installation environment. Round-trip tests are advisable: generate INI, parse it with the target runtime, and compare expected values.

### 8.4 Deleting destination installation JSON

After an `install.ini` is written and verified, an `install.json` in that **destination directory** may be removed. The source JSON must never be deleted. The generated INI path and the removed destination JSON path become protected outputs for the subsequent source-copy phase.

## 9. Source integration and conflict protection

### 9.1 Overwrite policy

Ordinary product source mappings overwrite existing destination files without prompting. This simplifies repeatable builds but increases the importance of input validation, backups, and accurate logs.

### 9.2 Protected output paths

Before copying, the script expands directory mappings into effective destination file paths and compares them with the protected paths established by INI generation. If any mapping would overwrite a generated INI or reintroduce a removed destination `install.json`, the script must fail **before source copying begins**. Silent skipping is not permitted, because it would conceal a manifest conflict.

For example:

```text
Generated: C:/des/media/modules/apps/install.ini
Source map: C:/src/media/modules/apps/ -> C:/des/media/modules/apps/
Conflict:  C:/src/media/modules/apps/install.ini would overwrite generated INI
Result:    Reject mapping before copying
```

This rule resolves the otherwise hazardous interaction between the required processing order and broad directory-copy operations.

### 9.3 Path and file-system hazards

Relative-path traversal, invalid paths, unexpected reparse points, and source/destination overlap should be checked. A directory copied into its own descendant can recursively expand unless explicitly rejected. These are implementation hardening considerations; the source specification expressly requires safe path handling and destination containment.

## 10. Final product ZIP construction

The product staging root is `product.zipfile_path`. After successful module resolution, INI generation, and source copying, the script archives its contents while excluding **existing product ZIPs** and temporary build files. Selected **module ZIPs must remain included**. A blanket `*.zip` exclusion would therefore violate the requirement.

The new product ZIP is built in a temporary directory **outside** the staging root, preserving paths relative to that root. After WinRAR integrity testing and expected-entry verification, the verified ZIP is moved into the staging root using the product filename. An existing final ZIP of that name must not be replaced before the new archive is verified.

Example resulting layout:

```text
C:/des/
  application/
  public/
  media/modules/apps/
    install.ini
    module_email(2.4.10).zip
  Uppererp(2.0)_php7.4.zip   <-- final output, excluded from its own contents
```

The exclusion policy for historical product ZIP names and temporary file patterns remains an **open specification detail**. A configurable, explicit pattern set is safer than broad extension exclusions.

## 11. Reliability, integrity, and security considerations

### 11.1 Layered verification

Three distinct questions should be answered: (1) Did the selected module file copy correctly? (2) Is the copied ZIP structurally readable? (3) Does the final product ZIP contain all required entries with correct paths? SHA-256 comparison addresses the first, archive testing the second, and manifest checks the third. None of these checks alone establishes that the software is free of malicious content or functionally compatible.

### 11.2 Failure boundaries

The specified system stops on missing inputs, malformed versions, failed copies, INI-generation errors, unsafe paths, and archive failures. It does not guarantee global rollback after all possible partial modifications. Logs must therefore record which changes completed before failure.

### 11.3 Supply-chain trust

Checksums detect accidental or unauthorized modification **relative to a trusted source**, but copying a compromised source ZIP and verifying its identical hash does not establish authenticity. Future versions could add signed manifests, trusted publishers, or provenance attestations. These are proposed improvements, not present requirements.

### 11.4 Logging and confidential data

The build log should record selected product config, module versions, file copy/overwrite operations, hash and archive checks, INI destinations, deleted obsolete packages, excluded files, and final archive path. Credentials and sensitive configuration values should not be logged. The requirement explicitly disallows storing SMB passwords in plaintext, although product SMB publishing is not specified.

## Detailed Working Algorithm — Product Generation (Expanded Methodology)

This section operationalizes **Product Packaging Requirements v1.3**. It is a specification-derived algorithm, not a claim that a production `Package-Product.ps1` has been executed or benchmarked.

### Algorithm P1 — Inputs, outputs, and invariants

**Inputs:** workspace, selected `product_*.json`, its `product`, `module_config`, and `source` entries, referenced installation JSON files, and existing module ZIP repositories. **Output:** `<product_key>(<product_version>)_<php_version>.zip` in `product.zipfile_path` and a traceable build log.

**Invariants:** the original JSON files remain unchanged; the highest available *valid numeric-dotted* module version is chosen for each exact module key; destination module ZIPs are deleted only after verified replacement; source copying may overwrite ordinary files but cannot overwrite generated INIs or recreate deleted destination installation JSON; all packaged outputs lie inside the product staging root; the final archive never includes itself or historical product archives.

### Algorithm P2 — Product selection and preflight

1. Confirm Windows PowerShell 5.1, WinRAR, Git, and required filesystem access. Discover `product_*.json`; prompt for selection when necessary.
2. Parse the chosen product configuration. Validate `product_key`, `product_version`, `php_version`, and `zipfile_path`; construct the output filename safely.
3. Validate each `module_config` entry (`src` installation JSON and `des` generated INI), and each product `source` mapping (`src` and `des`). Resolve paths canonically and reject traversal.
4. Read **each** referenced installation JSON independently. Its `modules` value is an **object** keyed by dynamic module names, not a fixed list or positional array.
5. Verify that every generated INI and module destination intended for the product lies under `product.zipfile_path`. Compute all source-copy destinations in advance; reject any mapping that would overwrite generated INIs or reintroduce destination `install.json` files slated for deletion.

### Algorithm P3 — Exact-key module resolution

For each installation JSON and each property under `modules`, read `module_key`, `module_src_dir`, and `module_des_dir`. Search only ZIP basenames of the form `<exact module_key>(<numeric dotted version>).zip`; do not confuse `module_email` with `module_emailplus`. Parse version components as integers and compare component by component, not as strings. For example, `2.4.10` outranks `2.4.7`. A missing matching package or invalid required version is a fatal error. Record the chosen ZIP basename for later INI synthesis. Where multiple installation configurations reference the same destination/module key, require a consistent selected package and reject contradictory mappings rather than silently overwriting decisions.

### Algorithm P4 — Verified module replacement

For each selected package: validate source archive integrity; copy it to `module_des_dir`, overwriting the same-named destination if present; verify SHA-256 equality and ZIP integrity at the destination. **Only after these checks succeed**, delete older ZIPs matching the same *exact* module key in that destination. Do not delete packages of other module keys. If copying or verification fails, leave existing module packages in place and stop. If cleanup fails, report a failed build rather than pretending success. Record every copy, hash, and deletion.

### Algorithm P5 — Installation INI synthesis

For each `module_config` entry, convert its source installation JSON into the destination INI using the project-specific mapping. Serialize `framework` scalar fields under `[framework]`. For every dynamic child property of `modules`, emit `[childName]`, copy `name` and optional `icon`, and emit `module = "<selected ZIP basename>"`; omit packaging-only `module_key`, `module_src_dir`, and `module_des_dir`. Preserve additional **scalar** module properties unless they are reserved; escape INI strings. Unknown non-scalar module properties or unagreed additional top-level sections must fail explicitly rather than be silently dropped. Write and verify the INI, then remove an existing **destination** `install.json` only after verification; never delete the original `module_config.src` JSON.

### Algorithm P6 — Product source integration

Before copying, expand each declared file or directory mapping into effective destination file paths. Copy the **contents** of a source directory into the destination directory, preserving relative subpaths; overwrite ordinary destination files automatically and log overwrites. Reject protected-output conflicts *before* starting the copy. Missing sources or copy failures are fatal. The current specification does **not** promise full rollback of already overwritten ordinary files; log partial changes clearly.

### Algorithm P7 — Product ZIP creation and publication

Enumerate the staging root `product.zipfile_path` after module replacement, INI synthesis, and product source copying. Include all intended files, **including module ZIPs**, but exclude historical product ZIPs and temporary build files by explicit, documented patterns; do not exclude all `*.zip`. Build the product archive in a temporary location **outside** the staging root, preserving relative paths. Test the ZIP with WinRAR, verify its manifest and required generated INIs/module ZIPs, then move it to the final destination. Replace a previous final product ZIP only after the new ZIP has been fully verified. Report all errors and output paths.

### Algorithm P8 — End-to-end pseudocode

```text
check_powershell_winrar_git_and_paths()
product ← select_product(discover("product_*.json"))
validate_product_metadata_and_output_name(product)
install_specs ← read_all_module_config_sources(product.module_config)
validate_destinations_inside_product_root(install_specs, product.zipfile_path)
protected_paths ← plan_generated_ini_and_removed_install_json_paths(install_specs)
copy_plan ← expand_product_source_mappings(product.source)
reject_copy_conflicts(copy_plan, protected_paths)
resolved ← resolve_highest_exact_key_module_versions(install_specs)
for each selected module package in resolved:
    copy_and_verify_module_zip()
    delete_older_exact_key_zips_only_after_verification()
for each installation specification in install_specs:
    ini ← synthesize_ini_with_selected_module_filenames()
    write_and_verify_ini(ini)
    delete_destination_install_json_if_present()
copy_declared_product_sources_with_overwrite(copy_plan)
manifest ← enumerate_product_root_excluding_product_zips_and_temp_files()
temporary_zip ← create_zip_outside_product_root(manifest)
verify_zip_integrity_and_expected_entries(temporary_zip)
replace_final_product_zip_only_after_verification()
write_build_log_and_result()
```

### Algorithm P9 — Worked dependency-resolution example

Assume installation JSON contains module entry `email` with `module_key = module_email` and a repository holding `module_email(2.4.7).zip`, `module_email(2.4.10).zip`, and `module_emailplus(9.0.0).zip`. The exact-key filter discards `module_emailplus`; numeric comparison selects `module_email(2.4.10).zip`. After copy, hash check, and archive test, the generated INI contains:

```ini
[email]
name = "Email"
module = "module_email(2.4.10).zip"
```

The example illustrates the algorithm, not a measured build result. The source installation JSON remains unchanged. The final product ZIP includes the selected module ZIP as a nested archive entry.

### Algorithm P10 — Failure-state matrix

| Failure | Expected behavior | Audit evidence |
|---|---|---|
| No valid module ZIP for an exact key | Stop before module copy | Key, searched directory, candidate list |
| Selected module ZIP corrupt | Keep existing module packages | WinRAR test result |
| Copy hash differs | Do not delete older versions | Source/destination SHA-256 |
| INI generation fails | Keep destination `install.json` | Parser/serializer error |
| Source copy targets generated INI | Reject before copying | Conflicting destination path |
| Generated INI lies outside staging root | Reject before build | Canonical destination and root |
| Final archive test fails | Preserve previous product ZIP | ZIP test and manifest comparison |
| Earlier ordinary source overwrite succeeds, later copy fails | Stop and log partial changes; no full rollback promised | Overwritten-file log |

To support an academic evaluation, measure module-resolution accuracy, integrity-test pass rate, conflict-detection rate, archive completeness, and elapsed time across repeatable fixtures. These metrics require real execution data before publication as findings.

---

## 12. Evaluation methodology

### 12.1 Experimental environment

A reproducible test report should record Windows version, PowerShell version, WinRAR version, filesystem type, number of modules, number and size of source files, number of installation configurations, and disk type. Tests should use isolated temporary directories and known fixtures.

### 12.2 Functional acceptance matrix

| Test ID | Scenario | Expected outcome |
|---|---|---|
| P01 | Several `product_*.json` files | User chooses product |
| P02 | No product configuration | Clear failure |
| P03 | Versions `2.4.7` and `2.4.10` | Select `2.4.10` |
| P04 | Keys `module_email` and `module_emailplus` | No cross-match or cross-deletion |
| P05 | Selected module missing | Abort |
| P06 | Copy fails or hash differs | Preserve previous module packages |
| P07 | Verified new module package | Delete only obsolete same-key ZIPs |
| P08 | New module entry added | Generate its INI section dynamically |
| P09 | Extra scalar module property | Preserve property in INI |
| P10 | Nested unsupported module property | Clear failure |
| P11 | INI successfully verified | Remove destination `install.json`, not source |
| P12 | Source mapping targets generated INI | Reject before source copy |
| P13 | Source mapping restores removed `install.json` | Reject before source copy |
| P14 | INI or module destination outside staging root | Reject before modifications |
| P15 | Existing product ZIP in staging root | Exclude from new archive |
| P16 | Required module ZIP in staging root | Include in new archive |
| P17 | Final ZIP verification fails | Preserve prior final product ZIP |
| P18 | Multiple `module_config` entries | Process each independently |

### 12.3 Quantitative metrics

Suggested measurements include end-to-end build duration, time spent in module resolution and archive testing, total bytes copied, final ZIP size, failure-detection latency, and number of incorrect entries found by manifest validation. A manual-versus-automated comparison should use identical input fixtures and clearly document operator steps and repetitions.

### 12.4 Results template (no results asserted)

| Metric | Manual baseline | Scripted workflow | Measurement status |
|---|---:|---:|---|
| Median build time (seconds) | TBD | TBD | Not measured |
| Wrong-version selections (count) | TBD | TBD | Not measured |
| Configuration mismatches (count) | TBD | TBD | Not measured |
| Failed builds detected before publication (%) | TBD | TBD | Not measured |
| Repeated-build archive consistency | TBD | TBD | Not measured |

No numerical performance improvement should be published until tests have been executed and evidence retained.

## 13. Discussion

The design shifts repetitive product assembly decisions into validated configuration data. Dynamic module sections reduce code changes when modules are added or removed, while numeric version comparison reduces a common filename-sorting error. Explicit source mappings and protected generated outputs define which files may be overwritten and which must remain authoritative.

A significant tradeoff is the requirement to select the **highest available version** rather than a version proven compatible with the product. Another is that the current workflow modifies the staging directory incrementally and does not promise full rollback. These constraints should guide operational controls and future design iterations.

The architecture also separates **package production** from **package consumption**. Module packaging is responsible for producing trustworthy, self-contained module ZIPs; product generation is responsible for selecting, integrating, and referencing them correctly. This separation supports independent release cadences but makes artifact identity and provenance increasingly important.

## 14. Limitations and future research

The v1.3 requirements leave several questions unresolved:

1. Whether previous product ZIPs remain in the output directory after publication.
2. How unknown top-level installation JSON sections or nested module properties should be serialized.
3. Whether the build should support full rollback of already-overwritten destination files.
4. Exact exclusion patterns for temporary files and historical product archives.
5. Whether destination installation JSON files outside explicitly generated INI locations should be removed.
6. How to resolve equal or nonstandard version representations and inter-module compatibility constraints.

Potential improvements include isolated immutable staging directories, atomic publication, dependency constraints, signed module manifests, reproducible ZIP metadata, dry-run previews, and automated continuous-integration tests. These proposals are outside the currently agreed requirements unless separately adopted.

## 15. Conclusion

This paper presents a configuration-driven design for assembling modular enterprise software products using Windows PowerShell 5.1. The specified workflow discovers product manifests, resolves highest-version module ZIPs, verifies copied artifacts, generates installation INI files, integrates product source files, and publishes a verified product ZIP. Its most important safeguards are exact module identity matching, numeric version comparison, deferred obsolete-package cleanup, protected generated configuration, and destination-root containment. The design provides a structured foundation for repeatable product packaging; claims about reliability gains or time savings must await implementation tests and recorded measurements.

## References and source basis

### Project primary sources

1. **ZF1 Product Packaging Script — Requirements v1.3.** Internal project specification, supplied in the conversation.
2. **`zf1-s3-product.zip`.** Project example archive containing `script_requirement.md`, `product_uppererp.json`, and illustrative installation JSON/INI files; source basis for the requirements.
3. **Design and Implementation of a Configuration-Driven Module Packaging System Using Windows PowerShell.** Companion research draft (Paper 1), supplied in the conversation.

### Technical references to verify during publication editing

4. Microsoft Learn. *about_PowerShell_5.1* and Windows PowerShell scripting documentation. Official platform documentation.
5. Microsoft Learn. *ConvertFrom-Json* and filesystem cmdlet documentation. Official platform documentation.
6. Microsoft Learn. *Get-FileHash*. Official PowerShell documentation.
7. RARLAB. *WinRAR command-line documentation*. Vendor documentation for ZIP creation and integrity testing.
8. IETF. *RFC 8259: The JavaScript Object Notation (JSON) Data Interchange Format*.
9. NIST. *FIPS 180-4: Secure Hash Standard (SHS)*. Background on SHA-256.

*Editorial note: Confirm exact reference editions, titles, access dates, and URLs before formal publication. No external reference verification was performed for this draft.*

## Mathematical Formalization of the Product Generation Algorithm

The following models describe the Product Packaging Requirements v1.3. They express specified correctness rules and candidate measurements, not verified execution results.

### P-F1. Numeric module-version ordering

Represent a dotted version as a vector of nonnegative integers, $v=(v_1,\ldots,v_r)$; pad missing trailing components with zeros for comparison. For two versions $a$ and $b$, numeric lexicographic ordering is:

$$\tag{P1}a>_{\mathrm{num}}b\iff\exists j:\left(\forall i<j,\ a_i=b_i\right)\land(a_j>b_j).$$

For example, $(2,4,10)>_{\mathrm{num}}(2,4,7)$, unlike a naive string comparison. Nonconforming filenames must be rejected or handled according to an explicitly documented version grammar.

### P-F2. Highest eligible module selection

Let $A_k$ be the set of ZIP artifacts whose **exact** module key is $k$, whose filename version is parseable, and whose eligibility checks pass. Then:

$$\tag{P2}z_k^*=\operatorname*{arg\,max}_{z\in A_k}\operatorname{version}(z).$$

The build must fail for a required module when $A_k=\varnothing$. Any product-level compatibility constraints must be included in eligibility before taking the maximum. The v1.3 requirement is to choose the highest valid available version; a general dependency solver is not assumed.

### P-F3. Required module completeness

Let $K$ be the set of required module keys and $Z$ the set of selected ZIPs. A complete selection satisfies:

$$\tag{P3}\forall k\in K,\quad \left|\{z\in Z:\operatorname{key}(z)=k\}\right|=1.$$

This rules out missing required modules and multiple selected versions of the same module.

### P-F4. Byte-for-byte copy integrity

For a selected source module ZIP $z$ and copied destination ZIP $c(z)$, let $H$ be SHA-256:

$$\tag{P4}H(z)=H(c(z)).$$

Hash equality is a practical integrity check against accidental transfer changes; it does **not** authenticate the producer without a separately trusted signature or provenance mechanism. WinRAR ZIP integrity verification remains an independent gate.

### P-F5. Safe cleanup of obsolete versions

Let $D_k$ be the preexisting destination ZIPs for exact module key $k$, and $z_k^*$ the verified new selection. Cleanup eligibility is:

$$\tag{P5}\operatorname{CleanupAllowed}(k)=V_{\mathrm{copy}}(z_k^*)\land V_{\mathrm{hash}}(z_k^*)\land V_{\mathrm{zip}}(z_k^*).$$

Only after this predicate is true may older matching ZIPs be removed. Unrelated module keys and the selected ZIP are excluded from deletion. This predicate is a necessary safety condition, not a guarantee of atomic filesystem operations.

### P-F6. Installer-to-package consistency

Let $\operatorname{iniFile}(k)$ denote the module filename referenced by the generated INI for key $k$, and $\operatorname{archiveFiles}(P)$ the paths in the final product archive $P$:

$$\tag{P6}\forall k\in K,\quad \operatorname{iniFile}(k)=\operatorname{name}(z_k^*)\land \operatorname{path}(z_k^*)\in\operatorname{archiveFiles}(P).$$

The generated INI must reference the selected artifact exactly, and that artifact must be included in the product ZIP.

### P-F7. Destination containment and protected paths

Let $R$ be the canonical staging root, $\operatorname{canon}(p)$ the normalized resolved destination path, and $G$ the protected generated-file set (including generated INIs). Every copied product source must satisfy:

$$\tag{P7}\operatorname{canon}(p)\in\operatorname{Descendants}(R)\quad\land\quad\operatorname{canon}(p)\notin G.$$

Implementations must reject path traversal, absolute-path escapes, and any configured copy that would overwrite a protected generated INI or reintroduce a removed installation JSON file.

### P-F8. Final archive exclusion rule

Let $S$ be the set of staged files, $O$ prior product ZIPs, and $T$ temporary build artifacts. The expected archive content set is:

$$\tag{P8}A_{\mathrm{product}}=S\setminus(O\cup T).$$

Selected module ZIPs remain included even though prior *product* ZIPs are excluded. The final ZIP is built outside staging, verified, and moved into its final location only on success.

### P-F9. Product verification gate

Let $V_i$ denote successful validation of configuration, selected modules, copied hashes, generated INI, protected paths, ZIP integrity, and final content membership. Product promotion requires:

$$\tag{P9}V_{\mathrm{product}}=\bigwedge_{i=1}^{7}V_i=\mathrm{true}.$$

Failure at any gate must prevent publication of the candidate as a verified product.

### P-F10. Product assembly evaluation metrics

For $n$ comparable manual/automated product builds, define average time savings:

$$\tag{P10}\overline{\Delta t}=\frac{1}{n}\sum_{i=1}^{n}(t_i^{(m)}-t_i^{(a)}).$$

For $N$ controlled fault-injection cases and $N_d$ cases correctly detected before publication, observed fault-detection coverage is:

$$\tag{P11}\widehat{C}_{\mathrm{fault}}=\frac{N_d}{N},\qquad N>0.$$

Report fault classes, test conditions, and raw counts with the result; the equation alone is not evidence of reliability.

### P-F11. Version-selection computational cost

If the repository contains $Z$ candidate ZIP filenames, $K$ requested module keys, and filename parsing plus lookup use hash-indexed module buckets, a linear scan can identify each bucket's numeric maximum in expected time:

$$\tag{P12}T_{\mathrm{selection}}=O(Z+K).$$

This bound concerns selection logic only; hashing, copying, ZIP compression, filesystem traversal, and WinRAR verification add costs proportional to the relevant bytes and environment.


---

## Appendix A. Proposed implementation function map

```text
Find-ProductConfigurations
Read-ProductManifest
Assert-ContainedDestination
Read-InstallManifest
Find-LatestModuleZip
Copy-AndVerifyModuleZip
Remove-ObsoleteModuleZips
Convert-InstallJsonToIni
Assert-ProtectedSourceMappings
Copy-ProductSources
Build-ProductZip
Test-ProductZip
Publish-VerifiedProductZip
Write-BuildLog
```

These are suggested function boundaries, **not** claims about functions already present in an implementation.

## Appendix B. Publication-ready figure suggestions

- **Figure 1:** Relationship between module ZIP generation and product assembly.
- **Figure 2:** Product build pipeline with preflight validation and verification gates.
- **Figure 3:** Dynamic `modules` JSON-to-INI transformation.
- **Figure 4:** Safe module replacement sequence and failure paths.
- **Figure 5:** Final product staging directory and ZIP inclusion/exclusion boundary.

## Appendix C. Reviewer checklist

- [ ] Every claim about implemented behavior is backed by source inspection or execution evidence.
- [ ] Every quantitative result has a documented test environment and raw measurements.
- [ ] Installation JSON examples use dynamically named module sections.
- [ ] Numeric version selection and exact-key matching are tested.
- [ ] Source-copy conflicts with generated INI and removed JSON are tested.
- [ ] Destination paths are checked against the canonical product staging root.
- [ ] Module ZIPs remain included when old product ZIPs are excluded.
- [ ] The manuscript distinguishes current requirements from proposed enhancements.
