# Intermediate Web Development — Course Syllabus

**75 lectures, 15 parts.** Concept-oriented notes for intermediate developers. Each chapter includes context, architecture, working principles, practical teaching fragment, trade-offs, activities, review Q&A, and references.

## Part 1: Modern Web Application Architecture

- Lecture 1.1: Traditional vs. Modern Web Applications
- Lecture 1.2: Monolithic and Modular Architecture
- Lecture 1.3: Layered Architecture and Separation of Concerns
- Lecture 1.4: Dependency Injection and Inversion of Control
- Lecture 1.5: Event-Driven Architecture
- Lecture 1.6: Clean Architecture and Hexagonal Architecture

## Part 2: Caching and Redis

- Lecture 2.1: Introduction to Caching
- Lecture 2.2: Redis Fundamentals and Architecture
- Lecture 2.3: Redis Data Structures
- Lecture 2.4: Redis for Session Management
- Lecture 2.5: Redis for Application Caching
- Lecture 2.6: Cache Invalidation and Performance Considerations

## Part 3: Real-Time Communication

- Lecture 3.1: HTTP Polling and Long Polling
- Lecture 3.2: WebSocket Technology
- Lecture 3.3: Server-Sent Events
- Lecture 3.4: WebSocket Servers: Workerman and Node.js
- Lecture 3.5: Designing Real-Time Notification Systems

## Part 4: Message Queues and Background Processing

- Lecture 4.1: Synchronous vs. Asynchronous Processing
- Lecture 4.2: Introduction to Message Queues
- Lecture 4.3: RabbitMQ Fundamentals
- Lecture 4.4: Background Workers and Job Processing
- Lecture 4.5: Retry Mechanisms, Dead-Letter Queues, and Reliability

## Part 5: Modern APIs and Integration

- Lecture 5.1: REST API Design Principles
- Lecture 5.2: API Versioning and Documentation
- Lecture 5.3: OpenAPI and Swagger
- Lecture 5.4: GraphQL Fundamentals
- Lecture 5.5: gRPC and Modern Service Communication

## Part 6: Authentication and Authorization

- Lecture 6.1: Sessions, Cookies, and Tokens
- Lecture 6.2: JSON Web Tokens
- Lecture 6.3: OAuth 2.0
- Lecture 6.4: OpenID Connect and Single Sign-On
- Lecture 6.5: Role-Based and Attribute-Based Access Control

## Part 7: Modern Web Security

- Lecture 7.1: OWASP Top 10 and Common Web Vulnerabilities
- Lecture 7.2: SQL Injection, XSS, and CSRF
- Lecture 7.3: HTTPS, TLS, and Certificate Fundamentals
- Lecture 7.4: Content Security Policy and Security Headers
- Lecture 7.5: API Security and Rate Limiting
- Lecture 7.6: Secure Development and Dependency Management

## Part 8: Database Performance and Optimization

- Lecture 8.1: Understanding Database Performance
- Lecture 8.2: Database Indexing Strategies
- Lecture 8.3: Query Optimization and EXPLAIN
- Lecture 8.4: Transactions, Locking, and Isolation
- Lecture 8.5: Replication, Connection Pooling, and Scaling

## Part 9: Containerization and Deployment

- Lecture 9.1: Virtual Machines vs. Containers
- Lecture 9.2: Docker Fundamentals
- Lecture 9.3: Docker Images, Containers, and Volumes
- Lecture 9.4: Docker Compose
- Lecture 9.5: Introduction to Kubernetes

## Part 10: Microservices and Distributed Systems

- Lecture 10.1: Introduction to Microservices
- Lecture 10.2: Monolith vs. Microservices
- Lecture 10.3: API Gateway and Service Discovery
- Lecture 10.4: Distributed Transactions and Eventual Consistency
- Lecture 10.5: Reliability, Circuit Breakers, and Service Resilience

## Part 11: Modern Frontend Technologies

- Lecture 11.1: Single-Page Applications
- Lecture 11.2: React, Vue, and Angular
- Lecture 11.3: TypeScript in Modern Frontend Development
- Lecture 11.4: Frontend State Management
- Lecture 11.5: Modern Build Tools and Progressive Web Applications

## Part 12: Monitoring, Logging, and Observability

- Lecture 12.1: Application Logging
- Lecture 12.2: Metrics and Monitoring
- Lecture 12.3: Prometheus and Grafana
- Lecture 12.4: Distributed Tracing and OpenTelemetry

## Part 13: Automated Testing and Code Quality

- Lecture 13.1: Unit, Integration, and End-to-End Testing
- Lecture 13.2: PHPUnit and JavaScript Testing
- Lecture 13.3: Static Analysis and Code Quality
- Lecture 13.4: Test Automation and Continuous Testing

## Part 14: CI-CD and Development Automation

- Lecture 14.1: Continuous Integration and Continuous Delivery
- Lecture 14.2: Git-Based Development Workflows
- Lecture 14.3: Automated Build Pipelines
- Lecture 14.4: Deployment Strategies and Rollback

## Part 15: Emerging Web Technologies

- Lecture 15.1: WebAssembly
- Lecture 15.2: Web Components
- Lecture 15.3: Edge Computing and Serverless Architecture
- Lecture 15.4: AI-Assisted Web Development
- Lecture 15.5: Retrieval-Augmented Generation and AI Integration

