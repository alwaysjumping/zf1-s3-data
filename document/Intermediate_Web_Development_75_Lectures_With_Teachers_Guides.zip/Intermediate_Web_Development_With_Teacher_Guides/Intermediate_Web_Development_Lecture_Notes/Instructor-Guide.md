# Instructor Guide

## Lesson rhythm (90 minutes)

1. 10 minutes: real-world problem and legacy baseline.
2. 15 minutes: background and core concepts.
3. 15 minutes: architecture and data-flow walkthrough.
4. 20 minutes: demonstrate the example and discuss error handling.
5. 20 minutes: learner activities and comparison exercise.
6. 10 minutes: review Q&A and a decision memo.

## Learning assessment

For each lecture ask students to explain: what the technology is, why it exists, which components communicate, how failure is handled, what the trade-offs are, and when not to use it. Grade the architecture sketch, lab observation, and short decision memo.

## Lab environment

Use a disposable local PHP + MariaDB employee directory as the running scenario. Optional labs can use Redis, Workerman, RabbitMQ, Docker, PHPUnit, and Grafana when preinstalled. Keep all demo data synthetic. For offline teaching, package installers, dependencies, and manuals ahead of time. Verify licenses and platform support.

## Suggested capstone

Teams propose a staged modernization of an employee portal: baseline measurements, caching decision, real-time notification strategy, job processing, API contract, security checklist, monitoring, tests, and deployment/rollback plan. Require an explicit justification for technologies **not** adopted.
