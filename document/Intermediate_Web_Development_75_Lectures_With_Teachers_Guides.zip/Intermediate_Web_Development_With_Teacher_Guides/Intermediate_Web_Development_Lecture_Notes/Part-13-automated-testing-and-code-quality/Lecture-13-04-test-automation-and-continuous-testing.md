# Part A — Student Lecture Notes

# Lecture 13.04 — Test Automation and Continuous Testing

**Course:** Intermediate Web Development: Modern Architecture, Security and Performance  
**Part:** 13 — Automated Testing and Code Quality  
**Audience:** Developers comfortable with HTML, CSS, JavaScript, PHP, SQL and HTTP  
**Duration:** 75–90 minutes (45 min concepts, 20 min demo, 15–25 min discussion/lab)

## 1. Introduction

**Test Automation and Continuous Testing** is a way of thinking about and implementing a specific engineering capability. In this lesson, we focus on **pipeline stages, quality gates and flaky-test triage**. The purpose is not to memorize configuration options: it is to understand the problem, the major components, the data flow, and the trade-offs well enough to make a sensible technology choice.

**Realistic example:** Release repeatedly misses regressions. This will be our running example, connected to an internal employee-management web application.

## 2. Background: why developers needed this

Traditional PHP applications often combine browser requests, business logic, database access, and optional integrations in one request/response path. This is convenient and remains appropriate for many workloads. Problems appear when one responsibility grows: pages become slow, dependencies fail, many clients require the same information, or developers cannot safely change one feature without affecting another.

**The problem in this lecture:** Release repeatedly misses regressions. A team can sometimes fix the symptom with a small local improvement. Other times a new component or architectural pattern provides a cleaner solution. The key is to identify the bottleneck or coupling before introducing infrastructure.

## 3. Problem statement and success criteria

The team wants to **run fast tests on each change and broader tests before release**. Success is not merely “the tool is installed.” Success means that users see a meaningful improvement, the behavior remains correct when a component fails, and another developer can operate and test the solution.

Suggested success checks:

- **Correctness:** results are accurate and access restrictions are enforced.
- **Performance:** measure response time, throughput, or resource use when relevant.
- **Reliability:** failures have bounded timeouts and a documented recovery path.
- **Maintainability:** interfaces and ownership are clear.
- **Security:** credentials and sensitive data are protected, with least-privilege access.

## 4. Core concepts

- **Pipeline stages** — Explain its role in the workflow and distinguish it from nearby concepts.
- **Quality gates and flaky-test triage** — Explain its role in the workflow and distinguish it from nearby concepts.

**Important distinction:** a technology and an architecture are not the same thing. A technology is a concrete implementation; an architecture defines component responsibilities and communication. A project can adopt the underlying pattern without adopting the most popular product.

## 5. Architecture: where the pieces fit

```text
Employee / Admin Browser
          |
          | HTTPS request or event stream
          v
Web Server / API Boundary
          |
          v
PHP Application (validation + authorization + business rules)
          |
          +----> MariaDB (durable business records)
          |
          +----> Optional supporting component
                  (cache, queue, worker, identity provider, etc.)
```

For **Test Automation and Continuous Testing**, label the optional component using these concepts: **pipeline stages, quality gates and flaky-test triage**. Ask which component is the source of truth, which can fail independently, and which communicates synchronously versus asynchronously. The diagram is a teaching model; not every lecture requires every component.

## 6. How it works — step by step

1. Identify the need: release repeatedly misses regressions.
2. Select the appropriate boundary and components: pipeline stages, quality gates and flaky-test triage.
3. Implement a small slice: run fast tests on each change and broader tests before release.
4. Add validation, authentication/authorization where applicable, error reporting, and safe defaults.
5. Test normal operation, a missing dependency, an invalid request, and recovery.
6. Measure whether the added complexity actually improves the original requirement.

**Failure walkthrough:** Imagine that the supporting component stops responding. Should the user see an error, receive stale data, wait for a retry, or continue with reduced functionality? The answer depends on whether the feature is essential, whether the operation is safe to retry, and whether the application can reconstruct state from durable storage.

## 7. Practical demonstration

The following is a **focused teaching fragment** for the technology family. It is not a complete deployable application and may require local packages, database tables or surrounding classes. Its purpose is to illustrate the central idea before students build a fuller integration.

```php
<?php
use PHPUnit\Framework\TestCase;
final class PriceCalculatorTest extends TestCase {
    public function testTotal(): void {
        $quantity = 3;
        $unitPrice = 200;
        $this->assertSame(600, $quantity * $unitPrice);
    }
}
// Choose a PHPUnit version compatible with the local PHP runtime.
```

**Lab task:** Add a boundary case, a failure case and a database integration test.

**Integration checklist:** determine configuration values; define error behavior; choose timeouts; protect secrets; add basic logging; and write a small test. For an offline classroom, download/install dependencies and documentation in advance.

## 8. Comparison with the traditional approach

| Question | Traditional/simple solution | Modern/alternative approach |
|---|---|---|
| Initial setup | Few moving parts | May need a service, package or additional convention |
| Team learning | Familiar code path | New terminology and operational skills |
| Main benefit | Simplicity and direct debugging | Better fit for the particular bottleneck or requirement |
| Failure modes | Often one application boundary | More dependencies, state transitions or coordination |
| Best fit | Small, stable, predictable workloads | Growing scale, richer interactions or explicit constraints |

**Specific decision for this lecture:** Run fast tests on each change and broader tests before release. But avoid adopting it if the cost of running and maintaining the additional approach exceeds the measured benefit.

## 9. Advantages and limitations

**Potential advantages:** improved separation of concerns, responsiveness, reuse, resilience or operational visibility, depending on the technology. In this scenario, the desired improvement is to **run fast tests on each change and broader tests before release**.

**Main limitation:** Poor test quality blocks delivery. Additional concerns include onboarding, version compatibility, monitoring, security patching and backup/recovery where applicable. No technology removes the need to understand its failure modes.

## 10. When to use it — and when not to

**Consider it when:** the scenario recurs, you can describe a measurable problem, your team can operate the new component, and a proof of concept shows improvement.

**Avoid or postpone it when:** the existing solution is already reliable, the benefit is speculative, the runtime is unsupported, or the operational overhead would be greater than the problem itself.

**Adoption sequence:** baseline → small prototype → functional tests → failure test → performance/security review → staged rollout → monitoring.

## 11. Security and operations

- Authenticate at the appropriate trust boundary and authorize each protected operation.
- Validate all external input; do not assume internal traffic is trustworthy.
- Keep passwords, tokens and private keys out of logs and repositories.
- Establish resource limits, timeouts and retry budgets to avoid cascading failure.
- Record actionable errors and metrics; do not log full sensitive payloads.
- Document backup and recovery for durable state; caches and queues have different guarantees.

## 12. Student activities

**Activity A — Concept map (10 min):** Define the terms from Section 4 and draw their relationships.

**Activity B — Architecture review (10 min):** Draw the actual request path for the employee-management scenario. Mark data ownership and failure points.

**Activity C — Lab (20 min):** Perform the demonstration in Section 7. Change one input, test an error, and record the observed behavior.

**Activity D — Decision memo (10 min):** Write five sentences: problem, existing approach, proposed approach, expected benefit, and principal risk.

## 13. Review questions with suggested answers

1. **What motivates this topic?** — Release repeatedly misses regressions.
2. **What is the proposed improvement?** — Run fast tests on each change and broader tests before release.
3. **What are the key concepts?** — pipeline stages, quality gates and flaky-test triage.
4. **What is a principal limitation?** — Poor test quality blocks delivery.
5. **Should a team always use this technology?** — No. Choose it only when requirements and measured benefits justify the additional cost.
6. **What should a production trial include?** — Validation, access control, failure testing, observability and a rollback plan.

## 14. Summary

- Start with the user or operational problem, not the product name.
- Understand the components and the data flow before writing integration code.
- Keep the authoritative business data and access-control decisions clearly defined.
- Test degraded operation and recovery, not only the happy path.
- Make adoption a reasoned engineering decision.

## 15. References and further reading

- MDN JavaScript (https://developer.mozilla.org/en-US/docs/Web/JavaScript)
- MDN Web Docs: https://developer.mozilla.org/
- PHP Manual: https://www.php.net/manual/en/

**Instructor note:** This chapter is intended for intermediate conceptual learning. It does not replace product-specific production documentation. PHP 7.4 is end-of-life; use a supported PHP version for new production systems. Verify library/runtime compatibility before running examples.

---

# Part B — Teacher's Guide: Test Automation and Continuous Testing

> **Instructor-only preparation.** Part A above remains the original student handout. This guide explains background, operating models, demonstrations, troubleshooting, and teaching strategies. The code lab is a small working illustration of the *part-level concept*; it is not necessarily a complete implementation of **Test Automation and Continuous Testing**.

## TG1. Detailed technology overview and historical motivation

**Topic:** Test Automation and Continuous Testing. This lesson belongs to **testing and quality**. Earlier web systems frequently used a direct browser → PHP → SQL → response path. That is still a valid design. New technologies arise when that path has an identifiable bottleneck, interaction requirement, reliability issue, or organizational coordination problem. They are not automatically better for every application.

**Lesson-specific situation:** Release repeatedly misses regressions. This will be our running example, connected to an internal employee-management web application.

**The specific problem to explain:** Release repeatedly misses regressions. A team can sometimes fix the symptom with a small local improvement. Other times a new component or architectural pattern provides a cleaner solution. The key is to identify the bottleneck or coupling before introducing infrastructure.

Before class, ask yourself three questions: (1) What observable symptom motivates the change? (2) Which component is responsible? (3) How will we measure whether the change helps? Do not begin by showing installation commands. Begin by explaining a real user-facing problem.

**Technical clarification:** The right implementation depends on workload, operational constraints, team experience, and how failures are handled. A new abstraction changes where complexity lives; it rarely removes complexity entirely.

## TG2. Technical foundations: terminology the teacher should know

For this topic, review these concepts: **assertion, fixture, test double, regression, deterministic result, and coverage**. The original student lecture identifies these specific terms: Pipeline stages — Explain its role in the workflow and distinguish it from nearby concepts.; Quality gates and flaky-test triage — Explain its role in the workflow and distinguish it from nearby concepts..

A useful teaching distinction is between a *concept*, a *protocol*, a *product*, and a *library*. For example, caching is a concept, Redis is a product implementing multiple data operations, TCP is a transport protocol, and a PHP Redis client is a library. A design decision about one does not automatically decide the others.

**Data ownership:** Identify the authoritative source of business records. Copies, projections, cached values, event messages, and browser state are not automatically authoritative. Explain how information becomes stale, how errors are reported, and what must happen if the optional component disappears.

**Execution context:** Mark which operations run inside the HTTP request, which run in a long-lived service or worker, and which happen in the browser. A process that serves thousands of connections has different resource and lifecycle concerns from a PHP script that ends after a request.

## TG3. Architecture and internal operation

```text
code -> test runner -> assertions -> report
```

Explain the diagram in this order:

1. **Entry point:** Where does the request, event, or scheduled action originate?
2. **Boundary:** What network, process, module, or trust boundary is crossed?
3. **State:** Which component holds the current value? Is it persistent or ephemeral?
4. **Result:** What is returned to the caller, and when?
5. **Failure:** If the middle component is unavailable, does the system fail closed, retry, queue work, or use a safe fallback?

**Internal reasoning:** The right implementation depends on workload, operational constraints, team experience, and how failures are handled. A new abstraction changes where complexity lives; it rarely removes complexity entirely.

Do not conflate a successful network response with a completed business operation. For example, an HTTP 202 response can mean a job was accepted for processing, not that an email was sent. Similarly, a cache hit says only that a key exists, not that the underlying business data is current or authorized for the caller.

## TG4. Step-by-step working principles

**Normal path:**

1. A user or service requests the feature illustrated by **Test Automation and Continuous Testing**.
2. The application validates inputs and checks any required permissions.
3. The relevant component handles the operation according to the architecture above.
4. The application converts the result into a stable contract (HTML, JSON, event, or job status).
5. Logging or metrics record the outcome without storing secrets.

**Failure path:**

1. Repeat the same operation with an invalid value or a deliberately unavailable dependency.
2. Observe the exception, timeout, rejected message, missing key, or other failure signal.
3. Explain what users should see and whether retry is safe.
4. Verify that partial results do not silently violate permissions or data integrity.
5. Explain recovery and how to tell that normal operation has resumed.

**Teaching checkpoint:** Ask students to point to the step that would change if the team removed the technology. Their answer reveals whether they understand its architectural role.

## TG5. Problems solved, real-world cases, and adoption decisions

**Case study:** Release repeatedly misses regressions. This will be our running example, connected to an internal employee-management web application. The organization should start with a baseline: response time, error rate, request frequency, or developer effort. Then build a minimal implementation and compare it with the existing approach.

**When to consider it:** The problem repeats frequently, a measurable improvement is possible, and the team can maintain the additional dependency.

**When to postpone it:** The existing implementation meets service goals, the workload is small, or adding a service increases failure modes more than it improves performance or usability.

**Comparison:** The conventional direct PHP/database approach is simple to deploy and debug. A testing and quality approach can offer more suitable capabilities but requires explicit configuration, observability, security review, and an operational owner. Explain the trade-off with an example rather than labeling one architecture as universally modern or superior.

## TG6. Practical classroom demonstration

**What this demonstrates:** A runnable foundation for **testing and quality**. For technology-specific behavior that requires an external service, prepare the service separately and do not misrepresent the simulation as a full product integration.

```php
<?php
function total(int $price, int $quantity): int { return $price * $quantity; }
function assertSameValue($expected, $actual): void {
    if ($expected !== $actual) { throw new RuntimeException('Assertion failed'); }
}
assertSameValue(30, total(10, 3));
echo "All assertions passed\n";
```

**Preparation and execution:** Run `php demo.php`; change expected result to 31 and observe failure. Later replace this custom assertion with PHPUnit.

**Teacher walkthrough:**

1. Predict the expected output with students before running the code.
2. Identify where the behavior corresponding to **Test Automation and Continuous Testing** would attach to this foundation.
3. Change one input and repeat.
4. Introduce one error or dependency failure and discuss safe handling.
5. Compare this simple demonstration with what a production installation would additionally need.

**Optional product-specific demonstration:** Introduce a bug into a small function, observe a failing test, fix it, and rerun the suite.

**Troubleshooting:** If a command is missing, check runtime installation and PATH. If a service is unreachable, check whether it is running, its bind address and port, firewall restrictions, credentials, and logs. If a result is unexpectedly unchanged, inspect cache, browser state, transaction state, or deployment version before assuming the code did not run.

## TG7. Advantages, limitations, and security

**Advantages:** Better alignment between a real requirement and an implementation technique; potential improvement in responsiveness, maintainability, scale, or reliability when measured and correctly operated.

**Limitations:** Added dependencies, new failure modes, version compatibility, more complicated debugging, and potential infrastructure cost. Not every use case needs a separate server or framework.

**Security checklist:**

- Identify trusted and untrusted callers, and enforce authorization on the server.
- Use TLS where network traffic or credentials need protection.
- Do not embed passwords, signing keys, or production tokens in lecture repositories.
- Validate inputs and encode outputs for the destination context.
- Limit resource usage and bound timeouts/retries to prevent cascading failures.
- Log failures with correlation identifiers, but redact sensitive payloads.
- Define patching, dependency review, and backup/recovery where state is durable.

**Compatibility:** PHP 7.4 is no longer supported upstream. Keep the legacy examples for teaching only; prefer supported runtimes for new deployments. Confirm library and browser compatibility before classroom installation.

## TG8. Student questions and model answers

**Q1. Why not keep the traditional implementation?**  
A. Keep it if it satisfies correctness, performance, and maintainability goals. Introduce this approach only for a specific, measurable need.

**Q2. Is Test Automation and Continuous Testing a product that we must install?**  
A. Not necessarily. Distinguish the underlying concept from any named product or library. Some lectures describe a pattern, protocol, or architecture rather than a standalone program.

**Q3. Does the technology automatically make the application faster?**  
A. No. Added network hops, serialization, synchronization, or resource contention can make it slower. Measure realistic workloads.

**Q4. What if the new component fails?**  
A. The application needs a defined failure policy: reject safely, retry within a budget, degrade gracefully, or recover from durable state. The right choice depends on the operation.

**Q5. Is it secure by default?**  
A. No single component guarantees application security. Authentication, authorization, validation, transport security, secret handling, and updates remain necessary.

**Q6. Can we use it on an offline intranet?**  
A. Usually, if compatible binaries, dependencies, documentation, and updates are prepared and distributed through approved processes. Internet access is not inherently required for local runtime operation.

**Q7. What should we test first?**  
A. The ordinary path, invalid input, unavailable dependency, permission denial, and one recovery scenario.

**Q8. What is the most important misconception for this lecture?**  
A. The right implementation depends on workload, operational constraints, team experience, and how failures are handled. A new abstraction changes where complexity lives; it rarely removes complexity entirely.

## TG9. Teaching techniques and instructor preparation

**Analogy:** Think of the application as an office workflow. The browser is a requester, the application service is the clerk who enforces policy, the database is the official records room, and optional systems such as caches, queues, and gateways are specialized assistants. A specialized assistant should not silently become the only official record.

**Suggested 90-minute schedule:** 10 min problem story; 15 min terminology; 15 min architecture diagram; 20 min live demo; 15 min failure and security discussion; 10 min questions; 5 min recap.

**Before class:** Run the demo twice on the exact classroom machine; confirm local dependencies; prepare a screenshot of the expected output; test one deliberate failure; keep an offline copy of the relevant official documentation.

**After class:** Ask learners to submit a one-page decision memo with the problem, architecture, benefits, costs, and one failure scenario.

## TG10. Additional learning resources

- Official topic/category documentation: https://docs.phpunit.de/
- PHP manual: https://www.php.net/manual/en/
- MDN web platform reference: https://developer.mozilla.org/
- OWASP cheat sheets: https://cheatsheetseries.owasp.org/

Download the relevant pages and dependencies before teaching on an offline network. Documentation changes over time; check the current official version before using configuration examples in production.
