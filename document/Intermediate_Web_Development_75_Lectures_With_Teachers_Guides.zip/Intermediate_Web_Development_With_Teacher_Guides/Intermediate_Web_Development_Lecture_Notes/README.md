# Intermediate Web Development — Complete Lecture Notes

This archive contains **75 individual Markdown lecture chapters** in **15 thematic parts**, a syllabus, an instructor guide, and demonstration snippets. Each chapter is an intermediate-level conceptual lesson with a scenario, explanation, architecture model, operating sequence, trade-offs, example, student activities, and Q&A.

**Scope:** These are complete teaching *handouts* rather than 75 independently runnable production projects or 10–15-page research monographs. Some examples are intentionally illustrative and require local supporting classes, packages, or services. Consult each chapter before using code.

**Audience:** Developers already comfortable with HTML, CSS, JavaScript, PHP, SQL, HTTP, and basic application development.

**Offline classroom:** Preinstall PHP, MariaDB, optional Redis/RabbitMQ/Docker and other dependencies before teaching. All lecture text is included offline; reference URLs are for later study.

**Security and compatibility:** PHP 7.4 is end-of-life. Some examples use supported PHP 8.x or pseudocode where noted. Do not deploy instructional fragments without proper authentication, authorization, secrets handling, validation, monitoring, and tests.

Open `Course-Syllabus.md` to navigate the 15 parts.


## Updated edition: Teacher's Guides

Each of the 75 lecture files now contains **Part A — Student Lecture Notes** (preserved from the original package) and **Part B — Teacher's Guide** (added). Teacher sections include deeper conceptual explanation, an operating model, normal/failure paths, a runnable part-level demonstration, troubleshooting, comparison, security notes, FAQs, teaching tips, and official reading.

**Scope clarification:** The demonstrations are intentionally small; several illustrate the category rather than fully implement each named product. External services (Redis, RabbitMQ, Docker, etc.) must be installed locally for their full live demonstrations. This is a teacher-preparation resource, not a verified production integration guide for every technology.
