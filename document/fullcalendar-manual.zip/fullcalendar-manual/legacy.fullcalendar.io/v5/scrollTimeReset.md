# scrollTimeReset

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/scrollTimeReset
>
> Latest version (v7): https://fullcalendar.io/docs/scrollTimeReset.md

Whether the view should scroll to [scrollTime](https://legacy.fullcalendar.io/v5/scrollTime.md) every time the date range changes.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

By default, whenever the date range changes either via the API or the end-user clicking prev/next, the scroll is reset. Set `scrollTimeReset` to `false` to disable this behavior.
