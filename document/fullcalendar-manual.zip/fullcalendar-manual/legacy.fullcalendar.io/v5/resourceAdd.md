# resourceAdd

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resourceAdd
>
> Latest version (v7): https://fullcalendar.io/docs/resourceAdd.md

Premium feature.

Called after a resource has been added to the calendar.

<div class='spec' markdown='1'>
function( addInfo )
</div>

This fires after [Calendar::addResource](https://legacy.fullcalendar.io/v5/addResource.md) is called.

The `addInfo` argument has the following properties:

<table>

<tr>
<th>resource</th>
<td>a <a href='https://legacy.fullcalendar.io/v5/resource-object.md'>Resource Object</a> for the added resource</td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

</table>
