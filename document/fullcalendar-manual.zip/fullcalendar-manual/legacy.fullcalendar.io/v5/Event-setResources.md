# Event::setResources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Event-setResources
>
> Latest version (v7): https://fullcalendar.io/docs/Event-setResources.md

Sets the [Resources](https://legacy.fullcalendar.io/v5/resource-object.md) associated with the given event.

<div class='spec' markdown='1'>
event.setResource([ resource0, resource1... ])
</div>

Can accept an array of resource IDs:

```js
var event = calendar.getEventById('1');
event.setResources([ 'a' ]); // set a single resource
event.setResources([ 'a', 'b' ]); // set multiple
```

Can also accept an array of [Resource Objects](https://legacy.fullcalendar.io/v5/resource-object.md):

```js
var resourceA = calendar.getResourceById('a');
var resourceB = calendar.getResourceById('b');

var event = calendar.getEventById('1');
event.setResources([ resourceA, resourceB ]);
```
