# View Object

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/view-object
>
> Latest version (v7): https://fullcalendar.io/docs/view-object.md

A View object contains information about a calendar view, such as title and date range. This information about the current view is passed into nearly every [handler](https://legacy.fullcalendar.io/v5/handlers.md).


## Properties

`type`
:   Name of one of the available views (a string).

`title`
:   Title text that is displayed at the top of the headerToolbar (such as "September 2009" or "Sep 7 - 13 2009").

`activeStart`
:   A [Date](https://legacy.fullcalendar.io/v5/date-object.md) that is the first visible day.
    In month view, this value is often before the 1st day of the month, because most months do not begin on the first day-of-week.

`activeEnd`
:   A [Date](https://legacy.fullcalendar.io/v5/date-object.md) that is the last visible day. **Note: This value is exclusive**. See how events are [are parsed from a plain object](https://legacy.fullcalendar.io/v5/event-parsing.md) for further details.

`currentStart`
:   A [Date](https://legacy.fullcalendar.io/v5/date-object.md) that is the start of the interval the view is trying to represent.
    For example, in month view, this will be the first of the month. This value disregards hidden days.

`currentEnd`
:   A [Date](https://legacy.fullcalendar.io/v5/date-object.md) that is the end of the interval the view is trying to represent. **Note: This value is exclusive**. See how events are [are parsed from a plain object](https://legacy.fullcalendar.io/v5/event-parsing.md) for further details.
    For example, in month view, this will be the day after the last day of the month.
    This value disregards hidden days.

`calendar`
:   The master Calendar Object this view belongs to.

These properties of the View object can only be read. A [custom view with settings](https://legacy.fullcalendar.io/v5/custom-view-with-settings.md) is the way to set any of them.
