# eventOrderStrict

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventOrderStrict
>
> Latest version (v7): https://fullcalendar.io/docs/eventOrderStrict.md

Ensures the [eventOrder](https://legacy.fullcalendar.io/v5/eventOrder.md) setting is strictly followed.

<div class='spec' markdown='1'>
Boolean, *default*: `false`
</div>

By default, this setting is `false`, meaning `eventOrder` is **not** strict and compactness will be prioritized over following `eventOrder` exactly.
