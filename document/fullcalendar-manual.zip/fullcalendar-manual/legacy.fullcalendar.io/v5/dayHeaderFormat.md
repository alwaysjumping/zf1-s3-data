# dayHeaderFormat

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dayHeaderFormat
>
> Latest version (v7): https://fullcalendar.io/docs/dayHeaderFormat.md

Determines the text that will be displayed on the calendar's column headings.

<div class='spec' markdown='1'>
[Date Formatter](https://legacy.fullcalendar.io/v5/date-formatting.md), *default*:

```js
// like 'Mon', for month view
{ weekday: 'short' }

// like 'Mon 9/7', for week views
{ weekday: 'short', month: 'numeric', day: 'numeric', omitCommas: true }

// like 'Monday', for day views
{ weekday: 'long' }
```
</div>

As noted above, each view has a specific default. Get fine-tuned control with [View-Specific Options](https://legacy.fullcalendar.io/v5/view-specific-options.md). A single string alone will set the value for all views.

If you need programmatic control, use the [day-header render hooks](https://legacy.fullcalendar.io/v5/day-header-render-hooks.md) instead.
