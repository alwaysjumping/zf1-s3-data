# stickyHeaderDates

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/stickyHeaderDates
>
> Latest version (v7): https://fullcalendar.io/docs/tableHeaderSticky.md

Whether to fix the date-headers at the top of the calendar to the viewport while scrolling.

<div class='spec' markdown='1'>
`'auto'` (the default), `true`, `false`
</div>

The default value of `'auto'` will look at the [height](https://legacy.fullcalendar.io/v5/height.md) setting and if it is `'auto'`, meaning the calendar has the potential to be very tall, sticky-header-dates will be activated.

The following demos show sticky date-headers:

- [timegrid view](https://legacy.fullcalendar.io/v5/sticky-timegrid-demo)
- [list view](https://legacy.fullcalendar.io/v5/sticky-list-demo)
- [timeline view](https://legacy.fullcalendar.io/v5/sticky-timeline-demo)
- [vertical resource view](https://legacy.fullcalendar.io/v5/sticky-resource-timegrid-demo)
