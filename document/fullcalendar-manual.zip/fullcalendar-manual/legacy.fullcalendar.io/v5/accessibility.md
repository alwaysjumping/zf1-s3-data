# Accessibility

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/accessibility
>
> Latest version (v7): https://fullcalendar.io/docs/accessibility.md

FullCalendar leverages [WAI-ARIA](https://www.w3.org/WAI/standards-guidelines/aria/) techniques for increased accessibility with keyboard usage and screen readers. These improvements are available in versions [5.10.0](https://github.com/fullcalendar/fullcalendar/releases/tag/v5.10.0) and later.

More specifically, [ARIA attributes](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA) and `title` attributes annotate interactive HTML elements within the calendar. Furthermore, any interactive element can be focused with the tab key.

Options related to accessibility:

## Articles

- [eventInteractive](https://legacy.fullcalendar.io/v5/eventInteractive.md) - Setting to true will cause all events to be focusable/tabbable. By default, only events that have an event.url property are tabbable.
- [Hints](https://legacy.fullcalendar.io/v5/hints.md) - Interactive HTML elements are annotated with aria-label and title attributes to make them more descriptive. It is possible to control the text of these attributes.

## See Also

- [customButtons](https://legacy.fullcalendar.io/v5/customButtons.md) - Defines custom buttons that can be used in the headerToolbar/footerToolbar.
- [Touch Support](https://legacy.fullcalendar.io/v5/touch.md) - FullCalendar’s Touch support includes smooth scrolling, time-range selection via long-press, and event drag-n-drop/resizing via long-press.
- [Optimizing for Print](https://legacy.fullcalendar.io/v5/print.md) - FullCalendar looks great on a computer screen, but by default it does not look very good for printing on a piece of paper. A web browser isn’t able to convert certain things consistently, such as absolute positioning and scrollbars. Fortunately FullCalendar can render differently for print if you configure it to do so.
