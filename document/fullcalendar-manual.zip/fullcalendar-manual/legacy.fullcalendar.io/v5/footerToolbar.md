# footerToolbar

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/footerToolbar
>
> Latest version (v7): https://fullcalendar.io/docs/footerToolbar.md

Defines the controls at the bottom of the calendar.

<div class='spec' markdown='1'>
Object / `false` (the default)
</div>

This settings accepts the same exact values as the [headerToolbar](https://legacy.fullcalendar.io/v5/headerToolbar.md) option.

It is `false` by default, meaning no controls will be rendered at the foot of the calendar.
