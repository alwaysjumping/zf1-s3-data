# unselect

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/unselect-callback
>
> Latest version (v7): https://fullcalendar.io/docs/unselect-callback.md

Triggered when the current selection is cleared.

<div class='spec' markdown='1'>
function( *jsEvent*, *view* )
</div>

A selection might be cleared for a number of reasons:

1. The user clicks away from the current selection (doesn't happen when [unselectAuto](https://legacy.fullcalendar.io/v5/unselectAuto.md) is `false`).

2. The user makes a *new* selection. The `unselect` callback will be fired before the new selection occurs.

3. The user moves forward or backward in the current view, or switches to a new view.

4. The [unselect](https://legacy.fullcalendar.io/v5/Calendar-unselect.md) method is called through the API.


`jsEvent` holds the primitive JavaScript event with information such as mouse coordinates. If `unselect` has been triggered via the [unselect method](https://legacy.fullcalendar.io/v5/Calendar-unselect.md), `jsEvent` will be `undefined`.
