# Resource-Area Header Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resource-area-header-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/resource-column-header-render-hooks.md

Premium feature.

The "resource-area header" is above the resource data and displays the text "Resources" by default.


`resourceAreaHeaderClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`resourceAreaHeaderContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`resourceAreaHeaderDidMount`

`resourceAreaHeaderWillUnmount`


## Argument

When the `resourceAreaHeaderDidMount` and `resourceAreaHeaderWillUnmount` hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `el` - the element
