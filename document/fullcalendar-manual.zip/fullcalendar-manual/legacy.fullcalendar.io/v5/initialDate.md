# initialDate

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/initialDate
>
> Latest version (v7): https://fullcalendar.io/docs/initialDate.md

The initial date displayed when the calendar first loads.

<div class='spec' markdown='1'>
[Date](https://legacy.fullcalendar.io/v5/date-parsing.md)
</div>

When not specified, this value defaults to the current date.

This value can be anything that can [parse into a Date](https://legacy.fullcalendar.io/v5/date-parsing.md), including an ISO8601 date string like `"2014-02-01"`.
