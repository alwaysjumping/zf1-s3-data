# droppable

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/droppable
>
> Latest version (v7): https://fullcalendar.io/docs/droppable.md

Determines if [external draggable elements](https://legacy.fullcalendar.io/v5/external-dragging.md) or events from other calendars can be dropped onto the calendar.

<div class='spec' markdown='1'>
Boolean, *default*: `false`
</div>

It's important to enable this setting if you want to use the [drop callback](https://legacy.fullcalendar.io/v5/drop.md) or the [eventReceive callback](https://legacy.fullcalendar.io/v5/eventReceive.md).
