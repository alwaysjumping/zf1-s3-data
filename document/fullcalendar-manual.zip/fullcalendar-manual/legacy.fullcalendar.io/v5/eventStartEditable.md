# eventStartEditable

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventStartEditable
>
> Latest version (v7): https://fullcalendar.io/docs/eventStartEditable.md

Allow events' start times to be editable through dragging.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

You must enable the `interaction` plugin before using this setting. [See code samples on the `editable` article &raquo;](https://legacy.fullcalendar.io/v5/editable.md)

This option can be overridden on a per-source basis with the `startEditable` [Event Source Object](https://legacy.fullcalendar.io/v5/event-source-object.md) option or on a per-event basis with the `startEditable` [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) option.
