# slotMinWidth

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/slotMinWidth
>
> Latest version (v7): https://fullcalendar.io/docs/slotMinWidth.md

Premium feature.

Determines how wide each of the time-axis slots will be. Specified as a number of pixels.

When not specified, a reasonable value will be automatically computed.
