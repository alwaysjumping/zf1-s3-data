# formatDate

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/formatDate
>
> Latest version (v7): https://fullcalendar.io/docs/formatDate.md

A utility function that formats a date into a string.

<div class='spec' markdown='1'>
FullCalendar.formatDate( *date*, *settings* )
</div>

`date` can be a [Date Object](https://legacy.fullcalendar.io/v5/date-object.md) or something that will [parse into a Date Object](https://legacy.fullcalendar.io/v5/date-parsing.md).

`settings` is an object that holds any of the [date format config](https://legacy.fullcalendar.io/v5/date-formatting.md) options. It also accepts the following additional properties:

- `locale` &mdash; the name of a [locale](https://legacy.fullcalendar.io/v5/locale.md) like `'es'`
- `timeZone` &mdash; the name of a [time zone](https://legacy.fullcalendar.io/v5/timeZone.md). Either `'local'`, `'UTC'`, or a named time zone

Example:

```js
import { formatDate } from '@fullcalendar/core'

let str = formatDate('2018-09-01', {
  month: 'long',
  year: 'numeric',
  day: 'numeric',
  timeZoneName: 'short',
  timeZone: 'UTC',
  locale: 'es'
})

console.log(str) // "1 de septiembre de 2018 0:00 UTC"
```
