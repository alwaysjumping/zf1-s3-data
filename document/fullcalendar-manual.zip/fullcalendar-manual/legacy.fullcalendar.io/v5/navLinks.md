# navLinks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/navLinks
>
> Latest version (v7): https://fullcalendar.io/docs/navLinks.md

Determines if day names and week names are clickable.

<div class='spec' markdown='1'>
boolean. *default*: `false`
</div>

When `true`, day headings and [weekNumbers](https://legacy.fullcalendar.io/v5/weekNumbers.md) will become clickable. When clicked, these links will bring the user to a view that represents the day/week. [View a simple demo](https://legacy.fullcalendar.io/v5/navLinks-demo).

The destination views are automatically determined by the views that are in the [headerToolbar](https://legacy.fullcalendar.io/v5/headerToolbar.md). However, they can be explicity defined using [navLinkDayClick](https://legacy.fullcalendar.io/v5/navLinkDayClick.md) and [navLinkWeekClick](https://legacy.fullcalendar.io/v5/navLinkWeekClick.md).
