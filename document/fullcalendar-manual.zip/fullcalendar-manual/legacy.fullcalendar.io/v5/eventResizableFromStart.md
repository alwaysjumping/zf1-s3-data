# eventResizableFromStart

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventResizableFromStart
>
> Latest version (v7): https://fullcalendar.io/docs/eventResizableFromStart.md

Whether the user can resize an event from its starting edge.

<div class='spec' markdown='1'>
`true` or `false` (default)
</div>

By default, the user cannot.
