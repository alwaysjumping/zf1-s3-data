# Resource Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resource-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/resource-cell-render-hooks.md

Premium feature.

## Label Hooks

A resource "label" is anywhere the name of a resource is displayed. They exist in the header of vertical resource view and the side section of resource timeline view.

`resourceLabelClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`resourceLabelContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`resourceLabelDidMount`

`resourceLabelWillUnmount`


## Lane Hooks

A resource "lane" is an element in resource-timeline view. It runs horizontally across the timeline slots for each resource.

`resourceLaneClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`resourceLaneContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`resourceLaneDidMount`

`resourceLaneWillUnmount`


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `resource` - [Resoure Object](https://legacy.fullcalendar.io/v5/resource-object.md)
- `date` - in vertical resource view, if this is a column that lives under a certain date, this will be the Date object
- `el` - the label element. only available in `resourceLabelDidMount`, `resourceLabelWillUnmount`, `resourceLaneDidMount`, and `resourceLaneWillUnmount`
