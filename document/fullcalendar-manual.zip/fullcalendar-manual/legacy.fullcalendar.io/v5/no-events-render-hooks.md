# No-Events Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/no-events-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/no-events-render-hooks.md

In list view, the “No events to display” message.


`noEventsClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`noEventsContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`noEventsDidMount`

`noEventsWillUnmount`


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `text` - the message text, from the `noEventsText` option
- `view` - the current [View Object](https://legacy.fullcalendar.io/v5/view-object.md)
- `el` - the element. only available in `noEventsDidMount` and `noEventsWillUnmount`
