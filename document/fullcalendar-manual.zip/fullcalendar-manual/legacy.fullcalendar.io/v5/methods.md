# Methods

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/methods
>
> Latest version (v7): https://fullcalendar.io/docs/vanilla-js.md#calendar-api

Methods provide ways to manipulate the calendar from JavaScript code.<!--more--> A method operates on a Calendar object that has already been [initialized](https://legacy.fullcalendar.io/v5/initialize-es6.md):

```js
calendar.next();
```

This will call the [next](https://legacy.fullcalendar.io/v5/Calendar-next.md) method and will force to the calendar to move to the next month/week/day.
