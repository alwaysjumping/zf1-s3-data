# eventShortHeight

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventShortHeight
>
> Latest version (v7): https://fullcalendar.io/docs/eventShortHeight.md

In **timeGrid** view, the height threshold for when an event has a "short" style.

<div class='spec' markdown='1'>
Number, *default*: `30`
</div>

Example of a regular event:

<img
  src='https://legacy.fullcalendar.io/v5/timegrid-event-notshort.png'
  alt='Screenshot of event with regular height'
  class='bordered-image'
  width='179'
  height='104'>

Example of a "short" event:

<img
  src='https://legacy.fullcalendar.io/v5/timegrid-event-short.png'
  alt='Screenshot of event with short height'
  class='bordered-image'
  width='179'
  height='104'>
