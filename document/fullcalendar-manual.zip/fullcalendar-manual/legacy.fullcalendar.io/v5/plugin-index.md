# Plugin Index

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/plugin-index
>
> Latest version (v7): https://fullcalendar.io/docs/plugin-index.md

FullCalendar offers the following packages:

<style>
  .plugin-table td:first-child strong { display: block; white-space: nowrap }
</style>

<table class='plugin-table'>
<thead>
  <tr>
    <th>Name</th>
    <th>Functionality / Views</th>
    <th>Yarn</th>
    <th>jsDelivr</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td>
      <strong>@fullcalendar/core</strong>
    </td>
    <td>
      Offers the <code>Calendar</code> class among other things
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/core'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/core?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/interaction</strong>
    </td>
    <td>
      Required to detect <a href='https://legacy.fullcalendar.io/v5/dateClick.md'>dateClick</a> actions,
      <a href='https://legacy.fullcalendar.io/v5/selectable.md'>selectable</a> actions, and
      <a href='https://legacy.fullcalendar.io/v5/editable.md'>event drag-n-drop &amp; resizing</a>.<br />
      <em>Not needed</em> for
      <a href='https://legacy.fullcalendar.io/v5/eventClick.md'>eventClick</a> or
      <a href='https://legacy.fullcalendar.io/v5/eventMouseEnter.md'>eventMouseEnter</a>/<a href='https://legacy.fullcalendar.io/v5/eventMouseLeave.md'>eventMouseLeave</a>.
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/interaction'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/interaction?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/daygrid</strong>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/month-view.md'>Month</a> and <a href='https://legacy.fullcalendar.io/v5/daygrid-view.md'>DayGrid</a> views:<br />
      <code>dayGridMonth</code>,
      <code>dayGridWeek</code>,
      <code>dayGridDay</code>,
      <code>dayGrid</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/daygrid'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/daygrid?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/timegrid</strong>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/timegrid-view.md'>TimeGrid</a> views:<br />
      <code>timeGridWeek</code>,
      <code>timeGridDay</code>,
      <code>timeGrid</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/timegrid'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/timegrid?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/list</strong>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/list-view.md'>Lists</a> views:<br />
      <code>listYear</code>,
      <code>listMonth</code>,
      <code>listWeek</code>,
      <code>listDay</code>,
      <code>list</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/list'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/list?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/scrollgrid</strong>
    </td>
    <td>
      Provides advanced scrolling features such as horizontal scrolling to certain views
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/scrollgrid'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/scrollgrid?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/timeline</strong>
      <a href='https://fullcalendar.io/pricing' class='badge'>Premium</a>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/timeline-view-no-resources.md'>Timeline views with <strong>no resource support</strong></a>:<br />
      <code>timelineYear</code>,
      <code>timelineMonth</code>,
      <code>timelineWeek</code>,
      <code>timelineDay</code>,
      <code>timeline</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/timeline'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/timeline?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/adaptive</strong>
      <a href='https://fullcalendar.io/pricing' class='badge'>Premium</a>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/print.md'>improved printing support</a>.
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/adaptive'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/adaptive?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/resource-common</strong>
      <a href='https://fullcalendar.io/pricing' class='badge'>Premium</a>
    </td>
    <td>
      Offers base support for resources. Required for all resource-related plugins.
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/resource-common'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/resource-common?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/resource-daygrid</strong>
      <a href='https://fullcalendar.io/pricing' class='badge'>Premium</a>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/resource-daygrid-view.md'>resource-enabled DayGrid</a> views:
      <code>resourceDayGridMonth</code>,
      <code>resourceDayGridWeek</code>,
      <code>resourceDayGridDay</code>,
      <code>resourceDayGrid</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/resource-daygrid'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/resource-daygrid?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/resource-timegrid</strong>
      <a href='https://fullcalendar.io/pricing' class='badge'>Premium</a>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/vertical-resource-view.md'>resource-enabled TimeGrid</a> views:
      <code>resourceTimeGridWeek</code>,
      <code>resourceTimeGridDay</code>,
      <code>resourceTimeGrid</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/resource-timegrid'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/resource-timegrid?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/resource-timeline</strong>
      <a href='https://fullcalendar.io/pricing' class='badge'>Premium</a>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/timeline-view.md'>resource-enabled Timeline</a> views:
      <code>resourceTimelineYear</code>,
      <code>resourceTimelineMonth</code>,
      <code>resourceTimelineWeek</code>,
      <code>resourceTimelineDay</code>,
      <code>resourceTimeline</code> (<a href='https://legacy.fullcalendar.io/v5/custom-view-with-settings.md'>generic</a>)
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/resource-timeline'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/resource-timeline?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/bootstrap5</strong>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/bootstrap5.md'>Bootstrap 5 theming</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/bootstrap5'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/bootstrap5?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/bootstrap</strong>
    </td>
    <td>
      Offers <a href='https://legacy.fullcalendar.io/v5/bootstrap4.md'>Bootstrap 4 theming</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/bootstrap'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/bootstrap?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/google-calendar</strong>
    </td>
    <td>
      For loading events from a public <a href='https://legacy.fullcalendar.io/v5/google-calendar.md'>Google Calendar feed</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/google-calendar'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/google-calendar?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/icalendar</strong>
    </td>
    <td>
      For loading events from an <a href='https://legacy.fullcalendar.io/v5/icalendar.md'>iCalendar feed</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/icalendar'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/icalendar?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/rrule</strong>
    </td>
    <td>
      For <a href='https://legacy.fullcalendar.io/v5/rrule-plugin.md'>leveraging the RRule library</a> for event recurrence
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/rrule'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/rrule?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/luxon2</strong>
    </td>
    <td>
      Offers a named-timezone implementation, a formatting string implementation, and utilities for converting to Luxon DateTimes. <a href='https://legacy.fullcalendar.io/v5/luxon2.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/luxon2'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/luxon2?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/luxon</strong>
    </td>
    <td>
      Supports Luxon v1. <a href='https://legacy.fullcalendar.io/v5/luxon1.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/luxon'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/luxon?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/moment</strong>
    </td>
    <td>
      Offers a formatting string implementation and utilities fo convert to Moment objects. <a href='https://legacy.fullcalendar.io/v5/moment-plugin.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/moment'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/moment?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/moment-timezone</strong>
    </td>
    <td>
      Offers a named timezone implementation. <a href='https://legacy.fullcalendar.io/v5/moment-timezone-plugin.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/moment-timezone'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/moment-timezone?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/react</strong>
    </td>
    <td>
      Offers a React component. <a href='https://legacy.fullcalendar.io/v5/react.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/react'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/react?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/vue3</strong>
    </td>
    <td>
      Offers a Vue 3 component. <a href='https://legacy.fullcalendar.io/v5/vue.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/vue3'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/vue3?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/vue</strong>
    </td>
    <td>
      Offers a Vue 2 component. <a href='https://legacy.fullcalendar.io/v5/vue.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/vue'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/vue?version=5.11.5'>jsDelivr</a></td>
  </tr>
  <tr>
    <td>
      <strong>@fullcalendar/angular</strong>
    </td>
    <td>
      Offers an Angular component. <a href='https://legacy.fullcalendar.io/v5/angular.md'>More info</a>
    </td>
    <td><a href='https://yarnpkg.com/package/@fullcalendar/angular'>Yarn</a></td>
    <td><a href='https://www.jsdelivr.com/package/npm/@fullcalendar/angular?version=5.11.5'>jsDelivr</a></td>
  </tr>
</tbody>
</table>
