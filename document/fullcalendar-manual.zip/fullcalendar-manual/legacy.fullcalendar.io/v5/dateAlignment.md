# dateAlignment

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dateAlignment
>
> Latest version (v7): https://fullcalendar.io/docs/dateAlignment.md

Determines the first visible day of a custom view.

<div class='spec' markdown='1'>
String
</div>

When a [Custom View](https://legacy.fullcalendar.io/v5/custom-view-with-settings.md) is being used, and you'd like to guarantee that the view begins at a certain interval, like the start-of-week or start-of-month, specify a value like `"week"` or `"month"`.

If not specified, a reasonable default will be generated based on the view's duration.

If a view's range is explicity defined with [visibleRange](https://legacy.fullcalendar.io/v5/visibleRange.md), `dateAlignment` will be ignored.
