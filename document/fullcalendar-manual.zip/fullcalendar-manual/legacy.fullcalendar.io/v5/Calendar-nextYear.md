# Calendar::nextYear

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-nextYear
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-nextYear.md

Moves the calendar forward one year.

<div class='spec' markdown='1'>
calendar.nextYear()
</div>
