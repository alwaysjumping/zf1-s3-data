# Resource::setProp

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Resource-setProp
>
> Latest version (v7): https://fullcalendar.io/docs/Resource-setProp.md

Premium feature.

Modifies any of the properties of a [Resource Object](https://legacy.fullcalendar.io/v5/resource-object.md).

<div class='spec' markdown='1'>
resource.setProp( *name*, *value* )
</div>

To modify any of the `extendedProps`, use [setExtendedProp](https://legacy.fullcalendar.io/v5/Resource-setExtendedProp.md).
