# Resource Display

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resource-display
>
> Latest version (v7): https://fullcalendar.io/docs/resource-display.md

Premium feature.

Control the visual aspects of your resources, such as ordering and text.

## Articles

- [resourceOrder](https://legacy.fullcalendar.io/v5/resourceOrder.md) - Determines the ordering of the resource list.
- [filterResourcesWithEvents](https://legacy.fullcalendar.io/v5/filterResourcesWithEvents.md) - When this setting is activated, only resources that have associated events will be displayed.
- [Resource Render Hooks](https://legacy.fullcalendar.io/v5/resource-render-hooks.md) - Label Hooks

## See Also

- [Timeline View](https://legacy.fullcalendar.io/v5/timeline-view.md) - FullCalendar Premium provides a view called “timeline view” with a customizable horizontal time-axis and resources as rows.
- [Vertical Resource View](https://legacy.fullcalendar.io/v5/vertical-resource-view.md) - FullCalendar Premium provides TimeGrid view and DayGrid view with the ability to display resources as columns.

## Demos

- [Using resourceLabelDidMount with a popover in vertical-resource-view](https://legacy.fullcalendar.io/v5/vertical-resource-render-hook-demo)
- [Using resourceLabelDidMount with a popover in timeline-view](https://legacy.fullcalendar.io/v5/timeline-resource-render-hook-demo)
