# Resource Object

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resource-object
>
> Latest version (v7): https://fullcalendar.io/docs/resource-object.md

Premium feature.

Raw resource objects are eventually [parsed](https://legacy.fullcalendar.io/v5/resource-parsing.md) into proper resource objects, which are accessible via Calendar methods such as [getResources](https://legacy.fullcalendar.io/v5/getResources.md) and [getResourceById](https://legacy.fullcalendar.io/v5/getResourceById.md). You can read their properties or manipulate them via methods.

Each resource has the following properties:

- `id` - the unique string identifier for this resource
- `title` - the string title of this resource
- `extendedProps` - a hash of non-standard props that were specified during [parsing](https://legacy.fullcalendar.io/v5/resource-parsing.md)
- `eventConstraint`
- `eventOverlap`
- `eventAllow`
- `eventBackgroundColor`
- `eventBorderColor`
- `eventTextColor`
- `eventClassNames`

The following essential methods are offered:

- [getParent](https://legacy.fullcalendar.io/v5/Resource-getParent.md)
- [getChildren](https://legacy.fullcalendar.io/v5/Resource-getChildren.md)
- [getEvents](https://legacy.fullcalendar.io/v5/Resource-getEvents.md)
- [remove](https://legacy.fullcalendar.io/v5/Resource-remove.md)

For more Resource methods, look for methods that start with `Resource::` in the docs.
