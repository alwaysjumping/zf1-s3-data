# showNonCurrentDates

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/showNonCurrentDates
>
> Latest version (v7): https://fullcalendar.io/docs/showNonCurrentDates.md

In month view, whether dates in the previous or next month should be rendered at all.

<div class='spec' markdown='1'>
Boolean, default: `true`
</div>

Days that are disabled will not render events.

When set to `false` in month view:

<img src='https://legacy.fullcalendar.io/v5/showNonCurrentDates-false.png' width='456' height='365' style='margin:20px 0 20px 40px' alt='not showing dates in other months' />

When set to `true` in month view (the default):

<img src='https://legacy.fullcalendar.io/v5/showNonCurrentDates-true.png' width='455' height='363' style='margin:20px 0 20px 40px' alt='showing dates in other months' />


## See Also

To customize the number of week rows displayed in month view, see [fixedWeekCount](https://legacy.fullcalendar.io/v5/fixedWeekCount.md).
