# eventChange

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventChange
>
> Latest version (v7): https://fullcalendar.io/docs/eventChange.md

Called after an event has been modified in some way.

<div class='spec' markdown='1'>
function( changeInfo )
</div>

This fires after any [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) setter method is called, like [setStart](https://legacy.fullcalendar.io/v5/Event-setStart.md). It is also called after an event has been dragged or resized. `eventChange` will fire *after* [eventDrop](https://legacy.fullcalendar.io/v5/eventDrop.md) and [eventResize](https://legacy.fullcalendar.io/v5/eventResize.md).

The `changeInfo` argument has the following properties:

<table>

<tr>
<th>event</th>
<td>an <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Object</a> with the updated changed data</td>
</tr>

<tr>
<th>relatedEvents</th>
<td>an array of other related <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Objects</a> that were also affected. an event might have other <a href='https://legacy.fullcalendar.io/v5/recurring-events.md'>recurring event</a> instances or might be linked to other events with the same <code>groupId</code></td>
</tr>

<tr>
<th>oldEvent</th>
<td>an <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Object</a> with data prior to the change</td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

</table>
