# Business Hours

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/business-hours
>
> Latest version (v7): https://fullcalendar.io/docs/business-hours.md

Emphasize a view's "business hours" (aka "working hours").

## Articles

- [businessHours](https://legacy.fullcalendar.io/v5/businessHours.md) - Emphasizes certain time slots on the calendar. By default, Monday-Friday, 9am-5pm.
- [businessHours-per-resource](https://legacy.fullcalendar.io/v5/businessHours-per-resource.md) - The main businessHours settings can be applied more granularly to individual resources via the businessHours property on the Resource input

## Demos

- [Business-hours on timeGridWeek view](https://legacy.fullcalendar.io/v5/businessHours-demo)
