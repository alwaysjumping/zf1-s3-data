# Day-Header Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/day-header-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/day-header-render-hooks.md

Customize the header elements above the day cells in daygrid and timegrid views with the following options. The same options also apply to the title elements for each day in list view. For the timeline view, see the [slot render hooks](https://legacy.fullcalendar.io/v5/slot-render-hooks.md).

`dayHeaderClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md) for adding classNames to the header `<th>` cell

`dayHeaderContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md). Generated content is inserted *inside* the inner-most wrapper of the header cell. It does not replace the `<th>` cell.

`dayHeaderDidMount` - called right after the `<th>` has been added to the DOM

`dayHeaderWillUnmount` - called right before the `<th>` will be removed from the DOM


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `date` - Date object
- `text`
- `isPast`
- `isFuture`
- `isToday`
- `isOther`
- `resource` - if the date column lives under a specific resource in [vertical resource view](https://legacy.fullcalendar.io/v5/vertical-resource-view.md), this value will be the [Resource Object](https://legacy.fullcalendar.io/v5/resource-object.md)
- `el` - the `<th>` element. only available in `dayHeaderDidMount` and `dayHeaderWillUnmount`
