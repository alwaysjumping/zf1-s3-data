# defaultTimedEventDuration

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/defaultTimedEventDuration
>
> Latest version (v7): https://fullcalendar.io/docs/defaultTimedEventDuration.md

A fallback duration for timed [Event Objects](https://legacy.fullcalendar.io/v5/event-object.md) without a specified `end` value.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md), *default*: `'01:00'` (1 hour)
</div>

If an event does not have an `end` specified, it will appear to be this duration when rendered.

The actual `end` of the event will remain unset unless [forceEventDuration](https://legacy.fullcalendar.io/v5/forceEventDuration.md) has been set to `true`.

This setting only affects events with `allDay` equal to `false`. For all-day events, use [defaultAllDayEventDuration](https://legacy.fullcalendar.io/v5/defaultAllDayEventDuration.md).
