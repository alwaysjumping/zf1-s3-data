# unselectAuto

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/unselectAuto
>
> Latest version (v7): https://fullcalendar.io/docs/unselectAuto.md

Whether clicking elsewhere on the page will cause the current selection to be cleared.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

This option can only take effect when [selectable](https://legacy.fullcalendar.io/v5/selectable.md) is set to `true`.
