# eventDragStop

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventDragStop
>
> Latest version (v7): https://fullcalendar.io/docs/eventDragStop.md

Triggered when event dragging stops.

<div class='spec' markdown='1'>
function( *info* ) { }
</div>

This callback is *guaranteed* to be triggered after the user drags an event, even if the event doesn't change date/time. It is triggered **before** the event's information has been modified (if moved to a new date/time) and before the [eventDrop](https://legacy.fullcalendar.io/v5/eventDrop.md) callback is triggered.

`info` is a plain object with the following properties:

<table>

<tr>
<th>event</th>
<td markdown='1'>
An [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) that holds information about the event (date, title, etc) **before** the drop.
</td>
</tr>

<tr>
<th>jsEvent</th>
<td markdown='1'>
The native JavaScript event with low-level information such as click coordinates.
</td>
</tr>

<tr>
<th>view</th>
<td markdown='1'>
The current [View Object](https://legacy.fullcalendar.io/v5/view-object.md).
</td>
</tr>

</table>
