# resourceChange

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resourceChange
>
> Latest version (v7): https://fullcalendar.io/docs/resourceChange.md

Premium feature.

Called after a resource has been modified in some way.

<div class='spec' markdown='1'>
function( changeInfo )
</div>

This fires after [Resource::setProp](https://legacy.fullcalendar.io/v5/Resource-setProp.md) or [Resource::setExtendedProp](https://legacy.fullcalendar.io/v5/Resource-setExtendedProp.md) is called.

The `changeInfo` argument has the following properties:

<table>

<tr>
<th>resource</th>
<td>a <a href='https://legacy.fullcalendar.io/v5/resource-object.md'>Resource Object</a> with the updated changed data</td>
</tr>

<tr>
<th>oldResource</th>
<td>a <a href='https://legacy.fullcalendar.io/v5/resource-object.md'>Resource Object</a> with data prior to the change</td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

</table>
