# firstDay

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/firstDay
>
> Latest version (v7): https://fullcalendar.io/docs/firstDay.md

The day that each week begins.

<div class='spec' markdown='1'>
Integer, *default*: `0` (Sunday)
</div>

The default value depends on the current [locale](https://legacy.fullcalendar.io/v5/locale.md).

The value must be a number that represents the day of the week.

Sunday=`0`, Monday=`1`, Tuesday=`2`, etc.

If [weekNumberCalculation](https://legacy.fullcalendar.io/v5/weekNumberCalculation.md) is set to `'ISO'`, this option defaults to `1` (Monday).
