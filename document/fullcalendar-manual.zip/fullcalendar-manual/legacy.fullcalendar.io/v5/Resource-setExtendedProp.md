# Resource::setExtendedProp

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Resource-setExtendedProp
>
> Latest version (v7): https://fullcalendar.io/docs/Resource-setExtendedProp.md

Premium feature.

Modifies a single property in an [Resource Object's](https://legacy.fullcalendar.io/v5/resource-object.md) `extendedProps` hash.

<div class='spec' markdown='1'>
resource.setExtendedProp( *name*, *value* )
</div>
