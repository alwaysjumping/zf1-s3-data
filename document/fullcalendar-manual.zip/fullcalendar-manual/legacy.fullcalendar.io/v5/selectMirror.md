# selectMirror

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/selectMirror
>
> Latest version (v7): https://fullcalendar.io/docs/selectMirror.md

Whether to draw a "placeholder" event while the user is dragging.

<div class='spec' markdown='1'>
Boolean, *default*: `false`
</div>

**This option only applies to the TimeGrid views.**

A value of `true` will draw a "placeholder" event while the user is dragging (similar to what Google Calendar does for its week and day views). A value of `false` (the default) will draw the standard highlighting over each cell.
