# displayEventEnd

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/displayEventEnd
>
> Latest version (v7): https://fullcalendar.io/docs/displayEventEnd.md

Whether or not to display an event's end time.

<div class='spec' markdown='1'>
Boolean, *default*:

```js
false // for dayGridMonth and dayGridWeek views
true  // for timeGridWeek, timeGridDay, and dayGridDay
```
</div>

As noted above, each view has a specific default. Get fine-tuned control with [View-Specific Options](https://legacy.fullcalendar.io/v5/view-specific-options.md). A single boolean alone will set the value for all views.

If an event does not have an end date/time, or [displayEventTime](https://legacy.fullcalendar.io/v5/displayEventTime.md) is `false`, it won't be displayed anyway, regardless of this setting.
