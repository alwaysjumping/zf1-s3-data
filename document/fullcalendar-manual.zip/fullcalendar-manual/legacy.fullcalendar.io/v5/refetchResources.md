# refetchResources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/refetchResources
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-refetchResources.md

Premium feature.

Causes the resource data to be fetched and freshly rerendered.

<div class='spec' markdown='1'>
.refetchResources()
</div>

If the `resources` option [was specified as an function](https://legacy.fullcalendar.io/v5/resources-function.md), it will be recalled. If the `resources` option [was specified as a JSON feed](https://legacy.fullcalendar.io/v5/resources-json-feed.md) it will be requested again.
