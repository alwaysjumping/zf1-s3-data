# All-Day Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/all-day-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/all-day-header-render-hooks.md

Customize parts of the UI that typically display the text "all-day".


`allDayClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`allDayContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`allDayDidMount`

`allDayWillUnmount`


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `text`
