# defaultAllDay

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/defaultAllDay
>
> Latest version (v7): https://fullcalendar.io/docs/defaultAllDay.md

Determines the default value for each [Event Object](https://legacy.fullcalendar.io/v5/event-object.md)'s `allDay` property when it is unspecified.

<div class='spec' markdown='1'>
Boolean, *default*: `undefined`
</div>

By default, `defaultAllDay` is not set. As a result, any Event Objects that do not specify an `allDay` property will be subject the guessing behavior mentioned in the [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) article.

Set this option to `true` or `false` to make it affect Event Objects without an `allDay` property.
