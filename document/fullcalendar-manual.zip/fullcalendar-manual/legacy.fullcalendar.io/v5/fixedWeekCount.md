# fixedWeekCount

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/fixedWeekCount
>
> Latest version (v7): https://fullcalendar.io/docs/fixedWeekCount.md

Determines the number of weeks displayed in a month view.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

If `true`, the calendar will always be 6 weeks tall. If `false`, the calendar will have either 4, 5, or 6 weeks, depending on the month.
