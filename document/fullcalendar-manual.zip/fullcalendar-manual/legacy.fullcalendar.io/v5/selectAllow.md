# selectAllow

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/selectAllow
>
> Latest version (v7): https://fullcalendar.io/docs/selectAllow.md

Exact programmatic control over where the user can select.

<div class='spec' markdown='1'>
function(selectInfo)
</div>

This callback will be called for every new potential selection as the user is dragging.

The callback function will receive information about where the user is attempting to select (`selectInfo`) and must return either `true` or `false`.

The `selectInfo` object will have the following properties:

- `start` (a [Date](https://legacy.fullcalendar.io/v5/date-object.md))
- `end` (a [Date](https://legacy.fullcalendar.io/v5/date-object.md))
- `resource` (a [Resource](https://legacy.fullcalendar.io/v5/resource-object.md))(if you are using a [Resource View](https://fullcalendar.io/pricing))

In line with the discussion about the [Event object](https://legacy.fullcalendar.io/v5/event-parsing.md), it is important to stress that the `end` date property is **exclusive**.
