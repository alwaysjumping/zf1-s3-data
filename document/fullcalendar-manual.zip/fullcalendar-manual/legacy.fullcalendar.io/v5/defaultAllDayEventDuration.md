# defaultAllDayEventDuration

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/defaultAllDayEventDuration
>
> Latest version (v7): https://fullcalendar.io/docs/defaultAllDayEventDuration.md

A fallback duration for all-day [Event Objects](https://legacy.fullcalendar.io/v5/event-object.md) without a specified `end` value.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md), *default*: `{ days: 1 }`
</div>

If an event does not have an `end` specified, it will appear to be this duration when rendered.

The actual `end` of the event will remain unset unless [forceEventDuration](https://legacy.fullcalendar.io/v5/forceEventDuration.md) has been set to `true`.

This setting only affects events with `allDay` equal to `true`. For timed events, use [defaultTimedEventDuration](https://legacy.fullcalendar.io/v5/defaultTimedEventDuration.md).
