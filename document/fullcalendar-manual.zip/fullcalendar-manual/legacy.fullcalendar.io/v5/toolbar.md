# Toolbar

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/toolbar
>
> Latest version (v7): https://fullcalendar.io/docs/toolbar.md

The area at the top and bottom of the calendar that contains buttons and other controls.

## Articles

- [headerToolbar](https://legacy.fullcalendar.io/v5/headerToolbar.md) - Defines the buttons and title at the top of the calendar.
- [footerToolbar](https://legacy.fullcalendar.io/v5/footerToolbar.md) - Defines the controls at the bottom of the calendar.
- [titleFormat](https://legacy.fullcalendar.io/v5/titleFormat.md) - Determines the text that will be displayed in the headerToolbar’s title.
- [titleRangeSeparator](https://legacy.fullcalendar.io/v5/titleRangeSeparator.md) - Determines the separator text when formatting the date range in the toolbar title.
- [buttonText](https://legacy.fullcalendar.io/v5/buttonText.md) - Text that will be displayed on buttons of the headerToolbar/footerToolbar.
- [buttonIcons](https://legacy.fullcalendar.io/v5/buttonIcons.md) - Icons that will be displayed in buttons of the headerToolbar/footerToolbar.
- [customButtons](https://legacy.fullcalendar.io/v5/customButtons.md) - Defines custom buttons that can be used in the headerToolbar/footerToolbar.

## Demos

- [Custom buttons and a footerToolbar](https://legacy.fullcalendar.io/v5/toolbar-demo)
