# weekText

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/weekText
>
> Latest version (v7): https://fullcalendar.io/docs/weekTextShort.md

The heading text for week numbers. Also affects weeks in [date formatting](https://legacy.fullcalendar.io/v5/date-formatting.md).

<div class='spec' markdown='1'>
String, *default*: `"W"`
</div>

This text will go above the week number column in the DayGrid views. It will go alongside the week number text in the top-left cell for TimeGrid views.

The default value will change based on the current [locale](https://legacy.fullcalendar.io/v5/locale.md).
