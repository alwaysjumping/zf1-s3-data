# Calendar::formatRange

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-formatRange
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-formatRange.md

Formats two dates, a start and an end, into a string. A separator string, most likely a dash, will be intelligently inserted between the two dates. Inherits the time zone and locale settings of the calendar it's called on.

<div class='spec' markdown='1'>
calendar.formatRange( *start*, *end*, *settings* )
</div>

`start` and `end` can each be a [Date Object](https://legacy.fullcalendar.io/v5/date-object.md) or something that will [parse into a Date Object](https://legacy.fullcalendar.io/v5/date-parsing.md).

`settings` is an object that holds any of the [date format config](https://legacy.fullcalendar.io/v5/date-formatting.md) options. It also accepts the following additional properties:

- `separator` &mdash; what will be inserted between the two dates. a `' - '` by default
- `isExclusive` &mdash; if `true`, the given end date will be considered the *exclusive end* of the range, meaning date just before the `end` will be rendered instead. Useful if you need to format an exclusive-end whole-day range.

Example:

```js
import { Calendar } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';

let calendar = new Calendar(calendarEl, {
  plugins: [ dayGridPlugin ],
  timeZone: 'UTC',
  locale: 'es'
})

let str = calendar.formatRange('2018-09-01', '2018-09-15', {
  month: 'long',
  year: 'numeric',
  day: 'numeric',
  separator: ' to '
})

console.log(str) // "1 to 15 de septiembre de 2018"
```
