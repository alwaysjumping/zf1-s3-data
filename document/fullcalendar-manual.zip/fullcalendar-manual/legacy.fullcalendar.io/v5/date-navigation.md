# Date Navigation

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/date-navigation
>
> Latest version (v7): https://fullcalendar.io/docs/date-navigation.md

Methods and settings that determine the view's current dates.

## Articles

- [initialDate](https://legacy.fullcalendar.io/v5/initialDate.md) - The initial date displayed when the calendar first loads.
- [dateIncrement](https://legacy.fullcalendar.io/v5/dateIncrement.md) - How far into the future/past the calendar navigates when prev/next is executed.
- [dateAlignment](https://legacy.fullcalendar.io/v5/dateAlignment.md) - Determines the first visible day of a custom view.
- [validRange](https://legacy.fullcalendar.io/v5/validRange.md) - Limits which dates the user can navigate to and where events can go.

## Methods

- [Calendar::prev](https://legacy.fullcalendar.io/v5/Calendar-prev.md) - Moves the calendar one step back (by a month or week for example).
- [Calendar::next](https://legacy.fullcalendar.io/v5/Calendar-next.md) - Moves the calendar one step forward (by a month or week for example).
- [Calendar::prevYear](https://legacy.fullcalendar.io/v5/Calendar-prevYear.md) - Moves the calendar back one year.
- [Calendar::nextYear](https://legacy.fullcalendar.io/v5/Calendar-nextYear.md) - Moves the calendar forward one year.
- [Calendar::today](https://legacy.fullcalendar.io/v5/Calendar-today.md) - Moves the calendar to the current date.
- [Calendar::gotoDate](https://legacy.fullcalendar.io/v5/Calendar-gotoDate.md) - Moves the calendar to an arbitrary date.
- [Calendar::incrementDate](https://legacy.fullcalendar.io/v5/Calendar-incrementDate.md) - Moves the calendar forward/backward an arbitrary amount of time.
- [Calendar::getDate](https://legacy.fullcalendar.io/v5/Calendar-getDate.md) - Returns a Date for the current date of the calendar.

## See Also

- [Date Nav Links](https://legacy.fullcalendar.io/v5/date-nav-links.md) - Turns various datetime text into clickable links that the user can use for navigation.

## Demos

- [Using external buttons with date API](https://legacy.fullcalendar.io/v5/date-api-buttons-demo)
