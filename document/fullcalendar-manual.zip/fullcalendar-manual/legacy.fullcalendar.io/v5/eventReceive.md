# eventReceive

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventReceive
>
> Latest version (v7): https://fullcalendar.io/docs/eventReceive.md

Called when an [external draggable element](https://legacy.fullcalendar.io/v5/external-dragging.md) with associated [event data](https://legacy.fullcalendar.io/v5/event-parsing.md) was dropped onto the calendar. Or an event [from another calendar](https://legacy.fullcalendar.io/v5/other-calendar-dragging.md).

<div class='spec' markdown='1'>
function( *info* ) { }
</div>

`info` is a plain object with the following properties:

<table>

<tr>
<th>event</th>
<td markdown='1'>
An [Event object](https://legacy.fullcalendar.io/v5/event-object.md) containing the newly created/received event.
</td>
</tr>

<tr>
<th>relatedEvents</th>
<td>an array of other related <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Objects</a> that have also been received. an event might have other <a href='https://legacy.fullcalendar.io/v5/recurring-events.md'>recurring event</a> instances or might be linked to other events with the same <code>groupId</code></td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

<tr>
<th>draggedEl</th>
<td markdown='1'>
The HTML element that was being dragged.
</td>
</tr>

<tr>
<th>view</th>
<td markdown='1'>
The current [View Object](https://legacy.fullcalendar.io/v5/view-object.md).
</td>
</tr>

</table>

This callback is fired *before* the [eventAdd](https://legacy.fullcalendar.io/v5/eventAdd.md) callback is fired.


## Resources

When an event has been dropped on a resource, the `event`'s resources will reflect.
