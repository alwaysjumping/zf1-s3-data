# nowIndicator

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/nowIndicator
>
> Latest version (v7): https://fullcalendar.io/docs/nowIndicator.md

Whether or not to display a marker indicating the current time.

<div class='spec' markdown='1'>
Boolean. *default*: `false`
</div>

The indicator will automatically reposition itself while the user is viewing the calendar.

When set to `true` in one of the **TimeGrid** views ([view live demo](https://legacy.fullcalendar.io/v5/timegrid-nowIndicator-demo)):

<img src='https://legacy.fullcalendar.io/v5/timegrid-nowIndicator-demo.png' width='323' height='241' alt='timegrid view now-indicator' />

When set to `true` in one of the **timeline** views ([view live demo](https://legacy.fullcalendar.io/v5/timeline-nowIndicator-demo)):

<img src='https://legacy.fullcalendar.io/v5/timeline-nowIndicator-demo.png' width='331' height='227' alt='timeline view now-indicator' />
