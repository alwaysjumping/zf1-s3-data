# Sizing

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/sizing
>
> Latest version (v7): https://fullcalendar.io/docs/sizing.md

How to control the dimensions of the calendar.

## Articles

- [height](https://legacy.fullcalendar.io/v5/height.md) - Sets the height of the entire calendar, including header and footer.
- [contentHeight](https://legacy.fullcalendar.io/v5/contentHeight.md) - Sets the height of the view area of the calendar.
- [aspectRatio](https://legacy.fullcalendar.io/v5/aspectRatio.md) - Sets the width-to-height aspect ratio of the calendar.
- [expandRows](https://legacy.fullcalendar.io/v5/expandRows.md) - If the rows of a given view don’t take up the entire height, they will expand to fit.
- [updateSize](https://legacy.fullcalendar.io/v5/updateSize.md) - Immediately forces the calendar to readjusts its size.
- [handleWindowResize](https://legacy.fullcalendar.io/v5/handleWindowResize.md) - Whether to automatically resize the calendar when the browser window resizes.
- [windowResizeDelay](https://legacy.fullcalendar.io/v5/windowResizeDelay.md) - The time the calendar will wait to adjust its size after a window resize occurs, in milliseconds.
- [stickyHeaderDates](https://legacy.fullcalendar.io/v5/stickyHeaderDates.md) - Whether to fix the date-headers at the top of the calendar to the viewport while scrolling.
- [stickyFooterScrollbar](https://legacy.fullcalendar.io/v5/stickyFooterScrollbar.md) - Whether to fix the view’s horizontal scrollbar to the bottom of the viewport while scrolling.

## Callbacks

- [windowResize](https://legacy.fullcalendar.io/v5/windowResize.md) - Triggered after the calendar’s dimensions have been changed due to the browser window being resized.

## See Also

- [render](https://legacy.fullcalendar.io/v5/render.md) - Will initially render a calendar, or if it is already rendered, will rerender it.

## Demos

- [Calendar with full-height](https://legacy.fullcalendar.io/v5/full-height-demo)
