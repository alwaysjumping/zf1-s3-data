# slotMinTime

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/slotMinTime
>
> Latest version (v7): https://fullcalendar.io/docs/slotMinTime.md

Determines the first time slot that will be displayed for each day.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md), default: `"00:00:00"`
</div>

The default `"00:00:00"` means the start time will be at the very beginning of the day (midnight).

Determines the first time slot, even when the scrollbars have been scrolled all the way back.
