# eventInteractive

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventInteractive
>
> Latest version (v7): https://fullcalendar.io/docs/eventInteractive.md

Setting to `true` will cause all events to be focusable/tabbable. By default, only events that have an `event.url` property are tabbable.

<div class='spec' markdown='1'>
Boolean, default: `false`
</div>

You can set this on a per-event basis using the `event.interactive` boolean of the [event object](https://legacy.fullcalendar.io/v5/event-parsing.md).
