# resourceGroupField

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resourceGroupField
>
> Latest version (v7): https://fullcalendar.io/docs/resourceGroupField.md

Premium feature.

Visually groups resources by certain criteria.

The given argument must be a field name that each resource object has. Example:

```js
var calendar = new Calendar(calendarEl, {
  resourceGroupField: 'groupId',
  resources: [
    {
      id: 'A',
      groupId: '1',
      title: 'Resource A'
    },
    {
      id: 'B',
      groupdId: '1',
      title: 'Resource B'
    },
    {
      id: 'C',
      groupId: '2',
      title: 'Resource C'
    }
  ]
});
```

Resource groups will have a gray divider at the top of each group. The text at the top of each group will be determined by the `resourceGroupLabelContent` [resource group render hook](https://legacy.fullcalendar.io/v5/resource-group-render-hooks.md).

[See a demo of resourceGroupField](https://legacy.fullcalendar.io/v5/timeline-resourceGroupField-demo).
