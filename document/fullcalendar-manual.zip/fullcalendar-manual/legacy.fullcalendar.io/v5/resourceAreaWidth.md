# resourceAreaWidth

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resourceAreaWidth
>
> Latest version (v7): https://fullcalendar.io/docs/resourceColumnsWidth.md

Premium feature.

Determines the width of the area that contains the list of resources.

<div class='spec' markdown='1'>
*default*: `"30%"`
</div>

Can be specified as a number of pixels, or a CSS string value, like `"25%"`.
