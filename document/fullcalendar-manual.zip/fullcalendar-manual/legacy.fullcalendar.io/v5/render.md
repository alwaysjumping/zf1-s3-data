# render

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/render
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-render.md

Will initially render a calendar, or if it is already rendered, will **rerender** it.

<div class='spec' markdown='1'>
.render()
</div>

This method is integral to [initializing a calendar](https://legacy.fullcalendar.io/v5/initialize-es6.md).
