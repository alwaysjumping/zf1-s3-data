# datesAboveResources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/datesAboveResources
>
> Latest version (v7): https://fullcalendar.io/docs/datesAboveResources.md

Premium feature.

Determines if `resourceTimeGrid` or `resourceDayGrid` views should render their date headings above their resource headings.

<div class='spec' markdown='1'>
Boolean, *default*: `false`
</div>

## Screenshot:

Examples of `datesAboveResources:false` (the default) ...

<img src='https://legacy.fullcalendar.io/v5/resourcesAboveDates.png' width='600' height='474' style='margin-left:-2px' alt='dates above resources' />

Examples of `datesAboveResources:true` ...

<img src='https://legacy.fullcalendar.io/v5/datesAboveResources.png' width='600' height='476' style='margin-left:-2px' alt='dates above resources' />
