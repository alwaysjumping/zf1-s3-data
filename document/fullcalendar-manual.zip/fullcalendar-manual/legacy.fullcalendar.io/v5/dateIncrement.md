# dateIncrement

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dateIncrement
>
> Latest version (v7): https://fullcalendar.io/docs/dateIncrement.md

How far into the future/past the calendar navigates when prev/next is executed.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md)-ish input
</div>

Determines how far the calendar will jump when the user presses the prev/next buttons in the [headerToolbar](https://legacy.fullcalendar.io/v5/headerToolbar.md) or when the [prev](https://legacy.fullcalendar.io/v5/Calendar-prev.md) or [next](https://legacy.fullcalendar.io/v5/Calendar-next.md) methods are executed.

When using a standard view, it is unnecessary to specify `dateIncrement`.

When using a [Custom View](https://legacy.fullcalendar.io/v5/custom-view-with-settings.md) with a specified `duration`, the `duration` value will be the default for `dateIncrement`.
