# Resource Data

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resource-data
>
> Latest version (v7): https://fullcalendar.io/docs/resource-data.md

Premium feature.

How to get resources onto your calendar and how to manipulate resource data thereafter.

## Articles

- [resources (as an array)](https://legacy.fullcalendar.io/v5/resources-array.md) - Tells the calendar to display resources from an array input.
- [resources (as a JSON feed)](https://legacy.fullcalendar.io/v5/resources-json-feed.md) - Tells the calendar to fetch the resource list from a remote script.
- [resources (as a function)](https://legacy.fullcalendar.io/v5/resources-function.md) - A custom function for programmatically generating raw Resources objects.
- [Resource Parsing](https://legacy.fullcalendar.io/v5/resource-parsing.md) - All of the techniques for specifying resources accept an array of raw objects. These raw objects are “parsed” into proper Resource objects, which are accessible via methods like getResources and getResourceById.
- [Resource Object](https://legacy.fullcalendar.io/v5/resource-object.md) - Raw resource objects are eventually parsed into proper resource objects, which are accessible via Calendar methods such as getResources and getResourceById. You can read their properties or manipulate them via methods.
- [Associating Events with Resources](https://legacy.fullcalendar.io/v5/resources-and-events.md) - How to specify which resources your events are assigned to.
- [refetchResourcesOnNavigate](https://legacy.fullcalendar.io/v5/refetchResourcesOnNavigate.md) - Whether to refetch and rerender resources when the user navigates to a different date or changes the view.
- [initialResources](https://legacy.fullcalendar.io/v5/initialResources.md) - This is exactly like specifying resources as an array except that if the supplied value changes, the calendar will NOT be updated to reflect. Only applicable to declarative front-end frameworks such as React, Vue, and Angular.

## Methods

- [refetchResources](https://legacy.fullcalendar.io/v5/refetchResources.md) - Causes the resource data to be fetched and freshly rerendered.
- [getTopLevelResources](https://legacy.fullcalendar.io/v5/getTopLevelResources.md) - A method that retrieves only top-level Resources.
- [getResources](https://legacy.fullcalendar.io/v5/getResources.md) - A method that retrieves all Resources, including children, as a single flat list.
- [getResourceById](https://legacy.fullcalendar.io/v5/getResourceById.md) - A method that retrieves a specific Resource Object in memory.
- [addResource](https://legacy.fullcalendar.io/v5/addResource.md) - Adds a new resource to the calendar after the initial resources have been displayed.
- [Resource::getParent](https://legacy.fullcalendar.io/v5/Resource-getParent.md) - Returns the parent Resource of a child resource.
- [Resource::getChildren](https://legacy.fullcalendar.io/v5/Resource-getChildren.md) - Returns a list of a resource’s child resources.
- [Resource::getEvents](https://legacy.fullcalendar.io/v5/Resource-getEvents.md) - Retrieves a list of Event Objects that are associated with the given resource.
- [Resource::setProp](https://legacy.fullcalendar.io/v5/Resource-setProp.md) - Modifies any of the properties of a Resource Object.
- [Resource::setExtendedProp](https://legacy.fullcalendar.io/v5/Resource-setExtendedProp.md) - Modifies a single property in an Resource Object’s extendedProps hash.
- [Resource::remove](https://legacy.fullcalendar.io/v5/Resource-remove.md) - Programmatically removes a resource from the calendar.
- [Resource::toPlainObject](https://legacy.fullcalendar.io/v5/Resource-toPlainObject.md) - Serializes a Resource API Object to a plain object that would be fit for JSON.stringify.

## Callbacks

- [resourceAdd](https://legacy.fullcalendar.io/v5/resourceAdd.md) - Called after a resource has been added to the calendar.
- [resourceChange](https://legacy.fullcalendar.io/v5/resourceChange.md) - Called after a resource has been modified in some way.
- [resourceRemove](https://legacy.fullcalendar.io/v5/resourceRemove.md) - Called after a resource has been removed from the calendar.
- [resourcesSet](https://legacy.fullcalendar.io/v5/resourcesSet.md) - Called after resource data is initialized OR changed in any way.

## See Also

- [Event::getResources](https://legacy.fullcalendar.io/v5/Event-getResources.md) - Gets the Resources associated with the given event.
- [Event::setResources](https://legacy.fullcalendar.io/v5/Event-setResources.md) - Sets the Resources associated with the given event.
- [businessHours-per-resource](https://legacy.fullcalendar.io/v5/businessHours-per-resource.md) - The main businessHours settings can be applied more granularly to individual resources via the businessHours property on the Resource input
- [loading](https://legacy.fullcalendar.io/v5/loading.md) - Triggered when event or resource fetching starts/stops.

## Demos

- [Add resources dynamically with addResource](https://legacy.fullcalendar.io/v5/addResource-demo)
