# Calendar::unselect

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-unselect
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-unselect.md

A method for programmatically clearing the current selection.

<div class='spec' markdown='1'>
calendar.unselect()
</div>
