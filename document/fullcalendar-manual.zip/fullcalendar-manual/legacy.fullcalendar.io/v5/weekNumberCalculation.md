# weekNumberCalculation

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/weekNumberCalculation
>
> Latest version (v7): https://fullcalendar.io/docs/weekNumberCalculation.md

The method for calculating week numbers that are displayed with the [weekNumbers](https://legacy.fullcalendar.io/v5/weekNumbers.md) setting.

<div class='spec' markdown='1'>
`"local"` (default), `"ISO"`, or a function
</div>

Specifying `"local"` causes the locale-specific calculation to be used, as determined by the calendar's [locale](https://legacy.fullcalendar.io/v5/locale.md) setting. This is the default.

Specifiying `"ISO"` results in [ISO8601 week numbers](https://en.wikipedia.org/wiki/ISO_8601#Week_dates). Specifying `"ISO"` changes the default value of [firstDay](https://legacy.fullcalendar.io/v5/firstDay.md) to `1` (Monday).

You may also specify a function, which must accept a single [Date](https://legacy.fullcalendar.io/v5/date-object.md) and return an integer week number.
