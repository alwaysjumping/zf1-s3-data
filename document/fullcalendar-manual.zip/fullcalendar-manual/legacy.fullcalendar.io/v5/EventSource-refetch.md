# EventSource::refetch

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/EventSource-refetch
>
> Latest version (v7): https://fullcalendar.io/docs/EventSource-refetch.md

Causes this event source to fetch its event data again.

<div class='spec' markdown='1'>
eventSource.refetch()
</div>

Must be called on an Event Source instance. See [getEventSources](https://legacy.fullcalendar.io/v5/Calendar-getEventSources.md) and [getEventSourceById](https://legacy.fullcalendar.io/v5/Calendar-getEventSourceById.md).
