# eventDragMinDistance

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventDragMinDistance
>
> Latest version (v7): https://fullcalendar.io/docs/eventDragMinDistance.md

How many pixels the user's mouse/touch must move before an event drag activates.

<div class='spec' markdown='1'>
Integer, *default:* `5`
</div>
