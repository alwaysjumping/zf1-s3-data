# Custom Views

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/custom-views
>
> Latest version (v7): https://fullcalendar.io/docs/custom-views.md

It's possible to take a pre-defined view that FullCalendar provides and create your own view that spans a different period of time. You can even code your own view from scratch with JS.

## Techniques

- [Custom Views via Settings](https://legacy.fullcalendar.io/v5/custom-view-with-settings.md) - It is possible to customize an existing available view by tweaking settings.
- [Custom Views via JS](https://legacy.fullcalendar.io/v5/custom-view-with-js.md) - For advanced developers, FullCalendar provides an API for building custom views with the unlimited flexibility of JavaScript code.

## Duration Settings

- [duration](https://legacy.fullcalendar.io/v5/duration.md) - Sets the exact duration of a custom view.
- [dayCount](https://legacy.fullcalendar.io/v5/dayCount.md) - Sets the exact number of days displayed in a custom view, regardless of weekends or hiddenDays.
- [visibleRange](https://legacy.fullcalendar.io/v5/visibleRange.md) - Sets the exact date range that is visible in a view.

## Demos

- [Custom 4-day TimeGrid view](https://legacy.fullcalendar.io/v5/timegrid-custom-view-demo)
- [Custom 4-day vertical resource view](https://legacy.fullcalendar.io/v5/vertical-resource-custom-demo)
- [Custom-duration timeline views](https://legacy.fullcalendar.io/v5/timeline-custom-view-demo)
