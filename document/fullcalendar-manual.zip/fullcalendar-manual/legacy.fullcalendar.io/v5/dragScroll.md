# dragScroll

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dragScroll
>
> Latest version (v7): https://fullcalendar.io/docs/dragScroll.md

Whether to automatically scoll the scroll-containers during event drag-and-drop and date selecting.

<div class='spec' markdown='1'>
Boolean, *default*: true
</div>

If enabled, the scroll container will automatically scroll once the mouse gets close to the edge.
