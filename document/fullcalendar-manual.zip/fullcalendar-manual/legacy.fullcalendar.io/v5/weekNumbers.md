# weekNumbers

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/weekNumbers
>
> Latest version (v7): https://fullcalendar.io/docs/weekNumbers.md

Determines if week numbers should be displayed on the calendar.

<div class='spec' markdown='1'>
Boolean, *default*: `false`
</div>

If set to `true`, week numbers will be displayed on the side of each row of days in Month/DayGrid views as well as at the top-left corner of the TimeGrid views. [View a simple demo](https://legacy.fullcalendar.io/v5/weekNumbers-demo).

By default, FullCalendar will use the current locale's week number calculation method. To display other types of week numbers, see [weekNumberCalculation](https://legacy.fullcalendar.io/v5/weekNumberCalculation.md).
