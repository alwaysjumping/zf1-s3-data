# resourcesSet

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resourcesSet
>
> Latest version (v7): https://fullcalendar.io/docs/resourcesSet.md

Premium feature.

Called after resource data is initialized **OR** changed in any way.

<div class='spec'>
function( resources )
</div>

`resources` is an array of [Resource Objects](https://legacy.fullcalendar.io/v5/resource-object.md). It contains the same result [Calendar::getResources](https://legacy.fullcalendar.io/v5/getResources.md) would return.

This callback will be useful for syncing an external data source with all calendar resource data.
