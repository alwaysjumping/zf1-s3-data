# Timeline View with no Resources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/timeline-view-no-resources
>
> Latest version (v7): https://fullcalendar.io/docs/timeline-view-no-resources.md

Premium feature.

You might like the way the time axis operates in Timeline view, but you simply don't want to display resource rows. If this is the case, you can initialize a plain timeline view in an [ES6 setup](https://legacy.fullcalendar.io/v5/initialize-es6.md) like so:

```js
import { Calendar } from '@fullcalendar/core';
import timelinePlugin from '@fullcalendar/timeline';
...
let calendar = new Calendar(calendarEl, {
  plugins: [ timelinePlugin ],
  initialView: 'timelineWeek'
});
...
```

Or, you can choose to initialize Timeline view with the `fullcalendar-scheduler` [global bundle](https://legacy.fullcalendar.io/v5/initialize-globals.md):

```html
<link href='fullcalendar-scheduler/main.css' rel='stylesheet' />
<script src='fullcalendar-scheduler/main.js'></script>
<script>
...
var calendar = new FullCalendar.Calendar(calendarEl, {
  initialView: 'timelineWeek'
});
...
</script>
```
