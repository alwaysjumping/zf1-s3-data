# Calendar::gotoDate

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-gotoDate
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-gotoDate.md

Moves the calendar to an arbitrary date.

<div class='spec' markdown='1'>
calendar.gotoDate( date )
</div>

`date` is a [parsable Date](https://legacy.fullcalendar.io/v5/date-parsing.md)
