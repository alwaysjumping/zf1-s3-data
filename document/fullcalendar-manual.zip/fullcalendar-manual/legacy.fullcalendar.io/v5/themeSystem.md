# themeSystem

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/themeSystem
>
> Upgrading to v7: https://fullcalendar.io/docs/upgrading-from-v6.md

Renders the calendar with a given theme system.

<div class='spec' markdown='1'>
String, *default*: `'standard'`
</div>

`'standard'`
: Renders a minimal look & feel, the look in most of the [demos](https://fullcalendar.io/demos). Does not require any CSS files beyond the FullCalendar base files.

`'bootstrap5'`
: Prepares the calendar for a [Bootstrap 5](https://getbootstrap.com/) theme. [Further instructions &raquo;](https://legacy.fullcalendar.io/v5/bootstrap5.md)

`'bootstrap'`
: Prepares the calendar for a [Bootstrap 4](https://getbootstrap.com/docs/4.6/getting-started/introduction/) theme. [Further instructions &raquo;](https://legacy.fullcalendar.io/v5/bootstrap4.md)
