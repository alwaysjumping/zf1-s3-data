# Calendar::getEventSourceById

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-getEventSourceById
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-getEventSourceById.md

Retrieves a specific [Event Source Object](https://legacy.fullcalendar.io/v5/event-source-object.md).

<div class='spec' markdown='1'>
calendar.getEventSourceById( id )
</div>

Will retrieve the Event Source Object with the given `id` property.
