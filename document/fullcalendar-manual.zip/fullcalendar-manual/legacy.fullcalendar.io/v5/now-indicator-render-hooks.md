# Now-Indicator Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/now-indicator-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/now-indicator-line-render-hooks.md

`nowIndicatorClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`nowIndicatorContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`nowIndicatorDidMount`

`nowIndicatorWillUnmount`


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `isAxis` - boolean
- `date` - Date object
- `el` - the element. only available in `nowIndicatorDidMount` and `nowIndicatorWillUnmount`
