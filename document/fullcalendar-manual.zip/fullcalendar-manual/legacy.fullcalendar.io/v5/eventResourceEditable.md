# eventResourceEditable

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventResourceEditable
>
> Latest version (v7): https://fullcalendar.io/docs/eventResourceEditable.md

Premium feature.

Determines whether the user can drag events between resources.

<div class='spec' markdown='1'>
Boolean
</div>

The default value is inherited from the master [editable](https://legacy.fullcalendar.io/v5/editable.md) flag, which is `false` by default.

You must enable the `interaction` plugin before using this setting.
<a href='https://legacy.fullcalendar.io/v5/editable.md' class='more-link'>See code samples on the `editable` article</a>

A variation of this property called `resourceEditable` can be set on an [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) for more granular control:

```js
var calendar = new Calendar(calendarEl, {
  initialView: 'timelineWeek',
  resources: [
    // resource data...
  ],
  editable: true, // event resources editable by default
  events: [
    // event data...
    {
      title: 'my event',
      start: '2016-01-01',
      resourceEditable: false // resource not editable for this event
    }
  ]
});
```

A similar technique can be used on [Event Source Objects](https://legacy.fullcalendar.io/v5/event-source-object.md).


## Preventing date changes, but allowing resource changes

If you'd like to allow the user to drag-n-drop an event to a different resource, you can set the master `editable` flag to `false`, but override it specifically for event resources:

```js
var calendar = new Calendar(calendarEl, {
  initialView: 'timeline',
  editable: false, // don't allow event dragging
  eventResourceEditable: true // except for between resources

  // resource and event data...
});
```
