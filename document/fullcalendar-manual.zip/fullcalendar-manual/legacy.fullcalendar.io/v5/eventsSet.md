# eventsSet

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventsSet
>
> Latest version (v7): https://fullcalendar.io/docs/eventsSet.md

Called after event data is initialized **OR** changed in any way.

<div class='spec'>
function( events )
</div>

`events` is an array of [Event Objects](https://legacy.fullcalendar.io/v5/event-object.md). It contains every event in memory, the same result [Calendar::getEvents](https://legacy.fullcalendar.io/v5/Calendar-getEvents.md) would return.

This callback will be useful for syncing an external data source with all calendar event data.
