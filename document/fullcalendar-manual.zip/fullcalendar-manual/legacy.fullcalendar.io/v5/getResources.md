# getResources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/getResources
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-getResources.md

Premium feature.

A method that retrieves all [Resources](https://legacy.fullcalendar.io/v5/resource-object.md), including children, as a single flat list.

<div class='spec' markdown='1'>
.getResources()
</div>

If you want to retrieve a list of *top-level* resources (resources that are not children of any other resource), then use [getTopLevelResources](https://legacy.fullcalendar.io/v5/getTopLevelResources.md) instead.
