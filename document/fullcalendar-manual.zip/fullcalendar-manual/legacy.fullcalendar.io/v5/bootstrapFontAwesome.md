# bootstrapFontAwesome

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/bootstrapFontAwesome
>
> Upgrading to v7: https://fullcalendar.io/docs/upgrading-from-v6.md

Determines which icons are displayed in buttons of the headerToolbar/footerToolbar when [Bootstrap **4** theming](https://legacy.fullcalendar.io/v5/bootstrap4.md) is on.
This setting does **not** apply to [Bootstrap **5** theming](https://legacy.fullcalendar.io/v5/bootstrap5.md). Use [buttonIcons](https://legacy.fullcalendar.io/v5/buttonIcons.md) instead.

<div class='spec' markdown='1'>
Object, *default:*

```js
{
  close: 'fa-times',
  prev: 'fa-chevron-left',
  next: 'fa-chevron-right',
  prevYear: 'fa-angle-double-left',
  nextYear: 'fa-angle-double-right'
}
```
</div>

This option only applies to calendars that have [themeSystem](https://legacy.fullcalendar.io/v5/themeSystem.md) set to `'bootstrap'` (Bootstrap 4). A FontAwesome stylesheet must be loaded before you can use Bootstrap 4 theming or customize the icons. [Getting started with FontAwesome](https://fontawesome.com/get-started).

A hash must be supplied that maps button names (from the [headerToolbar](https://legacy.fullcalendar.io/v5/headerToolbar.md)) to icon strings. [See a full list of FontAwesome icons](https://fontawesome.com/icons).

If a button does not have an entry, it falls back to using [buttonText](https://legacy.fullcalendar.io/v5/buttonText.md).

If you are using a Bootstrap theme and would prefer not to display any icons and would rather use `buttonText` instead, you can set the `bootstrapFontAwesome` option to `false`.
