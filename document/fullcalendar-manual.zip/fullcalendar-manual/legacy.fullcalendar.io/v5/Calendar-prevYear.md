# Calendar::prevYear

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-prevYear
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-prevYear.md

Moves the calendar back one year.

<div class='spec' markdown='1'>
calendar.prevYear()
</div>
