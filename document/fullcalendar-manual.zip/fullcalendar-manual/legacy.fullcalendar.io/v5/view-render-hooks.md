# View Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/view-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/view-render-hooks.md

## Hooks

`viewClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md) for adding classNames to the root view element. Called whenever the view changes.

`viewDidMount` - called right after the view has been added to the DOM

`viewWillUnmount` - called right before the view will be removed from the DOM


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `view` - a [View Object](https://legacy.fullcalendar.io/v5/view-object.md)
- `el` - the view's root HTML element. not available in `viewClassNames`
