# eventDataTransform

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventDataTransform
>
> Latest version (v7): https://fullcalendar.io/docs/eventDataTransform.md

A hook for transforming custom data into a standard [Event object](https://legacy.fullcalendar.io/v5/event-parsing.md).

<div class='spec' markdown='1'>
function( *eventData* ) {}
</div>

This hook allows you to receive arbitrary event data from a JSON feed or any other [Event Source](https://legacy.fullcalendar.io/v5/event-source-object.md) and transform it into the type of data FullCalendar accepts. This let's you easily accept alternative data formats without having to write a completely custom [events function](https://legacy.fullcalendar.io/v5/events-function.md).

This function is called once per received event. `eventData` is the event data that has been receieved. The function must return a [parsable Event object](https://legacy.fullcalendar.io/v5/event-parsing.md) or `false`, which will discard the event.

This function is **not** called for the [addEvent](https://legacy.fullcalendar.io/v5/Calendar-addEvent.md) method.

If you want to receive a non-standard root object from your event sources that is *not* an array, return a value from your [eventSourceSuccess](https://legacy.fullcalendar.io/v5/eventSourceSuccess.md) callback.
