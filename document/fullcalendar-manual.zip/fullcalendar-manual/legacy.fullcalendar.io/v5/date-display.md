# Date & Time Display

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/date-display
>
> Latest version (v7): https://fullcalendar.io/docs/date-display.md

Settings that control presence/absence of dates as well as their styling and text. These settings work across a variety of different views.

## Whole-day Settings

- [weekends](https://legacy.fullcalendar.io/v5/weekends.md) - Whether to include Saturday/Sunday columns in any of the calendar views.
- [hiddenDays](https://legacy.fullcalendar.io/v5/hiddenDays.md) - Exclude certain days-of-the-week from being displayed.
- [dayHeaders](https://legacy.fullcalendar.io/v5/dayHeaders.md) - Whether the day headers should appear. For the Month, TimeGrid, and DayGrid views.
- [dayHeaderFormat](https://legacy.fullcalendar.io/v5/dayHeaderFormat.md) - Determines the text that will be displayed on the calendar’s column headings.
- [dayMinWidth](https://legacy.fullcalendar.io/v5/dayMinWidth.md) - A minimum width for day cells, past which the calendar scrolls horizontally. When the calendar gets narrow enough that day cells can no longer meet their dayMinWidth, horizontal scrollbars appear.
- [Day-Header Render Hooks](https://legacy.fullcalendar.io/v5/day-header-render-hooks.md) - Customize the header elements above the day cells in daygrid and timegrid views with the following options. The same options also apply to the title elements for each day in list view. For the timeline view, see the slot render hooks.
- [Day-Cell Render Hooks](https://legacy.fullcalendar.io/v5/day-cell-render-hooks.md)

## Time-Axis Settings

- [slotDuration](https://legacy.fullcalendar.io/v5/slotDuration.md) - The frequency for displaying time slots.
- [slotLabelInterval](https://legacy.fullcalendar.io/v5/slotLabelInterval.md) - The frequency that the time slots should be labeled with text.
- [slotLabelFormat](https://legacy.fullcalendar.io/v5/slotLabelFormat.md) - Determines the text that will be displayed within a time slot.
- [slotMinTime](https://legacy.fullcalendar.io/v5/slotMinTime.md) - Determines the first time slot that will be displayed for each day.
- [slotMaxTime](https://legacy.fullcalendar.io/v5/slotMaxTime.md) - Determines the last time slot that will be displayed for each day. In line with the discussion about the Event object, it is important to stress that this should be specified as an exclusive end time.
- [scrollTime](https://legacy.fullcalendar.io/v5/scrollTime.md) - Determines how far forward the scroll pane is initially scrolled.
- [scrollTimeReset](https://legacy.fullcalendar.io/v5/scrollTimeReset.md) - Whether the view should scroll to scrollTime every time the date range changes.
- [Slot Render Hooks](https://legacy.fullcalendar.io/v5/slot-render-hooks.md) - The horizontal time slots in timegrid view or the vertical datetime slots in timeline view.

## Methods

- [scrollToTime](https://legacy.fullcalendar.io/v5/scrollToTime.md) - Programatically scroll the current view to the given time.

## Callbacks

- [datesSet](https://legacy.fullcalendar.io/v5/datesSet.md) - Called after the calendar’s date range has been initially set or changed in some way and the DOM has been updated.

## See Also

- [firstDay](https://legacy.fullcalendar.io/v5/firstDay.md) - The day that each week begins.
- [showNonCurrentDates](https://legacy.fullcalendar.io/v5/showNonCurrentDates.md) - In month view, whether dates in the previous or next month should be rendered at all.
