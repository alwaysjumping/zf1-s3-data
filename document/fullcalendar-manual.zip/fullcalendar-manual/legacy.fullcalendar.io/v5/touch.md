# Touch Support

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/touch
>
> Latest version (v7): https://fullcalendar.io/docs/touch.md

FullCalendar's Touch support includes smooth scrolling, time-range selection via long-press, and event drag-n-drop/resizing via long-press.

On a touch device, for the user to begin drag-n-dropping events, **they must first tap-and-hold on the event in order to "select" it!**

## Articles

- [longPressDelay](https://legacy.fullcalendar.io/v5/longPressDelay.md) - For touch devices, the amount of time the user must hold down before an event becomes draggable or a date becomes selectable.
- [eventLongPressDelay](https://legacy.fullcalendar.io/v5/eventLongPressDelay.md) - For touch devices, the amount of time the user must hold down before an event becomes draggable.
- [selectLongPressDelay](https://legacy.fullcalendar.io/v5/selectLongPressDelay.md) - For touch devices, the amount of time the user must hold down before a date becomes selectable.

## Images

![Example of a TimeGrid view event in the selected state](https://legacy.fullcalendar.io/v5/touch-timegrid.png)

![Example of a Timeline view event in the selected state](https://legacy.fullcalendar.io/v5/touch-scheduler.png)
