# nextDayThreshold

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/nextDayThreshold
>
> Latest version (v7): https://fullcalendar.io/docs/nextDayThreshold.md

How far an event must run into the next day before it renders on that day. It applies when an event's end time spans into another day.

<div class='spec' markdown='1'>
Duration, default: `"00:00:00"`
</div>

Only affects timed events that appear on whole-days. Whole-day cells occur in [DayGrid views](https://legacy.fullcalendar.io/v5/daygrid-view.md) and the all-day slots in the [TimeGrid views](https://legacy.fullcalendar.io/v5/timegrid-view.md).

For example, if `nextDayThreshold` were `'09:00'` (9am), the following event would appear to take up only one day:

```js
  var calendar = new Calendar(calendarEl, {
    // other options...
    nextDayThreshold: '09:00:00',
    events: [
      {
        // Goes from 8pm to 2am the next day.
        title: 'Event 1',
        start: '2014-02-04T20:00:00',
        end: '2014-02-05T02:00:00'
      }
    ]
  });
```

Whereas, the following event would appear to take up two days:

```js
  var calendar = new Calendar(calendarEl, {
    // other options...
    nextDayThreshold: '09:00:00',
    events: [
      {
        // Goes from 8pm to 10am the next day.
        title: 'Event 2',
        start: '2014-02-04T20:00:00',
        end: '2014-02-05T10:00:00'
      }
    ]
  });
```

It is important to stress that this `nextDayThreshold` option, set on the Calendar itself, is ignored when `allDay` is `true`. Generally, as discussed when defining an [Event object](https://legacy.fullcalendar.io/v5/event-parsing.md), `allDay`, `start` and `end` properties are sufficient for specifying an event that lasts an entire day.

However, when `allDay` is `false`, this additional `nextDayThreshold` property allows an override of the default behavior of exclusive end dates by setting the cut-off point (or minimum) for the event to be rendered on that date.
