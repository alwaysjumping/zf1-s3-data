# Event Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/event-render-hooks.md

Customize the rendering of event elements with the following options:

`eventClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md) for adding classNames to the outermost event element. If supplied as a callback function, it is called every time the associated event data changes.

`eventContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md). Generated content is inserted *inside* the inner-most wrapper of the event element. If supplied as a callback function, it is called every time the associated event data changes.

`eventDidMount` - called right after the element has been added to the DOM. If the event data changes, this is NOT called again.

`eventWillUnmount` - called right before the element will be removed from the DOM.


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `event` - [Event Object](https://legacy.fullcalendar.io/v5/event-object.md)
- `timeText`
- `isStart`
- `isEnd`
- `isMirror`
- `isPast`
- `isFuture`
- `isToday`
- `el` - the element. only available in `eventDidMount` and `eventWillUnmount`
- `view` - [View Object](https://legacy.fullcalendar.io/v5/view-object.md)
