# Event Sources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-source
>
> Latest version (v7): https://fullcalendar.io/docs/event-source.md

## Articles

- [events (as an array)](https://legacy.fullcalendar.io/v5/events-array.md) - An array of Event Objects that will be displayed on the calendar.
- [events (as a json feed)](https://legacy.fullcalendar.io/v5/events-json-feed.md) - A URL of a JSON feed that the calendar will fetch Event Objects from.
- [events (as a function)](https://legacy.fullcalendar.io/v5/events-function.md) - A custom function for programmatically generating Events.
- [events from Google Calendar](https://legacy.fullcalendar.io/v5/google-calendar.md) - FullCalendar can display events from a public Google Calendar.
- [events from an iCalendar feed](https://legacy.fullcalendar.io/v5/icalendar.md) - FullCalendar can display events from a public iCalendar feed.
- [Event Source Object](https://legacy.fullcalendar.io/v5/event-source-object.md) - An “event source” is anything that provides FullCalendar with data about events.
- [eventSources](https://legacy.fullcalendar.io/v5/eventSources.md) - A way to specify multiple event sources.
- [eventSourceSuccess](https://legacy.fullcalendar.io/v5/eventSourceSuccess.md) - A function that gets called when fetching succeeds. It can transform the response. Gets called for any type of Event source.
- [eventSourceFailure](https://legacy.fullcalendar.io/v5/eventSourceFailure.md) - Called when any of the event sources fails. Probably because an AJAX request failed.
- [initialEvents](https://legacy.fullcalendar.io/v5/initialEvents.md) - This is exactly like specifying events as an array except that if the supplied value changes, the calendar will NOT be updated to reflect. Only applicable to declarative front-end frameworks such as React, Vue, and Angular.

## Event Requesting

- [startParam](https://legacy.fullcalendar.io/v5/startParam.md) - A parameter of this name will be sent to each JSON event feed. It describes the start of the interval being fetched.
- [endParam](https://legacy.fullcalendar.io/v5/endParam.md) - A parameter of this name will be sent to each JSON event feed. It describes the exclusive end of the interval being fetched.
- [timeZoneParam](https://legacy.fullcalendar.io/v5/timeZoneParam.md) - A parameter of this name will be sent to each JSON event feed. It describes the timezone of the startParam and endParam values, as well as the desired timezone of the returned events.
- [lazyFetching](https://legacy.fullcalendar.io/v5/lazyFetching.md) - Determines when event fetching should occur.
- [loading](https://legacy.fullcalendar.io/v5/loading.md) - Triggered when event or resource fetching starts/stops.

## Methods

- [Calendar::getEventSources](https://legacy.fullcalendar.io/v5/Calendar-getEventSources.md) - Retrieves all Event Source Objects.
- [Calendar::getEventSourceById](https://legacy.fullcalendar.io/v5/Calendar-getEventSourceById.md) - Retrieves a specific Event Source Object.
- [Calendar::addEventSource](https://legacy.fullcalendar.io/v5/Calendar-addEventSource.md) - Dynamically adds an event source.
- [Calendar::refetchEvents](https://legacy.fullcalendar.io/v5/Calendar-refetchEvents.md) - Refetches events from all sources and rerenders them on the screen.
- [EventSource::refetch](https://legacy.fullcalendar.io/v5/EventSource-refetch.md) - Causes this event source to fetch its event data again.
- [EventSource::remove](https://legacy.fullcalendar.io/v5/EventSource-remove.md) - Removes all events associated with this source and prevents it from being fetched again.

## Demos

- [US holidays from Google Calendar](https://legacy.fullcalendar.io/v5/google-calendar-demo)
