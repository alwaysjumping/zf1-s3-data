# addResource

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/addResource
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-addResource.md

Premium feature.

Adds a new resource to the calendar after the initial resources have been displayed.

<div class='spec' markdown='1'>
.addResource( resource, [ scrollTo ] )
</div>

The `resource` argument should be an object with [raw Resource properties](https://legacy.fullcalendar.io/v5/resource-parsing.md) properties. Example:

```js
var calendar = new Calendar(calendarEl, {
  // options
});

calendar.addResource({
  id: 'e',
  title: 'Room E'
});
```

If you would like the new resource to be a child of an existing resource, make sure to set its `parentId`. This method will return the parsed [Resource](https://legacy.fullcalendar.io/v5/resource-object.md) with methods such as [getEvents](https://legacy.fullcalendar.io/v5/Resource-getEvents.md).

You may also specify an existing parsed Resource if it has previouisly been removed.

The `scrollTo` argument will scroll the current view to the newly added resource. It is optional and `true` by default. To disable this behavior, specify `false`.


[View a demo](https://legacy.fullcalendar.io/v5/addResource-demo) that utilizes addResource.
