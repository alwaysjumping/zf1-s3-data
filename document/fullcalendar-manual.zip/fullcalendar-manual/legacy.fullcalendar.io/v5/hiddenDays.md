# hiddenDays

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/hiddenDays
>
> Latest version (v7): https://fullcalendar.io/docs/hiddenDays.md

Exclude certain days-of-the-week from being displayed.

<div class='spec' markdown='1'>
Array, *default*: `[]`
</div>

The value is an array of day-of-week indices to hide. Each index is zero-base (Sunday=`0`) and ranges from `0-6`. Example:

```js
hiddenDays: [ 2, 4 ] // hide Tuesdays and Thursdays

hiddenDays: [ 1, 3, 5 ] // hide Mondays, Wednesdays, and Fridays
```

By default, no days are hidden, unless [weekends](https://legacy.fullcalendar.io/v5/weekends.md) is set to `false`.
