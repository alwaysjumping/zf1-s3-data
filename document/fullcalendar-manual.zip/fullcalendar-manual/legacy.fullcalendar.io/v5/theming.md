# Theme

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/theming
>
> Latest version (v7): https://fullcalendar.io/docs/theming.md

It is possible to change the look of the calendar (colors, fonts, etc) by applying a *theme*.

## Articles

- [themeSystem](https://legacy.fullcalendar.io/v5/themeSystem.md) - Renders the calendar with a given theme system.
- [Bootstrap 5 Theming](https://legacy.fullcalendar.io/v5/bootstrap5.md) - In order to correctly theme your calendar with a Bootstrap 5 theme, you must include the correct stylesheets, include the JavaScript plugin, and set themeSystem to 'bootstrap5'.
- [Bootstrap 4 Theming](https://legacy.fullcalendar.io/v5/bootstrap4.md) - In order to correctly theme your calendar with a Bootstrap 4 theme, you must include the correct stylesheets, include the JavaScript plugin, and set themeSystem to 'bootstrap'.
- [bootstrapFontAwesome](https://legacy.fullcalendar.io/v5/bootstrapFontAwesome.md) - Determines which icons are displayed in buttons of the headerToolbar/footerToolbar when Bootstrap 4 theming is on. This setting does not apply to Bootstrap 5 theming. Use buttonIcons instead.

## Demos

- [Bootstrap 5 theme](https://legacy.fullcalendar.io/v5/bootstrap5-demo)
