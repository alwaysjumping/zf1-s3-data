# windowResizeDelay

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/windowResizeDelay
>
> Upgrading to v7: https://fullcalendar.io/docs/upgrading-from-v6.md

The time the calendar will wait to adjust its size after a window resize occurs, in milliseconds.

<div class='spec' markdown='1'>
Integer. *default:* `100`
</div>

This delay exists in order to prevent overly frequent size adjustments while the user drags and resizes their browser window.
