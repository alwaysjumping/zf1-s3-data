# eventMinHeight

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventMinHeight
>
> Latest version (v7): https://fullcalendar.io/docs/eventMinHeight.md

In **timeGrid** view, the minimum height an event is allowed to be.

<div class='spec' markdown='1'>
Number, *default*: `15`
</div>
