# Resource DayGrid View

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resource-daygrid-view
>
> Latest version (v7): https://fullcalendar.io/docs/resource-daygrid-view.md

Premium feature.

A [DayGrid view](https://legacy.fullcalendar.io/v5/daygrid-view.md) like `dayGridDay` can be given resource functionality. It is initialized in an [ES6 setup](https://legacy.fullcalendar.io/v5/initialize-es6.md) like so:

```
npm install --save @fullcalendar/core @fullcalendar/resource-daygrid
```

```js
import { Calendar } from '@fullcalendar/core';
import resourceDayGridPlugin from '@fullcalendar/resource-daygrid';
...
let calendar = new Calendar(calendarEl, {
  plugins: [ resourceDayGridPlugin ],
  initialView: 'resourceDayGridDay',
  resources: [
    // your list of resources
  ]
});
...
```

Or, you can choose to initialize Resource DayGrid view with the `fullcalendar-scheduler` [global bundle](https://legacy.fullcalendar.io/v5/initialize-globals.md):

```html
<link href='fullcalendar-scheduler/main.css' rel='stylesheet' />
<script src='fullcalendar-scheduler/main.js'></script>
<script>
...
var calendar = new FullCalendar.Calendar(calendarEl, {
  initialView: 'resourceDayGridDay',
  resources: [
    // your list of resources
  ]
});
...
</script>
```
