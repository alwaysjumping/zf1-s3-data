# TimeGrid View

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/timegrid-view
>
> Latest version (v7): https://fullcalendar.io/docs/timegrid-view.md

A TimeGrid view displays one or more days side by side, against a vertical axis of time. The time axis usually runs from midnight to midnight. The two predefined TimeGrid views are the **timeGridWeek** and **timeGridDay** views. They can be initialized in an [ES6 setup](https://legacy.fullcalendar.io/v5/initialize-es6.md) like so:

```js
import { Calendar } from '@fullcalendar/core';
import timeGridPlugin from '@fullcalendar/timegrid';
...
let calendar = new Calendar(calendarEl, {
  plugins: [ timeGridPlugin ],
  initialView: 'timeGridWeek'
});
...
```

Or you can choose to initialized the TimeGrid views [as a global bundle](https://legacy.fullcalendar.io/v5/initialize-globals.md):

```html
<link href='fullcalendar/main.css' rel='stylesheet' />
<script src='fullcalendar/main.js'></script>
<script>
...
var calendar = new FullCalendar.Calendar(calendarEl, {
  initialView: 'timeGridWeek'
});
...
</script>
```

TimeGrid views of other durations can be made with a [custom view](https://legacy.fullcalendar.io/v5/custom-view-with-settings.md) with type `'timeGrid'`.

The following options are specific to TimeGrid view. However, there are numerous other options throughout the docs that affect the display of TimeGrid view, such as the [date/time display options](https://legacy.fullcalendar.io/v5/date-display.md) and [locale-related options](https://legacy.fullcalendar.io/v5/localization.md).

## TimeGrid-specific Options

- [eventMinHeight](https://legacy.fullcalendar.io/v5/eventMinHeight.md) - In timeGrid view, the minimum height an event is allowed to be.
- [eventShortHeight](https://legacy.fullcalendar.io/v5/eventShortHeight.md) - In timeGrid view, the height threshold for when an event has a “short” style.
- [slotEventOverlap](https://legacy.fullcalendar.io/v5/slotEventOverlap.md) - Determines if timed events in TimeGrid view should visually overlap.
- [allDaySlot](https://legacy.fullcalendar.io/v5/allDaySlot.md) - Determines if the “all-day” slot is displayed at the top of the calendar.
- [All-Day Render Hooks](https://legacy.fullcalendar.io/v5/all-day-render-hooks.md) - Customize parts of the UI that typically display the text “all-day”.

## See Also

- [eventMaxStack](https://legacy.fullcalendar.io/v5/eventMaxStack.md) - For timeline view, the maximum number of events that stack top-to-bottom. For timeGrid view, the maximum number of events that stack left-to-right.
- [slotDuration](https://legacy.fullcalendar.io/v5/slotDuration.md) - The frequency for displaying time slots.
- [slotLabelFormat](https://legacy.fullcalendar.io/v5/slotLabelFormat.md) - Determines the text that will be displayed within a time slot.
- [slotLabelInterval](https://legacy.fullcalendar.io/v5/slotLabelInterval.md) - The frequency that the time slots should be labeled with text.
- [slotMinTime](https://legacy.fullcalendar.io/v5/slotMinTime.md) - Determines the first time slot that will be displayed for each day.
- [slotMaxTime](https://legacy.fullcalendar.io/v5/slotMaxTime.md) - Determines the last time slot that will be displayed for each day. In line with the discussion about the Event object, it is important to stress that this should be specified as an exclusive end time.
- [expandRows](https://legacy.fullcalendar.io/v5/expandRows.md) - If the rows of a given view don’t take up the entire height, they will expand to fit.
- [nowIndicator](https://legacy.fullcalendar.io/v5/nowIndicator.md) - Whether or not to display a marker indicating the current time.
- [scrollTime](https://legacy.fullcalendar.io/v5/scrollTime.md) - Determines how far forward the scroll pane is initially scrolled.

## Demos

- [timeGridWeek and timeGridDay views](https://legacy.fullcalendar.io/v5/timegrid-standard-view-demo)
- [Custom 4-day TimeGrid view](https://legacy.fullcalendar.io/v5/timegrid-custom-view-demo)
