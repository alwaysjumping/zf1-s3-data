# Event Clicking & Hovering

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-clicking-hovering
>
> Latest version (v7): https://fullcalendar.io/docs/event-clicking-hovering.md

Handlers to know when an event has been clicked or hovered over.

## Articles

- [eventClick](https://legacy.fullcalendar.io/v5/eventClick.md) - Triggered when the user clicks an event.
- [eventMouseEnter](https://legacy.fullcalendar.io/v5/eventMouseEnter.md) - Triggered when the user mouses over an event. Similar to the native mouseenter.
- [eventMouseLeave](https://legacy.fullcalendar.io/v5/eventMouseLeave.md) - Triggered when the user mouses out of an event. Similar to the native mouseleave.

## Demos

- [eventClick triggering](https://legacy.fullcalendar.io/v5/eventClick-demo)
