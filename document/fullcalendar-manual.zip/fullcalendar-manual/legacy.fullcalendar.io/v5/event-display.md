# Event Display

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-display
>
> Latest version (v7): https://fullcalendar.io/docs/event-display.md

How to control the appearance of events on your calendar.

## Articles

- [eventColor](https://legacy.fullcalendar.io/v5/eventColor.md) - Sets the background and border colors for all events on the calendar.
- [eventBackgroundColor](https://legacy.fullcalendar.io/v5/eventBackgroundColor.md) - Sets the background color for all events on the calendar.
- [eventBorderColor](https://legacy.fullcalendar.io/v5/eventBorderColor.md) - Sets the border color for all events on the calendar.
- [eventTextColor](https://legacy.fullcalendar.io/v5/eventTextColor.md) - Sets the text color for all events on the calendar.
- [eventDisplay](https://legacy.fullcalendar.io/v5/eventDisplay.md) - Controls which preset rendering style events use.
- [eventTimeFormat](https://legacy.fullcalendar.io/v5/eventTimeFormat.md) - Determines the time-text that will be displayed on each event.
- [displayEventTime](https://legacy.fullcalendar.io/v5/displayEventTime.md) - Whether or not to display the text for an event’s date/time.
- [displayEventEnd](https://legacy.fullcalendar.io/v5/displayEventEnd.md) - Whether or not to display an event’s end time.
- [nextDayThreshold](https://legacy.fullcalendar.io/v5/nextDayThreshold.md) - How far an event must run into the next day before it renders on that day. It applies when an event’s end time spans into another day.
- [eventOrder](https://legacy.fullcalendar.io/v5/eventOrder.md) - Determines the ordering events within the same day.
- [eventOrderStrict](https://legacy.fullcalendar.io/v5/eventOrderStrict.md) - Ensures the eventOrder setting is strictly followed.
- [progressiveEventRendering](https://legacy.fullcalendar.io/v5/progressiveEventRendering.md) - When to render multiple asynchronous event sources in an individual or batched manner.
- [Event Render Hooks](https://legacy.fullcalendar.io/v5/event-render-hooks.md)

## Demos

- [Event color customization](https://legacy.fullcalendar.io/v5/event-colors-demo)
- [Event tooltip with eventDidMount](https://legacy.fullcalendar.io/v5/event-tooltip-demo)
