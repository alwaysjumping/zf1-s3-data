# resourceRemove

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resourceRemove
>
> Latest version (v7): https://fullcalendar.io/docs/resourceRemove.md

Premium feature.

Called after a resource has been removed from the calendar.

<div class='spec' markdown='1'>
function( removeInfo )
</div>

This fires after [Resource::remove](https://legacy.fullcalendar.io/v5/Resource-remove.md) is called.

The `removeInfo` argument has the following properties:

<table>

<tr>
<th>resource</th>
<td>the <a href='https://legacy.fullcalendar.io/v5/resource-object.md'>Resource Object</a> that was removed</td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

</table>
