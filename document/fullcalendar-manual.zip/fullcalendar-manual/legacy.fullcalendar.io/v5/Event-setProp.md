# Event::setProp

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Event-setProp
>
> Latest version (v7): https://fullcalendar.io/docs/Event-setProp.md

Modifies any of the non-date-related properties of an [Event Object](https://legacy.fullcalendar.io/v5/event-object.md).

<div class='spec' markdown='1'>
event.setProp( *name*, *value* )
</div>

This will cause the event to rerender. If there are other [events](https://legacy.fullcalendar.io/v5/event-object.md) that share the same `groupId`, those events' props will be similarly modified.

To modify any of the `extendedProps`, use [setExtendedProp](https://legacy.fullcalendar.io/v5/Event-setExtendedProp.md).

To modify date-related properties like `start`, `end`, and `allDay`, use the following methods:

- [setStart](https://legacy.fullcalendar.io/v5/Event-setStart.md)
- [setEnd](https://legacy.fullcalendar.io/v5/Event-setEnd.md)
- [setDates](https://legacy.fullcalendar.io/v5/Event-setDates.md)
- [setAllDay](https://legacy.fullcalendar.io/v5/Event-setAllDay.md)
- [moveStart](https://legacy.fullcalendar.io/v5/Event-moveStart.md)
- [moveEnd](https://legacy.fullcalendar.io/v5/Event-moveEnd.md)
- [moveDates](https://legacy.fullcalendar.io/v5/Event-moveDates.md)
