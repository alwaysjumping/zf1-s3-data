# Date Clicking & Selecting

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/date-clicking-selecting
>
> Latest version (v7): https://fullcalendar.io/docs/date-clicking-selecting.md

Detect when the user clicks on dates or times. Give the user the ability to select multiple dates or time slots with their mouse or touch device.

## Articles

- [selectable](https://legacy.fullcalendar.io/v5/selectable.md) - Allows a user to highlight multiple days or timeslots by clicking and dragging.
- [selectMirror](https://legacy.fullcalendar.io/v5/selectMirror.md) - Whether to draw a “placeholder” event while the user is dragging.
- [unselectAuto](https://legacy.fullcalendar.io/v5/unselectAuto.md) - Whether clicking elsewhere on the page will cause the current selection to be cleared.
- [unselectCancel](https://legacy.fullcalendar.io/v5/unselectCancel.md) - A way to specify elements that will ignore the unselectAuto option.
- [selectOverlap](https://legacy.fullcalendar.io/v5/selectOverlap.md) - Determines whether the user is allowed to select periods of time that are occupied by events.
- [selectConstraint](https://legacy.fullcalendar.io/v5/selectConstraint.md) - Limits user selection to certain windows of time.
- [selectAllow](https://legacy.fullcalendar.io/v5/selectAllow.md) - Exact programmatic control over where the user can select.
- [selectMinDistance](https://legacy.fullcalendar.io/v5/selectMinDistance.md) - The minimum distance the user’s mouse must travel after a mousedown, before a selection is allowed.

## Callbacks

- [dateClick](https://legacy.fullcalendar.io/v5/dateClick.md) - Triggered when the user clicks on a date or a time.
- [select](https://legacy.fullcalendar.io/v5/select-callback.md) - Triggered when a date/time selection is made.
- [unselect](https://legacy.fullcalendar.io/v5/unselect-callback.md) - Triggered when the current selection is cleared.

## Methods

- [Calendar::select](https://legacy.fullcalendar.io/v5/Calendar-select.md) - A method for programmatically selecting a period of time.
- [Calendar::unselect](https://legacy.fullcalendar.io/v5/Calendar-unselect.md) - A method for programmatically clearing the current selection.

## See Also

- [dragScroll](https://legacy.fullcalendar.io/v5/dragScroll.md) - Whether to automatically scoll the scroll-containers during event drag-and-drop and date selecting.
- [snapDuration](https://legacy.fullcalendar.io/v5/snapDuration.md) - The time interval at which a dragged event will snap to the time axis. Also affects the granularity at which selections can be made.
- [Touch Support](https://legacy.fullcalendar.io/v5/touch.md) - FullCalendar’s Touch support includes smooth scrolling, time-range selection via long-press, and event drag-n-drop/resizing via long-press.

## Demos

- [dateClick and selectable dates/times](https://legacy.fullcalendar.io/v5/date-clicking-selecting-demo)
- [Clicking and selecting on resources](https://legacy.fullcalendar.io/v5/date-clicking-selecting-resource-demo)
