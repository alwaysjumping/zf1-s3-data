# EventSource::remove

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/EventSource-remove
>
> Latest version (v7): https://fullcalendar.io/docs/EventSource-remove.md

Removes all events associated with this source and prevents it from being fetched again.

<div class='spec' markdown='1'>
eventSource.remove()
</div>

Must be called on an Event Source instance. See [getEventSources](https://legacy.fullcalendar.io/v5/Calendar-getEventSources.md) and [getEventSourceById](https://legacy.fullcalendar.io/v5/Calendar-getEventSourceById.md).
