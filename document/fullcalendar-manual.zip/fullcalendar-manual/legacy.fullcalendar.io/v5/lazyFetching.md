# lazyFetching

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/lazyFetching
>
> Latest version (v7): https://fullcalendar.io/docs/lazyFetching.md

Determines when event fetching should occur.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

When set to `true` (the default), the calendar will only fetch events when it absolutely needs to, minimizing AJAX calls. For example, say your calendar starts out in month view, in February. FullCalendar will fetch events for the entire month of February and store them in its internal cache. Then, say the user switches to week view and begins browsing the weeks in February. The calendar will avoid fetching events because it already has this information stored.

When set to `false`, the calendar will fetch events any time the view is switched, or any time the current date changes (for example, as a result of the user clicking prev/next).
