# forceEventDuration

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/forceEventDuration
>
> Latest version (v7): https://fullcalendar.io/docs/forceEventDuration.md

A flag to force assignment of an event's `end` if it is unspecified.

<div class='spec' markdown='1'>
Boolean, *default:* `false`
</div>

If an event's `end` is not specified, it will be calculated and assigned to the [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) using [defaultTimedEventDuration](https://legacy.fullcalendar.io/v5/defaultTimedEventDuration.md) or [defaultAllDayEventDuration](https://legacy.fullcalendar.io/v5/defaultAllDayEventDuration.md).
