# scrollTime

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/scrollTime
>
> Latest version (v7): https://fullcalendar.io/docs/scrollTime.md

Determines how far forward the scroll pane is initially scrolled.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md), *default*: `'06:00:00'` (6am)
</div>

The user will be able to scroll back to see events before this time. If you want to prevent users from doing this, use the [slotMinTime](https://legacy.fullcalendar.io/v5/slotMinTime.md) option instead.

By default, `scrollTime` is reapplied to the view whenever the date range changes. To disable this, set [scrollTimeReset](https://legacy.fullcalendar.io/v5/scrollTimeReset.md) to `false`.
