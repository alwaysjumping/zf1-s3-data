# snapDuration

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/snapDuration
>
> Latest version (v7): https://fullcalendar.io/docs/snapDuration.md

The time interval at which a dragged event will snap to the time axis. Also affects the granularity at which [selections](https://legacy.fullcalendar.io/v5/date-clicking-selecting.md) can be made.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md)
</div>

The default value will be whatever [slotDuration](https://legacy.fullcalendar.io/v5/slotDuration.md) is, which defaults to half an hour.
