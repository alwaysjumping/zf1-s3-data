# startParam

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/startParam
>
> Latest version (v7): https://fullcalendar.io/docs/startParam.md

A parameter of this name will be sent to each JSON event feed. It describes the start of the interval being fetched.

<div class='spec' markdown='1'>
String, *default*: `'start'`
</div>

The actual value of this parameter will be an ISO8601 date string.
