# eventMinWidth

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventMinWidth
>
> Latest version (v7): https://fullcalendar.io/docs/eventMinWidth.md

Premium feature.

In **timeline** view, the minimum width an event is allowed to be.

<div class='spec' markdown='1'>
Number, *default*: `30`
</div>
