# Event Popover

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-popover
>
> Latest version (v7): https://fullcalendar.io/docs/event-popover.md

When not all events will fit in a given day, you can display the excess events in a small window that will show up when the user clicks a "more" link.

This UI component only applies to [Month view](https://legacy.fullcalendar.io/v5/month-view.md), [DayGrid view](https://legacy.fullcalendar.io/v5/daygrid-view.md), and the "all-day" slot of [TimeGrid view](https://legacy.fullcalendar.io/v5/timegrid-view.md).

## Articles

- [dayMaxEventRows](https://legacy.fullcalendar.io/v5/dayMaxEventRows.md) - In dayGrid view, the max number of stacked event levels within a given day. This includes the +more link if present. The rest will show up in a popover.
- [dayMaxEvents](https://legacy.fullcalendar.io/v5/dayMaxEvents.md) - In, dayGrid view, the max number of events within a given day, not counting the +more link. The rest will show up in a popover.
- [eventMaxStack](https://legacy.fullcalendar.io/v5/eventMaxStack.md) - For timeline view, the maximum number of events that stack top-to-bottom. For timeGrid view, the maximum number of events that stack left-to-right.
- [moreLinkClick](https://legacy.fullcalendar.io/v5/moreLinkClick.md) - Determines what happens when the user clicks a “more” link. These links are created by the dayMaxEventRows or dayMaxEvents options.
- [dayPopoverFormat](https://legacy.fullcalendar.io/v5/dayPopoverFormat.md) - Determines the date format of title of the popover created by the moreLinkClick option.
- [More-Link Render Hooks](https://legacy.fullcalendar.io/v5/more-link-render-hooks.md) - moreLinkClassNames - a ClassName Input for adding classNames

## Demos

- [Event popover when too many events](https://legacy.fullcalendar.io/v5/event-popover-demo)
