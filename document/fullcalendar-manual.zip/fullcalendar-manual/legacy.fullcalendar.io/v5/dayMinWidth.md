# dayMinWidth

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dayMinWidth
>
> Latest version (v7): https://fullcalendar.io/docs/dayMinWidth.md

Premium feature.

A minimum width for day cells, past which the calendar scrolls horizontally. When the calendar gets narrow enough that day cells can no longer meet their `dayMinWidth`, horizontal scrollbars appear.

<div class='spec' markdown='1'>
number of pixels, undefined
</div>

For [vertical resource view](https://legacy.fullcalendar.io/v5/vertical-resource-view.md), daygrid view, and timegrid view.

Requires the `@fullcalendar/scrollgrid` [premium plugin](https://fullcalendar.io/pricing).

<a href='https://legacy.fullcalendar.io/v5/dayMinWidth-demo' class='more-link'>View a live example</a>
