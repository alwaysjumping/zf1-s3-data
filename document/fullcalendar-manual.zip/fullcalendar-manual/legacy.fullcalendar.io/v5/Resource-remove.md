# Resource::remove

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Resource-remove
>
> Latest version (v7): https://fullcalendar.io/docs/Resource-remove.md

Premium feature.

Programmatically removes a resource from the calendar.

<div class='spec' markdown='1'>
resource.remove()
</div>

Example:

```js
var calendar = new Calendar(calendarEl, {
  resources: [
    { id: 'a', title: 'Resource A' },
    { id: 'b', title: 'Resource B' }
  ]
});

var resourceA = calendar.getResourceById('a');

resourceA.remove();
```
