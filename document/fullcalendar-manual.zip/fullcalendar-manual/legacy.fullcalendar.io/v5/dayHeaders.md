# dayHeaders

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dayHeaders
>
> Latest version (v7): https://fullcalendar.io/docs/dayHeaders.md

Whether the day headers should appear. For the Month, TimeGrid, and DayGrid views.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

The default is to show these column headers, but if you would like to hide them, especially if you have a single-day view and you feel the column header is unnecessary, you can set it to `false`.
