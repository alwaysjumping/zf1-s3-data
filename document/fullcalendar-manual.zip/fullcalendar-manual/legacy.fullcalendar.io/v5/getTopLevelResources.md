# getTopLevelResources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/getTopLevelResources
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-getTopLevelResources.md

Premium feature.

A method that retrieves only top-level [Resources](https://legacy.fullcalendar.io/v5/resource-object.md).

<div class='spec' markdown='1'>
.getTopLevelResources()
</div>

Will return an array of resources that are not nested under any other resource. Nested child resources are available via the [getChildren](https://legacy.fullcalendar.io/v5/Resource-getChildren.md) method.
