# Calendar::getEvents

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-getEvents
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-getEvents.md

Retrieves events that FullCalendar has in memory.

<div class='spec' markdown='1'>
calendar.getEvents() -> Array
</div>

This method will return an array of [Event Objects](https://legacy.fullcalendar.io/v5/event-object.md) that FullCalendar has stored in client-side memory.
