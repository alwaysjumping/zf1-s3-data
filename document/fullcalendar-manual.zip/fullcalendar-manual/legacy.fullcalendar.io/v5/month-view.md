# Month View

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/month-view
>
> Latest version (v7): https://fullcalendar.io/docs/month-view.md

Month view displays the current month's days, and usually a few days of the previous and next months, in a table-like format. It's technically considered "dayGridMonth" view and is part of the [DayGrid plugin](https://legacy.fullcalendar.io/v5/daygrid-view.md). It can be initialized in an [ES6 setup](https://legacy.fullcalendar.io/v5/initialize-es6.md) like so:

```js
import { Calendar } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
...
let calendar = new Calendar(calendarEl, {
  plugins: [ dayGridPlugin ],
  initialView: 'dayGridMonth'
});
...
```

Or you can choose to initialized Month view [as a global bundle](https://legacy.fullcalendar.io/v5/initialize-globals.md):

```html
<link href='fullcalendar/main.css' rel='stylesheet' />
<script src='fullcalendar/main.js'></script>
<script>
...
var calendar = new FullCalendar.Calendar(calendarEl, {
  initialView: 'dayGridMonth'
});
...
</script>
```

The following options are specific to month view. However, there are numerous other options throughout the docs that affect the display of month view, such as the [date/time display options](https://legacy.fullcalendar.io/v5/date-display.md) and [locale-related options](https://legacy.fullcalendar.io/v5/localization.md).

## Month-View-specific Options

- [fixedWeekCount](https://legacy.fullcalendar.io/v5/fixedWeekCount.md) - Determines the number of weeks displayed in a month view.
- [showNonCurrentDates](https://legacy.fullcalendar.io/v5/showNonCurrentDates.md) - In month view, whether dates in the previous or next month should be rendered at all.

## Demos

- [Month View](https://legacy.fullcalendar.io/v5/month-view-demo)
