# slotLabelInterval

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/slotLabelInterval
>
> Latest version (v7): https://fullcalendar.io/docs/slotHeaderInterval.md

The frequency that the time slots should be labeled with text.

<div class='spec' markdown='1'>
[Duration](https://legacy.fullcalendar.io/v5/duration-object.md)
</div>

If not specified, a reasonable value will be automatically computed based on `slotDuration`. When specifying this option, give a [Duration](https://legacy.fullcalendar.io/v5/duration-object.md)-ish input, like `"01:00"` or `{hours:1}`. This will cause the header labels to appear on the hour marks, even if `slotDuration` was hypothetically 15 or 30 minutes long.
