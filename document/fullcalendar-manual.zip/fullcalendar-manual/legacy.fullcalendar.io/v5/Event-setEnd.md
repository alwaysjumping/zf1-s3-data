# Event::setEnd

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Event-setEnd
>
> Latest version (v7): https://fullcalendar.io/docs/Event-setEnd.md

Sets an event's end date.

<div class='spec' markdown='1'>
event.setEnd( *date* )
</div>

`date` is something that must [parse into a Date Object](https://legacy.fullcalendar.io/v5/date-parsing.md). It can also be `null`, in which case the event's end will be cleared.

If you'd like to set both the `start` and `end` at the same time, use [setDates](https://legacy.fullcalendar.io/v5/Event-setDates.md) instead.

If there are other events that share the same `groupId`, those events' end dates will be similarly modified.
