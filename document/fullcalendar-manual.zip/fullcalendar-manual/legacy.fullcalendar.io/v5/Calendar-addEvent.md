# Calendar::addEvent

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-addEvent
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-addEvent.md

Adds a new event to the calendar.

<div class='spec' markdown='1'>
calendar.addEvent( *event* [, *source* ] )
</div>

`event` is a plain object that will be [parsed into an Event Object](https://legacy.fullcalendar.io/v5/event-parsing.md).

`source` represents the Event Source you want to associate this event with. When the source is refetched, it will clear the dynamically added event from the internal cache before fetching. This optional parameter can be specified as any of the following:

- an Event Source ID `string`
- an [Event Source Object](https://legacy.fullcalendar.io/v5/event-source-object.md)
- `true`, which signifies the *first* event source

This method returns the proper [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) that was parsed from the plain object.

[View a live demo](https://legacy.fullcalendar.io/v5/Calendar-addEvent-demo) of addEvent.
