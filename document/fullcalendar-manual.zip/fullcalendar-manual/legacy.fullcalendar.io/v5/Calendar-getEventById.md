# Calendar::getEventById

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-getEventById
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-getEventById.md

Returns a single event with the matching `id`.

<div class='spec' markdown='1'>
calendar.getEventById( *id* )
</div>

`id` must be a string or a number

Will return an [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) if found, and `null` otherwise.
