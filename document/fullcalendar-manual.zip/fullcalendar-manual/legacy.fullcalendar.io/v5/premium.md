# Premium Plugins

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/premium
>
> Latest version (v7): https://fullcalendar.io/docs/premium.md

FullCalendar Premium (also known as "FullCalendar Scheduler") is a collection of plugins released under a [different license](https://fullcalendar.io/license) than the standard plugins. Each plugin offers additional functionality:

- [Timeline View](https://legacy.fullcalendar.io/v5/timeline-view.md) - display a large number of resources, with dates/times spanning horizontally
- [Vertical Resource View](https://legacy.fullcalendar.io/v5/vertical-resource-view.md) - display resources as columns
- [Print Optimization](https://legacy.fullcalendar.io/v5/print.md) - improve how your calendar looks when printed

A Premium plugin is initialized in the same way a typical standard plugin would be initialized:

- [**NPM/Yarn instructions**](https://legacy.fullcalendar.io/v5/initialize-es6.md#premium-plugins)
- [**ZIP archives and CDN links**](https://legacy.fullcalendar.io/v5/initialize-globals.md#premium-bundle)


## Free Trial

FullCalendar Premium can be downloaded and evaluated for an unlimited amount of time, free of charge. This evaluation version is licensed under a [Creative Commons license](https://creativecommons.org/licenses/by-nc-nd/4.0/) that does not allow distribution of source code modifications nor use in commercial production websites or products.

During your free trial, in order to hide the license warning, use the following [license key](https://legacy.fullcalendar.io/v5/schedulerLicenseKey.md):

```js
var calendar = new Calendar(calendarEl, {
  schedulerLicenseKey: 'CC-Attribution-NonCommercial-NoDerivatives'
});
```

## Demos

- [Various Resource-Timeline Views](https://legacy.fullcalendar.io/v5/timeline-standard-view-demo)
- [1-day vertical resource view](https://legacy.fullcalendar.io/v5/vertical-resource-standard-demo)

## Images

![Print optimization in Timeline view](https://legacy.fullcalendar.io/v5/timeline-print.png)
