# Calendar::incrementDate

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-incrementDate
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-incrementDate.md

Moves the calendar forward/backward an arbitrary amount of time.

<div class='spec' markdown='1'>
calendar.incrementDate( duration )
</div>

`duration` can be a [Duration](https://legacy.fullcalendar.io/v5/duration-object.md) object or anything the Duration constructor accepts.
