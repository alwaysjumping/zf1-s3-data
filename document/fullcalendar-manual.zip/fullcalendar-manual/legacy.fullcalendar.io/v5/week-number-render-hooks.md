# Week-Number Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/week-number-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/inline-week-number-render-hooks.md

`weekNumberClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md)

`weekNumberContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`weekNumberDidMount`

`weekNumberWillUnmount`


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `num`
- `text`
- `date` - Date object
