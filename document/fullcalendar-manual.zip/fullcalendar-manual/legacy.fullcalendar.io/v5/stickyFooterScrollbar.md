# stickyFooterScrollbar

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/stickyFooterScrollbar
>
> Latest version (v7): https://fullcalendar.io/docs/footerScrollbarSticky.md

Whether to fix the view's horizontal scrollbar to the bottom of the viewport while scrolling.

<div class='spec' markdown='1'>
`'auto'` (the default), `true`, `false`
</div>

When a view has horizontal scrollbars, for example, `timeline` view or the `daygrid` or `timegrid` views when the ([dayMinWidth](https://legacy.fullcalendar.io/v5/dayMinWidth.md)) settings is activated, and calendar is within view but the scrollbars are below the fold of the screen, this setting will fix the scrollbar to the bottom of the viewport.

The default value of `'auto'` will look at the [height](https://legacy.fullcalendar.io/v5/height.md) setting and if it is `'auto'`, meaning the calendar has the potential to be very tall, sticky-footer-scrollbars will be activated.

The following demos show sticky horizontal scrollbars:

- [timeline view](https://legacy.fullcalendar.io/v5/sticky-timeline-demo)
- [vertical resource view](https://legacy.fullcalendar.io/v5/sticky-resource-timegrid-demo)
