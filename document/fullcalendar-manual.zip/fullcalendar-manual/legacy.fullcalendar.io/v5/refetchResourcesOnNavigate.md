# refetchResourcesOnNavigate

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/refetchResourcesOnNavigate
>
> Latest version (v7): https://fullcalendar.io/docs/refetchResourcesOnNavigate.md

Premium feature.

Whether to refetch and rerender resources when the user navigates to a different date or changes the view.

<div class='spec' markdown='1'>
Boolean, *default*: `false`
</div>

If `refetchResourcesOnNavigate` is set to `true`...

- A [resources function](https://legacy.fullcalendar.io/v5/resources-function.md) will receive `start`, `end`, and `timezone` parameters
- A [resources JSON feed](https://legacy.fullcalendar.io/v5/resources-json-feed.md) will be requested with `start`, `end`, and `timezone` parameters
