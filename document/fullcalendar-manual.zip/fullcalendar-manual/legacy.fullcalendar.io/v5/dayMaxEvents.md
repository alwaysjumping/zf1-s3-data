# dayMaxEvents

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dayMaxEvents
>
> Latest version (v7): https://fullcalendar.io/docs/dayMaxEvents.md

In, **dayGrid** view, the max number of events within a given day, not counting the +more link. The rest will show up in a popover.

Just like with [dayMaxEventRows](https://legacy.fullcalendar.io/v5/dayMaxEventRows.md), if `true` is specified, the number of events will be limited to the height of the day cell.

For **timeGrid** and **timeline** views, see [eventMaxStack](https://legacy.fullcalendar.io/v5/eventMaxStack.md).
