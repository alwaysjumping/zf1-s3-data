# direction

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/direction
>
> Latest version (v7): https://fullcalendar.io/docs/direction.md

The direction that elements in the calendar are rendered. Either left-to-right or right-to-left.

<div class='spec' markdown='1'>
`'ltr'` (default) or `'rtl'`
</div>

This option is useful for right-to-left languages such as Arabic and Hebrew.
