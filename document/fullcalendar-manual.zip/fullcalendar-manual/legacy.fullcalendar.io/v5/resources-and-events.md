# Associating Events with Resources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/resources-and-events
>
> Latest version (v7): https://fullcalendar.io/docs/resources-and-events.md

Premium feature.

An [Event](https://legacy.fullcalendar.io/v5/event-parsing.md) becomes associated with a resource when its `resourceId` property matches one of the [Resource Object](https://legacy.fullcalendar.io/v5/resource-object.md)'s `id` fields:

```js
var calendar = new Calendar(calendarEl, {
  resources: [
    {
      id: 'a',
      title: 'Room A'
    }
  ],
  events: [
    {
      id: '1',
      resourceId: 'a',
      title: 'Meeting',
      start: '2015-02-14'
    }
  ]
});
```

## Multiple Resources

It is also possible to associate an event with *multiple* resources using the `resourceIds` property, which is an array:

```js
var calendar = new Calendar(calendarEl, {
  resources: [
    {
      id: 'a',
      title: 'Room A'
    },
    {
      id: 'b',
      title: 'Room B'
    }
  ],
  events: [
    {
      id: '1',
      resourceIds: ['a', 'b'],
      title: 'Meeting',
      start: '2015-02-14'
    }
  ]
});
```
