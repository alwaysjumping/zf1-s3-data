# Event Dragging & Resizing

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-dragging-resizing
>
> Latest version (v7): https://fullcalendar.io/docs/event-dragging-resizing.md

How to enable and control where the user can drag-n-drop and resize events. Start by setting the [editable](https://legacy.fullcalendar.io/v5/editable.md) setting to `true`. If you want to allow external elements to be dropped onto your calendar, visit the [droppable](https://legacy.fullcalendar.io/v5/droppable.md), [drop](https://legacy.fullcalendar.io/v5/drop.md), and [eventReceive](https://legacy.fullcalendar.io/v5/eventReceive.md) articles.

## Articles

- [External Event Dragging](https://legacy.fullcalendar.io/v5/external-dragging.md) - It’s possible to take elements that live outside of a calendar and make them drag-and-droppable. When they are dropped on a specific date of a calendar, a new event might be created and certain callbacks might fire. It is possible to achieve this using FullCalendar alone, without any third party libraries.
- [Dragging Between Calendars](https://legacy.fullcalendar.io/v5/other-calendar-dragging.md) - It’s possible to initialize two or more separate Calendars, and then allow the user to drag events between the calendars!
- [Third-Party Dragging Libraries](https://legacy.fullcalendar.io/v5/third-party-dragging.md) - It’s possible to leverage a third-party library to do your external element drag-n-drop, instead of FullCalendar’s own. You might want to do this if you prefer the visual effects of another library, need “sorting” functionality, or need the ability to drag-n-drop between multiple containers, functionality that FullCalendar does not have.

## Flags

- [editable](https://legacy.fullcalendar.io/v5/editable.md) - Determines whether the events on the calendar can be modified.
- [eventStartEditable](https://legacy.fullcalendar.io/v5/eventStartEditable.md) - Allow events’ start times to be editable through dragging.
- [eventResizableFromStart](https://legacy.fullcalendar.io/v5/eventResizableFromStart.md) - Whether the user can resize an event from its starting edge.
- [eventDurationEditable](https://legacy.fullcalendar.io/v5/eventDurationEditable.md) - Allow events’ durations to be editable through resizing.
- [eventResourceEditable](https://legacy.fullcalendar.io/v5/eventResourceEditable.md) - Determines whether the user can drag events between resources.
- [droppable](https://legacy.fullcalendar.io/v5/droppable.md) - Determines if external draggable elements or events from other calendars can be dropped onto the calendar.

## Effects

- [eventDragMinDistance](https://legacy.fullcalendar.io/v5/eventDragMinDistance.md) - How many pixels the user’s mouse/touch must move before an event drag activates.
- [dragRevertDuration](https://legacy.fullcalendar.io/v5/dragRevertDuration.md) - Time it takes for an event to revert to its original position after an unsuccessful drag.
- [dragScroll](https://legacy.fullcalendar.io/v5/dragScroll.md) - Whether to automatically scoll the scroll-containers during event drag-and-drop and date selecting.
- [snapDuration](https://legacy.fullcalendar.io/v5/snapDuration.md) - The time interval at which a dragged event will snap to the time axis. Also affects the granularity at which selections can be made.
- [allDayMaintainDuration](https://legacy.fullcalendar.io/v5/allDayMaintainDuration.md) - Determines how an event’s duration changes when it’s dragged between timed and all-day sections.
- [fixedMirrorParent](https://legacy.fullcalendar.io/v5/fixedMirrorParent.md) - The parent element that fixed-positioned event mirror elements are attached to while dragging.

## Control

- [eventOverlap](https://legacy.fullcalendar.io/v5/eventOverlap.md) - Determines if events being dragged and resized are allowed to overlap each other.
- [eventConstraint](https://legacy.fullcalendar.io/v5/eventConstraint.md) - Limits event dragging and resizing to certain windows of time.
- [eventAllow](https://legacy.fullcalendar.io/v5/eventAllow.md) - Exact programmatic control over where an event can be dropped.
- [dropAccept](https://legacy.fullcalendar.io/v5/dropAccept.md) - Provides a way to filter which external elements can be dropped onto the calendar.

## Callbacks

- [eventDragStart](https://legacy.fullcalendar.io/v5/eventDragStart.md) - Triggered when event dragging begins.
- [eventDragStop](https://legacy.fullcalendar.io/v5/eventDragStop.md) - Triggered when event dragging stops.
- [eventDrop](https://legacy.fullcalendar.io/v5/eventDrop.md) - Triggered when dragging stops and the event has moved to a different day/time.
- [drop](https://legacy.fullcalendar.io/v5/drop.md) - Called when an external draggable element or an event from another calendar has been dropped onto the calendar.
- [eventReceive](https://legacy.fullcalendar.io/v5/eventReceive.md) - Called when an external draggable element with associated event data was dropped onto the calendar. Or an event from another calendar.
- [eventLeave](https://legacy.fullcalendar.io/v5/eventLeave.md) - Triggered when on a calendar when one if its events is about to be dropped onto another calendar.
- [eventResizeStart](https://legacy.fullcalendar.io/v5/eventResizeStart.md) - Triggered when event resizing begins.
- [eventResizeStop](https://legacy.fullcalendar.io/v5/eventResizeStop.md) - Triggered when event resizing stops.
- [eventResize](https://legacy.fullcalendar.io/v5/eventResize.md) - Triggered when resizing stops and the event has changed in duration.

## See Also

- [validRange](https://legacy.fullcalendar.io/v5/validRange.md) - Limits which dates the user can navigate to and where events can go.
- [Touch Support](https://legacy.fullcalendar.io/v5/touch.md) - FullCalendar’s Touch support includes smooth scrolling, time-range selection via long-press, and event drag-n-drop/resizing via long-press.

## Demos

- [Enable event dragging/resizing](https://legacy.fullcalendar.io/v5/event-dragging-resizing-demo)
- [Drag-n-drop external events](https://legacy.fullcalendar.io/v5/external-dragging-demo)
- [Constrain event dragging by certain criteria](https://legacy.fullcalendar.io/v5/event-constraint-demo)
