# selectMinDistance

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/selectMinDistance
>
> Latest version (v7): https://fullcalendar.io/docs/selectMinDistance.md

The minimum distance the user's mouse must travel after a mousedown, before a selection is allowed.

<div class='spec' markdown='1'>
Integer, *default*: `0`
</div>

The default value of `0` puts no restriction on the distance the mouse must travel.

A non-zero value is useful for differentiating a selection from a [dateClick](https://legacy.fullcalendar.io/v5/dateClick.md).

This setting is only applicable to mouse-related interaction. For touch interation, see [selectLongPressDelay](https://legacy.fullcalendar.io/v5/selectLongPressDelay.md).
