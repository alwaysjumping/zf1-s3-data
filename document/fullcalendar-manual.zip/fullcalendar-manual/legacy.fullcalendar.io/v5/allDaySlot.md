# allDaySlot

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/allDaySlot
>
> Latest version (v7): https://fullcalendar.io/docs/allDaySlot.md

Determines if the "all-day" slot is displayed at the top of the calendar.

<div class='spec' markdown='1'>
Boolean, *default*: `true`
</div>

When hidden with `false`, all-day events will not be displayed in TimeGrid views.
