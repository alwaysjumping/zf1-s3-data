# Locale

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/localization
>
> Latest version (v7): https://fullcalendar.io/docs/localization.md

You can tailor the calendar for certain languages (aka "locales"). The [locale](https://legacy.fullcalendar.io/v5/locale.md) setting is the most important, as it sets the defaults of many other options at the same time.

## Articles

- [locale](https://legacy.fullcalendar.io/v5/locale.md)
- [direction](https://legacy.fullcalendar.io/v5/direction.md) - The direction that elements in the calendar are rendered. Either left-to-right or right-to-left.
- [firstDay](https://legacy.fullcalendar.io/v5/firstDay.md) - The day that each week begins.

## See Also

- [eventTimeFormat](https://legacy.fullcalendar.io/v5/eventTimeFormat.md) - Determines the time-text that will be displayed on each event.
- [dayHeaderFormat](https://legacy.fullcalendar.io/v5/dayHeaderFormat.md) - Determines the text that will be displayed on the calendar’s column headings.
- [titleFormat](https://legacy.fullcalendar.io/v5/titleFormat.md) - Determines the text that will be displayed in the headerToolbar’s title.
- [buttonText](https://legacy.fullcalendar.io/v5/buttonText.md) - Text that will be displayed on buttons of the headerToolbar/footerToolbar.
- [weekText](https://legacy.fullcalendar.io/v5/weekText.md) - The heading text for week numbers. Also affects weeks in date formatting.
- [More-Link Render Hooks](https://legacy.fullcalendar.io/v5/more-link-render-hooks.md) - moreLinkClassNames - a ClassName Input for adding classNames
- [dayPopoverFormat](https://legacy.fullcalendar.io/v5/dayPopoverFormat.md) - Determines the date format of title of the popover created by the moreLinkClick option.

## Demos

- [Dynamically switch between locales](https://legacy.fullcalendar.io/v5/locale-demo)
