# More-Link Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/more-link-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/more-link-render-hooks.md

`moreLinkClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md) for adding classNames

`moreLinkContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md)

`moreLinkDidMount` - called right after the link has been added to the DOM

`moreLinkWillUnmount` - called right before the link will be removed from the DOM


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `num` - the number of hidden events
- `text` - the localized text that would appear in the link by default
