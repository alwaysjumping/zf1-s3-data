# listDayFormat

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/listDayFormat
>
> Latest version (v7): https://fullcalendar.io/docs/listDayFormat.md

A [Date Formatter](https://legacy.fullcalendar.io/v5/date-formatting.md) that affects the text on the left side of the day headings in list view.

<div class='spec' markdown='1'>
String, `false`
</div>

<img src='https://legacy.fullcalendar.io/v5/listDayFormat.png' width='468' height='259' style='box-shadow: 0 1px 4px rgba(0,0,0,.3)' alt='customized list-view date strings' />

If `false` is specified, no text is displayed.
