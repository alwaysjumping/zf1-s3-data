# weekNumberFormat

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/weekNumberFormat
>
> Latest version (v7): https://fullcalendar.io/docs/weekNumberFormat.md

Controls the week number text.

<div class='spec' markdown='1'>
[Date Formatter](https://legacy.fullcalendar.io/v5/date-formatting.md), *default*: `{ week: 'narrow' }`
</div>

The formatted text depends on [weekText](https://legacy.fullcalendar.io/v5/weekText.md).

If set to `{ week: 'short' }`, and `weekText` is set to `"W"`, a value like `"W 6"` will be outputted.

If set to `{ week: 'narrow' }`, and `weekText` is set to `"W"`, a value like `"W6"` will be outputted.

If set to `{ week: 'numeric' }`, a plain numeric value like `"6"` will be outputted.
