# Date Library

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/date-library
>
> Latest version (v7): https://fullcalendar.io/docs/date-library.md

## Articles

- [Date Parsing](https://legacy.fullcalendar.io/v5/date-parsing.md) - FullCalendar’s API accepts date information in many places, such as when you set the initialDate or define an event’s start/end.
- [Date Objects](https://legacy.fullcalendar.io/v5/date-object.md) - FullCalendar’s API exposes Date objects in many places, such as dateClick or a View object’s activeStart/activeEnd.
- [Duration Object](https://legacy.fullcalendar.io/v5/duration-object.md) - A duration is a way to express an amount of time that has passed. It can also be used to express a time-of-day, in other words, the amount of time that has passed since the start of the day.
- [Date Formatting](https://legacy.fullcalendar.io/v5/date-formatting.md) - The term “date formatting” means taking a Date object and converting it into a string. The string can either be a standard string format like ISO8601 (ex: '2018-05-01') or it can be something more custom that you can display to users.
- [defaultRangeSeparator](https://legacy.fullcalendar.io/v5/defaultRangeSeparator.md) - The separator text used for date-formatting ranges throughout the API.

## Util Methods

- [formatDate](https://legacy.fullcalendar.io/v5/formatDate.md) - A utility function that formats a date into a string.
- [formatRange](https://legacy.fullcalendar.io/v5/formatRange.md) - Formats two dates, a start and an end, into a string. A separator string, most likely a dash, will be intelligently inserted between the two dates.
- [Calendar::formatDate](https://legacy.fullcalendar.io/v5/Calendar-formatDate.md) - A method that formats a date into a string. It inherits the locale and time zone settings of the calendar it’s called on.
- [Calendar::formatIso](https://legacy.fullcalendar.io/v5/Calendar-formatIso.md) - Formats a date into an ISO8601 string. Outputs a UTC offset appropriate to the calendar it’s called on.
- [Calendar::formatRange](https://legacy.fullcalendar.io/v5/Calendar-formatRange.md) - Formats two dates, a start and an end, into a string. A separator string, most likely a dash, will be intelligently inserted between the two dates. Inherits the time zone and locale settings of the calendar it’s called on.

## Plugins

- [Moment Plugin](https://legacy.fullcalendar.io/v5/moment-plugin.md) - Moment JS is a popular library for parsing, formatting, and manipulating dates.
- [Moment Timezone Plugin](https://legacy.fullcalendar.io/v5/moment-timezone-plugin.md) - Moment Timezone is a library for dealing with time zones. FullCalendar has a connector plugin that gives your calendar support for arbitrary named time zones. It provides a “named timezone implementation” for the timeZone setting.
- [Luxon 2 Plugin](https://legacy.fullcalendar.io/v5/luxon2.md) - Luxon is a JavaScript date library that cleverly leverages the browser’s native APIs for many things such as time zones, locales, and formatting. However, it requires IE11 and above, and if you want to use named time zones, it does not support IE at all, only Microsoft Edge. If these browser requirements are okay for your project, then all is good!
- [Luxon 1 Plugin](https://legacy.fullcalendar.io/v5/luxon1.md) - Luxon is a JavaScript date library that cleverly leverages the browser’s native APIs for many things such as time zones, locales, and formatting. However, it requires IE11 and above, and if you want to use named time zones, it does not support IE at all, only Microsoft Edge. If these browser requirements are okay for your project, then all is good!

## See Also

- [timeZone](https://legacy.fullcalendar.io/v5/timeZone.md) - A time zone is a region of the world that serves as a context for displaying dates.
