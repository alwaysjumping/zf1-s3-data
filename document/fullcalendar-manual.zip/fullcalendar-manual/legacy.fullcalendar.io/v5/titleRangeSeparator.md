# titleRangeSeparator

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/titleRangeSeparator
>
> Upgrading to v7: https://fullcalendar.io/docs/upgrading-from-v6.md

Determines the separator text when formatting the date range in the [toolbar](https://legacy.fullcalendar.io/v5/toolbar.md) title.

<div class='spec' markdown='1'>
String, *default:* `' \u2013 '` (en dash)
</div>

Works in tandem with [titleFormat](https://legacy.fullcalendar.io/v5/titleFormat.md).

For all other date range separator text, use [defaultRangeSeparator](https://legacy.fullcalendar.io/v5/defaultRangeSeparator.md).
