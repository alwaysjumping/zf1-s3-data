# timeZoneParam

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/timeZoneParam
>
> Latest version (v7): https://fullcalendar.io/docs/timeZoneParam.md

A parameter of this name will be sent to each JSON event feed. It describes the timezone of the [startParam](https://legacy.fullcalendar.io/v5/startParam.md) and [endParam](https://legacy.fullcalendar.io/v5/endParam.md) values, as well as the desired timezone of the returned events.

<div class='spec' markdown='1'>
String, *default*: `'timeZone'`
</div>

The value of this parameter will be a timezone string like `"America/Chicago"` or `"UTC"`. For `local`, it will be unspecified. See the [timeZone setting](https://legacy.fullcalendar.io/v5/timeZone.md) for more info.
