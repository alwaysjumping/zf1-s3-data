# Resource::getParent

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Resource-getParent
>
> Latest version (v7): https://fullcalendar.io/docs/Resource-getParent.md

Premium feature.

Returns the parent [Resource](https://legacy.fullcalendar.io/v5/resource-object.md) of a child resource.

<div class='spec' markdown='1'>
resource.getParent()
</div>

If the resource does not have a parent because it is already a top-level resource, the result will be `null`.
