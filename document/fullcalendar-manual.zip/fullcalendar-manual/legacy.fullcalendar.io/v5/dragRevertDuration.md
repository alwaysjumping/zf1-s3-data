# dragRevertDuration

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dragRevertDuration
>
> Latest version (v7): https://fullcalendar.io/docs/dragRevertDuration.md

Time it takes for an event to revert to its original position after an unsuccessful drag.

<div class='spec' markdown='1'>
Integer, *default*: `500`
</div>

Time is in milliseconds (1 second = 1000 milliseconds).
