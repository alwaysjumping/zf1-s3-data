# defaultRangeSeparator

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/defaultRangeSeparator
>
> Upgrading to v7: https://fullcalendar.io/docs/upgrading-from-v6.md

The separator text used for [date-formatting](https://legacy.fullcalendar.io/v5/date-formatting.md) ranges throughout the API.

<div class='spec' markdown='1'>
String, *default:* `' - '`
</div>

This calendar-wide setting affects settings that render date ranges, like [eventTimeFormat](https://legacy.fullcalendar.io/v5/eventTimeFormat.md). The default will look something like `2:00pm - 3:00pm`.

If you want to customize the title in the toolbar, use [titleRangeSeparator](https://legacy.fullcalendar.io/v5/titleRangeSeparator.md) instead.
