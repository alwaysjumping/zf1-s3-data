# Calendar::view

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-view
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-view.md

Access the [View Object](https://legacy.fullcalendar.io/v5/view-object.md) for the current view.

This is a property of a `Calendar` object, not a method.
This is useful if you want to get information about the calendar’s title or start/end dates.

Example Usage:

```js
var view = calendar.view;
alert("The view's title is " + view.title);
```
