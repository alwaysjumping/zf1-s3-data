# eventMouseEnter

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventMouseEnter
>
> Latest version (v7): https://fullcalendar.io/docs/eventMouseEnter.md

Triggered when the user mouses over an event. Similar to the native [mouseenter](https://developer.mozilla.org/en-US/docs/Web/Events/mouseenter).

<div class='spec' markdown='1'>
function( *mouseEnterInfo* ) { }
</div>

`mouseEnterInfo` is a plain object with the following properties:

<table>

<tr>
<th>event</th>
<td markdown='1'>
The associated [Event Object](https://legacy.fullcalendar.io/v5/event-object.md).
</td>
</tr>

<tr>
<th>el</th>
<td markdown='1'>
The HTML element for this event.
</td>
</tr>

<tr>
<th>jsEvent</th>
<td markdown='1'>
The native JavaScript event with low-level information such as click coordinates.
</td>
</tr>

<tr>
<th>view</th>
<td markdown='1'>
The current [View Object](https://legacy.fullcalendar.io/v5/view-object.md).
</td>
</tr>

</table>

Unlike some other event-related interactions, `eventMouseEnter` does not require the `interaction` plugin.
