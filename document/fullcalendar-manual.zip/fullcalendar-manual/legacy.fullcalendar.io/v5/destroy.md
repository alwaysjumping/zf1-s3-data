# destroy

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/destroy
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-destroy.md

Restores the container element to the state before FullCalendar was initialized.

<div class='spec' markdown='1'>
calendar.destroy()
</div>

Removes elements, events handlers, and internal data.
