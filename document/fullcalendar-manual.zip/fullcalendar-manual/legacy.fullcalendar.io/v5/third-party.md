# Third Party Tools

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/third-party
>
> Latest version (v7): https://fullcalendar.io/docs/llms.txt

How to use FullCalendar with third-party tools and frameworks.

## Articles

- [TypeScript Support](https://legacy.fullcalendar.io/v5/typescript.md) - It is possible to use FullCalendar and Scheduler with TypeScript, a type-aware superset of the JavaScript language that compiles down to JavaScript.
- [React Component](https://legacy.fullcalendar.io/v5/react.md) - FullCalendar seamlessly integrates with the React JavaScript framework. It provides a component that exactly matches the functionality of FullCalendar’s standard API.
- [Vue Component](https://legacy.fullcalendar.io/v5/vue.md) - FullCalendar seamlessly integrates with the Vue JavaScript framework. It provides a component that exactly matches the functionality of FullCalendar’s standard API.
- [Angular Component](https://legacy.fullcalendar.io/v5/angular.md) - FullCalendar integrates with the Angular 9 - 14. It provides a component that exactly matches the functionality of FullCalendar’s standard API.

## See Also

- [Plugin Index](https://legacy.fullcalendar.io/v5/plugin-index.md)
