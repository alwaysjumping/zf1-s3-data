# Event Model

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-model
>
> Latest version (v7): https://fullcalendar.io/docs/event-model.md

## Articles

- [Event Parsing](https://legacy.fullcalendar.io/v5/event-parsing.md) - When you give your calendar event data, whether it’s through an array, a json feed, or the addEvent method, you specify the event as a plain JavaScript object with properties. This object then gets “parsed” into a proper Event Object that is then exposed in other parts of the API, like the event render hooks method.
- [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) - A JavaScript object that FullCalendar uses to store information about a calendar event. It is exposed in various places of the API such as getEventById and provides methods for dynamic manipulation. It was originally parsed from a plain object.
- [Recurring Events](https://legacy.fullcalendar.io/v5/recurring-events.md) - A recurring event is an event that happens more than once, on a repeating schedule. When a repeating event is turned into individual event instances with individual dates, it is called “expanding” the event.
- [RRule Plugin](https://legacy.fullcalendar.io/v5/rrule-plugin.md) - The RRule plugin is a connector to the rrule js library. It is powerful for specifying recurring events, moreso than FullCalendar’s built-in simple event recurrence.

## Event Data Parsing

- [eventDataTransform](https://legacy.fullcalendar.io/v5/eventDataTransform.md) - A hook for transforming custom data into a standard Event object.
- [defaultAllDay](https://legacy.fullcalendar.io/v5/defaultAllDay.md) - Determines the default value for each Event Object’s allDay property when it is unspecified.
- [defaultAllDayEventDuration](https://legacy.fullcalendar.io/v5/defaultAllDayEventDuration.md) - A fallback duration for all-day Event Objects without a specified end value.
- [defaultTimedEventDuration](https://legacy.fullcalendar.io/v5/defaultTimedEventDuration.md) - A fallback duration for timed Event Objects without a specified end value.
- [forceEventDuration](https://legacy.fullcalendar.io/v5/forceEventDuration.md) - A flag to force assignment of an event’s end if it is unspecified.

## Methods

- [Calendar::getEvents](https://legacy.fullcalendar.io/v5/Calendar-getEvents.md) - Retrieves events that FullCalendar has in memory.
- [Calendar::getEventById](https://legacy.fullcalendar.io/v5/Calendar-getEventById.md) - Returns a single event with the matching id.
- [Calendar::addEvent](https://legacy.fullcalendar.io/v5/Calendar-addEvent.md) - Adds a new event to the calendar.
- [Event::setProp](https://legacy.fullcalendar.io/v5/Event-setProp.md) - Modifies any of the non-date-related properties of an Event Object.
- [Event::setExtendedProp](https://legacy.fullcalendar.io/v5/Event-setExtendedProp.md) - Modifies a single property in an Event Object’s extendedProps hash.
- [Event::setStart](https://legacy.fullcalendar.io/v5/Event-setStart.md) - Sets an event’s start date.
- [Event::setEnd](https://legacy.fullcalendar.io/v5/Event-setEnd.md) - Sets an event’s end date.
- [Event::setDates](https://legacy.fullcalendar.io/v5/Event-setDates.md) - Sets an event’s start date, end date, and allDay properties at the same time.
- [Event::setAllDay](https://legacy.fullcalendar.io/v5/Event-setAllDay.md) - Sets whether an event is considered all-day.
- [Event::moveStart](https://legacy.fullcalendar.io/v5/Event-moveStart.md) - Will move an event’s start date by a specific period of time.
- [Event::moveEnd](https://legacy.fullcalendar.io/v5/Event-moveEnd.md) - Will move an event’s end date by a specific period of time.
- [Event::moveDates](https://legacy.fullcalendar.io/v5/Event-moveDates.md) - Will move an event’s start and end dates by a specific period of time.
- [Event::formatRange](https://legacy.fullcalendar.io/v5/Event-formatRange.md) - Formats an event’s dates into a string.
- [Event::remove](https://legacy.fullcalendar.io/v5/Event-remove.md) - Removes an event from the calendar.
- [Event::getResources](https://legacy.fullcalendar.io/v5/Event-getResources.md) - Gets the Resources associated with the given event.
- [Event::setResources](https://legacy.fullcalendar.io/v5/Event-setResources.md) - Sets the Resources associated with the given event.
- [Event::toPlainObject](https://legacy.fullcalendar.io/v5/Event-toPlainObject.md) - Serializes an Event API Object to a plain object that would be fit for JSON.stringify.

## Callbacks

- [eventAdd](https://legacy.fullcalendar.io/v5/eventAdd.md) - Called after an event has been added to the calendar.
- [eventChange](https://legacy.fullcalendar.io/v5/eventChange.md) - Called after an event has been modified in some way.
- [eventRemove](https://legacy.fullcalendar.io/v5/eventRemove.md) - Called after an event has been removed from the calendar.
- [eventsSet](https://legacy.fullcalendar.io/v5/eventsSet.md) - Called after event data is initialized OR changed in any way.

## See Also

- [Associating Events with Resources](https://legacy.fullcalendar.io/v5/resources-and-events.md) - How to specify which resources your events are assigned to.

## Demos

- [Add an event dynamically](https://legacy.fullcalendar.io/v5/Calendar-addEvent-demo)
