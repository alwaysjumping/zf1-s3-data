# eventBorderColor

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventBorderColor
>
> Latest version (v7): https://fullcalendar.io/docs/eventColor.md

Sets the border color for all events on the calendar.

<div class='spec' markdown='1'>
String
</div>

You can use any of the CSS color formats such `#f00`, `#ff0000`, `rgb(255,0,0)`, or `red`.

This option can be overridden on a per-source basis with the `borderColor` [Event Source Object](https://legacy.fullcalendar.io/v5/event-source-object.md) option or on a per-event basis with the `borderColor` [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) option.
