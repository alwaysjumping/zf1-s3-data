# initialResources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/initialResources
>
> Latest version (v7): https://fullcalendar.io/docs/initialResources.md

Premium feature.

This is exactly like specifying [resources as an array](https://legacy.fullcalendar.io/v5/resources-array.md) except that if the supplied value changes, the calendar will **NOT** be updated to reflect. Only applicable to declarative front-end frameworks such as React, Vue, and Angular.

Useful for when you want to supply an initial set of resources and then manipulate these resources via the API. If you use `initialResources`, when your component receives new props, your changes will not be overwritten with the original resource array.
