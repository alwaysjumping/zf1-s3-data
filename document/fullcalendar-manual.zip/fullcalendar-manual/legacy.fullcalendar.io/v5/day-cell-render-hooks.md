# Day-Cell Render Hooks

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/day-cell-render-hooks
>
> Latest version (v7): https://fullcalendar.io/docs/day-cell-render-hooks.md

Customize the day cells in daygrid and timegrid views with the following options:

`dayCellClassNames` - a [ClassName Input](https://legacy.fullcalendar.io/v5/classname-input.md) for adding classNames to the `<td>` cell

`dayCellContent` - a [Content Injection Input](https://legacy.fullcalendar.io/v5/content-injection.md). Generated content is inserted *inside* the inner-most wrapper of the day cell. It does not replace the `<td>` cell.

`dayCellDidMount` - called right after the `<td>` has been added to the DOM

`dayCellWillUnmount` - called right before the `<td>` will be removed from the DOM


## Timeline View

For customizing the day cells in [Timeline view](https://legacy.fullcalendar.io/v5/timeline-view.md), use the [Slot Render Hooks](https://legacy.fullcalendar.io/v5/slot-render-hooks.md) instead. From an API-perspective they are considered "slots," not "days," because they can be any duration.


## Argument

When the above hooks are specified as a function in the form `function(arg)`, the `arg` is an object with the following properties:

- `date` - Date object
- `dayNumberText`
- `isPast`
- `isFuture`
- `isToday`
- `isOther`
- `resource` - if the date cell lives under a specific resource in [vertical resource view](https://legacy.fullcalendar.io/v5/vertical-resource-view.md), this value will be the [Resource Object](https://legacy.fullcalendar.io/v5/resource-object.md)
- `el` - the `<td>` element. only available in `dayCellDidMount` and `dayCellWillUnmount`
