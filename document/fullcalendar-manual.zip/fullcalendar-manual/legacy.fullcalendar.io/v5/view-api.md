# View API

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/view-api
>
> Latest version (v7): https://fullcalendar.io/docs/view-api.md

FullCalendar provides settings, methods, and callbacks for interacting with and switching the current view.

## Articles

- [initialView](https://legacy.fullcalendar.io/v5/initialView.md) - The initial view when the calendar loads.
- [View Object](https://legacy.fullcalendar.io/v5/view-object.md) - A View object contains information about a calendar view, such as title and date range. This information about the current view is passed into nearly every handler.
- [Calendar::view](https://legacy.fullcalendar.io/v5/Calendar-view.md) - Access the View Object for the current view.
- [Calendar::changeView](https://legacy.fullcalendar.io/v5/Calendar-changeView.md) - Immediately switches to a different view.
- [View Render Hooks](https://legacy.fullcalendar.io/v5/view-render-hooks.md) - Hooks

## See Also

- [View-Specific Options](https://legacy.fullcalendar.io/v5/view-specific-options.md) - You can specify options that apply only to specific calendar views.
