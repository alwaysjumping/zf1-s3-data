# eventAdd

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventAdd
>
> Latest version (v7): https://fullcalendar.io/docs/eventAdd.md

Called after an event has been added to the calendar.

<div class='spec' markdown='1'>
function( addInfo )
</div>

This fires after [Calendar::addEvent](https://legacy.fullcalendar.io/v5/Calendar-addEvent.md) is called or when an external event is dropped from [outside the calendar](https://legacy.fullcalendar.io/v5/external-dragging.md) or from [a different calendar](https://legacy.fullcalendar.io/v5/other-calendar-dragging.md). If being called as a result of the latter two, `eventAdd` will be fired *after* [eventReceive](https://legacy.fullcalendar.io/v5/eventReceive.md).

The `addInfo` argument has the following properties:

<table>

<tr>
<th>event</th>
<td>an <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Object</a> for the added event</td>
</tr>

<tr>
<th>relatedEvents</th>
<td>an array of other related <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Objects</a> that have also been added. an event might have other <a href='https://legacy.fullcalendar.io/v5/recurring-events.md'>recurring event</a> instances or might be linked to other events with the same <code>groupId</code></td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

</table>
