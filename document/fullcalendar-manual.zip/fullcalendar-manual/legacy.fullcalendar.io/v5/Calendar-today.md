# Calendar::today

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-today
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-today.md

Moves the calendar to the current date.

<div class='spec' markdown='1'>
calendar.today()
</div>

Example using `today` with an external button:

```js
document.getElementById('my-today-button').addEventListener('click', function() {
  calendar.today();
});
```
