# drop

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/drop
>
> Latest version (v7): https://fullcalendar.io/docs/drop.md

Called when an [external draggable element](https://legacy.fullcalendar.io/v5/external-dragging.md) or [an event from another calendar](https://legacy.fullcalendar.io/v5/other-calendar-dragging.md) has been dropped onto the calendar.

<div class='spec' markdown='1'>
function( *dropInfo* ) { }
</div>

`dropInfo` is a plain object with the following properties:

<table>

<tr>
<th>allDay</th>
<td markdown='1'>
`true` or `false` whether dropped on one of the all-day cells.
</td>
</tr>

<tr>
<th>date</th>
<td markdown='1'>
The [Date](https://legacy.fullcalendar.io/v5/date-object.md) of where the draggable was dropped.
</td>
</tr>

<tr>
<th>dateStr</th>
<td markdown='1'>
The [ISO8601 string](https://en.wikipedia.org/wiki/ISO_8601) representation of where the draggable was dropped.
</td>
</tr>

<tr>
<th>draggedEl</th>
<td markdown='1'>
The HTML element that was being dragged.
</td>
</tr>

<tr>
<th>jsEvent</th>
<td markdown='1'>
The native JavaScript event with low-level information such as click coordinates.
</td>
</tr>

<tr>
<th>resource</th>
<td markdown='1'>
If the current view is a resource-view, the [Resource Object](https://legacy.fullcalendar.io/v5/resource-object.md) the element was dropped on. Must be using one of the [resource plugins](https://fullcalendar.io/pricing).
</td>
</tr>

<tr>
<th>view</th>
<td markdown='1'>
The current [View Object](https://legacy.fullcalendar.io/v5/view-object.md).
</td>
</tr>

</table>

If you need an Event object, see [eventReceive](https://legacy.fullcalendar.io/v5/eventReceive.md) instead.
