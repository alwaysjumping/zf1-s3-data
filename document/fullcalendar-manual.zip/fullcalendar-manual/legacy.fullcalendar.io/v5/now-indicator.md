# Now Indicator

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/now-indicator
>
> Latest version (v7): https://fullcalendar.io/docs/now-indicator.md

You can display a marker that represents the exact current time in both [TimeGrid view](https://legacy.fullcalendar.io/v5/timegrid-view.md) and [Timeline view](https://legacy.fullcalendar.io/v5/timeline-view.md).

## Articles

- [nowIndicator](https://legacy.fullcalendar.io/v5/nowIndicator.md) - Whether or not to display a marker indicating the current time.
- [now](https://legacy.fullcalendar.io/v5/now.md) - Explicitly sets the “today” date of the calendar. This is the day that is normally highlighted in yellow.
- [Now-Indicator Render Hooks](https://legacy.fullcalendar.io/v5/now-indicator-render-hooks.md) - nowIndicatorClassNames - a ClassName Input

## Demos

- [TimeGrid view now-indicator](https://legacy.fullcalendar.io/v5/timegrid-nowIndicator-demo)
- [Timeline-view now-indicator](https://legacy.fullcalendar.io/v5/timeline-nowIndicator-demo)
