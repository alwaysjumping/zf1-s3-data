# eventSources

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventSources
>
> Latest version (v7): https://fullcalendar.io/docs/eventSources.md

A way to specify multiple event sources.

<div class='spec' markdown='1'>
Array
</div>

This option is used instead of the `events` option.

You can put any number of [event arrays](https://legacy.fullcalendar.io/v5/events-array.md), [functions](https://legacy.fullcalendar.io/v5/events-function.md), [JSON feed URLs](https://legacy.fullcalendar.io/v5/events-json-feed.md), or full-out [Event Source Objects](https://legacy.fullcalendar.io/v5/event-source-object.md) into the `eventSources` array.

Here is an example calendar that displays two [JSON feeds](https://legacy.fullcalendar.io/v5/events-json-feed.md):

```js
var calendar = new Calendar(calendarEl, {
  eventSources: [
    '/feed1.php',
    '/feed2.php'
  ]
});
```
