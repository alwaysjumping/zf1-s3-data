# eventRemove

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventRemove
>
> Latest version (v7): https://fullcalendar.io/docs/eventRemove.md

Called after an event has been removed from the calendar.

<div class='spec' markdown='1'>
function( removeInfo )
</div>

This fires after [Event::remove](https://legacy.fullcalendar.io/v5/Event-remove.md) is called. It also happens when an event is being dragged [to another calendar](https://legacy.fullcalendar.io/v5/other-calendar-dragging.md), in which case `eventRemove` fires *after* [eventLeave](https://legacy.fullcalendar.io/v5/eventLeave.md).

The `removeInfo` argument has the following properties:

<table>

<tr>
<th>event</th>
<td>the <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Object</a> that was removed</td>
</tr>

<tr>
<th>relatedEvents</th>
<td>an array of other related <a href='https://legacy.fullcalendar.io/v5/event-object.md'>Event Objects</a> that were also be removed. an event might have other <a href='https://legacy.fullcalendar.io/v5/recurring-events.md'>recurring event</a> instances or might be linked to other events with the same <code>groupId</code></td>
</tr>

<tr>
<th>revert</th>
<td>a function that can be called to reverse this action</td>
</tr>

</table>
