# locale

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/locale
>
> Latest version (v7): https://fullcalendar.io/docs/locale.md

The `locale` and `locales` options allow you to localize certain aspects of the calendar:

- the text in buttons, as defined by [headerToolbar](https://legacy.fullcalendar.io/v5/headerToolbar.md)
- text that contains month or day-of-week strings
- date formatting, such as [eventTimeFormat](https://legacy.fullcalendar.io/v5/eventTimeFormat.md)
- [weekNumberCalculation](https://legacy.fullcalendar.io/v5/weekNumberCalculation.md)
- [firstDay](https://legacy.fullcalendar.io/v5/firstDay.md)


## Loading Locales for an ES6 build system

If you are using [an ES6 build system](https://legacy.fullcalendar.io/v5/initialize-es6.md) and want to load a specific locale, do something like this:

```js
import { Calendar } from '@fullcalendar/core';
import esLocale from '@fullcalendar/core/locales/es';
...
let calendar = new Calendar(calendarEl, {
  locale: esLocale
});
...
```

If you want to load multiple specific locales with the ability to switch between them after pageload, do something like this:

```js
import { Calendar } from '@fullcalendar/core';
import esLocale from '@fullcalendar/core/locales/es';
import frLocale from '@fullcalendar/core/locales/fr';
...
let calendar = new Calendar(calendarEl, {
  locales: [ esLocale, frLocale ],
  locale: 'fr' // the initial locale. if not specified, uses the first one
});
...
calendar.setOption('locale', 'es');
```

If you want to load ALL locales have the ability to switch between them after pageload, do something like this:

```js
import { Calendar } from '@fullcalendar/core';
import allLocales from '@fullcalendar/core/locales-all';
...
let calendar = new Calendar(calendarEl, {
  locales: allLocales,
  locale: 'fr' // the initial locale
});
...
calendar.setOption('locale', 'pt-br');
```


## Loading Locales with Script Tags and Browser Globals

If you are using [script tags and browser globals](https://legacy.fullcalendar.io/v5/initialize-globals.md) and want to load a specific locale, do something like this:

```html
<script src='fullcalendar/core/main.js'></script>
<script src='fullcalendar/core/locales/es.js'></script>
<script>
...
var calendar = new FullCalendar.Calendar(calendarEl, {
  locale: 'es'
});
...
</script>
```

If you want to load ALL locales have the ability to switch between them after pageload, do something like this:

```html
<script src='fullcalendar/core/main.js'></script>
<script src='fullcalendar/core/locales-all.js'></script>
<script>
...
var calendar = new FullCalendar.Calendar(calendarEl, {
  locale: 'es'
});
...
calendar.setOption('locale', 'fr');
</script>
```

For more information, [view a live demo](https://legacy.fullcalendar.io/v5/locale-demo).
