# initialView

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/initialView
>
> Latest version (v7): https://fullcalendar.io/docs/initialView.md

The initial view when the calendar loads.

<div class='spec' markdown='1'>
String. the default value is `'dayGridMonth'`
</div>

A name of any of the available views, such as `'dayGridWeek'`, `'timeGridDay'`, `'listWeek'` .
