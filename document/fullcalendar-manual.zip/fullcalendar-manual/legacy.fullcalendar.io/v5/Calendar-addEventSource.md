# Calendar::addEventSource

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Calendar-addEventSource
>
> Latest version (v7): https://fullcalendar.io/docs/Calendar-addEventSource.md

Dynamically adds an event source.

<div class='spec' markdown='1'>
calendar.addEventSource( *source* )
</div>

Source may be an Array/URL/Function just as in the `events` option. Events will be immediately fetched from this source and placed on the calendar.
