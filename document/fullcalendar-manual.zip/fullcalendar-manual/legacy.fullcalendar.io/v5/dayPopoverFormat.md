# dayPopoverFormat

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/dayPopoverFormat
>
> Latest version (v7): https://fullcalendar.io/docs/popoverFormat.md

Determines the date format of title of the popover created by the [moreLinkClick](https://legacy.fullcalendar.io/v5/moreLinkClick.md) option.

<div class='spec' markdown='1'>
[Date Formatter](https://legacy.fullcalendar.io/v5/date-formatting.md), *default*:

```js
{ month: 'long', day: 'numeric', year: 'numeric' }
```
</div>

The default value produces strings like `Monday, September 24`.
