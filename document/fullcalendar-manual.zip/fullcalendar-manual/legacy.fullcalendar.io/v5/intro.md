# Introduction

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/intro
>
> Latest version (v7): https://fullcalendar.io/docs/llms.txt

How to get FullCalendar's code, initialize a calendar, and other basic principles.

## Articles

- [Getting Started](https://legacy.fullcalendar.io/v5/getting-started.md) - How to initialize a calendar
- [Initialize with Script Tags](https://legacy.fullcalendar.io/v5/initialize-globals.md) - Use pre-built bundles and HTML script tags
- [Initialize with ES6 Build System](https://legacy.fullcalendar.io/v5/initialize-es6.md) - For non-trivial projects, it is recommended to use an ES6-compatible build system like Webpack or Rollup along with a package manager like NPM or Yarn.
- [Plugin Index](https://legacy.fullcalendar.io/v5/plugin-index.md)
- [Handlers](https://legacy.fullcalendar.io/v5/handlers.md) - How to attach handlers to your calendar, which execute when other things happen.
- [Methods](https://legacy.fullcalendar.io/v5/methods.md) - Methods provide ways to manipulate the calendar from JavaScript code.
- [Reduced Test Cases](https://legacy.fullcalendar.io/v5/reduced-test-cases.md) - How to create a simplified, reproducible demonstration of a bug
- [V5 Release Notes and Upgrade Guide](https://legacy.fullcalendar.io/v5/upgrading-from-v4.md) - What changed between v4 and v5, and how to upgrade

## More Advanced

- [CSS Customization](https://legacy.fullcalendar.io/v5/css-customization.md) - This article describes the various techniques for customizing the CSS of your calendar.
- [View-Specific Options](https://legacy.fullcalendar.io/v5/view-specific-options.md) - You can specify options that apply only to specific calendar views.
- [Get/Set Options Dynamically](https://legacy.fullcalendar.io/v5/dynamic-options.md) - You can get/set calendar options after a calendar has already been initialized.
- [render](https://legacy.fullcalendar.io/v5/render.md) - Will initially render a calendar, or if it is already rendered, will rerender it.
- [destroy](https://legacy.fullcalendar.io/v5/destroy.md) - Restores the container element to the state before FullCalendar was initialized.
- [rerenderDelay](https://legacy.fullcalendar.io/v5/rerenderDelay.md) - The amount of milliseconds to wait before rerendering anything on a calendar.
- [Calendar::render](https://legacy.fullcalendar.io/v5/Calendar-render.md) - Initially render the calendar, or rerender it after initialization.
- [Calendar::batchRendering](https://legacy.fullcalendar.io/v5/Calendar-batchRendering.md) - A way to group operations that cause rerenders.
- [ClassName Inputs](https://legacy.fullcalendar.io/v5/classname-input.md) - CSS classNames can be injected into FullCalendar’s DOM in various places. They can be provided in the following formats.
- [Content Injection](https://legacy.fullcalendar.io/v5/content-injection.md) - Custom content can be injected into FullCalendar’s DOM in various places. This content can be provided in the following formats.

## See Also

- [initialDate](https://legacy.fullcalendar.io/v5/initialDate.md) - The initial date displayed when the calendar first loads.
- [initialView](https://legacy.fullcalendar.io/v5/initialView.md) - The initial view when the calendar loads.
- [View API](https://legacy.fullcalendar.io/v5/view-api.md) - FullCalendar provides settings, methods, and callbacks for interacting with and switching the current view.
