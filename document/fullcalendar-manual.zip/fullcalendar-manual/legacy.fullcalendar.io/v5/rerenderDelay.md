# rerenderDelay

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/rerenderDelay
>
> Latest version (v7): https://fullcalendar.io/docs/rerenderDelay.md

The amount of milliseconds to wait before rerendering anything on a calendar.

<div class='spec' markdown='1'>
Integer / `null` (turned off, the default)
</div>

When this value is specified as a millisecond number value, the calendar will begin to wait after any operation that might result in rerendering. The rerendering could be a result of any action, such as a changing of the current view or an [addEvent](https://legacy.fullcalendar.io/v5/Calendar-addEvent.md) call. After this time has passed, the calendar will rerender what it needs to all-at-once. This can reduce the number of rerenders, for performance reasons.
