# Event::remove

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/Event-remove
>
> Latest version (v7): https://fullcalendar.io/docs/Event-remove.md

Removes an event from the calendar.

<div class='spec' markdown='1'>
event.remove()
</div>

You must call this on an [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) that you received elsewhere in the API, such as [getEventById](https://legacy.fullcalendar.io/v5/Calendar-getEventById.md).
