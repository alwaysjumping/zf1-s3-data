# Event Parsing

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/event-parsing
>
> Latest version (v7): https://fullcalendar.io/docs/event-parsing.md

When you give your calendar event data, whether it's through [an array](https://legacy.fullcalendar.io/v5/events-array.md), [a json feed](https://legacy.fullcalendar.io/v5/events-json-feed.md), or the [addEvent method](https://legacy.fullcalendar.io/v5/Calendar-addEvent.md), you specify the event as a plain JavaScript object with properties. This object then gets "parsed" into a proper [Event Object](https://legacy.fullcalendar.io/v5/event-object.md) that is then exposed in other parts of the API, like the [event render hooks](https://legacy.fullcalendar.io/v5/event-render-hooks.md) method.

This article describes all the properties you may supply in your plain, pre-parsed object. To demonstrate the simplest case:

```js
var calendar = new Calendar(calendarEl, {
  events: [
    { // this object will be "parsed" into an Event Object
      title: 'The Title', // a property!
      start: '2018-09-01', // a property!
      end: '2018-09-02' // a property! ** see important note below about 'end' **
    }
  ]
})
```

Here are all the available properties, **all of which are optional**:

<table>

  <tr>
  <th>id</th>
  <td markdown='1'>
  String or Integer. Will uniquely identify your event. Useful for [getEventById](https://legacy.fullcalendar.io/v5/Calendar-getEventById.md).
  </td>
  </tr>

  <tr>
  <th>groupId</th>
  <td markdown='1'>
  String or Integer. Events that share a `groupId` will be dragged and resized together automatically.
  </td>
  </tr>

  <tr>
  <th>allDay</th>
  <td markdown='1'>
  Boolean (`true` or `false`). Determines if the event is shown in the "all-day" section of the view, if applicable. Determines if time text is displayed in the event. If this value is not specified, it will be inferred by the `start` and `end` properties. See notes below.

  **Do not put quotes around this value**. That would make it a string, not a boolean.
  </td>
  </tr>

  <tr>
  <th>start</th>
  <td markdown='1'>
  Something [date-parseable](https://legacy.fullcalendar.io/v5/date-parsing.md). When your event begins. If your event is explicitly `allDay`, hour, minutes, seconds and milliseconds will be ignored.
  </td>
  </tr>

  <tr>
  <th>end</th>
  <td markdown='1'>
  Something [date-parseable](https://legacy.fullcalendar.io/v5/date-parsing.md). When your event ends. If your event is explicitly `allDay`, hour, minutes, seconds and milliseconds will be ignored. If omitted, your events will appear to have the default duration. See [defaultAllDayEventDuration](https://legacy.fullcalendar.io/v5/defaultAllDayEventDuration.md), [defaultTimedEventDuration](https://legacy.fullcalendar.io/v5/defaultTimedEventDuration.md), and [forceEventDuration](https://legacy.fullcalendar.io/v5/forceEventDuration.md) for more info.

  **Note: This value is exclusive.** For example, if you have an all-day event that has an `end` of `2018-09-03`, then it will span through `2018-09-02` and end before the start of `2018-09-03`.
  </td>
  </tr>

  <tr>
  <th>daysOfWeek</th>
  <td markdown='1'>
  Array. (For defining a [simple recurring event](https://legacy.fullcalendar.io/v5/recurring-events.md)). The days of the week this event repeats. An array of integers representing days e.g. `[0, 1]` for an event that repeats on Sundays and Mondays.
  </td>
  </tr>

  <tr>
  <th>startTime</th>
  <td markdown='1'>
  Something [duration-parseable](https://legacy.fullcalendar.io/v5/duration-object.md). (For defining a [simple recurring event](https://legacy.fullcalendar.io/v5/recurring-events.md)). The time of day the event starts.
  </td>
  </tr>

  <tr>
  <th>endTime</th>
  <td markdown='1'>
  Something [duration-parseable](https://legacy.fullcalendar.io/v5/duration-object.md). (For defining a [simple recurring event](https://legacy.fullcalendar.io/v5/recurring-events.md)). The time of day the event ends.
  </td>
  </tr>

  <tr>
  <th>startRecur</th>
  <td markdown='1'>
  Something [date-parseable](https://legacy.fullcalendar.io/v5/date-parsing.md). (For defining a [simple recurring event](https://legacy.fullcalendar.io/v5/recurring-events.md)). When recurrences of the event start.
  </td>
  </tr>

  <tr>
  <th>endRecur</th>
  <td markdown='1'>
  Something [date-parseable](https://legacy.fullcalendar.io/v5/date-parsing.md). (For defining a [simple recurring event](https://legacy.fullcalendar.io/v5/recurring-events.md)). When recurrences of the event end.
  </td>
  </tr>

  <tr>
  <th>title</th>
  <td markdown='1'>
  String. The text that will appear on an event.
  </td>
  </tr>

  <tr>
  <th>url</th>
  <td markdown='1'>
  String. A URL that will be visited when this event is clicked by the user. For more information on controlling this behavior, see the [eventClick](https://legacy.fullcalendar.io/v5/eventClick.md) callback.
  </td>
  </tr>

  <tr>
  <th>interactive</th>
  <td markdown='1'>
  Boolean. Whether or not the event is tabbable. Defaults to `true` if `url` is present, `false` otherwise. See [eventInteractive](https://legacy.fullcalendar.io/v5/eventInteractive.md) for more info.
  </td>
  </tr>

  <tr>
  <th><div style='white-space:nowrap'>className or</div> classNames</th>
  <td markdown='1'>
  String or Array. A single string like `'myclass'`, a space-separated string like `'myclass1 myclass2'`, or an array of strings like `[ 'myclass1', 'myclass2' ]`. Determines which HTML classNames will be attached to the rendered event.
  </td>
  </tr>

  <tr>
  <th>editable</th>
  <td markdown='1'>
  Boolean (`true` or `false`). Overrides the master [editable](https://legacy.fullcalendar.io/v5/editable.md) option for this single event.
  </td>
  </tr>

  <tr>
  <th>startEditable</th>
  <td markdown='1'>
  Boolean (`true` or `false`). Overrides the master [eventStartEditable](https://legacy.fullcalendar.io/v5/eventStartEditable.md) option for this single event.
  </td>
  </tr>

  <tr>
  <th>durationEditable</th>
  <td markdown='1'>
  Boolean (`true` or `false`). Overrides the master [eventDurationEditable](https://legacy.fullcalendar.io/v5/eventDurationEditable.md) option for this single event.
  </td>
  </tr>

  <tr>
  <th>resourceEditable</th>
  <td markdown='1'>
  Boolean (`true` or `false`). Overrides the master [eventResourceEditable](https://legacy.fullcalendar.io/v5/eventResourceEditable.md) option for this single event.
  Requires one of the [resource plugins](https://fullcalendar.io/pricing).
  </td>
  </tr>

  <tr>
  <th>resourceId</th>
  <td markdown='1'>
  String. The string ID of a [Resource](https://legacy.fullcalendar.io/v5/resource-object.md).
  See [Associating Events with Resources](https://legacy.fullcalendar.io/v5/resources-and-events.md).
  Requires one of the [resource plugins](https://fullcalendar.io/pricing).
  </td>
  </tr>

  <tr>
  <th>resourceIds</th>
  <td markdown='1'>
  Array. An array of string IDs of [Resources](https://legacy.fullcalendar.io/v5/resource-object.md).
  See [Associating Events with Resources](https://legacy.fullcalendar.io/v5/resources-and-events.md).
  Requires one of the [resource plugins](https://fullcalendar.io/pricing).
  </td>
  </tr>

  <tr>
  <th>display</th>
  <td markdown='1'>
  Allows alternate rendering of the event, like background events. Can be `'auto'` (the default), `'block'`, `'list-item'`, `'background'`, `'inverse-background'`, or `'none'`. See [eventDisplay](https://legacy.fullcalendar.io/v5/eventDisplay.md).
  </td>
  </tr>

  <tr>
  <th>overlap</th>
  <td markdown='1'>
  Boolean (`true` or `false`). Overrides the master [eventOverlap](https://legacy.fullcalendar.io/v5/eventOverlap.md) option for this single event. If `false`, prevents this event from being dragged/resized over other events. Also prevents other events from being dragged/resized over this event.
  </td>
  </tr>

  <tr>
  <th>constraint</th>
  <td markdown='1'>
  A **groupId** belonging to other events, `"businessHours"`, or an object. Overrides the master [eventConstraint](https://legacy.fullcalendar.io/v5/eventConstraint.md) option for this single event.
  </td>
  </tr>

  <tr>
  <th>color</th>
  <td markdown='1'>
  String. An alias for specifying the **backgroundColor** and **borderColor** at the same time.
  </td>
  </tr>

  <tr>
  <th>backgroundColor</th>
  <td markdown='1'>
  Sets an event's background color just like the calendar-wide [eventBackgroundColor](https://legacy.fullcalendar.io/v5/eventBackgroundColor.md) option.
  </td>
  </tr>

  <tr>
  <th>borderColor</th>
  <td markdown='1'>
  Sets an event's border color just like the calendar-wide [eventBorderColor](https://legacy.fullcalendar.io/v5/eventBorderColor.md) option.
  </td>
  </tr>

  <tr>
  <th>textColor</th>
  <td markdown='1'>
  Sets an event's text color just like the calendar-wide [eventTextColor](https://legacy.fullcalendar.io/v5/eventTextColor.md) option.
  </td>
  </tr>

  <tr>
  <th>
  <div style='white-space:nowrap'>rrule</div>
  <div style='white-space:nowrap'>duration</div>
  </th>
  <td markdown='1'>
  These properties are for [RRule recurrence](https://legacy.fullcalendar.io/v5/rrule-plugin.md).
  </td>
  </tr>

  <tr>
  <th>
  <div style='white-space:nowrap'>daysOfWeek</div>
  <div style='white-space:nowrap'>startTime</div>
  <div style='white-space:nowrap'>endTime</div>
  <div style='white-space:nowrap'>startRecur</div>
  <div style='white-space:nowrap'>endRecur</div>
  <div style='white-space:nowrap'>groupId</div>
  </th>
  <td markdown='1'>
  These properties are for ["simple" recurrence](https://legacy.fullcalendar.io/v5/recurring-events.md).
  </td>
  </tr>

  <tr>
  <th>extendedProps</th>
  <td markdown='1'>
  Object. A plain object with any miscellaneous properties. It will be directly transferred to the `extendedProps` hash in each [Event Object](https://legacy.fullcalendar.io/v5/event-object.md). Often, these props are useful in [event render hooks](https://legacy.fullcalendar.io/v5/event-render-hooks.md).
  </td>
  </tr>

  <tr>
  <th><em>any other property!</em></th>
  <td markdown='1'>
  Every other non-standard property will be transferred over to the `extendedProps` hash in the [Event Object](https://legacy.fullcalendar.io/v5/event-object.md). However, it is recommended to explicitly define these in the `extendedProps` hash.
  </td>
  </tr>

</table>

## Events and Dates

There are 3 date-related properties of events to highlight:

### `allDay`

If an event object does not explicitly define an `allDay` value, FullCalendar will do its best to guess whether it is an all-day event or not. It will look at the `start` and `end` values of your supplied event, and if, for example, both are ISO8601 strings in the format `2018-09-01` without time parts, it will infer `allDay` as `true`. If the time parts of only `start` or `end` is provided, FullCalendar assumes that `allDay` is `false`.

### `start`

As defined above, this is the date when an event begins. In other words, the event starts from this given date value and continues onwards. This value specifies the **inclusive** start of the event. In effect, if `allDay` is not explicitly set to `true` and `start` is `2018-09-01`, internally, this is recognized as `2018-09-01T00:00:00`.

### `end`

As defined above, this is the date when an event finishes. In other words, the event continues up to this cut-off point in time. This value specifies the **exclusive** end of the event. Since the event is not expected to continue beyond the given `end` date it may also be described as non-inclusive.

Again, if `allDay` is not explicitly set to `true` and `end` is `2018-09-07`, internally this is recognized as `2018-09-07T00:00:00`. It is that point in time, at the final part of `2018-09-06` and beginning of `2018-09-07`.

FullCalendar handles these dates in the same way as discussed in the [iCalendar Specifications (RFC 5545)](https://icalendar.org/iCalendar-RFC-5545/3-6-1-event-component.html) and [Google Calendar API](https://developers.google.com/calendar/v3/reference/events/list) documentation.

In summary, `start` date is **inclusive** while `end` date is **exclusive**. In order to avoid inconsistencies, applications should consider passing [ISO8601 strings](https://en.wikipedia.org/wiki/ISO_8601) with datetime values for `start` and `end` dates to FullCalendar, if `allDay` is `false`.
