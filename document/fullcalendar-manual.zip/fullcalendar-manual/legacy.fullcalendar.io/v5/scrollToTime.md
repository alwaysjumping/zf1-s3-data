# scrollToTime

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/scrollToTime
>
> Latest version (v7): https://fullcalendar.io/docs/scrollToTime.md

Programatically scroll the current view to the given time.

<div class='spec' markdown='1'>
calendar.scrollToTime( [durationInput](https://legacy.fullcalendar.io/v5/duration-object.md) )
</div>
