# eventSourceFailure

> FullCalendar v5 documentation, for an old release. Web version: https://legacy.fullcalendar.io/v5/eventSourceFailure
>
> Latest version (v7): https://fullcalendar.io/docs/eventSourceFailure.md

Called when any of the event sources fails. Probably because [an AJAX request](https://legacy.fullcalendar.io/v5/events-json-feed.md) failed.

<div class='spec' markdown='1'>
function( *errorObj* )
</div>

Receives one argument, an error object, which is guaranteed to have at least a `message` property (a string).
