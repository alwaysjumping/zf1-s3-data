# Lecture 10.4 — Sass and CSS Compilation

**Course:** Modern Web Development Technologies and Practical Programming  
**Audience:** Beginner / junior developers  
**Suggested duration:** 75–90 minutes  
**Primary lab stack:** PHP 7.4, MariaDB, HTML, CSS, JavaScript (with optional locally installed tooling)  
**Offline use:** Lecture text and starter code are self-contained. Some labs require software to be installed locally beforehand.

## 1. Learning objectives

After this lecture, learners should be able to:
1. Define **Sass and CSS Compilation** in their own words.
2. Explain which practical development problem motivates this topic.
3. Read, run, and modify the starter example.
4. Identify one trade-off, one failure mode, and one security or maintenance consideration.
5. Explain when a simpler alternative would be preferable.

## 2. Concept and motivation

**Core lesson:** Compile .scss, manage partials and variables, compare source maps and minified output.

A web technology is useful only when it addresses a real requirement. Before adopting it, identify the expected users, data, operating environment, supported browsers, security constraints, and maintenance cost. Prefer a small working implementation before adding a framework or a distributed service.

### Questions to ask before coding

- What input does this component accept and what output should it produce?
- Which part executes in the browser, application server, or database?
- What happens when input is invalid, a request fails, or a dependency is unavailable?
- How will another developer understand and test this behavior?
- Does this technique require newer runtime or browser capabilities?

## 3. How it works

**Key teaching point A:** Compile .scss, manage partials and variables, compare source maps and minified output.

**Key teaching point B:** Explain the trade-offs and failure cases using the example below.

Follow this general engineering sequence:

```text
Requirement -> Design choice -> Implementation -> Test
      ^                                      |
      +---------- Review and improve <------+
```

For the topic **Sass and CSS Compilation**, discuss the interface/contract first, then the implementation details. Use a realistic employee-management or dashboard example to show where the concept belongs.

## 4. Guided starter example

The following is a **foundation example for Part 10**, not a complete implementation of every feature named in this lecture. Adapt it using the topic-specific tasks in Sections 5 and 7.

```bash
git init
git add README.md
git commit -m "Initial training project"
git log --oneline
# Build tools must be installed/prepared before entering an offline environment.
```

**Run it:** Create a local repository, make a change, inspect git diff, and revert safely.

### Code walk-through

1. Identify the entry point and the inputs.
2. Identify the operation that produces a visible result.
3. Determine what validation or error handling is present.
4. Locate the boundary between this example and external services.
5. Explain how the behavior would change with 100 users or 100,000 records.

## 5. Topic-specific workshop

**Scenario:** A company maintains an internal employee directory and production dashboard. The team is considering **Sass and CSS Compilation**.

**Task A — Explain:** In 3–5 sentences, connect the scenario to this principle: Compile .scss, manage partials and variables, compare source maps and minified output.

**Task B — Design:** Draw a simple flow showing where this technology fits. Label inputs, outputs, errors, and trust boundaries.

**Task C — Modify:** Extend the starter example with one new feature related to **Sass and CSS Compilation**. For a conceptual or architecture lecture, produce a short design document and a small executable proof of concept instead of inventing infrastructure.

**Task D — Test:** Write at least three test cases: normal input, invalid input, and dependency failure. Record the expected result before executing each test.

## 6. Comparison and trade-offs

| Dimension | Simpler / traditional approach | Approach discussed in this lecture |
|---|---|---|
| Setup | Often fewer tools | May require additional conventions or tooling |
| Learning curve | Familiar and direct | Requires understanding new concepts |
| Maintenance | Good for small isolated tasks | Can help structure larger or repeated tasks |
| Compatibility | Usually broad when using basic web standards | Verify actual target runtime/browser support |
| Failure handling | Often local and straightforward | May add asynchronous or distributed failure modes |
| Adoption decision | Prefer when requirements are simple | Prefer only when measurable benefits justify complexity |

**Instructor discussion:** Ask students to argue both for and against adoption in a 5-person team maintaining an offline intranet application.

## 7. Exercises

### Beginner (15 minutes)
Write a glossary of five terms related to **Sass and CSS Compilation**. Annotate the starter example and predict its output before running it.

### Intermediate (20 minutes)
Implement a small change connected to this topic. Document the expected behavior, show the result, and test one edge case.

### Advanced (20 minutes)
Design a production-readiness checklist addressing logging, configuration, security, accessibility where relevant, compatibility, and recoverability. Describe how you would test the system without Internet access.

## 8. Common mistakes

1. Choosing a tool because it is new rather than because the requirement needs it.
2. Copying a code sample without understanding its runtime and dependencies.
3. Assuming client-side checks replace server-side validation.
4. Ignoring error handling, timeouts, or unsupported browser features.
5. Treating a proof of concept as production-ready code.

## 9. Review questions and model answers

**Q1. What problem does Sass and CSS Compilation address?**  
A. Compile .scss, manage partials and variables, compare source maps and minified output.

**Q2. What should you decide before implementation?**  
A. Requirements, environment, interfaces, failure behavior, and maintainability.

**Q3. Why test an invalid input?**  
A. It verifies that failures are controlled and do not corrupt data or expose sensitive information.

**Q4. Does a newer technology automatically make software faster?**  
A. No. Performance depends on the workload, design, configuration, and measurements.

**Q5. What should be included in a code review?**  
A. Correctness, readability, security, test coverage, compatibility, and operational impact.

## 10. Instructor notes

- **10 min:** Motivate the problem with a familiar company workflow.
- **15 min:** Teach terminology and the working model.
- **20 min:** Walk through the starter example and demonstrate output.
- **20 min:** Supervise the topic-specific workshop.
- **10 min:** Compare alternatives and failure modes.
- **10 min:** Review questions and assign exercises.

**Assessment:** Learners pass when they can explain the concept, demonstrate a modification, and describe at least one limitation.

## 11. Further reading (for preparation before going offline)

- MDN Web Docs — web platform concepts and compatibility
- PHP Manual — PHP syntax, security, and runtime behavior
- MariaDB Documentation — SQL, transactions, indexing, and operations
- Official documentation for any library/framework introduced in this lecture

**Compatibility note:** Code examples in this course target PHP 7.4 when PHP is used. PHP 7.4 is end-of-life and should be used only where legacy constraints require it; use a supported PHP release for new production deployments. Examples that use optional tooling require compatible locally installed versions.

---
**End of Lecture 10.4.**
