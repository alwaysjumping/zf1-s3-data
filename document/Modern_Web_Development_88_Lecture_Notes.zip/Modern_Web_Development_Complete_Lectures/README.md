# Modern Web Development Technologies — Lecture Notes

**88 lecture handouts across 12 parts.** These are self-contained instructor/student starter notes, with objectives, concept explanations, starter code, exercises, review questions and teaching guidance. They are **not** 88 fully developed 15–25-page textbooks or 88 independently runnable projects; the code in most lectures is a part-level foundation sample, and topic-specific implementations remain student exercises.

Lecture 1.1 is a longer standalone chapter. Some tools require local installation before offline use. PHP 7.4 is end-of-life; do not use it for new production systems.

## Contents

- Part 1: Web Fundamentals (5 lectures)
- Part 2: HTML and CSS (7 lectures)
- Part 3: JavaScript (10 lectures)
- Part 4: TypeScript (6 lectures)
- Part 5: PHP (8 lectures)
- Part 6: Databases (7 lectures)
- Part 7: APIs and Communication (8 lectures)
- Part 8: Web Architecture (8 lectures)
- Part 9: Security (8 lectures)
- Part 10: Development Tools (7 lectures)
- Part 11: Testing (6 lectures)
- Part 12: Emerging Technologies (8 lectures)
