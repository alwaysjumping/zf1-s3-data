# Cloud Computing Fundamentals — Lectures 1–10

**Course:** Beginner | **Format:** Student Lecture Notes + Teacher’s Guide | **Example:** School website


---
# Lecture 1: Introduction to Cloud Computing

## Part A — Student Lecture Notes

### Learning objectives

Explain introduction to cloud computing, give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

On-demand computing resources accessed over a network.

### School website example

Compare a school buying a server versus renting computing capacity.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

On-demand computing resources accessed over a network.

## Part B — Teacher’s Guide

### Technical background

Compare a school buying a server versus renting computing capacity.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Compare a school buying a server versus renting computing capacity.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 2: How Cloud Computing Works

## Part A — Student Lecture Notes

### Learning objectives

Explain how cloud computing works, give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

Data centers contain physical servers, storage, networking, cooling and power. Virtualization enables virtual machines.

### School website example

Trace DNS → HTTPS → web server → response; distinguish hypervisors from containers.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

Data centers contain physical servers, storage, networking, cooling and power. Virtualization enables virtual machines.

## Part B — Teacher’s Guide

### Technical background

Trace DNS → HTTPS → web server → response; distinguish hypervisors from containers.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Trace DNS → HTTPS → web server → response; distinguish hypervisors from containers.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 3: Cloud Deployment Models

## Part A — Student Lecture Notes

### Learning objectives

Explain cloud deployment models, give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

Public, private, hybrid and multi-cloud describe where and how environments operate.

### School website example

Classify a startup, a bank and a school; distinguish deployment from service models.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

Public, private, hybrid and multi-cloud describe where and how environments operate.

## Part B — Teacher’s Guide

### Technical background

Classify a startup, a bank and a school; distinguish deployment from service models.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Classify a startup, a bank and a school; distinguish deployment from service models.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 4: Software as a Service (SaaS)

## Part A — Student Lecture Notes

### Learning objectives

Explain software as a service (saas), give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

SaaS offers complete provider-operated applications.

### School website example

Compare a hosted school website builder to installing a CMS on a local server.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

SaaS offers complete provider-operated applications.

## Part B — Teacher’s Guide

### Technical background

Compare a hosted school website builder to installing a CMS on a local server.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Compare a hosted school website builder to installing a CMS on a local server.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 5: Platform as a Service (PaaS)

## Part A — Student Lecture Notes

### Learning objectives

Explain platform as a service (paas), give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

PaaS hosts customer-developed applications on managed runtimes.

### School website example

Trace source code → build → deployment → instance → load balancer.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

PaaS hosts customer-developed applications on managed runtimes.

## Part B — Teacher’s Guide

### Technical background

Trace source code → build → deployment → instance → load balancer.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Trace source code → build → deployment → instance → load balancer.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 6: Infrastructure as a Service (IaaS)

## Part A — Student Lecture Notes

### Learning objectives

Explain infrastructure as a service (iaas), give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

IaaS supplies virtual servers, disks and networks.

### School website example

Trace VM image → size → storage → network → boot → SSH → web server.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

IaaS supplies virtual servers, disks and networks.

## Part B — Teacher’s Guide

### Technical background

Trace VM image → size → storage → network → boot → SSH → web server.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Trace VM image → size → storage → network → boot → SSH → web server.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 7: Function as a Service (FaaS)

## Part A — Student Lecture Notes

### Learning objectives

Explain function as a service (faas), give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

FaaS runs functions triggered by events.

### School website example

Trace photo upload → event → function → thumbnail; discuss retries.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

FaaS runs functions triggered by events.

## Part B — Teacher’s Guide

### Technical background

Trace photo upload → event → function → thumbnail; discuss retries.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Trace photo upload → event → function → thumbnail; discuss retries.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 8: Comparison of Service Models

## Part A — Student Lecture Notes

### Learning objectives

Explain comparison of service models, give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

SaaS use software; PaaS deploy apps; IaaS manage virtual machines; FaaS run functions.

### School website example

Compare responsibilities for OS, runtime, code, data and access.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

SaaS use software; PaaS deploy apps; IaaS manage virtual machines; FaaS run functions.

## Part B — Teacher’s Guide

### Technical background

Compare responsibilities for OS, runtime, code, data and access.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Compare responsibilities for OS, runtime, code, data and access.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 9: Cloud Security

## Part A — Student Lecture Notes

### Learning objectives

Explain cloud security, give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

Authentication verifies identity; authorization checks permission; encryption protects data.

### School website example

Build a student/teacher/admin permissions matrix and discuss shared responsibility.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

Authentication verifies identity; authorization checks permission; encryption protects data.

## Part B — Teacher’s Guide

### Technical background

Build a student/teacher/admin permissions matrix and discuss shared responsibility.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Build a student/teacher/admin permissions matrix and discuss shared responsibility.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final


---
# Lecture 10: Real-World Applications

## Part A — Student Lecture Notes

### Learning objectives

Explain real-world applications, give a real-world example and identify provider/customer responsibilities.

### Beginner explanation

Cloud systems combine services for websites, APIs, storage and event processing.

### School website example

Design a school website and evaluate cost, failure, security and recovery.

### Architecture diagram

```text
Students → Network → Website / Cloud Service → Storage → Response
```

### Key terminology

Provider: organization operating the service. Customer: organization using it. Resource: computing capability. Availability: ability to access the service.

### Summary

Cloud systems combine services for websites, APIs, storage and event processing.

## Part B — Teacher’s Guide

### Technical background

Design a school website and evaluate cost, failure, security and recovery.

### Architecture and internal operations

1. Identify the user request or event.
2. Determine which resources the provider operates.
3. Authenticate and authorize access.
4. Route the request to the application or resource.
5. Process and store data.
6. Monitor performance and failures.

### Traditional on-premises comparison

On-premises teams procure and operate physical hardware; cloud services delegate selected responsibilities. Managed services do not eliminate customer duties.

### Classroom demonstration

Design a school website and evaluate cost, failure, security and recovery.

### Advantages and limitations

Cloud services can speed provisioning and reduce administration, but introduce cost, connectivity, configuration and provider dependencies.

### Security and operational challenges

Discuss MFA, least privilege, network access, encryption, backup, monitoring, incident response and cost alerts.

### Common misconceptions

Cloud does not mean no physical servers. Cloud is not always cheaper or automatically secure.

### Questions and answers

**Who owns the security problem?** Both provider and customer, with duties depending on the model.

**Can it run on an intranet?** Private cloud-style services can be hosted internally.

### Teaching tips and activities

Use the same school website example; ask students to draw the architecture and label responsibilities.

### Additional resources

NIST definition: https://csrc.nist.gov/pubs/sp/800/145/final