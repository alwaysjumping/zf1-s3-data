# Cloud Computing Lecture Notes

Contains 11 lectures, with student notes and teacher guides. All content is Markdown for offline reading. External documentation links are optional and require Internet access.
