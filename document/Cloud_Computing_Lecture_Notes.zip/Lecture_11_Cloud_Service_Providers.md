# Lecture 11 — Real-World Cloud Services

**12 services with student notes and individual teacher guides.**

## Provider comparison

| Model | Service | Website | Purpose |

|---|---|---|---|

| SaaS | Google Workspace | https://workspace.google.com/ | Email and document collaboration |

| SaaS | Microsoft 365 | https://www.microsoft.com/microsoft-365 | Office, email, collaboration |

| SaaS | Salesforce | https://www.salesforce.com/ | Customer relationship management |

| PaaS | Heroku | https://www.heroku.com/ | Deploy web applications |

| PaaS | Google App Engine | https://cloud.google.com/appengine | Managed application hosting |

| PaaS | Azure App Service | https://azure.microsoft.com/en-us/products/app-service | Managed web/API hosting |

| IaaS | Amazon EC2 | https://aws.amazon.com/ec2/ | Virtual Linux/Windows servers |

| IaaS | Azure Virtual Machines | https://azure.microsoft.com/en-us/products/virtual-machines | Virtual Windows/Linux servers |

| IaaS | Google Compute Engine | https://cloud.google.com/compute | Configurable virtual computing |

| FaaS | AWS Lambda | https://aws.amazon.com/lambda/ | Event-triggered functions |

| FaaS | Azure Functions | https://azure.microsoft.com/en-us/products/functions | Serverless function execution |

| FaaS-style | Cloudflare Workers | https://workers.cloudflare.com/ | Distributed serverless request processing |


---
# Google Workspace

## Student Lecture Notes

**Service:** Google Workspace  
**Official website:** https://workspace.google.com/  
**Category:** SaaS

### Main purpose and problem solved
Email and document collaboration. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Email and document collaboration; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Google Workspace for email and document collaboration. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Google Workspace is an example of SaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Google Workspace exposes email and document collaboration through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving email and document collaboration. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://support.google.com/a/


---
# Microsoft 365

## Student Lecture Notes

**Service:** Microsoft 365  
**Official website:** https://www.microsoft.com/microsoft-365  
**Category:** SaaS

### Main purpose and problem solved
Office, email, collaboration. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Office, email, collaboration; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Microsoft 365 for office, email, collaboration. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Microsoft 365 is an example of SaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Microsoft 365 exposes office, email, collaboration through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving office, email, collaboration. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://learn.microsoft.com/en-us/microsoft-365/


---
# Salesforce

## Student Lecture Notes

**Service:** Salesforce  
**Official website:** https://www.salesforce.com/  
**Category:** SaaS

### Main purpose and problem solved
Customer relationship management. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Customer relationship management; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Salesforce for customer relationship management. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Salesforce is an example of SaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Salesforce exposes customer relationship management through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving customer relationship management. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://developer.salesforce.com/docs


---
# Heroku

## Student Lecture Notes

**Service:** Heroku  
**Official website:** https://www.heroku.com/  
**Category:** PaaS

### Main purpose and problem solved
Deploy web applications. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Deploy web applications; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Heroku for deploy web applications. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Heroku is an example of PaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Heroku exposes deploy web applications through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving deploy web applications. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://devcenter.heroku.com/


---
# Google App Engine

## Student Lecture Notes

**Service:** Google App Engine  
**Official website:** https://cloud.google.com/appengine  
**Category:** PaaS

### Main purpose and problem solved
Managed application hosting. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Managed application hosting; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Google App Engine for managed application hosting. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Google App Engine is an example of PaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Google App Engine exposes managed application hosting through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving managed application hosting. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://cloud.google.com/appengine/docs


---
# Azure App Service

## Student Lecture Notes

**Service:** Azure App Service  
**Official website:** https://azure.microsoft.com/en-us/products/app-service  
**Category:** PaaS

### Main purpose and problem solved
Managed web/API hosting. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Managed web/API hosting; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Azure App Service for managed web/api hosting. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Azure App Service is an example of PaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Azure App Service exposes managed web/api hosting through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving managed web/api hosting. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://learn.microsoft.com/en-us/azure/app-service/


---
# Amazon EC2

## Student Lecture Notes

**Service:** Amazon EC2  
**Official website:** https://aws.amazon.com/ec2/  
**Category:** IaaS

### Main purpose and problem solved
Virtual Linux/Windows servers. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Virtual Linux/Windows servers; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Amazon EC2 for virtual linux/windows servers. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Amazon EC2 is an example of IaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Amazon EC2 exposes virtual linux/windows servers through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving virtual linux/windows servers. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://docs.aws.amazon.com/ec2/


---
# Azure Virtual Machines

## Student Lecture Notes

**Service:** Azure Virtual Machines  
**Official website:** https://azure.microsoft.com/en-us/products/virtual-machines  
**Category:** IaaS

### Main purpose and problem solved
Virtual Windows/Linux servers. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Virtual Windows/Linux servers; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Azure Virtual Machines for virtual windows/linux servers. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Azure Virtual Machines is an example of IaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Azure Virtual Machines exposes virtual windows/linux servers through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving virtual windows/linux servers. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://learn.microsoft.com/en-us/azure/virtual-machines/


---
# Google Compute Engine

## Student Lecture Notes

**Service:** Google Compute Engine  
**Official website:** https://cloud.google.com/compute  
**Category:** IaaS

### Main purpose and problem solved
Configurable virtual computing. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Configurable virtual computing; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Google Compute Engine for configurable virtual computing. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Google Compute Engine is an example of IaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Google Compute Engine exposes configurable virtual computing through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving configurable virtual computing. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://cloud.google.com/compute/docs


---
# AWS Lambda

## Student Lecture Notes

**Service:** AWS Lambda  
**Official website:** https://aws.amazon.com/lambda/  
**Category:** FaaS

### Main purpose and problem solved
Event-triggered functions. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Event-triggered functions; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses AWS Lambda for event-triggered functions. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

AWS Lambda is an example of FaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

AWS Lambda exposes event-triggered functions through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving event-triggered functions. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://docs.aws.amazon.com/lambda/latest/dg/welcome.html


---
# Azure Functions

## Student Lecture Notes

**Service:** Azure Functions  
**Official website:** https://azure.microsoft.com/en-us/products/functions  
**Category:** FaaS

### Main purpose and problem solved
Serverless function execution. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Serverless function execution; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Azure Functions for serverless function execution. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Azure Functions is an example of FaaS; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Azure Functions exposes serverless function execution through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving serverless function execution. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://learn.microsoft.com/en-us/azure/azure-functions/


---
# Cloudflare Workers

## Student Lecture Notes

**Service:** Cloudflare Workers  
**Official website:** https://workers.cloudflare.com/  
**Category:** FaaS-style

### Main purpose and problem solved
Distributed serverless request processing. It replaces the need for customers to build or operate the entire equivalent capability themselves.

### How it works
A user or developer authenticates, configures the service, and sends requests or events to provider-managed infrastructure. The provider executes the relevant operations and returns results.

### Architecture

```text
User/Developer → Provider-managed service → Processing/Storage → Result
```

### Main features
Distributed serverless request processing; access controls; managed service operations; configuration and monitoring tools as applicable.

### Practical example

A school uses Cloudflare Workers for distributed serverless request processing. Identify which tasks remain with school staff.

### Getting started

1. Open the official website.
2. Review plans, trial and billing requirements.
3. Register a test organization or project.
4. Configure identities, permissions and resources.
5. Test with fictional data.
6. Monitor activity and clean up chargeable resources.

### Advantages and limitations

**Advantages:** Managed infrastructure and convenient access to the advertised capability.

**Limitations:** Service costs, platform-specific rules, configuration, provider dependency and network access requirements.

### Summary

Cloudflare Workers is an example of FaaS-style; explain what it provides and what its customers still manage.

## Teacher’s Guide

### Technical architecture

Cloudflare Workers exposes distributed serverless request processing through managed provider systems. Distinguish the control plane (account, configuration, permissions) from the data plane (request and data processing). Proprietary implementation details may not be public.

### Step-by-step operation

1. User authenticates.
2. Permissions and service configuration are evaluated.
3. Provider routes the request to an available execution resource.
4. The service performs the requested operation.
5. Data or results are returned and relevant activity logged.

### Comparison with traditional hosting

Identify which physical servers, operating systems, runtimes and applications an organization would need to install and maintain for an equivalent self-hosted solution.

### Classroom demonstration

Demonstrate or simulate a school use case involving distributed serverless request processing. Use only fictional data and remove temporary paid resources.

### Troubleshooting

- Access denied: check credentials, roles and permissions.
- Service unavailable: check status and network path.
- Incorrect result: check input and configuration.
- Unexpected bill: inspect usage and resource lifecycle.

### Security and operational challenges

MFA, least privilege, secure credentials, encryption, backups, logs, cost budgets and shared responsibility.

### Student questions

**Does the provider do everything?** No; customers still manage their configuration, access and data governance.

**Is a trial always free?** No; verify current billing and trial terms.

### Teaching tips

Use a diagram and compare the same task under traditional on-premises hosting.

### Official documentation

https://developers.cloudflare.com/workers/


---
# Classroom Capstone

Teams design a school website with SaaS, PaaS, IaaS or PaaS plus FaaS. Include an architecture diagram, access controls, cost categories, failure modes and provider/customer responsibilities.